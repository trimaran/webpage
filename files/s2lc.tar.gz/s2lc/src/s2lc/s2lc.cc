/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: s2lc.cc:
//   
//   Author: Sam Larsen
//   Date: Thu Dec  2 13:06:00 2004
//
//   Function:  SUIF to Lcode conversion
//		Known limitations:
//		- Doesn't support structure arguments
//
//===========================================================================

const int MIN_PARAM_SPACE = 16;

#include <Lcode/l_main.h>
#include <suif1.h>
#include <useful.h>
#include <string>
#ifdef SUIF_DEPS
#include "depend.h"
#endif
#include "cfg.h"
#include <assert.h>

int param_space;
int instr_count;
int reg_count;

FILE* outfile = stdout;

char* k_offset;
char* k_regnum;

enum Type {Int8,  UInt8,  Int16,  UInt16,  Int32,  UInt32,  Float32,  Float64,
	   VOID, LAST};
static int alu_ops[io_last][LAST];

void init_opcode_map();

// Class to gather function type information.  Primarily, this 
// consists of calculating correct stack offsets depending on
// argument size and alignment restrictions.
class func_info {
public:
  unsigned num_args() { return reg_args + mem_args; }
  unsigned num_reg_args() { return reg_args; }
  unsigned num_mem_args() { return mem_args; }

  int offset(int i) { return offsets[i]; }
  int reg_offset(int i) { return offsets[i]; }
  int mem_offset(int i) { return offsets[reg_args + i]; }

  type_node* type(int i) { return types[i]; }
  type_node* reg_type(int i) { return types[i]; }
  type_node* mem_type(int i) { return types[reg_args + i]; }

  type_node* return_type() { return ret_type; }
  int param_space() { return space; }
  bool has_varargs() { return varargs; }

  // Get the macro ID for parameter i
  int macro(int i) 
  {
    assert(i < reg_args);
    bool is_float = types[i]->unqual()->op() == TYPE_FLOAT;
#ifdef OPENIMPACT
    switch (offsets[i]) {
      case  0: return is_float ? L_MAC_P5 : L_MAC_P0;
      case  4: return is_float ? L_MAC_P6 : L_MAC_P1;
      case  8: return is_float ? L_MAC_P7 : L_MAC_P2;
      case 12: return is_float ? L_MAC_P8 : L_MAC_P3;
      default: assert(0);
    }
#else
    switch (offsets[i]) {
      case  -4: return is_float ? L_MAC_P5 : L_MAC_P0;
      case  -8: return is_float ? L_MAC_P6 : L_MAC_P1;
      case -12: return is_float ? L_MAC_P7 : L_MAC_P2;
      case -16: return is_float ? L_MAC_P8 : L_MAC_P3;
      default: assert(0);
    }
#endif
  }

protected:
  func_info() {}
  void compute_offsets()
  {
    reg_args = 0;
    mem_args = 0;

    int curr_off = 0;
    for (unsigned i=0; i<types.size(); i++)
    {
      type_node* tn = types[i];
      assert_msg(!tn->is_struct(), ("struct arguments not supported"));

      int align = get_alignment(tn) / 8;
      int size = tn->size() / 8;
      if (i < 4)
      {
	if (align < 4) align = 4;
	if (size < 4) size = 4;
      }

#ifdef OPENIMPACT
      offsets.push_back(-curr_off);
      curr_off = (curr_off - size) & ~(align-1);
#else
      curr_off = (curr_off - size) & ~(align-1);
      offsets.push_back(curr_off);
#endif    
      if (curr_off >= -16) reg_args++;
      else mem_args++;
    }

    space = -curr_off;
  }

  unsigned reg_args;
  unsigned mem_args;
  std::vector<int> offsets;
  std::vector<type_node*> types;
  type_node* ret_type;
  int space;
  bool varargs;
};

// Gather function information from a call instruction
class call_info : public func_info {
public:
  call_info(in_cal* call)
  {
    ret_type = call->result_type();
    varargs = false;

    for (unsigned i=0; i<call->num_args(); i++)
      types.push_back(call->argument(i).type());

    compute_offsets();
  }
};

// Gather function information from a tree_proc
class proc_info : public func_info {
public:
  proc_info(tree_proc* tp)
  {
    func_type* ftype = tp->proc()->type();
 
    ret_type = ftype->return_type();
    varargs = ftype->has_varargs();

    sym_node_list_iter iter(tp->proc_syms()->params());
    while (!iter.is_empty())
      types.push_back(((var_sym*)iter.step())->type());

    compute_offsets();
  }
};


// ------------------------------------------------------------------------

void set_offset(var_sym* sym, int offset)
{
  sym->set_annote(k_offset, new immed_list(immed(offset)));
}


int get_offset(var_sym* sym)
{
  immed_list* il = (immed_list*)sym->peek_annote(k_offset);
  assert(il != NULL);
  return il->head()->contents.integer();
}


Type get_base_type(type_node* tn)
{
  int size = tn->size();
  switch (tn->unqual()->op())
  {
    case TYPE_INT:
    {
      if (((base_type*)tn)->is_signed())
      {
	switch (size)
	{
	  case 8:  return Int8;
	  case 16: return Int16;
	  case 32: return Int32;
	  default: assert_msg(0, ("%d-bit integer type", size));
	}
      }
      else
      {
	switch (size)
	{
	  case 8:  return UInt8;
	  case 16: return UInt16;
	  case 32: return UInt32;
	  default: assert_msg(0, ("%d-bit unsigned type", size));
	}
      }	
    }
      
    case TYPE_FLOAT:
    {
      switch (size)
      {
	case 32: return Float32;
	case 64: return Float64;
	default: assert_msg(0, ("%d-bit float type", size));
      }
    }
    
    case TYPE_VOID: return VOID;
      
    case TYPE_ARRAY:
    case TYPE_PTR: return UInt32;
      
    case TYPE_FUNC:   assert_msg(0, ("bad type: TYPE_FUNC"));
    case TYPE_GROUP:  assert_msg(0, ("bad type: TYPE_GROUP"));
    case TYPE_STRUCT: assert_msg(0, ("bad type: TYPE_STRUCT"));
    case TYPE_UNION:  assert_msg(0, ("bad_type: TYPE_UNION"));
    case TYPE_ENUM:   assert_msg(0, ("bad_type: TYPE_ENUM"));
      
    default: assert(0);
  }
}


Type get_type(type_node* tn)
{
  Type type = get_base_type(tn);
  return type;
}


int get_reg_class(type_node* tn)
{
  switch (get_type(tn))
  {
    case Int8:
    case UInt8:
    case Int16:
    case UInt16:
    case Int32:
    case UInt32:  return L_CTYPE_INT;
    case Float32: return L_CTYPE_FLOAT;
    case Float64: return L_CTYPE_DOUBLE;
    default: assert(0);
  }
}


L_Oper* new_oper(int l_op)
{
  L_Oper* oper = L_new_oper(instr_count++);
  oper->proc_opc = l_op;
  oper->opc = l_op;
  oper->opcode = L_opcode_name(l_op);

  return oper;
}
  

L_Oper* new_alu_oper(if_ops opcode, type_node* tn)
{
  Type type = get_type(tn);

  int l_op = alu_ops[opcode][type];
  assert_msg(l_op >= 0, ("unknown op: %d with type %d", opcode, type));

  return new_oper(l_op);
}


L_Oper* new_alu_oper(instruction* instr)
{
  if_ops opcode = instr->opcode();
  assert(opcode != io_str);
  return new_alu_oper(opcode, instr->result_type());
}


L_Operand* new_reg_operand(type_node* type)
{
  int rclass = get_reg_class(type);
  return L_new_register_operand(reg_count++, rclass, L_PTYPE_NULL);
}


L_Operand* new_reg_operand(var_sym* sym)
{
  int rnum;

  immed_list* il = (immed_list*)sym->peek_annote(k_regnum);
  if (il == NULL)
  {
    rnum = reg_count++;
    sym->set_annote(k_regnum, new immed_list(immed(rnum)));
  }
  else rnum = il->head()->contents.integer();

  int rclass = get_reg_class(sym->type());
  return L_new_register_operand(rnum, rclass, L_PTYPE_NULL);
}


void load_from_stack(L_Cb* cb, var_sym* sym, L_Operand* opnd)
{
  assert(sym->is_auto());
  int macro = sym->is_param() ? L_MAC_IP : L_MAC_LV;

  L_Oper* load = new_alu_oper(io_lod, sym->type());
  load->src[0] = L_new_macro_operand(macro, L_CTYPE_INT, L_PTYPE_NULL);
  load->src[1] = L_new_gen_int_operand(get_offset(sym));
  load->dest[0] = opnd;

  L_insert_oper_after(cb, cb->last_op, load);
}


void load_global(L_Cb* cb, var_sym* sym, L_Operand* opnd)
{
  assert(sym->is_static());
  type_node* tn = sym->type();

  char* addr = (char*)(std::string("_") + sym->name()).c_str();

  L_Oper* load = new_alu_oper(io_lod, tn);
  load->src[0] = L_new_gen_label_operand(addr);
  load->src[1] = L_new_gen_int_operand(0);
  load->dest[0] = opnd;
  
  L_insert_oper_after(cb, cb->last_op, load);
}


L_Operand* read_source(L_Cb* cb, var_sym* sym)
{
  if (sym->is_auto())
  {
    if (sym->is_spilled())
    {
      L_Operand* opnd = new_reg_operand(sym->type());
      load_from_stack(cb, sym, opnd);
      return L_copy_operand(opnd);
    }
    else
    {
      return new_reg_operand(sym);
    }
  }
  else
  {
    L_Operand* opnd = new_reg_operand(sym->type());
    load_global(cb, sym, opnd);
    return L_copy_operand(opnd);
  }
}


void store_to_stack(L_Cb* cb, var_sym* sym, L_Operand* opnd)
{
  assert(sym->is_auto());
  int macro = sym->is_param() ? L_MAC_IP : L_MAC_LV;

  L_Oper* store = new_alu_oper(io_str, sym->type());
  store->src[0] = L_new_macro_operand(macro, L_CTYPE_INT, L_PTYPE_NULL);
  store->src[1] = L_new_gen_int_operand(get_offset(sym));
  store->src[2] = L_copy_operand(opnd);

  L_insert_oper_after(cb, cb->last_op, store);
}


void store_global(L_Cb* cb, var_sym* sym, L_Operand* opnd)
{
  assert(sym->is_static());
  type_node* tn = sym->type();

  char* addr = (char*)(std::string("_") + sym->name()).c_str();

  L_Oper* store = new_alu_oper(io_str, tn);
  store->src[0] = L_new_gen_label_operand(addr);
  store->src[1] = L_new_gen_int_operand(0);
  store->src[2] = opnd;

  L_insert_oper_after(cb, cb->last_op, store);
}


void write_dest(L_Cb* cb, L_Oper* oper, var_sym* sym)
{
  if (sym->is_auto())
  {
    if (sym->is_spilled())
    {
      oper->dest[0] = new_reg_operand(sym->type());
      store_to_stack(cb, sym, L_copy_operand(oper->dest[0]));
    }
    else
    {
      oper->dest[0] = new_reg_operand(sym);
    }
  }
  else
  {
    oper->dest[0] = new_reg_operand(sym->type());
    store_global(cb, sym, L_copy_operand(oper->dest[0]));
  }
}


L_Operand* do_immed_operand(L_Cb* cb, in_ldc* instr)
{
  immed imm = instr->value();
  if (imm.is_integer())
    return L_new_gen_int_operand(imm.integer());

  else if (imm.is_unsigned_int())
    return L_new_gen_int_operand(imm.unsigned_int());

  else if (imm.is_flt())
  {
    int size = instr->result_type()->size();
    switch (size)
    {
      case 32: return L_new_float_operand(imm.flt());
      case 64: return L_new_double_operand(imm.flt());
      default: assert_msg(0, ("%d-bit float type", size));
    }
  }
  
  else if (imm.is_symbol())
  {
    sym_node* node = imm.symbol();
    assert(node->is_var() || node->is_proc());

    if (node->is_var())
      assert_msg(((var_sym*)node)->parent_var() == NULL, 
		 ("encountered sub-var: run porky -no-sub-vars"));

    int offset = imm.offset() / 8;

    L_Operand* opnd;
    if (node->is_var() && ((var_sym*)node)->is_auto())
    {
      offset += get_offset((var_sym*)node);
      int macro = ((var_sym*)node)->is_param() ? L_MAC_IP : L_MAC_LV;
      opnd = L_new_macro_operand(macro, L_CTYPE_INT, L_PTYPE_NULL);
    }
    else
    {
      const char* pre = node->is_proc() ? "_$fn_" : "_";
      std::string tmp = std::string(pre) + node->name();
      opnd = L_new_gen_label_operand((char*)tmp.c_str());
    }

    if (offset == 0)
      return opnd;
    else
    {
      L_Oper* oper = new_alu_oper(io_add, type_unsigned);
      oper->src[0] = opnd;
      oper->src[1] = L_new_gen_int_operand(offset);
      oper->dest[0] = new_reg_operand(type_unsigned);
      L_insert_oper_after(cb, cb->last_op, oper);
      return L_copy_operand(oper->dest[0]);
    }
  }

  else assert_msg(0, ("unexpected immed type: %c", imm.kind()));
  return NULL;
}


L_Operand* do_operand(L_Cb* cb, const operand& oprnd)
{
  if (oprnd.is_immed())
    return do_immed_operand(cb, (in_ldc*)oprnd.instr());

  else if (oprnd.is_symbol())
    return read_source(cb, oprnd.symbol());

  else if (oprnd.is_null())
    return NULL;

  else if (oprnd.is_instr())
    assert_msg(0, ("encountered exp tree: run flatten"));

  else assert(0);
  return NULL;
}


void do_lod(L_Cb* cb, instruction* instr)
{
  L_Oper* oper = new_alu_oper(io_lod, instr->result_type());

  oper->src[0] = do_operand(cb, instr->src_op(0));
  oper->src[1] = L_new_gen_int_operand(0);

  L_insert_oper_after(cb, cb->last_op, oper);
  write_dest(cb, oper, instr->dst_op().symbol());

  // use the ext field to save away the suif instruction
  oper->ext = instr;
}


void do_str(L_Cb* cb, instruction* instr)
{
  type_node* tn = instr->src_op(1).type();
  L_Oper* oper = new_alu_oper(io_str, tn);

  oper->src[0] = do_operand(cb, instr->src_op(0));
  oper->src[1] = L_new_gen_int_operand(0);
  oper->src[2] = do_operand(cb, instr->src_op(1));

  L_insert_oper_after(cb, cb->last_op, oper);

  // use the ext field to save away the suif instruction
  oper->ext = instr;
}


void do_cvt(L_Cb* cb, instruction* instr)
{
  int src_class = get_reg_class(instr->src_op(0).type());
  int dst_class = get_reg_class(instr->result_type());

  int l_op;
  switch (src_class)
  {
    case L_CTYPE_INT:
      switch (dst_class)
      {
	case L_CTYPE_INT:    l_op = Lop_MOV;  break;
	case L_CTYPE_FLOAT:  l_op = Lop_I_F;  break;
	case L_CTYPE_DOUBLE: l_op = Lop_I_F2; break;
	default: assert(0);
      }
      break;

    case L_CTYPE_FLOAT:
      switch (dst_class)
      {
	case L_CTYPE_INT:    l_op = Lop_F_I;   break;
	case L_CTYPE_FLOAT:  l_op = Lop_MOV_F; break;
	case L_CTYPE_DOUBLE: l_op = Lop_F_F2;  break;
	default: assert(0);
      }
      break;

    case L_CTYPE_DOUBLE:
      switch (dst_class)
      {
	case L_CTYPE_INT:    l_op = Lop_F2_I;   break;
	case L_CTYPE_FLOAT:  l_op = Lop_F2_F;   break;
	case L_CTYPE_DOUBLE: l_op = Lop_MOV_F2; break;
	default: assert(0);
      }
      break;
    default: assert(0);
  }

  L_Oper* oper = new_oper(l_op);
  oper->src[0] = do_operand(cb, instr->src_op(0));
  L_insert_oper_after(cb, cb->last_op, oper);
  write_dest(cb, oper, instr->dst_op().symbol());
}


void do_rrr(L_Cb* cb, instruction* instr)
{
  L_Oper* oper = new_alu_oper(instr);

  for (unsigned i=0; i<instr->num_srcs(); i++)
    oper->src[i] = do_operand(cb, instr->src_op(i));
  
  L_insert_oper_after(cb, cb->last_op, oper);
  write_dest(cb, oper, instr->dst_op().symbol());
}


void do_gen(L_Cb* cb, in_gen* instr)
{
  int l_op = L_opcode_id(instr->name());
  assert_msg(l_op != -1, ("unknown gen op: %s\n", instr->name()));
  L_Oper* oper = new_oper(l_op);

  for (unsigned i=0; i<instr->num_srcs(); i++)
    oper->src[i] = do_operand(cb, instr->src_op(i));
  
  L_insert_oper_after(cb, cb->last_op, oper);
  write_dest(cb, oper, instr->dst_op().symbol());
}


L_Operand* new_param_macro(func_info& info, int param)
{
  int macro = info.macro(param);
  int rclass = get_reg_class(info.type(param));
  return L_new_macro_operand(macro, rclass, L_PTYPE_NULL);
}


L_Operand* new_macro_rtn(type_node* tn)
{
  switch (get_type(tn))
  {
    case Int8:
    case UInt8:
    case Int16:
    case UInt16:
    case Int32:
    case UInt32:
    case VOID:
      return L_new_macro_operand(L_MAC_P15, L_CTYPE_INT, L_PTYPE_NULL);

    case Float32:
      return L_new_macro_operand(L_MAC_P4, L_CTYPE_FLOAT, L_PTYPE_NULL);

    case Float64:
      return L_new_macro_operand(L_MAC_P4, L_CTYPE_DOUBLE, L_PTYPE_NULL);

    default: assert(0);
  }
}


void append_type_string(type_node* tn, std::string& str)
{
  if (tn->is_struct())
  {
    str += "S_";
    str += ((struct_type*)tn)->name();
  }
  else if (tn->is_ptr())
  {
    std::string tmp("+P");
    while ((tn = ((ptr_type*)tn)->ref_type())->is_ptr())
      tmp += "P";

    if (tn->is_func())
    {
      append_type_string(((func_type*)tn)->return_type(), str);
      str += tmp + "F";
    }
    else 
    {
      append_type_string(tn, str);
      str += tmp;
    }
  }
  else
  {
    switch (get_type(tn))
    {
      case Int8:    str += "char"; break;
      case UInt8:   str += "uchar"; break;
      case Int16:   str += "short"; break;
      case UInt16:  str += "ushort"; break;
      case Int32:   str += "int"; break;
      case UInt32:  str += "uint"; break;
      case Float32: str += "float"; break;
      case Float64: str += "double"; break;
      case VOID:    str += "void"; break;
      default: assert(0);
    }
  }
}


void attach_call_info(L_Attr*& targ, func_info& info)
{
  L_Attr* attr = L_new_attr("call_info", 1);
  targ = L_concat_attr(targ, attr);

  std::string str = "\"";
  append_type_string(info.return_type(), str);

  for (unsigned i=0; i<info.num_args(); i++)
  {
    str += "%";
    append_type_string(info.type(i), str);
  }
  if (info.has_varargs()) str += "%vararg";

  str += "\"";
  L_set_attr_field(attr, 0, L_new_gen_string_operand((char*)str.c_str()));
}


void attach_tr(L_Attr*& targ, func_info& info)
{
  if (info.num_reg_args() > 0)
  {
    L_Attr* attr = L_new_attr("tr", info.num_reg_args());
    targ = L_concat_attr(targ, attr);

    for (unsigned i=0; i<info.num_reg_args(); i++)
      L_set_attr_field(attr, i, new_param_macro(info, i));
  }
}


void attach_tro(L_Attr*& targ, func_info& info)
{
  if (info.num_reg_args() > 0)
  {
    L_Attr* attr = L_new_attr("tro", info.num_reg_args());
    targ = L_concat_attr(targ, attr);

    for (unsigned i=0; i<info.num_reg_args(); i++)
    {
      int offset = info.reg_offset(i);
      L_set_attr_field(attr, i, L_new_gen_int_operand(offset));
    }
  }
}


void attach_tmo(L_Attr*& targ, func_info& info)
{
  if (info.num_mem_args() > 0)
  {
    L_Attr* attr = L_new_attr("tmo", info.num_mem_args());
    targ = L_concat_attr(targ, attr);

    for (unsigned i=0; i<info.num_mem_args(); i++)
    {
      int offset = info.mem_offset(i);
      L_set_attr_field(attr, i, L_new_gen_int_operand(offset));
    }
  }
}


void attach_tms(L_Attr*& targ, func_info& info)
{
  if (info.num_mem_args() > 0)
  {
    L_Attr* attr = L_new_attr("tms", info.num_mem_args());
    targ = L_concat_attr(targ, attr);

    for (unsigned i=0; i<info.num_mem_args(); i++)
    {
      int size = info.mem_type(i)->size() / 8;
      L_set_attr_field(attr, i, L_new_gen_int_operand(size));
    }
  }
}


void attach_ret(L_Attr*& targ, func_info& info)
{
  L_Attr* attr = L_new_attr("ret", 1);
  targ = L_concat_attr(targ, attr);
  L_set_attr_field(attr, 0, new_macro_rtn(info.return_type()));
}


void do_cal(L_Cb* cb, in_cal* instr)
{
  L_Oper* call = new_oper(Lop_JSR);
  call->src[0] = do_operand(cb, instr->addr_op());

  call_info info(instr);
  if (info.param_space() > param_space)
    param_space = info.param_space();

  int count = 0;
  assert(info.num_args() == instr->num_args());
  for (unsigned i=0; i<info.num_reg_args(); i++)
  {
    operand arg = instr->argument(count++);

    L_Oper* move = new_alu_oper(io_cpy, arg.type());
    move->src[0] = do_operand(cb, arg);
    move->dest[0] = new_param_macro(info, i);
    L_insert_oper_after(cb, cb->last_op, move);
  }
  for (unsigned i=0; i<info.num_mem_args(); i++)
  {
    operand arg = instr->argument(count++);

    L_Oper* store = new_alu_oper(io_str, arg.type());
    store->src[0] = L_new_macro_operand(L_MAC_OP, L_CTYPE_INT, L_PTYPE_NULL);
    store->src[1] = L_new_gen_int_operand(info.mem_offset(i));
    store->src[2] = do_operand(cb, arg);
    L_insert_oper_after(cb, cb->last_op, store);
  }

  attach_tr(call->attr, info);
  attach_tmo(call->attr, info);
  attach_ret(call->attr, info);
  attach_call_info(call->attr, info);

  L_insert_oper_after(cb, cb->last_op, call);

  operand dst = instr->dst_op();
  if (dst.is_symbol())
  {
    L_Oper* move = new_alu_oper(io_cpy, dst.type());
    move->src[0] = new_macro_rtn(instr->result_type());
    L_insert_oper_after(cb, cb->last_op, move);
    write_dest(cb, move, dst.symbol());
  }
}


void do_ret(L_Cb* cb, instruction* instr)
{
  assert(instr->opcode() == io_ret);
  L_Oper* oper = new_oper(Lop_RTS);

  operand src = instr->src_op(0);
  if (!src.is_null())
  {
    L_Oper* move = new_alu_oper(io_cpy, src.type());
    move->src[0] = do_operand(cb, src);
    move->dest[0] = new_macro_rtn(src.type());
    
    L_Attr* attr = L_new_attr("tr", 1);
    L_set_attr_field(attr, 0, L_copy_operand(move->dest[0]));
    oper->attr = L_concat_attr(oper->attr, attr);

    L_insert_oper_after(cb, cb->last_op, move);
  }

  L_insert_oper_after(cb, cb->last_op, new_oper(Lop_EPILOGUE));
  L_insert_oper_after(cb, cb->last_op, oper);
}


void do_ldc(L_Cb* cb, in_ldc* instr)
{
  L_Oper* oper = new_alu_oper(io_cpy, instr->result_type());
  oper->src[0] = do_immed_operand(cb, instr);
  L_insert_oper_after(cb, cb->last_op, oper);
  write_dest(cb, oper, instr->dst_op().symbol());
}


void do_neg(L_Cb* cb, instruction* instr)
{
  type_node* tn = instr->result_type();
  L_Oper* oper = new_alu_oper(io_sub, tn);

  L_Operand* src0;
  switch (get_reg_class(tn))
  {
    case L_CTYPE_INT:    src0 = L_new_gen_int_operand(0); break;
    case L_CTYPE_FLOAT:  src0 = L_new_float_operand(0); break;
    case L_CTYPE_DOUBLE: src0 = L_new_double_operand(0); break;
    default: assert(0);
  }

  oper->src[0] = src0;
  oper->src[1] = do_operand(cb, instr->src_op(0));
  L_insert_oper_after(cb, cb->last_op, oper);
  write_dest(cb, oper, instr->dst_op().symbol());
}


void do_not(L_Cb* cb, instruction* instr)
{
  L_Oper* oper = new_alu_oper(io_xor, instr->result_type());
  oper->src[0] = L_new_gen_int_operand(-1);
  oper->src[1] = do_operand(cb, instr->src_op(0));
  L_insert_oper_after(cb, cb->last_op, oper);
  write_dest(cb, oper, instr->dst_op().symbol());
}


void do_jmp(cfg* graph, L_Func* fn, L_Cb* cb, in_bj* instr)
{
  L_Oper* oper = new_oper(Lop_JUMP);
  int id = graph->lookup(instr->target())->get_number();
  L_Cb* target = L_cb_hash_tbl_find(fn->cb_hash_tbl, id);
  oper->src[0] = L_new_cb_operand(target);
  L_insert_oper_after(cb, cb->last_op, oper);
}

#ifdef OPENIMPACT
void do_cmp(L_Cb* cb, instruction* instr)
{
  int comp;
  switch (instr->opcode()) {
    case io_seq: comp = Lcmp_COM_EQ; break;
    case io_sne: comp = Lcmp_COM_NE; break;
    case io_sl:  comp = Lcmp_COM_LT; break;
    case io_sle: comp = Lcmp_COM_LE; break;
    default: assert(0);
  }

  int opc, type;
  switch (get_type(instr->src_op(0).type())) {
    case Int32:   opc = Lop_RCMP;   type = L_CTYPE_INT; break;
    case UInt32:  opc = Lop_RCMP;   type = L_CTYPE_UINT; break;
    case Float32: opc = Lop_RCMP_F; type = L_CTYPE_FLOAT; break;
    case Float64: opc = Lop_RCMP_F; type = L_CTYPE_DOUBLE; break;
    default: assert(0);
  }

  L_Oper* oper = new_oper(opc);
  L_set_compare(oper, type, comp);

  for (unsigned i=0; i<instr->num_srcs(); i++)
    oper->src[i] = do_operand(cb, instr->src_op(i));

  L_insert_oper_after(cb, cb->last_op, oper);
  write_dest(cb, oper, instr->dst_op().symbol());
}


void do_cbr(cfg* graph, L_Func* fn, L_Cb* cb, in_bj* instr)
{
  operand src = instr->src_op();
  bool btrue = instr->opcode() == io_btrue;

  L_Oper* oper = NULL;
  if (src.is_symbol() || src.is_immed())
  {
    oper = new_oper(Lop_BR);
    L_set_compare(oper, L_CTYPE_INT, btrue ? Lcmp_COM_NE : Lcmp_COM_EQ);
    oper->src[0] = do_operand(cb, instr->src_op());
    oper->src[1] = L_new_gen_int_operand(0);
  }

  else
  {
    assert(src.is_instr());
    instruction* cmp = src.instr();

    int comp;
    switch (cmp->opcode()) {
      case io_seq: comp = btrue ? Lcmp_COM_EQ : Lcmp_COM_NE; break;
      case io_sne: comp = btrue ? Lcmp_COM_NE : Lcmp_COM_EQ; break;
      case io_sl:  comp = btrue ? Lcmp_COM_LT : Lcmp_COM_GE; break;
      case io_sle: comp = btrue ? Lcmp_COM_LE : Lcmp_COM_GT; break;
      default: assert(0);
    }

    int opc, type;
    switch (get_type(cmp->src_op(0).type())) {
      case Int32:   opc = Lop_BR;   type = L_CTYPE_INT; break;
      case UInt32:  opc = Lop_BR;   type = L_CTYPE_UINT; break;
      case Float32: opc = Lop_BR_F; type = L_CTYPE_FLOAT; break;
      case Float64: opc = Lop_BR_F; type = L_CTYPE_DOUBLE; break;
      default: assert(0);
    }

    oper = new_oper(opc);
    L_set_compare(oper, type, comp);
    oper->src[0] = do_operand(cb, cmp->src_op(0));
    oper->src[1] = do_operand(cb, cmp->src_op(1));
  }

  int id = graph->lookup(instr->target())->get_number();
  L_Cb* target = L_cb_hash_tbl_find(fn->cb_hash_tbl, id);
  oper->src[2] = L_new_cb_operand(target);
  
  L_insert_oper_after(cb, cb->last_op, oper);
}


#else
void do_cmp(L_Cb* cb, instruction* instr)
{
  L_Oper* oper = new_alu_oper(instr->opcode(), instr->src_op(0).type());

  for (unsigned i=0; i<instr->num_srcs(); i++)
    oper->src[i] = do_operand(cb, instr->src_op(i));
  
  L_insert_oper_after(cb, cb->last_op, oper);
  write_dest(cb, oper, instr->dst_op().symbol());
}


void do_cbr(cfg* graph, L_Func* fn, L_Cb* cb, in_bj* instr)
{
  static int BEQ[] = {Lop_BEQ, Lop_BEQ,   Lop_BEQ_F, Lop_BEQ_F2};
  static int BNE[] = {Lop_BNE, Lop_BNE,   Lop_BNE_F, Lop_BNE_F2};
  static int BLT[] = {Lop_BLT, Lop_BLT_U, Lop_BLT_F, Lop_BLT_F2};
  static int BLE[] = {Lop_BLE, Lop_BLE_U, Lop_BLE_F, Lop_BLE_F2};
  static int BGT[] = {Lop_BGT, Lop_BGT_U, Lop_BGT_F, Lop_BGT_F2};
  static int BGE[] = {Lop_BGE, Lop_BGE_U, Lop_BGE_F, Lop_BGE_F2};

  if_ops opcode = instr->opcode();
  operand src = instr->src_op();

  L_Oper* oper = NULL;
  if (src.is_symbol() || src.is_immed())
  {
    int index;
    switch (get_type(src.type()))
    {
      case Int32:  index = 0; break;
      case UInt32: index = 1; break;
      default: assert(0);
    }

    oper = new_oper((opcode == io_btrue) ? BNE[index] : BEQ[index]);
    oper->src[0] = do_operand(cb, instr->src_op());
    oper->src[1] = L_new_gen_int_operand(0);
  }

  else
  {
    assert(src.is_instr());
    instruction* cmp = src.instr();

    int index;
    switch (get_type(cmp->src_op(0).type()))
    {
      case Int32:   index = 0; break;
      case UInt32:  index = 1; break;
      case Float32: index = 2; break;
      case Float64: index = 3; break;
      default: assert(0);
    }

    int opc;
    if (opcode == io_btrue)
    {
      switch (cmp->opcode())
      {
	case io_seq: opc = BEQ[index]; break;
	case io_sne: opc = BNE[index]; break;
	case io_sle: opc = BLE[index]; break;
	case io_sl:  opc = BLT[index]; break;
	default: assert(0);
      }
    }
    else
    {
      assert(opcode == io_bfalse);
      switch (cmp->opcode())
      {
	case io_seq: opc = BNE[index]; break;
	case io_sne: opc = BEQ[index]; break;
	case io_sle: opc = BGT[index]; break;
	case io_sl:  opc = BGE[index]; break;
	default: assert(0);
      }
    }

    oper = new_oper(opc);
    oper->src[0] = do_operand(cb, cmp->src_op(0));
    oper->src[1] = do_operand(cb, cmp->src_op(1));
  }

  int id = graph->lookup(instr->target())->get_number();
  L_Cb* target = L_cb_hash_tbl_find(fn->cb_hash_tbl, id);
  oper->src[2] = L_new_cb_operand(target);
  
  L_insert_oper_after(cb, cb->last_op, oper);
}
#endif


// Convert SUIF annotations to lcode attributes.
void do_annotes(L_Cb* cb, instruction* instr)
{
  L_Oper* oper = cb->last_op;
  assert(oper != NULL);

  annote_list_iter iter(instr->annotes());
  while (!iter.is_empty())
  {
    annote* note = iter.step();
    char* name = note->name();

    annote_def* def = lookup_annote(name);
    if (def != NULL && def->output() && 
	// Some annotations are for SUIF internal use - don't copy them over
	strcmp(name, "fields") &&
	strcmp(name, "io write") &&
	strcmp(name, "io read"))
    {
      immed_list* immeds = note->immeds();
      L_Attr* attr = L_new_attr(name, immeds->count());
      oper->attr = L_concat_attr(oper->attr, attr);
      
      int index = 0;
      immed_list_iter data(immeds);
      while (!data.is_empty())
      {
	L_Operand* field;
	immed imm = data.step();
	switch (imm.kind()) 
	{
	  case im_float: 
	    field = L_new_double_operand(imm.flt());
	    break;
	  case im_string:
	    field = L_new_gen_string_operand(imm.string());
	    break;
	  case im_int:
	    field = L_new_gen_int_operand(imm.integer());
	    break;
	  default: 
	    assert_msg(0, ("unsupported immed kind '%c' in annote %s",
			   imm.kind(), note->name()));
	}
	L_set_attr_field(attr, index++, field);
      }
    }
  }
}


void do_instr(cfg* graph, L_Func* fn, L_Cb* cb, instruction* instr)
{
  switch (instr->opcode())
  {
    case io_mrk: 
    case io_lab: return;

    case io_lod: do_lod(cb, instr); break;
    case io_str: do_str(cb, instr); break;
    case io_cvt: do_cvt(cb, instr); break;
    case io_ret: do_ret(cb, instr); break;
    case io_neg: do_neg(cb, instr); break;
    case io_not: do_not(cb, instr); break;
    case io_cal: do_cal(cb, (in_cal*)instr); break;
    case io_ldc: do_ldc(cb, (in_ldc*)instr); break;
    case io_jmp: do_jmp(graph, fn, cb, (in_bj*)instr); break;
    case io_btrue:
    case io_bfalse: do_cbr(graph, fn, cb, (in_bj*)instr); break;
    case io_seq: 
    case io_sne: 
    case io_sl:  
    case io_sle: do_cmp(cb, instr); break;
    case io_gen: do_gen(cb, (in_gen*)instr); break;
    default:     do_rrr(cb, instr); break;
  }

  do_annotes(cb, instr);
}


void do_block(cfg* graph, L_Func* fn, Block* block)
{
  L_Cb* cb = L_cb_hash_tbl_find(fn->cb_hash_tbl, block->get_number());
  assert(cb != NULL);

  const std::vector<instruction*>& instrs = block->get_instrs();
  for (size_t i=0; i<instrs.size(); i++)
  {
    instruction* instr = instrs[i];
    do_instr(graph, fn, cb, instr);
  }
}


void connect_blocks(L_Func* fn, Block* src, Block* dst, int taken)
{
  int src_id = src->get_number();
  int dst_id = dst->get_number();

  L_Cb* src_cb = L_cb_hash_tbl_find(fn->cb_hash_tbl, src_id);
  L_Cb* dst_cb = L_cb_hash_tbl_find(fn->cb_hash_tbl, dst_id);

  L_Flow* flow = L_new_flow(taken, src_cb, dst_cb, 0.0);
  src_cb->dest_flow = L_concat_flow(src_cb->dest_flow, flow);
}


bool is_taken_edge(Block* src, Block* dst)
{
  instruction* jump = src->get_instrs().back();
  if (jump->format() == inf_bj)
  {
    instruction* targ = dst->get_instrs().front();
    if (targ->format() == inf_lab)
    {
      if (((in_bj*)jump)->target() == ((in_lab*)targ)->label())
	return true;
    }
  }

  return false;
}


void do_body(L_Func* fn, tree_proc* tp)
{
  cfg graph(tp);

  // Build all the blocks
  const std::vector<Block*>& blocks = graph.get_blocks();
  for (unsigned i=0; i<blocks.size(); i++)
  {
    Block* block = blocks[i];
    if (!block->is_entry() && !block->is_exit())
    {
      L_Cb* cb = L_new_cb(block->get_number());
      L_insert_cb_after(fn, fn->last_cb, cb);
    }
  }

  // Insert operations
  for (unsigned i=0; i<blocks.size(); i++)
  {
    Block* block = blocks[i];
    if (!block->is_entry() && !block->is_exit())
      do_block(&graph, fn, block);
  }

  // Create flow edges between the blocks
  for (unsigned i=0; i<blocks.size(); i++)
  {
    Block* src = blocks[i];
    if (!src->is_entry() && !src->is_exit())
    {
      const std::vector<Block*>& succs = src->get_succs();
      assert(succs.size() <= 2);

      Block* fall = NULL;
      for (size_t j=0; j<succs.size(); j++)
      {
	Block* dst = succs[j];
	if (!dst->is_entry() && !dst->is_exit())
	{
	  if (is_taken_edge(src, dst))
	    connect_blocks(fn, src, dst, 1);
	  else
	  {
	    // There should be at most one fallthrough edge
	    assert(fall == NULL);
	    fall = dst;
	  }
	}
      }

      // Elcor wants to have the fallthrough edge last
      if (fall) connect_blocks(fn, src, fall, 0);
    }
  }
}


void do_proc_decl(tree_proc* tp)
{
  L_Data* data;
  L_Datalist* datalist = L_new_datalist();

  data = L_new_data(L_INPUT_MS);
  data->N = L_MS_TEXT;
  L_concat_datalist_element(datalist, L_new_datalist_element(data));

  data = L_new_data(L_INPUT_GLOBAL);
  data->address = L_new_expr_label(tp->proc()->name());
  L_concat_datalist_element(datalist, L_new_datalist_element(data));

  L_print_datalist(outfile, datalist);
  L_delete_datalist(datalist);
}


void handle_locals(L_Cb* cb, tree_proc*tp)
{
  int offset = 0;
  sym_node_list_iter iter(tp->proc_syms()->symbols());
  while (!iter.is_empty())
  {
    var_sym* sym = (var_sym*)iter.step();
    if (sym->is_var())
    {
      assert_msg(sym->is_auto(), ("static local: run porky -globalize"));
      if (!sym->is_param() && sym->is_spilled())
      {
	type_node* tn = sym->type();
	int size = tn->size() / 8;
	int align = get_alignment(tn) / 8;

	offset = (offset - size) & ~(align-1);
	assert_msg(offset < 0, ("LV stack overflow"));
	set_offset(sym, offset);
      }
    }
  }

  L_Oper* oper = new_oper(Lop_DEFINE);
  oper = new_oper(Lop_DEFINE);
  oper->dest[0] = L_new_macro_operand(L_MAC_LOCAL_SIZE, L_CTYPE_INT, 0);
  oper->src[0] = L_new_gen_int_operand(-offset);
  L_insert_oper_after(cb, cb->last_op, oper);
}


void handle_params(L_Cb* cb, tree_proc* tp)
{
  proc_info info(tp);

  sym_node_list_iter iter(tp->proc_syms()->params());
  for (int i=0; i<info.num_args(); i++)
  {
    var_sym* sym = (var_sym*)iter.step();
    assert(sym->is_param());

    int offset = info.offset(i);
    set_offset(sym, offset);

    // parameter is in a register
    if (i < info.num_reg_args())
    {
      if (sym->is_spilled())
	store_to_stack(cb, sym, new_param_macro(info, i));

      else
      {
	L_Oper* oper = new_alu_oper(io_cpy, sym->type());
	oper->src[0] = new_param_macro(info, i);
	oper->dest[0] = new_reg_operand(sym);
	L_insert_oper_after(cb, cb->last_op, oper);
      }
    }

    // parameter is on the stack
    else
    {
      if (!sym->is_spilled())
	load_from_stack(cb, sym, new_reg_operand(sym));
    }
  }
}


void insert_param_def(L_Cb* cb, L_Oper* pos)
{
  L_Oper* oper = new_oper(Lop_DEFINE);
  oper->dest[0] = L_new_macro_operand(L_MAC_PARAM_SIZE, L_CTYPE_INT, 0);
  oper->src[0] = L_new_gen_int_operand(param_space);
  L_insert_oper_after(cb, pos, oper);
}

#ifdef SUIF_DEPS
void add_sync_between_opers(L_Oper* op1, L_Oper* op2, int dist)
{
  L_Sync* sync1 = L_new_sync(op2);
  sync1->dist = dist;
  sync1->info = dist == 0 ? SET_NONLOOP_CARRIED(0) : SET_INNER_CARRIED(0);
  sync1->info |= SET_DEFINITE_SYNC(0);

  L_Sync* sync2 = L_new_sync(op1);
  sync2->dist = dist;
  sync2->info = sync1->info;

  L_insert_head_sync_in_oper(op1, sync1);
  L_insert_tail_sync_in_oper(op2, sync2);
}


// Return the size in bytes of the data accessed by this memop
int get_access_size(L_Oper* op)
{
  int opc = op->opc;

  if (opc == alu_ops[io_lod][Int8] ||
      opc == alu_ops[io_lod][UInt8] ||
      opc == alu_ops[io_str][Int8] ||
      opc == alu_ops[io_str][UInt8])
    return type_signed_char->size() / 8;

  if (opc == alu_ops[io_lod][Int16] ||
      opc == alu_ops[io_lod][UInt16] ||
      opc == alu_ops[io_str][Int16] ||
      opc == alu_ops[io_str][UInt16])
    return type_signed_short->size() / 8;

  if (opc == alu_ops[io_lod][Int32] ||
      opc == alu_ops[io_lod][UInt32] ||
      opc == alu_ops[io_str][Int32] ||
      opc == alu_ops[io_str][UInt32])
    return type_signed->size() / 8;

  if (opc == alu_ops[io_lod][Float32] ||
      opc == alu_ops[io_str][Float32])
    return type_float->size() / 8;

  if (opc == alu_ops[io_lod][Float64] ||
      opc == alu_ops[io_str][Float64])
    return type_double->size() / 8;

  assert_msg(0, ("unexpected opcode"));
  return 0;
}


// This function is used to determine independence for accesses to 
// globals and the stack.
bool independent_memops(L_Oper* op1, L_Oper* op2)
{
  L_Operand* op1_base = op1->src[0];
  L_Operand* op2_base = op2->src[0];

  L_Operand* op1_offset = op1->src[1];
  L_Operand* op2_offset = op2->src[1];

  // If the base operand is a macro register, the associated memop
  // is a stack access.
  if (L_is_macro(op1_base) && L_is_macro(op2_base))
  {
    // Accesses to different portions of the stack are independent
    if (!L_same_operand(op1_base, op2_base))
      return true;

    // Independent if there's no overlap
    if (L_is_int_constant(op1_offset) && L_is_int_constant(op2_offset))
      return L_no_overlap(op1_offset->value.i, get_access_size(op1),
			  op2_offset->value.i, get_access_size(op2));
  }

  // Stack access independent of a global access
  else if ((L_is_label(op1_base) && L_is_macro(op2_base)) ||
	   (L_is_label(op2_base) && L_is_macro(op1_base)))
    return true;

  // Accesses to globals
  else if (L_is_label(op1_base) && L_is_label(op2_base))
  {
    // Accesses to different globals are independent
    if (strcmp(op1_base->value.l, op2_base->value.l))
      return true;

    // Independent of there's no overlap
    if (L_is_int_constant(op1_offset) && L_is_int_constant(op2_offset))
      return L_no_overlap(op1_offset->value.i, get_access_size(op1),
			  op2_offset->value.i, get_access_size(op2));
  }

  return false;
}


// Insert dependences between memory operations
void insert_sync_arcs(tree_proc* tp, L_Func* fn, src_lang_type lang)
{
  std::vector<L_Oper*> ld_ops;
  std::vector<L_Oper*> st_ops;

  // Build lists of all loads and stores
  for (L_Cb* cb = fn->first_cb; cb != NULL; cb = cb->next_cb)
  {
    for (L_Oper* op = cb->first_op; op != NULL; op = op->next_op)
    {
      if (L_load_opcode(op))
	ld_ops.push_back(op);
      else if (L_store_opcode(op))
	st_ops.push_back(op);
    }
  }

  // dependences between load and stores
  for (size_t i=0; i<st_ops.size(); i++)
  {
    L_Oper* st_op = st_ops[i];
    instruction* st_instr = (instruction*)st_op->ext;

    for (size_t j=0; j<ld_ops.size(); j++)
    {
      L_Oper* ld_op = ld_ops[j];
      instruction* ld_instr = (instruction*)ld_op->ext;

      if (!independent_memops(st_op, ld_op))
      {
	// See if more accurate dep info is available from SUIF
	if (st_instr && ld_instr)
	{
	  int dist;
	  if (is_dependence(st_instr, ld_instr, lang, &dist))
	    add_sync_between_opers(st_op, ld_op, dist);
	  if (is_dependence(ld_instr, st_instr, lang, &dist))
	    add_sync_between_opers(ld_op, st_op, dist);
	}
	// Otherwise assume the worst
	else
	{
	  add_sync_between_opers(st_op, ld_op, 0);
	  add_sync_between_opers(ld_op, st_op, 0);
	}
      }
    }
  }

  // dependences between stores
  for (size_t i=0; i<st_ops.size(); i++)
  {
    L_Oper* st_op1 = st_ops[i];
    instruction* st_instr1 = (instruction*)st_op1->ext;

    for (size_t j=i+1; j<st_ops.size(); j++)
    {
      L_Oper* st_op2 = st_ops[j];
      instruction* st_instr2 = (instruction*)st_op2->ext;

      if (!independent_memops(st_op1, st_op2))
      {
	// See if more accurate dep info is available from SUIF
	if (st_instr1 && st_instr2)
	{
	  int dist;
	  if (is_dependence(st_instr1, st_instr2, lang, &dist))
	    add_sync_between_opers(st_op1, st_op2, dist);
	  if (is_dependence(st_instr2, st_instr1, lang, &dist))
	    add_sync_between_opers(st_op2, st_op1, dist);
	}
	// Otherwise assume the worst
	else
	{
	  add_sync_between_opers(st_op1, st_op2, 0);
	  add_sync_between_opers(st_op2, st_op1, 0);
	}
      }
    }
  }

  // Attach attribute to indicate that sync arcs have been added
  L_Attr* attr = L_new_attr("DEP_PRAGMAS", 0);
  fn->attr = L_concat_attr(fn->attr, attr);

  // Use original lcode function to draw jsr arcs
  L_build_sync_arcs_from_lcode_disamb(fn, L_SYNC_TYPE_JSR_GLOBAL, 1);
}
#endif

void do_proc(tree_proc* tp)
{
  // Various initializations
  reg_count = 0;
  instr_count = 0;
  param_space = MIN_PARAM_SPACE;

  // Create the proc
  proc_sym* ps = tp->proc();
  std::string name = std::string("_") + ps->name();
  L_Func* fn = L_new_func((char*)name.c_str(), 0.0);
  L_fn = fn;

  // Attach necessary call attributes
  proc_info info(tp);
  attach_call_info(fn->attr, info);
  attach_tr(fn->attr, info);
  attach_tro(fn->attr, info);
  attach_tmo(fn->attr, info);
  attach_tms(fn->attr, info);

  // Block 0 holds the various define ops
  L_Cb* cb = L_new_cb(0);
  L_insert_cb_after(fn, fn->last_cb, cb);

  handle_locals(cb, tp);
  L_Oper* pos = cb->last_op;

  L_insert_oper_after(cb, cb->last_op, new_oper(Lop_PROLOGUE));
  handle_params(cb, tp);

  do_body(fn, tp);

  insert_param_def(cb, pos);
#ifdef SUIF_DEPS
  insert_sync_arcs(tp, fn, tp->proc()->src_lang());
#endif

  // Insert flow edge from block 0 to the first real block
  L_Flow* flow = L_new_flow(0, cb, cb->next_cb, 0.0);
  cb->dest_flow = L_concat_flow(cb->dest_flow, flow);

  // Print everything out
  do_proc_decl(tp);
  L_print_func(outfile, fn);
  L_delete_func(fn);
}


void name_anon_types()
{
  global_symtab* globals = fileset->globals();

  type_node_list_iter iter(globals->types());
  while (!iter.is_empty())
  {
    type_node* tn = (struct_type*)iter.step();
    if (tn->is_struct())
    {
      struct_type* type = (struct_type*)tn;
      char* name = type->name();
      if (!isalpha(name[0]) && name[0] != '_')
	type->set_name((char*)(std::string("__tmp") + name).c_str());
    }
  }

  globals->rename_duplicates();
}


void rename_statics()
{
  base_symtab_list_iter iter(fileset->globals()->children());
  while (!iter.is_empty())
  {
    base_symtab* symtab = iter.step();

    std::string prefix(symtab->name());
    for (size_t i=0; i<prefix.size(); i++)
      if (prefix[i] == '.') prefix[i] = '_';

    sym_node_list_iter syms(symtab->symbols());
    while (!syms.is_empty())
    {
      var_sym* sym = (var_sym*)syms.step();
      if (sym->is_var() && sym->has_var_def())
      {
	std::string name(prefix + "_" + sym->name());
	sym->set_name((char*)name.c_str());
      }
    }
  }
}


void set_h_type(L_Type* h_type, type_node* tn)
{
  type_ops op = tn->op();

/*
  assert_msg(op != TYPE_GROUP, ("can't handle GROUP types\n"));
  if (op == TYPE_STRUCT)
  {
    h_type->type = L_DATA_STRUCT;
    h_type->struct_name = ((struct_type*)tn)->name();
  }
  else if (op == TYPE_UNION)
  {
    h_type->type = L_DATA_UNION;
    h_type->struct_name = ((struct_type*)tn)->name();
  }
*/

  // Declaring SUIF 'group' types is complicated since fields are 
  // allowed to overlap arbitrarily.  Theoretically, a group should
  // be broken down into unions and structs.  This is what is 
  // done in SUIF's s2c pass for example.  Unfortunately, the code
  // to do this is hairy and not available in a standalone library.
  // To make matters worse, the implementation is buggy.
  //
  // Just declare all structs, unions, and groups as arrays of chars
  // (appropriately sized).  There's nothing in the lcode that 
  // references field names anyway, so chunk of memory suffices.
  if (tn->is_struct())
  {
    L_Dcltr* dcltr = L_new_dcltr();
    h_type->dcltr = L_concat_dcltr(h_type->dcltr, dcltr);
    dcltr->method = L_D_ARRY;
    dcltr->index = L_new_expr_int(tn->size() / 8);
    set_h_type(h_type, type_char);
  }

  else if (op == TYPE_PTR)
  {
    L_Dcltr* dcltr = L_new_dcltr();
    h_type->dcltr = L_concat_dcltr(h_type->dcltr, dcltr);
    dcltr->method = L_D_PTR;
    set_h_type(h_type, ((ptr_type*)tn)->ref_type());
  }

  else if (op == TYPE_ARRAY)
  {
    L_Dcltr* dcltr = L_new_dcltr();
    h_type->dcltr = L_concat_dcltr(h_type->dcltr, dcltr);
    dcltr->method = L_D_ARRY;

    int too_messy = 0;
    int size = array_num_elem((array_type*)tn, &too_messy);
    assert(!too_messy);

    dcltr->index = L_new_expr_int(size);
    set_h_type(h_type, ((array_type*)tn)->elem_type());
  }
  
  else if (op == TYPE_FUNC)
  {
    L_Dcltr* dcltr = L_new_dcltr();
    h_type->dcltr = L_concat_dcltr(h_type->dcltr, dcltr);
    dcltr->method = L_D_FUNC;
    set_h_type(h_type, ((func_type*)tn)->return_type());
  }

  else switch (get_type(tn))
  {
    case Int8:   
    case UInt8:   h_type->type = L_DATA_CHAR;   break;
    case Int16:  
    case UInt16:  h_type->type = L_DATA_SHORT;  break;
    case Int32:    
    case UInt32:  h_type->type = L_DATA_INT;    break;
    case Float32: h_type->type = L_DATA_FLOAT;  break;
    case Float64: h_type->type = L_DATA_DOUBLE; break;
    case VOID:    h_type->type = L_DATA_VOID;   break;
    default: assert(0);
  }
}


void set_h_type(L_Data* data, type_node* tn)
{
  data->h_type = L_new_type();
  set_h_type(data->h_type, tn);
}


void do_struct_decls()
{
  L_Data* data;
  L_Datalist* datalist = L_new_datalist();

  data = L_new_data(L_INPUT_MS);
  data->N = L_MS_BSS;
  L_concat_datalist_element(datalist, L_new_datalist_element(data));

  type_node_list_iter iter(fileset->globals()->types());
  while (!iter.is_empty())
  {
    struct_type* type = (struct_type*)iter.step();
    if (type->is_struct())
    {
      switch (type->op()) {
	case TYPE_GROUP:  assert_msg(0, ("can't handle GROUP types\n"));
	case TYPE_STRUCT: data = L_new_data(L_INPUT_DEF_STRUCT); break;
	case TYPE_UNION:  data = L_new_data(L_INPUT_DEF_UNION); break;
	default: assert(0);
      }

      data->address = L_new_expr_string(type->name());
      L_concat_datalist_element(datalist, L_new_datalist_element(data));

      sort_fields_by_offset(type);
      for (unsigned i=0; i<type->num_fields(); i++)
      {
	data = L_new_data(L_INPUT_FIELD);
	data->address = L_new_expr_string(type->field_name(i));
	set_h_type(data, type->field_type(i));
	L_concat_datalist_element(datalist, L_new_datalist_element(data));
      }
    }
  }

  L_print_datalist(outfile, datalist);
  L_delete_datalist(datalist);
}


L_Data* new_init_data(immed imm, int size, char* base, int offset)
{
  L_Data* data;

  if (imm.is_integer())
  {
    switch (size)
    {
      case 1: data = L_new_data(L_INPUT_WB); break;
      case 2: data = L_new_data(L_INPUT_WW); break;
      case 4: data = L_new_data(L_INPUT_WI); break;
      default: assert(0);
    }
    data->value = L_new_expr_int(imm.integer());
  }
  else if (imm.is_unsigned_int())
  {
    assert(size == 4);
    data = L_new_data(L_INPUT_WI);
    data->value = L_new_expr_int(imm.unsigned_int());
  }
  else if (imm.is_flt())
  {
    switch (size)
    {
      case 4: 
	data = L_new_data(L_INPUT_WF);
	data->value = L_new_expr_float(imm.flt());
	break;

      case 8: 
	data = L_new_data(L_INPUT_WF2);
	data->value = L_new_expr_double(imm.flt());
	break;

      default: assert(0);
    }
  }
  else if (imm.is_symbol())
  {
    data = L_new_data(L_INPUT_WI);
    data->value = L_new_expr_label(imm.symbol()->name());
  }
  else assert_msg(0, ("unexpected immed type: %c", imm.kind()));

  data->address = L_new_expr_addr(base, offset);
  return data;
}


void do_data(L_Datalist* datalist, var_sym* sym)
{
  L_Data* data;
  char* address = sym->name();
  type_node* type = sym->type();

  data = L_new_data(L_INPUT_GLOBAL);
  data->address = L_new_expr_label(address);
  set_h_type(data, type);
  L_concat_datalist_element(datalist, L_new_datalist_element(data));

  data = L_new_data(L_INPUT_ALIGN);
  data->N = get_alignment(type) / 8;
  data->address = L_new_expr_label(address);
  L_concat_datalist_element(datalist, L_new_datalist_element(data));

  data = L_new_data(L_INPUT_RESERVE);
  data->N = type->size() / 8;
  L_concat_datalist_element(datalist, L_new_datalist_element(data));

  assert(sym->has_var_def());
  var_def* def = sym->definition();
  immed_list* mil = (immed_list*)def->peek_annote(k_multi_init);
  if (mil != NULL)
  {
    assert(def->peek_annote(k_repeat_init) == NULL);
    immed_list_iter iter(mil);
    
    int size = iter.step().integer() / 8;
    char* base = sym->name();	
    int offset = 0;
    while (!iter.is_empty())
    {
      L_Data* data = new_init_data(iter.step(), size, base, offset);
      L_concat_datalist_element(datalist, L_new_datalist_element(data));
      offset += size;
    }
  }

  if (def->peek_annote(k_repeat_init))
  {
    annote_list_iter annotes(def->annotes());
    
    char* base = sym->name();
    int offset = 0;
    while (!annotes.is_empty())
    {
      annote* note = annotes.step();
      if (!strcmp(note->name(), "repeat_init"))
      {
	immed_list_iter iter((immed_list*)note->data());
	int num = iter.step().integer();
	int size = iter.step().integer() / 8;
	immed imm = iter.step();

	for (int i=0; i<num; i++)
	{
	  L_Data* data = new_init_data(imm, size, base, offset);
	  L_concat_datalist_element(datalist, L_new_datalist_element(data));
	  offset += size;
	}
      }

      if (!strcmp(note->name(), "fill"))
      {
	immed_list_iter iter((immed_list*)note->data());
	offset += iter.step().integer() / 8;
      }
    }
  }
}


void do_data(L_Datalist* datalist, base_symtab* symtab)
{
  sym_node_list_iter iter(symtab->symbols());
  while (!iter.is_empty())
  {
    var_sym* sym = (var_sym*)iter.step();
    if (sym->is_var() && sym->has_var_def())
      do_data(datalist, sym);
  }
}


void do_data()
{
  L_Datalist* datalist = L_new_datalist();
  L_data_list = datalist;

  L_Data* data = L_new_data(L_INPUT_MS);
  data->N = L_MS_DATA;
  L_concat_datalist_element(datalist, L_new_datalist_element(data));

  global_symtab* globals = fileset->globals();
  do_data(datalist, globals);

  base_symtab_list_iter iter(globals->children());
  while (!iter.is_empty())
    do_data(datalist, iter.step());

  L_print_datalist(outfile, datalist);
  L_delete_datalist(datalist);
}


void init_Lcode(int argc, char** argv, char** envp)
{
  L_arch = "impact";
  L_model = "v1.0";
  L_curr_pass_name = argv[0];
  L_input_file = argv[1];
  L_output_file = (argc == 3) ? argv[2] : (char*)"stdout";

  Parm_Macro_List* external_list = L_create_external_macro_list (argv, envp);
  L_command_line_macro_list = external_list;

  L_parm_file = L_get_std_parm_name (argv, envp, "STD_PARMS_FILE",
				     "./STD_PARMS");
  L_load_parameters (L_parm_file, external_list,  
		     "(Lglobal", L_read_parm_global);
  L_load_parameters (L_parm_file, external_list,  
		     "(Larchitecture", L_read_parm_arch);
  L_load_parameters (L_parm_file, external_list,  
		     "(Lfile", L_read_parm_file);

  L_init_symbol();
  L_setup_alloc_pools();

#ifdef OPENIMPACT
  L_swarch = "default";
  M_set_machine(L_arch, L_model, L_swarch);
#else
  M_set_machine(L_arch, L_model);
#endif
  M_define_macros(L_macro_symbol_table);
  M_define_opcode_name(L_opcode_symbol_table);
}


int main(int argc, char** argv, char** envp)
{
  if (argc != 2 && argc != 3)
  {
    fprintf(stderr, "Usage: %s <input> [output]\n", argv[0]);
    exit(1);
  }

  if (argc == 3)
  {
    outfile = fopen(argv[2], "w");
    if (!outfile) 
    {
      fprintf(stderr, "Error opening %s\n", argv[2]);
      exit(1);
    }
  }

  init_Lcode(argc, argv, envp);
  start_suif(argc, argv);

#ifdef SUIF_DEPS
  depend_init(FALSE);
#endif
  ANNOTE(k_offset, "offset", FALSE);
  ANNOTE(k_regnum, "regnum", FALSE);

  fileset->add_file(argv[1], NULL);

  init_opcode_map();
  name_anon_types();
//do_struct_decls();
  rename_statics();

  fileset->reset_iter();
  file_set_entry* fse;
  while ((fse = fileset->next_file()))
  {
    fse->reset_proc_iter();
        
    proc_sym* ps;
    while ((ps = fse->next_proc())) 
    {
      ps->read_proc(TRUE, FALSE);
      do_proc(ps->block());
      ps->flush_proc();
    }
  }

  do_data();
  exit_suif();

  if (outfile != stdout) fclose(outfile);
}


void init_opcode_map()
{
  for (int i = 0; i < io_last; i++)
    for (int j = 0; j < LAST; j++)
      alu_ops[i][j] = -1;

  alu_ops[io_nop][VOID] = Lop_NO_OP;

  alu_ops[io_cpy][Int8]    = Lop_MOV;
  alu_ops[io_cpy][UInt8]   = Lop_MOV;
  alu_ops[io_cpy][Int16]   = Lop_MOV;
  alu_ops[io_cpy][UInt16]  = Lop_MOV;
  alu_ops[io_cpy][Int32]   = Lop_MOV;
  alu_ops[io_cpy][UInt32]  = Lop_MOV;
  alu_ops[io_cpy][Float32] = Lop_MOV_F;
  alu_ops[io_cpy][Float64] = Lop_MOV_F2;

  alu_ops[io_add][Int32]   = Lop_ADD;
  alu_ops[io_add][UInt32]  = Lop_ADD_U;
  alu_ops[io_add][Float32] = Lop_ADD_F;
  alu_ops[io_add][Float64] = Lop_ADD_F2;

  alu_ops[io_sub][Int32]   = Lop_SUB;
  alu_ops[io_sub][UInt32]  = Lop_SUB_U;
  alu_ops[io_sub][Float32] = Lop_SUB_F;
  alu_ops[io_sub][Float64] = Lop_SUB_F2;

  alu_ops[io_mul][Int32]   = Lop_MUL;
  alu_ops[io_mul][UInt32]  = Lop_MUL_U;
  alu_ops[io_mul][Float32] = Lop_MUL_F;
  alu_ops[io_mul][Float64] = Lop_MUL_F2;

  alu_ops[io_div][Int32]   = Lop_DIV;
  alu_ops[io_div][UInt32]  = Lop_DIV_U;
  alu_ops[io_div][Float32] = Lop_DIV_F;
  alu_ops[io_div][Float64] = Lop_DIV_F2;

  alu_ops[io_rem][Int32]  = Lop_REM;
  alu_ops[io_rem][UInt32] = Lop_REM_U;

//alu_ops[io_abs][Int32]   = Lop_ABS;
  alu_ops[io_abs][Float32] = Lop_ABS_F;
  alu_ops[io_abs][Float64] = Lop_ABS_F2;

  alu_ops[io_min][Int32]   = Lop_MIN;
  alu_ops[io_min][Float32] = Lop_MIN_F;
  alu_ops[io_min][Float64] = Lop_MIN_F2;

  alu_ops[io_max][Int32]   = Lop_MAX;
  alu_ops[io_max][Float32] = Lop_MAX_F;
  alu_ops[io_max][Float64] = Lop_MAX_F2;

  alu_ops[io_and][Int32]  = Lop_AND;
  alu_ops[io_and][UInt32] = Lop_AND;

  alu_ops[io_ior][Int32]  = Lop_OR;
  alu_ops[io_ior][UInt32] = Lop_OR;

  alu_ops[io_xor][Int32]  = Lop_XOR;
  alu_ops[io_xor][UInt32] = Lop_XOR;

  alu_ops[io_asr][Int32]  = Lop_ASR;
  alu_ops[io_lsr][UInt32] = Lop_LSR;

  alu_ops[io_lsl][Int32]  = Lop_LSL;
  alu_ops[io_lsl][UInt32] = Lop_LSL;

  alu_ops[io_lod][Int8]    = Lop_LD_C;
  alu_ops[io_lod][UInt8]   = Lop_LD_UC;
  alu_ops[io_lod][Int16]   = Lop_LD_C2;
  alu_ops[io_lod][UInt16]  = Lop_LD_UC2;
  alu_ops[io_lod][Int32]   = Lop_LD_I;
  alu_ops[io_lod][UInt32]  = Lop_LD_I;
  alu_ops[io_lod][Float32] = Lop_LD_F;
  alu_ops[io_lod][Float64] = Lop_LD_F2;

  alu_ops[io_str][Int8]    = Lop_ST_C;
  alu_ops[io_str][UInt8]   = Lop_ST_C;
  alu_ops[io_str][Int16]   = Lop_ST_C2;
  alu_ops[io_str][UInt16]  = Lop_ST_C2;
  alu_ops[io_str][Int32]   = Lop_ST_I;
  alu_ops[io_str][UInt32]  = Lop_ST_I;
  alu_ops[io_str][Float32] = Lop_ST_F;
  alu_ops[io_str][Float64] = Lop_ST_F2;  

#ifndef OPENIMPACT
  alu_ops[io_seq][Int32]   = Lop_EQ;
  alu_ops[io_seq][UInt32]  = Lop_EQ;
  alu_ops[io_seq][Float32] = Lop_EQ_F;
  alu_ops[io_seq][Float64] = Lop_EQ_F2;

  alu_ops[io_sne][Int32]   = Lop_NE;
  alu_ops[io_sne][UInt32]  = Lop_NE;
  alu_ops[io_sne][Float32] = Lop_NE_F;
  alu_ops[io_sne][Float64] = Lop_NE_F2;

  alu_ops[io_sl][Int32]    = Lop_LT;
  alu_ops[io_sl][UInt32]   = Lop_LT_U;
  alu_ops[io_sl][Float32]  = Lop_LT_F;
  alu_ops[io_sl][Float64]  = Lop_LT_F2;

  alu_ops[io_sle][Int32]   = Lop_LE;
  alu_ops[io_sle][UInt32]  = Lop_LE_U;
  alu_ops[io_sle][Float32] = Lop_LE_F;
  alu_ops[io_sle][Float64] = Lop_LE_F2;
#endif
}
