/* Copyright (c) 2005 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: attach_dep_info.cc:
//   
//   Author: Sam Larsen
//   Date: Tue Jan 11 09:27:53 2005
//
//   Function:  Uses the SUIF dependence library to identify memory
//		dependences and attaches them as annotations.  This
//		pass only considers loop independent dependences and
//		dependences carried by the inner loop.
//
//		Known limitations:
//		- Limited to countable loops with no control flow
//		  and no function calls.
//
//===========================================================================

#include <dependence.h>
#include <suif1.h>
#include <useful.h>
#include "do_loops.h"
#include "depend.h"
#include <list>
#include <assert.h>
using namespace std;

typedef list<instruction*> instr_list;

void gather_memops(instruction* instr, instr_list& memops)
{
  // Position in the list corresponds to position in the loop body,
  // so iterate over sources first so that stores are entered last
  for (unsigned i=0; i<instr->num_srcs(); i++)
  {
    operand oprnd = instr->src_op(i);
    if (oprnd.is_instr())
      gather_memops(oprnd.instr(), memops);
  }

  if_ops opcode = instr->opcode();
  assert_msg(opcode != io_memcpy, ("found memcpy... run no_memcpys"));

  if (opcode == io_lod || opcode == io_str)
    memops.push_back(instr);
}


void gather_memops(tree_node_list* tnl, instr_list& memops)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
      gather_memops(((tree_instr*)tn)->instr(), memops);

    else for (unsigned i=0; i<tn->num_child_lists(); i++)
      gather_memops(tn->child_list_num(i), memops);
  }
}


// Tests if arr0 is dependent on arr1
bool is_dep(in_array* arr0, in_array* arr1, int& dist)
{
  dist = -1; 
  bool dep = false;

  deptest_result res;
  dvlist* dep_test = DependenceTest(arr0, arr1, &res, TRUE);

  switch (res) {
    case dt_ok:        break;
    case dt_indep:     return false;
    case dt_too_messy: return true;
    default: assert_msg(0, ("%d\n", res));
  }

  assert(dep_test);
  dvlist_iter iter(dep_test);
  while (!iter.is_empty())
  {
    distance_vector* dv = ((dvlist_e*)iter.step())->dv;

    // Only consider dependences carried by the inner loop
    if (dv->level() == dv->size())
    {
//    distance& d = ((distance_vector_e*)dv->tail())->d;
      distance_vector_e* dv_e = (distance_vector_e*)dv->tail();

      // Use -1 to indicate 'non-constant'.  This is okay because
      // DependenceTest is called to return only positive distances
      int tmp = dv_e->d.is_const() ? dv_e->d.dist() : -1;
      if (!dep || (tmp < dist)) dist = tmp;

      dep = true;
    }
  }

  return dep;
}


void mark_arr_deps(instruction* in0, instruction* in1)
{
  in_array* arr0 = (in_array*)in0->src_op(0).instr();
  in_array* arr1 = (in_array*)in1->src_op(0).instr();

  assert(arr0->opcode() == io_array && arr1->opcode() == io_array);

  bool arr0_lhs = is_lhs(arr0);
  bool arr1_lhs = is_lhs(arr1);

  if (arr0_lhs || arr1_lhs)
  {
    int dist;
    if (is_dep(arr1, arr0, dist))
    {
      // Special case: non-constant distance.  We must assume
      // both intra-loop and loop-carried dependences.
      if (dist == -1)
      {
	if (arr0_lhs)
	{
	  if (arr1_lhs)
	  {
	    add_edge(in0, in1, 0, Output);
	    add_edge(in1, in0, 1, Output);
	  }
	  else
	  {
	    add_edge(in0, in1, 0, Flow);
	    add_edge(in1, in0, 1, Anti);
	  }
	}
	else if (arr1_lhs)
	{
	  add_edge(in0, in1, 0, Anti);
	  add_edge(in1, in0, 1, Flow);
	}
      }
      // Intra loop dependence.
      else if (dist == 0)
      {
	if (arr0_lhs)
	{
	  if (arr1_lhs)
	    add_edge(in0, in1, 0, Output);
	  else
	    add_edge(in0, in1, 0, Flow);
	}
	else if (arr1_lhs)
	  add_edge(in0, in1, 0, Anti);
      }
      // Loop carried dependence.
      else
      {
	if (arr0_lhs)
	{
	  if (arr1_lhs)
	    add_edge(in0, in1, dist, Output);
	  else
	    add_edge(in0, in1, dist, Flow);
	}
	else if (arr1_lhs)
	  add_edge(in0, in1, dist, Anti);
      }
    }
    // Loop carried dependence the other way arround.  Distances 
    // of 0 and -1 will be caught above.
    else if (is_dep(arr0, arr1, dist))
    {
      assert(dist > 0);
      if (arr0_lhs)
      {
	if (arr1_lhs)
	  add_edge(in1, in0, dist, Output);
	else
	  add_edge(in1, in0, dist, Anti);
      }
      else if (arr1_lhs)
	add_edge(in1, in0, dist, Flow);
    }
  }
}


void mark_deps(instruction* in0, instruction* in1)
{
  if_ops op0 = in0->opcode();
  if_ops op1 = in1->opcode();

  assert(op0 == io_lod || op0 == io_str);
  assert(op1 == io_lod || op1 == io_str);

  if (op0 == io_str)
  {
    if (op1 == io_str)
    {
      add_edge(in0, in1, 0, Output);
      add_edge(in1, in0, 1, Output);
    }
    else
    {
      add_edge(in0, in1, 0, Flow);
      add_edge(in1, in0, 1, Anti);
    }
  }
  else
  {
    if (op1 == io_str)
    {
      add_edge(in0, in1, 0, Anti);
      add_edge(in1, in0, 1, Flow);
    }
  }
}


bool addr_is_array(instruction* instr)
{
  assert(instr->opcode() == io_lod || instr->opcode() == io_str);

  operand oprnd = instr->src_op(0);
  if (oprnd.is_instr())
  {
    instruction* instr = oprnd.instr();
    if (instr->opcode() == io_array)
      return true;
  }

  return false;
}


// We can compare the indices of these array accesses of they are in
// fact array accesses and they address the same array.
bool can_compare_arrays(instruction* in0, instruction* in1)
{
  if (addr_is_array(in0) && addr_is_array(in1))
  {
    int off0, off1;
    var_sym* sym0 = find_base_sym(in0, off0);
    var_sym* sym1 = find_base_sym(in1, off1);
    if (sym0 != NULL && sym1 != NULL)
      if (sym0 == sym1 && off0 == off1)
	return true;
  }

  return false;
}


// memops are inserted into the list in original program order and order
// determines the type of dependence (e.g. flow vs. anti).  This is overly
// simplistic in general but works for inner loops with no control flow.
void mark_dependences(instr_list& memops, src_lang_type lang)
{
  for (instr_list::iterator i=memops.begin(); i != memops.end(); i++)
  {
    instruction* in0 = *i;

    instr_list::iterator j = i; j++;
    for (; j != memops.end(); j++)
    {
      instruction* in1 = *j;

      // First check to see if the base addresses imply independence
      if (might_alias(in0, in1, lang))
      {
	// See if we can determine independence by comparing array
	// indices.  If we are analyzing Fortran and these are 
	// actually different arrays, might_alias should have
	// return false already.
	if (can_compare_arrays(in0, in1))
	  mark_arr_deps(in0, in1);

	// Have to assume dependence
	else mark_deps(in0, in1);
      }
    }
  }
}


void attach_dep_info(tree_for* tf, src_lang_type lang)
{
  prep_tree_for(tf);

  instr_list memops;
  gather_memops(tf->body(), memops);
  mark_dependences(memops, lang);
}


void do_proc(tree_proc* tp)
{
  // needed by dependence library
  fill_in_access(tp);

  Do_loops do_loops(tp);
  const vector<tree_for*>& loops = do_loops.get_loops();
  for (size_t i=0; i<loops.size(); i++)
    attach_dep_info(loops[i], tp->proc()->src_lang());
}


int main(int argc, char** argv)
{
  if (argc != 3)
  {
    fprintf(stderr, "Usage: %s <input> <output>\n", argv[0]);
    exit(1);
  }

  start_suif(argc, argv);
  depend_init(TRUE);
  suif_proc_iter(argc, argv, do_proc, TRUE, TRUE, FALSE);
}
