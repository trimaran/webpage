/* Copyright (c) 2005 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: no_memcpys.cc:
//   
//   Author: Sam Larsen
//   Date: Wed Jan 12 10:00:35 2005
//
//   Function:  Replace memcpy instructions with lod/str pairs.
//
//===========================================================================

#include <suif1.h>

static void replace(instruction* instr)
{  
  if (instr->opcode() == io_memcpy)
  {
    instr->set_opcode(io_str);

    operand src = instr->src_op(1);
    src.remove();

    assert(src.is_instr() || src.is_symbol());

    type_node* type;
    if (src.is_instr())
      type = src.instr()->result_type();
    else type = src.symbol()->type();

    assert(type->is_ptr());
    type = ((ptr_type*)type)->ref_type()->unqual();

    instruction* lod = new in_rrr(io_lod, type, operand(), src, operand());
    instr->set_src_op(1, operand(lod));
  }
}


static void replace(tree_node_list* tnl)
{
  tree_node_list_iter iter(tnl);
  while(!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
      replace(((tree_instr*)tn)->instr());

    else for (unsigned i=0; i<tn->num_child_lists(); i++)
    replace(tn->child_list_num(i));
  }
}


static void do_proc(tree_proc* tp)
{
  replace(tp->body());
}


int main(int argc, char** argv)
{
  if (argc != 3)
  {
    fprintf(stderr, "Usage: %s <input file> <output file>\n", argv[0]);
    exit(1);
  }

  start_suif(argc, argv);
  suif_proc_iter(argc, argv, do_proc, TRUE, TRUE, FALSE);
}
