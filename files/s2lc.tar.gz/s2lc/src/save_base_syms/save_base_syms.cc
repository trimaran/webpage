/* Copyright (c) 2005 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: save_base_syms.cc:
//   
//   Author: Sam Larsen
//   Date: Fri Jul 20 17:59:06 2001
//
//   Function:  For each load and store to an array, save the away the array
//		var_sym to help dependence checking later.
//
//===========================================================================

#include <suif1.h>
#include "depend.h"

static void find_refs(instruction* instr)
{
  if_ops op = instr->opcode();
  assert_msg(op != io_memcpy, ("found memcpy... run no_memcpys"));

  if (op == io_lod || op == io_str)
  {
    int off;
    var_sym* sym = find_base_sym(instr, off);
    if (sym != NULL)
      add_base_sym(instr, sym, off);
  }
  
  for (unsigned j=0; j<instr->num_srcs(); j++)
    if (instr->src_op(j).is_instr())
      find_refs(instr->src_op(j).instr());
}


static void find_refs(tree_node_list* tnl)
{
  tree_node_list_iter iter(tnl);
  while(!iter.is_empty())
  {
    tree_node* tn = iter.step();

    if (tn->is_instr())
      find_refs(((tree_instr*)tn)->instr());

    for (unsigned i=0; i<tn->num_child_lists(); i++)
      find_refs(tn->child_list_num(i));
  }
}


static void find_refs(tree_proc* tp)
{
  find_refs(tp->body());
}


int main(int argc, char** argv)
{
  if (argc != 3)
  {
    fprintf(stderr, "Usage: %s <input> <output>\n", argv[0]);
    exit(1);
  }

  start_suif(argc, argv);
  depend_init(TRUE);
  suif_proc_iter(argc, argv, find_refs, TRUE);
}
