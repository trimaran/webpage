/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: main.cc:
//   
//   Author: Sam Larsen
//   Date: Wed Dec 29 23:42:26 1999
//
//   Function:  Partial Redundancy Elimination.
//
//   This pass is an implementation of the Lazy Code Motion algorithm
//   developed by Knoop, Ruthing, and Steffen (PLDI '92 p. 224-234).
//   Muchnick (pg. 407) describes this algorithm in his presentation of 
//   PRE except that his equations operate on full basic blocks rather 
//   than on nodes with a single instruction.  He uses "ANTloc" 
//   (local anticipatability) in place of "Used".  Also, there appears
//   to be a bug in his equations for 'redundancy' and 'isolation'.  
//   This implementation uses the equations in the PLDI paper.
//
//===========================================================================

#include "pre.h"
#include "copy_prop.h"
#include "depend.h"
#include <list>

static int cp_only;
static int pre_only;

// I only want to eliminate int constants as part of larger 
// expressions. 'Unflattening' these ldc instructions will make 
// expressions with constants appear as single instructions.
static void treeify_immeds(tree_proc* tp)
{
  tree_node_list_iter iter(tp->body());
  while (!iter.is_empty())
  {
    tree_instr* ti = (tree_instr*)iter.step();
    assert_msg(ti->is_instr(), ("convert to low SUIF\n"));

    instruction* instr = ti->instr();

    if (instr->opcode() == io_ldc && instr->dst_op().is_instr() &&
	instr->result_type()->op() != TYPE_FLOAT)
    {
      tree_node_list_e *pos = ti->list_e();
      ti->parent()->remove(pos);
      delete pos;

      ti->remove_instr(instr);
      delete ti;
    }
  }
}


// PRE errs when there isn't a path to the exit node.
static bool path_to_exit(tree_proc* tp)
{
  cfg graph(tp);
  vector<bool> visited(graph.num_blocks(), false);

  list<Block*> worklist;
  worklist.push_front(graph.get_entry());

  while (worklist.size() != 0)
  {
    Block* block = worklist.front();
    worklist.pop_front();
    visited[block->get_number()] = true;

    const vector<Block*> succs = block->get_succs();
    for (size_t i=0; i<succs.size(); i++)
      if (!visited[succs[i]->get_number()])
	worklist.push_back(succs[i]);
  }

  if (!visited[graph.get_exit()->get_number()])
  {
    fprintf(stderr, "WARNING: no path to exit in %s", tp->proc()->name());
    fprintf(stderr, " -- skipping analysis here\n");
    return false;
  }

  return true;
}


static void do_proc(tree_proc* tp)
{
  if (!path_to_exit(tp))
    return;

  treeify_immeds(tp);
  
  bool changes = true;
  while (changes)
  {
    changes = false;
    if (!pre_only)
      copy_prop COPY(tp);
    
    if (!cp_only)
    {
      bool pre_changes = true;
      while (pre_changes)
      {
	pre PRE(tp);
	pre_changes = PRE.transform();
	if (pre_changes) changes = true;
      }
    }
  }
}


int main(int argc, char** argv)
{
  static cmd_line_option options[] = {
    {CLO_NOARG,  "-cp-only",  "", &cp_only},
    {CLO_NOARG,  "-pre-only", "", &pre_only}
  };  
  
  parse_cmd_line(argc,argv,options, sizeof(options)/sizeof(cmd_line_option));
  if (argc != 3)
  {
    fprintf(stderr, "usage: %s [options] <input> <output>\n", argv[0]);
    fprintf(stderr, "options: -cp-only   only perform copy propagation\n");
    fprintf(stderr, "         -pre-only  do not perform copy propagation\n");
    exit(1);
  }

  start_suif(argc, argv);
  depend_init(TRUE);
  suif_proc_iter(argc, argv, do_proc, TRUE, FALSE, FALSE);
}
