/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: isolated.cc:
//   
//   Author: Sam Larsen
//   Date: Mon Jan  3 01:19:34 2000
//
//   Function:  Isolated
//
//   "A computationally optimal placement pl is isolated iff there is a 
//   computation point n that is an n-isolated node with respect to pl, 
//   i.e. on every terminating path starting in a successor of n every 
//   original computation is preceeded by a computation of pl."
//
//===========================================================================

#include "isolated.h"

isolated::isolated(cfg& graph, instr_info& info,
		   used& USED_in, latest& LATE_in) :
  vector<bitvector>(graph.num_blocks(), bitvector(info.size(), true)),
  num_exprs(info.size()),
  USED(USED_in),
  LATE(LATE_in)
{}


bool isolated::apply(Block* block)
{
  vector<bitvector>& ISOL = *this;
  int n = block->get_number();

  bitvector old = ISOL[n];

  ISOL[n] = bitvector(num_exprs, true);

  const vector<Block*>& succs = block->get_succs();
  for (size_t i=0; i<succs.size(); i++)
  {
    int m = succs[i]->get_number();
    ISOL[n] &= LATE[m] | (~USED[m] & ISOL[m]);
  }

  return old != ISOL[n];
}
