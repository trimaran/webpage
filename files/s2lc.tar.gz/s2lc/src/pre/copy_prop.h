/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: copy_prop.h:
//   
//   Author: Sam Larsen
//   Date: Mon Aug 11 11:49:57 2003
//
//   Function:  Copy propagation module to make PRE more effective.
//
//===========================================================================

#ifndef _COPY_PROP_H_
#define _COPY_PROP_H_

#include "dataflow.h"

class copyInfo {
public:
  copyInfo(var_sym*, var_sym*);
  copyInfo(const copyInfo&);
  ~copyInfo();

  var_sym* dst;
  var_sym* src;

private:
  copyInfo();
};

class copy_prop {
public:
  copy_prop(tree_proc*);
  ~copy_prop();

private:
  copy_prop();

  void allocate_vectors();
  void find_copies();

  void compute_gen_kill();
  void compute_gen_kill(instruction*, bitvector&, bitvector&);

  void analyze();
  bool analyze(Block*);

  void transform();
  void replace(instruction*, bitvector&);
  var_sym* lookup(var_sym*, bitvector&);

  void kill_after_write(var_sym*, bitvector&, bitvector&);
  void kill_after_store(bitvector&, bitvector&);
  void kill_after_call(in_cal*, bitvector&, bitvector&);

  inline bool is_copy(instruction*);
  inline bool self_copy(instruction*);
  inline int get_index(instruction*);

  inline void set_gen_bit(bitvector&, bitvector&, int);
  inline void set_kill_bit(bitvector&, bitvector&, int);

  cfg graph;
  const vector<Block*>& blocks;
  bool fortran;
  vector<copyInfo> copies;

  vector<bitvector> IN;
  vector<bitvector> OUT;
  vector<bitvector> GEN;
  vector<bitvector> KILL;
};

#endif
