/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: transp.cc:
//   
//   Author: Sam Larsen
//   Date: Thu Dec 30 02:51:27 1999
//
//   Function:  local transparency
//
//   "An expression's value is locally transparent in basic block i if 
//   there are no assignments in the block to variables that occur in the 
//   expression."
//
//===========================================================================

#include "transp.h"
#include "depend.h"

transp::transp(cfg& graph, instr_info& info, src_lang_type lang) :
  vector<bitvector>(graph.num_blocks(), bitvector(info.size(), true))
{
  const vector<Block*>& blocks = graph.get_blocks();
  for (size_t n=0; n<blocks.size(); n++)
  {
    Block* block = blocks[n];
    if (block->is_real())
    {
      const vector<instruction*>& instrs = block->get_instrs();
      assert(instrs.size() == 1);
      instruction* instr = instrs[0];
      if_ops op = instr->opcode();

      // Clear any exprs that could read this instruction's dest
      if (instr->dst_op().is_symbol())
      {
	var_sym* sym = instr->dst_op().symbol();
	bool spilled = lang == src_c && sym->is_spilled();

	for (size_t i=0; i<info.size(); i++)
	  if (has_var(info[i], sym) || (spilled && has_mem_read(info[i])))
	    (*this)[n].clear(i);
      }

      // Clear any loads that could alias with this store
      else if (op == io_str)
      {
	if (lang == src_fortran)
	{
	  for (size_t i=0; i<info.size(); i++)
	    if (has_mem_read(info[i]) && might_alias(instr, info[i], lang))
	      (*this)[n].clear(i);
	}
	else 
	{
	  for (size_t i=0; i<info.size(); i++)
	    if (has_mem_read(info[i]) || has_spilled_var(info[i]))
	      (*this)[n].clear(i);
	}
      }

      // Clear any exprs that could be modified by this call
      else if (op == io_cal)
      {
	for (size_t i=0; i<info.size(); i++)
	  if (has_spilled_var(info[i]) || has_mem_read(info[i]))
	    (*this)[n].clear(i);
      }
    }
  }
}


bool transp::has_var(instruction* instr, var_sym* sym)
{
  for (unsigned j=0; j<instr->num_srcs(); j++)
  {
    operand oprnd = instr->src_op(j);
    if (oprnd.is_symbol() && oprnd.symbol() == sym)
      return true;

    if (oprnd.is_instr() && has_var(oprnd.instr(), sym))
      return true;
  }

  if (instr->opcode() == io_ldc)
  {
    immed imm = ((in_ldc*)instr)->value();
    if (imm.is_symbol() && imm.symbol() == sym)
      return true;
  }

  return false;
}


bool transp::has_mem_read(instruction* instr)
{
  if_ops op = instr->opcode();
  if (op == io_lod || op == io_memcpy)
    return true;

  for (unsigned j=0; j<instr->num_srcs(); j++)
  {
    operand oprnd = instr->src_op(j);
    if (oprnd.is_instr() && has_mem_read(oprnd.instr()))
      return true;
  }
  
  return false;
}


bool transp::has_spilled_var(instruction* instr)
{
  for (unsigned j=0; j<instr->num_srcs(); j++)
  {
    operand oprnd = instr->src_op(j);
    if (oprnd.is_symbol() && oprnd.symbol()->is_spilled())
      return true;

    if (oprnd.is_instr() && has_spilled_var(oprnd.instr()))
      return true;
  }

  return false;
}
