/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: delayed.cc:
//   
//   Author: Sam Larsen
//   Date: Mon Jan  3 00:50:21 2000
//
//   Function:  Delayedness
//
//   "A placement is delayed iff every computation point n is an
//   n-delayed node, i.e. on every path from [entry] to n there is a
//   computation point of the Safe-Earliest Transformation such that
//   all subsequent original computations of p lie in n."
//
//===========================================================================

#include "delayed.h"

delayed::delayed(cfg& graph, instr_info& info,
		 used& USED_in, downsafe& DSAFE_in, earliest& EARL_in) :
  vector<bitvector>(graph.num_blocks(), bitvector(info.size(), true)),
  num_exprs(info.size()),
  USED(USED_in),
  DSAFE(DSAFE_in),
  EARL(EARL_in)
{}


bool delayed::apply(Block* block)
{
  vector<bitvector>& DELAY = *this;
  int n = block->get_number();

  bitvector old = DELAY[n];

  bitvector DELAYprod;
  if (block->is_entry())
    DELAYprod = bitvector(num_exprs, false);

  else
  {
    DELAYprod = bitvector(num_exprs, true);

    const vector<Block*>& preds = block->get_preds();
    for (size_t i=0; i<preds.size(); i++)
    {
      int m = preds[i]->get_number();
      DELAYprod &= ~USED[m] & DELAY[m];
    }
  }

  DELAY[n] = (DSAFE[n] & EARL[n]) | DELAYprod;
  return old != DELAY[n];
}
