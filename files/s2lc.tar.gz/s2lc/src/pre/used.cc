/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: used.cc:
//   
//   Author: Sam Larsen
//   Date: Thu Dec 30 22:22:11 1999
//
//   Function:  Used
//
//   An expression's value is used in basic block i if there is a 
//   computation of the expression in the block.  For full basic blocks,
//   this is replaced by local anticipatability.
//
//===========================================================================

#include "used.h"

used::used(cfg& graph, instr_info& info) :
  vector<bitvector>(graph.num_blocks(), bitvector(info.size(), false))
{
  const vector<Block*>& blocks = graph.get_blocks();
  for (size_t n=0; n<blocks.size(); n++)
  {
    Block* block = blocks[n];
    if (block->is_real())
    {
      const vector<instruction*>& instrs = block->get_instrs();
      assert(instrs.size() == 1);
      instruction* instr = instrs[0];

      // Trimaran can't recognize DO loops if the main induction
      // op is optimized.
      if (!induction_op(instr))
      {
	if (info.is_member(instr))
	  (*this)[n].set(info.get_index(instr));
      }
    }
  }
}


bool used::induction_op(instruction* instr)
{
  if (instr->opcode() != io_add)
    return false;

  operand imm = instr->src_op(1);
  if (!imm.is_immed() || !imm.immediate().is_integer())
    return false;

  operand dst = instr->dst_op();
  operand src = instr->src_op(0);

  if (!dst.is_symbol() || !src.is_symbol())
    return false;

  if (dst.symbol() != src.symbol())
    return false;

  return true;
}
