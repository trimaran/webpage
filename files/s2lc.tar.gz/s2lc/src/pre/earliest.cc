/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: earliest.cc:
//   
//   Author: Sam Larsen
//   Date: Mon Jan  3 00:35:08 2000
//
//   Function:  Earliestness
//
//   "A placement is earliest iff every computation point n is an
//   n-earliest node, i.e. there is a path leading from [start] to n
//   where no node m prior to n is n-safe and delivers the same value
//   as n when computing t."
//
//===========================================================================

#include "earliest.h"

earliest::earliest(cfg& graph, instr_info& info, 
		   downsafe& DSAFE_in, transp& TRANSP_in) :
  vector<bitvector>(graph.num_blocks(), bitvector(info.size(), false)),
  num_exprs(info.size()),
  DSAFE(DSAFE_in),
  TRANSP(TRANSP_in)
{}


bool earliest::apply(Block* block)
{
  vector<bitvector>& EARL = *this;
  int n = block->get_number();

  bitvector old = EARL[n];

  if (block->is_entry())
    EARL[n] = bitvector(num_exprs, true);

  else
  {
    EARL[n] = bitvector(num_exprs, false);

    const vector<Block*>& preds = block->get_preds();
    for (size_t i=0; i<preds.size(); i++)
    {
      int m = preds[i]->get_number();
      EARL[n] |= ~TRANSP[m] | (~DSAFE[m] & EARL[m]);
    }
  }

  return old != EARL[n];
}
