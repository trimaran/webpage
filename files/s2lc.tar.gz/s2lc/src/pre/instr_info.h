/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: instr_info.h:
//   
//   Author: Sam Larsen
//   Date: Thu Dec 30 01:31:14 1999
//
//   Function:  Set of expressions in a procedure.
//
//===========================================================================

#ifndef _INSTR_INFO_H_
#define _INSTR_INFO_H_

#include <map>
#include <vector>
#undef assert
#include <suif1.h>

using namespace std;

// Comparison function for instructions.  The instr_info object 
// maintains a set of the expressions in a procedure
class lt_instr {
public:
  bool operator()(instruction*, instruction*) const;

private:
  int comp_instrs(instruction*, instruction*) const;
  int comp_oprnds(operand, operand) const;
  int comp_ldcs(in_ldc*, in_ldc*) const;
};


class instr_info : public vector<instruction*> {
public:
  instr_info(tree_proc*);
  ~instr_info() {}

  bool is_member(instruction* instr) {
    return exprs.find(instr) != exprs.end();
  }

  size_t get_index(instruction* instr) {
    assert(is_member(instr));
    return exprs[instr];
  }

private:
  void gather_exprs(instruction*);
  void gather_exprs(tree_node* tn);
  void gather_exprs(tree_node_list*);
  bool good_expr(instruction*);

  map<instruction*, int, lt_instr> exprs;
};

#endif
