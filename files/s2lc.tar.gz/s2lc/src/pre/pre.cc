/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: pre.cc:
//   
//   Author: Sam Larsen
//   Date: Fri Dec 31 02:35:40 1999
//
//   Function:  Partial redundancy elimination
//
//===========================================================================

#include "pre.h"
#include "transp.h"
#include "used.h"
#include "downsafe.h"
#include "earliest.h"
#include "delayed.h"
#include "latest.h"
#include "isolated.h"

pre::pre(tree_proc* tp) : graph(tp, false), info(tp)
{
  transp TRANSP(graph, info, tp->proc()->src_lang());
  used USED(graph, info);

  downsafe DSAFE(graph, info, USED, TRANSP);
  solve<downsafe>(graph, DSAFE, Reverse);

  earliest EARL(graph, info, DSAFE, TRANSP);
  solve<earliest>(graph, EARL, Forward);

  delayed DELAY(graph, info, USED, DSAFE, EARL);
  solve<delayed>(graph, DELAY, Forward);

  latest LATE(graph, info, USED, DELAY);

  isolated ISOL(graph, info, USED, LATE);
  solve<isolated>(graph, ISOL, Reverse);
  
  for (size_t n=0; n<LATE.size(); n++)
  {
    OPT.push_back(LATE[n] & ~ISOL[n]);
    REDN.push_back(USED[n] & ~(LATE[n] & ISOL[n]));
  }
}


var_sym* pre::get_tmp_var(instruction* pr_exp, base_symtab* scope)
{
  var_sym* tmp = tmp_table[pr_exp];

  if (tmp == NULL)
  {
    type_node* type = pr_exp->result_type()->unqual();
    tmp = scope->new_unique_var(type, "_pre");
    tmp_table[pr_exp] = tmp;
  }

  return tmp;
}


bool pre::transform()
{
  bool changes = false;

  const vector<Block*>& blocks = graph.get_blocks();
  for (unsigned n=0; n<blocks.size(); n++)
  {
    Block* block = blocks[n];
    if (block->is_real())
    {
      const vector<instruction*>& instrs = block->get_instrs();
      assert(instrs.size() == 1);

      tree_instr* blk_ti = instrs[0]->parent();
      base_symtab* scope = blk_ti->scope();

      // For expressions whose optimum placement is in
      // this node, create new instructions.
      for (size_t i=0; i<info.size(); i++)
	if (OPT[n][i])
	{
	  changes = true;

	  instruction* pr_exp = info[i];
	  var_sym* tmp = get_tmp_var(pr_exp, scope);
	  
	  instruction* new_instr = clone(pr_exp);
	  new_instr->set_dst(operand(tmp));
	  insert_instr(new_instr, blk_ti);
	}

      // If this node has a redundant expression, then
      // replace the expression with the temp var.
      for (size_t i=0; i<info.size(); i++)
	if (REDN[n][i])
	{
	  instruction* pr_exp = info[i];
	  var_sym* tmp = get_tmp_var(pr_exp, scope);
	  insert_var(tmp, blk_ti);
	}
    }
  }

  return changes;
}


// SUIF's clone procedure seems to cause assertion failures in some
// cases.  I'll just write my own:
instruction* pre::clone(instruction* instr)
{
  type_node* type = instr->result_type();

  switch (instr->format()) {
    case inf_rrr: 
    {
      instruction* new_instr = new in_rrr(instr->opcode(), type);
      for (unsigned i=0; i<instr->num_srcs(); i++)
      {
	operand src = instr->src_op(i);
	if (src.is_symbol())
	  new_instr->set_src_op(i, operand(src.symbol()));

	else if (src.is_instr())
	  new_instr->set_src_op(i, operand(clone(src.instr())));
      }

      return new_instr;
    }

    case inf_ldc:
    {
      immed value = ((in_ldc*)instr)->value();
      return new in_ldc(type, operand(), value);
    }

    default: assert_msg(0, ("unknown instruction format\n"));
  }

  return NULL;
}


void pre::insert_instr(instruction* new_instr, tree_instr* blk_ti)
{
  tree_instr* new_ti = new tree_instr(new_instr);
  if (blk_ti->instr()->opcode() == io_lab)
  {
    blk_ti->parent()->insert_after(new_ti, blk_ti->list_e());
    return;
  }

  // The new instruction needs to be inserted before blk_ti, but
  // that might be in the middle of an expression tree, so we
  // may need to scan backwards to the last instr in the tree.
  tree_node_list_e* tnle = blk_ti->list_e();
  while (tnle->prev())
  {
    instruction* prev = ((tree_instr*)tnle->prev()->contents)->instr();
    if (!prev->dst_op().is_instr())
      break;
    tnle = tnle->prev();
  }

  blk_ti = (tree_instr*)tnle->contents;
  blk_ti->parent()->insert_before(new_ti, blk_ti->list_e());
}


void pre::insert_var(var_sym* var, tree_instr* blk_ti)
{
  instruction* instr = blk_ti->instr();
  operand dst_op = instr->dst_op();

  // If the redundant expression is not a sub-expression, then
  // just copy the variable.
  if (dst_op.is_symbol())
  {
    in_rrr* cpy = new in_rrr(io_cpy, instr->result_type(), 
			     dst_op, operand(var));
    blk_ti->remove_instr(instr);
    blk_ti->set_instr(cpy);
  }

  // If the redundant expression is a sub-expression, then 
  // substitute the variable for the entire operand, and 
  // eliminate the expression altogether.
  else if (dst_op.is_instr())
  {
    instruction* pred = dst_op.instr();
    for (unsigned j=0; j<pred->num_srcs(); j++)
    {
      operand src_op = pred->src_op(j);
      if (src_op.is_instr() && src_op.instr() == instr)
      {
	src_op.remove();
	pred->set_src_op(j, operand(var));
	blk_ti->parent()->remove(blk_ti->list_e());
	break;
      }
    }
  }

  else 
  {
    instr->print();
    assert(0);
  }
}
