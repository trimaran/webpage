/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: instr_info.cc:
//   
//   Author: Sam Larsen
//   Date: Thu Dec 30 01:33:46 1999
//
//   Function:  Set of expressions in a procedure.
//
//===========================================================================

#include "instr_info.h"

instr_info::instr_info(tree_proc* tp)
{
  gather_exprs(tp->body());
}


void instr_info::gather_exprs(tree_node* tn)
{
  if (tn->is_instr())
    gather_exprs(((tree_instr*)tn)->instr());
  
  else for (unsigned i=0; i< tn->num_child_lists(); i++)
    gather_exprs(tn->child_list_num(i));
}


void instr_info::gather_exprs(tree_node_list* tnl)
{
  tree_node_list_iter iter(tnl);
  while(!iter.is_empty())
    gather_exprs(iter.step());
}


void instr_info::gather_exprs(instruction* instr)
{
  if (good_expr(instr))
  {
    if (exprs.find(instr) == exprs.end())
    {
      exprs[instr] = size();
      push_back(instr);
    }
  }

  else for (unsigned j=0; j<instr->num_srcs(); j++)
    if (instr->src_op(j).is_instr())
      gather_exprs(instr->src_op(j).instr());
}


// Check to see if this kind of instruction can be eliminated
bool instr_info::good_expr(instruction* instr)
{
  // A good expression can't have any instruction operands unless
  // they are ldc's
  for (unsigned j=0; j<instr->num_srcs(); j++)
  {
    operand src = instr->src_op(j);
    if (src.is_instr() && src.instr()->opcode() != io_ldc)
      return false;
  }

  // Eliminate redundant array references
  inst_format fmt = instr->format();
  if (fmt == inf_array)
    return true;

  // Eliminate redundant floating point constants
  if (fmt == inf_ldc)
    return instr->result_type()->op() == TYPE_FLOAT;

  if_ops op = instr->opcode();
  if (fmt == inf_rrr &&
      !(op == io_mrk || op == io_nop || op == io_ret ||
	op == io_cpy || op == io_str || op == io_memcpy))
    return true;

  return false;
}


bool lt_instr::operator()(instruction* in0, instruction* in1) const
{
  return comp_instrs(in0, in1) < 0;
}


int lt_instr::comp_instrs(instruction* in0, instruction* in1) const
{
  // Compare the opcodes
  if_ops op0 = in0->opcode();
  if_ops op1 = in1->opcode();

  if (op0 < op1) return -1;
  if (op0 > op1) return  1;
  
  // Compare the number of sources
  if (in0->num_srcs() < in1->num_srcs()) return -1;
  if (in0->num_srcs() > in1->num_srcs()) return  1;

  // If ldc instrs, check the constants
  if (op0 == io_ldc)
    return comp_ldcs((in_ldc*)in0, (in_ldc*)in1);

  // If array instrs, check the offset
  if (op0 == io_array)
  {
    unsigned off0 = ((in_array*)in0)->offset();
    unsigned off1 = ((in_array*)in1)->offset();
    
    if (off0 < off1) return -1;
    if (off0 > off1) return  1;
  }

  // Check the operands
  for (unsigned j=0; j<in0->num_srcs(); j++)
  {
    int test = comp_oprnds(in0->src_op(j), in1->src_op(j));
    if (test < 0) return -1;
    if (test > 0) return  1;
  }

  // Check the result types
  type_node* type0 = in0->result_type()->unqual();
  type_node* type1 = in1->result_type()->unqual();
  if (!type0->is_same(type1))
  {
    if (type0 < type1) return -1;
    if (type0 > type1) return  1;
    assert(0);
  }

  // The fields annotation must be checked or structs could be PRE'd 
  // when they shouldn't
  immed_list* il0 = (immed_list*)in0->peek_annote(k_fields);
  immed_list* il1 = (immed_list*)in1->peek_annote(k_fields);
  if (il0 == NULL && il1 != NULL) return -1;
  if (il0 != NULL && il1 == NULL) return  1;
  if (il0 != NULL && il1 != NULL)
  {
    if (il0->count() < il1->count()) return -1;
    if (il0->count() > il1->count()) return  1;

    immed_list_iter iter0(il0);
    immed_list_iter iter1(il1);
    while (!iter0.is_empty())
    {
      immed imm0 = iter0.step();
      immed imm1 = iter1.step();
      assert(imm0.is_string() && imm1.is_string());

      int test = strcmp(imm0.string(), imm1.string());
      if (test < 0) return -1;
      if (test > 0) return  1;
    }
  }

  // They must be the same
  return 0;
}


int lt_instr::comp_oprnds(operand op0, operand op1) const
{
  operand_kinds k0 = op0.kind();
  operand_kinds k1 = op1.kind();

  if (k0 < k1) return -1;
  if (k0 > k1) return  1;

  if (k0 == OPER_SYM)
  {
    var_sym* sym0 = op0.symbol();
    var_sym* sym1 = op1.symbol();

    if (sym0 < sym1) return -1;
    if (sym0 > sym1) return  1;
    return 0;
  }

  else if (k0 == OPER_INSTR)
    return comp_instrs(op0.instr(), op1.instr());

  else if (k0 == OPER_NULL)
    return 0;

  assert(0);
  return 0;
}


int lt_instr::comp_ldcs(in_ldc* in0, in_ldc* in1) const
{
  immed imm0 = in0->value();
  immed imm1 = in1->value();

  immed_kinds kind0 = imm0.kind();
  immed_kinds kind1 = imm1.kind();

  if (kind0 < kind1) return -1;
  if (kind0 > kind1) return  1;

  switch (kind0) {
  case im_int: {
    if (imm0.integer() < imm1.integer()) return -1;
    if (imm0.integer() > imm1.integer()) return  1;
    return 0;
  }

  case im_float: {
    if (imm0.flt() < imm1.flt()) return -1;
    if (imm0.flt() > imm1.flt()) return  1;
    return 0;
  }

  case im_symbol: {
    if (imm0.symbol() < imm1.symbol()) return -1;
    if (imm0.symbol() > imm1.symbol()) return  1;

    if (imm0.offset() < imm1.offset()) return -1;
    if (imm0.offset() > imm1.offset()) return  1;
    return 0;
  }

  case im_extended_int: {
    int test = strcmp(imm0.ext_integer(), imm1.ext_integer());
    if (test < 0) return -1;
    if (test > 0) return  1;
    return 0;
  }

  default: 
    assert_msg(0, ("Unsupported immediate '%c' - fix this", kind0));
    return 0;
  }
}
