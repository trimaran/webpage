/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: latest.cc:
//   
//   Author: Sam Larsen
//   Date: Mon Jan  3 01:07:47 2000
//
//   Function:  Latest
//
//   "A computationally optimal placement pl is latest iff every compuatation 
//   point n is an n-latest node, i.e.
//   - n is a computation point of some computationally optimal placement and
//   - on every terminating path p starting in n any following computation
//     point of a computationally optimal placement occurs after an original
//     computation on p."
//
//===========================================================================

#include "latest.h"

latest::latest(cfg& graph, instr_info& info,
	       used& USED, delayed& DELAY)
{
  const vector<Block*>& blocks = graph.get_blocks();
  for (size_t n=0; n<blocks.size(); n++)
  {
    Block* block = blocks[n];
    assert(n == block->get_number());

    bitvector DELAYprod(info.size(), true);

    const vector<Block*>& succs = block->get_succs();
    for (size_t i=0; i<succs.size(); i++)
    {
      int m = succs[i]->get_number();
      DELAYprod &= DELAY[m];
    }

    push_back(DELAY[n] & (USED[n] | ~DELAYprod));
  }
}
