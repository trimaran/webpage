/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: downsafe.cc:
//   
//   Author: Sam Larsen
//   Date: Fri Dec 31 03:05:39 1999
//
//   Function:  Down-safeness
//
//   "A placement is down-safe, iff every compuation point n is an
//   n-down-safe node, i.e. a computation of t at n does not introduce
//   a new value on a terminating path starting in n."
//
//   Muchnick refers to this as global anticipatability.
//
//===========================================================================

#include "downsafe.h"

downsafe::downsafe(cfg& graph, instr_info& info, 
		   used& USED_in, transp& TRANSP_in) :
  vector<bitvector>(graph.num_blocks(), bitvector(info.size(), true)),
  num_exprs(info.size()),
  USED(USED_in),
  TRANSP(TRANSP_in)
{}


bool downsafe::apply(Block* block)
{
  vector<bitvector>& DSAFE = *this;
  int n = block->get_number();

  bitvector old = DSAFE[n];

  if (block->is_exit())
    DSAFE[n] = bitvector(num_exprs, false);

  else
  {
    bitvector DSAFEprod(num_exprs, true);

    const vector<Block*>& succs = block->get_succs();
    for (size_t i=0; i<succs.size(); i++)
    {
      int m = succs[i]->get_number();
      DSAFEprod &= DSAFE[m];
    }

    DSAFE[n] = USED[n] | (TRANSP[n] & DSAFEprod);
  }

  return old != DSAFE[n];
}
