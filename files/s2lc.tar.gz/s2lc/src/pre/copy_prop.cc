/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: copy_prop.cc:
//   
//   Author: Sam Larsen
//   Date: Mon Aug 11 12:04:33 2003
//
//   Function:  Copy propagation module to make PRE more effective.
//
//===========================================================================

#include "copy_prop.h"

copyInfo::copyInfo(var_sym* d, var_sym* s) : dst(d), src(s)
{}

copyInfo::copyInfo(const copyInfo& cpy) : dst(cpy.dst), src(cpy.src)
{}

copyInfo::~copyInfo()
{}


copy_prop::copy_prop(tree_proc* tp) : graph(tp), blocks(graph.get_blocks())
{
  fortran = tp->proc()->src_lang() == src_fortran;

  find_copies();
  if (copies.size() > 0)
  {
    allocate_vectors();
    compute_gen_kill();
    analyze();
    transform();
  }
}


copy_prop::~copy_prop()
{}


void copy_prop::allocate_vectors()
{
  size_t ncopies = copies.size();
  size_t nblocks = graph.num_blocks();

  IN = vector<bitvector>(nblocks, bitvector(ncopies, false));
  OUT = vector<bitvector>(nblocks, bitvector(ncopies, true));
  GEN = vector<bitvector>(nblocks, bitvector(ncopies, false));
  KILL = vector<bitvector>(nblocks, bitvector(ncopies, false));

  OUT[graph.get_entry()->get_number()] = bitvector(ncopies, false);
}


bool copy_prop::is_copy(instruction* instr)
{
  if (instr->opcode() == io_cpy)
  {
    operand src = instr->src_op(0);
    operand dst = instr->dst_op();
    if (src.is_symbol() && dst.is_symbol() && src.symbol() != dst.symbol())
      return true;
  }

  return false;
}


bool copy_prop::self_copy(instruction* instr)
{
  if (instr->opcode() == io_cpy)
  {
    operand src = instr->src_op(0);
    operand dst = instr->dst_op();
    if (src.is_symbol() && dst.is_symbol() && src.symbol() == dst.symbol())
      return true;
  }
  
  return false;
}


int copy_prop::get_index(instruction* instr)
{
  var_sym* dst = instr->dst_op().symbol();
  var_sym* src = instr->src_op(0).symbol();

  for (size_t j=0; j<copies.size(); j++)
    if (copies[j].dst == dst && copies[j].src == src)
      return j;

  return -1;
}


void copy_prop::find_copies()
{
  for (size_t i=0; i<blocks.size(); i++)
  {
    const vector<instruction*>& instrs = blocks[i]->get_instrs();
    for (size_t j=0; j<instrs.size(); j++)
    {
      instruction* instr = instrs[j];
      if (is_copy(instr))
      {
	int index = get_index(instr);
	if (index == -1)
	{
	  var_sym* dst = instr->dst_op().symbol();
	  var_sym* src = instr->src_op(0).symbol();
	  
	  copies.push_back(copyInfo(dst, src));
	}
      }
    }
  }
}


void copy_prop::set_gen_bit(bitvector& gen, bitvector& kill, int i)
{
  gen.set(i);
  kill.clear(i);
}

void copy_prop::set_kill_bit(bitvector& gen, bitvector& kill, int i)
{
  kill.set(i);
  gen.clear(i);
}


void copy_prop::compute_gen_kill()
{
  for (size_t i=0; i<blocks.size(); i++)
  {
    Block* block = blocks[i];
    int n = block->get_number();

    bitvector& gen = GEN[n];
    bitvector& kill = KILL[n];

    const vector<instruction*>& instrs = block->get_instrs();
    for (size_t j=0; j<instrs.size(); j++)
      compute_gen_kill(instrs[j], gen, kill);
  }
}


void copy_prop::compute_gen_kill(instruction* instr, bitvector& gen,
				 bitvector& kill)
{
  // Kill after variable writes
  if (instr->dst_op().is_symbol() && !self_copy(instr))
    kill_after_write(instr->dst_op().symbol(), gen, kill);
  
  // Set GEN bits for copy instructions
  if (is_copy(instr))
    set_gen_bit(gen, kill, get_index(instr));
  
  // Kill copies after a call instruction
  if (instr->opcode() == io_cal)
    kill_after_call((in_cal*)instr, gen, kill);
  
  // Kill copies after a store instruction
  if (!fortran && instr->opcode() == io_str)
    kill_after_store(gen, kill);
}


// Kill any copies that use this written variable
void copy_prop::kill_after_write(var_sym* sym, bitvector& gen, bitvector& kill)
{
  for (size_t j=0; j<copies.size(); j++)
    if (copies[j].dst == sym || copies[j].src == sym)
      set_kill_bit(gen, kill, j);
}


// Copies with aliased variables need to be killed after a store
void copy_prop::kill_after_store(bitvector& gen, bitvector& kill)
{
  for (size_t j=0; j<copies.size(); j++)
    if (copies[j].dst->is_spilled() || copies[j].src->is_spilled())
      set_kill_bit(gen, kill, j);
}


// For a call instruction, handle any globals or vars that have 
// their addrs passed
void copy_prop::kill_after_call(in_cal* call, bitvector& gen, bitvector& kill)
{
  // Any global variables should be killed after a function call
  for (size_t j=0; j<copies.size(); j++)
    if (copies[j].dst->is_static() || copies[j].src->is_static())
      set_kill_bit(gen, kill, j);
   
  // Any local variables that have their address taken in the arg
  // list should also be killed
  for (unsigned j=0; j<call->num_args(); j++)
  {
    operand oprnd = call->argument(j);
    if (oprnd.is_instr())
    {
      in_ldc* ldc = (in_ldc*)oprnd.instr();
      if (ldc->opcode() == io_ldc)
      {
	immed imm = ldc->value();
	if (imm.is_symbol())
	{
	  var_sym* sym = (var_sym*)imm.symbol();
	  if (sym->is_var())
	    kill_after_write(sym, gen, kill);
	}
      }
    }
  }
}


void copy_prop::analyze()
{
  bool changes = true;
  while (changes)
  {
    changes = false;
    for (size_t i=0; i<blocks.size(); i++)
      if (analyze(blocks[i])) changes = true;
  }
}


bool copy_prop::analyze(Block* block)
{
  int n = block->get_number();

  const vector<Block*>& preds = block->get_preds();
  if (preds.size() > 0)
    IN[n] = OUT[preds[0]->get_number()];
  else
    IN[n] = bitvector(copies.size(), false);

  for (size_t i=1; i<preds.size(); i++)
  {
    bitvector& pred_out = OUT[preds[i]->get_number()];
    IN[n] &= pred_out;
  }

  bitvector old = OUT[n];

  OUT[n] = (IN[n] | GEN[n]) & ~KILL[n];
  return OUT[n] != old;
}


void copy_prop::transform()
{
  for (size_t i=0; i<blocks.size(); i++)
  {
    Block* block = blocks[i];

    bitvector vec(IN[block->get_number()]);
    bitvector gen(copies.size(), false);
    bitvector kill(copies.size(), false);
    
    const vector<instruction*>& instrs = block->get_instrs();
    for (size_t j=0; j<instrs.size(); j++)
    {
      instruction* instr = instrs[j];
      compute_gen_kill(instr, gen, kill);
      replace(instr, vec);
      vec = (vec | gen) & ~kill;
    }
  }
}


var_sym* copy_prop::lookup(var_sym* sym, bitvector& vec)
{
  for (size_t j=0; j<vec.size(); j++)
  {
    if (vec[j] && copies[j].dst == sym)
    {
      var_sym* eqv = copies[j].src;
      assert(eqv != sym);

      var_sym* tmp = lookup(eqv, vec);
      return tmp ? tmp : eqv;
    }
  }

  return NULL;
}


void copy_prop::replace(instruction* instr, bitvector& vec)
{
  for (unsigned j=0; j<instr->num_srcs(); j++)
  {
    operand src = instr->src_op(j);

    if (src.is_instr())
      replace(src.instr(), vec);

    else if (src.is_symbol())
    {
      var_sym* eqv = lookup(src.symbol(), vec);
      if (eqv)
      {
	src.remove();
	instr->set_src_op(j, operand(eqv));
      }
    }
  }
}
