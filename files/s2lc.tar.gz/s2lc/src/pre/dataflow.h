/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: dataflow.h:
//   
//   Author: Sam Larsen
//   Date: Tue Feb 28 19:45:54 2006
//
//   Function:  Bitvector class and a driver for dataflow analysis.
//
//===========================================================================

#ifndef _DATAFLOW_H_
#define _DATAFLOW_H_

#include <list>
#include <vector>
#include <cfg.h>
#include <assert.h>
using namespace std;

// Bitvector for iterative dataflow analysis
class bitvector {
private:
  static const size_t SIZE = sizeof(unsigned);
  vector<unsigned> bits;
  size_t nbits;

public:
  bitvector() {
    nbits = 0;
  }

  bitvector(size_t num, bool init) {
    bits = vector<unsigned>((num + SIZE) / SIZE, init ? ~0u : 0u);
    nbits = num;
  }

  bitvector(const bitvector& bv) { 
    bits = bv.bits;
    nbits = bv.nbits;
  }

  size_t size() { return nbits; }

  void set(size_t i) {
    assert(i < nbits);
    size_t wi = i / SIZE;
    size_t bi = i % SIZE;
    bits[wi] |= (1 << bi);
  }

  void clear(size_t i) {
    assert(i < nbits);
    size_t wi = i / SIZE;
    size_t bi = i % SIZE;
    bits[wi] &= ~(1 << bi);
  }

  bool operator[](size_t i) const {
    assert(i < nbits);
    size_t wi = i / SIZE;
    size_t bi = i % SIZE;
    return (bits[wi] & (1 << bi)) != 0;
  }

  bool operator!=(const bitvector& bv) const {
    assert(nbits == bv.nbits);
    for (size_t i=0; i<bits.size(); i++)
      if (bits[i] != bv.bits[i])
	return true;
    return false;
  }

  bitvector& operator|=(const bitvector& bv) {
    assert(nbits == bv.nbits);
    for (size_t i=0; i<bits.size(); i++)
      bits[i] |= bv.bits[i];
    return *this;
  }

  bitvector operator|(const bitvector& bv) const {
    bitvector res(*this);
    res |= bv;
    return res;
  }
  
  bitvector& operator&=(const bitvector& bv) {
    assert(nbits == bv.nbits);
    for (size_t i=0; i<bits.size(); i++)
      bits[i] &= bv.bits[i];
    return *this;
  }

  bitvector operator&(const bitvector& bv) const {
    bitvector res(*this);
    res &= bv;
    return res;
  }

  bitvector operator~() {
    bitvector res(*this);
    for (size_t i=0; i<res.bits.size(); i++)
      res.bits[i] = ~res.bits[i];
    return res;
  }
};


// Driver for iterative dataflow analysis
enum DFDirection {Forward, Reverse};

template<class T>
void solve(cfg& graph, T& prob, DFDirection dir)
{
  list<Block*> worklist;
  vector<bool> in_worklist(graph.num_blocks(), true);

  const vector<Block*>& blocks = (dir == Forward) ?
    graph.get_forward_df_order() : graph.get_reverse_df_order();

  for (size_t i=0; i<blocks.size(); i++)
    worklist.push_back(blocks[i]);

  while (worklist.size() != 0)
  {
    Block* curr = worklist.front();
    worklist.pop_front();
    in_worklist[curr->get_number()] = false;

    if (prob.apply(curr))
    {
      const vector<Block*>& edges = (dir == Forward) ?
	curr->get_succs() : curr->get_preds();

      for (size_t i=0; i<edges.size(); i++)
      {
	Block* block = edges[i];
	size_t id = block->get_number();
	if (!in_worklist[id])
	{
	  worklist.push_back(block);
	  in_worklist[id] = true;
	}
      }
    }
  }
}

#endif
