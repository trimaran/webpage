/* Copyright (c) 2005 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: flatten.cc:
//   
//   Author: Sam Larsen
//   Date: Thu Jan  6 13:21:08 2005
//
//   Function:  Flatten expression trees.  Also make sure every subroutine
//		has one return.
//
//===========================================================================

#include <suif1.h>

// Leave certain branches intact so that s2lc can recognize and insert
// more specific branch opcodes than those provided in SUIF (e.g. blt, bge)
bool good_branch(instruction* instr, instruction* child)
{
  if_ops op = instr->opcode();
  if (op == io_btrue || op == io_bfalse)
  {
    if_ops child_op = child->opcode();
    if (child_op == io_seq) return true;
    if (child_op == io_sne) return true;
    if (child_op == io_sle) return true;
    if (child_op == io_sl)  return true;
  }

  return false;
}


bool useless_cvt(instruction* instr)
{
  if (instr->opcode() == io_cvt)
  {
    type_ops src = instr->src_op(0).type()->unqual()->op();
    type_ops dst = instr->result_type()->unqual()->op();

    if (src == dst)
      return true;

    if ((src == TYPE_INT || src == TYPE_PTR) &&
	(dst == TYPE_INT || dst == TYPE_PTR))
      return true;
  }

  return false;
}


void flatten(instruction* instr)
{
  if_ops op = instr->opcode();
  assert_msg(op != io_memcpy, ("found memcpy... run no_memcpys"));

  for (unsigned i=0; i<instr->num_srcs(); i++)
  {
    operand oprnd = instr->src_op(i);
    if (oprnd.is_instr() && !oprnd.is_immed())
    {
      instruction* child = oprnd.instr();
      flatten(child);
      
      if (!good_branch(instr, child))
      {
	tree_instr* ti = instr->parent();
	instr->src_op(i).remove();
	
	var_sym* new_vs = ti->scope()->new_unique_var
	  (child->result_type()->unqual(), "t");
	
	child->set_dst(operand(new_vs));
	instr->set_src_op(i, operand(new_vs));
	
	tree_instr* new_ti = new tree_instr(child);
	ti->parent()->insert_before(new_ti, ti->list_e());
      }
    }
  }
}


void flatten(tree_node_list* tnl)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_instr* ti = (tree_instr*)iter.step();
    assert_msg(ti->is_instr(), ("Convert to low suif\n"));
    flatten(ti->instr());
  }
}
    

// Only one return per procedure is allowed.  Transform procedure
// body to enforce this.
void find_retns(tree_proc* tp)
{
  tree_node_list* tnl = tp->body();
  tree_instr* last = (tree_instr*)tnl->tail()->contents;

  instruction* retn = NULL;
  var_sym* retn_val = NULL;

  type_node* type = tp->proc()->type()->return_type();

  if (last->instr()->opcode() != io_ret)
  {
    if (type->op() != TYPE_VOID)
    {
      retn_val = tnl->scope()->new_unique_var(type, "r");
      retn = new in_rrr(io_ret, type_void, operand(), operand(retn_val));
    }
    else retn = new in_rrr(io_ret, type_void, operand(), operand());

    tree_instr* ti = new tree_instr(retn);
    tnl->insert_after(ti, last->list_e());
    last = ti;
  }
  else
  {
    retn = last->instr();

    if (type->op() != TYPE_VOID)
    {
      operand oprnd = retn->src_op(0);
      assert(!oprnd.is_null());

      if (oprnd.is_symbol())
	retn_val = oprnd.symbol();
      else
      {
	oprnd.remove();
	retn_val = tnl->scope()->new_unique_var(type, "r");
	instruction* cpy = new in_rrr(io_cpy, type, operand(retn_val), oprnd);
	tnl->insert_before(new tree_instr(cpy), last->list_e());
	retn->set_src_op(0, operand(retn_val));
      }
    }
  }

  label_sym* target = tp->proc_syms()->new_unique_label();
  instruction* lab = new in_lab(target);
  tnl->insert_before(new tree_instr(lab), last->list_e());

  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_instr* ti = (tree_instr*)iter.step();
    if (ti == last) break;

    instruction* instr = ti->instr();
    if (instr->opcode() == io_ret)
    {
      ti->remove_instr(instr);
      instruction* jmp = new in_bj(io_jmp, target);
      ti->set_instr(jmp);

      if (type->op() != TYPE_VOID)
      {
	operand oprnd = instr->src_op(0);
	assert(!oprnd.is_null());
	assert(retn_val != NULL);

	oprnd.remove();
	instruction* cpy = new in_rrr(io_cpy, type, operand(retn_val), oprnd);
	tnl->insert_before(new tree_instr(cpy), ti->list_e());
      }
    }
  }
}


void do_proc(tree_proc* tp)
{
  flatten(tp->body());
  find_retns(tp);
}


int main(int argc, char** argv)
{
  if (argc != 3)
  {
    fprintf(stderr, "usage: %s <input> <output>\n", argv[0]);
    exit(1);
  }

  start_suif(argc, argv);
  char* k_stride;
  ANNOTE(k_stride, "stride", FALSE);
  suif_proc_iter(argc, argv, do_proc, TRUE, TRUE, FALSE);
}
