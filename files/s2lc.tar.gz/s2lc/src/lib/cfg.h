/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: cfg.h:
//   
//   Author: Sam Larsen
//   Date: Sat Jan 22 12:55:55 2005
//
//   Function:  CFG class.  This code will attempt to build basic blocks
//		from structured control flow.  However, 'for' loops are
//		difficult to get right since explicit instructions may
//		not exist for the lb, ub, and step computations.  This
//		class is best used after dismantling all high-level
//		SUIF constructs.
//
//===========================================================================

#ifndef _CFG_H_
#define _CFG_H_

#include <vector>
#include <map>
#undef assert
#include <suif1.h>

// Basic block class
class Block {
  friend class cfg;

public:
  enum Type {Entry, Exit, Real};
  Block(Type t) { set_type(t); }

  size_t num_instrs() const { return instrs.size(); }
  const std::vector<instruction*>& get_instrs() const { return instrs; }
  const std::vector<Block*>& get_preds() const { return preds; }
  const std::vector<Block*>& get_succs() const { return succs; }

  size_t get_number() const { return number; }
  bool is_entry() const { return type == Entry; }
  bool is_exit() const { return type == Exit; }
  bool is_real() const { return type == Real; }

private:
  void set_type(Type t) { type = t; }
  void set_number(size_t n) { number = n; }
  void append(instruction* ins) { instrs.push_back(ins); }
  void connect(Block*);
  void detach(Block*);

  std::vector<instruction*> instrs;
  std::vector<Block*> preds;
  std::vector<Block*> succs;
  Type type;
  size_t number;
};


// Control flow graph
class cfg {
public:
  cfg(tree_proc*, bool bb = true);
  ~cfg();

  Block* get_entry() const { return entry; }
  Block* get_exit() const { return exit; }
  Block* lookup(label_sym* sym) { return labels[sym]; }

  size_t num_blocks() const { return blocks.size(); }
  const std::vector<Block*>& get_blocks() const { return blocks; }

  // Sort blocks in depth-first order
  const std::vector<Block*>& get_forward_df_order() {
    if (forward_df_order.size() == 0) df_visit(true);
    return forward_df_order;
  }
  
  // Sort blocks in reverse depth-first order
  const std::vector<Block*>& get_reverse_df_order() {
    if (reverse_df_order.size() == 0) df_visit(false);
    return reverse_df_order;
  }

  void print(FILE* fp = stdout);

private:
  Block* new_block(Block::Type type = Block::Real);
  Block* do_tnl(tree_node_list*, Block*);
  void fix_branches();
  void remove_empty();

  void df_visit(bool);
  void df_visit(Block*, std::vector<bool>&, bool);

  std::vector<Block*> blocks;
  std::vector<Block*> forward_df_order;
  std::vector<Block*> reverse_df_order;
  Block* entry;
  Block* exit;

  std::map<label_sym*,Block*> labels;
  bool build_blocks;
};

#endif
