/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: do_loops.h:
//   
//   Author: Sam Larsen
//   Date: Fri Apr 29 15:15:26 2005
//
//   Function:  Class to locate inner countable loops that contain no
//		control flow and no function calls.
//
//===========================================================================

#ifndef _DO_LOOPS_H_
#define _DO_LOOPS_H_

#include <vector>
#undef assert
#include <suif1.h>

class Do_loops {
public:
  Do_loops(tree_proc* tp) {
    find_loops(tp->body());
  }
  const std::vector<tree_for*>& get_loops() {
    return loops;
  }

private:
  bool find_loops(tree_node_list*);
  bool good_loop(tree_for*);
  bool good_step(tree_for*);
  bool good_loop(tree_node_list*);
  bool good_instr(instruction*);

  std::vector<tree_for*> loops;
};

#endif
