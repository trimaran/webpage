/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: depend.cc:
//   
//   Author: Sam Larsen
//   Date: Mon Aug 29 20:43:39 2005
//
//   Function:  Functions for reading and writing dependence annotations.
//
//===========================================================================

#include "depend.h"

static char* k_parent_id = NULL;
static char* k_instr_num = NULL;
static char* k_loop_deps = NULL;
static char* k_addr_base = NULL;

// Register annotations
void depend_init(int write_out)
{
  assert(write_out == TRUE || write_out == FALSE);
  ANNOTE(k_parent_id, "parent_id", write_out);
  ANNOTE(k_instr_num, "instr_num", write_out);
  ANNOTE(k_loop_deps, "loop_deps", write_out);
  ANNOTE(k_addr_base, "addr_base", write_out);
}


// If the source is Fortran, this code assumes memops to different base 
// addresses can not alias.  For C, this holds only if both memops
// access a global or local array (i.e. no pointers), or if the
// pointers are declared with 'restrict'.
bool might_alias(instruction* in0, instruction* in1, src_lang_type lang)
{
  assert_msg(k_parent_id, ("ERROR: need to call depend_init()"));

  assert(in0 && in1);
  if_ops op0 = in0->opcode();
  if_ops op1 = in1->opcode();

  assert(op0 == io_lod || op0 == io_str);
  assert(op1 == io_lod || op1 == io_str);

  int off0, off1;
  var_sym* sym0 = find_base_sym(in0, off0);
  var_sym* sym1 = find_base_sym(in1, off1);

  if (sym0 != NULL && sym1 != NULL) {
    if ((sym0 != sym1) || (off0 != off1)) {

      // Assume different symbols do not alias in Fortran
      if (lang == src_fortran)
	return false;

      type_node* tn0 = sym0->type();
      type_node* tn1 = sym1->type();

      // Assume no aliasing if both are array types
      if (tn0->unqual()->is_array() && tn1->unqual()->is_array())
	return false;

#ifdef RESTRICT_KEYWORD
      // Assume no aliasing if both are restricted pointers
      if (tn0->is_ptr() && tn1->is_ptr())
      {
	type_node* ref0 = ((ptr_type*)tn0)->ref_type();
	type_node* ref1 = ((ptr_type*)tn1)->ref_type();

	if (ref0->is_restrict() && ref1->is_restrict())
	  return false;
      }
#endif
    }
  }

  return true;
}


// Checks for dependence edge from src to dst
bool is_dependence(instruction* src, instruction* dst,
		   src_lang_type lang, int* dist)
{
  assert(src && dst);

  // If these memops access different base addresses, there's no dependence
  if (might_alias(src, dst, lang) == false)
    return false;

  // Otherise, check dependence annotations
  immed_list* il0 = (immed_list*)src->peek_annote(k_parent_id);
  immed_list* il1 = (immed_list*)dst->peek_annote(k_parent_id);

  if (il0 && il1)
  {
    int par0 = il0->head()->contents.integer();
    int par1 = il1->head()->contents.integer();

    if (par0 == par1)
    {
      il0 = (immed_list*)src->peek_annote(k_instr_num);
      il1 = (immed_list*)dst->peek_annote(k_instr_num);

      assert(il0 && il1);
      int dst_id = il1->head()->contents.integer();

      annote_list_iter notes(src->annotes());
      while (!notes.is_empty())
      {
	annote* note = notes.step();
	if (!strcmp(note->name(), k_loop_deps))
	{
	  immed_list_iter iter((immed_list*)note->data());
	  int id = iter.step().integer();
	  if (id == dst_id)
	  {
	    if (dist) *dist = iter.step().integer();
	    return true;
	  }
	}
      }

      return false;
    }
  }

  return true;
}


// Attach annotations to uniquely identify instructions and the loop
// nest they reside in.
static void prep_instr(instruction* instr, int parent_id)
{
  if_ops opcode = instr->opcode();
  assert_msg(opcode != io_memcpy, ("found memcpy... run no_memcpys"));

  if (opcode == io_lod || opcode == io_str)
  {
    instr->set_annote(k_parent_id, new immed_list(immed(parent_id)));
    instr->set_annote(k_instr_num, new immed_list(immed(instr->number())));
  }

  for (unsigned i=0; i<instr->num_srcs(); i++)
  {
    operand src = instr->src_op(i);
    if (src.is_instr())
      prep_instr(src.instr(), parent_id);
  }
}


static void prep_tnl(tree_node_list* tnl, int parent_id)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
      prep_instr(((tree_instr*)tn)->instr(), parent_id);

    for (unsigned i=0; i<tn->num_child_lists(); i++)
      prep_tnl(tn->child_list_num(i), parent_id);
  }
}


void prep_tree_for(tree_for* tf)
{
  assert_msg(k_parent_id, ("ERROR: need to call loop_dep_init()"));
  prep_tnl(tf->body(), tf->number());
}


// Insert a dependence edge between these instructions
void add_edge(instruction* src, instruction* dst, int dist, edge_t type)
{
  immed_list* il0 = (immed_list*)src->peek_annote(k_instr_num);
  immed_list* il1 = (immed_list*)dst->peek_annote(k_instr_num);

  assert_msg(il0 && il1, ("ERROR: need to call prep_tree_for()"));

  src->append_annote(k_loop_deps, new immed_list(immed(dst->number()),
						 immed(dist),
						 immed(type)));
}


static operand base_from_instr(instruction *instr)
{
  switch (instr->opcode())
  {
    case io_cpy:
    case io_cvt:
    {
      if (instr->src_op(0).type()->is_ptr())
	return instr->src_op(0);
      break;
    }

    case io_add:
    case io_sub:
    {
      if (instr->src_op(0).type()->is_ptr())
	return instr->src_op(0);
      if (instr->opcode() == io_add && instr->src_op(1).type()->is_ptr())
	return instr->src_op(1);
      break;
    }

    case io_array:
      return ((in_array*)instr)->base_op();
      
    default:  break;
  }

  return operand();
}


static var_sym* find_base_sym(operand addr, int& offset)
{
  if (addr.is_symbol())
  {
    offset = 0;
    return addr.symbol();
  }

  else if (addr.is_immed())
  {
    immed imm = addr.immediate();
    if (imm.is_symbol())
    {
      offset = imm.offset();
      return (var_sym*)imm.symbol();
    }
  }

  else if (addr.is_instr())
  {
    addr = base_from_instr(addr.instr());
    return find_base_sym(addr, offset);
  }

  return NULL;
}


// Retrieve the base address symbol from this memop
var_sym* find_base_sym(instruction* instr, int& offset)
{
  if_ops opcode = instr->opcode();
  assert(opcode == io_lod || opcode == io_str);

  // see if there's already an annotation
  immed_list* il = (immed_list*)instr->peek_annote(k_addr_base);
  if (il != NULL)
  {
    immed_list_iter iter(il);
    sym_node* sym = iter.step().symbol();
    offset = iter.step().integer();
    return (var_sym*)sym;
  }

  // otherwise search the address operand
  return find_base_sym(instr->src_op(0), offset);
}


// Insert a base address annotation
void add_base_sym(instruction* memop, var_sym* sym, int offset)
{
  if_ops op = memop->opcode();
  assert(op == io_lod || op == io_str);
  assert(sym != NULL);

  immed_list* il = new immed_list;
  il->append(immed(sym));
  il->append(immed(offset));
  memop->set_annote(k_addr_base, il);
}
