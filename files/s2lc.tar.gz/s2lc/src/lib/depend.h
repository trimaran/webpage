/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: depend.h:
//   
//   Author: Sam Larsen
//   Date: Mon Aug 29 21:23:18 2005
//
//   Function:  Functions for reading and writing dependence annotations.
//
//===========================================================================

#ifndef _DEPEND_H_
#define _DEPEND_H_

#include <suif1.h>

enum edge_t {Flow, Anti, Output};

void depend_init(int write_out);
void prep_tree_for(tree_for* tf);
void add_edge(instruction* src, instruction* dst, int dist, edge_t type);
bool might_alias(instruction* in0, instruction* in1, src_lang_type lang);
bool is_dependence(instruction* src, instruction* dst,
		   src_lang_type lang, int* dist=NULL);

var_sym* find_base_sym(instruction* instr, int& offset);
void add_base_sym(instruction* memop, var_sym* sym, int offset);

#endif
