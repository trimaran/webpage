/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: cfg.cc:
//   
//   Author: Sam Larsen
//   Date: Sat Jan 22 12:56:45 2005
//
//   Function:  CFG class.  This code will attempt to build basic blocks
//		from structured control flow.  However, for loops are
//		difficult to get right since explicit instructions may
//		not exist for the lb, ub, and step computations.  This
//		class is best used after dismantling all high-level
//		SUIF constructs.
//
//===========================================================================

#include "cfg.h"
using namespace std;

void Block::connect(Block* block)
{
  succs.push_back(block);
  block->preds.push_back(this);
}


void Block::detach(Block* block)
{
  size_t last = succs.size() - 1;
  for (size_t i=0; i<succs.size(); i++)
  {
    if (succs[i] == block)
    {
      if (i < last) succs[i] = succs[last];
      succs.pop_back();
      break;
    }
  }

  last = block->preds.size() - 1;
  for (size_t i=0; i<block->preds.size(); i++)
  {
    if (block->preds[i] == this)
    {
      if (i < last) block->preds[i] = block->preds[last];
      block->preds.pop_back();
      break;
    }
  }
}


cfg::cfg(tree_proc* tp, bool bb)
{
  build_blocks = bb;

  entry = new_block(Block::Entry);
  exit = new_block(Block::Exit);

  Block* first = new_block();
  Block* last = do_tnl(tp->body(), first);

  entry->connect(first);
  last->connect(exit);

  fix_branches();
  remove_empty();

  for (size_t i=0; i<blocks.size(); i++)
    blocks[i]->set_number(i);
}


cfg::~cfg()
{
  for (size_t i=0; i<blocks.size(); i++)
  {
    assert(blocks[i]);
    delete blocks[i];
  }
}


Block* cfg::new_block(Block::Type type)
{
  Block* block = new Block(type);
  blocks.push_back(block);
  return block;
}


Block* cfg::do_tnl(tree_node_list* tnl, Block* curr)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    switch (tn->kind())
    {
      case TREE_INSTR:
      {
	instruction* instr = ((tree_instr*)tn)->instr();
	if_ops opcode = instr->opcode();

	// Handle labels before inserting instructions
	if (opcode == io_lab)
	{
	  Block* prev = curr;
	  curr = new_block();
	  prev->connect(curr);
	  labels[((in_lab*)instr)->label()] = curr;
	}

	if (opcode != io_mrk)
	  curr->append(instr);

	if (opcode == io_ret)
	{
	  Block* prev = curr;
	  curr = new_block();
	  assert(exit);
	  prev->connect(exit);
	}

	else if (instr->format() == inf_bj || !build_blocks)
	{
	  Block* prev = curr;
	  curr = new_block();
	  if (opcode != io_jmp)
	    prev->connect(curr);  
	}
      }
      break;

      // A TREE_LOOP contains an explicit branch to the 'toplabl'
      // label.  Therefore, we don't need to create a new block
      // following the loop as this will be created when the branch
      // instruction is encountered.  Also, the backedge will be
      // inserted by fix_branches().
      case TREE_LOOP:
      {
	tree_loop* tl = (tree_loop*)tn;

	Block* body_b = new_block();
	Block* body_e = do_tnl(tl->body(), body_b);
	curr->connect(body_b);

	Block* test_b = new_block();
	Block* test_e = do_tnl(tl->test(), test_b);	
	body_e->connect(test_b);

	curr = test_e;

	labels[tl->contlab()] = test_b;
	labels[tl->brklab()]  = curr;
	labels[tl->toplab()]  = body_b;
      }	    
      break;

      case TREE_FOR:
      {
	tree_for* tf = (tree_for*)tn;

	Block* lb_e = do_tnl(tf->lb_list(), curr);
	Block* ub_e = do_tnl(tf->ub_list(), lb_e);

	Block* lpad_b = new_block();
	Block* lpad_e = do_tnl(tf->landing_pad(), lpad_b);
	ub_e->connect(lpad_b);

	Block* body_b = new_block();
	Block* body_e = do_tnl(tf->body(), body_b);
	lpad_e->connect(body_b);

	Block* step_b = new_block();
	Block* step_e = do_tnl(tf->step_list(), step_b);
	step_e->connect(body_b);

	curr = new_block();
	ub_e->connect(curr);
	step_e->connect(curr);

	labels[tf->contlab()] = step_b;
	labels[tf->brklab()]  = curr;
      }
      break;

      // A TREE_IF contains an explicit branch to the jumpto label.
      // Therefore, we don't need to create a new block for the 'then'
      // part as this will be created when the branch is encounterd.
      // Also, the edge between the header and the 'else' part will
      // be inserted by fix_branches().
      case TREE_IF:
      {
	tree_if* ti = (tree_if*)tn;	

	Block* head_e = do_tnl(ti->header(), curr);
	Block* then_e = do_tnl(ti->then_part(), head_e);

	Block* else_b = new_block();
	Block* else_e = do_tnl(ti->else_part(), else_b);

	curr = new_block();
	then_e->connect(curr);
	else_e->connect(curr);

	labels[ti->jumpto()] = else_b;
      }
      break;

      case TREE_BLOCK:
      {
	tree_block* tb = (tree_block*)tn;
	curr = do_tnl(tb->body(), curr);
      }
      break;

      default: assert(0);
    }
  }

  return curr;
}


void cfg::fix_branches()
{
  for (size_t i=0; i<blocks.size(); i++)
  {
    Block* block = blocks[i];
    if (block->num_instrs() > 0)
    {
      instruction* instr = block->instrs.back();
      if (instr->format() == inf_bj)
      {
	label_sym* target = ((in_bj*)instr)->target();
	map<label_sym*,Block*>::iterator iter = labels.find(target);
	assert_msg(iter != labels.end(), ("branch to unknown label\n"));
	block->connect(iter->second);
      }
    }
  }
}


void cfg::remove_empty()
{
  vector<Block*> tmp;

  for (size_t i=0; i<blocks.size(); i++)
  {
    Block* block = blocks[i];
    if (block->is_real() && block->num_instrs() == 0)
    {
      const vector<Block*>& preds = block->get_preds();
      const vector<Block*>& succs = block->get_succs();

      for (size_t j=0; j<preds.size(); j++)
	for (size_t k=0; k<succs.size(); k++)
	  preds[j]->connect(succs[k]);

      while (preds.size())
	preds[0]->detach(block);

      while (succs.size())
	block->detach(succs[0]);

      delete block;
    }
    else tmp.push_back(block);
  }

  blocks = tmp;
}


void cfg::df_visit(bool forward)
{
  vector<bool> visited(blocks.size(), false);
  df_visit(forward ? entry : exit, visited, forward);
}
 

void cfg::df_visit(Block* curr, vector<bool>& visited, bool forward)
{
  visited[curr->get_number()] = true;
  if (forward)
    forward_df_order.push_back(curr);
  else
    reverse_df_order.push_back(curr);

  const vector<Block*>& blocks = forward ?
    curr->get_succs() : curr->get_preds();

  for (size_t i=0; i<blocks.size(); i++)
  {
    Block* block = blocks[i];
    if (!visited[block->get_number()])
      df_visit(block, visited, forward);
  }
}


void cfg::print(FILE* fp)
{
  fprintf(fp, "digraph cfg {\n");

  for (size_t i=0; i<blocks.size(); i++)
  {
    Block* block = blocks[i];
    int num = block->get_number();
    fprintf(fp, "%d [label=\"BB: %d\\n", num, num);
    
    if (block->is_entry()) fprintf(fp, "ENTRY");
    if (block->is_exit()) fprintf(fp, "EXIT");

    const vector<instruction*>& instrs = block->get_instrs();
    for (size_t j=0; j<instrs.size(); j++)
      fprintf(fp, "%d: %s\\n", instrs[j]->number(), instrs[j]->op_string());

    fprintf(fp, "\", shape=box];\n");
  }

  for (size_t i=0; i<blocks.size(); i++)
  {
    int id = blocks[i]->get_number();

    const vector<Block*>& succs = blocks[i]->get_succs();
    for (size_t j=0; j<succs.size(); j++)
      fprintf(fp, "%d -> %d;\n", id, succs[j]->get_number());
  }

  fprintf(fp, "}\n");
}
