/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: do_loops.cc:
//   
//   Author: Sam Larsen
//   Date: Fri Apr 29 15:15:35 2005
//
//   Function:  Class to locate inner countable loops that contain no
//		control flow and no function calls.
//
//===========================================================================

#include "do_loops.h"
using namespace std;

// Make sure step op is an integer constant
bool Do_loops::good_step(tree_for* tf)
{
  operand step = tf->step_op();
  if (step.is_immed())
  {
    immed imm = step.immediate();
    if (imm.is_integer())
      return true;
  }

  return false;
}

// Make sure there are no function calls or internal branches
bool Do_loops::good_instr(instruction* instr)
{  
  if (instr->format() == inf_bj)
    return false;
  
  if (instr->opcode() == io_cal)
    return false;
  
  for (unsigned j=0; j<instr->num_srcs(); j++)
  {
    operand oprnd = instr->src_op(j);
    if (oprnd.is_instr() && !good_instr(oprnd.instr()))
      return false;
  }
  
  return true;
}


bool Do_loops::good_loop(tree_node_list* tnl)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();    
    if (tn->is_instr())
    {
      instruction* instr = ((tree_instr*)tn)->instr();
      if (!good_instr(instr))
	return false;
    }

    else return false;
  }

  return true;
}


bool Do_loops::good_loop(tree_for* tf)
{
  if (!good_step(tf) || !good_loop(tf->body()))
    return false;

  return true;
}

// Look for inner loops
bool Do_loops::find_loops(tree_node_list* tnl)
{
  bool inner_for = true;

  tree_node_list_iter iter(tnl);
  while(!iter.is_empty())
  {
    tree_node* tn = iter.step();
    tree_kinds kind = tn->kind();
    switch (kind)
    {
      case TREE_FOR:
      {
	tree_for* tf = (tree_for*)tn;
	if (find_loops(tf->body()) && good_loop(tf))
	{
	  if (tf->index()->is_addr_taken())
	    warning_line(tf, "for loop index has address taken");

	  loops.push_back(tf);
	}
	
	inner_for = false;
	break;
      }

      case TREE_LOOP:
      {
	find_loops(((tree_loop*)tn)->body());
	inner_for = false;
	break;
      }

      case TREE_IF:
      {
	inner_for = find_loops(((tree_if*)tn)->then_part()) && inner_for;
	inner_for = find_loops(((tree_if*)tn)->else_part()) && inner_for;
	break;
      }
      
      case TREE_BLOCK: assert_msg(0, ("dismantle blocks"));
      case TREE_INSTR: break;
      default: assert(0);
    }
  }

  return inner_for;
}
