/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: indvar_opt.cc:
//   
//   Author: Sam Larsen
//   Date: Tue Mar  6 16:51:25 2001
//
//   Function:  Strength reduction of address calculations
//
//===========================================================================

#include "ind_vars.h"
#include <useful.h>
#include <builder.h>
#include "stride.h"

int stride_only;
char* k_stride;
char* k_addr_incr;

//---------------------------------------------------------------------------
bool has_lab(tree_node_list* tnl, label_sym* lab)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
    {
      in_bj* bj = (in_bj*)((tree_instr*)tn)->instr();
      if (bj->format() == inf_bj && bj->target() == lab)
	return true;
    }      

    for (unsigned i=0; i<tn->num_child_lists(); i++)
      if (has_lab(tn->child_list_num(i), lab))
	return true;
  }

  return false;
}

//---------------------------------------------------------------------------
void replace_lab(tree_node_list* tnl, label_sym* old_lab, label_sym* new_lab)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
    {
      in_bj* bj = (in_bj*)((tree_instr*)tn)->instr();
      if (bj->format() == inf_bj && bj->target() == old_lab)
	bj->set_target(new_lab);
    }

    for (unsigned i=0; i<tn->num_child_lists(); i++)
      replace_lab(tn->child_list_num(i), old_lab, new_lab);
  }
}

//---------------------------------------------------------------------------
void replace_var(instruction* instr, var_sym* old_var, var_sym* new_var)
{
  for (unsigned i=0; i<instr->num_srcs(); i++)
  {
    operand src = instr->src_op(i);
    if (src.is_symbol())
    {
      var_sym* sym = src.symbol();
      if (sym == old_var)
      {
	src.remove();
	instr->set_src_op(i, operand(new_var));
      }
    }

    else if (src.is_instr())
      replace_var(src.instr(), old_var, new_var);
  }
}

//---------------------------------------------------------------------------
void replace_var(tree_node_list* tnl, var_sym* old_var, var_sym* new_var)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
      replace_var(((tree_instr*)tn)->instr(), old_var, new_var);

    for (unsigned i=0; i<tn->num_child_lists(); i++)
      replace_var(tn->child_list_num(i), old_var, new_var);
  }
}

//---------------------------------------------------------------------------
void strength_reduce(tree_node* tn, ind_vars& ivars)
{
  bool is_for = tn->is_for();

  tree_for* tf = (tree_for*)tn;
  tree_loop* tl = (tree_loop*)tn;
  
  tree_node_list* body = is_for ? tf->body() : tl->body();
  base_symtab* scope = body->scope();

  sr_expr_vec& sr_exprs = ivars.get_sr_exprs();

  // Make sure to increment everything before continuing
  if (sr_exprs.size() > 0)
  {
    label_sym* contlab = is_for ? tf->contlab() : tl->contlab();
    if (has_lab(body, contlab))
    {
      proc_symtab* symtab = tn->proc()->block()->proc_syms();
      label_sym* new_lab = symtab->new_unique_label("cont");
      replace_lab(body, contlab, new_lab);
      body->append(new tree_instr(new in_lab(new_lab)));
    }
  }

  // Take care of each dependent induction variable and mem address
  for (unsigned i=0; i<sr_exprs.size(); i++)
  {
    sr_expr& expr = sr_exprs[i];
    compl_var& cvar = expr.cvar();
    basic_var& bvar = expr.bvar();

    instruction* instr = cvar.instr();
    
    // Calculate d * b
    lineq& lin = expr.linear_eq();
    operand d = bvar.src_op();
    operand b = lin.get_mul();
    
    int val;
    bool fold = fold_mul(d, b, val);

    // Make the new temporary variable
    var_sym* tmp;

    bool memop = instr->opcode() == io_lod || instr->opcode() == io_str;
    if (memop)
    {
      // Replace address calculation with a new variable
      tmp = scope->new_unique_var(instr->src_op(0).type()->unqual(), "p");
      operand oprnd = instr->src_op(0);
      oprnd.remove();
      instr->set_src_op(0, operand(tmp));

      // Attach the stride annotation
      if (fold) set_stride(instr, val);
    }
    else
    {
      // Replace the assignment of the ind_var with a cpy from the tmp var
      var_sym* dst = instr->dst_op().symbol();
      tmp = scope->new_unique_var(dst->type()->unqual(), "t");
      
      tree_instr* ti = instr->parent();
      ti->remove_instr(instr);
      block cpy = (block(dst) = block(tmp));
      ti->set_instr(cpy.make_instruction());

      //replace_var(ti->list_e(), dst, tmp);
    }
    
    // Put tmp = tmp + d*b after the increment of the basic induction var
    block con = fold ? block(val) : (block(d) * block(b));
    block inc = (block(tmp) = block(tmp) + con);

    instruction* pos = bvar.instr();
    tree_node_list_e* list_e = pos ? pos->parent()->list_e() : body->tail();
    instruction* update = inc.make_instruction();
    body->insert_after(new tree_instr(update), list_e);

    // if this is an address increment for a memop, note it as such
    if (memop) {
      update->set_annote(k_addr_incr, new immed_list);
      if (fold) set_stride(update, val);
    }

    // Put tmp = b*i + c in the loop header
    var_sym* biv = lin.get_biv();
    block var = is_for && biv==tf->index() ? block(tf->lb_op()) : block(biv);

    block mul = lin.has_mul() ? (block(lin.get_mul()) * var) : var;
    block add = lin.has_add() ? (mul + block(lin.get_add())) : mul;
    block hdr = (block(tmp) = add);
    
    if (is_for) tf->landing_pad()->append(hdr.make_tree_node());
    else tl->parent()->insert_before(hdr.make_tree_node(), tl->list_e());
  }
}


//---------------------------------------------------------------------------
void attach_strides(ind_vars& ivars)
{
  sr_expr_vec& sr_exprs = ivars.get_sr_exprs();
  for (unsigned i=0; i<sr_exprs.size(); i++)
  {
    sr_expr& expr = sr_exprs[i];

    instruction* instr = expr.cvar().instr();
    if (instr->opcode() == io_lod || instr->opcode() == io_str)
    {
      // Calculate d * b
      operand d = expr.bvar().src_op();
      operand b = expr.linear_eq().get_mul();
      
      int val;
      bool fold = fold_mul(d, b, val);
      if (fold) set_stride(instr, val);
    }
  }
}


//---------------------------------------------------------------------------
void mark_nonstrided(instruction* instr)
{
  for (unsigned j=0; j<instr->num_srcs(); j++)
  {
    operand src = instr->src_op(j);
    if (src.is_instr())
      mark_nonstrided(src.instr());
  }

  if_ops op = instr->opcode();
  if (op == io_lod || op == io_str)
    set_stride(instr, 0);
}

void mark_nonstrided(tree_node_list* tnl)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
      mark_nonstrided(((tree_instr*)tn)->instr());

    for (unsigned i=0; i<tn->num_child_lists(); i++)
      mark_nonstrided(tn->child_list_num(i));
  }
}

void mark_nonstrided(tree_node* tn)
{
  if (tn->is_for()) mark_nonstrided(((tree_for*)tn)->body());
  else mark_nonstrided(((tree_loop*)tn)->body());
}


//---------------------------------------------------------------------------
void find_loops(tree_node_list* tnl, bool fortran)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    assert_msg(!tn->is_block(), ("dismantle tree_blocks"));

    for (unsigned i=0; i<tn->num_child_lists(); i++)
      find_loops(tn->child_list_num(i), fortran);

    if (tn->is_for() || tn->is_loop())
    {
      ind_vars ivars(tn, fortran);
      if (stride_only) attach_strides(ivars);
      else strength_reduce(tn, ivars);
      mark_nonstrided(tn);
    }
  }
}

//---------------------------------------------------------------------------
void do_proc(tree_proc* tp)
{
  bool fortran = tp->proc()->src_lang() == src_fortran;
  block::set_proc(tp);
  find_loops(tp->body(), fortran);
}

//---------------------------------------------------------------------------
int main(int argc, char** argv)
{
  static cmd_line_option options[] = {
    {CLO_NOARG, "-stride-only", "", &stride_only}
  };
  
  parse_cmd_line(argc, argv, options, sizeof(options)/sizeof(cmd_line_option));

  if (argc != 3)
  {
    fprintf(stderr, "Usage: %s <input> <output>\n", argv[0]);
    exit(1);
  }

  start_suif(argc, argv);
  ANNOTE(k_stride, "stride", TRUE);
  ANNOTE(k_addr_incr, "addr_incr", TRUE);
  suif_proc_iter(argc, argv, do_proc, TRUE, TRUE, FALSE);
}
