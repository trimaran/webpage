/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: lineq.h:
//   
//   Author: Sam Larsen
//   Date: Tue Mar  6 01:48:55 2001
//
//   Function:  A linear equation of the form j=mul*biv+add is associated 
//		with each induction variable.  biv is a basic induction 
//		variable, 'mul' and 'add' are loop constants.
//
//===========================================================================

#ifndef _LINEQ_H_
#define _LINEQ_H_

#include <suif1.h>

class lineq {
  friend lineq operator*(operand, lineq&);
  friend lineq operator+(operand, lineq&);
  friend lineq operator-(operand, lineq&);

public:
  lineq();
  lineq(var_sym*);
  lineq(const lineq&);

  lineq operator*(operand);
  lineq operator+(operand);
  lineq operator-(operand);
  lineq operator-();

  var_sym* get_biv();
  operand get_mul();
  operand get_add();

  bool has_mul();
  bool has_add();
  bool is_null();

private:
  var_sym* biv;
  operand mul;
  operand add;
};

#endif
