/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: ind_vars.h:
//   
//   Author: Sam Larsen
//   Date: Tue Mar  6 16:45:59 2001
//
//   Function:  Induction variable identification
//
//===========================================================================

#ifndef _IND_VARS_H_
#define _IND_VARS_H_

#include <map>
#include <vector>
#undef assert
#include "containers.h"
using namespace std;

typedef map<var_sym*, lineq> lineq_table;
typedef map<var_sym*, basic_var> basic_var_table;
typedef map<var_sym*, compl_var> compl_var_table;
typedef map<suif_object*, unsigned> obj_map;
typedef vector<sr_expr> sr_expr_vec;

class ind_vars {
public:
  ind_vars(tree_node*, bool);
  sr_expr_vec& get_sr_exprs();
  compl_var_table& get_compl_vars();
  basic_var_table& get_basic_vars();

private:
  inline bool good_var(var_sym*);
  void count_writes(in_cal*);
  void count_writes(tree_node_list*);
  bool loop_const(operand);
  bool basic_expr(instruction*);
  void find_basic_vars(tree_node_list*);
  lineq make_lineq(instruction*, var_sym*&);
  void find_compl_vars(tree_node_list*);
  void find_mem_addrs(instruction*);
  void find_mem_addrs(tree_node_list*);
  bool is_basic(var_sym*);
  bool is_compl(var_sym*);

  bool fortran;
  obj_map num_writes;
  lineq_table lineqs;
  compl_var_table compl_vars;
  basic_var_table basic_vars;
  sr_expr_vec sr_exprs;
};

#endif
