/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: ind_vars.cc:
//   
//   Author: Sam Larsen
//   Date: Wed Feb 14 16:15:38 2001
//
//   Function:  Induction variable identification
//
//===========================================================================

#include <map>
#include "ind_vars.h"
#include "stride.h"

//---------------------------------------------------------------------------
// Some basic requirements of induction variables
//---------------------------------------------------------------------------
bool ind_vars::good_var(var_sym* sym)
{
  if (sym->is_spilled())
    return false;

  if (sym->type()->op() == TYPE_FLOAT)
    return false;

  if (num_writes[sym] != 1)
    return false;

  return true;
}

//---------------------------------------------------------------------------
// If a variable's address is passed to a function, then assume it's 
// written in that function and increment num_writes
//---------------------------------------------------------------------------
void ind_vars::count_writes(in_cal* call)
{
  for (unsigned j=0; j<call->num_args(); j++)
  {
    operand oprnd = call->argument(j);
    if (oprnd.is_instr())
    {
      in_ldc* ldc = (in_ldc*)oprnd.instr();
      if (ldc->opcode() == io_ldc)
      {
	immed imm = ldc->value();
	if (imm.is_symbol())
	{
	  sym_node* sym = imm.symbol();
	  if (sym->is_var())
	    num_writes[sym]++;
	}
      }
    }
  }
}

//---------------------------------------------------------------------------
// Count the number of times each variable is written
//---------------------------------------------------------------------------
void ind_vars::count_writes(tree_node_list* tnl)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
    {
      instruction* instr = ((tree_instr*)tn)->instr();
      operand dst = instr->dst_op();
      if (dst.is_symbol())
	num_writes[dst.symbol()]++;

      // With fortran we can be more aggressive, but we need to
      // make sure we account for call-by-ref variables
      if (fortran && instr->opcode() == io_cal)
	count_writes((in_cal*)instr);
    }

    if (tn->is_for())
      num_writes[((tree_for*)tn)->index()] += 2;

    for (unsigned i=0; i<tn->num_child_lists(); i++)
      count_writes(tn->child_list_num(i));
  }
}      

//---------------------------------------------------------------------------
// Return true if the operand is a loop constant
//---------------------------------------------------------------------------
bool ind_vars::loop_const(operand oprnd)
{
  if (oprnd.is_immed())
    return true;

  else if (oprnd.is_instr())
  {
    instruction* instr = oprnd.instr();
    for (unsigned i=0; i<instr->num_srcs(); i++)
      if (!loop_const(instr->src_op(i)))
	return false;

    return true;
  }

  else if (oprnd.is_symbol())
  {
    var_sym* sym = oprnd.symbol();
    return num_writes[sym] == 0 && (fortran || !sym->is_spilled());
  }

  else return true;
}

//---------------------------------------------------------------------------
// Return true if this instruction is of the form i+d or d+i, where d is
// a loop constant
//---------------------------------------------------------------------------
bool ind_vars::basic_expr(instruction* instr)
{
  if_ops opcode = instr->opcode();
  if (opcode == io_add || opcode == io_sub)
  {
    operand dst = instr->dst_op();
    assert(dst.is_symbol());

    operand src0 = instr->src_op(0);
    operand src1 = instr->src_op(1);

    if ((dst == src0 && loop_const(src1)) ||
	(dst == src1 && loop_const(src0) && opcode == io_add))
      return true;
  }

  return false;
}

//---------------------------------------------------------------------------
// Find basic induction variables
//---------------------------------------------------------------------------
void ind_vars::find_basic_vars(tree_node_list* tnl)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
    {
      instruction* instr = ((tree_instr*)tn)->instr();
      operand dst = instr->dst_op();
      if (dst.is_symbol())
      {
	var_sym* sym = dst.symbol();
	if (good_var(sym) && basic_expr(instr))
	{
	  basic_vars[sym] = basic_var(instr);
	  assert(lineqs.find(sym) == lineqs.end());
	  lineqs[sym] = lineq(sym);
	}
      }
    }
  }
}
    
//---------------------------------------------------------------------------
// Return the corresponding linear equation of this expression.  If it is
// not of the proper form then return a null lineq.
//---------------------------------------------------------------------------
lineq ind_vars::make_lineq(instruction* instr, var_sym*& ind)
{
  if_ops op = instr->opcode();
  if (op == io_add || op == io_mul || op == io_sub || op == io_neg)
  {
    operand src0 = instr->src_op(0);
    operand src1 = instr->src_op(1);

    if (loop_const(src0))
    {
      if (src1.is_symbol() && lineqs.find(src1.symbol()) != lineqs.end())
      {
	ind = src1.symbol();
	switch (op) {
	case io_mul: return src0 * lineqs[ind]; break;
	case io_add: return src0 + lineqs[ind]; break;
	case io_sub: return src0 - lineqs[ind]; break;
	default:     return lineq();
	}
      }
      
      else if (src1.is_instr())
      {
	lineq lin = make_lineq(src1.instr(), ind);
	if (!lin.is_null())
	{
	  switch (op) {
	  case io_mul: return src0 * lin; break;
	  case io_add: return src0 + lin; break;
	  case io_sub: return src0 - lin; break;
	  default:     return lineq();
	  }
	}
      }
    }
    else if (loop_const(src1))
    {
      if (src0.is_symbol() && lineqs.find(src0.symbol()) != lineqs.end())
      {
	ind = src0.symbol();
	switch (op) {
	case io_mul: return  lineqs[ind] * src1; break;
	case io_add: return  lineqs[ind] + src1; break;
	case io_sub: return  lineqs[ind] - src1; break;
	case io_neg: return -lineqs[ind]; break;
	default:     return lineq();
	}
      }
      else if (src0.is_instr())
      {
	lineq lin = make_lineq(src0.instr(), ind);
	if (!lin.is_null())
	{
	  switch (op) {
	  case io_mul: return  lin * src1; break;
	  case io_add: return  lin + src1; break;
	  case io_sub: return  lin - src1; break;
	  case io_neg: return -lin; break;
	  default:     return lineq();
	  }
	}
      }
    }
  }

  else if (op == io_cvt || op == io_cpy)
  {
    operand src = instr->src_op(0);
    if (src.is_symbol() && lineqs.find(src.symbol()) != lineqs.end())
    {
      ind = src.symbol();
      return lineqs[ind];
    }

    else if (src.is_instr())
      return make_lineq(src.instr(), ind);
  }

  return lineq();
}

//---------------------------------------------------------------------------
// Find all dependent induction variables
//---------------------------------------------------------------------------
void ind_vars::find_compl_vars(tree_node_list* tnl)
{
  unsigned size = 0;
  while (size != lineqs.size())
  {
    size = lineqs.size();
    tree_node_list_iter iter(tnl);
    
    while (!iter.is_empty())
    {
      tree_node* tn = iter.step();
      if (tn->is_instr())
      {
	instruction* instr = ((tree_instr*)tn)->instr();
	operand oprnd = instr->dst_op();
	if (oprnd.is_symbol())
	{
	  var_sym* dst = oprnd.symbol();
	  if (good_var(dst) && lineqs.find(dst) == lineqs.end())
	  {
	    var_sym* ind = NULL;
	    lineq lin = make_lineq(instr, ind);

	    if (!lin.is_null())
	    {
	      assert(ind != NULL);

	      lineqs[dst] = lin;
	      compl_var cvar(instr, ind);
	      compl_vars[dst] = cvar;

	      basic_var& bvar = basic_vars[lin.get_biv()];
	      sr_exprs.push_back(sr_expr(cvar, bvar, lin));
	    }
	  }
	}
      }
    }
  }
}

//---------------------------------------------------------------------------
// Gather linear equations for address calculations
//---------------------------------------------------------------------------
void ind_vars::find_mem_addrs(instruction* instr)
{      
  if_ops opcode = instr->opcode();
  assert_msg(opcode != io_memcpy, ("found memcpy... run no_memcpys"));

  if (opcode == io_lod || opcode == io_str)
  {
    operand oprnd = instr->src_op(0);
    if (oprnd.is_instr())
    {
      instruction* addr = oprnd.instr();
      var_sym* ind = NULL;
      lineq lin = make_lineq(addr, ind);

      if (!lin.is_null())
      {
	assert(ind != NULL);
	compl_var cvar(instr, ind);
	basic_var& bvar = basic_vars[lin.get_biv()];
	sr_exprs.push_back(sr_expr(cvar, bvar, lin));
      }
    }
  }

  for (unsigned i=0; i<instr->num_srcs(); i++)
    if (instr->src_op(i).is_instr())
      find_mem_addrs(instr->src_op(i).instr());
}

//---------------------------------------------------------------------------
void ind_vars::find_mem_addrs(tree_node_list* tnl)
{
  tree_node_list_iter iter(tnl);
  while (!iter.is_empty())
  {
    tree_node* tn = iter.step();
    if (tn->is_instr())
      find_mem_addrs(((tree_instr*)tn)->instr());

    else for (unsigned i=0; i<tn->num_child_lists(); i++)
      find_mem_addrs(tn->child_list_num(i));
  }
}

//---------------------------------------------------------------------------
// Find the induction variables
//---------------------------------------------------------------------------
ind_vars::ind_vars(tree_node* tn, bool src_fortran)
{
  fortran = src_fortran;

  if (tn->is_for())
  {
    tree_for* tf = (tree_for*)tn;
    tree_node_list* body = tf->body();

    count_writes(body);

    // Account for *the* index variable since it's not written in the body
    var_sym* ind = tf->index();
    lineqs[ind] = lineq(ind);
    basic_vars[ind] = basic_var(tf->step_op());
    num_writes[ind] = 1;

    find_basic_vars(body);
    find_compl_vars(body);
    find_mem_addrs(body);
  }
  else
  {
    assert(tn->is_loop());
    tree_loop* tl = (tree_loop*)tn;

    tree_node_list* body = tl->body();

    count_writes(body);
    count_writes(tl->test());

    find_basic_vars(body);
    find_compl_vars(body);
    find_mem_addrs(body);
  }
}

//---------------------------------------------------------------------------
bool ind_vars::is_basic(var_sym* vs)
{
  return basic_vars.find(vs) != basic_vars.end();
}

//---------------------------------------------------------------------------
bool ind_vars::is_compl(var_sym* vs)
{
  return compl_vars.find(vs) != compl_vars.end();
}

//---------------------------------------------------------------------------
sr_expr_vec& ind_vars::get_sr_exprs()
{
  return sr_exprs;
}

//---------------------------------------------------------------------------
compl_var_table& ind_vars::get_compl_vars()
{
  return compl_vars;
}

//---------------------------------------------------------------------------
basic_var_table& ind_vars::get_basic_vars()
{
  return basic_vars;
}
