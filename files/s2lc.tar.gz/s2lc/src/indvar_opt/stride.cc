/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: stride.cc:
//   
//   Author: Sam Larsen
//   Date: Thu Mar 29 13:37:44 2001
//
//   Function:  Stuff to compute and add stride annotations to 
//		induction variables
//
//===========================================================================

#include "stride.h"

extern char* k_stride;

//---------------------------------------------------------------------------
bool fold(operand oprnd, int& val)
{
  if (oprnd.is_instr())
  {
    instruction* instr = oprnd.instr();
    if_ops opcode = instr->opcode();

    if (opcode == io_ldc)
    {
      immed imm = ((in_ldc*)instr)->value();
      assert(imm.is_integer());

      val = imm.integer();
      return true;
    }
    else if (opcode == io_mul || opcode == io_add || opcode == io_sub)
    {
      int a, b;
      if (fold(instr->src_op(0), a) && fold(instr->src_op(1), b))
      {
	if (opcode == io_mul) val = a * b;
	if (opcode == io_add) val = a + b;
	if (opcode == io_sub) val = a - b;
	return true;
      }
    }
    else if (opcode == io_neg || opcode == io_cpy || opcode == io_cvt)
    {
      int a;
      if (fold(instr->src_op(0), a))
      {
	if (opcode == io_neg) val = -a;
	if (opcode == io_cpy) val =  a;
	if (opcode == io_cvt) val =  a;
	return true;
      }
    }
  }

  return false;
}

//---------------------------------------------------------------------------
bool fold_mul(operand op0, operand op1, int& val)
{
  int a, b;
  if (fold(op0, a) && fold(op1, b))
  {
    val = a * b;
    return true;
  }

  return false;
}

//---------------------------------------------------------------------------
void set_stride(suif_object* obj, int val)
{
  immed_list* il = (immed_list*)obj->peek_annote(k_stride);
  if (il == NULL)
  {
    il = new immed_list;
    il->append(immed(val));
    obj->set_annote(k_stride, il);
  }
}
