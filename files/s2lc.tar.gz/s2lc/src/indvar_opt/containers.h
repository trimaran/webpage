/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: containers.h:
//   
//   Author: Sam Larsen
//   Date: Mon Mar 26 13:12:52 2001
//
//   Function:  Containers for induction variables and memory addresses
//
//===========================================================================

#ifndef _CONTAINERS_H_
#define _CONTAINERS_H_

#include "lineq.h"

class basic_var {
public:
  basic_var();
  basic_var(instruction*);
  basic_var(operand);
  basic_var(const basic_var&);

  operand src_op() { return src.clone(); }
  instruction* instr() { return ins; }

private:
  operand src;
  instruction* ins;
};


class compl_var {
public:
  compl_var();
  compl_var(instruction*, var_sym*);
  compl_var(const compl_var&);

  instruction* instr() { return ins; }
  var_sym* induc_var() { return sym; }

private:
  instruction* ins;
  var_sym* sym;
};


class sr_expr {
public:
  sr_expr();
  sr_expr(compl_var&, basic_var&, lineq&);
  sr_expr(const sr_expr&);

  compl_var& cvar() { return com; }
  basic_var& bvar() { return bas; }
  lineq& linear_eq() { return lin; }

private:
  compl_var com;
  basic_var bas;
  lineq lin;
};

#endif
