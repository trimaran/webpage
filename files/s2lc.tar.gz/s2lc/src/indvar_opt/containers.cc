/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: containers.cc:
//   
//   Author: Sam Larsen
//   Date: Mon Mar 26 13:14:51 2001
//
//   Function:  Containers for induction variables and memory addresses
//
//===========================================================================

#include "containers.h"

//---------------------------------------------------------------------------
basic_var::basic_var()
{
  ins = NULL;
}

//---------------------------------------------------------------------------
// Construct a new basic_var from this instruction.  The operand that is
// not the biv is needed for strength reduction.
//---------------------------------------------------------------------------
basic_var::basic_var(instruction* i)
{
  assert(i != NULL);
  ins = i;

  if_ops opcode = ins->opcode();
  assert(opcode == io_add || opcode == io_sub);

  operand dst = ins->dst_op();
  assert(dst.is_symbol());

  operand src0 = ins->src_op(0);
  operand src1 = ins->src_op(1);

  if (dst == src0)
  {
    if (opcode == io_sub) 
      src = operand(new in_rrr(io_neg, src1.type(), operand(), src1.clone()));
    else src = src1;
  }
  else if (dst == src1)
  {
    assert(opcode == io_add);
    src = src0;
  }
  else assert(0);
}

//---------------------------------------------------------------------------
//  Construct a new basic var directly from an operand
//---------------------------------------------------------------------------
basic_var::basic_var(operand oprnd)
{
  src = oprnd;
  ins = NULL;
}

//---------------------------------------------------------------------------
basic_var::basic_var(const basic_var& v)
{
  src = v.src;
}

//---------------------------------------------------------------------------
compl_var::compl_var()
{
  ins = NULL;
  sym = NULL;
}

//---------------------------------------------------------------------------
compl_var::compl_var(instruction* i, var_sym* s)
{
  ins = i;
  sym = s;
}

//---------------------------------------------------------------------------
compl_var::compl_var(const compl_var& c)
{
  ins = c.ins;
  sym = c.sym;
}

//---------------------------------------------------------------------------
sr_expr::sr_expr()
{}

//---------------------------------------------------------------------------
sr_expr::sr_expr(compl_var& c, basic_var& b, lineq& l)
{
  com = c;
  bas = b;
  lin = l;
}

//---------------------------------------------------------------------------
sr_expr::sr_expr(const sr_expr& s)
{
  com = s.com;
  bas = s.bas;
  lin = s.lin;
}
