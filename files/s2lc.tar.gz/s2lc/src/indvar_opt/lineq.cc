/* Copyright (c) 2006 Massachusetts Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */

//===========================================================================
//
//   FILE: lineq.cc:
//   
//   Author: Sam Larsen
//   Date: Thu Mar  8 13:29:42 2001
//
//   Function:  A linear equation of the form j=mul*biv+add is associated 
//		with each induction variable.  biv is a basic induction 
//		variable, 'mul' and 'add' are loop constants.
//
//===========================================================================

#include "lineq.h"

static operand new_mul(operand a, operand b)
{
  in_rrr* mul = new in_rrr(io_mul, a.type(), operand(), a.clone(), b.clone());
  return operand(mul);
}

static operand new_add(operand a, operand b)
{
  in_rrr* add = new in_rrr(io_add, a.type(), operand(), a.clone(), b.clone());
  return operand(add);
}

static operand new_sub(operand a, operand b)
{
  in_rrr* sub = new in_rrr(io_sub, a.type(), operand(), a.clone(), b.clone());
  return operand(sub);
}

static operand new_neg(operand a)
{
  in_rrr* neg = new in_rrr(io_neg, a.type(), operand(), a.clone(), operand());
  return operand(neg);
}

static operand new_con(int c, type_node* type)
{
  in_ldc* con = new in_ldc(type, operand(), immed(c));
  return operand(con);
}
  

lineq::lineq()
{
  biv = NULL;
}

lineq::lineq(var_sym* vs)
{
  assert(vs != NULL);
  biv = vs;
}


lineq::lineq(const lineq& le)
{
  biv = le.biv;
  mul = operand(le.mul).clone();
  add = operand(le.add).clone();
}


lineq operator*(operand oprnd, lineq& le)
{
  lineq nle(le.biv);

  if (!le.mul.is_null())
    nle.mul = new_mul(oprnd, le.mul);
  else 
    nle.mul = oprnd.clone();

  if (!le.add.is_null()) 
    nle.add = new_mul(oprnd, le.add);

  return nle;
}

lineq lineq::operator*(operand oprnd)
{
  lineq nle(biv);

  if (!mul.is_null())
    nle.mul = new_mul(mul, oprnd);
  else
    nle.mul = oprnd.clone();

  if (!add.is_null())
    nle.add = new_mul(add, oprnd);

  return nle;
}

lineq operator+(operand oprnd, lineq& le)
{
  lineq nle(le.biv);

  if (!le.mul.is_null())
    nle.mul = le.mul.clone();

  if (!le.add.is_null())
    nle.add = new_add(oprnd, le.add);
  else
    nle.add = oprnd.clone();

  return nle;
}

lineq lineq::operator+(operand oprnd)
{
  lineq nle(biv);

  if (!mul.is_null())
    nle.mul = mul.clone();

  if (!add.is_null())
    nle.add = new_add(add, oprnd);
  else
    nle.add = oprnd.clone();

  return nle;
}

lineq operator-(operand oprnd, lineq& le)
{
  lineq nle(le.biv);

  if (!le.mul.is_null())
    nle.mul = new_neg(le.mul);
  else
    nle.mul = new_con(-1, le.biv->type());

  if (!le.add.is_null())
    nle.add = new_sub(oprnd, le.add);
  else
    nle.add = oprnd.clone();

  return nle;
}

lineq lineq::operator-(operand oprnd)
{
  lineq nle(biv);

  if (!mul.is_null())
    nle.mul = mul.clone();

  if (!add.is_null())
    nle.add = new_sub(add, oprnd);
  else
    nle.add = new_neg(oprnd);

  return nle;
}

lineq lineq::operator-()
{
  lineq nle(biv);

  if (!mul.is_null())
    nle.mul = new_neg(mul);
  else
    nle.mul = new_con(-1, biv->type());

  if (!add.is_null())
    nle.add = new_neg(add);

  return nle;
}

var_sym* lineq::get_biv()
{
  assert(biv);
  return biv;
}

operand lineq::get_mul()
{
  if (!mul.is_null()) return mul.clone();
  return new_con(1, biv->type());
}

operand lineq::get_add()
{
  if (!add.is_null()) return add.clone();
  return new_con(0, biv->type());
}

bool lineq::has_mul()
{
  return !mul.is_null();
}

bool lineq::has_add()
{
  return !add.is_null();
}

bool lineq::is_null()
{
  return biv == NULL;
}
