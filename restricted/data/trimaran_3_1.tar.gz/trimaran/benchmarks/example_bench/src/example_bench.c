/* An example program used by the .../impact/tutorials/bench_info_tutorial
 * to demonstrate the new bench_info framework.
 * Author: John C. Gyllenhaal and Wen-mei Hwu  11/19/98
 */
#include <stdio.h>
#include "example_bench.h"

int main(int argc, char **argv)
{
    FILE *input;
    char *input_name;
    int outer_iter1, inner_iter1, inner_iter2, inner_iter3; 
    int outer1, inner1, inner2, inner3, i;
    int sum2;
    int ch;


    /* Print usage if don't have expected number of arguments */
    if (argc != 6)
    {
	fprintf (stderr, 
		 "Usage: example_bench input outer_iter1 inner_iter1 "
		 "inner_iter2 inner_iter3\n\n");
	fprintf (stderr,
                 "       Example program for "
		 ".../impact/tutorials/bench_info_tutorial\n"
		 "       Prints contents of 'input'\n"
		 "       Rest of 'iter' arguments must be integers.\n"
		 "       Set iteration count of various loops.\n");
        exit (1);
    }
	
    input_name = argv[1];
    outer_iter1 = convert_to_int (argv[2]);
    inner_iter1 = convert_to_int (argv[3]);
    inner_iter2 = convert_to_int (argv[4]);
    inner_iter3 = convert_to_int (argv[5]);

    printf ("Args: %s %i %i %i %i\n\n", input_name, outer_iter1, inner_iter1,
	    inner_iter2, inner_iter3);

    /* Print out contents of the file of "input_name" */
    if ((input = fopen (input_name, "r")) == NULL)
    {
	fprintf (stderr, "Error: could not open '%s'!\n", input_name);
	exit (1);
    }
    printf ("== Begin contents of '%s' ==\n", input_name);
    while ((ch = getc(input)) != EOF)
	putchar (ch);
    printf ("==  End contents of '%s'  ==\n\n", input_name);

    fclose (input);

    /* Initialize int array */
    for (i=0; i < 16; i++)
	int_array[i] = (1 << i) - 1;

    /* Initialize sums */
    sum1 = 0;
    sum2 = 0;
    sum3 = 0;

    /* Use parameter to control some random computation loops */
    for (outer1 = 1; outer1 <= outer_iter1; outer1++)
    {
	for (inner1 = 1; inner1 <= inner_iter1; inner1++)
	{
	    sum1 += inner1;
	}

	for (inner2 = 1; inner2 <= inner_iter2; inner2++)
	{
	    sum2 += do_sum2 (inner2);

            /* Keep from wrapping */
	    while (sum2 > 1000000000)
		sum2 -= 1000000000;
	}

	for (inner3 = 1; inner3 <= inner_iter3; inner3++)
	{
	    do_sum3 (inner3);
	}
    }

    /* Print out results, so everything is not deleted as dead code :)
     * and to provide something to check.
     */
    printf ("Results:\n");
    printf ("sum1 = %i\n", sum1);
    printf ("sum2 = %i\n", sum2);
    printf ("sum3 = %i\n", sum3);

    return (0);
}
