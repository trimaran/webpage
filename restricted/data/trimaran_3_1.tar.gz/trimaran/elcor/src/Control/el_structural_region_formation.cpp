/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1996 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           el_structural_region_formation.cpp
//      Author:         Matthai Philipose
//      Created:        August 23 1996
//      Description:    Given a procedure, decompose it into single-entry dags
//                      and if-convert all the dags
//                      
/////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include "control_analysis_solver.h"
#include "iterators.h"
#include "list.h"
#include "el_bb_tools.h"
#include "map.h"
#include "el_if_converter.h"
#include "el_control.h"
#include "edge_utilities.h"
#include "op.h"
#include "edge.h"
#include "el_opti.h"
#include "connect.h"
#include "opcode_properties.h"
#include "attributes.h"
#include "edge_attributes.h"
#include "el_normalize_branches.h"
#include "dbg.h"
#include "pred_analysis.h"
#include "el_structural_region_formation.h"
#include "el_bb_tools.h"
#include "el_loop.h"
#include "el_control_init.h"
#include "el_tail_duplication.h"
#include "el_loop_iterators.h"

void el_form_regions_structurally(Procedure *f)
{
  //start by if-converting the innermost loops
  el_if_convert_innermost_loops(f);
  
  //figure out the loops in f
  El_Loop_Graph loops(f);

  //deal with all the loops
  El_if_convert_all_loops(f,loops);

  //deal with everything on the top (procedure)-level scope
  //i.e. stuff outside all the loops
  El_if_convert_all_but_loops(f,loops);

  return;
}


void find_loop_bbs_not_in_any_loop(Procedure *f,
				   El_Loop_Graph& loops,
				   Hash_set<Basicblock*>& todo_bbs)
{
  
  //find every bb in the procedure
  for(Region_all_ops op_iter(f);op_iter!=0;op_iter++)
    {
      Op* op=*op_iter;
      Basicblock* bb=(Basicblock*)op->parent();
      assert(bb->is_bb());
      
      //epilogue bb doesn't go into any region
      if(!bb->flag(EL_REGION_HAS_EPILOGUE_OP))
	todo_bbs+=bb;
    }
  
  //remove all bbs that are in loops
  for(El_Loop_Graph_Post_DFS l_iter(loops);l_iter!=0;l_iter++)
    {
      El_Loop* loop=*l_iter;      
      todo_bbs-=loop->loop_blocks;
    }
  
  return;
}


void El_if_convert_all_but_loops(Procedure *f,El_Loop_Graph& loops)
{
   //all bbs in the current loop body eligible to go into
  //regions (all bbs except ones in nested sub-loops of
  //the current loop)... one per loop body
  Hash_set<Basicblock*> todo_bbs;

  //bbs going into the compound_region being formed
  //(may be many of these per loop body)
  Hash_set<Basicblock*> cr_bbs; 
  
  //all bbs that start off compound_regions in a loop body
  Hash_set<Basicblock*> seed_bbs;

  Dlist<Basicblock*> sorted_todo_bbs;//topo-sorted todo_bbs
  Hash_set<Edge*> entry_edges;


  //Loop through the loops starting at the innermost ones, moving
  //outwards, dividing each loop-body into single-entry regions
  //and if-converting these regions


  //prepare for lift-off!... I mean, initialize
  todo_bbs.clear();
  seed_bbs.clear();
  sorted_todo_bbs.clear();

      
  //only bbs in the current loop-body that are not in any
  //nested bb are eligible for going into regions
  find_loop_bbs_not_in_any_loop(f,loops,todo_bbs);
  
  //we want to traverse the bbs in topo order, since we're
  //trying to find bbs all of whose predecessors have been
  //processed (and placed into or out of the current region)
  Basicblock* procedure_entry_block=el_get_proc_entry_bb(f);  
  el_topo_sort_bbset(todo_bbs,sorted_todo_bbs,procedure_entry_block);
      
      
  //A seed is a bb in todo_bbs that has all entry edges coming from
  //outside todo_bbs
  seed_bbs+=procedure_entry_block;
  find_entry_bbs(todo_bbs,seed_bbs);


  //grow regions out of the existing seeds; a bb goes into the
  //region being formed if all its inedges are from within the 
  //region; a bb is a new seed if one its edges comes from the 
  //region being formed and the other from outside it
  while(!seed_bbs.is_empty())
    {
      Basicblock* seed_bb=seed_bbs.pop();
	  
      cr_bbs.clear();//initialize the set of bbs going into the new region
      cr_bbs+=seed_bb;
	  
      //iterate through the topo-sorted candidate bbs, starting at the seed_bb
      //seeing if the above criteria for membership in the region/seeds apply
      for(Dlist_iterator<Basicblock*> bb_iter(sorted_todo_bbs,seed_bb);bb_iter!=0;bb_iter++)
	{
	  Basicblock* cur_bb=*bb_iter;

	  if(cur_bb==seed_bb)//the seed's already in  cr_bbs
	    continue;

	  int num_in_set = num_predecessors_in_set(cr_bbs,cur_bb);
	  if(num_in_set==bb_num_inedges(cur_bb))	
	    //cur_bb is in the current region being formed
	    cr_bbs+=cur_bb;		
	  else if (num_in_set!=0)
	    //cur_bb is a future seed: it has at least one
	    //(but not all) edge from the current region being formed
	    seed_bbs+=cur_bb;
	}
	  
      //Remove all the bbs going into the current region
      //from the todo list
      for(Hash_set_iterator<Basicblock*> b_iter(cr_bbs);b_iter!=0;b_iter++)
	{
	  Basicblock* bb=*b_iter;
	  sorted_todo_bbs.remove(bb);
	}

      //form the compound_region comprising of the bbs identified in the cr_bbs 
      //set above
      entry_edges.clear();
      for(Region_entry_edges e_iter(seed_bb);e_iter!=0;e_iter++)
	{
	  Edge* edge = *e_iter;
	  entry_edges += edge;
	}
      Compound_region* cr=el_mark_cr_on_cfg(f,cr_bbs,entry_edges);

      //debug
      //cout << "RRRRR region found:\n";
	  
      for(Hash_set_iterator<Basicblock*> db_iter(cr_bbs);db_iter!=0;db_iter++)
	{
	  Basicblock* bb=*db_iter;
	  //cout << *bb;
	}
	  

      //If-convert the region you just marked on
      El_if_convert(cr, El_frp_model);
	  
      //nuke the region now it's not needed
      El_remove_region(cr, true);     
	  	  
    }
      
  //better have done the todo bbs!
  assert(sorted_todo_bbs.is_empty());    	
    

  return;
}

void El_if_convert_all_loops(Procedure *f,El_Loop_Graph& loops)
  {
   //all bbs in the current loop body eligible to go into
  //regions (all bbs except ones in nested sub-loops of
  //the current loop)... one per loop body
  Hash_set<Basicblock*> todo_bbs;

  //bbs going into the compound_region being formed
  //(may be many of these per loop body)
  Hash_set<Basicblock*> cr_bbs; 
  
  //all bbs that start off compound_regions in a loop body
  Hash_set<Basicblock*> seed_bbs;

  Dlist<Basicblock*> sorted_todo_bbs;//topo-sorted todo_bbs
  Hash_set<Edge*> entry_edges;


  //Loop through the loops starting at the innermost ones, moving
  //outwards, dividing each loop-body into single-entry regions
  //and if-converting these regions
  for(El_Loop_Graph_Post_DFS l_iter(loops);l_iter!=0;l_iter++)
    {
      El_Loop* loop=*l_iter;

      //we've already processed innermost loops
      bool is_innermost=false;
      for(El_Loop_Graph_Innermost lp_iter(loops); lp_iter != 0; lp_iter++)
	{
	  El_Loop* lp=*lp_iter;
	  if(lp==loop)
	    {
	      is_innermost=true;
	      break;
	    }
	}
      if(is_innermost)
	continue;


      //prepare for lift-off!... I mean, initialize
      todo_bbs.clear();
      seed_bbs.clear();
      sorted_todo_bbs.clear();
      
      //only bbs in the current loop-body that are not in any
      //nested bb are eligible for going into regions
      el_find_loop_bbs_not_in_nested_loops(loop,loops,todo_bbs);

      //we want to traverse the bbs in topo order, since we're
      //trying to find bbs all of whose predecessors have been
      //processed (and placed into or out of the current region)
      el_topo_sort_bbset(todo_bbs,sorted_todo_bbs,loop->header_block);

  
      //find the seeds for region formation
      //seeds for region formation are initially all bbs that have an external
      //incoming edge (the loop header is one too, since the backedge is external)
      seed_bbs+=loop->header_block;
      find_entry_bbs(todo_bbs,seed_bbs);


      //grow regions out of the existing seeds; a bb goes into the
      //region being formed if all its inedges are from within the 
      //region; a bb is a new seed if one its edges comes from the 
      //region being formed and the other from outside it
      while(!seed_bbs.is_empty())
	{
	  Basicblock* seed_bb=seed_bbs.pop();
	  
	  cr_bbs.clear();//initialize the set of bbs going into the new region
	  cr_bbs+=seed_bb;
	  
	  //iterate through the topo-sorted candidate bbs, starting at the seed_bb
	  //seeing if the above criteria for membership in the region/seeds apply
	  for(Dlist_iterator<Basicblock*> bb_iter(sorted_todo_bbs,seed_bb);bb_iter!=0;bb_iter++)
	    {
	      Basicblock* cur_bb=*bb_iter;

	      if(cur_bb==seed_bb)//the seed's already in  cr_bbs
		continue;

	      int num_in_set = num_predecessors_in_set(cr_bbs,cur_bb);
	      if(num_in_set==bb_num_inedges(cur_bb))	
		//cur_bb is in the current region being formed
		cr_bbs+=cur_bb;		
	      else if (num_in_set!=0)
		//cur_bb is a future seed: it has at least one
		//(but not all) edge from the current region being formed
		seed_bbs+=cur_bb;
	    }
	  
	  //Remove all the bbs going into the current region
	  //from the todo list
	  for(Hash_set_iterator<Basicblock*> b_iter(cr_bbs);b_iter!=0;b_iter++)
	    {
	      Basicblock* bb=*b_iter;
	      sorted_todo_bbs.remove(bb);
	    }

	  //form the compound_region comprising of the bbs identified in the cr_bbs 
	  //set above
	  entry_edges.clear();
	  for(Region_entry_edges e_iter(seed_bb);e_iter!=0;e_iter++)
	    {
	      Edge* edge = *e_iter;
	      entry_edges += edge;
	    }
	  Compound_region* cr=el_mark_cr_on_cfg(f,cr_bbs,entry_edges);

	  //debug
	  //cout << "RRRRR region found:\n";
	  
	  for(Hash_set_iterator<Basicblock*> db_iter(cr_bbs);db_iter!=0;db_iter++)
	    {
	      Basicblock* bb=*db_iter;
	      //cout << *bb;
	    }
	  

	  //If-convert the region you just marked on
	  El_if_convert(cr, El_frp_model);
	  
	  //nuke the region now it's not needed
	  El_remove_region(cr, true);     
	  	  
	}
      
      //better have done the todo bbs!
      assert(sorted_todo_bbs.is_empty());    	
    }
  return;
}


//bb is an entry_bb of bbs is one that has at least one predecessor 
//outside entry_bbs
void find_entry_bbs(Hash_set<Basicblock*>& bbs,Hash_set<Basicblock*>& output)
{
  for(Hash_set_iterator<Basicblock*> bb_iter(bbs);bb_iter!=0;bb_iter++)
    {
      Basicblock* bb=*bb_iter;
      bool is_entry=false;
      for(Region_entry_edges e_iter(bb);e_iter!=0;e_iter++)
	{
	  Edge* edge=*e_iter;
	  Basicblock* src_bb=(Basicblock*)edge->src()->parent();
	  
	  if(!bbs.is_member(src_bb))
	    {
	      is_entry=true;
	      break;
	    }
	}
      if(is_entry)
	output+=bb;
    }


  return;
}


int  num_predecessors_in_set(Hash_set<Basicblock*>& cr_bbs,Basicblock* cur_bb)
{
  int count=0;
  for(Region_entry_edges e_iter(cur_bb);e_iter!=0;e_iter++)
    {
      Edge* edge=*e_iter;
      
      if(cr_bbs.is_member((Basicblock*)edge->src()->parent()))
	count++;
    }
  return count;
}

int bb_num_inedges(Basicblock* cur_bb)
{
  int count=0;
  for(Region_entry_edges e_iter(cur_bb);e_iter!=0;e_iter++,count++)
    ;
  return count;
}


void el_topo_sort_bbset(Hash_set<Basicblock*>& bbs, Dlist<Basicblock*>& result,Basicblock* entry_bb)
{
  Hash_set<Basicblock*> visited_bbs;
  Dlist<Basicblock*> ni_bbs; //No-Inedge bbs
  
  //the entry_bb is always in
  ni_bbs.push(entry_bb); 
  //find all bbs in bbs all of whose inedges come from outside
  //bbs 
  for(Hash_set_iterator<Basicblock*>  h_iter(bbs);h_iter!=0;h_iter++)
    {
      bool is_ni=true;
      Basicblock* bb=*h_iter;
      if(bb==entry_bb)
	continue;//we've already put in the entry_bb

      for(Region_entry_edges e_edge(bb);e_edge!=0;e_edge++)
	{
	  Edge* edge=*e_edge;
	  if(bbs.is_member((Basicblock*)edge->src()->parent()))
	    {
	      is_ni=false;
	      break;
	    }
	}
      if(is_ni)
	ni_bbs.push(bb);            
    }
  
  //loop till no more no-inedge nodes are left
  while(!ni_bbs.is_empty())
    {
      Basicblock* bb=ni_bbs.pop();
      result.push_tail(bb);
      visited_bbs+=bb;

      //check if each successor of bb can be added to ni_bbs
      for(Region_exit_edges e_edge(bb);e_edge!=0;e_edge++)
	{
	  Edge* edge=*e_edge;
	 
	  Basicblock* succ=(Basicblock*)edge->dest()->parent();
	  if((!bbs.is_member(succ))||
	     (entry_bb==succ))//we're not interested in blocks outside
	    continue;             //the set being sorted
	  
	  bool all_preds_visited=true;
	  //check if every predecessor of succ is already visited
	  for(Region_entry_edges e_edge(succ);e_edge!=0;e_edge++)
	    {
	      Edge* edge=*e_edge;
	      Basicblock* pred=(Basicblock*)edge->src()->parent();
	      
	      //a predecessor that is in bbs _and_ not yet
	      //visited means that succ is no longer ready
	      //to be inducted into the topo order
	      if((!visited_bbs.is_member(pred))&&
		 (bbs.is_member(pred)))
		{
		  all_preds_visited=false;
		  break;
		}
	    }
	  if(all_preds_visited)ni_bbs.push_tail(succ);
	}
    }
  
  return;
}

