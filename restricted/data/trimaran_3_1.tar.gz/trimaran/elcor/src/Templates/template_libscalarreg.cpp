/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           RegAllocTemplate.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include <typeinfo>

#include "pred_interface.h"

#include "dlist.h"
#include "dlist.cpp"
#include "hash_map.h"
#include "hash_map.cpp"
#include "hash_set.h"
#include "hash_set.cpp"
#include "hash_table.h"
#include "hash_table.cpp"
#include "list.h"
#include "list.cpp"
#include "list_set.h"
#include "list_set.cpp"
#include "map.h"
#include "map.cpp"
#include "msort.h"
#include "msort.cpp"
#include <slist.h>
#include <slist.cpp>
#include "tuples.h"
#include "tuples.cpp"
#include "vector.h"
#include "vector.cpp"

#include <iterators.h>
#include <operand.h>
#include <operand_concat.h>
#include <operand_concat.cpp>
#include "ref.h"
#include "region.h"
#include "rr_life.h"
#include "mdes.h"
#include "ReconcileCode.h"
#include "RegisterBank.h"
#include "LiveRange.h"

class Compound_region;
class LiveRange;
class Op;
class RegAllocSolverData;

template class List_set< void* >;
template class List_set_iterator< void* >;
template class List_set< Operand >;
template class List_set_iterator< Operand >;
template class List_set< Basicblock* >;
template class List_set_iterator< Basicblock* >;
template class List_set< Hyperblock* >;
template class List_set_iterator< Hyperblock* >;
template class List_set< Compound_region *>;
template class List_set_iterator<Compound_region *>;
template class List_set< LoopBody* >;
template class List_set_iterator< LoopBody* >;
template class List_set< Region *>;
template class List_set_iterator<Region *>;
template class List_set< RR_ref_data *>;
template class List_set_iterator< RR_ref_data *>;
template class List_set< RR_ref_data >;
template class List_set_iterator< RR_ref_data >;
template class List_set<LiveSubRegion *>;
template class List_set_iterator< LiveSubRegion* >;
template class List_set<LiveBlock *>;
template class List_set_iterator< LiveBlock* >;

template class List_set< Quad<Op *, Port_type, int, Operand> >;
template class List_set_iterator< Quad<Op *, Port_type, int, Operand> >;
template class List_set<Hash_set<Edge *> >;
template class List_set< Hash_set< int > >;
template class List_set_iterator<Hash_set<Edge *> >;
template class List_set<Pair<Basicblock *, Basicblock *> *>;
template class List_set_iterator<Pair<Basicblock *, Basicblock *> *>;


template class  Dlist<Compound_region *>;
template class  Dlist<El_ref>;
template class  Dlist<LiveRange *>;
template class  Dlist<RegAllocSolverData *>;
template class  Dlist_iterator<RegAllocSolverData *>;
template class  Dlist_iterator<El_ref>;
template class  Dlist_iterator<Compound_region *>;
template class  Dlist_iterator<LiveRange *>;


template class Hash_table<Pred_cookie>;
template class Hash_table_iterator<LiveRange *>;
template class Hash_table_iterator<Op const *>;


template class List<LiveRange *>;
template class List<LiveUnit*>;
template class List_iterator<LiveUnit *>;
template class List<LiveBlock*>;
template class List_iterator<LiveBlock *>;
template class List<LiveSubRegion*>;
template class List_iterator<LiveSubRegion *>;
template class List<Compound_region*>;
template class List_iterator<Compound_region *>;
template class List< LiveRangePair >;
template class List_iterator < LiveRangePair >;
template class List<ReconcileCodeData>;


template class List_iterator<LiveRange *>;
template class List_iterator<Pred_cookie>;
template class List_iterator<ReconcileCodeData>;


template class List_set<int>;
template class List_set_iterator<int>;
template class List_set<Edge *>;
template class List_set_iterator<Edge *>;
template class List_set<LiveRange *>;
template class List_set_iterator<LiveRange *>;
template class List_set<Op const *>;
template class List_set_iterator<Op const *>;
template class List_set<Pred_cookie>;
//template class List_set<const Op*>;
//template class List_set_iterator<const Op*>;


template class Map<int, double>;
template class Map<int, List<LiveRange *> >; 
template class Map<Edge*, LiveRange*>;
template class Map<Edge*, List<Op*> >;
template class Map_iterator<Edge*, List<Op*> >;
template class Map_iterator<Operand, Pred_cookie>;
template class Map< Edge *, List< ReconcileCodeData > >;
template class Map_iterator< Edge *, List<ReconcileCodeData> >;
template class Map< Edge *, List< ReconcileCodeData >* >;
template class Map<Op *, double>;
template class Map<Op *, Pred_cookie *>;
template class Map<Operand, LiveBlock *>;
template class Map<Operand, LiveRange *>;
template class Map<Operand, LiveUnit *>;
template class Map<Operand, Pred_cookie>;
template class Map<Operand, List<LiveRange *> >;
template class Map<Region*, int>;


template class Map_iterator<int, double>;
template class Map_iterator<int, List<LiveRange *> >; 
template class Map_iterator< Edge *, List<ReconcileCodeData>* >;
template class Map_iterator< Edge *, LiveRange* >;
template class Map_iterator<Op *, double>;
template class Map_iterator< Region*, int >;


template class Hash_map<Edge*, List<Op*> >;
template class Hash_map_iterator<Edge*, List<Op*> >;


template class  Vector< List_set<int> >;
template class  Vector< List<LiveRange *> >;
template class  Vector< List<Pred_cookie> >;
template class  Vector< List<Op const *> >;
template class  Vector< RegisterBank >;

template class  Pair<Op*, Op*>;
template class  Triple<Op*, Op*, LiveRange*>;
template class  Triple<Pair<Edge *, int> *, LiveRange *, LiveRange *>;
template class  List<Triple<Op*, Op*, LiveRange*> >;
template class  List_iterator<Triple<Op*, Op*, LiveRange*> >;


template class Operand_2_iter<Op_taken_liveout_sources, Op_fallthrough_liveout_sources>;


template ostream& operator<<(ostream &, List_set<int> const &);
template ostream& operator<<(ostream &, List_set<Reg_descr *> const &);
template ostream& operator<<(ostream &, List_set<Op_descr *> const &);
template ostream& operator<<(ostream &, List_set<Io_descr *> const &);

