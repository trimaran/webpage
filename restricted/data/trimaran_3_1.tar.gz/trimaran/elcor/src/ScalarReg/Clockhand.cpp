/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           Clockhand.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include "Clockhand.h"
#include "LiveRange.h"

#include <region.h>
#include <iterators.h>


Map<Region*, int> _caller_clockhand;
Map<Region*, int> _callee_clockhand;

void	set_clockhand(Region* _region) {
    int max_caller_hand = 0;
    int max_callee_hand = 0;
    int caller_hand = 0;
    int callee_hand = 0;

    for (Region_control_flow_pred iter(_region); iter!=0; iter++) {
	Region* r = (Region*)(*iter);
	if (_caller_clockhand.is_bound(r)) {
	    caller_hand  = _caller_clockhand.value(r);
	    max_caller_hand = max(max_caller_hand, caller_hand);
	}
	if (_callee_clockhand.is_bound(r)) {
	    callee_hand  = _callee_clockhand.value(r);
	    max_callee_hand = max(max_callee_hand, callee_hand);
	}
    }

    for (Region_control_flow_succ iter2(_region); iter2!=0; iter2++) {
	Region* r = (Region*)(*iter2);

	if (_caller_clockhand.is_bound(r)) {
	    caller_hand  = _caller_clockhand.value(r);
	    max_caller_hand = max(max_caller_hand, caller_hand);
	}
	if (_callee_clockhand.is_bound(r)) {
	    callee_hand  = _callee_clockhand.value(r);
	    max_callee_hand = max(max_callee_hand, callee_hand);
	}
    }

    _callee_clockhand.bind(_region, max_callee_hand);
    _caller_clockhand.bind(_region, max_caller_hand);
}


int	
get_clockhand(Region* _region, 
	      LiveRange::CallerCalleeType& _call_type){
    if (_call_type == LiveRange::CALLER_SAVED) {
	return _caller_clockhand.value(_region);
    }
    else {
	return _callee_clockhand.value(_region);
    }
}


void	
update_clockhand(Region* _region, 
		 LiveRange::CallerCalleeType& _call_type,
		 int reg) {

    if (_call_type == LiveRange::CALLER_SAVED) {
	_caller_clockhand.bind(_region, reg);
    }
    else {
	_callee_clockhand.bind(_region, reg);
    }
    
}



int get_caller_clockhand(Region* _region) {
    return _caller_clockhand.value(_region);
}


int get_callee_clockhand(Region* _region) {
    return _callee_clockhand.value(_region);
}




void    increase_caller_clockhand(Region* _region) {
    int hand = get_caller_clockhand(_region);
    hand++;
    _caller_clockhand.bind(_region, hand);
}


void    increase_callee_clockhand(Region* _region) {
    int hand = get_callee_clockhand(_region);
    hand++;
    _callee_clockhand.bind(_region, hand);
}

