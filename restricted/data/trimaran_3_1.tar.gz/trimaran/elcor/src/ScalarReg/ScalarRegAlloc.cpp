/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           ScalarRegAlloc.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include "ScalarRegAlloc.h"
#include "LiveRange.h"
#include "LiveRangeConstruction.h"
#include "ReconcileCode.h"
#include "RegisterBank.h"
#include "RegAllocSolver.h"
#include "SpillCodeUtils.h"
#include "SpillStack.h"

#include <dbg.h>
#include <ir_writer.h>
#include <regtochar.h>
#include <opcode_load_store.h>
#include <connect.h>
#include <edge.h>
#include <edge_utilities.h>
#include <el_control.h>
#include <intf.h>
#include <iterators.h>
#include <mdes.h>
#include <opcode.h>
#include <operand.h>
#include <pred_analysis.h>
#include <reaching_defs_solver.h>
#include <region.h>
#include <slist.h>
#include <tuples.h>
#include <el_sreg_init.h>
#include <bit_vector.h>

/*************************************************************************
 * static data and functions
 *************************************************************************/

static void 	initialize(Procedure* proc_);

static void 	region_reg_alloc(Compound_region* r);  
static void	reg_reconcile(const List_set<LiveRange*>& lr_list);
static void	propagate_binding (LiveRange* lr_);
static void	resolve_delayed_lr(const LiveRange* bound_lr_, LiveRange* target_lr_);
static void 	bind_lrs(const LiveRange* l, LiveRange* llr);
static void update_adj_lrs(List<LiveRange*>& lrs_, const GlobalBoundMap& b_map);
SpillStack ScalarRegAlloc::_spill_stack;

ScalarRegAlloc::ScalarRegAlloc(Procedure* proc_) {


    initialize(proc_);

    El_do_reaching_defs(proc_);
    el_flow_delete_liveness(proc_);
    delete_local_analysis_info_for_all_hbs_bbs(proc_);
    create_local_analysis_info_for_all_hbs_bbs(proc_);
    el_flow_compute_liveness(proc_);

    region_reg_alloc(proc_);

    generate_spill_code(proc_);
    proc_->set_flag(EL_PROC_REGISTER_ALLOCATED);
}


// Identify _epilogue_region and _prologue_region for callee saved
// register spilling
void
ScalarRegAlloc::initialize(Procedure* proc_) {
    
    // find prologue and epilogue region
    for (Region_subregions iter(proc_); iter != 0; iter++) {
	// save prologue region and epilogue region
	Region* sub_region = (*iter);
	if (sub_region->flag(EL_REGION_HAS_PROLOGUE_OP))
	    _prologue_region = (Compound_region*)sub_region;
	else if (sub_region->flag(EL_REGION_HAS_EPILOGUE_OP))
	    _epilogue_region = (Compound_region*)sub_region;
    }

    _spill_stack.clear();
    _spill_stack.set_stack_locs(proc_);

    GlobalBoundMap::instance.clear();
    RegisterBankPool::instance().clear_reg_use_count();
    ReconcileCodeSet::clear();


}


// a region is base if unit of reg alloc/reconcile 
int
ScalarRegAlloc::is_base_region(Region* r) { 
    if (strcmp(El_core_allocator_region, "proc") == 0) {
	return (r->is_procedure());
    }
    else {
	// this verion supports global RA only
	assert(0);
    }
    return true;
}


void
ScalarRegAlloc::region_reg_alloc(Compound_region* r) { 

    if (!r) {
	El_punt("Null region passed to reg alloc!\n");
	return;
    }

    if (!is_base_region(r)) {
	// Sort the region by weight and keep the separate list
	// Original list may be added with SPILL block and we do not 
	// want to process with SPILL block again. -- Hansoo Kim

	List<Compound_region*> sorted_region_list; 

	// region frequency order
	if (EL_use_frequency) {
	    for (Region_subregions_freq subregs_by_freq(r); 
		 subregs_by_freq!=0; subregs_by_freq++) {
		sorted_region_list.add_tail((Compound_region*)*subregs_by_freq);
	    }
 	}
	else {	
	    for (Region_subregions subregs(r); subregs!=0; subregs++) {
		sorted_region_list.add_tail((Compound_region*)*subregs);
	    }
	}

	for(List_iterator<Compound_region*> iter(sorted_region_list); 
	    iter != 0; iter++) {
            region_reg_alloc(*iter);
        }
    }
    else {
	core_reg_alloc(r);
    }
}


// Give a compound_region R where R is the base of Register allocation 
//
void
ScalarRegAlloc::core_reg_alloc(Compound_region* r) {
    if (dbg(status, 1)) {
	cout << "(Reg Alloc)";
	if (r->is_bb())
	    cout << "bb: ";
	else if (r->is_hb())
	    cout << "hb: ";
	else if (r->is_loop())
	    cout << "loop: ";
	else if (r->is_procedure())
	    cout << "proc: ";
	else
	    cout << "region: ";
	cout << r->id() << endl << flush;
    }

    List<LiveRange*> lrs = construct_live_ranges(r);
    // update_adj_lrs(lrs, a_gb_map);

    // create local VR_map and PQS info
    // delete_local_analysis_info_for_all_hbs_bbs(r);
    // create_local_analysis_info_for_all_hbs_bbs(r);


    
    {
	// PR should be processed first;
	Reg_file i = PR;
	char* file_name = regfile_to_char((Reg_file)i);
	RegAllocSolver* reg_solver = new RegAllocSolver(file_name);

	for (List_iterator<LiveRange*> m_iter(lrs); m_iter != 0; m_iter++) {
	    LiveRange* a_lr = (*m_iter);
	    //if ( a_lr->variable().physical_file_type() == file_name) {
	    if ( a_lr->variable().file_type() == (Reg_file)i) {
		reg_solver->add_liverange(a_lr);
	    }
	}

	reg_solver->process_coloring();

	// set of liveranges of a particular register file
	const List<LiveRange*>& lrs = reg_solver->live_ranges();
	region_reconcile(lrs);
    }

    for (int i = FIRST_FILE; i < NUM_REG_FILE; i++) {
	if ((Reg_file)i == PR)
	    continue;

	char* file_name = regfile_to_char((Reg_file)i);
	RegAllocSolver* reg_solver = new RegAllocSolver(file_name);

	for (List_iterator<LiveRange*> m_iter(lrs); m_iter != 0; m_iter++) {
	    LiveRange* a_lr = (*m_iter);
	    //if ( a_lr->variable().physical_file_type() == file_name) {
	    if ( a_lr->variable().file_type() == (Reg_file)i) {
		reg_solver->add_liverange(a_lr);
	    }
	}

	reg_solver->process_coloring();

	// set of liveranges of a particular register file
	const List<LiveRange*>& lrs = reg_solver->live_ranges();
	region_reconcile(lrs);

    }
}


// add non-A bindings (from region just allocated) to global bindings 
// also, propagate this to delayed-binding
void
ScalarRegAlloc::region_reconcile(const List<LiveRange*>& lr_list) {

    for (List_iterator<LiveRange*> li(lr_list); li!=0; li++) { 

        LiveRange* lr = *li;

	if (lr->reg_bind_state() == LiveRange::DELAYED) {
	    lr->coloring_pass_through();
	}

	if (lr->reg_bind_state() != LiveRange::DELAYED) {
	    lr->reconcile();
	}
    }
}



// update adj_lrs list of LR in global_LR_list and initialize a new LR
// base on the LR's in global_LR_list.
// global_LR_list info is used not only for reconcile, but also for the
// register selection of a new LR. Given a new LR, new_lr1, its adjacent
// LR list is initialize with LR's in its neighbor region which is core
// allocated already (whether it is colored or delayed).
//
// update_adj_lrs() is called when
//   1. a new LR is constructed
//   2. a LR is splitted to 2 new LR's
//  NEEDS to remove old information, when you split. 
//  (??? get adj_lr info dynamically)
void
update_adj_lrs(List<LiveRange*>& lrs_, const GlobalBoundMap& b_map) {

    for (List_iterator<LiveRange*> iter(lrs_); iter!=0; iter++) {
	LiveRange* lr = *iter;
	lr->add_adj_lrs(b_map);
    }
}



// Once a region passthrus are resolved, postprocessing 
// adds the code on edges
void 
ScalarRegAlloc::generate_spill_code(Procedure* r) {

    //
    // Now iterate thru all the edges with patchup code and 
    // create BBs

    ReconcileCodeSet::generate_reconcile_code();



    // find all used CALLEE saved register and add spill code 
    // in EPILOGUE and PROLOGUE
    int base = 0;
    int i;
    Operand pred_operand(new Pred_lit(true));
    Operand temp_operand( new Macro_reg(SPILL_TEMPREG) );

    for (i = FIRST_FILE; i < NUM_REG_FILE; i++) {
	char* file_name = regfile_to_char((Reg_file)i);
	RegisterBank& a_bank = RegisterBankPool::reg_bank((Reg_file)i);
	// List_set<int>& reg_set = RegisterBank::_reg_bank_pool[i]._used_callee;

	Data_type d_type;
	Reg_file f_type;
	if (i == GPR) {
	    d_type = EL_DT_INT;
	    f_type = GPR;
	}
	else if (i == FPR) {
	    d_type = EL_DT_DOUBLE;
	    f_type = FPR;
	}
	else if (i == PR) {
	    d_type = EL_DT_PREDICATE;
	    f_type = PR;
	    
	    generate_PR_spill_code(a_bank, base);
	    base += a_bank._stack_size;
	    continue;
	}
	else if (i == BTR) {
	    d_type = EL_DT_BRANCH;
	    f_type = BTR;
	}
	else if (i == CR) {
	    d_type = EL_DT_POINTER;
	    f_type = CR;
	}
	else {
	    d_type = EL_DT_VOID;
	    f_type = NUM_REG_FILE;
	}

	for (int reg_i = a_bank._macro_size +a_bank._caller_size ; reg_i < a_bank._reg_use_count.dim(); reg_i++) {
	    int pos = 0;
	    if (a_bank._reg_use_count[reg_i] == 0)
		continue;
	    else
		pos = reg_i;

	    int stack_loc = _spill_stack._var_spill_size + base + a_bank.bit_width()*pos/8;

	    Operand sp_operand(new Macro_reg(SP_REG));
	    Operand loc_operand(new Int_lit(stack_loc));
	    Operand reg_operand( new Reg(d_type) );
	    reg_operand.bind_reg(reg_i);

	    Op* st_pos_op = new Op( (Opcode)ADD_W);
	    st_pos_op->set_dest(DEST1, temp_operand);
	    st_pos_op->set_src(SRC1, sp_operand);
	    st_pos_op->set_src(SRC2, loc_operand);
	    st_pos_op->set_src(PRED1, pred_operand);
	    st_pos_op->set_flag(EL_OPER_SPILL_CODE);

	    Op* store_op = NULL;
	    switch (f_type) {
	    case GPR:
	    case PR:
	    case BTR:
	    case CR:
		store_op = new Op( (Opcode)S_W_C1 );
		break;
	    case FPR:
		store_op = new Op( (Opcode)FS_D_C1 );
		break;
	    default:
		assert(0);
	    }

	    store_op->set_src(SRC1, temp_operand);
	    store_op->set_src(SRC2, reg_operand);
	    store_op->set_src(PRED1, pred_operand);
	    store_op->set_flag(EL_OPER_SPILL_CODE);

	    //El_insert_op_before_switch(_prologue_region, st_pos_op);
	    //El_insert_op_before_switch(_prologue_region, store_op);
	    El_insert_op_after_merge(_prologue_region, store_op);
	    El_insert_op_after_merge(_prologue_region, st_pos_op);

	    Op* load_op = NULL;
	    switch (f_type) {
	    case GPR:
	    case PR:
	    case BTR:
	    case CR:
		load_op = new Op( (Opcode) L_W_C1_C1);// datatype?
		break;
	    case FPR:
		load_op = new Op( (Opcode) FL_D_C1_C1);// datatype?
		break;
	    default:
		assert(0);
	    }
	    load_op->set_dest(DEST1, reg_operand);
	    load_op->set_src(SRC1, temp_operand);
	    load_op->set_src(PRED1, pred_operand);
	    load_op->set_flag(EL_OPER_SPILL_CODE);

	    Op* ld_pos_op = new Op( (Opcode)ADD_W);
	    ld_pos_op->set_dest(DEST1, temp_operand);
	    ld_pos_op->set_src(SRC1, sp_operand);
	    ld_pos_op->set_src(SRC2, loc_operand);
	    ld_pos_op->set_src(PRED1, pred_operand);
	    ld_pos_op->set_flag(EL_OPER_SPILL_CODE);

	    //El_insert_op_after_merge(_epilogue_region, ld_pos_op);
	    //El_insert_op_after_merge(_epilogue_region, load_op);
	    El_insert_op_before_switch(_epilogue_region, ld_pos_op);
	    El_insert_op_before_switch(_epilogue_region, load_op);
	}
	
	base += a_bank._stack_size;
    }

    // define SWAP with register spill area size
    // Hansoo Kim
    Op* define_op = new Op((Opcode)DEFINE);
    Operand sp_operand(new Macro_reg(SWAP));
    define_op->set_dest(DEST1, sp_operand);
    Operand loc_operand(new Int_lit(_spill_stack._var_spill_size+ base));
    define_op->set_src(SRC1, loc_operand);
    Region_entry_ops op_iter(r);
    Op* first_op = *op_iter;
    El_insert_op_after(first_op->parent(), define_op, first_op);

}

void
ScalarRegAlloc::generate_PR_spill_code(RegisterBank& PR_reg_bank_,
				       int base_) 
{
    int reg_size = PR_reg_bank_._size;
    int CR_width = 32; // hard coded, fix it later

    Bitvector callee_vector(reg_size);
    for (int i = 0; i < PR_reg_bank_._reg_use_count.dim(); i++) {
	if (PR_reg_bank_._reg_use_count[i] > 0) {
	    callee_vector.set_bit(i);
	}
    }

    for (int index = 0; index < reg_size/CR_width; index++) {
	//int mask = 0xF << index*CR_width;
	//Bitvector mask_vec(reg_size);
	//mask_vec.set_from_mask(mask);
	//cout << mask_vec << flush;

	int counter = 0;
	for (int cb = index*CR_width; cb < (index+1)*CR_width; cb++) {
	    if (callee_vector.bit(cb) == true ) {
		counter++;
	    }
	}

	//if ( (mask_vec *= callee_vector).ones_count() > 0 ) {
	if (counter > 0) {

	    Macro_name PV_i = RegisterBank::PV_num(index);
	    Operand pr_operand(new Macro_reg(PV_i));

	    int stack_loc = _spill_stack._var_spill_size + base_;

	    // generate code
	    Op* st_pos_op = new Op( (Opcode)ADD_W);

	    Operand temp_operand( new Macro_reg(SPILL_TEMPREG) );
	    Operand sp_operand(new Macro_reg(SP_REG));
	    Operand loc_operand(new Int_lit(stack_loc));
	    Operand pred_operand(new Pred_lit(true));

	    st_pos_op->set_dest(DEST1, temp_operand);
	    st_pos_op->set_src(SRC1, sp_operand);
	    st_pos_op->set_src(SRC2, loc_operand);
	    st_pos_op->set_src(PRED1, pred_operand);
	    st_pos_op->set_flag(EL_OPER_SPILL_CODE);

	    Op* store_op = new Op( (Opcode)SAVE) ;
	    store_op->set_src(SRC1, temp_operand);
	    store_op->set_src(SRC2, pr_operand);
	    store_op->set_src(PRED1, pred_operand);
	    store_op->set_flag(EL_OPER_SPILL_CODE);

	    //El_insert_op_before_switch(_prologue_region, st_pos_op);
	    //El_insert_op_before_switch(_prologue_region, store_op);
	    El_insert_op_after_merge(_prologue_region, store_op);
	    El_insert_op_after_merge(_prologue_region, st_pos_op);
		
	    Op* load_op = new Op( (Opcode) RESTORE );
	    load_op->set_dest(DEST1, pr_operand);
	    load_op->set_src(SRC1, temp_operand);
	    load_op->set_src(PRED1, pred_operand);
	    load_op->set_flag(EL_OPER_SPILL_CODE);

	    Op* ld_pos_op = new Op( (Opcode)ADD_W);
	    ld_pos_op->set_dest(DEST1, temp_operand);
	    ld_pos_op->set_src(SRC1, sp_operand);
	    ld_pos_op->set_src(SRC2, loc_operand);
	    ld_pos_op->set_src(PRED1, pred_operand);
	    ld_pos_op->set_flag(EL_OPER_SPILL_CODE);

	    //El_insert_op_after_merge(_epilogue_region, load_op);
	    //El_insert_op_after_merge(_epilogue_region, ld_pos_op);
	    El_insert_op_before_switch(_epilogue_region, ld_pos_op);
	    El_insert_op_before_switch(_epilogue_region, load_op);

	    base_ += (CR_width/8);

	}
    }
}


