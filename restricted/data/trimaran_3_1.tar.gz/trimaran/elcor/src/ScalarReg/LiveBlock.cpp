/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           LiveBlock.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include <bit_vector.h>
#include <attributes.h>
#include <el_sreg_init.h>
#include <flow_analysis_solver.h>
#include <intf.h>
#include <iterators.h>
#include <math.h>
#include <opcode_properties.h>
#include <dbg.h>

#include "GlobalBoundMap.h"
#include "LiveBlock.h"
#include "LiveSubRegion.h"
#include "ReconcileCode.h"
#include "RegisterBank.h"
#include "SpillCodeUtils.h"


LiveBlock::LiveBlock() {

}

LiveBlock::LiveBlock(Compound_region* region, Operand& var) {
    _region = region;
    _var = var;
    _spill_cost = 0;
    _caller_benefit = 0;
    _callee_benefit = 0;
}


bool
LiveBlock::has_single_ref()const {
    if (EL_op_based_liverange) {
	int c = ref_op_count();
	if (c > 1)
	    return false;
	else
	    return true;
    }
    else {
	return true;
    }
}

bool
LiveBlock::has_single_block()const {
    return true;
}

bool
LiveBlock::is_pass_through()const {
    if (_live_refs.size() > 0) 
	return false;
    else
	return true;
}


// check the number of operation in reference.
// But the mutiple references in a single operation is counted
// as a single unit.
int
LiveBlock::ref_op_count()const {
    List_set<Op*> ref_ops;
    for (List_iterator<El_ref> iter(_live_refs); iter!=0; iter++) {
	El_ref ref = *iter;
	ref_ops += ref.get_op();
    }
    return ref_ops.size();
}


int
LiveBlock::live_ops_count()const {
    return _live_ops.size();
}


void
LiveBlock::add_live_op(Op* op_, Pred_cookie& pred_) {
    Node<Op*>* op_ptr = _live_ops.find(op_);
    if (op_ptr == NULL) {
	_live_ops.add_tail( op_ );
	Pred_cookie* pos = _pred_pool.find_and_add((Pred_cookie&)pred_);
	_pred_map.bind(op_, pos);
    }
    else {
	// rebind operation with new Pred_cookie
	Pred_cookie* pos = _pred_pool.find_and_add((Pred_cookie&)pred_);
	_pred_map.bind(op_, pos);
    }
}

void
LiveBlock::set_entry_edges() {
    Op* first_op = _live_ops.tail();
    // this is first operation of this live-range, since live-range
    // is constructed backward.

    List<Edge*> op_entry_edges = ((Region*)_region)->inedges();
    for (List_iterator<Edge*> iter(op_entry_edges);
	 iter != 0; iter++) {
	Edge* edge = *iter;
	Liveness_info* liveness = get_liveness_info(edge);
	if (liveness) {
	    for (Liveness_info_iterator li(*liveness); li != 0; li++) {
		Operand& var=*li;
		if (var==_var) {
		    _entry_edges.add_tail(edge);
		    break;
		}
	    }
	}
    }

}

void
LiveBlock::set_exit_edges() {
    Op* last_op = _live_ops.head();
    // this is first operation of this live-range, since live-range
    // is constructed backward.

    List<Edge*> op_exit_edges = ((Region*)_region)->outedges();
    for (List_iterator<Edge*> iter(op_exit_edges);
	 iter != 0; iter++) {
	Edge* edge = *iter;
	Liveness_info* liveness = get_liveness_info(edge);
	if (liveness) {
	    for (Liveness_info_iterator li(*liveness); li != 0; li++) {
		Operand& var=*li;
		if (var==_var) {
		    _exit_edges.add_tail(edge);
		    break;
		}
	    }
	}
    }

}

bool
LiveBlock::is_in_interference_set(LiveUnit* a_lr) {
    return a_lr->is_in_interference_set(this);
}

bool
LiveBlock::is_in_interference_set(LiveBlock* a_lr) {
    return _inf_lus.is_member(a_lr);
}

bool
LiveBlock::init_interference_recursively(LiveUnit* a_lr) {
    return a_lr->init_interference_recursively(this);
}

bool
LiveBlock::init_interference_recursively(LiveBlock* a_lr) {
    bool is_interfered = false;
    if (EL_op_based_liverange) {
	is_interfered = check_interfere(a_lr);
    }
    else {
	is_interfered = true;
    }

    if (is_interfered) {
	_inf_lus.add_tail(a_lr);
	a_lr->_inf_lus.add_tail(this);
    }
    return is_interfered;
}


/*
void 
LiveBlock::update_interfered_set(LiveUnit* a_lr) {
    a_lr->update_interfered_set(this);
}
*/

void
LiveBlock::set_interference(LiveBlock* a_lr) {
    if (check_interfere(a_lr)) {
	_inf_lus.add_tail(a_lr);
	a_lr->_inf_lus.add_tail(this);
    }
}

void
LiveBlock::upscale_interference() {
    assert(_parent);
    for (List_iterator<LiveBlock*> i2(_inf_lus); i2!=0; i2++) {
	LiveBlock* inf_su = *i2;
	LiveSubRegion* inf_parent = inf_su->_parent;
	_parent->add_interference(inf_parent);
    }

}


bool
LiveBlock::check_interfere(LiveBlock* a_lr) {

    bool is_interfered = false;

    if (_var.physical_file_type() != a_lr->_var.physical_file_type()) {
	is_interfered = false;
	return false;
    }

    {
	Op* first_op = _live_ops.tail();

	if (a_lr->_live_ops.is_member(first_op) == true) {

	    if (EL_do_pred_analysis) {
		// not supported in release version
		assert(0);
	    }
	    else {
		return true;
	    }
	}
    }

    {
	Op* first_op = a_lr->_live_ops.tail();

	if (_live_ops.is_member(first_op) == true) {

	    if (EL_do_pred_analysis) {
		Pred_cookie* pred1 = _pred_map.value(first_op);
		Pred_cookie* pred2 = a_lr->_pred_map.value(first_op);

		if ( !pred1->is_disjoint(*pred2) ) {
		    return true;
		}
	    }
	    else {
		return true;
	    }
	}
    }

    /*
    if (_live_refs.size() == 0) {
	// this is pass-through
	// will interfere anyway
	return true;
    }
    else if (a_lr->_live_refs.size() == 0) {
	// this is pass-through
	// will interfere anyway
	return true;
    }
    */

    {
	for (List_iterator<El_ref> iter1(_live_refs); iter1 != 0; iter1++) {
	    El_ref ref = *iter1;
	    switch (ref.get_ref_type()) {
	    case EXP_DEST:
	    case IMP_DEST:
	    case EXP_SRC:
	    case IMP_SRC: 
	    case PRED_SRC:
	    {
		if (a_lr->_live_ops.is_member(ref.get_op()) == false) {
		    // currrent operation is not live in lr_
		    break;
		}

		if (EL_do_pred_analysis) {
		    Pred_cookie* pred1 = _pred_map.value(ref.get_op());
		    Pred_cookie* pred2 = a_lr->_pred_map.value(ref.get_op());

		    if ( !pred1->is_disjoint(*pred2) ) {
			is_interfered = true;
		    }
		}
		else {
		    is_interfered = true;
		}
	    }
	    break;
	    
	    default:
		// Is this valid case? Check this.
		assert(0);
	    }
	}

	for (List_iterator<El_ref> iter2(a_lr->_live_refs); iter2 != 0; iter2++) {
	    El_ref ref = *iter2;
	    switch (ref.get_ref_type()) {
	    case EXP_DEST:
	    case IMP_DEST:
	    case EXP_SRC:
	    case IMP_SRC:
	    case PRED_SRC:
	    {
		if (!_live_ops.is_member(ref.get_op())) {
		    // currrent operation is not live in lr_
		    break;
		}

		if (EL_do_pred_analysis) {
		    Pred_cookie* pred1 = _pred_map.value(ref.get_op());
		    Pred_cookie* pred2 = a_lr->_pred_map.value(ref.get_op());

		    if ( !pred1->is_disjoint(*pred2) ) {
			is_interfered = true;
		    }
		}
		else {
		    is_interfered = true;
		}
	    }
	    break;

	    default:
		// Is this valid case? Check this.
		assert(0);
	    }
	}

    }
    
    return is_interfered;
}


bool LiveBlock::is_entry_edge_for_sublr(Edge* e) {

    for (List_iterator<Op*> iter(_live_ops); iter!=0; iter++) {
	Region* op = *iter;
	if (op->inedges().is_member(e)) {
	    return true;
	}
    }

    return false;
   
}

bool
LiveBlock::is_exit_edge_for_sublr(Edge* e) {

    for (List_iterator<Op*> iter(_live_ops); iter!=0; iter++) {
	Region* op = *iter;
	if (op->outedges().is_member(e)) {
	    return true;
	}
    }

    return false;
   
}

bool
LiveBlock::is_member(const Op* op)const {
    return _live_ops.is_member( (Op*)op);
}


void
LiveBlock::bind_register(int reg_num_,
			 LiveRange::CallerCalleeType reg_save_type) {

    //_reg_bind_state = BOUND;
    //_reg_num = reg_num_;

    _var.bind_reg(reg_num_);

    for (List_iterator<El_ref> iter1(_live_refs); iter1 != 0; iter1++) {
        (*iter1).get_operand().bind_reg(reg_num_);
    }


    // update forbidden regs
    add_forbidden_reg(reg_num_);
    for (List_iterator<LiveBlock*> iter2(_inf_lus); iter2 != 0; iter2++) {
        LiveBlock* lb_ptr = *iter2;
        lb_ptr->add_forbidden_reg(reg_num_);
    }


    // code patch for caller saved registers
    if (reg_save_type == LiveRange::CALLER_SAVED) {
        for (List_iterator<Op*> iter(_live_ops); iter != 0; iter++) {
            Op* op_ptr = *iter;
            if (is_brl(op_ptr)) {

                // if (_live_ops.head() != op_ptr) {
		// We do not have to spill for last BRL operation
		{
                    //SpillCodeUtils::store_before(_var, op_ptr);
		    for (List_iterator<Edge*> i_iter( ((Region*)op_ptr)->inedges()); i_iter!=0; i_iter++) {
			Edge* ie = *i_iter;
			ReconcileCodeSet::add_preop_store(ie, _var, op_ptr->src(PRED1));
		    }

                    //SpillCodeUtils::load_after(_var, op_ptr);
		    for (List_iterator<Edge*> o_iter( ((Region*)op_ptr)->outedges()); o_iter!=0; o_iter++) {
			Edge* oe = *o_iter;
			ReconcileCodeSet::add_postop_load(oe, _var, op_ptr->src(PRED1));
		    }
		}

            }
        }
    }
}

void
LiveBlock::spilling() {


    RegisterBank& reg_bank = RegisterBankPool::instance().bank(_var.file_type());
    for (List_iterator<El_ref> iter(_live_refs); iter != 0; iter++) {
	El_ref& ref = *iter;
	int port_num = ref.get_port_num();
	Op* op_ptr = ref.get_op();

	// register is reserved for spilling
	int pref_reg = reg_bank.spill_reg(port_num);
	ref.get_operand().bind_reg(pref_reg);

	El_ref_type ref_type= ref.get_ref_type();
	if (ref_type == EXP_DEST) {
	    for (List_iterator<Edge*> o_iter( ((Region*)ref.get_op())->outedges()); o_iter!=0; o_iter++) {
		Edge* oe = *o_iter;
		ReconcileCodeSet::add_postop_store(oe, ref.get_operand(), op_ptr->src(PRED1));
		//ReconcileCodeSet::add_store(oe, ref.get_operand());
		// SpillCodeUtils::store_after(ref.get_operand(), ref.get_op());
	    }
	}
	else if (ref_type == EXP_SRC) {
	    for (List_iterator<Edge*> i_iter( ((Region*)ref.get_op())->inedges()); i_iter!=0; i_iter++) {
		Edge* ie = *i_iter;
		ReconcileCodeSet::add_preop_load(ie, ref.get_operand(), op_ptr->src(PRED1));
	    }
	    //SpillCodeUtils::load_before(ref.get_operand(), ref.get_op());
	}
    }
    
}


Pair<LiveUnit*, LiveUnit*>
LiveBlock::split() {
    LiveBlock* lr1 = new LiveBlock(_region, _var);
    LiveBlock* lr2 = new LiveBlock(_region, _var);

    if (1) {
	split_ops(lr1, lr2);
    }
    else {
	// split by colorable register (like C&H)
	split_ops_by_colorable(lr1, lr2);
    }


    // split El_ref,  split_live_refs(lr1, lr2);
    for (List_iterator<El_ref> ref_iter(_live_refs); ref_iter !=0; ref_iter++) {
	El_ref& c_ref = *ref_iter;
	if (c_ref.get_ref_type() == EXP_SRC) {
	    if (lr1->_live_ops.is_member(c_ref.get_op())) {
		lr1->add_live_ref(c_ref);
	    }
	    else {
		lr2->add_live_ref(c_ref);
	    }
	}
	else if (c_ref.get_ref_type() == EXP_DEST) {
	    if (lr1->_live_ops.is_member(c_ref.get_op())) {
		lr1->add_live_ref(c_ref);
	    }
	    else {
		lr2->add_live_ref(c_ref);
	    }
	}
	else {
	    assert(0);
	}
    }

    bool found = false;
    Op* dest_op = lr1->_live_ops.tail();	// first Op in post live_range (lr1)
    Op* src_op =  lr2->_live_ops.head();	// last Op in pre live_range(lr2)
    // add entry/exit edges between two LR
    for (List_iterator<Edge*> ei(((Region*)src_op)->outedges()); ei!=0; ei++) {
	Edge* e=*ei;
	if (e->is_control() && e->dest()==dest_op) {
	    lr2->_exit_edges.add_tail(e);
	    lr1->_entry_edges.add_tail(e);
	    found = true;
	}
    }

    // 2 non-continous LR are possible
    // assert(found==true);

    // split entry/exit edges of this block to lr1 and lr2
    for (List_iterator<Edge*> en_iter(_entry_edges); en_iter!=0; en_iter++) {
	Edge* ee = *en_iter;
	Op* dest_op = ee->dest();
	if (lr1->is_member(dest_op)) {
	    lr1->_entry_edges.add_tail(ee);
	}
	else if (lr2->is_member(dest_op)) {
	    lr2->_entry_edges.add_tail(ee);
	}
	else {
	    assert(0);
	}
    }
    for (List_iterator<Edge*> ex_iter(_exit_edges); ex_iter!=0; ex_iter++) {
	Edge* ee = *ex_iter;
	Op* src_op = ee->src();
	if (lr1->is_member(src_op)) {
	    lr1->_exit_edges.add_tail(ee);
	}
	else if (lr2->is_member(src_op)) {
	    lr2->_exit_edges.add_tail(ee);
	}
	else {
	    assert(0);
	}
    }

    // split interference
    for (List_iterator<LiveBlock*> iter(_inf_lus); iter!=0; iter++) {
	LiveBlock* inf_b = *iter;
	(inf_b->_inf_lus).remove(this);
	inf_b->set_interference(lr1);
	inf_b->set_interference(lr2);
    }


    // set forbidden_regs
    for (List_iterator<LiveBlock*> i1(lr1->_inf_lus); i1!=0; i1++) {
	LiveBlock* inf_b = *i1;
	if (inf_b->_var.allocated()) {
	    lr1->_forbidden_regs.set_bit(inf_b->_var.mc_num());
	}
    }
    for (List_iterator<LiveBlock*> i2(lr2->_inf_lus); i2!=0; i2++) {
	LiveBlock* inf_b = *i2;
	if (inf_b->_var.allocated()) {
	    lr2->_forbidden_regs.set_bit(inf_b->_var.mc_num());
	}
    }



    lr1->_freq_map = _freq_map;
    lr2->_freq_map = _freq_map;

    lr1->set_priority();
    lr2->set_priority();

    if (dbg(status, 2)) {
	printf("Variable %d Split block %d with (%d,%d) ops\n",
	       _var.vr_num(),
	       _region->id(), lr1->_live_ops.size(), lr2->_live_ops.size());
    }
    return Pair<LiveUnit *,LiveUnit *> (lr1, lr2);
}


void
LiveBlock::split_ops_by_colorable(LiveBlock* lr1, LiveBlock* lr2) {

    Bitvector used_regs;
    bool is_first_op = true;
    eString phy_file_name = _var.physical_file_type();
    int static_reg_size =  MDES_reg_static_size(phy_file_name);

    for (List_iterator<Op*> op_iter(_live_ops); op_iter!=0; op_iter++) {

	Op* op = *op_iter;

	if (is_branch(op)){
	    for(Op_pseudo_sources lives(op); lives != 0; lives++) {

		El_ref cur_ref = lives.get_ref();
		Operand& var = cur_ref.get_operand();

		if (var.is_reg() && var.allocated()) {
		    used_regs.set_bit(var.mc_num());
		}
	    }
	}

	for(Op_all_dests dests(op); dests != 0; dests++) {
	    El_ref cur_ref = dests.get_ref();
            Operand& var = cur_ref.get_operand();

	    if (var.is_reg() && var.allocated()) {
		used_regs.set_bit(var.mc_num());
	    }

	}

	for(Op_all_inputs ins(op); ins != 0; ins++) {
	    El_ref cur_ref = ins.get_ref();
            Operand& var = cur_ref.get_operand();
	    if (var.is_reg() && var.allocated()) {
		used_regs.set_bit(var.mc_num());
	    }

	}

	if (is_first_op) {
	    lr2->add_live_op(op, *_pred_map.value(op));
	    is_first_op = false;
	}
	else if (used_regs.ones_count() < static_reg_size) {
	    lr2->add_live_op(op, *_pred_map.value(op));
	}
	else {
	    lr1->add_live_op(op, *_pred_map.value(op));
	}
    }

}


void 
LiveBlock::split_ops(LiveBlock* lr1, LiveBlock* lr2) {
    double caller_benefit = 0;
    double callee_benefit = 0;
    double max_caller_benefit = -1;
    double max_callee_benefit = -1;
    int caller_split_point = -1;
    int callee_split_point = -1;
    int last_op_id;

    for (List_iterator<Op*> op_iter(_live_ops); op_iter!=0; op_iter++) {
	Op* op = *op_iter;
	last_op_id = op->id();

	if (is_brl(op)) {
	    caller_benefit -= (LiveRange::STORE_LATENCY+LiveRange::LOAD_LATENCY);
	}
	
	for (Op_all_inputs oi(op); oi!=0; oi++) {
	    Operand& tmp_input = (*oi) ;
	    if (tmp_input.is_reg() == false) {
		continue;
	    }
	    else if (tmp_input.vr_num() == _var.vr_num()) {
		caller_benefit += LiveRange::LOAD_LATENCY;
		callee_benefit += LiveRange::LOAD_LATENCY;
	    }
	}

	for (Op_all_dests oo(op); oo!=0; oo++) {
	    Operand& tmp_input = (*oo) ;
	    if (tmp_input.is_reg() == false) {
		continue;
	    }
	    else if (tmp_input.vr_num() == _var.vr_num()) {
		caller_benefit += LiveRange::STORE_LATENCY;
		callee_benefit += LiveRange::STORE_LATENCY;
	    }
	}

	if (caller_benefit > max_caller_benefit) {
	    max_caller_benefit = caller_benefit;
	    caller_split_point = op->id();
	}

	if (callee_benefit > max_callee_benefit) {
	    max_callee_benefit = callee_benefit;
	    callee_split_point = op->id();
	}
    }

    {
	if (max_caller_benefit > max_callee_benefit &&
	    caller_split_point != last_op_id) {
	    split_ops(lr1, lr2, caller_split_point);
	}
	else if (max_callee_benefit > max_caller_benefit &&
		 callee_split_point != last_op_id) {
	    split_ops(lr1, lr2, callee_split_point);
	}
	else {
	    if (callee_split_point!=-1&&
		callee_split_point != last_op_id && max_callee_benefit > 0) {
		split_ops(lr1, lr2, callee_split_point);
	    }
	    else if (caller_split_point!=-1 && 
		     caller_split_point != last_op_id && max_caller_benefit > 0) {
		split_ops(lr1, lr2, caller_split_point);
	    }
	    else
		split_ops_half(lr1, lr2);
	}
    }
}

void
LiveBlock::split_ops(LiveBlock* lr1, LiveBlock* lr2, int split_op) {
    bool after_split_point = false;
    for (List_iterator<Op*> op_iter(_live_ops); op_iter!=0; op_iter++) {
	Op* cur_op = *op_iter;
	if (after_split_point == false) {
 	    lr1->add_live_op(cur_op, *_pred_map.value(cur_op));
	}
	else {
	    lr2->add_live_op(cur_op, *_pred_map.value(cur_op));
	}
	if (cur_op->id() == split_op)
	    after_split_point = true;
    }
    assert(after_split_point==true);

}


void
LiveBlock::split_ops_half(LiveBlock* lr1, LiveBlock* lr2) {
    int op_num = _live_ops.size();
    int count = 0;
    for (List_iterator<Op*> op_iter(_live_ops); op_iter!=0; op_iter++, count++) {
	Op* cur_op = *op_iter;
	if (count < op_num/2) {
	    lr1->add_live_op(cur_op, *_pred_map.value(cur_op));
	}
	else {
	    lr2->add_live_op(cur_op, *_pred_map.value(cur_op));
	}
    }

}



void
LiveBlock::add_all_adj_lr(LiveRange* lr1, LiveRange* lr2) {

    for (List_iterator<Edge*> e_iter1(_entry_edges); e_iter1!=0; e_iter1++) {
	Edge* ee = *e_iter1;
	if (lr2->exit_edges().is_member(ee)) {
	    lr1->add_adj_lr(ee, lr2); 
	    lr2->add_adj_lr(ee, lr1);
	}
    }   


    for (List_iterator<Edge*> e_iter2(_exit_edges); e_iter2!=0; e_iter2++) {
	Edge* ee = *e_iter2;
	if (lr2->entry_edges().is_member(ee)) {
	    lr1->add_adj_lr(ee, lr2); 
	    lr2->add_adj_lr(ee, lr1);
	}   
    }   

}

//
// set expected save cost by register allocation 
//
void
LiveBlock::set_priority() {
    Op* last_op = _live_ops.head();
    List<Op*> brl_ops;
    for (List_iterator<Op*> op_iter(_live_ops); op_iter != 0; op_iter++) {
	Op* op = *op_iter;
	if (is_brl(op)) {
	    brl_ops.add_tail(op);
	    if (op != last_op) {
		// exclude last brl operation
		// variable is not live-out from brl operation
		_brl_num++;
	    }
	} 
    }

    for (List_iterator<El_ref> iter(_live_refs); iter != 0; iter++) {
	El_ref& ref = *iter;
	El_ref_type ref_type= ref.get_ref_type();
	if (ref_type == EXP_SRC) {
	    _def_num++;
	}
	else if (ref_type == EXP_DEST) {
	    _use_num++;
	}
    }


    /*
      callee saved register needs to spilling that register at the function
      boundaries (in prologue and epilogue).
     This extra cost can be spread out to all live ranges in this function
     which is using that callee saved register.
     To estimate this cost, I use 1/2 in the following code
     All cost are mutiplied with weight information, but added 1 for not 
     profiled Elcor
    
     added 9/9/98
     But the above algorothm has following problem
     Consider a LiveRange lr1 where it has n definition of variable vr1
     and m number of uses, but no function calles. In this case, caller
     benefit is sligtly bigger that callee benefit (bt the factor of
     callee saved register spill in prologue and epilogue). If there is
     no caller saved register, then callee register may be used. In the 
     case of m and n are 0 (this is pass-through) live range, 
     callee_benefit is negative and caller_benefit is 0. This leads
     propagate_in() for lr1 to reject all callee_saved register.
    
     So another algorithm is
     A. Caller/Callee Benefit
       Do not consider callee-register spill cost for benefit
    
     B. Propagate_in 
          (used for new register selection in non pass-through
           and  reconcile for pass-through)
    For a given adjacent LR adj_lr
    if (adj_lr is SPILLED) {
	if (lr1->caller_benefit() - patch_cost(adj_lr,lr1) > 0)
	    try other to bound;
	else if (lr1->callee_benefit() - patch_cost(adj_lr,lr1) > 0)
	    try other to bound;
	else 
	    SPILL lr1;
    }
    else if (adj_lr is CALLER_BOUND with reg1) {
	if (reg1 is available &&
	    lr1->caller_benefit() > 0)
	    BOUND lr1 with reg1;
    }
    else if (adj_lr is CALLEE_BOUND with reg1) {
	int extra_cost = (
	    LOAD_COST+STORE_COST  if reg1 is first use
	    0, other wise);
			
	if (reg1 is available &&
	    lr1->caller_benefit() - extra_cost)
	    BOUND lr1 with reg1;
    }
			  
    C. Register selection (coloring, new register without neighbor))
    if (caller_benefit == callee_benefit) {
    // this is when there is no function call
      assert(_caller_benefit >= 0); // _caller_benefit is 0, it lr1 is pass-through
      use caller_first; 
      int extra_cost = (
        LOAD_COST+STORE_COST  if reg1 is first use
        0, other wise);
      if (_callee_benefit - extra cost > 0) {
          then try callee;
      }
    }
    else if (caller_benefit() > callee_benefit) {
       use caller first;
       try callee, if possible
    } 
    else {
        ....
    }
    */

    if (0) {
	for (List_iterator<El_ref> iter(_live_refs); iter!=0; iter++) {
	    El_ref& ref = *iter;
	    Op* op = ref.get_op();
	    Lcode_attribute_map *map = get_lcode_attributes(op);
	    float prob = 0;
	    if (map->is_bound("wgt")) {
		List<Operand>& wgt = map->value("wgt");
		for (List_iterator<Operand> optr(wgt);  optr != 0;  optr++) {
		    Operand& a_operand = *optr;
		    assert(a_operand.is_float()==true);
		    prob += a_operand.float_value();
		}
	    }
	    else {
		prob = 1;
	    }

	    
	    if (ref.get_ref_type() == PRED_SRC || ref.get_ref_type() == EXP_SRC || ref.get_ref_type() == IMP_SRC) {
		_spill_cost += LiveRange::LOAD_LATENCY * prob;
	    }
	    else if (ref.get_ref_type() == EXP_DEST || ref.get_ref_type() == IMP_DEST) {
		_spill_cost += LiveRange::STORE_LATENCY * prob;

	    }
	    else {
		assert(0);
	    }
	}
	_caller_benefit = _spill_cost - _brl_num * (LiveRange::STORE_LATENCY+LiveRange::LOAD_LATENCY);
	_caller_benefit = _caller_benefit * (_region->weight + 1);
	_callee_benefit = _spill_cost;
	_callee_benefit = _callee_benefit * (_region->weight + 1);
    }
    else if (EL_use_predicate_priority) {
	assert(0);
	// not supported in this version
    }
    else if (EL_use_frequency) {
	_spill_cost = _def_num * LiveRange::STORE_LATENCY + _use_num * LiveRange::LOAD_LATENCY;
	_caller_benefit = _spill_cost - _brl_num * (LiveRange::STORE_LATENCY+LiveRange::LOAD_LATENCY);
	_caller_benefit = _caller_benefit * (_region->weight + 1);
	_callee_benefit = _spill_cost;
	_callee_benefit = _callee_benefit * (_region->weight + 1);
    }
    else {
	_spill_cost = _def_num * LiveRange::STORE_LATENCY + _use_num * LiveRange::LOAD_LATENCY;
	_caller_benefit = _spill_cost - _brl_num * (LiveRange::STORE_LATENCY+LiveRange::LOAD_LATENCY);
	_callee_benefit = _spill_cost;
    }

    
    // EL_call_cost_priority : call cost directed priority function
    // 0; priority function does not consider caller/callee saved cost
    //    In coloring, choose caller saved register, if LR is leaf 
    //    Then use callee, if available.
    // 1: priority function is reflecting caller/callee saved cost
    //    If prefered register is not available, use other register 
    //	  or spill according to benefit
    if (EL_call_cost_priority == 0) {
	_priority = _spill_cost * (_region->weight + 1) / _live_ops.size();
    }
    else if (EL_call_cost_priority == 1) {
	_priority = _spill_cost * (_region->weight + 1);
    }
    else if (EL_call_cost_priority == 2) {
	_priority = _spill_cost * (_region->weight + 1);
    }
    else if (EL_call_cost_priority == 3) {
	if (_callee_benefit > _caller_benefit) {
	    if (_caller_benefit > 0) {
		_priority = (_callee_benefit - _caller_benefit);
	    }
	    else {
		_priority = _callee_benefit;
	    }
	}
	else {
	    if (_callee_benefit > 0) {
		_priority = _caller_benefit - _callee_benefit;
	    }
	    else {
		_priority = _caller_benefit;
	    }
	}
    }
    else if (EL_call_cost_priority == 4) {
	if (_callee_benefit > _caller_benefit) {
	    if (_caller_benefit > 0) {
		_priority = (_callee_benefit - _caller_benefit);
	    }
	    else {
		_priority = _callee_benefit;
	    }
	}
	else {
	    if (_callee_benefit > 0) {
		_priority = _caller_benefit - _callee_benefit;
	    }
	    else {
		_priority = _caller_benefit;
	    }
	}
	_priority = (_spill_cost * (_region->weight + 1) + _priority);
    }
    else {
	assert(0);
    }
}


void
LiveBlock::split_live_refs(LiveBlock* new_lr1, LiveBlock* new_lr2) {
    for (List_iterator<El_ref> iter(_live_refs); iter !=0; iter++) {
	El_ref& c_ref = *iter;
	if (c_ref.get_ref_type() == EXP_SRC) {
	    if (new_lr1->_live_ops.is_member(c_ref.get_op())) {
		new_lr1->add_live_ref(c_ref);
	    }
	    else {
		new_lr2->add_live_ref(c_ref);
	    }
	}
	else if (c_ref.get_ref_type() == EXP_DEST) {
	    if (new_lr1->_live_ops.is_member(c_ref.get_op())) {
		new_lr1->add_live_ref(c_ref);
	    }
	    else {
		new_lr2->add_live_ref(c_ref);
	    }
	}
	else {
	    assert(0);
	}
    }
}

