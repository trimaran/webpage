/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           LiveSubRegion.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include <bit_vector.h>
#include <attributes.h>
#include <el_sreg_init.h>
#include <flow_analysis_solver.h>
#include <intf.h>
#include <iterators.h>
#include <math.h>
#ifdef LINUX
#include <values.h>
#endif
#include <opcode_properties.h>
#include <dbg.h>
#include <sys/param.h>

#include "GlobalBoundMap.h"
#include "LiveSubRegion.h"
#include "ReconcileCode.h"
#include "RegisterBank.h"
#include "SpillCodeUtils.h"


/*************************************************************************
 *
 *  LiveSubRegion
 *
 ************************************************************************/
LiveSubRegion::LiveSubRegion(Compound_region* r, Operand& var) {
    _region = r;
    _var = var;
}


bool
LiveSubRegion::has_single_ref()const {
    if (EL_op_based_liverange) {
	int op_count = 0;
	for (List_iterator<LiveUnit*> iter(_live_units); iter != 0; iter++) {
	    LiveUnit* sub_lu = *iter;
	    op_count += sub_lu->ref_op_count();
	}
	if (op_count > 1)
	    return false;
	else
	    return true;
    }
    else {
	if (_live_units.size()==1) {
	    LiveUnit* sub_lu = _live_units.head();
	    if (sub_lu->region()->is_bb() || sub_lu->region()->is_hb())
		return true;
	    else
		return sub_lu->has_single_ref();
	}
	else {
	    return false;
	}
    }
}

bool
LiveSubRegion::has_single_block()const {
    if (_live_units.size()==1) {
	LiveUnit* sub_lu = _live_units.head();
	return sub_lu->has_single_block();
    }
    else {
	return false;
    }
}

bool
LiveSubRegion::is_in_interference_set(LiveUnit* a_lr) {
    return a_lr->is_in_interference_set(this);
}


bool
LiveSubRegion::is_in_interference_set(LiveSubRegion* a_lr) {
    return (_inf_lus.is_member(a_lr));
}


bool
LiveSubRegion::init_interference_recursively(LiveUnit* a_lr) {
    return a_lr->init_interference_recursively(this);
}


// 
// update current LiveUnit interferences based on sub-LiveUnit 
// for interfering.
// This functions assumes that its sub-LiveUnit has already updated
// interference set
//
bool
LiveSubRegion::init_interference_recursively(LiveSubRegion* a_lr) {

    assert(this->region() == a_lr->region());
    bool is_interfered = false;

    for (List_iterator<LiveUnit*> iter(_live_units); iter != 0; iter++) {
	LiveUnit* sub_lr1 = *iter;
	
	for (List_iterator<LiveUnit*> iter2(a_lr->_live_units); iter2 != 0; iter2++) {
	    LiveUnit* sub_lr2 = *iter2;
	    if (sub_lr1->region() != sub_lr2->region()) {
		continue;
	    }
	    else {
		if (sub_lr1->init_interference_recursively(sub_lr2)) {
		    is_interfered = true;
		}
	    }
	}
    }

    if (is_interfered) {
	add_interference(a_lr);
	a_lr->add_interference(this);
    }

    return is_interfered;
}


void
LiveSubRegion::add_interference(LiveSubRegion* a_lu) {
    assert(_level == a_lu->_level);
    if (_inf_lus.is_member(a_lu) == false) {
	_inf_lus.add_tail(a_lu);
    }
}


void
LiveSubRegion::remove_interference(LiveSubRegion* a_lu) {
    assert(_level == a_lu->_level);
    if (_inf_lus.is_member(a_lu) == false) {
	_inf_lus.remove(a_lu);
    }
}


void
LiveSubRegion::upscale_interference() {
    assert(_parent);
    for (List_iterator<LiveSubRegion*> i2(_inf_lus); i2!=0; i2++) {
	LiveSubRegion* inf_su = *i2;
	LiveSubRegion* inf_parent = inf_su->_parent;
	_parent->add_interference(inf_parent);
    }

}

bool
LiveSubRegion::is_member(const Op* op)const {
    for (List_iterator<LiveUnit*> iter(_live_units); iter != 0; iter++) {
	LiveUnit* sub_lu = *iter;
	if (sub_lu->is_member(op))
	    return true;
    }
    return false;
}


bool
LiveSubRegion::is_pass_through()const {
    for (List_iterator<LiveUnit*> iter(_live_units); iter != 0; iter++) {
	LiveUnit* sub_lr1 = *iter;
	if (sub_lr1->is_pass_through() == false)
	    return false;
    }
    return true;
}


int
LiveSubRegion::ref_op_count()const {
    int count = 0;
    for (List_iterator<LiveUnit*> iter(_live_units); iter != 0; iter++) {
	LiveUnit* sub_lu = *iter;
	count += sub_lu->ref_op_count();
    }
    return count;
}


int
LiveSubRegion::live_ops_count()const {
    return _live_ops_num;
}


void
LiveSubRegion::add_sub_liveunit(LiveUnit* a_lu) {
    a_lu->set_parent(this);
    _live_units.add_tail(a_lu);
    for (List_iterator<El_ref> iter(a_lu->live_refs()); iter!=0; iter++) {
	El_ref& a_ref = *iter;
	_live_refs.add_tail(a_ref);
    }

    a_lu->upscale_interference();


    _forbidden_regs += a_lu->_forbidden_regs;
}


LiveUnit*
LiveSubRegion::find_sub_live_unit(const Op* op) {
    for (List_iterator<LiveUnit*> iter(_live_units); iter!=0; iter++) {
	LiveUnit* sub_lu = *iter;
	if (sub_lu->is_member(op)) {
	    return sub_lu;
	}
    }
    return NULL;
}



// 
// Splitting current LiveUnit into new New LiveUnit
// If it has only one sub-LiveUnit, call it recursivley
//
Pair<LiveUnit*, LiveUnit*>
LiveSubRegion::split() {

    LiveSubRegion* lr1 = new LiveSubRegion(_region, _var);
    LiveSubRegion* lr2 = new LiveSubRegion(_region, _var);
    unsigned child_num = _live_units.size();

    if (child_num == 1) {
	LiveUnit* sub_lu = _live_units.pop();
	Pair<LiveUnit*, LiveUnit*> splitted = sub_lu->split();
	delete sub_lu;

	LiveUnit* sub_lr1 = splitted.first;
	LiveUnit* sub_lr2 = splitted.second;

	lr1->add_sub_liveunit(sub_lr1);
	lr2->add_sub_liveunit(sub_lr2);
	
	for (List_iterator<Edge*> iter(sub_lr2->_entry_edges); iter!=0; iter++) {
	    Edge* e = *iter;
	    Op* src_op = e->src();
	    if (lr1->is_member(src_op)) {
		lr2->_entry_edges.add_tail(e);
		lr1->_exit_edges.add_tail(e);
	    }
	}

	for (List_iterator<Edge*> ex_iter(sub_lr2->_exit_edges); ex_iter!=0; ex_iter++) {
	    Edge* e = *ex_iter;
	    Op* dest_op = e->dest();
	    if (lr1->is_member(dest_op)) {
		lr1->_entry_edges.add_tail(e);
		lr2->_exit_edges.add_tail(e);
	    }
	}

    }
    else {
	
	if (EL_split_scheme == 0) {
	    split_by_region(lr1, lr2);
	}
	else if (EL_split_scheme == 1) {
	    split_by_frequency(lr1, lr2);
	}
	else if (EL_split_scheme == 2) {

	    // divide subregion into 2 groups by caller/callee benefit
	    int max_region_id = 0;
	    int max_caller_region = 0;
	    int max_callee_region = 0;
	    double caller_benefit = 0;
	    double callee_benefit = 0;
	    double max_caller_benefit = -MAXFLOAT;
	    double max_callee_benefit = -MAXFLOAT;
	
	    for (List_iterator<LiveUnit*> iter(_live_units); iter!=0; iter++) {
		LiveUnit* sub_lu = *iter;
		max_region_id = sub_lu->_region->id();

		caller_benefit += sub_lu->_caller_benefit;
		callee_benefit += sub_lu->_callee_benefit;

		if (caller_benefit > max_caller_benefit) {
		    max_caller_benefit = caller_benefit;
		    max_caller_region = sub_lu->_region->id();
		}

		if (callee_benefit > max_callee_benefit) {
		    max_callee_benefit = callee_benefit;
		    max_callee_region = sub_lu->_region->id();
		}

	    }

	    if (max_caller_benefit > max_callee_benefit &&
		max_caller_region != max_region_id) {
		split_by(lr1, lr2, max_caller_region);
	    }
	    else if (max_callee_benefit > max_caller_benefit &&
		     max_callee_region != max_region_id) {
		split_by(lr1, lr2, max_callee_region);
	    }
	    else if (max_callee_benefit == max_caller_benefit) {
		if (max_caller_region != max_region_id) {
		    split_by(lr1, lr2, max_caller_region);
		}
		else if (max_callee_region != max_region_id) {
		    split_by(lr1, lr2, max_callee_region);
		}
		else {
		    split_in_half(lr1, lr2);
		}
	    }
	    else if (max_callee_benefit > 0 && max_callee_region != max_region_id) {
		split_by(lr1, lr2, max_callee_region);
	    }
	    else if (max_caller_benefit > 0 && max_caller_region != max_region_id) {
		split_by(lr1, lr2, max_caller_region);
	    }
	    else {
		split_in_half(lr1, lr2);
	    }
	}
	else {
	    // So divide sub-region into 2 equel set in other version
	    split_in_half(lr1, lr2);
	}

	assert(lr1->_live_units.size() * lr2->_live_units.size() > 0);
	assert(lr1->_live_units.size() + lr2->_live_units.size() == child_num);

	if (dbg(status, 2)) {
	    for (List_iterator<LiveUnit*> si1(lr1->_live_units); si1!=0; si1++) {
		LiveUnit* sub_lu = *si1;
		printf("L%d ",sub_lu->_region->id());
	    }
	    for (List_iterator<LiveUnit*> si2(lr2->_live_units); si2!=0; si2++) {
		LiveUnit* sub_lu = *si2;
		printf("R%d ",sub_lu->_region->id());
	    }
	    printf("Variable %d \n", _var.vr_num());
	}
    }

    // split entry/exit edges between lr1 and lr2
    for (List_iterator<LiveUnit*> si(lr1->_live_units); si!=0; si++) {
	LiveUnit* sub_lu = *si;
	for (List_iterator<Edge*> en_iter(sub_lu->_entry_edges); en_iter!=0; en_iter++) {
	    Edge* e = *en_iter;
	    Op* src_op = e->src();
	    if (lr2->is_member(src_op)) {
		lr1->_entry_edges.add_tail(e);
		lr2->_exit_edges.add_tail(e);
	    }
	}

	for (List_iterator<Edge*> ex_iter(sub_lu->_exit_edges); ex_iter!=0; ex_iter++) {
	    Edge* e = *ex_iter;
	    Op* dest_op = e->dest();
	    if (lr2->is_member(dest_op)) {
		lr1->_exit_edges.add_tail(e);
		lr2->_entry_edges.add_tail(e);
	    }
	}
    }


    // update interference graph
    // remove iterference information of old LiveUnit
    for (List_iterator<LiveSubRegion*> diter1(_inf_lus); diter1!=0; diter1++) {
	LiveSubRegion* lu_ptr = *diter1;
	
	lu_ptr->remove_interference(this);
    }

    for (List_iterator<LiveSubRegion*> lui1(lr1->_inf_lus); lui1!=0; lui1++) {
	LiveSubRegion* lu_ptr = *lui1;
	lu_ptr->add_interference(lr1);
    }
    for (List_iterator<LiveSubRegion*> lui2(lr2->_inf_lus); lui2!=0; lui2++) {
	LiveSubRegion* lu_ptr = *lui2;
	lu_ptr->add_interference(lr2);
    }

    // split entry edges of this to lr1 and lr2
    for (List_iterator<Edge*> ee_c(_entry_edges); ee_c!=0; ee_c++) {
	Edge* e = *ee_c;
	if (lr1->is_entry_edge_for_sublr(e)) {
	    lr1->_entry_edges.add_tail(e);
	}
	else if (lr2->is_entry_edge_for_sublr(e)) {
	    lr2->_entry_edges.add_tail(e);
	}
	else {
	    //impossible
	    assert(0);
	}
    }    
	
    // split exit edge
    for (List_iterator<Edge*> ee_b(_exit_edges); ee_b!=0; ee_b++) {
	Edge* e = *ee_b;
	if (lr1->is_exit_edge_for_sublr(e)) {
	    lr1->_exit_edges.add_tail(e);
	}
	else if (lr2->is_exit_edge_for_sublr(e)) {
	    lr2->_exit_edges.add_tail(e);
	}
	else {
	    //impossible
	    assert(0);
	}
    }


    lr1->set_priority();
    lr2->set_priority();

    return Pair<LiveUnit*, LiveUnit*> (lr1, lr2);
}



void
LiveSubRegion::split_by_region(LiveSubRegion* lr1,
			       LiveSubRegion* lr2) {

    eString phy_file_name = _var.physical_file_type();
    int static_reg_size =  MDES_reg_static_size(phy_file_name);
    Bitvector used_regs;

    // set every not prefered register as used
    RegisterBank& rb = RegisterBankPool::reg_bank(_var.file_type());
    used_regs += rb._macro_bv;
    if (_caller_benefit < _callee_benefit) {
	used_regs += rb._caller_bv;
    }
    else if (_callee_benefit < _caller_benefit) {
	used_regs += rb._callee_bv;
    }

    LiveUnit* first_lu = _live_units.pop();
    lr1->add_sub_liveunit(first_lu);
    used_regs += first_lu->_forbidden_regs;

    for (List_iterator<LiveUnit*> iter(_live_units); iter !=0; iter++) {
	LiveUnit* sub_lu = *iter;
	used_regs += sub_lu->_forbidden_regs;

	if (used_regs.ones_count() < static_reg_size) {
	    lr1->add_sub_liveunit(sub_lu);
	}
	else {
	    lr2->add_sub_liveunit(sub_lu);
	}

    }


}


Edge*
highest_frequency_edge(const List_set<Edge*>& edges) {

    double freq = 0;
    Edge* freq_edge = NULL;

    for (List_set_iterator<Edge*> iter(edges); iter!=0; iter++) {
	Edge* e = *iter;
	Control_flow_freq* cf_freq = get_control_flow_freq(e);
	if (cf_freq->freq >= freq) {
	    freq = cf_freq->freq;
	    freq_edge = e;
	}
    }

    return freq_edge;
}


void
LiveSubRegion::split_by_frequency(LiveSubRegion* lr1,
				  LiveSubRegion* lr2) {

    eString phy_file_name = _var.physical_file_type();
    int static_reg_size =  MDES_reg_static_size(phy_file_name);
    Bitvector used_regs;
    List_set<Edge*> adj_edges;

    // set every not prefered register as used
    RegisterBank& rb = RegisterBankPool::reg_bank(_var.file_type());
    used_regs += rb._macro_bv;
    if (_caller_benefit < _callee_benefit) {
	used_regs += rb._caller_bv;
    }
    else if (_callee_benefit < _caller_benefit) {
	used_regs += rb._callee_bv;
    }

    double highest_weight = 0.0;
    LiveUnit* seed_lu = NULL;
    for (List_iterator<LiveUnit*> iter(_live_units); iter !=0; iter++) {
	LiveUnit* sub_lu = *iter;
	double region_weight = sub_lu->_region->weight;
	if (region_weight >= highest_weight) {
	    highest_weight = region_weight;
	    seed_lu = sub_lu;
	}
    }

    lr1->add_sub_liveunit(seed_lu);
    used_regs += seed_lu->_forbidden_regs;
    adj_edges += seed_lu->_entry_edges;
    adj_edges += seed_lu->_exit_edges;

    while (1) {
	Edge* e = highest_frequency_edge(adj_edges);
	if (e == NULL)
	    break;

	adj_edges -= e;
	Op* src_op = e->src();
	Op* dest_op = e->dest();
	LiveUnit* sub_lu = NULL;

	if (lr1->is_member(src_op)) {
	    sub_lu = find_sub_live_unit(dest_op);
	}
	else {
	    assert(lr1->is_member(dest_op));
	    sub_lu = find_sub_live_unit(src_op);
	}

	if (sub_lu == NULL) {
	    // not in this region
	    continue;
	}

	if (lr1->_live_units.is_member(sub_lu)) {
	    continue;
	}

	used_regs += sub_lu->_forbidden_regs;

	if (used_regs.ones_count() < static_reg_size) {
	    lr1->add_sub_liveunit(sub_lu);
	    List_set<Edge*> intersect;
	    intersect += sub_lu->_entry_edges;
	    intersect += sub_lu->_exit_edges;
	    intersect *= adj_edges;
	    adj_edges += sub_lu->_entry_edges;
	    adj_edges += sub_lu->_exit_edges;
	    adj_edges -= intersect;
	}
	else {
	    break;
	}
    }

    for (List_iterator<LiveUnit*> iter2(_live_units); iter2 !=0; iter2++) {
	LiveUnit* sub_lu = *iter2;
	if (lr1->_live_units.is_member(sub_lu) == false) {
	    lr2->add_sub_liveunit(sub_lu);
	}
    }
    
}

/*
void
LiveSubRegion::split_by_freq_and_calling(LiveSubRegion* lr1,
					 LiveSubRegion* lr2) {

    eString phy_file_name = _var.physical_file_type();
    int static_reg_size =  MDES_reg_static_size(phy_file_name);
    Bitvector used_regs;
    List_set<Edge*> adj_edges;

    double highest_weight = 0.0;
    LiveUnit* seed_lu = NULL;
    for (List_iterator<LiveUnit*> iter(_live_units); iter !=0; iter++) {
	LiveUnit* sub_lu = *iter;
	double region_weight = sub_lu->_region->weight;
	if (region_weight >= highest_weight) {
	    highest_weight = region_weight;
	    seed_lu = sub_lu;
	}
    }

    lr1->add_sub_liveunit(seed_lu);


    // divide subregion into 2 groups by caller/callee benefit
    int max_region_id = 0;
    int max_caller_region = 0;
    int max_callee_region = 0;
    double caller_benefit = 0;
    double callee_benefit = 0;
    double max_caller_benefit = -MAXFLOAT;
    double max_callee_benefit = -MAXFLOAT;
	
    // expand by frequency order
    while (1) {
	Edge* e = highest_frequency_edge(adj_edges);
	if (e == NULL)
	    break;

	Op* src_op = e->src();
	Op* dest_op = e->dest();
	LiveUnit* sub_lu = NULL;

	if (lr1->is_member(src_op)) {
	    sub_lu = find_sub_live_unit(dest_op);
	}
	else {
	    assert(lr1->is_member(dest_op));
	    sub_lu = find_sub_live_unit(src_op);
	}
	assert(lr1->_live_units.is_member(sub_lu) == false);
	
	max_region_id = sub_lu->_region->id();

	caller_benefit += sub_lu->_caller_benefit;
	callee_benefit += sub_lu->_callee_benefit;

	if (caller_benefit > max_caller_benefit) {
	    max_caller_benefit = caller_benefit;
	    max_caller_region = sub_lu->_region->id();
	}

	if (callee_benefit > max_callee_benefit) {
	    max_callee_benefit = callee_benefit;
	    max_callee_region = sub_lu->_region->id();
	}
    }

}
*/

void
LiveSubRegion::split_by(LiveSubRegion* lr1,
			LiveSubRegion* lr2,
			int split_point) {

    bool over_split_point = false;

    for (List_iterator<LiveUnit*> iter(_live_units); iter!=0; iter++) {

	LiveUnit* sub_lu = *iter;
	LiveUnit* parent_lu = NULL;
	LiveUnit* opposit_lu = NULL;

	if (over_split_point == false) {
		parent_lu = lr1;
		opposit_lu = lr2;

		if (dbg(status, 2)) {
		    printf("L%d ",sub_lu->_region->id());
		}

	    }
	else {
		parent_lu = lr2;
		opposit_lu = lr1;

		if (dbg(status, 2)) {
		    printf("R%d ",sub_lu->_region->id());
		}
	}

	/* moved to outter scope
	for (List_iterator<Edge*> en_iter(sub_lu->_entry_edges); en_iter!=0; en_iter++) {
		Edge* e = *en_iter;
		Op* src_op = e->src();
		if (opposit_lu->is_member(src_op)) {
		    parent_lu->_entry_edges.add_tail(e);
		    opposit_lu->_exit_edges.add_tail(e);
		}
	}

	for (List_iterator<Edge*> ex_iter(sub_lu->_exit_edges); ex_iter!=0; ex_iter++) {
	    Edge* e = *ex_iter;
	    Op* dest_op = e->dest();
	    if (opposit_lu->is_member(dest_op)) {
		parent_lu->_exit_edges.add_tail(e);
		opposit_lu->_entry_edges.add_tail(e);
	    }
	}
	*/

	parent_lu->add_sub_liveunit(sub_lu);

	if (sub_lu->_region->id() == split_point) {
	    over_split_point = true;
	}
	    
    }
    assert(over_split_point == true);

    if (dbg(status, 2)) {
	printf("Variable %d \n", _var.vr_num());
    }

}

void
LiveSubRegion::split_in_half(LiveSubRegion* lr1,
			     LiveSubRegion* lr2) {

    int count = 0;
    int child_num = _live_units.size();

    for (List_iterator<LiveUnit*> iter(_live_units); iter!=0; iter++) {
	    LiveUnit* sub_lu = *iter;
	    LiveUnit* parent_lu = NULL;
	    LiveUnit* opposit_lu = NULL;
	    if (count < child_num/2) {
		parent_lu = lr1;
		opposit_lu = lr2;

		if (dbg(status, 2)) {
		    printf("L%d ",sub_lu->_region->id());
		}

	    }
	    else {
		parent_lu = lr2;
		opposit_lu = lr1;

		if (dbg(status, 2)) {
		    printf("R%d ",sub_lu->_region->id());
		}
	    }

	    /* moved to outer scope
	    for (List_iterator<Edge*> en_iter(sub_lu->_entry_edges); en_iter!=0; en_iter++) {
		Edge* e = *en_iter;
		Op* src_op = e->src();
		if (opposit_lu->is_member(src_op)) {
		    parent_lu->_entry_edges.add_tail(e);
		    opposit_lu->_exit_edges.add_tail(e);
		}
	    }

	    for (List_iterator<Edge*> ex_iter(sub_lu->_exit_edges); ex_iter!=0; ex_iter++) {
		Edge* e = *ex_iter;
		Op* dest_op = e->dest();
		if (opposit_lu->is_member(dest_op)) {
		    parent_lu->_exit_edges.add_tail(e);
		    opposit_lu->_entry_edges.add_tail(e);
		}
	    }
	    */

	    parent_lu->add_sub_liveunit(sub_lu);
	    count++;
	    
	}

	if (dbg(status, 2)) {
	    printf("Variable %d \n", _var.vr_num());
	}

}


// bind phisical register to LiveUnit
// update forbidden set for itself and all interfered LiveUnit
void
LiveSubRegion::bind_register(int reg_num_,
			     LiveRange::CallerCalleeType reg_save_type) {
    _forbidden_regs.set_bit(reg_num_);
    for (List_iterator<LiveSubRegion*> lu_iter(_inf_lus); 
	 lu_iter!=0; lu_iter++) {
	LiveSubRegion* inf_lu = *lu_iter;
	inf_lu->_forbidden_regs.set_bit(reg_num_);
    }

    for (List_iterator<LiveUnit*> iter(_live_units); iter!=0; iter++) {
	LiveUnit* lr = *iter;
	lr->bind_register(reg_num_, reg_save_type);
    }
}




void
LiveSubRegion::set_entry_edges() {
    List<Edge*> region_entry_edges = ((Region*)_region)->inedges();
    for (List_iterator<Edge*> iter(region_entry_edges);
	 iter != 0; iter++) {
	Edge* edge = *iter;
	Liveness_info* liveness = get_liveness_info(edge);
	for (Liveness_info_iterator li(*liveness); li != 0; li++) {
	    Operand& var=*li;
	    if (var==_var) {
		_entry_edges.add_tail(edge);
		break;
	    }
	}
    }
}


void
LiveSubRegion::set_exit_edges() {
    List<Edge*> region_exit_edges = ((Region*)_region)->outedges();
    for (List_iterator<Edge*> iter(region_exit_edges);
	 iter != 0; iter++) {
	Edge* edge = *iter;
	Liveness_info* liveness = get_liveness_info(edge);
	for (Liveness_info_iterator li(*liveness); li != 0; li++) {
	    Operand& var=*li;
	    if (var==_var) {
		_entry_edges.add_tail(edge);
		break;
	    }
	}
    }
}



bool
LiveSubRegion::is_entry_edge_for_sublr(Edge* e) {

   for (List_iterator<LiveUnit*> iter(_live_units); iter!=0; iter++) {
       LiveUnit* lu = *iter;
       if (lu->_entry_edges.is_member(e)) 
	   return true;
   }
  
   return false;
}


bool
LiveSubRegion::is_exit_edge_for_sublr(Edge* e) {

   for (List_iterator<LiveUnit*> iter(_live_units); iter!=0; iter++) {
       LiveUnit* lu = *iter;
       if (lu->_exit_edges.is_member(e)) 
	   return true;
   }
  
   return false;
}



void
LiveSubRegion::spilling() {
    for (List_iterator<LiveUnit*> iter(_live_units); iter!=0; iter++) {
	LiveUnit* lu = *iter;
	lu->spilling();
    }
}



void
LiveSubRegion::add_all_adj_lr(LiveRange* lr1, LiveRange* lr2) {

   for (List_iterator<LiveUnit*> iter(_live_units); iter!=0; iter++) {
       LiveUnit* lu = *iter;
       lu->add_all_adj_lr(lr1, lr2);
   }

}


void
LiveSubRegion::set_priority() {
    _live_ops_num = 0;
    for (List_iterator<LiveUnit*> iter(_live_units); iter != 0; iter++) {
	LiveUnit* sub_range = *iter;
	
	// do not call it recusrsively.
	// Let's set the value of priority as bottom up manner in
	// LiveUnit construction time.
	//sub_range->set_priority();

	_brl_num += sub_range->_brl_num;
	_def_num += sub_range->_def_num;
	_use_num += sub_range->_use_num;

	_spill_cost += sub_range->_spill_cost;
	_caller_benefit += sub_range->_caller_benefit;
	_callee_benefit += sub_range->_callee_benefit;
	_priority += sub_range->_priority;
	_live_ops_num += sub_range->live_ops_count();
    }
    
}

void
LiveSubRegion::print() {
    for (int i = 0; i < _level; i++) {
	cout << " ";
    }
    for (List_iterator<LiveUnit*> iter(_live_units); iter != 0; iter++) {
	LiveUnit* sub_range = *iter;
	cout << sub_range->_region->id() << " " << endl;
    }
    for (List_iterator<LiveUnit*> iter2(_live_units); iter2 != 0; iter2++) {
	LiveUnit* sub_range = *iter2;
	sub_range->print();
    }
}
