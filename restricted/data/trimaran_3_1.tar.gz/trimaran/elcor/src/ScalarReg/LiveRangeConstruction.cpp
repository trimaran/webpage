/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           LiveRangeConstruction.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include <adjlist_graph.h>
#include <attributes.h>
#include <edge_utilities.h>
#include <iterators.h>
#include <opcode_properties.h>
#include <operand.h>
#include <region.h>

#include "GlobalBoundMap.h"
#include "LiveRange.h"
#include "LiveUnit.h"
#include "LiveBlock.h"
#include "LiveSubRegion.h"
#include "LiveRangeConstruction.h"
#include "ListRegionTilingGraph.h"


static List<LiveUnit*>
local_liveness_walk (Compound_region* r, 
		     Map<Operand, Pred_cookie>& liveness_map_,
		     Op* entry_op = NULL, Op* exit_op = NULL);

static List<LiveUnit*>
construct_live_units(Compound_region* r_);

//
// This functions is to consruct live-ranges for each variable.
// If a given region is the block (HB/BB), a LiveRange is constructed
// with set of LiveBlock*.
// If a given region is a compound region of blocks, it will call 
// construct_live_ranges() recursively with sub-region and LiveUnit is
// contructed with set of LiveSubRegion*
//
List<LiveRange*>
construct_live_ranges(Compound_region* r_)
{
    List<LiveRange*> lrs;
    List<LiveUnit*> live_units = construct_live_units(r_);
    for (List_iterator<LiveUnit*> iter(live_units); iter!=0; iter++) {
	LiveUnit* lu = *iter;
	LiveRange* lr = new LiveRange(lu->variable());
	lr->set_live_unit(lu);
	lrs.add_tail(lr);
    }
    return lrs;
}


static List<LiveUnit*>
construct_live_units(Compound_region* r_) 
{
    List<LiveUnit*> lr_list;

    if (r_->is_bb() || r_->is_hb()) {

	Map<Operand, Pred_cookie> pred_map;
	lr_list = local_liveness_walk((Compound_region*)r_, pred_map);
    }
    else { // recursrion call
	Map<Operand, LiveUnit*> lr_map;
	List<LiveUnit*> lrs;

	// traverse all sub-region by topological sort order
	// Alist_region_tiling_graph c_graph(r_,GRAPH_OPS_PLUS );
	ListRegionTilingGraph c_graph(r_,GRAPH_OPS_PLUS );
	for (Alist_graph_post_dfs r_iter(c_graph, UP);
	     r_iter != 0; r_iter++) {
	    int index = *r_iter;
	    List<LiveUnit*> sub_lrs = construct_live_units((Compound_region*) c_graph.b_map[index]);

	    // for each LiveUnit l constructed in a sub-region, find/create 
	    // parent LiveUnit p and add l to p
	    for (List_iterator<LiveUnit*> m_iter(sub_lrs); m_iter != 0; m_iter++) {
		LiveUnit* sub_lr = *m_iter;
		Operand var = sub_lr->variable();
		
		LiveUnit* parent_lu = NULL;
		if (lr_map.is_bound(var)) {
		    parent_lu = lr_map.value(var);
		    parent_lu->add_sub_liveunit(sub_lr);
		    parent_lu->add_live_ref(sub_lr->live_refs());
		}
		else {
		    parent_lu = new LiveSubRegion(r_, var);
		    parent_lu->add_sub_liveunit(sub_lr);
		    lr_map.bind(var, parent_lu);
		    lr_list.add_tail(parent_lu);
		}

	    }

	} // end of first for loop
    } // end of else. recurion call

    for (List_iterator<LiveUnit*> iter(lr_list); iter != 0; iter++) {
	LiveUnit* lr = *iter;
	lr->set_priority();
	lr->set_entry_edges();
	lr->set_exit_edges();
    }
    return lr_list;

}




// This is the code for initializing pseudo sources before you call the
// Op_pseudo_sources iterator. Call this function before any call to
// Op_pseudo_sources, preferably call it right in the beginning of the
// intra-region allocation.
//
// This is a cleaned-up version of some of the code in reaching definitions. 
// See the function 
//  Reaching_defs_maps::Reaching_defs_maps 
// (between the comments // use liveness and // create the operand map)
// in file
//	 reaching_defs_solver.cpp.
//
//

static void 
initialize_pseudo_sources(Compound_region* r)
{
    //
    // Use liveness information for entry/exit processing
    //
    // Compute pseudo defs for entry operations
    //
    for (Region_entry_ops en_op_iter(r) ; en_op_iter != 0 ; en_op_iter++) {
	Op* cur_op = *en_op_iter ;
	List<Operand>* entry_pseudo_defs = 
	    (List<Operand>*)get_generic_attribute(cur_op, "entry_pseudo_defs") ;
	if (entry_pseudo_defs == NULL) {
	    entry_pseudo_defs = new List<Operand>();
	}
	else {
	    entry_pseudo_defs->clear() ;
	}
	for(Region_entry_edges en_edge_iter(r) ; en_edge_iter != 0 ;
	    en_edge_iter++) {
	    Edge* cur_edge = *en_edge_iter ;
	    if (cur_edge->dest() != cur_op) continue ;
	    
	    Liveness_info* linfo = get_liveness_info(cur_edge) ;
	    if (linfo) {
		for (Liveness_info_iterator li(*linfo) ; li != 0 ; li++) {
		    Operand& tmpoper = *li ;
		    if (!entry_pseudo_defs->is_member(tmpoper)){
			entry_pseudo_defs->add_tail(tmpoper) ;
		    }
		}
	    }
	}

	if (entry_pseudo_defs->is_empty()) {
	    delete entry_pseudo_defs ;
	}
	else {
	    set_generic_attribute(cur_op, "entry_pseudo_defs", entry_pseudo_defs);
	}
    }
   
    //
    // Now compute pseudo uses for exit ops
    //

    for(Region_exit_ops ex_op_iter(r) ; ex_op_iter != 0 ; ex_op_iter++) {
	Op* cur_op = *ex_op_iter ;
	List<Operand>* taken_exit_pseudo_uses = 
	    (List<Operand>*)get_generic_attribute(cur_op, "taken_exit_pseudo_uses") ;
	List<Operand>* fallthrough_exit_pseudo_uses = 
	    (List<Operand>*)get_generic_attribute(cur_op, "fallthrough_exit_pseudo_uses") ;
	if (taken_exit_pseudo_uses == NULL) {
	    taken_exit_pseudo_uses = new List<Operand>();
	}
	else {
	    taken_exit_pseudo_uses->clear() ;
	}
	if (fallthrough_exit_pseudo_uses == NULL) {
	    fallthrough_exit_pseudo_uses = new List<Operand>();
	}
	else {
	    fallthrough_exit_pseudo_uses->clear() ;
	}
	for(Region_exit_edges ex_edge_iter(r) ; ex_edge_iter != 0 ; 
	    ex_edge_iter++) {
	    Edge* cur_edge = *ex_edge_iter ;
	    if (cur_edge->src() != cur_op) continue ;
	    
	    List<Operand>* tmp_exit_pseudo_uses ;
	    if (is_fall_through(cur_edge)) {
		tmp_exit_pseudo_uses = fallthrough_exit_pseudo_uses ;
	    }
	    else {
		tmp_exit_pseudo_uses = taken_exit_pseudo_uses ;
	    }
	 
	    Liveness_info* linfo = get_liveness_info(cur_edge) ;
	    if (linfo) {
		for (Liveness_info_iterator li(*linfo) ; li != 0 ; li++) {
		    Operand& tmpoper = *li ;
		    if (!tmp_exit_pseudo_uses->is_member(tmpoper)){
			tmp_exit_pseudo_uses->add_tail(tmpoper) ;
		    }
		}
	    }
	}
	if (taken_exit_pseudo_uses->is_empty()) {
	    delete taken_exit_pseudo_uses ;
	}
	else {
	    set_generic_attribute (cur_op, "taken_exit_pseudo_uses", taken_exit_pseudo_uses) ;
	}
	if (fallthrough_exit_pseudo_uses->is_empty()) {
	    delete fallthrough_exit_pseudo_uses ;
	}
	else {
	    set_generic_attribute (cur_op, "fallthrough_exit_pseudo_uses", fallthrough_exit_pseudo_uses) ;
	}
    }
}



// 
// scan a operation by operation in backward order in Hyperblock or
// Basicblock and returns created Map<Operand, LiveBlock*> for each 
// variable in a given region(HB/BB) 
//
static List<LiveUnit*>
local_liveness_walk (
    Compound_region* r, 
    Map<Operand, Pred_cookie>& liveness_map_,
    Op* entry_op, 
    Op* exit_op)
{
    List<LiveUnit*> lr_list;
    Map<Operand, LiveBlock*> live_block_map;
    double region_freq = 0;

    Pred_jar pj(r);
    initialize_pseudo_sources(r);
    for (Region_ops_reverse_C0_order ops(r, exit_op); ops != 0; ops++) {

	Op* op = *ops;
	if (entry_op != NULL && op == entry_op) break;

	if (is_branch(op)){
	    for(Op_pseudo_sources lives(op); lives != 0; lives++) {
		El_ref cur_ref = lives.get_ref();
		Operand& var = cur_ref.get_operand();
		if (!var.is_reg()) {
		    continue;
                }

                if (var.is_rotating()) {
                    // rotate register allocation for static variable
                    // will be added.
                    continue;
                }

		// Pred_cookie guard = pj.get_lub_guard(cur_ref);
		Pred_cookie guard = Pred_jar::get_true();
		if (liveness_map_.is_bound(cur_ref.get_operand())) {
		    Pred_cookie& p = liveness_map_.value(cur_ref.get_operand());
		    p.lub_sum(guard);
		    if (p == Pred_jar::get_false()) {
			liveness_map_.unbind(cur_ref.get_operand());
			//live_block_map.unbind(cur_ref.get_operand());
		    }
		}
		else {
		    if (guard != Pred_jar::get_false()) {
			liveness_map_.bind(cur_ref.get_operand(), guard);
		    }
		}
	    }

	    List<Edge*> out_edges = ((Region*)op)->outedges();
	    for (List_iterator<Edge*> e_iter(out_edges); e_iter!=0; e_iter++) {
		Edge* e = *e_iter;
		Control_flow_freq* cf_freq = get_control_flow_freq(e);
		if (cf_freq)
		    region_freq += cf_freq->freq;
    
	    }
	}

	// update LiveBlock
	for (Map_iterator<Operand, Pred_cookie> iter(liveness_map_); iter != 0; iter++) {
	    Pair<Operand, Pred_cookie>& ele = *iter;
	    Operand& var = ele.first;

            // Rotating registers are not used for static register allocation
            // right now
            assert(var.is_rotating()==false);

	    LiveBlock* a_block = NULL;
	    if (live_block_map.is_bound(var)) {
		a_block = live_block_map.value(var);
	    }
	    else {
		a_block = new LiveBlock(r, var);
                if (var.is_rotating()) {
                    // rotate register allocation for static variable
                    // will be added.
                    //_rr_lrs += cur_lr;
                }
                else {
		    lr_list.add_tail(a_block);
		    live_block_map.bind(var, a_block);
                }
	    }

	    a_block->add_live_op(op, ele.second);
	    
	    if (is_brl(op)) {
		a_block->_freq_map.bind(op, region_freq);
	    }
	}

	for(Op_all_dests dests(op); dests != 0; dests++) {

	    El_ref cur_ref = dests.get_ref();
            Operand& var = cur_ref.get_operand();

 	    if (!var.is_reg()) {
		// only Reg operand is the target for static register
		// allocation
		continue;
	    }

            if (var.is_rotating()) {
                // rotate register allocation for static variable
                // will be added.
                continue;
            }

	    Pred_cookie guard = pj.get_glb_guard(cur_ref);

	    LiveBlock* a_block = NULL;
	    if (live_block_map.is_bound(var)) {
		a_block = live_block_map.value(var);
	    }
	    else {
		a_block = new LiveBlock(r, var);
		lr_list.add_tail(a_block);
		live_block_map.bind(var, a_block);
	    }

	    if (liveness_map_.is_bound(cur_ref.get_operand())) {
		Pred_cookie& p = liveness_map_.value(cur_ref.get_operand());
		p.lub_diff(guard);
		if (p == Pred_jar::get_false()) {
		    liveness_map_.unbind(cur_ref.get_operand());
		    //live_block_map.unbind(cur_ref.get_operand());
		}
	    }
	    else {
                // This definition is dead code.
                // Do not bind this variable to liveness map.
                // liveness_map_.bind(cur_ref.get_operand(), guard)
                a_block->add_live_op(op, guard);
	    }

	    a_block->add_live_ref(cur_ref);
	    a_block->_freq_map.bind(op, region_freq);
	}

	for(Op_all_inputs ins(op); ins != 0; ins++) {
	    El_ref cur_ref = ins.get_ref();
            Operand& var = cur_ref.get_operand();
	    Pred_cookie guard = pj.get_lub_guard(cur_ref);

 	    if (!var.is_reg()) {
		// only Reg operand is the target for static register
		// allocation
		continue;
	    }

            if (var.is_rotating()) {
                // rotate register allocation for static variable
                // will be added.
                continue;
            }

	    if (liveness_map_.is_bound(var)) {
		Pred_cookie& p = liveness_map_.value(cur_ref.get_operand());
		p.lub_sum(guard);
	    }
	    else {
		liveness_map_.bind(var, guard);
	    }

	    LiveBlock* a_block = NULL;
	    if (live_block_map.is_bound(var)) {
		a_block = live_block_map.value(var);
	    }
	    else {
		a_block = new LiveBlock(r, var);
		lr_list.add_tail(a_block);
		live_block_map.bind(var, a_block);
	    }

	    a_block->add_live_ref(cur_ref);
	    a_block->_freq_map.bind(op, region_freq);
	    a_block->add_live_op(op, liveness_map_.value(var));
	}
    } // end of for

    return lr_list;
}



