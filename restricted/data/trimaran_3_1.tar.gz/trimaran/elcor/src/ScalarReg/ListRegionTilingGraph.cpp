/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           ListRegionTilingGraph.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include "ListRegionTilingGraph.h"
#include "iterators.h"
#include "control_analysis_solver.h"
#include "list_set.h"
#include "op.h"
#include "edge.h"
#include "el_dot_tools.h"
#include "opcode_properties.h"


////////////////////////////////////////////////////////////////////
//
// ListRegionTilingGraph   Graph of a tiling of region hierarchy
//
///////////////////////////////////////////////////////////////////

ListRegionTilingGraph::ListRegionTilingGraph() 
{}

ListRegionTilingGraph::ListRegionTilingGraph(Region* r, GRAPH_CATEGORY gc)
{
      int List_set_size = 1007 ;
   if (gc == GRAPH_OPS) {
      int op_count = 0 ;
      for(Region_all_ops ri(r) ; ri != 0 ; ri++) op_count++ ;
      List_set_size = op_count ;
   }
   // Construct a list of regions and their successors
   List_set<Region*> region_set;

   switch(gc) {
      case GRAPH_SUBREGIONS:
      {
	 for(Region_subregions ri(r) ; ri != 0 ; ri++) {
	    region_set += (*ri) ;
	 }
      }
      break ;
      case GRAPH_OPS:
      {
	 for(Region_all_ops ri(r) ; ri != 0 ; ri++) {
	    region_set += (*ri) ;
	 }
      }
      break ;
      case GRAPH_OPS_PLUS:
      {
	 for(Region_all_ops ri(r) ; ri != 0 ; ri++) {
	    region_set += ((*ri)->parent()) ;
	 }
      }
      break ;
      case GRAPH_BBS:
      case GRAPH_HBS:
      case GRAPH_HBS_SESE:      
      case GRAPH_HBS_BBS:
      case GRAPH_HBS_BBS_SESE:      
      {
	 Dlist<Region*> rstack ;
	 rstack.push(r) ;
	 while (!rstack.is_empty()) {
	    Region* tmpr = rstack.pop() ;
	    bool check_cond ;
	    switch(gc) {
	       case GRAPH_BBS:
               check_cond = tmpr->is_bb() ;
	       break ;
	       case GRAPH_HBS:
	       case GRAPH_HBS_SESE:
	       check_cond = tmpr->is_hb() ;
	       break ;
	       case GRAPH_HBS_BBS:
	       case GRAPH_HBS_BBS_SESE:
	       check_cond = (tmpr->is_hb() || tmpr->is_bb());	     
	       break ;
	       default :
	       assert(0) ;
	       ;
	    }
	    if (check_cond) {
	       region_set += tmpr ;
	       if ((tmpr->is_hb()) && 
		   ((gc == GRAPH_HBS_SESE) || (gc == GRAPH_HBS_BBS_SESE))) {
		  for (Region_exit_ops rxop(tmpr) ; rxop != 0 ; rxop++) {
		     region_set += *rxop ;
		  }
	       }
	    }
	    else {
	       for (Region_subregions ri(tmpr) ; ri != 0 ; ri++) {
		  rstack.push(*ri) ;
	       }
	    }
	 }
      }
      break ;
      default:
      assert(0) ;
      ;
   }
   // Sort the regions into graph_entry_regions + intermediate_regions +
   // graph_exit_regions
   List_set<Region*> region_entry_set;
   List_set<Region*> region_exit_set;
   List_set<Region*> region_orig_exit_set;
   
   for (Region_entry_ops rent(r) ; rent != 0 ; rent++) {
      Region* tmpr = *rent ;
      Region* largest_parent = 0 ;
      while (tmpr) {
	 if (region_set.is_member(tmpr)) {
	    largest_parent = tmpr ;
	 }
	 tmpr = tmpr->parent() ;
      }
      assert(largest_parent) ;
      region_entry_set += largest_parent ;
   }
   for (Region_exit_ops rex(r) ; rex != 0 ; rex++) {
      Region* tmpr = *rex ;
      Region* largest_parent = 0 ;
      while (tmpr) {
	 if (region_set.is_member(tmpr)) {
	    largest_parent = tmpr ;
	 }
	 tmpr = tmpr->parent() ;
      }
      assert(largest_parent) ;
      region_exit_set += largest_parent ;
   }
   region_orig_exit_set = region_exit_set;
   region_exit_set -= region_entry_set ;
   region_set -= region_entry_set ;
   region_set -= region_exit_set ;

   List_set_iterator<Region*> rsit ;
   List<Region*> region_list ;

   for (rsit(region_entry_set) ; rsit != 0 ; rsit++) {
      region_list.add_tail(*rsit) ;
   }
   for (rsit(region_set) ; rsit != 0 ; rsit++) {
      region_list.add_tail(*rsit) ;
   }
   for (rsit(region_exit_set) ; rsit != 0 ; rsit++) {
      region_list.add_tail(*rsit) ;
   }

   region_set += region_entry_set ;
   region_set += region_exit_set ;

   // Assign dense int's to regions
   node_count = region_list.size() ;
   
   b_map.resize(node_count) ;
   succ_list.resize(node_count) ;
   pred_list.resize(node_count) ;
   int counter = 0 ;
   for (List_iterator<Region*> si2(region_list) ; si2 != 0 ; si2++) {
      f_map.bind(*si2,counter) ;
      b_map[counter] = *si2 ;
      counter++ ;
   }

   // Find the adjacency list
   // For the special HB case (dataflow analysis treatment of HB's,
   //     make HB node point to the HB exit ops and HB exit ops to
   //     the true successors of HB
   //

   
   for (int nodei = 0 ; nodei < node_count ; nodei++)
   {
      Region* tmp_reg = b_map[nodei] ;
      int r_num = f_map.value(tmp_reg) ;
      if ((tmp_reg->is_hb() || tmp_reg->is_op()) &&
	  ((gc == GRAPH_HBS_SESE) || (gc == GRAPH_HBS_BBS_SESE)))
      {
	 if (tmp_reg->is_hb()) {
	    for (Region_exit_ops rxop(tmp_reg) ; rxop != 0 ; rxop++)
	    {
	       // hook up the HB node to the exit op nodes
	       int node_number =  f_map.value(*rxop) ;
	       if (!succ_list[r_num].is_member(node_number))
	       {
		  succ_list[r_num].add_tail(node_number) ;
	       }
	       if (!pred_list[node_number].is_member(r_num))
	       {
		  pred_list[node_number].add_tail(r_num);
	       }
	       // hook up the exit op node to its out-of-HB successor. 
               // The exit edge cannot leave the region itself
	       for (Op_outedges edgei(*rxop,CONTROL0_OUTEDGES) ;
		    edgei != 0 ; edgei++) {
		  if ((region_edge_crosses_boundary(tmp_reg, *edgei)) &&
                      (!region_edge_crosses_boundary(r, *edgei))) { 
		     Region* tr = (*edgei)->dest() ;
		     assert(tr) ;
		     while (!region_set.is_member(tr))
		     {
			tr = tr->parent() ;
			if (tr == 0)
			{
			   //
			   // Check if this edge leaves the top level region
			   //
			   if (region_contains_edge(r,*edgei)) {
			      El_punt("ERROR: The region hierarchy does not contain a tiling of the requested type") ;
			   }
			   else {
			      break ;
			   }
			}
		     }
		     if (tr == 0) continue ;
		     int node_number2 = f_map.value(tr) ;
		     if (!succ_list[node_number].is_member(node_number2))
		     {
			succ_list[node_number].add_tail(node_number2) ;
		     }
		     if (!pred_list[node_number2].is_member(node_number))
		     {
			pred_list[node_number2].add_tail(node_number) ;
		     }
		     
		  }
	       }
	    }
	 } // else skip the ops
      }
      else {
	 for (Region_exit_edges rex(tmp_reg) ; rex != 0 ; rex++)
	 {
            if (region_edge_crosses_boundary(r, *rex)) continue; // don't consider edges that leave the region
	    Region* tr = (*rex)->dest() ;
	    assert(tr) ;
	    while (!region_set.is_member(tr))
	    {
	       tr = tr->parent() ;
	       if (tr == 0)
	       {
		  if (region_contains_edge(r,*rex)) {
		     El_punt("ERROR: The region hierarchy does not contain a tiling of the requested type") ;
		  }
		  else {
		     break ;
		  }
	       }
	    }
	    if (tr == 0) continue ;
	    int node_number = f_map.value(tr) ;
	    if (!succ_list[r_num].is_member(node_number))
	    {
	       succ_list[r_num].add_tail(node_number) ;
	    }
	    if (!pred_list[node_number].is_member(r_num))
	    {
	       pred_list[node_number].add_tail(r_num) ;
	    }
	 }
      }
   }
   node_count = succ_list.dim() ;
}
