/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1996 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

///////////////////////////////////////////////////////////////////////////
//
//      File:           el_sreg_impact.cpp
//      Author:         Scott A. Mahlke
//      Created:        October 1996
//      Description:    Interface routines to Impact register allocator
//
///////////////////////////////////////////////////////////////////////////

#include "defs.h"
#include "el_extern.h"
#include "el_sreg_driver.h"
#include "el_sreg_impact.h"

static int *caller_int_reg_map;
static int *callee_int_reg_map;
static int *caller_flt_reg_map;
static int *callee_flt_reg_map;
static int *caller_dbl_reg_map;
static int *callee_dbl_reg_map; 
static int *caller_prd_reg_map;
static int *callee_prd_reg_map;
static int *caller_btr_reg_map;
static int *callee_btr_reg_map;

static Set caller_int_set = NULL;
static Set callee_int_set = NULL;
static Set caller_float_set = NULL;
static Set callee_float_set = NULL;
static Set caller_double_set = NULL;
static Set callee_double_set = NULL;
static Set caller_predicate_set = NULL;
static Set callee_predicate_set = NULL;
static Set caller_btr_set = NULL;
static Set callee_btr_set = NULL;

/* Need to modify to interface to the mdes!! */
int Lsched_loads_per_cycle(void)
{
    return (2);
}

/* Need to modify to interface to the mdes!! */
int Lsched_stores_per_cycle(void)
{
    return (2);
}

int Lsched_issue_time(L_Oper *oper)
{
    L_Attr *attr;

    attr = L_find_attr(oper->attr, "isl");
    if (attr == NULL)
	return (-1);
    else
	return (attr->field[0]->value.i);
}

int Lsched_latency(L_Oper *oper)
{
    L_Attr *attr;

    attr = L_find_attr(oper->attr, "isl");
    if (attr == NULL)
        return (0);
    else 
	return (attr->field[2]->value.i);
}

/*
 *	This is a fake version of the real op_flag_set routine in liblmdes
 */
int op_flag_set (unsigned int opcode, int mask)
{
    if (mask & OP_FLAG_JSR) {
	if ((opcode == Lop_JSR) || (opcode == Lop_JSR_FS) ||
            (opcode == PLAYDOHop_BRL))
	    return (1);
    }
    if (mask & OP_FLAG_RTS) {
	if ((opcode == Lop_RTS) || (opcode == Lop_RTS_FS))
	    return (1);
    }
    if (mask & OP_FLAG_LOAD) {
	if ((opcode >= PLAYDOHop_L_B_V1_V1) && (opcode <= PLAYDOHop_LI_W_C3_C3))
	    return (1);
	if ((opcode >= PLAYDOHop_FL_S_V1_V1) && (opcode <= PLAYDOHop_FLI_D_C3_C3))
	    return (1);
	if ((opcode >= PLAYDOHop_LDS_B_V1_V1) && (opcode <= PLAYDOHop_FLDV_D))
	    return (1);
    }
    if (mask & OP_FLAG_STORE) {
	if ((opcode >= PLAYDOHop_S_B_V1) && (opcode <= PLAYDOHop_SI_W_C3))
	    return (1);
	if ((opcode >= PLAYDOHop_FS_S_V1) && (opcode <= PLAYDOHop_FSI_D_C3))
	    return (1);
    }
    if (mask & OP_FLAG_CBR) {
	if ((opcode == PLAYDOHop_BRCT) || (opcode == PLAYDOHop_BRCF) ||
	    (opcode == PLAYDOHop_BRLC))
	    return (1);
	if ((opcode >= PLAYDOHop_BRF_B_B_B) && (opcode <= PLAYDOHop_BRDVF))
	    return (1);
    }
    if (mask & OP_FLAG_JMP) {
	if (opcode == PLAYDOHop_BRU)
	    return (1);
    }
    if (mask & OP_FLAG_IGNORE) {
	if ((opcode == Lop_DEFINE) || (opcode == Lop_PROLOGUE) ||
	    (opcode == Lop_EPILOGUE))
	    return (1);
    }

    return (0);
}


/*
 *      Just check if function hyperblock flag is set correctly
 *      so we can handle old files, can get rid of this eventually.
 */
static void L_check_func_hyperblock_flag(L_Func *fn)
{
    int func_flag, cb_flag;
    L_Cb *cb;

    cb_flag = 0;
    for (cb=fn->first_cb; cb!=NULL; cb=cb->next_cb) {
        if (L_EXTRACT_BIT_VAL(cb->flags, L_CB_HYPERBLOCK)) {
            cb_flag = 1;
            break;
        }
        if (L_EXTRACT_BIT_VAL(cb->flags, L_CB_SOFTPIPE) &&
	    L_EXTRACT_BIT_VAL(cb->flags, L_CB_VIOLATES_LC_SEMANTICS)) {
            cb_flag = 1;
            break;
        }
    }

    func_flag = L_EXTRACT_BIT_VAL(fn->flags, L_FUNC_HYPERBLOCK);
    if (cb_flag!=func_flag) {
        fprintf(stderr, "Limpact: WARNING - hyperblock func flag not correct!\n");
        if (cb_flag) {
            fn->flags = L_SET_BIT_FLAG(fn->flags, L_FUNC_HYPERBLOCK);
        }
        else {
            fn->flags = L_CLR_BIT_FLAG(fn->flags, L_FUNC_HYPERBLOCK);
        }
    }
}

/* Hack to fixup predicate attributes for spill code inserted SAM 10-94 */
static void L_fix_vpred_attrs(L_Func *fn)
{
    L_Cb *cb;
    L_Oper *oper, *ptr;
    L_Attr *attr, *new_attr;

    for (cb=fn->first_cb; cb!=NULL; cb=cb->next_cb) {
	if (! L_EXTRACT_BIT_VAL(cb->flags, L_CB_HYPERBLOCK))
	    continue;
	for (oper=cb->first_op; oper!=NULL; oper=oper->next_op) {
	    if (! L_EXTRACT_BIT_VAL(oper->flags, L_OPER_SPILL_CODE))
		continue;
	    if (oper->pred[0]==NULL)
		continue;

	    if (L_store_opcode(oper)) {
		/* search up first */
		for (ptr=oper->prev_op; ptr!=NULL; ptr=ptr->prev_op) {
		    if (L_EXTRACT_BIT_VAL(ptr->flags, L_OPER_SPILL_CODE))
			continue;
		    if (L_same_operand(oper->pred[0], ptr->pred[0]))
			break;
		}
		if (ptr==NULL) {	/* try down */
		    for (ptr=oper->next_op; ptr!=NULL; ptr=ptr->next_op) {
		        if (L_EXTRACT_BIT_VAL(ptr->flags, L_OPER_SPILL_CODE))
			    continue;
		        if (L_same_operand(oper->pred[0], ptr->pred[0]))
			    break;
		    }
		}
		if (ptr==NULL)
		    L_punt("L_fix_vpred_attrs: no match found for op %d", oper->id);

		attr = L_find_attr(ptr->attr, L_VPRED_PRD_ATTR_NAME);
		if (attr==NULL)
		    L_punt("L_fix_vpred_attrs: no vpred attr found");
		new_attr = L_copy_attr_element(attr);
		oper->attr = L_concat_attr(oper->attr, new_attr);
	    }

	    else if (L_load_opcode(oper) || L_int_add_opcode(oper)) {
		/* look down first */
		for (ptr=oper->next_op; ptr!=NULL; ptr=ptr->next_op) {
		    if (L_EXTRACT_BIT_VAL(ptr->flags, L_OPER_SPILL_CODE))
			continue;
		    if (L_same_operand(oper->pred[0], ptr->pred[0]))
			break;
		}
		if (ptr==NULL) {		/* try up */
		    for (ptr=oper->prev_op; ptr!=NULL; ptr=ptr->prev_op) {
		        if (L_EXTRACT_BIT_VAL(ptr->flags, L_OPER_SPILL_CODE))
			    continue;
		        if (L_same_operand(oper->pred[0], ptr->pred[0]))
			    break;
		    }
		}
		if (ptr==NULL)
		    L_punt("L_fix_vpred_attrs: no match found for op %d, oper->id");

		attr = L_find_attr(ptr->attr, L_VPRED_PRD_ATTR_NAME);
		if (attr==NULL)
		    L_punt("L_fix_vpred_attrs: no vpred attr found");
		new_attr = L_copy_attr_element(attr);
		oper->attr = L_concat_attr(oper->attr, new_attr);
	    }

	    else {
		L_punt("L_fix_vpred_attrs: illegal spill oper");
	    }
	}
    }
}

/******************************************************************************\
 *
 * Functions which provide penalties for use of callee and caller save 
 * registers.
 *
\******************************************************************************/

#define LOAD_COST       1.0
#define STORE_COST      1.0

double R_callee_cost(int ctype, int leaf, int callee_allocated)
{
    double      cost;
    int         loads_per_cycle, stores_per_cycle;

    /* currently assumes uniform model */
    loads_per_cycle = Lsched_loads_per_cycle();
    stores_per_cycle = Lsched_stores_per_cycle();

    switch (ctype)
    {
        case L_CTYPE_INT:
        case L_CTYPE_FLOAT:
        case L_CTYPE_DOUBLE:
	case L_CTYPE_BTR:
            cost = LOAD_COST/loads_per_cycle + STORE_COST/stores_per_cycle;
            break;
        case L_CTYPE_PREDICATE:
            cost = 0;
            break;

        default:
            L_punt ("R_callee_cost: invalid ctype of %d", ctype);
    }

    return cost;
}

double R_caller_cost(int ctype, int leaf)
{
    double      cost;
    int         loads_per_cycle, stores_per_cycle;

    if ( leaf ) return 0;

    /* currently assumes uniform model */
    loads_per_cycle = Lsched_loads_per_cycle();
    stores_per_cycle = Lsched_stores_per_cycle();

    switch (ctype)
    {
        case L_CTYPE_INT:
        case L_CTYPE_FLOAT:
        case L_CTYPE_DOUBLE:
	case L_CTYPE_BTR:
            cost = LOAD_COST/loads_per_cycle + STORE_COST/stores_per_cycle;
            break;
        case L_CTYPE_PREDICATE:
            cost = 0;
            break;

        default:
            L_punt ("R_caller_cost: invalid ctype of %d", ctype);
    }

    return cost;
}

double R_spill_load_cost(int ctype)
{
    double      cost;
    int         loads_per_cycle;

    /* currently assumes uniform model */
    loads_per_cycle = Lsched_loads_per_cycle();

    switch (ctype)
    {
        case L_CTYPE_INT:
        case L_CTYPE_FLOAT:
        case L_CTYPE_DOUBLE:
            cost = LOAD_COST;
            break;
        case L_CTYPE_PREDICATE:
            cost = LOAD_COST;
            break;

        default:
            L_punt ("R_spill_load_cost: invalid ctype of %d", ctype);
    }

    return cost;
}

double R_spill_store_cost(int ctype)
{
    double      cost;
    int         stores_per_cycle;

    /* currently assumes uniform model */
    stores_per_cycle = Lsched_stores_per_cycle();

    switch (ctype)
    {
        case L_CTYPE_INT:
        case L_CTYPE_FLOAT:
        case L_CTYPE_DOUBLE:
            cost = STORE_COST;
            break;
        case L_CTYPE_PREDICATE:
            cost = STORE_COST;
            break;

        default:
            L_punt ("R_spill_store_cost: invalid ctype of %d", ctype);
    }

    return cost;
}


/****************************************************************\
 *
 * Register allocator callbacks for insertion of spill code
 *
\****************************************************************/

L_Attr *O_create_reg_alloc_attr(int type_flag)
{
    L_Attr *attr;

    switch (type_flag) {
	case 0:
            attr = L_new_attr("sreg_spill", 0);
	    break;
	case 1:
            attr = L_new_attr("sreg_caller", 0);
	    break;
	case 2:
            attr = L_new_attr("sreg_callee", 0);
	    break;
	default:
	    L_punt("O_create_reg_alloc_attr: unknown type %d", type_flag);
    }

    return (attr);
}

int O_require_callee_save_code(int ctype)
{
    /* always insert callee save code for HP playdoh */
    if (M_playdoh_model==M_PLAYDOH_V1_HP) {
	switch (ctype) {
	    case L_CTYPE_PREDICATE:
	    case L_CTYPE_INT:
	    case L_CTYPE_FLOAT:
	    case L_CTYPE_DOUBLE:
	    case L_CTYPE_BTR:
		return (1);
	    default:
		L_punt("O_require_callee_save_code: illegal ctype received");
	}
    }

    /* Sparc has register windows for int/fp regs, so no callee save code needed */
    else if (M_playdoh_model==M_PLAYDOH_V1_SUN) {
	switch (ctype) {
	    case L_CTYPE_INT:
	    case L_CTYPE_FLOAT:
	    case L_CTYPE_DOUBLE:
		return (0);
	    case L_CTYPE_PREDICATE:
	    case L_CTYPE_BTR:
		return (1);
	    default:
		L_punt("O_require_callee_save_code: illegal ctype received");
	}
    }

    else {
	L_punt("O_require_callee_save_code: illegal value of M_playdoh_model %d",
		M_playdoh_model);
    }
    return (0);
}

L_Oper* O_address_add(int offset, L_Operand **pred, int type_flag, int operand_ptype)
{
    int i;
    L_Oper *new_oper;
    L_Attr *attr;

    new_oper = L_create_new_op(Lop_ADD);
    new_oper->flags = L_SET_BIT_FLAG(new_oper->flags, L_OPER_SPILL_CODE);
    new_oper->dest[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
    new_oper->src[0] = L_new_macro_operand(L_MAC_SP, L_CTYPE_INT, L_PTYPE_NULL);
    new_oper->src[1] = L_new_gen_int_operand(offset);

    /* flag the add as being inserted by the register allocator, so the spill
        offset can be later updated */
    attr = L_new_attr("regalloc1",1);
    L_set_int_attr_field(attr, 0, type_flag);
    new_oper->attr = L_concat_attr(new_oper->attr, attr);

    attr = O_create_reg_alloc_attr(type_flag);
    new_oper->attr = L_concat_attr(new_oper->attr, attr);

    /* Set the predicates of oper1 and oper2 */
    if (pred!=NULL) {
        for (i=0; i<L_max_pred_operand; i++) {
            new_oper->pred[i] = L_copy_operand(pred[i]);
        }
        if ((operand_ptype==L_PTYPE_UNCOND_T) ||
		(operand_ptype==L_PTYPE_UNCOND_F)) {
            L_delete_operand(new_oper->pred[0]);
            new_oper->pred[0] = NULL;
        }
    }

    return (new_oper);
}

L_Oper* O_fill_reg(int reg, int type, L_Operand *operand, int fill_offset,
			L_Operand **pred, int type_flag)
{
    int op, i, pop;
    L_Oper *new_oper1, *new_oper2;
    L_Attr *attr;
    
    switch (operand->ctype) {
        case L_CTYPE_INT:
	case L_CTYPE_BTR:
	    op = Lop_LD_I;
	    pop = PLAYDOHop_L_W_C1_C1;
    	    break;
        case L_CTYPE_FLOAT:
	    op = Lop_LD_F;
	    pop = PLAYDOHop_FL_S_C1_C1;
	    break;
        case L_CTYPE_DOUBLE:
            op = Lop_LD_F2;
	    pop = PLAYDOHop_FL_D_C1_C1;
	    break;
	case L_CTYPE_PREDICATE:
#if 0
	    op = Lop_PRED_LD;
	    break;
#endif
        default :
    	    L_punt("O_fill_reg: unsupported register type %d", operand->ctype);
    }
   
    /* Generate spill address */
    new_oper1 = O_address_add(fill_offset, pred, type_flag, operand->ptype);

    /* Generate the load op */
    new_oper2 = L_create_new_op(op);
    new_oper2->flags = L_SET_BIT_FLAG(new_oper2->flags,
					L_OPER_SPILL_CODE|L_OPER_SAFE_PEI);
    new_oper2->proc_opc = pop;
    new_oper2->src[0] = L_copy_operand(new_oper1->dest[0]);
    new_oper2->src[1] = L_new_gen_int_operand(0);

    if ( type == L_OPERAND_REGISTER )
        new_oper2->dest[0] = L_new_register_operand(reg,operand->ctype,L_PTYPE_NULL);
    else
        new_oper2->dest[0] = L_new_macro_operand(reg,operand->ctype,L_PTYPE_NULL);
   
    /* flag load as being inserted by the register allocator */
#if 0
    attr = L_new_attr("regalloc1", 1);
    L_set_int_attr_field(attr, 0, type_flag);
    new_oper2->attr = L_concat_attr(new_oper2->attr,attr);
#endif
    attr = O_create_reg_alloc_attr(type_flag);
    new_oper2->attr = L_concat_attr(new_oper2->attr, attr);
 
    /* Add the spill offset attribute to assist memory disambiguation */
    attr = L_new_attr("offset", 1);
    L_set_int_attr_field(attr, 0, fill_offset);
    new_oper2->attr = L_concat_attr(new_oper2->attr,attr);

    /* Set the predicates of oper1 and oper2 */
    if (pred!=NULL) {
        for (i=0; i<L_max_pred_operand; i++) {
            new_oper2->pred[i] = L_copy_operand(pred[i]);
        }
        if ((operand->ptype==L_PTYPE_UNCOND_T) ||
		(operand->ptype==L_PTYPE_UNCOND_F)) {
            L_delete_operand(new_oper2->pred[0]);
            new_oper2->pred[0] = NULL;
        }
    }

    new_oper1->next_op = new_oper2;
    
    return(new_oper1);
}


L_Oper* O_spill_reg(int reg, int type, L_Operand *operand, int spill_offset,
			L_Operand **pred, int type_flag)
{
    int op, i, pop;
    L_Oper *new_oper1, *new_oper2;
    L_Attr *attr;
    
    switch (operand->ctype) {
        case L_CTYPE_INT:
	case L_CTYPE_BTR:
	    op = Lop_ST_I;
	    pop = PLAYDOHop_S_W_C1;
    	    break;
        case L_CTYPE_FLOAT :
	    op = Lop_ST_F;
	    pop = PLAYDOHop_FS_S_C1;
	    break;
        case L_CTYPE_DOUBLE :
            op = Lop_ST_F2;
	    pop = PLAYDOHop_FS_D_C1;
	    break;
	case L_CTYPE_PREDICATE:
#if 0
	    op = Lop_PRED_ST;
	    break;
#endif
        default :
    	    L_punt("O_spill_reg: unsupported register type", operand->ctype);
    }

    /* Generate spill address */
    new_oper1 = O_address_add(spill_offset, pred, type_flag, operand->ptype);

    /* Generate the store op */
    new_oper2 = L_create_new_op(op);
    new_oper2->flags = L_SET_BIT_FLAG(new_oper2->flags,
					L_OPER_SPILL_CODE|L_OPER_SAFE_PEI);
    new_oper2->proc_opc = pop;
    new_oper2->src[0] = L_copy_operand(new_oper1->dest[0]);
    new_oper2->src[1] = L_new_gen_int_operand(0);
    if ( type == L_OPERAND_REGISTER )
	new_oper2->src[2] = L_new_register_operand(reg,operand->ctype,L_PTYPE_NULL);
    else 
        new_oper2->src[2] = L_new_macro_operand(reg,operand->ctype,0);

    /* flag store as being inserted by the register allocator */
#if 0
    attr = L_new_attr("regalloc1", 1);
    L_set_int_attr_field(attr, 0, type_flag);
    new_oper2->attr = L_concat_attr(new_oper2->attr,attr);
#endif
    attr = O_create_reg_alloc_attr(type_flag);
    new_oper2->attr = L_concat_attr(new_oper2->attr, attr);
   
    /* Add the spill offset attribute to assist memory disambiguation */
    attr = L_new_attr("offset", 1);
    L_set_int_attr_field(attr, 0, spill_offset);
    new_oper2->attr = L_concat_attr(new_oper2->attr,attr);

    if ( pred != NULL ) {
        for (i=0; i<L_max_pred_operand; i++) {
            new_oper2->pred[i] = L_copy_operand(pred[i]);
        }
        if ((operand->ptype==L_PTYPE_UNCOND_T) ||
		(operand->ptype==L_PTYPE_UNCOND_F)) {
            L_delete_operand(new_oper2->pred[0]);
            new_oper2->pred[0] = NULL;
        }
    } 
    
    new_oper1->next_op = new_oper2;
	
    return(new_oper1);
}


L_Oper *O_jump_oper(int opc, L_Cb *dest_cb)
{

    L_Oper *new_oper = L_create_new_op(opc);
    new_oper->src[0] = L_new_cb_operand(dest_cb); 

    return(new_oper);
}

static L_Oper *new_load_operation(int index, int type, int offset, int type_flag)
{
    L_Oper *oper;
    L_Attr *attr;

    switch (type) {
    case L_CTYPE_BTR:
	oper = L_create_new_op(Lop_LD_I);
	oper->proc_opc = PLAYDOHop_L_W_C1_C1;
	oper->dest[0] = L_new_register_operand(index, L_CTYPE_BTR, L_PTYPE_NULL);
	oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
	oper->src[1] = L_new_gen_int_operand(0);
	break;
    case L_CTYPE_INT:
	oper = L_create_new_op(Lop_LD_I);
	oper->proc_opc = PLAYDOHop_L_W_C1_C1;
	oper->dest[0] = L_new_register_operand(index, L_CTYPE_INT, L_PTYPE_NULL);
	oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
	oper->src[1] = L_new_gen_int_operand(0);
	break;
    case L_CTYPE_FLOAT:
    case L_CTYPE_DOUBLE:
	oper = L_create_new_op(Lop_LD_F2);
	oper->proc_opc = PLAYDOHop_FL_D_C1_C1;
	oper->dest[0] = L_new_register_operand(index, L_CTYPE_DOUBLE, L_PTYPE_NULL);
	oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
	oper->src[1] = L_new_gen_int_operand(0);
	break;
    case L_CTYPE_PREDICATE:
#if 0
	oper = L_create_new_op(Lop_PRED_LD);
	oper->dest[0] = L_new_register_operand(index, L_CTYPE_PREDICATE,
						L_PTYPE_NULL);
	oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
	oper->src[1] = L_new_gen_int_operand(0);
	break;
#endif
    default:
	L_punt("new_load_operation: illegal ctype %d", type);
    }

    oper->flags = L_SET_BIT_FLAG(oper->flags, L_OPER_SPILL_CODE|L_OPER_SAFE_PEI);

    /* Add attribute making as inserted by register allocator */
#if 0
    attr = L_new_attr("regalloc1", 1);
    L_set_int_attr_field(attr, 0, type_flag);
    oper->attr = L_concat_attr(oper->attr, attr);
#endif
    attr = O_create_reg_alloc_attr(type_flag);
    oper->attr = L_concat_attr(oper->attr, attr);

    /* Add the spill code offset attribute */
    attr = L_new_attr("offset", 1);
    L_set_int_attr_field(attr, 0, offset);
    oper->attr = L_concat_attr(oper->attr, attr);

    return oper;
}

static L_Oper *new_store_operation(int index, int type, int offset, int type_flag)
{
    L_Oper *oper;
    L_Attr *attr;

    switch (type) {
    case L_CTYPE_BTR:
	oper = L_create_new_op(Lop_ST_I);
	oper->proc_opc = PLAYDOHop_S_W_C1;
	oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
	oper->src[1] = L_new_gen_int_operand(0);
	oper->src[2] = L_new_register_operand(index, L_CTYPE_BTR, L_PTYPE_NULL);
	break;
    case L_CTYPE_INT:
	oper = L_create_new_op(Lop_ST_I);
	oper->proc_opc = PLAYDOHop_S_W_C1;
	oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
	oper->src[1] = L_new_gen_int_operand(0);
	oper->src[2] = L_new_register_operand(index, L_CTYPE_INT, L_PTYPE_NULL);
	break;
    case L_CTYPE_FLOAT:
    case L_CTYPE_DOUBLE:
	oper = L_create_new_op(Lop_ST_F2);
	oper->proc_opc = PLAYDOHop_FS_D_C1;
	oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
	oper->src[1] = L_new_gen_int_operand(0);
	oper->src[2] = L_new_register_operand(index, L_CTYPE_DOUBLE, L_PTYPE_NULL);
	break;
    case L_CTYPE_PREDICATE:
#if 0
	oper = L_create_new_op(Lop_PRED_ST);
	oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
	oper->src[1] = L_new_gen_int_operand(0);
	oper->src[2] = L_new_register_operand(index, L_CTYPE_PREDICATE,
						L_PTYPE_NULL);
	break;
#endif
    default:
	L_punt("new_store_operation: illegal ctype %d", type);
    }

    oper->flags = L_SET_BIT_FLAG(oper->flags, L_OPER_SPILL_CODE|L_OPER_SAFE_PEI);

    /* Add attribute making as inserted by register allocator */
#if 0
    attr = L_new_attr("regalloc1", 1);
    L_set_int_attr_field(attr, 0, type_flag);
    oper->attr = L_concat_attr(oper->attr, attr);
#endif
    attr = O_create_reg_alloc_attr(type_flag);
    oper->attr = L_concat_attr(oper->attr, attr);

    /* Add the spill code offset attribute */
    attr = L_new_attr("offset", 1);
    L_set_int_attr_field(attr, 0, offset);
    oper->attr = L_concat_attr(oper->attr, attr);

    return oper;
}

static L_Oper *new_blk_load_operation(Set restore_set, int offset, int type_flag)
{
    int size, *buf;
    L_Oper *oper;
    L_Attr *attr;

    oper = L_create_new_op(Lop_PRED_LD_BLK);
    oper->dest[0] = L_new_macro_operand(L_MAC_PRED_ALL, L_CTYPE_PREDICATE,
                                                        L_PTYPE_NULL);
    oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
						L_PTYPE_NULL);
    oper->src[1] = L_new_gen_int_operand(0);

    oper->flags = L_SET_BIT_FLAG(oper->flags, L_OPER_SPILL_CODE|L_OPER_SAFE_PEI);

    /* Add attribute making as inserted by register allocator */
#if 0
    attr = L_new_attr("regalloc1", 1);
    L_set_int_attr_field(attr, 0, type_flag);
    oper->attr = L_concat_attr(oper->attr, attr);
#endif
    attr = O_create_reg_alloc_attr(type_flag);
    oper->attr = L_concat_attr(oper->attr, attr);

    /* Add the spill code offset attribute */
    attr = L_new_attr("offset", 1);
    L_set_int_attr_field(attr, 0, offset);
    oper->attr = L_concat_attr(oper->attr, attr);

    /* Mark the first and last register to be saved by this op for the emulator */
    size = Set_size(restore_set);
    if (size<=0)
	L_punt("new_blk_load_operation: no predicates to restore");
    buf = (int *) Lcode_malloc(sizeof(int)*size);
    Set_2array(restore_set, buf);
    attr = L_new_attr("pred_refs", 3);
    L_set_int_attr_field(attr, 0, buf[0]);
    L_set_int_attr_field(attr, 1, buf[size-1]);
    L_set_int_attr_field(attr, 2, size);
    oper->attr = L_concat_attr(oper->attr, attr);
    Lcode_free(buf);

    return (oper);
}

static L_Oper *new_blk_store_operation(Set save_set, int offset, int type_flag)
{
    int size, *buf;
    L_Oper *oper;
    L_Attr *attr;

    oper = L_create_new_op(Lop_PRED_ST_BLK);
    oper->src[0] = L_new_macro_operand(PLAYDOH_MAC_TEMPREG, L_CTYPE_INT,
							L_PTYPE_NULL);
    oper->src[1] = L_new_gen_int_operand(0);
    oper->src[2] = L_new_macro_operand(L_MAC_PRED_ALL, L_CTYPE_PREDICATE,
							L_PTYPE_NULL);

    oper->flags = L_SET_BIT_FLAG(oper->flags, L_OPER_SPILL_CODE|L_OPER_SAFE_PEI);

    /* Add attribute making as inserted by register allocator */
#if 0
    attr = L_new_attr("regalloc1", 1);
    L_set_int_attr_field(attr, 0, type_flag);
    oper->attr = L_concat_attr(oper->attr, attr);
#endif
    attr = O_create_reg_alloc_attr(type_flag);
    oper->attr = L_concat_attr(oper->attr, attr);

    /* Add the spill code offset attribute */
    attr = L_new_attr("offset", 1);
    L_set_int_attr_field(attr, 0, offset);
    oper->attr = L_concat_attr(oper->attr, attr);

    /* Mark the first and last register to be saved by this op for the emulator */
    size = Set_size(save_set);
    if (size<=0)
	L_punt("new_blk_load_operation: no predicates to save");
    buf = (int *) Lcode_malloc(sizeof(int)*size);
    Set_2array(save_set, buf);
    attr = L_new_attr("pred_refs", 3);
    L_set_int_attr_field(attr, 0, buf[0]);
    L_set_int_attr_field(attr, 1, buf[size-1]);
    L_set_int_attr_field(attr, 2, size);
    oper->attr = L_concat_attr(oper->attr, attr);
    Lcode_free(buf);

    return(oper);
}

void O_register_init(void)
{
    int i, base;
    static init = 0;

    if (init) return;
    init = 1;

    /*
     *	Define register banks.
     */

    base = 0;

    caller_int_reg_map = (int *) MALLOC(int,El_num_static_gpr_caller);
    for ( i = 0; i < El_num_static_gpr_caller; i++ ) {  
	caller_int_reg_map[i] = El_num_static_gpr_resv + i + base;
    }
    R_define_physical_bank( R_CALLER,			/* bank saving conv */
			    R_INT,			/* bank data type   */
			    El_num_static_gpr_caller,	/* num registers    */
			    1,				/* register size    */
			    R_OVERLAP_INT,		/* banks that overlap */
			    caller_int_reg_map,		/* register map ptr */
			    &caller_int_set);		/* set of caller int
							   registers used */

    base += El_num_static_gpr_caller;

    callee_int_reg_map = (int *) MALLOC(int,El_num_static_gpr_callee);
    for ( i = 0; i < El_num_static_gpr_callee; i++ )  {
        callee_int_reg_map[i] = El_num_static_gpr_resv + i + base;
    }
    R_define_physical_bank(	R_CALLEE,
				R_INT,
				El_num_static_gpr_callee,
				1,
				R_OVERLAP_INT,
			   	callee_int_reg_map,
				&callee_int_set);

    base += El_num_static_gpr_callee;
    base += El_num_static_gpr_resv;

    base += El_num_rotating_gpr;

    caller_flt_reg_map = (int *) MALLOC(int,El_num_static_fpr_caller);
    caller_dbl_reg_map = (int *) MALLOC(int,El_num_static_fpr_caller);
    for ( i = 0; i < El_num_static_fpr_caller; i++ )  {
	caller_flt_reg_map[i] = El_num_static_fpr_resv + i + base;
    }
    for ( i = 0; i < El_num_static_fpr_caller; i++ )  {
	caller_dbl_reg_map[i] = El_num_static_fpr_resv + i + base;
    }
    R_define_physical_bank(	R_CALLER,
				R_FLOAT,
				El_num_static_fpr_caller,
				1,
				R_OVERLAP_FLOAT | R_OVERLAP_DOUBLE, 
				caller_flt_reg_map,
				&caller_float_set);

    R_define_physical_bank(	R_CALLER,
				R_DOUBLE,
				El_num_static_fpr_caller,
				1,
				R_OVERLAP_FLOAT | R_OVERLAP_DOUBLE, 
				caller_dbl_reg_map,
				&caller_double_set);

    base += El_num_static_fpr_caller;

    callee_flt_reg_map = (int *) MALLOC(int,El_num_static_fpr_callee);
    callee_dbl_reg_map = (int *) MALLOC(int,El_num_static_fpr_callee);
    for ( i = 0; i < El_num_static_fpr_callee; i++ )  {
	callee_flt_reg_map[i] = El_num_static_fpr_resv + i + base;
    }
    for ( i = 0; i < El_num_static_fpr_callee; i++ )  {
	callee_dbl_reg_map[i] = El_num_static_fpr_resv + i + base;
    }
    R_define_physical_bank(	R_CALLEE,
				R_FLOAT,
			        El_num_static_fpr_callee,
				1,
				R_OVERLAP_FLOAT | R_OVERLAP_DOUBLE, 
				callee_flt_reg_map,
				&callee_float_set);
    
    R_define_physical_bank(	R_CALLEE,
				R_DOUBLE,
				El_num_static_fpr_callee,
				1,
				R_OVERLAP_FLOAT | R_OVERLAP_DOUBLE, 
				callee_dbl_reg_map,
				&callee_double_set);

    base += El_num_static_fpr_callee;
    base += El_num_static_fpr_resv;

    base += El_num_rotating_fpr;

    caller_prd_reg_map = (int *) MALLOC(int,El_num_static_pr_caller);
    for ( i = 0; i < El_num_static_pr_caller; i++ )  {
	caller_prd_reg_map[i] = El_num_static_pr_resv + i + base;
    }
    R_define_physical_bank(	R_CALLER,
				R_PREDICATE,
				El_num_static_pr_caller,
				1,
				R_OVERLAP_PREDICATE,
				caller_prd_reg_map,
				&caller_predicate_set);

    base += El_num_static_pr_caller;

    callee_prd_reg_map = (int *) MALLOC(int,El_num_static_pr_callee);
    for ( i = 0; i < El_num_static_pr_callee; i++ )  {
	callee_prd_reg_map[i] = El_num_static_pr_resv + i + base;
    }
    R_define_physical_bank(	R_CALLEE,
				R_PREDICATE,
				El_num_static_pr_callee,
				1,
				R_OVERLAP_PREDICATE,
				callee_prd_reg_map,
				&callee_predicate_set);

    base += El_num_static_pr_callee;
    base += El_num_static_pr_resv;

    base += El_num_rotating_pr;

    caller_btr_reg_map = (int *) MALLOC(int,El_num_static_btr_caller);
    for ( i = 0; i < El_num_static_btr_caller; i++ )  {
	caller_btr_reg_map[i] = El_num_static_btr_resv + i + base;
    }
    R_define_physical_bank(	R_CALLER,
				R_BTR,
				El_num_static_btr_caller,
				1,
				R_OVERLAP_BTR,
				caller_btr_reg_map,
				&caller_btr_set);

    base += El_num_static_btr_caller;
    
    callee_btr_reg_map = (int *) MALLOC(int,El_num_static_btr_callee);
    for ( i = 0; i < El_num_static_btr_callee; i++ )  {
	callee_btr_reg_map[i] = El_num_static_btr_resv + i + base;
    }
    R_define_physical_bank(	R_CALLEE,
				R_BTR,
				El_num_static_btr_callee,
				1,
				R_OVERLAP_BTR,
				callee_btr_reg_map,
				&callee_btr_set);

    base += El_num_static_btr_callee;
    base += El_num_static_btr_resv;

}

void O_register_allocation(L_Func *fn, Parm_Macro_List *command_line_macro_list)
{
    L_Oper *oper;
    L_Cb *cb;
    int i, spill_space, size_int, size_flt, size_btr;
    Set fcle, icle, bcle;

    int *callee_reg_array,n_callee;

    L_check_func_hyperblock_flag(fn);

    /* Reset the register usage sets */
    caller_int_set = Set_dispose(caller_int_set);
    callee_int_set = Set_dispose(callee_int_set);
    caller_float_set = Set_dispose(caller_float_set);
    callee_float_set = Set_dispose(callee_float_set);
    caller_double_set = Set_dispose(caller_double_set);
    callee_double_set = Set_dispose(callee_double_set);
    caller_predicate_set = Set_dispose(caller_predicate_set);
    callee_predicate_set = Set_dispose(callee_predicate_set);
    caller_btr_set = Set_dispose(caller_btr_set);
    callee_btr_set = Set_dispose(callee_btr_set);
    
    spill_space = R_register_allocation(fn, command_line_macro_list);
    
    /*  IN ORDER TO BE ABLE TO PERFORM REGISTER ALLOCATION TWICE  */
    /*  THE ONLY ADDITIONAL WORK WE ARE ALLOWED TO DO HERE IS THE */
    /*  INSERTION OF THE "CALLEE" SAVED REGISTERS.                */ 
    /*  THUS THE FINAL SWAP SPACE WILL BE THE VALUE RETURNED BY   */
    /*  REGISTER ALLOCATION PLUS THE SPACE REQUIRED FOR CALLEE SVS*/

    fcle = icle = bcle = 0;
	
    /* Place Callee-saved integer registers used into the icle set */
    callee_reg_array = (int *) MALLOC(int,Set_size(callee_int_set)+
			      	  Set_size(callee_float_set)+
			          Set_size(callee_double_set)+
				  Set_size(callee_btr_set));
    n_callee = Set_2array(callee_int_set,callee_reg_array);
    for ( i = 0; i < n_callee; i++ )  {
	icle = Set_add(icle,callee_reg_array[i]);
    }

   
    /* Place the double register corresponding to Callee-saved */
    /* float register used in the fcle set		       */
    n_callee = Set_2array(callee_float_set,callee_reg_array);
    for ( i = 0; i < n_callee; i++ )  {
	fcle = Set_add(fcle,callee_reg_array[i]);
    }

    /* Place the Callee-saved double registers used into the fcle set */
    n_callee = Set_2array(callee_double_set,callee_reg_array);
    for ( i = 0; i < n_callee; i++ )  {
        fcle = Set_add(fcle,callee_reg_array[i]);
    }
    
    /* Place the callee-saved btr registers used into the bcle set */
    n_callee = Set_2array(callee_btr_set,callee_reg_array);
    for ( i = 0; i < n_callee; i++ )  {
	bcle = Set_add(bcle,callee_reg_array[i]);
    }
    
    size_int = Set_size(icle);
    size_flt = Set_size(fcle);
    size_btr = Set_size(bcle);
    spill_space += size_int*4 + size_flt*8 + size_btr*4;
    Set_2array(fcle, callee_reg_array);
    Set_2array(icle, callee_reg_array+size_flt);
    Set_2array(bcle, callee_reg_array+size_flt+size_int);

    for (cb=fn->first_cb; cb!=NULL; cb=cb->next_cb) {
	L_Oper *next_oper, *new_oper1, *new_oper2;
	for (oper=cb->first_op; oper!=NULL; oper=next_oper) {
	    int opc, k, swap_offset;
	    next_oper = oper->next_op;	/* this is important */
	    opc = oper->opc;
	    /*
	     *	Additional save/restore.
	     */
	    switch (opc) {

	    case Lop_PROLOGUE:
		/*
		 *  Insert save code after it.
		 */
		swap_offset = spill_space;
		swap_offset += (8-(swap_offset%8));

	        if (O_require_callee_save_code(L_CTYPE_DOUBLE)) {
	            for ( k = 0; k < size_flt; k++ )  {
		        new_oper1 = O_address_add(swap_offset, NULL,
						R_CALLEE_SAVE_CODE, L_PTYPE_NULL);
		        new_oper2 = new_store_operation(callee_reg_array[k],
			  		    L_CTYPE_DOUBLE, swap_offset,
					    R_CALLEE_SAVE_CODE);
		        L_insert_oper_after(cb,oper,new_oper2);
		        L_insert_oper_after(cb,oper,new_oper1);
		        swap_offset += 8;
		    }
		}
	        if (O_require_callee_save_code(L_CTYPE_INT)) {
		    for ( k = size_flt; k < (size_flt+size_int); k++ )  {
		        new_oper1 = O_address_add(swap_offset, NULL,
						R_CALLEE_SAVE_CODE, L_PTYPE_NULL);
                        new_oper2 = new_store_operation(callee_reg_array[k],
				       L_CTYPE_INT, swap_offset, R_CALLEE_SAVE_CODE);
                        L_insert_oper_after(cb,oper,new_oper2);
                        L_insert_oper_after(cb,oper,new_oper1);
                        swap_offset += 4;
		    }
		}
	        if (O_require_callee_save_code(L_CTYPE_BTR)) {
		    for (k=(size_flt+size_int);k<(size_flt+size_int+size_btr);k++) {
		        new_oper1 = O_address_add(swap_offset, NULL,
						R_CALLEE_SAVE_CODE, L_PTYPE_NULL);
                        new_oper2 = new_store_operation(callee_reg_array[k],
				       L_CTYPE_BTR, swap_offset, R_CALLEE_SAVE_CODE);
                        L_insert_oper_after(cb,oper,new_oper2);
                        L_insert_oper_after(cb,oper,new_oper1);
                        swap_offset += 4;
		    }
		}

		if (O_require_callee_save_code(L_CTYPE_PREDICATE)) {
		    /* insert a PRED_ST_BLK if there are any callee save pred regs */
		    if (Set_size(callee_predicate_set) > 0) {
		        new_oper1 = O_address_add(swap_offset, NULL,
						   R_CALLEE_SAVE_CODE, L_PTYPE_NULL);
		        new_oper2 = new_blk_store_operation(callee_predicate_set,
						swap_offset, R_CALLEE_SAVE_CODE);
		        L_insert_oper_after(cb, oper, new_oper2);
		        L_insert_oper_after(cb, oper, new_oper1);
		        swap_offset += ((El_num_static_pr_callee+El_num_static_pr_caller+31)/32)*4;
		    }
		}

		new_oper1 = L_create_new_op(Lop_DEFINE);
		new_oper1->dest[0] = L_new_macro_operand(L_MAC_SWAP_SIZE,
							L_CTYPE_INT, L_PTYPE_NULL);
		new_oper1->src[0] = L_new_gen_int_operand(swap_offset);
		L_insert_oper_before(cb,oper,new_oper1);

		break;

   	    case Lop_EPILOGUE:
		/*
		 *  Insert restore code before it.
		 */
		swap_offset = spill_space;
		swap_offset += (8-(swap_offset%8));

	        if (O_require_callee_save_code(L_CTYPE_DOUBLE)) {
                    for ( k = 0; k < size_flt; k++ )  {
		        new_oper1 = O_address_add(swap_offset, NULL,
						R_CALLEE_SAVE_CODE, L_PTYPE_NULL);
                        L_insert_oper_before(cb,oper,new_oper1);
                        new_oper2 = new_load_operation(callee_reg_array[k],
				    L_CTYPE_DOUBLE, swap_offset, R_CALLEE_SAVE_CODE);
                        L_insert_oper_before(cb,oper,new_oper2);
                        swap_offset += 8;
                    }
		}
	        if (O_require_callee_save_code(L_CTYPE_INT)) {
                    for ( k = size_flt; k < (size_flt+size_int); k++ )  {
		        new_oper1 = O_address_add(swap_offset, NULL,
					R_CALLEE_SAVE_CODE, L_PTYPE_NULL);
                        L_insert_oper_before(cb,oper,new_oper1);
                        new_oper2 = new_load_operation(callee_reg_array[k],
				    L_CTYPE_INT, swap_offset, R_CALLEE_SAVE_CODE);
                        L_insert_oper_before(cb,oper,new_oper2);
                        swap_offset += 4;
		    }	
		}
	        if (O_require_callee_save_code(L_CTYPE_BTR)) {
                    for (k=(size_flt+size_int);k<(size_flt+size_int+size_btr);k++) {
		        new_oper1 = O_address_add(swap_offset, NULL,
						R_CALLEE_SAVE_CODE, L_PTYPE_NULL);
                        L_insert_oper_before(cb,oper,new_oper1);
                        new_oper2 = new_load_operation(callee_reg_array[k],
				    L_CTYPE_BTR, swap_offset, R_CALLEE_SAVE_CODE);
                        L_insert_oper_before(cb,oper,new_oper2);
                        swap_offset += 4;
		    }	
		}
	        if (O_require_callee_save_code(L_CTYPE_PREDICATE)) {
                    /* insert a PRED_ST_BLK if there are any callee save pred regs */
		    if (Set_size(callee_predicate_set) > 0) {
		        new_oper1 = O_address_add(swap_offset, NULL,
					    R_CALLEE_SAVE_CODE, L_PTYPE_NULL);
                        L_insert_oper_before(cb, oper, new_oper1);
                        new_oper2 = new_blk_load_operation(callee_predicate_set,
						swap_offset, R_CALLEE_SAVE_CODE);
                        L_insert_oper_before(cb, oper, new_oper2);
		        swap_offset += ((El_num_static_pr_callee+El_num_static_pr_caller+31)/32)*4;
		    }
		}

		break;

	    default:
		break;
	    }
	}
    }

    /* Hack to fixup predicate attributes for spill code inserted SAM 10-94 */
    L_fix_vpred_attrs(fn);

    /*
     *	Free up resource.
     */
    free(callee_reg_array);

    /* Reset the register usage sets */
    caller_int_set = Set_dispose(caller_int_set);
    callee_int_set = Set_dispose(callee_int_set);
    caller_float_set = Set_dispose(caller_float_set);
    callee_float_set = Set_dispose(callee_float_set);
    caller_double_set = Set_dispose(caller_double_set);
    callee_double_set = Set_dispose(callee_double_set);
    caller_predicate_set = Set_dispose(caller_predicate_set);
    callee_predicate_set = Set_dispose(callee_predicate_set);
    caller_btr_set = Set_dispose(caller_btr_set);
    callee_btr_set = Set_dispose(callee_btr_set);
}
