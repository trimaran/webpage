/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1994 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

///////////////////////////////////////////////////////////////////////////
//									 //
//      File:           el_opti_dead_code.cpp                            //
//      Authors:        Sadun Anik					 //
//      Created:        July 1996					 //
//      Description:    Dead Code Eliminator Implementation		 //
// 									 //
///////////////////////////////////////////////////////////////////////////

#include "el_opti_dead_code.h"
#include "reaching_defs_solver.h"
#include "pred_analysis.h"
#include "iterators.h"
#include "opcode_properties.h"
#include "connect.h"
#include "dbg.h"

static bool is_analyzed(Operand &oper, unsigned int filter_flag)
{
   if ((filter_flag & ANALYZE_MEMVR) && oper.is_mem_vr()) return true ;
   if ((filter_flag & ANALYZE_ALLREG) && (oper.is_reg() || oper.is_macro_reg())) {
      if (filter_flag == ANALYZE_ALLREG) return true ;
      Reg_file cur_rfile = oper.file_type() ;
      if ((filter_flag & ANALYZE_INT) && (cur_rfile == GPR)) return true ;
      if ((filter_flag & ANALYZE_FP) && (cur_rfile == FPR)) return true ;
      if ((filter_flag & ANALYZE_BTR) && (cur_rfile == BTR)) return true ;
      if ((filter_flag & ANALYZE_PR) && (cur_rfile == PR)) return true ;
   }
   return false ;
}

static bool is_analyzed(El_ref& cur_ref, unsigned int filter_flag)
{
   if (cur_ref.get_operand().is_reg() ||
       cur_ref.get_operand().is_mem_vr() ||
       cur_ref.get_operand().is_macro_reg())
      return (is_analyzed(cur_ref.get_operand(), filter_flag));
   else
      return false ;
}

static bool is_deletable_op(Op* cur_op, unsigned int filter_flag)
{
   if (cur_op->num_dests() == 0) return (false) ;
   if (is_control_switch(cur_op)) return (false) ;
   if (is_store(cur_op)) return (false) ;
   if (is_remap(cur_op)) return (false) ;   
   if (is_pseudo(cur_op)) return (false) ;
   if (is_predicate_set(cur_op) ||
       is_predicate_clear(cur_op) ||
       is_clear_all_rotating(cur_op)) return (false) ;

   /* SAM, 3-98 check filter flag to make more fine grain dead code decisions */
   /* If ANALYZE_ALLREG or ANALYZE_ALL, then full analysis done, so deleteable */
   if ((filter_flag == ANALYZE_ALLREG) || (filter_flag == ANALYZE_ALL))
      return (true) ;

   /* Otherwise, partial analysis was done, so check the dest operands of cur_op */
   for (Op_complete_dests dest_i(cur_op); dest_i!=0; dest_i++) {
      Operand dest = *dest_i;
      if (dest.is_undefined())
         continue;
      if (! is_analyzed(dest, filter_flag))
         return (false);
   }

   return (true);
}

static void add_to_list_if_dead(Op* cur_op, List<Op*>& dc_list, Reaching_defs_info* rd_info, unsigned int filter_flag)
{
   if (!is_deletable_op(cur_op, filter_flag)) return ;
   bool no_uses = true ;
   for (Op_explicit_dests desti(cur_op) ; desti != 0 ; desti++) {
      El_ref cur_def = desti.get_ref() ;
      if (is_analyzed(cur_def, filter_flag)) {
	 List<El_ref>* uses = rd_info->get_du_chain(cur_def) ;
	 if (!(uses->is_empty())) {
	    no_uses = false ;
	 }
         else {
            /* Nuke the dead operand, SAM 8-96 */
            Operand undefined;
            cur_op->set_dest(desti.get_port_num(), undefined);
	    if (dbg(opti,1))
              cdbg << "Dead code elim: Deleting dest operand "
		   << desti.get_port_num() << " of op " << cur_op->id() << endl;
         }
      }
   }
   if (no_uses) {
      dc_list.add_tail(cur_op) ;
      if (dbg(opti,1))
        cdbg << "Dead code elim: Deleting op " << cur_op->id() << endl;
   }
}

/*
 *  SAM 8-96, added to fix opcodes for ops which have several dead dest
 *  operands, but the op could not be completely deleted
 */
static void fix_opcode_for_undefined_operands(Compound_region* R)
{
  Op *cur_op;
  Operand dest, dest1, dest2, undef;
  Opcode new_opc;
  int num_undef;

  for (Region_all_ops reg_opi(R) ; reg_opi != 0 ; reg_opi++) {
    cur_op = *reg_opi ;
    if (is_pseudo(cur_op))
      continue;
    if (cur_op->num_dests() <= 0)
      continue;
    /* count up the number of undefined dests */
    num_undef = 0;
    for (Op_explicit_dests desti(cur_op) ; desti != 0 ; desti++) {
      dest = *desti;
      if (dest.is_undefined())
        num_undef++;
    }
    if (num_undef == 0)
      continue;
    /* Ok, we have some undefined dests, so try to update the opcode */
    if (is_cmpp(cur_op)) {
      /* For cmpp, make sure the real operand is in dest1, if not swap dests */
      if (cur_op->dest(DEST1).is_undefined()) {
        if (cur_op->dest(DEST2).is_undefined())
          El_punt("fix_opcode_for_undefined_operands: both dests of cmpp undefined");
        dest1 = cur_op->dest(DEST1);
        dest2 = cur_op->dest(DEST2);
	cur_op->set_dest(DEST1, dest2);
	cur_op->set_dest(DEST2, dest1);
        new_opc = exchange_cmpp_dest_modifiers(cur_op->opcode());
        cur_op->set_opcode(new_opc);
        if (dbg(opti,2))
          cdbg << "Dead code elim: swapping dests of cmpp " << cur_op->id() << endl;
      }
    }
    else if (is_load(cur_op)) {
      /* For a load, if DEST1 is undefined, convert op to an increment, if
         DEST2 is undefined convert it to a simple load */
      if (cur_op->dest(DEST1).is_undefined()) {
        if (cur_op->dest(DEST2).is_undefined())
          El_punt("fix_opcode_for_undefined_operands: both dests of li undefined");
        new_opc = extract_increment_from_post_increment(cur_op->opcode());
        cur_op->set_dest(DEST1, cur_op->dest(DEST2));
        cur_op->set_dest(DEST2, undef);
        cur_op->set_opcode(new_opc);
        cur_op->update_num_operands();
        if (dbg(opti,2))
          cdbg << "Dead code elim: Converting " << cur_op->id()
               << " from a post inc load to an increment" << endl;
      }
      else if (cur_op->dest(DEST2).is_undefined()) {
        new_opc = remove_post_increment(cur_op->opcode());
        cur_op->set_dest(DEST2, undef);
        cur_op->set_src(SRC2, undef);
        cur_op->set_opcode(new_opc);
        cur_op->update_num_operands();
        if (dbg(opti,2))
          cdbg << "Dead code elim: Converting " << cur_op->id()
               << " from a post inc load to a regular load" << endl;
      }
    }
    else if (is_store(cur_op)) {
      /* For a store, convert post increment store to regular store */
      if (cur_op->dest(DEST1).is_undefined()) {
        new_opc = remove_post_increment(cur_op->opcode());
        cur_op->set_dest(DEST1, undef);
        cur_op->set_src(SRC3, undef);
        cur_op->set_opcode(new_opc);
        cur_op->update_num_operands();
        if (dbg(opti,2))
          cdbg << "Dead code elim: Converting " << cur_op->id()
               << " from a post inc store to a regular store" << endl;
      }
    }
    else {
      El_punt("fix_opcode_for_undefined_operands: unknown op with multiple dests");
    }
  }
}


void el_opti_eliminate_dead_code(Compound_region* R, unsigned int filter_flag,
				 bool run_rdefs)
{
   if (dbg(opti, 1) || dbg(status, 3)) 
    cdbg << "-- Dead code elimination " << endl;

   if (run_rdefs == true) {
      create_local_analysis_info_for_all_hbs_bbs(R) ;
      El_do_reaching_defs (R, filter_flag) ;
   }
   Reaching_defs_info* rdinfo = get_reaching_defs_info (R) ;

   Region_all_ops reg_opi ;
   List<Op*> dead_op_list ;
   for (reg_opi(R) ; reg_opi != 0 ; reg_opi++) {
      Op* cur_op = *reg_opi ;
      add_to_list_if_dead(cur_op, dead_op_list, rdinfo, filter_flag) ;
   }
// Dead op worklist is constructed. Do work until the list is empty

   while(!(dead_op_list.is_empty())) {
      List<Op*> potential_dead_code_list ;
      Op* cur_op = dead_op_list.pop() ;
      for (Op_explicit_inputs usei(cur_op) ; usei != 0 ; usei++) {
	 El_ref cur_use = usei.get_ref() ;
	 if (!is_analyzed(cur_use, filter_flag)) continue ;
	 List<El_ref>* rd_list = rdinfo->get_ud_chain(cur_use) ;
	 for (List_iterator<El_ref> defi(*rd_list) ; defi != 0 ; defi++) {
	    El_ref& cur_def = *defi ;
	    if (!is_analyzed(cur_def, filter_flag)) continue ;
	    List<El_ref>* uses_list = rdinfo->get_du_chain(cur_def) ;
	    uses_list->remove(cur_use) ;
	    if (uses_list->is_empty()) {
	       Op* tmp_op = cur_def.get_op() ;
	       if (!potential_dead_code_list.is_member(tmp_op)) { 
		  potential_dead_code_list.add_tail(tmp_op) ;
	       }
	    }
	 }
      }
      //
      // Check potential_dead_code_list actually contains new dead code
      //
      for (List_iterator<Op*> pdi(potential_dead_code_list) ; pdi!=0 ; pdi++){
	 Op* cur_op = *pdi ;
	 add_to_list_if_dead(cur_op, dead_op_list, rdinfo, filter_flag) ;
      }
      //
      // Remove the op
      //
      C0_remove_op(cur_op) ;
      cur_op->parent()->remove_region(cur_op) ;
      delete cur_op ;
      
   }
   fix_opcode_for_undefined_operands(R);

   if (run_rdefs == true) {
      delete_local_analysis_info_for_all_hbs_bbs(R) ; 
   }
}

