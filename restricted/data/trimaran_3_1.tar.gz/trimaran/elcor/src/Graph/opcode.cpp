/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1994 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           opcode.cpp
//      Authors:        Sadun Anik, Scott Mahlke, Richard Johnson
//      Created:        December 1994
//      Description:    Enums for the opcodes 
//
/////////////////////////////////////////////////////////////////////////////

#include "opcode.h"
#include "opcode_cmpp.h"
#include "opcode_load_store.h"
#include "hash_functions.h"
#include <string.h>

Hash_map<eString, Opcode> el_string_to_opcode_map(hash_estring, 1000);
Hash_map<Opcode, eString> el_opcode_to_string_map(hash_opcode, 1000) ;

Hash_map<IR_BASE_OPCODE, eString> el_base_opcode_to_string_map(hash_IR_BASE_OPCODE, 200) ;


//
//	Note the map initialization function is split up into several
//	components for compilation speed reasons, not for correctness,
//	so additions/changes can be made freely.  SAM 5-95
//

static void el_init_elcor_opcode_maps_arithmetic()
{
   el_string_to_opcode_map.bind("NO_OP", NO_OP) ;
   el_opcode_to_string_map.bind(NO_OP, "NO_OP") ;
   el_string_to_opcode_map.bind("M_NO_OP", M_NO_OP) ;
   el_opcode_to_string_map.bind(M_NO_OP, "M_NO_OP") ;
   el_string_to_opcode_map.bind("ABS_W", ABS_W) ;
   el_opcode_to_string_map.bind(ABS_W, "ABS_W") ;
   el_string_to_opcode_map.bind("ADD_W", ADD_W) ;
   el_opcode_to_string_map.bind(ADD_W, "ADD_W") ;
   el_string_to_opcode_map.bind("ADDL_W", ADDL_W) ;
   el_opcode_to_string_map.bind(ADDL_W, "ADDL_W") ;
   el_string_to_opcode_map.bind("AND_W", AND_W) ;
   el_opcode_to_string_map.bind(AND_W, "AND_W") ;
   el_string_to_opcode_map.bind("ANDCM_W", ANDCM_W) ;
   el_opcode_to_string_map.bind(ANDCM_W, "ANDCM_W") ;
   el_string_to_opcode_map.bind("DIV_W", DIV_W) ;
   el_opcode_to_string_map.bind(DIV_W, "DIV_W") ;
   el_string_to_opcode_map.bind("DIVL_W", DIVL_W) ;
   el_opcode_to_string_map.bind(DIVL_W, "DIVL_W") ;
   el_string_to_opcode_map.bind("MPY_W", MPY_W) ;
   el_opcode_to_string_map.bind(MPY_W, "MPY_W") ;
   el_string_to_opcode_map.bind("MPYL_W", MPYL_W) ;
   el_opcode_to_string_map.bind(MPYL_W, "MPYL_W") ;
   el_string_to_opcode_map.bind("NAND_W", NAND_W) ;
   el_opcode_to_string_map.bind(NAND_W, "NAND_W") ;
   el_string_to_opcode_map.bind("NOR_W", NOR_W) ;
   el_opcode_to_string_map.bind(NOR_W, "NOR_W") ;
   el_string_to_opcode_map.bind("OR_W", OR_W) ;
   el_opcode_to_string_map.bind(OR_W, "OR_W") ;
   el_string_to_opcode_map.bind("ORCM_W", ORCM_W) ;
   el_opcode_to_string_map.bind(ORCM_W, "ORCM_W") ;
   el_string_to_opcode_map.bind("REM_W", REM_W) ;
   el_opcode_to_string_map.bind(REM_W, "REM_W") ;
   el_string_to_opcode_map.bind("REML_W", REML_W) ;
   el_opcode_to_string_map.bind(REML_W, "REML_W") ;
   el_string_to_opcode_map.bind("SH1ADDL_W", SH1ADDL_W) ;
   el_opcode_to_string_map.bind(SH1ADDL_W, "SH1ADDL_W") ;
   el_string_to_opcode_map.bind("SH2ADDL_W", SH2ADDL_W) ;
   el_opcode_to_string_map.bind(SH2ADDL_W, "SH2ADDL_W") ;
   el_string_to_opcode_map.bind("SH3ADDL_W", SH3ADDL_W) ;
   el_opcode_to_string_map.bind(SH3ADDL_W, "SH3ADDL_W") ;
   el_string_to_opcode_map.bind("SHL_W", SHL_W) ;
   el_opcode_to_string_map.bind(SHL_W, "SHL_W") ;
   el_string_to_opcode_map.bind("SHR_W", SHR_W) ;
   el_opcode_to_string_map.bind(SHR_W, "SHR_W") ;
   el_string_to_opcode_map.bind("SHLA_W", SHLA_W) ;
   el_opcode_to_string_map.bind(SHLA_W, "SHLA_W") ;
   el_string_to_opcode_map.bind("SHRA_W", SHRA_W) ;
   el_opcode_to_string_map.bind(SHRA_W, "SHRA_W") ;
   el_string_to_opcode_map.bind("SUB_W", SUB_W) ;
   el_opcode_to_string_map.bind(SUB_W, "SUB_W") ;
   el_string_to_opcode_map.bind("SUBL_W", SUBL_W) ;
   el_opcode_to_string_map.bind(SUBL_W, "SUBL_W") ;
   el_string_to_opcode_map.bind("XOR_W", XOR_W) ;
   el_opcode_to_string_map.bind(XOR_W, "XOR_W") ;
   el_string_to_opcode_map.bind("XORCM_W", XORCM_W) ;
   el_opcode_to_string_map.bind(XORCM_W, "XORCM_W") ;

   el_string_to_opcode_map.bind("DIVFLOOR_W", DIVFLOOR_W) ;
   el_opcode_to_string_map.bind(DIVFLOOR_W, "DIVFLOOR_W") ;
   el_string_to_opcode_map.bind("DIVCEIL_W", DIVCEIL_W) ;
   el_opcode_to_string_map.bind(DIVCEIL_W, "DIVCEIL_W") ;
   el_string_to_opcode_map.bind("MIN_W", MIN_W) ;
   el_opcode_to_string_map.bind(MIN_W, "MIN_W") ;
   el_string_to_opcode_map.bind("MAX_W", MAX_W) ;
   el_opcode_to_string_map.bind(MAX_W, "MAX_W") ;

   el_string_to_opcode_map.bind("FADD_S", FADD_S) ;
   el_opcode_to_string_map.bind(FADD_S, "FADD_S") ;
   el_string_to_opcode_map.bind("FADD_D", FADD_D) ;
   el_opcode_to_string_map.bind(FADD_D, "FADD_D") ;
   el_string_to_opcode_map.bind("FABS_S", FABS_S) ;
   el_opcode_to_string_map.bind(FABS_S, "FABS_S") ;
   el_string_to_opcode_map.bind("FABS_D", FABS_D) ;
   el_opcode_to_string_map.bind(FABS_D, "FABS_D") ;
   el_string_to_opcode_map.bind("FDIV_S", FDIV_S) ;
   el_opcode_to_string_map.bind(FDIV_S, "FDIV_S") ;
   el_string_to_opcode_map.bind("FDIV_D", FDIV_D) ;
   el_opcode_to_string_map.bind(FDIV_D, "FDIV_D") ;
   el_string_to_opcode_map.bind("FMAX_S", FMAX_S) ;
   el_opcode_to_string_map.bind(FMAX_S, "FMAX_S") ;
   el_string_to_opcode_map.bind("FMAX_D", FMAX_D) ;
   el_opcode_to_string_map.bind(FMAX_D, "FMAX_D") ;
   el_string_to_opcode_map.bind("FMIN_S", FMIN_S) ;
   el_opcode_to_string_map.bind(FMIN_S, "FMIN_S") ;
   el_string_to_opcode_map.bind("FMIN_D", FMIN_D) ;
   el_opcode_to_string_map.bind(FMIN_D, "FMIN_D") ;
   el_string_to_opcode_map.bind("FMPY_S", FMPY_S) ;
   el_opcode_to_string_map.bind(FMPY_S, "FMPY_S") ;
   el_string_to_opcode_map.bind("FMPY_D", FMPY_D) ;
   el_opcode_to_string_map.bind(FMPY_D, "FMPY_D") ;
   el_string_to_opcode_map.bind("FMPYADD_S", FMPYADD_S) ;
   el_opcode_to_string_map.bind(FMPYADD_S, "FMPYADD_S") ;
   el_string_to_opcode_map.bind("FMPYADD_D", FMPYADD_D) ;
   el_opcode_to_string_map.bind(FMPYADD_D, "FMPYADD_D") ;
   el_string_to_opcode_map.bind("FMPYADDN_S", FMPYADDN_S) ;
   el_opcode_to_string_map.bind(FMPYADDN_S, "FMPYADDN_S") ;
   el_string_to_opcode_map.bind("FMPYADDN_D", FMPYADDN_D) ;
   el_opcode_to_string_map.bind(FMPYADDN_D, "FMPYADDN_D") ;
   el_string_to_opcode_map.bind("FMPYRSUB_S", FMPYRSUB_S) ;
   el_opcode_to_string_map.bind(FMPYRSUB_S, "FMPYRSUB_S") ;
   el_string_to_opcode_map.bind("FMPYRSUB_D", FMPYRSUB_D) ;
   el_opcode_to_string_map.bind(FMPYRSUB_D, "FMPYRSUB_D") ;
   el_string_to_opcode_map.bind("FMPYSUB_S", FMPYSUB_S) ;
   el_opcode_to_string_map.bind(FMPYSUB_S, "FMPYSUB_S") ;
   el_string_to_opcode_map.bind("FMPYSUB_D", FMPYSUB_D) ;
   el_opcode_to_string_map.bind(FMPYSUB_D, "FMPYSUB_D") ;
   el_string_to_opcode_map.bind("FRCP_S", FRCP_S) ;
   el_opcode_to_string_map.bind(FRCP_S, "FRCP_S") ;
   el_string_to_opcode_map.bind("FRCP_D", FRCP_D) ;
   el_opcode_to_string_map.bind(FRCP_D, "FRCP_D") ;
   el_string_to_opcode_map.bind("FSQRT_S", FSQRT_S) ;
   el_opcode_to_string_map.bind(FSQRT_S, "FSQRT_S") ;
   el_string_to_opcode_map.bind("FSQRT_D", FSQRT_D) ;
   el_opcode_to_string_map.bind(FSQRT_D, "FSQRT_D") ;
   el_string_to_opcode_map.bind("FSUB_S", FSUB_S) ;
   el_opcode_to_string_map.bind(FSUB_S, "FSUB_S") ;
   el_string_to_opcode_map.bind("FSUB_D", FSUB_D) ;
   el_opcode_to_string_map.bind(FSUB_D, "FSUB_D") ;

   el_string_to_opcode_map.bind("CONVWS", CONVWS) ;
   el_opcode_to_string_map.bind(CONVWS, "CONVWS") ;
   el_string_to_opcode_map.bind("CONVWD", CONVWD) ;
   el_opcode_to_string_map.bind(CONVWD, "CONVWD") ;
   el_string_to_opcode_map.bind("CONVSW", CONVSW) ;
   el_opcode_to_string_map.bind(CONVSW, "CONVSW") ;
   el_string_to_opcode_map.bind("CONVDW", CONVDW) ;
   el_opcode_to_string_map.bind(CONVDW, "CONVDW") ;
   el_string_to_opcode_map.bind("CONVSD", CONVSD) ;
   el_opcode_to_string_map.bind(CONVSD, "CONVSD") ;
   el_string_to_opcode_map.bind("CONVDS", CONVDS) ;
   el_opcode_to_string_map.bind(CONVDS, "CONVDS") ;
   el_string_to_opcode_map.bind("EXTS_B", EXTS_B) ;
   el_opcode_to_string_map.bind(EXTS_B, "EXTS_B") ;
   el_string_to_opcode_map.bind("EXTS_H", EXTS_H) ;
   el_opcode_to_string_map.bind(EXTS_H, "EXTS_H") ;

   el_string_to_opcode_map.bind("MOVE", MOVE) ;
   el_opcode_to_string_map.bind(MOVE, "MOVE") ;
   el_string_to_opcode_map.bind("MOVEGF_L", MOVEGF_L) ;
   el_opcode_to_string_map.bind(MOVEGF_L, "MOVEGF_L") ;
   el_string_to_opcode_map.bind("MOVEGF_U", MOVEGF_U) ;
   el_opcode_to_string_map.bind(MOVEGF_U, "MOVEGF_U") ;
   el_string_to_opcode_map.bind("MOVEF_S", MOVEF_S) ;
   el_opcode_to_string_map.bind(MOVEF_S, "MOVEF_S") ;
   el_string_to_opcode_map.bind("MOVEF_D", MOVEF_D) ;
   el_opcode_to_string_map.bind(MOVEF_D, "MOVEF_D") ;
   el_string_to_opcode_map.bind("MOVEFG_L", MOVEFG_L) ;
   el_opcode_to_string_map.bind(MOVEFG_L, "MOVEFG_L") ;
   el_string_to_opcode_map.bind("MOVEFG_U", MOVEFG_U) ;
   el_opcode_to_string_map.bind(MOVEFG_U, "MOVEFG_U") ;
   el_string_to_opcode_map.bind("MOVEPG", MOVEPG) ;
   el_opcode_to_string_map.bind(MOVEPG, "MOVEPG") ;
   el_string_to_opcode_map.bind("LDCM", LDCM) ;
   el_opcode_to_string_map.bind(LDCM, "LDCM") ;

   el_string_to_opcode_map.bind("MOVEGG", MOVEGG) ;
   el_opcode_to_string_map.bind(MOVEGG, "MOVEGG") ;
   el_string_to_opcode_map.bind("MOVEGC", MOVEGC) ;
   el_opcode_to_string_map.bind(MOVEGC, "MOVEGC") ;
   el_string_to_opcode_map.bind("MOVECG", MOVECG) ;
   el_opcode_to_string_map.bind(MOVECG, "MOVECG") ;
   el_string_to_opcode_map.bind("MOVEBB", MOVEBB) ;
   el_opcode_to_string_map.bind(MOVEBB, "MOVEBB") ;

   el_string_to_opcode_map.bind("CMPR_W_FALSE", CMPR_W_FALSE) ;
   el_opcode_to_string_map.bind(CMPR_W_FALSE, "CMPR_W_FALSE") ;
   el_string_to_opcode_map.bind("CMPR_W_EQ", CMPR_W_EQ) ;
   el_opcode_to_string_map.bind(CMPR_W_EQ, "CMPR_W_EQ") ;
   el_string_to_opcode_map.bind("CMPR_W_LT", CMPR_W_LT) ;
   el_opcode_to_string_map.bind(CMPR_W_LT, "CMPR_W_LT") ;
   el_string_to_opcode_map.bind("CMPR_W_LEQ", CMPR_W_LEQ) ;
   el_opcode_to_string_map.bind(CMPR_W_LEQ, "CMPR_W_LEQ") ;
   el_string_to_opcode_map.bind("CMPR_W_GT", CMPR_W_GT) ;
   el_opcode_to_string_map.bind(CMPR_W_GT, "CMPR_W_GT") ;
   el_string_to_opcode_map.bind("CMPR_W_GEQ", CMPR_W_GEQ) ;
   el_opcode_to_string_map.bind(CMPR_W_GEQ, "CMPR_W_GEQ") ;
   el_string_to_opcode_map.bind("CMPR_W_SV", CMPR_W_SV) ;
   el_opcode_to_string_map.bind(CMPR_W_SV, "CMPR_W_SV") ;
   el_string_to_opcode_map.bind("CMPR_W_OD", CMPR_W_OD) ;
   el_opcode_to_string_map.bind(CMPR_W_OD, "CMPR_W_OD") ;
   el_string_to_opcode_map.bind("CMPR_W_TRUE", CMPR_W_TRUE) ;
   el_opcode_to_string_map.bind(CMPR_W_TRUE, "CMPR_W_TRUE") ;
   el_string_to_opcode_map.bind("CMPR_W_NEQ", CMPR_W_NEQ) ;
   el_opcode_to_string_map.bind(CMPR_W_NEQ, "CMPR_W_NEQ") ;
   el_string_to_opcode_map.bind("CMPR_W_LLT", CMPR_W_LLT) ;
   el_opcode_to_string_map.bind(CMPR_W_LLT, "CMPR_W_LLT") ;
   el_string_to_opcode_map.bind("CMPR_W_LLEQ", CMPR_W_LLEQ) ;
   el_opcode_to_string_map.bind(CMPR_W_LLEQ, "CMPR_W_LLEQ") ;
   el_string_to_opcode_map.bind("CMPR_W_LGT", CMPR_W_LGT) ;
   el_opcode_to_string_map.bind(CMPR_W_LGT, "CMPR_W_LGT") ;
   el_string_to_opcode_map.bind("CMPR_W_LGEQ", CMPR_W_LGEQ) ;
   el_opcode_to_string_map.bind(CMPR_W_LGEQ, "CMPR_W_LGEQ") ;
   el_string_to_opcode_map.bind("CMPR_W_NSV", CMPR_W_NSV) ;
   el_opcode_to_string_map.bind(CMPR_W_NSV, "CMPR_W_NSV") ;
   el_string_to_opcode_map.bind("CMPR_W_EV", CMPR_W_EV) ;
   el_opcode_to_string_map.bind(CMPR_W_EV, "CMPR_W_EV") ;

   el_string_to_opcode_map.bind("FCMPR_S_FALSE", FCMPR_S_FALSE) ;
   el_opcode_to_string_map.bind(FCMPR_S_FALSE, "FCMPR_S_FALSE") ;
   el_string_to_opcode_map.bind("FCMPR_S_EQ", FCMPR_S_EQ) ;
   el_opcode_to_string_map.bind(FCMPR_S_EQ, "FCMPR_S_EQ") ;
   el_string_to_opcode_map.bind("FCMPR_S_LT", FCMPR_S_LT) ;
   el_opcode_to_string_map.bind(FCMPR_S_LT, "FCMPR_S_LT") ;
   el_string_to_opcode_map.bind("FCMPR_S_LEQ", FCMPR_S_LEQ) ;
   el_opcode_to_string_map.bind(FCMPR_S_LEQ, "FCMPR_S_LEQ") ;
   el_string_to_opcode_map.bind("FCMPR_S_GT", FCMPR_S_GT) ;
   el_opcode_to_string_map.bind(FCMPR_S_GT, "FCMPR_S_GT") ;
   el_string_to_opcode_map.bind("FCMPR_S_GEQ", FCMPR_S_GEQ) ;
   el_opcode_to_string_map.bind(FCMPR_S_GEQ, "FCMPR_S_GEQ") ;
   el_string_to_opcode_map.bind("FCMPR_S_NEQ", FCMPR_S_NEQ) ;
   el_opcode_to_string_map.bind(FCMPR_S_NEQ, "FCMPR_S_NEQ") ;
   el_string_to_opcode_map.bind("FCMPR_S_TRUE", FCMPR_S_TRUE) ;
   el_opcode_to_string_map.bind(FCMPR_S_TRUE, "FCMPR_S_TRUE") ;

   el_string_to_opcode_map.bind("FCMPR_D_FALSE", FCMPR_D_FALSE) ;
   el_opcode_to_string_map.bind(FCMPR_D_FALSE, "FCMPR_D_FALSE") ;
   el_string_to_opcode_map.bind("FCMPR_D_EQ", FCMPR_D_EQ) ;
   el_opcode_to_string_map.bind(FCMPR_D_EQ, "FCMPR_D_EQ") ;
   el_string_to_opcode_map.bind("FCMPR_D_LT", FCMPR_D_LT) ;
   el_opcode_to_string_map.bind(FCMPR_D_LT, "FCMPR_D_LT") ;
   el_string_to_opcode_map.bind("FCMPR_D_LEQ", FCMPR_D_LEQ) ;
   el_opcode_to_string_map.bind(FCMPR_D_LEQ, "FCMPR_D_LEQ") ;
   el_string_to_opcode_map.bind("FCMPR_D_GT", FCMPR_D_GT) ;
   el_opcode_to_string_map.bind(FCMPR_D_GT, "FCMPR_D_GT") ;
   el_string_to_opcode_map.bind("FCMPR_D_GEQ", FCMPR_D_GEQ) ;
   el_opcode_to_string_map.bind(FCMPR_D_GEQ, "FCMPR_D_GEQ") ;
   el_string_to_opcode_map.bind("FCMPR_D_NEQ", FCMPR_D_NEQ) ;
   el_opcode_to_string_map.bind(FCMPR_D_NEQ, "FCMPR_D_NEQ") ;
   el_string_to_opcode_map.bind("FCMPR_D_TRUE", FCMPR_D_TRUE) ;
   el_opcode_to_string_map.bind(FCMPR_D_TRUE, "FCMPR_D_TRUE") ;

   // New move operations used to save/restore and spill/unspill predicate 
   // registers -- VK/5/22/98
   el_string_to_opcode_map.bind("MOVEGBP", MOVEGBP) ;
   el_opcode_to_string_map.bind(MOVEGBP, "MOVEGBP") ;
   el_string_to_opcode_map.bind("MOVEGCM", MOVEGCM) ;
   el_opcode_to_string_map.bind(MOVEGCM, "MOVEGCM") ;
}

static void el_init_elcor_opcode_maps_cmpp1_1()
{
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UN_UN", (Opcode) CMPP_W_FALSE_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UN_UN, "CMPP_W_FALSE_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UN_UC", (Opcode) CMPP_W_FALSE_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UN_UC, "CMPP_W_FALSE_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UN_CN", (Opcode) CMPP_W_FALSE_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UN_CN, "CMPP_W_FALSE_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UN_CC", (Opcode) CMPP_W_FALSE_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UN_CC, "CMPP_W_FALSE_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UN_ON", (Opcode) CMPP_W_FALSE_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UN_ON, "CMPP_W_FALSE_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UN_OC", (Opcode) CMPP_W_FALSE_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UN_OC, "CMPP_W_FALSE_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UN_AN", (Opcode) CMPP_W_FALSE_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UN_AN, "CMPP_W_FALSE_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UN_AC", (Opcode) CMPP_W_FALSE_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UN_AC, "CMPP_W_FALSE_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_FALSE_UC_UN", (Opcode) CMPP_W_FALSE_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UC_UN, "CMPP_W_FALSE_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UC_UC", (Opcode) CMPP_W_FALSE_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UC_UC, "CMPP_W_FALSE_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UC_CN", (Opcode) CMPP_W_FALSE_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UC_CN, "CMPP_W_FALSE_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UC_CC", (Opcode) CMPP_W_FALSE_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UC_CC, "CMPP_W_FALSE_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UC_ON", (Opcode) CMPP_W_FALSE_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UC_ON, "CMPP_W_FALSE_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UC_OC", (Opcode) CMPP_W_FALSE_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UC_OC, "CMPP_W_FALSE_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UC_AN", (Opcode) CMPP_W_FALSE_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UC_AN, "CMPP_W_FALSE_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_UC_AC", (Opcode) CMPP_W_FALSE_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_UC_AC, "CMPP_W_FALSE_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_FALSE_CN_UN", (Opcode) CMPP_W_FALSE_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CN_UN, "CMPP_W_FALSE_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CN_UC", (Opcode) CMPP_W_FALSE_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CN_UC, "CMPP_W_FALSE_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CN_CN", (Opcode) CMPP_W_FALSE_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CN_CN, "CMPP_W_FALSE_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CN_CC", (Opcode) CMPP_W_FALSE_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CN_CC, "CMPP_W_FALSE_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CN_ON", (Opcode) CMPP_W_FALSE_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CN_ON, "CMPP_W_FALSE_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CN_OC", (Opcode) CMPP_W_FALSE_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CN_OC, "CMPP_W_FALSE_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CN_AN", (Opcode) CMPP_W_FALSE_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CN_AN, "CMPP_W_FALSE_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CN_AC", (Opcode) CMPP_W_FALSE_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CN_AC, "CMPP_W_FALSE_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_FALSE_CC_UN", (Opcode) CMPP_W_FALSE_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CC_UN, "CMPP_W_FALSE_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CC_UC", (Opcode) CMPP_W_FALSE_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CC_UC, "CMPP_W_FALSE_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CC_CN", (Opcode) CMPP_W_FALSE_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CC_CN, "CMPP_W_FALSE_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CC_CC", (Opcode) CMPP_W_FALSE_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CC_CC, "CMPP_W_FALSE_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CC_ON", (Opcode) CMPP_W_FALSE_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CC_ON, "CMPP_W_FALSE_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CC_OC", (Opcode) CMPP_W_FALSE_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CC_OC, "CMPP_W_FALSE_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CC_AN", (Opcode) CMPP_W_FALSE_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CC_AN, "CMPP_W_FALSE_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_CC_AC", (Opcode) CMPP_W_FALSE_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_CC_AC, "CMPP_W_FALSE_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_FALSE_ON_UN", (Opcode) CMPP_W_FALSE_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_ON_UN, "CMPP_W_FALSE_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_ON_UC", (Opcode) CMPP_W_FALSE_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_ON_UC, "CMPP_W_FALSE_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_ON_CN", (Opcode) CMPP_W_FALSE_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_ON_CN, "CMPP_W_FALSE_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_ON_CC", (Opcode) CMPP_W_FALSE_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_ON_CC, "CMPP_W_FALSE_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_ON_ON", (Opcode) CMPP_W_FALSE_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_ON_ON, "CMPP_W_FALSE_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_ON_OC", (Opcode) CMPP_W_FALSE_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_ON_OC, "CMPP_W_FALSE_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_ON_AN", (Opcode) CMPP_W_FALSE_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_ON_AN, "CMPP_W_FALSE_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_ON_AC", (Opcode) CMPP_W_FALSE_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_ON_AC, "CMPP_W_FALSE_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_FALSE_OC_UN", (Opcode) CMPP_W_FALSE_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_OC_UN, "CMPP_W_FALSE_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_OC_UC", (Opcode) CMPP_W_FALSE_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_OC_UC, "CMPP_W_FALSE_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_OC_CN", (Opcode) CMPP_W_FALSE_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_OC_CN, "CMPP_W_FALSE_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_OC_CC", (Opcode) CMPP_W_FALSE_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_OC_CC, "CMPP_W_FALSE_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_OC_ON", (Opcode) CMPP_W_FALSE_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_OC_ON, "CMPP_W_FALSE_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_OC_OC", (Opcode) CMPP_W_FALSE_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_OC_OC, "CMPP_W_FALSE_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_OC_AN", (Opcode) CMPP_W_FALSE_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_OC_AN, "CMPP_W_FALSE_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_OC_AC", (Opcode) CMPP_W_FALSE_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_OC_AC, "CMPP_W_FALSE_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_FALSE_AN_UN", (Opcode) CMPP_W_FALSE_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AN_UN, "CMPP_W_FALSE_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AN_UC", (Opcode) CMPP_W_FALSE_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AN_UC, "CMPP_W_FALSE_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AN_CN", (Opcode) CMPP_W_FALSE_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AN_CN, "CMPP_W_FALSE_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AN_CC", (Opcode) CMPP_W_FALSE_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AN_CC, "CMPP_W_FALSE_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AN_ON", (Opcode) CMPP_W_FALSE_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AN_ON, "CMPP_W_FALSE_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AN_OC", (Opcode) CMPP_W_FALSE_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AN_OC, "CMPP_W_FALSE_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AN_AN", (Opcode) CMPP_W_FALSE_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AN_AN, "CMPP_W_FALSE_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AN_AC", (Opcode) CMPP_W_FALSE_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AN_AC, "CMPP_W_FALSE_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_FALSE_AC_UN", (Opcode) CMPP_W_FALSE_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AC_UN, "CMPP_W_FALSE_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AC_UC", (Opcode) CMPP_W_FALSE_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AC_UC, "CMPP_W_FALSE_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AC_CN", (Opcode) CMPP_W_FALSE_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AC_CN, "CMPP_W_FALSE_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AC_CC", (Opcode) CMPP_W_FALSE_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AC_CC, "CMPP_W_FALSE_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AC_ON", (Opcode) CMPP_W_FALSE_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AC_ON, "CMPP_W_FALSE_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AC_OC", (Opcode) CMPP_W_FALSE_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AC_OC, "CMPP_W_FALSE_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AC_AN", (Opcode) CMPP_W_FALSE_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AC_AN, "CMPP_W_FALSE_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_FALSE_AC_AC", (Opcode) CMPP_W_FALSE_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_FALSE_AC_AC, "CMPP_W_FALSE_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp1_2()
{
   el_string_to_opcode_map.bind("CMPP_W_EQ_UN_UN", (Opcode) CMPP_W_EQ_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UN_UN, "CMPP_W_EQ_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UN_UC", (Opcode) CMPP_W_EQ_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UN_UC, "CMPP_W_EQ_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UN_CN", (Opcode) CMPP_W_EQ_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UN_CN, "CMPP_W_EQ_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UN_CC", (Opcode) CMPP_W_EQ_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UN_CC, "CMPP_W_EQ_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UN_ON", (Opcode) CMPP_W_EQ_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UN_ON, "CMPP_W_EQ_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UN_OC", (Opcode) CMPP_W_EQ_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UN_OC, "CMPP_W_EQ_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UN_AN", (Opcode) CMPP_W_EQ_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UN_AN, "CMPP_W_EQ_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UN_AC", (Opcode) CMPP_W_EQ_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UN_AC, "CMPP_W_EQ_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_EQ_UC_UN", (Opcode) CMPP_W_EQ_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UC_UN, "CMPP_W_EQ_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UC_UC", (Opcode) CMPP_W_EQ_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UC_UC, "CMPP_W_EQ_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UC_CN", (Opcode) CMPP_W_EQ_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UC_CN, "CMPP_W_EQ_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UC_CC", (Opcode) CMPP_W_EQ_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UC_CC, "CMPP_W_EQ_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UC_ON", (Opcode) CMPP_W_EQ_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UC_ON, "CMPP_W_EQ_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UC_OC", (Opcode) CMPP_W_EQ_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UC_OC, "CMPP_W_EQ_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UC_AN", (Opcode) CMPP_W_EQ_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UC_AN, "CMPP_W_EQ_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_UC_AC", (Opcode) CMPP_W_EQ_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_UC_AC, "CMPP_W_EQ_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_EQ_CN_UN", (Opcode) CMPP_W_EQ_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CN_UN, "CMPP_W_EQ_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CN_UC", (Opcode) CMPP_W_EQ_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CN_UC, "CMPP_W_EQ_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CN_CN", (Opcode) CMPP_W_EQ_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CN_CN, "CMPP_W_EQ_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CN_CC", (Opcode) CMPP_W_EQ_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CN_CC, "CMPP_W_EQ_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CN_ON", (Opcode) CMPP_W_EQ_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CN_ON, "CMPP_W_EQ_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CN_OC", (Opcode) CMPP_W_EQ_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CN_OC, "CMPP_W_EQ_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CN_AN", (Opcode) CMPP_W_EQ_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CN_AN, "CMPP_W_EQ_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CN_AC", (Opcode) CMPP_W_EQ_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CN_AC, "CMPP_W_EQ_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_EQ_CC_UN", (Opcode) CMPP_W_EQ_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CC_UN, "CMPP_W_EQ_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CC_UC", (Opcode) CMPP_W_EQ_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CC_UC, "CMPP_W_EQ_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CC_CN", (Opcode) CMPP_W_EQ_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CC_CN, "CMPP_W_EQ_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CC_CC", (Opcode) CMPP_W_EQ_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CC_CC, "CMPP_W_EQ_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CC_ON", (Opcode) CMPP_W_EQ_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CC_ON, "CMPP_W_EQ_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CC_OC", (Opcode) CMPP_W_EQ_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CC_OC, "CMPP_W_EQ_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CC_AN", (Opcode) CMPP_W_EQ_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CC_AN, "CMPP_W_EQ_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_CC_AC", (Opcode) CMPP_W_EQ_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_CC_AC, "CMPP_W_EQ_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_EQ_ON_UN", (Opcode) CMPP_W_EQ_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_ON_UN, "CMPP_W_EQ_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_ON_UC", (Opcode) CMPP_W_EQ_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_ON_UC, "CMPP_W_EQ_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_ON_CN", (Opcode) CMPP_W_EQ_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_ON_CN, "CMPP_W_EQ_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_ON_CC", (Opcode) CMPP_W_EQ_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_ON_CC, "CMPP_W_EQ_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_ON_ON", (Opcode) CMPP_W_EQ_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_ON_ON, "CMPP_W_EQ_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_ON_OC", (Opcode) CMPP_W_EQ_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_ON_OC, "CMPP_W_EQ_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_ON_AN", (Opcode) CMPP_W_EQ_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_ON_AN, "CMPP_W_EQ_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_ON_AC", (Opcode) CMPP_W_EQ_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_ON_AC, "CMPP_W_EQ_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_EQ_OC_UN", (Opcode) CMPP_W_EQ_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_OC_UN, "CMPP_W_EQ_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_OC_UC", (Opcode) CMPP_W_EQ_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_OC_UC, "CMPP_W_EQ_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_OC_CN", (Opcode) CMPP_W_EQ_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_OC_CN, "CMPP_W_EQ_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_OC_CC", (Opcode) CMPP_W_EQ_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_OC_CC, "CMPP_W_EQ_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_OC_ON", (Opcode) CMPP_W_EQ_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_OC_ON, "CMPP_W_EQ_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_OC_OC", (Opcode) CMPP_W_EQ_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_OC_OC, "CMPP_W_EQ_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_OC_AN", (Opcode) CMPP_W_EQ_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_OC_AN, "CMPP_W_EQ_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_OC_AC", (Opcode) CMPP_W_EQ_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_OC_AC, "CMPP_W_EQ_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_EQ_AN_UN", (Opcode) CMPP_W_EQ_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AN_UN, "CMPP_W_EQ_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AN_UC", (Opcode) CMPP_W_EQ_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AN_UC, "CMPP_W_EQ_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AN_CN", (Opcode) CMPP_W_EQ_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AN_CN, "CMPP_W_EQ_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AN_CC", (Opcode) CMPP_W_EQ_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AN_CC, "CMPP_W_EQ_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AN_ON", (Opcode) CMPP_W_EQ_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AN_ON, "CMPP_W_EQ_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AN_OC", (Opcode) CMPP_W_EQ_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AN_OC, "CMPP_W_EQ_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AN_AN", (Opcode) CMPP_W_EQ_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AN_AN, "CMPP_W_EQ_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AN_AC", (Opcode) CMPP_W_EQ_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AN_AC, "CMPP_W_EQ_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_EQ_AC_UN", (Opcode) CMPP_W_EQ_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AC_UN, "CMPP_W_EQ_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AC_UC", (Opcode) CMPP_W_EQ_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AC_UC, "CMPP_W_EQ_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AC_CN", (Opcode) CMPP_W_EQ_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AC_CN, "CMPP_W_EQ_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AC_CC", (Opcode) CMPP_W_EQ_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AC_CC, "CMPP_W_EQ_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AC_ON", (Opcode) CMPP_W_EQ_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AC_ON, "CMPP_W_EQ_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AC_OC", (Opcode) CMPP_W_EQ_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AC_OC, "CMPP_W_EQ_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AC_AN", (Opcode) CMPP_W_EQ_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AC_AN, "CMPP_W_EQ_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_EQ_AC_AC", (Opcode) CMPP_W_EQ_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_EQ_AC_AC, "CMPP_W_EQ_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp1_3()
{
   el_string_to_opcode_map.bind("CMPP_W_LT_UN_UN", (Opcode) CMPP_W_LT_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UN_UN, "CMPP_W_LT_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UN_UC", (Opcode) CMPP_W_LT_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UN_UC, "CMPP_W_LT_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UN_CN", (Opcode) CMPP_W_LT_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UN_CN, "CMPP_W_LT_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UN_CC", (Opcode) CMPP_W_LT_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UN_CC, "CMPP_W_LT_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UN_ON", (Opcode) CMPP_W_LT_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UN_ON, "CMPP_W_LT_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UN_OC", (Opcode) CMPP_W_LT_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UN_OC, "CMPP_W_LT_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UN_AN", (Opcode) CMPP_W_LT_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UN_AN, "CMPP_W_LT_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UN_AC", (Opcode) CMPP_W_LT_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UN_AC, "CMPP_W_LT_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LT_UC_UN", (Opcode) CMPP_W_LT_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UC_UN, "CMPP_W_LT_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UC_UC", (Opcode) CMPP_W_LT_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UC_UC, "CMPP_W_LT_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UC_CN", (Opcode) CMPP_W_LT_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UC_CN, "CMPP_W_LT_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UC_CC", (Opcode) CMPP_W_LT_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UC_CC, "CMPP_W_LT_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UC_ON", (Opcode) CMPP_W_LT_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UC_ON, "CMPP_W_LT_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UC_OC", (Opcode) CMPP_W_LT_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UC_OC, "CMPP_W_LT_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UC_AN", (Opcode) CMPP_W_LT_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UC_AN, "CMPP_W_LT_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_UC_AC", (Opcode) CMPP_W_LT_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_UC_AC, "CMPP_W_LT_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LT_CN_UN", (Opcode) CMPP_W_LT_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CN_UN, "CMPP_W_LT_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CN_UC", (Opcode) CMPP_W_LT_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CN_UC, "CMPP_W_LT_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CN_CN", (Opcode) CMPP_W_LT_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CN_CN, "CMPP_W_LT_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CN_CC", (Opcode) CMPP_W_LT_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CN_CC, "CMPP_W_LT_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CN_ON", (Opcode) CMPP_W_LT_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CN_ON, "CMPP_W_LT_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CN_OC", (Opcode) CMPP_W_LT_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CN_OC, "CMPP_W_LT_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CN_AN", (Opcode) CMPP_W_LT_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CN_AN, "CMPP_W_LT_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CN_AC", (Opcode) CMPP_W_LT_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CN_AC, "CMPP_W_LT_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LT_CC_UN", (Opcode) CMPP_W_LT_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CC_UN, "CMPP_W_LT_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CC_UC", (Opcode) CMPP_W_LT_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CC_UC, "CMPP_W_LT_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CC_CN", (Opcode) CMPP_W_LT_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CC_CN, "CMPP_W_LT_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CC_CC", (Opcode) CMPP_W_LT_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CC_CC, "CMPP_W_LT_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CC_ON", (Opcode) CMPP_W_LT_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CC_ON, "CMPP_W_LT_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CC_OC", (Opcode) CMPP_W_LT_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CC_OC, "CMPP_W_LT_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CC_AN", (Opcode) CMPP_W_LT_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CC_AN, "CMPP_W_LT_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_CC_AC", (Opcode) CMPP_W_LT_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_CC_AC, "CMPP_W_LT_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LT_ON_UN", (Opcode) CMPP_W_LT_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_ON_UN, "CMPP_W_LT_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_ON_UC", (Opcode) CMPP_W_LT_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_ON_UC, "CMPP_W_LT_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_ON_CN", (Opcode) CMPP_W_LT_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_ON_CN, "CMPP_W_LT_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_ON_CC", (Opcode) CMPP_W_LT_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_ON_CC, "CMPP_W_LT_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_ON_ON", (Opcode) CMPP_W_LT_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_ON_ON, "CMPP_W_LT_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_ON_OC", (Opcode) CMPP_W_LT_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_ON_OC, "CMPP_W_LT_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_ON_AN", (Opcode) CMPP_W_LT_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_ON_AN, "CMPP_W_LT_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_ON_AC", (Opcode) CMPP_W_LT_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_ON_AC, "CMPP_W_LT_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LT_OC_UN", (Opcode) CMPP_W_LT_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_OC_UN, "CMPP_W_LT_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_OC_UC", (Opcode) CMPP_W_LT_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_OC_UC, "CMPP_W_LT_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_OC_CN", (Opcode) CMPP_W_LT_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_OC_CN, "CMPP_W_LT_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_OC_CC", (Opcode) CMPP_W_LT_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_OC_CC, "CMPP_W_LT_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_OC_ON", (Opcode) CMPP_W_LT_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_OC_ON, "CMPP_W_LT_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_OC_OC", (Opcode) CMPP_W_LT_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_OC_OC, "CMPP_W_LT_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_OC_AN", (Opcode) CMPP_W_LT_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_OC_AN, "CMPP_W_LT_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_OC_AC", (Opcode) CMPP_W_LT_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_OC_AC, "CMPP_W_LT_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LT_AN_UN", (Opcode) CMPP_W_LT_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AN_UN, "CMPP_W_LT_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AN_UC", (Opcode) CMPP_W_LT_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AN_UC, "CMPP_W_LT_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AN_CN", (Opcode) CMPP_W_LT_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AN_CN, "CMPP_W_LT_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AN_CC", (Opcode) CMPP_W_LT_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AN_CC, "CMPP_W_LT_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AN_ON", (Opcode) CMPP_W_LT_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AN_ON, "CMPP_W_LT_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AN_OC", (Opcode) CMPP_W_LT_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AN_OC, "CMPP_W_LT_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AN_AN", (Opcode) CMPP_W_LT_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AN_AN, "CMPP_W_LT_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AN_AC", (Opcode) CMPP_W_LT_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AN_AC, "CMPP_W_LT_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LT_AC_UN", (Opcode) CMPP_W_LT_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AC_UN, "CMPP_W_LT_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AC_UC", (Opcode) CMPP_W_LT_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AC_UC, "CMPP_W_LT_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AC_CN", (Opcode) CMPP_W_LT_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AC_CN, "CMPP_W_LT_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AC_CC", (Opcode) CMPP_W_LT_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AC_CC, "CMPP_W_LT_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AC_ON", (Opcode) CMPP_W_LT_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AC_ON, "CMPP_W_LT_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AC_OC", (Opcode) CMPP_W_LT_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AC_OC, "CMPP_W_LT_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AC_AN", (Opcode) CMPP_W_LT_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AC_AN, "CMPP_W_LT_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LT_AC_AC", (Opcode) CMPP_W_LT_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LT_AC_AC, "CMPP_W_LT_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp1_4()
{
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UN_UN", (Opcode) CMPP_W_LEQ_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UN_UN, "CMPP_W_LEQ_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UN_UC", (Opcode) CMPP_W_LEQ_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UN_UC, "CMPP_W_LEQ_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UN_CN", (Opcode) CMPP_W_LEQ_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UN_CN, "CMPP_W_LEQ_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UN_CC", (Opcode) CMPP_W_LEQ_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UN_CC, "CMPP_W_LEQ_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UN_ON", (Opcode) CMPP_W_LEQ_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UN_ON, "CMPP_W_LEQ_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UN_OC", (Opcode) CMPP_W_LEQ_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UN_OC, "CMPP_W_LEQ_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UN_AN", (Opcode) CMPP_W_LEQ_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UN_AN, "CMPP_W_LEQ_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UN_AC", (Opcode) CMPP_W_LEQ_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UN_AC, "CMPP_W_LEQ_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LEQ_UC_UN", (Opcode) CMPP_W_LEQ_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UC_UN, "CMPP_W_LEQ_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UC_UC", (Opcode) CMPP_W_LEQ_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UC_UC, "CMPP_W_LEQ_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UC_CN", (Opcode) CMPP_W_LEQ_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UC_CN, "CMPP_W_LEQ_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UC_CC", (Opcode) CMPP_W_LEQ_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UC_CC, "CMPP_W_LEQ_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UC_ON", (Opcode) CMPP_W_LEQ_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UC_ON, "CMPP_W_LEQ_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UC_OC", (Opcode) CMPP_W_LEQ_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UC_OC, "CMPP_W_LEQ_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UC_AN", (Opcode) CMPP_W_LEQ_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UC_AN, "CMPP_W_LEQ_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_UC_AC", (Opcode) CMPP_W_LEQ_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_UC_AC, "CMPP_W_LEQ_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LEQ_CN_UN", (Opcode) CMPP_W_LEQ_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CN_UN, "CMPP_W_LEQ_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CN_UC", (Opcode) CMPP_W_LEQ_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CN_UC, "CMPP_W_LEQ_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CN_CN", (Opcode) CMPP_W_LEQ_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CN_CN, "CMPP_W_LEQ_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CN_CC", (Opcode) CMPP_W_LEQ_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CN_CC, "CMPP_W_LEQ_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CN_ON", (Opcode) CMPP_W_LEQ_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CN_ON, "CMPP_W_LEQ_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CN_OC", (Opcode) CMPP_W_LEQ_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CN_OC, "CMPP_W_LEQ_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CN_AN", (Opcode) CMPP_W_LEQ_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CN_AN, "CMPP_W_LEQ_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CN_AC", (Opcode) CMPP_W_LEQ_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CN_AC, "CMPP_W_LEQ_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LEQ_CC_UN", (Opcode) CMPP_W_LEQ_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CC_UN, "CMPP_W_LEQ_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CC_UC", (Opcode) CMPP_W_LEQ_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CC_UC, "CMPP_W_LEQ_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CC_CN", (Opcode) CMPP_W_LEQ_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CC_CN, "CMPP_W_LEQ_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CC_CC", (Opcode) CMPP_W_LEQ_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CC_CC, "CMPP_W_LEQ_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CC_ON", (Opcode) CMPP_W_LEQ_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CC_ON, "CMPP_W_LEQ_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CC_OC", (Opcode) CMPP_W_LEQ_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CC_OC, "CMPP_W_LEQ_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CC_AN", (Opcode) CMPP_W_LEQ_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CC_AN, "CMPP_W_LEQ_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_CC_AC", (Opcode) CMPP_W_LEQ_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_CC_AC, "CMPP_W_LEQ_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LEQ_ON_UN", (Opcode) CMPP_W_LEQ_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_ON_UN, "CMPP_W_LEQ_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_ON_UC", (Opcode) CMPP_W_LEQ_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_ON_UC, "CMPP_W_LEQ_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_ON_CN", (Opcode) CMPP_W_LEQ_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_ON_CN, "CMPP_W_LEQ_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_ON_CC", (Opcode) CMPP_W_LEQ_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_ON_CC, "CMPP_W_LEQ_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_ON_ON", (Opcode) CMPP_W_LEQ_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_ON_ON, "CMPP_W_LEQ_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_ON_OC", (Opcode) CMPP_W_LEQ_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_ON_OC, "CMPP_W_LEQ_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_ON_AN", (Opcode) CMPP_W_LEQ_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_ON_AN, "CMPP_W_LEQ_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_ON_AC", (Opcode) CMPP_W_LEQ_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_ON_AC, "CMPP_W_LEQ_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LEQ_OC_UN", (Opcode) CMPP_W_LEQ_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_OC_UN, "CMPP_W_LEQ_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_OC_UC", (Opcode) CMPP_W_LEQ_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_OC_UC, "CMPP_W_LEQ_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_OC_CN", (Opcode) CMPP_W_LEQ_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_OC_CN, "CMPP_W_LEQ_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_OC_CC", (Opcode) CMPP_W_LEQ_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_OC_CC, "CMPP_W_LEQ_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_OC_ON", (Opcode) CMPP_W_LEQ_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_OC_ON, "CMPP_W_LEQ_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_OC_OC", (Opcode) CMPP_W_LEQ_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_OC_OC, "CMPP_W_LEQ_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_OC_AN", (Opcode) CMPP_W_LEQ_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_OC_AN, "CMPP_W_LEQ_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_OC_AC", (Opcode) CMPP_W_LEQ_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_OC_AC, "CMPP_W_LEQ_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LEQ_AN_UN", (Opcode) CMPP_W_LEQ_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AN_UN, "CMPP_W_LEQ_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AN_UC", (Opcode) CMPP_W_LEQ_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AN_UC, "CMPP_W_LEQ_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AN_CN", (Opcode) CMPP_W_LEQ_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AN_CN, "CMPP_W_LEQ_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AN_CC", (Opcode) CMPP_W_LEQ_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AN_CC, "CMPP_W_LEQ_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AN_ON", (Opcode) CMPP_W_LEQ_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AN_ON, "CMPP_W_LEQ_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AN_OC", (Opcode) CMPP_W_LEQ_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AN_OC, "CMPP_W_LEQ_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AN_AN", (Opcode) CMPP_W_LEQ_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AN_AN, "CMPP_W_LEQ_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AN_AC", (Opcode) CMPP_W_LEQ_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AN_AC, "CMPP_W_LEQ_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LEQ_AC_UN", (Opcode) CMPP_W_LEQ_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AC_UN, "CMPP_W_LEQ_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AC_UC", (Opcode) CMPP_W_LEQ_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AC_UC, "CMPP_W_LEQ_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AC_CN", (Opcode) CMPP_W_LEQ_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AC_CN, "CMPP_W_LEQ_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AC_CC", (Opcode) CMPP_W_LEQ_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AC_CC, "CMPP_W_LEQ_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AC_ON", (Opcode) CMPP_W_LEQ_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AC_ON, "CMPP_W_LEQ_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AC_OC", (Opcode) CMPP_W_LEQ_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AC_OC, "CMPP_W_LEQ_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AC_AN", (Opcode) CMPP_W_LEQ_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AC_AN, "CMPP_W_LEQ_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LEQ_AC_AC", (Opcode) CMPP_W_LEQ_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LEQ_AC_AC, "CMPP_W_LEQ_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp1_5()
{
   el_string_to_opcode_map.bind("CMPP_W_GT_UN_UN", (Opcode) CMPP_W_GT_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UN_UN, "CMPP_W_GT_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UN_UC", (Opcode) CMPP_W_GT_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UN_UC, "CMPP_W_GT_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UN_CN", (Opcode) CMPP_W_GT_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UN_CN, "CMPP_W_GT_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UN_CC", (Opcode) CMPP_W_GT_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UN_CC, "CMPP_W_GT_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UN_ON", (Opcode) CMPP_W_GT_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UN_ON, "CMPP_W_GT_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UN_OC", (Opcode) CMPP_W_GT_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UN_OC, "CMPP_W_GT_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UN_AN", (Opcode) CMPP_W_GT_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UN_AN, "CMPP_W_GT_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UN_AC", (Opcode) CMPP_W_GT_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UN_AC, "CMPP_W_GT_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GT_UC_UN", (Opcode) CMPP_W_GT_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UC_UN, "CMPP_W_GT_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UC_UC", (Opcode) CMPP_W_GT_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UC_UC, "CMPP_W_GT_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UC_CN", (Opcode) CMPP_W_GT_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UC_CN, "CMPP_W_GT_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UC_CC", (Opcode) CMPP_W_GT_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UC_CC, "CMPP_W_GT_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UC_ON", (Opcode) CMPP_W_GT_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UC_ON, "CMPP_W_GT_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UC_OC", (Opcode) CMPP_W_GT_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UC_OC, "CMPP_W_GT_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UC_AN", (Opcode) CMPP_W_GT_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UC_AN, "CMPP_W_GT_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_UC_AC", (Opcode) CMPP_W_GT_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_UC_AC, "CMPP_W_GT_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GT_CN_UN", (Opcode) CMPP_W_GT_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CN_UN, "CMPP_W_GT_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CN_UC", (Opcode) CMPP_W_GT_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CN_UC, "CMPP_W_GT_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CN_CN", (Opcode) CMPP_W_GT_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CN_CN, "CMPP_W_GT_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CN_CC", (Opcode) CMPP_W_GT_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CN_CC, "CMPP_W_GT_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CN_ON", (Opcode) CMPP_W_GT_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CN_ON, "CMPP_W_GT_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CN_OC", (Opcode) CMPP_W_GT_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CN_OC, "CMPP_W_GT_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CN_AN", (Opcode) CMPP_W_GT_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CN_AN, "CMPP_W_GT_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CN_AC", (Opcode) CMPP_W_GT_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CN_AC, "CMPP_W_GT_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GT_CC_UN", (Opcode) CMPP_W_GT_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CC_UN, "CMPP_W_GT_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CC_UC", (Opcode) CMPP_W_GT_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CC_UC, "CMPP_W_GT_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CC_CN", (Opcode) CMPP_W_GT_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CC_CN, "CMPP_W_GT_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CC_CC", (Opcode) CMPP_W_GT_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CC_CC, "CMPP_W_GT_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CC_ON", (Opcode) CMPP_W_GT_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CC_ON, "CMPP_W_GT_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CC_OC", (Opcode) CMPP_W_GT_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CC_OC, "CMPP_W_GT_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CC_AN", (Opcode) CMPP_W_GT_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CC_AN, "CMPP_W_GT_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_CC_AC", (Opcode) CMPP_W_GT_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_CC_AC, "CMPP_W_GT_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GT_ON_UN", (Opcode) CMPP_W_GT_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_ON_UN, "CMPP_W_GT_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_ON_UC", (Opcode) CMPP_W_GT_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_ON_UC, "CMPP_W_GT_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_ON_CN", (Opcode) CMPP_W_GT_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_ON_CN, "CMPP_W_GT_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_ON_CC", (Opcode) CMPP_W_GT_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_ON_CC, "CMPP_W_GT_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_ON_ON", (Opcode) CMPP_W_GT_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_ON_ON, "CMPP_W_GT_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_ON_OC", (Opcode) CMPP_W_GT_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_ON_OC, "CMPP_W_GT_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_ON_AN", (Opcode) CMPP_W_GT_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_ON_AN, "CMPP_W_GT_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_ON_AC", (Opcode) CMPP_W_GT_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_ON_AC, "CMPP_W_GT_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GT_OC_UN", (Opcode) CMPP_W_GT_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_OC_UN, "CMPP_W_GT_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_OC_UC", (Opcode) CMPP_W_GT_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_OC_UC, "CMPP_W_GT_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_OC_CN", (Opcode) CMPP_W_GT_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_OC_CN, "CMPP_W_GT_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_OC_CC", (Opcode) CMPP_W_GT_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_OC_CC, "CMPP_W_GT_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_OC_ON", (Opcode) CMPP_W_GT_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_OC_ON, "CMPP_W_GT_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_OC_OC", (Opcode) CMPP_W_GT_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_OC_OC, "CMPP_W_GT_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_OC_AN", (Opcode) CMPP_W_GT_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_OC_AN, "CMPP_W_GT_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_OC_AC", (Opcode) CMPP_W_GT_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_OC_AC, "CMPP_W_GT_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GT_AN_UN", (Opcode) CMPP_W_GT_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AN_UN, "CMPP_W_GT_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AN_UC", (Opcode) CMPP_W_GT_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AN_UC, "CMPP_W_GT_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AN_CN", (Opcode) CMPP_W_GT_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AN_CN, "CMPP_W_GT_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AN_CC", (Opcode) CMPP_W_GT_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AN_CC, "CMPP_W_GT_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AN_ON", (Opcode) CMPP_W_GT_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AN_ON, "CMPP_W_GT_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AN_OC", (Opcode) CMPP_W_GT_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AN_OC, "CMPP_W_GT_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AN_AN", (Opcode) CMPP_W_GT_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AN_AN, "CMPP_W_GT_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AN_AC", (Opcode) CMPP_W_GT_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AN_AC, "CMPP_W_GT_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GT_AC_UN", (Opcode) CMPP_W_GT_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AC_UN, "CMPP_W_GT_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AC_UC", (Opcode) CMPP_W_GT_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AC_UC, "CMPP_W_GT_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AC_CN", (Opcode) CMPP_W_GT_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AC_CN, "CMPP_W_GT_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AC_CC", (Opcode) CMPP_W_GT_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AC_CC, "CMPP_W_GT_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AC_ON", (Opcode) CMPP_W_GT_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AC_ON, "CMPP_W_GT_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AC_OC", (Opcode) CMPP_W_GT_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AC_OC, "CMPP_W_GT_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AC_AN", (Opcode) CMPP_W_GT_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AC_AN, "CMPP_W_GT_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GT_AC_AC", (Opcode) CMPP_W_GT_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GT_AC_AC, "CMPP_W_GT_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp1_6()
{
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UN_UN", (Opcode) CMPP_W_GEQ_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UN_UN, "CMPP_W_GEQ_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UN_UC", (Opcode) CMPP_W_GEQ_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UN_UC, "CMPP_W_GEQ_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UN_CN", (Opcode) CMPP_W_GEQ_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UN_CN, "CMPP_W_GEQ_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UN_CC", (Opcode) CMPP_W_GEQ_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UN_CC, "CMPP_W_GEQ_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UN_ON", (Opcode) CMPP_W_GEQ_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UN_ON, "CMPP_W_GEQ_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UN_OC", (Opcode) CMPP_W_GEQ_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UN_OC, "CMPP_W_GEQ_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UN_AN", (Opcode) CMPP_W_GEQ_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UN_AN, "CMPP_W_GEQ_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UN_AC", (Opcode) CMPP_W_GEQ_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UN_AC, "CMPP_W_GEQ_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GEQ_UC_UN", (Opcode) CMPP_W_GEQ_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UC_UN, "CMPP_W_GEQ_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UC_UC", (Opcode) CMPP_W_GEQ_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UC_UC, "CMPP_W_GEQ_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UC_CN", (Opcode) CMPP_W_GEQ_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UC_CN, "CMPP_W_GEQ_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UC_CC", (Opcode) CMPP_W_GEQ_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UC_CC, "CMPP_W_GEQ_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UC_ON", (Opcode) CMPP_W_GEQ_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UC_ON, "CMPP_W_GEQ_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UC_OC", (Opcode) CMPP_W_GEQ_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UC_OC, "CMPP_W_GEQ_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UC_AN", (Opcode) CMPP_W_GEQ_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UC_AN, "CMPP_W_GEQ_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_UC_AC", (Opcode) CMPP_W_GEQ_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_UC_AC, "CMPP_W_GEQ_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GEQ_CN_UN", (Opcode) CMPP_W_GEQ_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CN_UN, "CMPP_W_GEQ_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CN_UC", (Opcode) CMPP_W_GEQ_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CN_UC, "CMPP_W_GEQ_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CN_CN", (Opcode) CMPP_W_GEQ_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CN_CN, "CMPP_W_GEQ_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CN_CC", (Opcode) CMPP_W_GEQ_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CN_CC, "CMPP_W_GEQ_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CN_ON", (Opcode) CMPP_W_GEQ_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CN_ON, "CMPP_W_GEQ_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CN_OC", (Opcode) CMPP_W_GEQ_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CN_OC, "CMPP_W_GEQ_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CN_AN", (Opcode) CMPP_W_GEQ_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CN_AN, "CMPP_W_GEQ_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CN_AC", (Opcode) CMPP_W_GEQ_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CN_AC, "CMPP_W_GEQ_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GEQ_CC_UN", (Opcode) CMPP_W_GEQ_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CC_UN, "CMPP_W_GEQ_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CC_UC", (Opcode) CMPP_W_GEQ_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CC_UC, "CMPP_W_GEQ_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CC_CN", (Opcode) CMPP_W_GEQ_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CC_CN, "CMPP_W_GEQ_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CC_CC", (Opcode) CMPP_W_GEQ_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CC_CC, "CMPP_W_GEQ_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CC_ON", (Opcode) CMPP_W_GEQ_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CC_ON, "CMPP_W_GEQ_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CC_OC", (Opcode) CMPP_W_GEQ_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CC_OC, "CMPP_W_GEQ_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CC_AN", (Opcode) CMPP_W_GEQ_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CC_AN, "CMPP_W_GEQ_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_CC_AC", (Opcode) CMPP_W_GEQ_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_CC_AC, "CMPP_W_GEQ_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GEQ_ON_UN", (Opcode) CMPP_W_GEQ_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_ON_UN, "CMPP_W_GEQ_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_ON_UC", (Opcode) CMPP_W_GEQ_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_ON_UC, "CMPP_W_GEQ_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_ON_CN", (Opcode) CMPP_W_GEQ_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_ON_CN, "CMPP_W_GEQ_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_ON_CC", (Opcode) CMPP_W_GEQ_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_ON_CC, "CMPP_W_GEQ_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_ON_ON", (Opcode) CMPP_W_GEQ_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_ON_ON, "CMPP_W_GEQ_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_ON_OC", (Opcode) CMPP_W_GEQ_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_ON_OC, "CMPP_W_GEQ_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_ON_AN", (Opcode) CMPP_W_GEQ_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_ON_AN, "CMPP_W_GEQ_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_ON_AC", (Opcode) CMPP_W_GEQ_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_ON_AC, "CMPP_W_GEQ_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GEQ_OC_UN", (Opcode) CMPP_W_GEQ_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_OC_UN, "CMPP_W_GEQ_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_OC_UC", (Opcode) CMPP_W_GEQ_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_OC_UC, "CMPP_W_GEQ_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_OC_CN", (Opcode) CMPP_W_GEQ_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_OC_CN, "CMPP_W_GEQ_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_OC_CC", (Opcode) CMPP_W_GEQ_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_OC_CC, "CMPP_W_GEQ_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_OC_ON", (Opcode) CMPP_W_GEQ_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_OC_ON, "CMPP_W_GEQ_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_OC_OC", (Opcode) CMPP_W_GEQ_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_OC_OC, "CMPP_W_GEQ_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_OC_AN", (Opcode) CMPP_W_GEQ_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_OC_AN, "CMPP_W_GEQ_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_OC_AC", (Opcode) CMPP_W_GEQ_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_OC_AC, "CMPP_W_GEQ_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GEQ_AN_UN", (Opcode) CMPP_W_GEQ_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AN_UN, "CMPP_W_GEQ_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AN_UC", (Opcode) CMPP_W_GEQ_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AN_UC, "CMPP_W_GEQ_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AN_CN", (Opcode) CMPP_W_GEQ_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AN_CN, "CMPP_W_GEQ_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AN_CC", (Opcode) CMPP_W_GEQ_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AN_CC, "CMPP_W_GEQ_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AN_ON", (Opcode) CMPP_W_GEQ_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AN_ON, "CMPP_W_GEQ_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AN_OC", (Opcode) CMPP_W_GEQ_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AN_OC, "CMPP_W_GEQ_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AN_AN", (Opcode) CMPP_W_GEQ_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AN_AN, "CMPP_W_GEQ_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AN_AC", (Opcode) CMPP_W_GEQ_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AN_AC, "CMPP_W_GEQ_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_GEQ_AC_UN", (Opcode) CMPP_W_GEQ_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AC_UN, "CMPP_W_GEQ_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AC_UC", (Opcode) CMPP_W_GEQ_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AC_UC, "CMPP_W_GEQ_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AC_CN", (Opcode) CMPP_W_GEQ_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AC_CN, "CMPP_W_GEQ_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AC_CC", (Opcode) CMPP_W_GEQ_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AC_CC, "CMPP_W_GEQ_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AC_ON", (Opcode) CMPP_W_GEQ_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AC_ON, "CMPP_W_GEQ_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AC_OC", (Opcode) CMPP_W_GEQ_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AC_OC, "CMPP_W_GEQ_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AC_AN", (Opcode) CMPP_W_GEQ_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AC_AN, "CMPP_W_GEQ_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_GEQ_AC_AC", (Opcode) CMPP_W_GEQ_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_GEQ_AC_AC, "CMPP_W_GEQ_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp1_7()
{
   el_string_to_opcode_map.bind("CMPP_W_SV_UN_UN", (Opcode) CMPP_W_SV_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UN_UN, "CMPP_W_SV_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UN_UC", (Opcode) CMPP_W_SV_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UN_UC, "CMPP_W_SV_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UN_CN", (Opcode) CMPP_W_SV_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UN_CN, "CMPP_W_SV_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UN_CC", (Opcode) CMPP_W_SV_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UN_CC, "CMPP_W_SV_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UN_ON", (Opcode) CMPP_W_SV_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UN_ON, "CMPP_W_SV_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UN_OC", (Opcode) CMPP_W_SV_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UN_OC, "CMPP_W_SV_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UN_AN", (Opcode) CMPP_W_SV_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UN_AN, "CMPP_W_SV_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UN_AC", (Opcode) CMPP_W_SV_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UN_AC, "CMPP_W_SV_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_SV_UC_UN", (Opcode) CMPP_W_SV_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UC_UN, "CMPP_W_SV_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UC_UC", (Opcode) CMPP_W_SV_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UC_UC, "CMPP_W_SV_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UC_CN", (Opcode) CMPP_W_SV_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UC_CN, "CMPP_W_SV_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UC_CC", (Opcode) CMPP_W_SV_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UC_CC, "CMPP_W_SV_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UC_ON", (Opcode) CMPP_W_SV_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UC_ON, "CMPP_W_SV_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UC_OC", (Opcode) CMPP_W_SV_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UC_OC, "CMPP_W_SV_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UC_AN", (Opcode) CMPP_W_SV_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UC_AN, "CMPP_W_SV_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_UC_AC", (Opcode) CMPP_W_SV_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_UC_AC, "CMPP_W_SV_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_SV_CN_UN", (Opcode) CMPP_W_SV_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CN_UN, "CMPP_W_SV_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CN_UC", (Opcode) CMPP_W_SV_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CN_UC, "CMPP_W_SV_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CN_CN", (Opcode) CMPP_W_SV_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CN_CN, "CMPP_W_SV_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CN_CC", (Opcode) CMPP_W_SV_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CN_CC, "CMPP_W_SV_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CN_ON", (Opcode) CMPP_W_SV_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CN_ON, "CMPP_W_SV_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CN_OC", (Opcode) CMPP_W_SV_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CN_OC, "CMPP_W_SV_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CN_AN", (Opcode) CMPP_W_SV_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CN_AN, "CMPP_W_SV_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CN_AC", (Opcode) CMPP_W_SV_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CN_AC, "CMPP_W_SV_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_SV_CC_UN", (Opcode) CMPP_W_SV_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CC_UN, "CMPP_W_SV_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CC_UC", (Opcode) CMPP_W_SV_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CC_UC, "CMPP_W_SV_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CC_CN", (Opcode) CMPP_W_SV_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CC_CN, "CMPP_W_SV_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CC_CC", (Opcode) CMPP_W_SV_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CC_CC, "CMPP_W_SV_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CC_ON", (Opcode) CMPP_W_SV_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CC_ON, "CMPP_W_SV_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CC_OC", (Opcode) CMPP_W_SV_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CC_OC, "CMPP_W_SV_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CC_AN", (Opcode) CMPP_W_SV_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CC_AN, "CMPP_W_SV_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_CC_AC", (Opcode) CMPP_W_SV_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_CC_AC, "CMPP_W_SV_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_SV_ON_UN", (Opcode) CMPP_W_SV_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_ON_UN, "CMPP_W_SV_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_ON_UC", (Opcode) CMPP_W_SV_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_ON_UC, "CMPP_W_SV_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_ON_CN", (Opcode) CMPP_W_SV_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_ON_CN, "CMPP_W_SV_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_ON_CC", (Opcode) CMPP_W_SV_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_ON_CC, "CMPP_W_SV_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_ON_ON", (Opcode) CMPP_W_SV_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_ON_ON, "CMPP_W_SV_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_ON_OC", (Opcode) CMPP_W_SV_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_ON_OC, "CMPP_W_SV_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_ON_AN", (Opcode) CMPP_W_SV_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_ON_AN, "CMPP_W_SV_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_ON_AC", (Opcode) CMPP_W_SV_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_ON_AC, "CMPP_W_SV_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_SV_OC_UN", (Opcode) CMPP_W_SV_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_OC_UN, "CMPP_W_SV_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_OC_UC", (Opcode) CMPP_W_SV_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_OC_UC, "CMPP_W_SV_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_W_SV_OC_CN", (Opcode) CMPP_W_SV_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_OC_CN, "CMPP_W_SV_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_OC_CC", (Opcode) CMPP_W_SV_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_OC_CC, "CMPP_W_SV_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_OC_ON", (Opcode) CMPP_W_SV_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_OC_ON, "CMPP_W_SV_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_OC_OC", (Opcode) CMPP_W_SV_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_OC_OC, "CMPP_W_SV_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_OC_AN", (Opcode) CMPP_W_SV_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_OC_AN, "CMPP_W_SV_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_OC_AC", (Opcode) CMPP_W_SV_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_OC_AC, "CMPP_W_SV_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_SV_AN_UN", (Opcode) CMPP_W_SV_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AN_UN, "CMPP_W_SV_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AN_UC", (Opcode) CMPP_W_SV_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AN_UC, "CMPP_W_SV_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AN_CN", (Opcode) CMPP_W_SV_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AN_CN, "CMPP_W_SV_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AN_CC", (Opcode) CMPP_W_SV_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AN_CC, "CMPP_W_SV_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AN_ON", (Opcode) CMPP_W_SV_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AN_ON, "CMPP_W_SV_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AN_OC", (Opcode) CMPP_W_SV_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AN_OC, "CMPP_W_SV_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AN_AN", (Opcode) CMPP_W_SV_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AN_AN, "CMPP_W_SV_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AN_AC", (Opcode) CMPP_W_SV_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AN_AC, "CMPP_W_SV_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_SV_AC_UN", (Opcode) CMPP_W_SV_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AC_UN, "CMPP_W_SV_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AC_UC", (Opcode) CMPP_W_SV_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AC_UC, "CMPP_W_SV_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AC_CN", (Opcode) CMPP_W_SV_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AC_CN, "CMPP_W_SV_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AC_CC", (Opcode) CMPP_W_SV_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AC_CC, "CMPP_W_SV_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AC_ON", (Opcode) CMPP_W_SV_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AC_ON, "CMPP_W_SV_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AC_OC", (Opcode) CMPP_W_SV_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AC_OC, "CMPP_W_SV_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AC_AN", (Opcode) CMPP_W_SV_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AC_AN, "CMPP_W_SV_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_SV_AC_AC", (Opcode) CMPP_W_SV_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_SV_AC_AC, "CMPP_W_SV_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp1_8()
{
   el_string_to_opcode_map.bind("CMPP_W_OD_UN_UN", (Opcode) CMPP_W_OD_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UN_UN, "CMPP_W_OD_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UN_UC", (Opcode) CMPP_W_OD_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UN_UC, "CMPP_W_OD_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UN_CN", (Opcode) CMPP_W_OD_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UN_CN, "CMPP_W_OD_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UN_CC", (Opcode) CMPP_W_OD_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UN_CC, "CMPP_W_OD_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UN_ON", (Opcode) CMPP_W_OD_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UN_ON, "CMPP_W_OD_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UN_OC", (Opcode) CMPP_W_OD_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UN_OC, "CMPP_W_OD_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UN_AN", (Opcode) CMPP_W_OD_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UN_AN, "CMPP_W_OD_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UN_AC", (Opcode) CMPP_W_OD_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UN_AC, "CMPP_W_OD_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_OD_UC_UN", (Opcode) CMPP_W_OD_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UC_UN, "CMPP_W_OD_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UC_UC", (Opcode) CMPP_W_OD_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UC_UC, "CMPP_W_OD_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UC_CN", (Opcode) CMPP_W_OD_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UC_CN, "CMPP_W_OD_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UC_CC", (Opcode) CMPP_W_OD_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UC_CC, "CMPP_W_OD_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UC_ON", (Opcode) CMPP_W_OD_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UC_ON, "CMPP_W_OD_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UC_OC", (Opcode) CMPP_W_OD_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UC_OC, "CMPP_W_OD_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UC_AN", (Opcode) CMPP_W_OD_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UC_AN, "CMPP_W_OD_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_UC_AC", (Opcode) CMPP_W_OD_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_UC_AC, "CMPP_W_OD_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_OD_CN_UN", (Opcode) CMPP_W_OD_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CN_UN, "CMPP_W_OD_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CN_UC", (Opcode) CMPP_W_OD_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CN_UC, "CMPP_W_OD_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CN_CN", (Opcode) CMPP_W_OD_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CN_CN, "CMPP_W_OD_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CN_CC", (Opcode) CMPP_W_OD_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CN_CC, "CMPP_W_OD_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CN_ON", (Opcode) CMPP_W_OD_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CN_ON, "CMPP_W_OD_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CN_OC", (Opcode) CMPP_W_OD_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CN_OC, "CMPP_W_OD_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CN_AN", (Opcode) CMPP_W_OD_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CN_AN, "CMPP_W_OD_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CN_AC", (Opcode) CMPP_W_OD_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CN_AC, "CMPP_W_OD_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_OD_CC_UN", (Opcode) CMPP_W_OD_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CC_UN, "CMPP_W_OD_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CC_UC", (Opcode) CMPP_W_OD_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CC_UC, "CMPP_W_OD_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CC_CN", (Opcode) CMPP_W_OD_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CC_CN, "CMPP_W_OD_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CC_CC", (Opcode) CMPP_W_OD_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CC_CC, "CMPP_W_OD_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CC_ON", (Opcode) CMPP_W_OD_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CC_ON, "CMPP_W_OD_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CC_OC", (Opcode) CMPP_W_OD_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CC_OC, "CMPP_W_OD_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CC_AN", (Opcode) CMPP_W_OD_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CC_AN, "CMPP_W_OD_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_CC_AC", (Opcode) CMPP_W_OD_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_CC_AC, "CMPP_W_OD_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_OD_ON_UN", (Opcode) CMPP_W_OD_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_ON_UN, "CMPP_W_OD_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_ON_UC", (Opcode) CMPP_W_OD_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_ON_UC, "CMPP_W_OD_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_ON_CN", (Opcode) CMPP_W_OD_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_ON_CN, "CMPP_W_OD_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_ON_CC", (Opcode) CMPP_W_OD_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_ON_CC, "CMPP_W_OD_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_ON_ON", (Opcode) CMPP_W_OD_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_ON_ON, "CMPP_W_OD_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_ON_OC", (Opcode) CMPP_W_OD_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_ON_OC, "CMPP_W_OD_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_ON_AN", (Opcode) CMPP_W_OD_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_ON_AN, "CMPP_W_OD_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_ON_AC", (Opcode) CMPP_W_OD_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_ON_AC, "CMPP_W_OD_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_OD_OC_UN", (Opcode) CMPP_W_OD_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_OC_UN, "CMPP_W_OD_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_OC_UC", (Opcode) CMPP_W_OD_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_OC_UC, "CMPP_W_OD_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_OC_CN", (Opcode) CMPP_W_OD_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_OC_CN, "CMPP_W_OD_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_OC_CC", (Opcode) CMPP_W_OD_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_OC_CC, "CMPP_W_OD_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_OC_ON", (Opcode) CMPP_W_OD_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_OC_ON, "CMPP_W_OD_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_OC_OC", (Opcode) CMPP_W_OD_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_OC_OC, "CMPP_W_OD_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_OC_AN", (Opcode) CMPP_W_OD_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_OC_AN, "CMPP_W_OD_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_OC_AC", (Opcode) CMPP_W_OD_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_OC_AC, "CMPP_W_OD_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_OD_AN_UN", (Opcode) CMPP_W_OD_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AN_UN, "CMPP_W_OD_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AN_UC", (Opcode) CMPP_W_OD_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AN_UC, "CMPP_W_OD_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AN_CN", (Opcode) CMPP_W_OD_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AN_CN, "CMPP_W_OD_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AN_CC", (Opcode) CMPP_W_OD_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AN_CC, "CMPP_W_OD_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AN_ON", (Opcode) CMPP_W_OD_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AN_ON, "CMPP_W_OD_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AN_OC", (Opcode) CMPP_W_OD_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AN_OC, "CMPP_W_OD_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AN_AN", (Opcode) CMPP_W_OD_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AN_AN, "CMPP_W_OD_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AN_AC", (Opcode) CMPP_W_OD_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AN_AC, "CMPP_W_OD_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_OD_AC_UN", (Opcode) CMPP_W_OD_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AC_UN, "CMPP_W_OD_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AC_UC", (Opcode) CMPP_W_OD_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AC_UC, "CMPP_W_OD_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AC_CN", (Opcode) CMPP_W_OD_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AC_CN, "CMPP_W_OD_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AC_CC", (Opcode) CMPP_W_OD_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AC_CC, "CMPP_W_OD_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AC_ON", (Opcode) CMPP_W_OD_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AC_ON, "CMPP_W_OD_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AC_OC", (Opcode) CMPP_W_OD_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AC_OC, "CMPP_W_OD_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AC_AN", (Opcode) CMPP_W_OD_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AC_AN, "CMPP_W_OD_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_OD_AC_AC", (Opcode) CMPP_W_OD_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_OD_AC_AC, "CMPP_W_OD_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp1()
{
   el_init_elcor_opcode_maps_cmpp1_1() ;
   el_init_elcor_opcode_maps_cmpp1_2() ;
   el_init_elcor_opcode_maps_cmpp1_3() ;
   el_init_elcor_opcode_maps_cmpp1_4() ;
   el_init_elcor_opcode_maps_cmpp1_5() ;
   el_init_elcor_opcode_maps_cmpp1_6() ;
   el_init_elcor_opcode_maps_cmpp1_7() ;
   el_init_elcor_opcode_maps_cmpp1_8() ;
}

static void el_init_elcor_opcode_maps_cmpp2_1()
{
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UN_UN", (Opcode) CMPP_W_TRUE_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UN_UN, "CMPP_W_TRUE_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UN_UC", (Opcode) CMPP_W_TRUE_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UN_UC, "CMPP_W_TRUE_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UN_CN", (Opcode) CMPP_W_TRUE_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UN_CN, "CMPP_W_TRUE_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UN_CC", (Opcode) CMPP_W_TRUE_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UN_CC, "CMPP_W_TRUE_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UN_ON", (Opcode) CMPP_W_TRUE_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UN_ON, "CMPP_W_TRUE_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UN_OC", (Opcode) CMPP_W_TRUE_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UN_OC, "CMPP_W_TRUE_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UN_AN", (Opcode) CMPP_W_TRUE_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UN_AN, "CMPP_W_TRUE_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UN_AC", (Opcode) CMPP_W_TRUE_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UN_AC, "CMPP_W_TRUE_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_TRUE_UC_UN", (Opcode) CMPP_W_TRUE_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UC_UN, "CMPP_W_TRUE_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UC_UC", (Opcode) CMPP_W_TRUE_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UC_UC, "CMPP_W_TRUE_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UC_CN", (Opcode) CMPP_W_TRUE_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UC_CN, "CMPP_W_TRUE_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UC_CC", (Opcode) CMPP_W_TRUE_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UC_CC, "CMPP_W_TRUE_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UC_ON", (Opcode) CMPP_W_TRUE_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UC_ON, "CMPP_W_TRUE_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UC_OC", (Opcode) CMPP_W_TRUE_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UC_OC, "CMPP_W_TRUE_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UC_AN", (Opcode) CMPP_W_TRUE_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UC_AN, "CMPP_W_TRUE_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_UC_AC", (Opcode) CMPP_W_TRUE_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_UC_AC, "CMPP_W_TRUE_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_TRUE_CN_UN", (Opcode) CMPP_W_TRUE_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CN_UN, "CMPP_W_TRUE_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CN_UC", (Opcode) CMPP_W_TRUE_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CN_UC, "CMPP_W_TRUE_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CN_CN", (Opcode) CMPP_W_TRUE_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CN_CN, "CMPP_W_TRUE_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CN_CC", (Opcode) CMPP_W_TRUE_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CN_CC, "CMPP_W_TRUE_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CN_ON", (Opcode) CMPP_W_TRUE_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CN_ON, "CMPP_W_TRUE_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CN_OC", (Opcode) CMPP_W_TRUE_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CN_OC, "CMPP_W_TRUE_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CN_AN", (Opcode) CMPP_W_TRUE_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CN_AN, "CMPP_W_TRUE_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CN_AC", (Opcode) CMPP_W_TRUE_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CN_AC, "CMPP_W_TRUE_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_TRUE_CC_UN", (Opcode) CMPP_W_TRUE_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CC_UN, "CMPP_W_TRUE_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CC_UC", (Opcode) CMPP_W_TRUE_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CC_UC, "CMPP_W_TRUE_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CC_CN", (Opcode) CMPP_W_TRUE_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CC_CN, "CMPP_W_TRUE_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CC_CC", (Opcode) CMPP_W_TRUE_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CC_CC, "CMPP_W_TRUE_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CC_ON", (Opcode) CMPP_W_TRUE_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CC_ON, "CMPP_W_TRUE_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CC_OC", (Opcode) CMPP_W_TRUE_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CC_OC, "CMPP_W_TRUE_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CC_AN", (Opcode) CMPP_W_TRUE_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CC_AN, "CMPP_W_TRUE_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_CC_AC", (Opcode) CMPP_W_TRUE_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_CC_AC, "CMPP_W_TRUE_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_TRUE_ON_UN", (Opcode) CMPP_W_TRUE_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_ON_UN, "CMPP_W_TRUE_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_ON_UC", (Opcode) CMPP_W_TRUE_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_ON_UC, "CMPP_W_TRUE_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_ON_CN", (Opcode) CMPP_W_TRUE_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_ON_CN, "CMPP_W_TRUE_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_ON_CC", (Opcode) CMPP_W_TRUE_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_ON_CC, "CMPP_W_TRUE_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_ON_ON", (Opcode) CMPP_W_TRUE_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_ON_ON, "CMPP_W_TRUE_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_ON_OC", (Opcode) CMPP_W_TRUE_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_ON_OC, "CMPP_W_TRUE_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_ON_AN", (Opcode) CMPP_W_TRUE_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_ON_AN, "CMPP_W_TRUE_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_ON_AC", (Opcode) CMPP_W_TRUE_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_ON_AC, "CMPP_W_TRUE_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_TRUE_OC_UN", (Opcode) CMPP_W_TRUE_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_OC_UN, "CMPP_W_TRUE_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_OC_UC", (Opcode) CMPP_W_TRUE_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_OC_UC, "CMPP_W_TRUE_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_OC_CN", (Opcode) CMPP_W_TRUE_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_OC_CN, "CMPP_W_TRUE_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_OC_CC", (Opcode) CMPP_W_TRUE_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_OC_CC, "CMPP_W_TRUE_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_OC_ON", (Opcode) CMPP_W_TRUE_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_OC_ON, "CMPP_W_TRUE_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_OC_OC", (Opcode) CMPP_W_TRUE_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_OC_OC, "CMPP_W_TRUE_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_OC_AN", (Opcode) CMPP_W_TRUE_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_OC_AN, "CMPP_W_TRUE_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_OC_AC", (Opcode) CMPP_W_TRUE_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_OC_AC, "CMPP_W_TRUE_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_TRUE_AN_UN", (Opcode) CMPP_W_TRUE_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AN_UN, "CMPP_W_TRUE_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AN_UC", (Opcode) CMPP_W_TRUE_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AN_UC, "CMPP_W_TRUE_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AN_CN", (Opcode) CMPP_W_TRUE_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AN_CN, "CMPP_W_TRUE_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AN_CC", (Opcode) CMPP_W_TRUE_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AN_CC, "CMPP_W_TRUE_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AN_ON", (Opcode) CMPP_W_TRUE_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AN_ON, "CMPP_W_TRUE_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AN_OC", (Opcode) CMPP_W_TRUE_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AN_OC, "CMPP_W_TRUE_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AN_AN", (Opcode) CMPP_W_TRUE_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AN_AN, "CMPP_W_TRUE_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AN_AC", (Opcode) CMPP_W_TRUE_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AN_AC, "CMPP_W_TRUE_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_TRUE_AC_UN", (Opcode) CMPP_W_TRUE_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AC_UN, "CMPP_W_TRUE_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AC_UC", (Opcode) CMPP_W_TRUE_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AC_UC, "CMPP_W_TRUE_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AC_CN", (Opcode) CMPP_W_TRUE_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AC_CN, "CMPP_W_TRUE_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AC_CC", (Opcode) CMPP_W_TRUE_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AC_CC, "CMPP_W_TRUE_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AC_ON", (Opcode) CMPP_W_TRUE_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AC_ON, "CMPP_W_TRUE_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AC_OC", (Opcode) CMPP_W_TRUE_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AC_OC, "CMPP_W_TRUE_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AC_AN", (Opcode) CMPP_W_TRUE_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AC_AN, "CMPP_W_TRUE_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_TRUE_AC_AC", (Opcode) CMPP_W_TRUE_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_TRUE_AC_AC, "CMPP_W_TRUE_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp2_2()
{
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UN_UN", (Opcode) CMPP_W_NEQ_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UN_UN, "CMPP_W_NEQ_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UN_UC", (Opcode) CMPP_W_NEQ_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UN_UC, "CMPP_W_NEQ_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UN_CN", (Opcode) CMPP_W_NEQ_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UN_CN, "CMPP_W_NEQ_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UN_CC", (Opcode) CMPP_W_NEQ_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UN_CC, "CMPP_W_NEQ_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UN_ON", (Opcode) CMPP_W_NEQ_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UN_ON, "CMPP_W_NEQ_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UN_OC", (Opcode) CMPP_W_NEQ_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UN_OC, "CMPP_W_NEQ_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UN_AN", (Opcode) CMPP_W_NEQ_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UN_AN, "CMPP_W_NEQ_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UN_AC", (Opcode) CMPP_W_NEQ_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UN_AC, "CMPP_W_NEQ_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_NEQ_UC_UN", (Opcode) CMPP_W_NEQ_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UC_UN, "CMPP_W_NEQ_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UC_UC", (Opcode) CMPP_W_NEQ_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UC_UC, "CMPP_W_NEQ_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UC_CN", (Opcode) CMPP_W_NEQ_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UC_CN, "CMPP_W_NEQ_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UC_CC", (Opcode) CMPP_W_NEQ_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UC_CC, "CMPP_W_NEQ_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UC_ON", (Opcode) CMPP_W_NEQ_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UC_ON, "CMPP_W_NEQ_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UC_OC", (Opcode) CMPP_W_NEQ_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UC_OC, "CMPP_W_NEQ_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UC_AN", (Opcode) CMPP_W_NEQ_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UC_AN, "CMPP_W_NEQ_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_UC_AC", (Opcode) CMPP_W_NEQ_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_UC_AC, "CMPP_W_NEQ_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_NEQ_CN_UN", (Opcode) CMPP_W_NEQ_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CN_UN, "CMPP_W_NEQ_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CN_UC", (Opcode) CMPP_W_NEQ_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CN_UC, "CMPP_W_NEQ_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CN_CN", (Opcode) CMPP_W_NEQ_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CN_CN, "CMPP_W_NEQ_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CN_CC", (Opcode) CMPP_W_NEQ_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CN_CC, "CMPP_W_NEQ_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CN_ON", (Opcode) CMPP_W_NEQ_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CN_ON, "CMPP_W_NEQ_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CN_OC", (Opcode) CMPP_W_NEQ_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CN_OC, "CMPP_W_NEQ_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CN_AN", (Opcode) CMPP_W_NEQ_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CN_AN, "CMPP_W_NEQ_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CN_AC", (Opcode) CMPP_W_NEQ_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CN_AC, "CMPP_W_NEQ_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_NEQ_CC_UN", (Opcode) CMPP_W_NEQ_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CC_UN, "CMPP_W_NEQ_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CC_UC", (Opcode) CMPP_W_NEQ_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CC_UC, "CMPP_W_NEQ_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CC_CN", (Opcode) CMPP_W_NEQ_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CC_CN, "CMPP_W_NEQ_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CC_CC", (Opcode) CMPP_W_NEQ_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CC_CC, "CMPP_W_NEQ_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CC_ON", (Opcode) CMPP_W_NEQ_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CC_ON, "CMPP_W_NEQ_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CC_OC", (Opcode) CMPP_W_NEQ_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CC_OC, "CMPP_W_NEQ_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CC_AN", (Opcode) CMPP_W_NEQ_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CC_AN, "CMPP_W_NEQ_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_CC_AC", (Opcode) CMPP_W_NEQ_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_CC_AC, "CMPP_W_NEQ_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_NEQ_ON_UN", (Opcode) CMPP_W_NEQ_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_ON_UN, "CMPP_W_NEQ_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_ON_UC", (Opcode) CMPP_W_NEQ_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_ON_UC, "CMPP_W_NEQ_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_ON_CN", (Opcode) CMPP_W_NEQ_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_ON_CN, "CMPP_W_NEQ_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_ON_CC", (Opcode) CMPP_W_NEQ_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_ON_CC, "CMPP_W_NEQ_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_ON_ON", (Opcode) CMPP_W_NEQ_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_ON_ON, "CMPP_W_NEQ_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_ON_OC", (Opcode) CMPP_W_NEQ_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_ON_OC, "CMPP_W_NEQ_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_ON_AN", (Opcode) CMPP_W_NEQ_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_ON_AN, "CMPP_W_NEQ_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_ON_AC", (Opcode) CMPP_W_NEQ_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_ON_AC, "CMPP_W_NEQ_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_NEQ_OC_UN", (Opcode) CMPP_W_NEQ_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_OC_UN, "CMPP_W_NEQ_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_OC_UC", (Opcode) CMPP_W_NEQ_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_OC_UC, "CMPP_W_NEQ_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_OC_CN", (Opcode) CMPP_W_NEQ_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_OC_CN, "CMPP_W_NEQ_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_OC_CC", (Opcode) CMPP_W_NEQ_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_OC_CC, "CMPP_W_NEQ_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_OC_ON", (Opcode) CMPP_W_NEQ_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_OC_ON, "CMPP_W_NEQ_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_OC_OC", (Opcode) CMPP_W_NEQ_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_OC_OC, "CMPP_W_NEQ_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_OC_AN", (Opcode) CMPP_W_NEQ_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_OC_AN, "CMPP_W_NEQ_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_OC_AC", (Opcode) CMPP_W_NEQ_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_OC_AC, "CMPP_W_NEQ_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_NEQ_AN_UN", (Opcode) CMPP_W_NEQ_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AN_UN, "CMPP_W_NEQ_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AN_UC", (Opcode) CMPP_W_NEQ_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AN_UC, "CMPP_W_NEQ_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AN_CN", (Opcode) CMPP_W_NEQ_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AN_CN, "CMPP_W_NEQ_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AN_CC", (Opcode) CMPP_W_NEQ_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AN_CC, "CMPP_W_NEQ_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AN_ON", (Opcode) CMPP_W_NEQ_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AN_ON, "CMPP_W_NEQ_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AN_OC", (Opcode) CMPP_W_NEQ_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AN_OC, "CMPP_W_NEQ_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AN_AN", (Opcode) CMPP_W_NEQ_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AN_AN, "CMPP_W_NEQ_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AN_AC", (Opcode) CMPP_W_NEQ_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AN_AC, "CMPP_W_NEQ_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_NEQ_AC_UN", (Opcode) CMPP_W_NEQ_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AC_UN, "CMPP_W_NEQ_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AC_UC", (Opcode) CMPP_W_NEQ_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AC_UC, "CMPP_W_NEQ_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AC_CN", (Opcode) CMPP_W_NEQ_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AC_CN, "CMPP_W_NEQ_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AC_CC", (Opcode) CMPP_W_NEQ_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AC_CC, "CMPP_W_NEQ_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AC_ON", (Opcode) CMPP_W_NEQ_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AC_ON, "CMPP_W_NEQ_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AC_OC", (Opcode) CMPP_W_NEQ_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AC_OC, "CMPP_W_NEQ_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AC_AN", (Opcode) CMPP_W_NEQ_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AC_AN, "CMPP_W_NEQ_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_NEQ_AC_AC", (Opcode) CMPP_W_NEQ_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_NEQ_AC_AC, "CMPP_W_NEQ_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp2_3()
{
   el_string_to_opcode_map.bind("CMPP_W_LLT_UN_UN", (Opcode) CMPP_W_LLT_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UN_UN, "CMPP_W_LLT_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UN_UC", (Opcode) CMPP_W_LLT_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UN_UC, "CMPP_W_LLT_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UN_CN", (Opcode) CMPP_W_LLT_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UN_CN, "CMPP_W_LLT_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UN_CC", (Opcode) CMPP_W_LLT_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UN_CC, "CMPP_W_LLT_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UN_ON", (Opcode) CMPP_W_LLT_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UN_ON, "CMPP_W_LLT_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UN_OC", (Opcode) CMPP_W_LLT_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UN_OC, "CMPP_W_LLT_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UN_AN", (Opcode) CMPP_W_LLT_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UN_AN, "CMPP_W_LLT_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UN_AC", (Opcode) CMPP_W_LLT_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UN_AC, "CMPP_W_LLT_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLT_UC_UN", (Opcode) CMPP_W_LLT_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UC_UN, "CMPP_W_LLT_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UC_UC", (Opcode) CMPP_W_LLT_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UC_UC, "CMPP_W_LLT_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UC_CN", (Opcode) CMPP_W_LLT_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UC_CN, "CMPP_W_LLT_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UC_CC", (Opcode) CMPP_W_LLT_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UC_CC, "CMPP_W_LLT_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UC_ON", (Opcode) CMPP_W_LLT_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UC_ON, "CMPP_W_LLT_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UC_OC", (Opcode) CMPP_W_LLT_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UC_OC, "CMPP_W_LLT_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UC_AN", (Opcode) CMPP_W_LLT_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UC_AN, "CMPP_W_LLT_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_UC_AC", (Opcode) CMPP_W_LLT_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_UC_AC, "CMPP_W_LLT_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLT_CN_UN", (Opcode) CMPP_W_LLT_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CN_UN, "CMPP_W_LLT_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CN_UC", (Opcode) CMPP_W_LLT_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CN_UC, "CMPP_W_LLT_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CN_CN", (Opcode) CMPP_W_LLT_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CN_CN, "CMPP_W_LLT_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CN_CC", (Opcode) CMPP_W_LLT_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CN_CC, "CMPP_W_LLT_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CN_ON", (Opcode) CMPP_W_LLT_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CN_ON, "CMPP_W_LLT_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CN_OC", (Opcode) CMPP_W_LLT_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CN_OC, "CMPP_W_LLT_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CN_AN", (Opcode) CMPP_W_LLT_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CN_AN, "CMPP_W_LLT_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CN_AC", (Opcode) CMPP_W_LLT_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CN_AC, "CMPP_W_LLT_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLT_CC_UN", (Opcode) CMPP_W_LLT_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CC_UN, "CMPP_W_LLT_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CC_UC", (Opcode) CMPP_W_LLT_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CC_UC, "CMPP_W_LLT_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CC_CN", (Opcode) CMPP_W_LLT_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CC_CN, "CMPP_W_LLT_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CC_CC", (Opcode) CMPP_W_LLT_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CC_CC, "CMPP_W_LLT_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CC_ON", (Opcode) CMPP_W_LLT_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CC_ON, "CMPP_W_LLT_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CC_OC", (Opcode) CMPP_W_LLT_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CC_OC, "CMPP_W_LLT_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CC_AN", (Opcode) CMPP_W_LLT_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CC_AN, "CMPP_W_LLT_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_CC_AC", (Opcode) CMPP_W_LLT_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_CC_AC, "CMPP_W_LLT_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLT_ON_UN", (Opcode) CMPP_W_LLT_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_ON_UN, "CMPP_W_LLT_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_ON_UC", (Opcode) CMPP_W_LLT_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_ON_UC, "CMPP_W_LLT_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_ON_CN", (Opcode) CMPP_W_LLT_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_ON_CN, "CMPP_W_LLT_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_ON_CC", (Opcode) CMPP_W_LLT_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_ON_CC, "CMPP_W_LLT_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_ON_ON", (Opcode) CMPP_W_LLT_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_ON_ON, "CMPP_W_LLT_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_ON_OC", (Opcode) CMPP_W_LLT_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_ON_OC, "CMPP_W_LLT_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_ON_AN", (Opcode) CMPP_W_LLT_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_ON_AN, "CMPP_W_LLT_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_ON_AC", (Opcode) CMPP_W_LLT_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_ON_AC, "CMPP_W_LLT_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLT_OC_UN", (Opcode) CMPP_W_LLT_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_OC_UN, "CMPP_W_LLT_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_OC_UC", (Opcode) CMPP_W_LLT_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_OC_UC, "CMPP_W_LLT_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_OC_CN", (Opcode) CMPP_W_LLT_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_OC_CN, "CMPP_W_LLT_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_OC_CC", (Opcode) CMPP_W_LLT_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_OC_CC, "CMPP_W_LLT_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_OC_ON", (Opcode) CMPP_W_LLT_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_OC_ON, "CMPP_W_LLT_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_OC_OC", (Opcode) CMPP_W_LLT_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_OC_OC, "CMPP_W_LLT_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_OC_AN", (Opcode) CMPP_W_LLT_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_OC_AN, "CMPP_W_LLT_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_OC_AC", (Opcode) CMPP_W_LLT_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_OC_AC, "CMPP_W_LLT_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLT_AN_UN", (Opcode) CMPP_W_LLT_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AN_UN, "CMPP_W_LLT_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AN_UC", (Opcode) CMPP_W_LLT_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AN_UC, "CMPP_W_LLT_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AN_CN", (Opcode) CMPP_W_LLT_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AN_CN, "CMPP_W_LLT_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AN_CC", (Opcode) CMPP_W_LLT_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AN_CC, "CMPP_W_LLT_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AN_ON", (Opcode) CMPP_W_LLT_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AN_ON, "CMPP_W_LLT_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AN_OC", (Opcode) CMPP_W_LLT_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AN_OC, "CMPP_W_LLT_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AN_AN", (Opcode) CMPP_W_LLT_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AN_AN, "CMPP_W_LLT_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AN_AC", (Opcode) CMPP_W_LLT_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AN_AC, "CMPP_W_LLT_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLT_AC_UN", (Opcode) CMPP_W_LLT_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AC_UN, "CMPP_W_LLT_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AC_UC", (Opcode) CMPP_W_LLT_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AC_UC, "CMPP_W_LLT_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AC_CN", (Opcode) CMPP_W_LLT_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AC_CN, "CMPP_W_LLT_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AC_CC", (Opcode) CMPP_W_LLT_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AC_CC, "CMPP_W_LLT_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AC_ON", (Opcode) CMPP_W_LLT_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AC_ON, "CMPP_W_LLT_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AC_OC", (Opcode) CMPP_W_LLT_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AC_OC, "CMPP_W_LLT_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AC_AN", (Opcode) CMPP_W_LLT_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AC_AN, "CMPP_W_LLT_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLT_AC_AC", (Opcode) CMPP_W_LLT_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLT_AC_AC, "CMPP_W_LLT_AC_AC") ;
}

static void el_init_elcor_opcode_maps_cmpp2_4()
{
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UN_UN", (Opcode) CMPP_W_LLEQ_UN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UN_UN, "CMPP_W_LLEQ_UN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UN_UC", (Opcode) CMPP_W_LLEQ_UN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UN_UC, "CMPP_W_LLEQ_UN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UN_CN", (Opcode) CMPP_W_LLEQ_UN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UN_CN, "CMPP_W_LLEQ_UN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UN_CC", (Opcode) CMPP_W_LLEQ_UN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UN_CC, "CMPP_W_LLEQ_UN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UN_ON", (Opcode) CMPP_W_LLEQ_UN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UN_ON, "CMPP_W_LLEQ_UN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UN_OC", (Opcode) CMPP_W_LLEQ_UN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UN_OC, "CMPP_W_LLEQ_UN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UN_AN", (Opcode) CMPP_W_LLEQ_UN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UN_AN, "CMPP_W_LLEQ_UN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UN_AC", (Opcode) CMPP_W_LLEQ_UN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UN_AC, "CMPP_W_LLEQ_UN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UC_UN", (Opcode) CMPP_W_LLEQ_UC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UC_UN, "CMPP_W_LLEQ_UC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UC_UC", (Opcode) CMPP_W_LLEQ_UC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UC_UC, "CMPP_W_LLEQ_UC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UC_CN", (Opcode) CMPP_W_LLEQ_UC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UC_CN, "CMPP_W_LLEQ_UC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UC_CC", (Opcode) CMPP_W_LLEQ_UC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UC_CC, "CMPP_W_LLEQ_UC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UC_ON", (Opcode) CMPP_W_LLEQ_UC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UC_ON, "CMPP_W_LLEQ_UC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UC_OC", (Opcode) CMPP_W_LLEQ_UC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UC_OC, "CMPP_W_LLEQ_UC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UC_AN", (Opcode) CMPP_W_LLEQ_UC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UC_AN, "CMPP_W_LLEQ_UC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_UC_AC", (Opcode) CMPP_W_LLEQ_UC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_UC_AC, "CMPP_W_LLEQ_UC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CN_UN", (Opcode) CMPP_W_LLEQ_CN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CN_UN, "CMPP_W_LLEQ_CN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CN_UC", (Opcode) CMPP_W_LLEQ_CN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CN_UC, "CMPP_W_LLEQ_CN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CN_CN", (Opcode) CMPP_W_LLEQ_CN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CN_CN, "CMPP_W_LLEQ_CN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CN_CC", (Opcode) CMPP_W_LLEQ_CN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CN_CC, "CMPP_W_LLEQ_CN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CN_ON", (Opcode) CMPP_W_LLEQ_CN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CN_ON, "CMPP_W_LLEQ_CN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CN_OC", (Opcode) CMPP_W_LLEQ_CN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CN_OC, "CMPP_W_LLEQ_CN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CN_AN", (Opcode) CMPP_W_LLEQ_CN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CN_AN, "CMPP_W_LLEQ_CN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CN_AC", (Opcode) CMPP_W_LLEQ_CN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CN_AC, "CMPP_W_LLEQ_CN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CC_UN", (Opcode) CMPP_W_LLEQ_CC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CC_UN, "CMPP_W_LLEQ_CC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CC_UC", (Opcode) CMPP_W_LLEQ_CC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CC_UC, "CMPP_W_LLEQ_CC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CC_CN", (Opcode) CMPP_W_LLEQ_CC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CC_CN, "CMPP_W_LLEQ_CC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CC_CC", (Opcode) CMPP_W_LLEQ_CC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CC_CC, "CMPP_W_LLEQ_CC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CC_ON", (Opcode) CMPP_W_LLEQ_CC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CC_ON, "CMPP_W_LLEQ_CC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CC_OC", (Opcode) CMPP_W_LLEQ_CC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CC_OC, "CMPP_W_LLEQ_CC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CC_AN", (Opcode) CMPP_W_LLEQ_CC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CC_AN, "CMPP_W_LLEQ_CC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_CC_AC", (Opcode) CMPP_W_LLEQ_CC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_CC_AC, "CMPP_W_LLEQ_CC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLEQ_ON_UN", (Opcode) CMPP_W_LLEQ_ON_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_ON_UN, "CMPP_W_LLEQ_ON_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_ON_UC", (Opcode) CMPP_W_LLEQ_ON_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_ON_UC, "CMPP_W_LLEQ_ON_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_ON_CN", (Opcode) CMPP_W_LLEQ_ON_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_ON_CN, "CMPP_W_LLEQ_ON_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_ON_CC", (Opcode) CMPP_W_LLEQ_ON_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_ON_CC, "CMPP_W_LLEQ_ON_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_ON_ON", (Opcode) CMPP_W_LLEQ_ON_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_ON_ON, "CMPP_W_LLEQ_ON_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_ON_OC", (Opcode) CMPP_W_LLEQ_ON_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_ON_OC, "CMPP_W_LLEQ_ON_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_ON_AN", (Opcode) CMPP_W_LLEQ_ON_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_ON_AN, "CMPP_W_LLEQ_ON_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_ON_AC", (Opcode) CMPP_W_LLEQ_ON_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_ON_AC, "CMPP_W_LLEQ_ON_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLEQ_OC_UN", (Opcode) CMPP_W_LLEQ_OC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_OC_UN, "CMPP_W_LLEQ_OC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_OC_UC", (Opcode) CMPP_W_LLEQ_OC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_OC_UC, "CMPP_W_LLEQ_OC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_OC_CN", (Opcode) CMPP_W_LLEQ_OC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_OC_CN, "CMPP_W_LLEQ_OC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_OC_CC", (Opcode) CMPP_W_LLEQ_OC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_OC_CC, "CMPP_W_LLEQ_OC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_OC_ON", (Opcode) CMPP_W_LLEQ_OC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_OC_ON, "CMPP_W_LLEQ_OC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_OC_OC", (Opcode) CMPP_W_LLEQ_OC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_OC_OC, "CMPP_W_LLEQ_OC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_OC_AN", (Opcode) CMPP_W_LLEQ_OC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_OC_AN, "CMPP_W_LLEQ_OC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_OC_AC", (Opcode) CMPP_W_LLEQ_OC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_OC_AC, "CMPP_W_LLEQ_OC_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AN_UN", (Opcode) CMPP_W_LLEQ_AN_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AN_UN, "CMPP_W_LLEQ_AN_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AN_UC", (Opcode) CMPP_W_LLEQ_AN_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AN_UC, "CMPP_W_LLEQ_AN_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AN_CN", (Opcode) CMPP_W_LLEQ_AN_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AN_CN, "CMPP_W_LLEQ_AN_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AN_CC", (Opcode) CMPP_W_LLEQ_AN_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AN_CC, "CMPP_W_LLEQ_AN_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AN_ON", (Opcode) CMPP_W_LLEQ_AN_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AN_ON, "CMPP_W_LLEQ_AN_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AN_OC", (Opcode) CMPP_W_LLEQ_AN_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AN_OC, "CMPP_W_LLEQ_AN_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AN_AN", (Opcode) CMPP_W_LLEQ_AN_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AN_AN, "CMPP_W_LLEQ_AN_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AN_AC", (Opcode) CMPP_W_LLEQ_AN_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AN_AC, "CMPP_W_LLEQ_AN_AC") ;

   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AC_UN", (Opcode) CMPP_W_LLEQ_AC_UN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AC_UN, "CMPP_W_LLEQ_AC_UN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AC_UC", (Opcode) CMPP_W_LLEQ_AC_UC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AC_UC, "CMPP_W_LLEQ_AC_UC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AC_CN", (Opcode) CMPP_W_LLEQ_AC_CN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AC_CN, "CMPP_W_LLEQ_AC_CN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AC_CC", (Opcode) CMPP_W_LLEQ_AC_CC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AC_CC, "CMPP_W_LLEQ_AC_CC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AC_ON", (Opcode) CMPP_W_LLEQ_AC_ON) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AC_ON, "CMPP_W_LLEQ_AC_ON") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AC_OC", (Opcode) CMPP_W_LLEQ_AC_OC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AC_OC, "CMPP_W_LLEQ_AC_OC") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AC_AN", (Opcode) CMPP_W_LLEQ_AC_AN) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AC_AN, "CMPP_W_LLEQ_AC_AN") ;
   el_string_to_opcode_map.bind("CMPP_W_LLEQ_AC_AC", (Opcode) CMPP_W_LLEQ_AC_AC) ;
   el_opcode_to_string_map.bind((Opcode) CMPP_W_LLEQ_AC_AC, "CMPP_W_LLEQ_AC_AC") ;
}

extern void    el_init_elcor_opcode_maps_cmpp2_5() ;
extern void    el_init_elcor_opcode_maps_cmpp2_6() ;
extern void    el_init_elcor_opcode_maps_cmpp2_7() ;
extern void    el_init_elcor_opcode_maps_cmpp2_8() ;

static void el_init_elcor_opcode_maps_cmpp2()
{
   el_init_elcor_opcode_maps_cmpp2_1() ;
   el_init_elcor_opcode_maps_cmpp2_2() ;
   el_init_elcor_opcode_maps_cmpp2_3() ;
   el_init_elcor_opcode_maps_cmpp2_4() ;
   el_init_elcor_opcode_maps_cmpp2_5() ;
   el_init_elcor_opcode_maps_cmpp2_6() ;
   el_init_elcor_opcode_maps_cmpp2_7() ;
   el_init_elcor_opcode_maps_cmpp2_8() ;
}

extern void el_init_elcor_opcode_maps_fcmpp1();
extern void el_init_elcor_opcode_maps_fcmpp2();
extern void el_init_elcor_opcode_maps_memory();
extern void el_init_elcor_opcode_maps_misc();
extern void el_init_elcor_opcode_maps_lm();
extern void el_init_elcor_base_opcode_maps();

void el_init_elcor_opcode_maps()
{
    el_init_elcor_opcode_maps_arithmetic();
    el_init_elcor_opcode_maps_cmpp1();
    el_init_elcor_opcode_maps_cmpp2();
    el_init_elcor_opcode_maps_fcmpp1();
    el_init_elcor_opcode_maps_fcmpp2();
    el_init_elcor_opcode_maps_memory();
    el_init_elcor_opcode_maps_misc();
    el_init_elcor_opcode_maps_lm();

    el_init_elcor_base_opcode_maps();
}

//////////////////////////////////////////////////////////////////

unsigned hash_opcode(Opcode& opc)
{
   return(ELCOR_INT_HASH(opc)) ;
}

//////////////////////////////////////////////////////////////////

unsigned hash_IR_BASE_OPCODE(IR_BASE_OPCODE& opc)
{
   return(ELCOR_INT_HASH(opc)) ;
}

//////////////////////////////////////////////////////////////////

istream& operator>>(istream& is, Opcode& opc) 
{
    char name[80] ;

    is >> name ;
    opc = el_string_to_opcode_map.value(name) ;

    return (is) ;
}

ostream& operator<<(ostream& os, const Opcode opcode) 
{
    eString name;

    name = el_opcode_to_string_map.value(opcode);
    os << name;

    return (os);
}
  
ostream& operator<<(ostream& os, const IR_BASE_OPCODE opcode) 
{
    eString name;

    name = el_base_opcode_to_string_map.value(opcode);
    os << name;

    return (os);
}

Opcode opcode_or(Opcode& opc, Opcode& modifier)
{
  Opcode new_opc = (Opcode)(opc | modifier);
  return new_opc;
}
  
// end of opcode.cpp
