/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1994 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           opcode_properties.cpp
//      Authors:        Sadun Anik, Richard Johnson, Scott Mahlke,
//                      Dave August, Sumedh Sathaye
//      Created:        December 1994
//      Description:    Functions specific to opcode values 
//
/////////////////////////////////////////////////////////////////////////////

#include "iterators.h"
#include "opcode_properties.h"
#include "op.h"
#include "operand.h"
#include "opcode_load_store.h"


///////////////////////////////////////////////////////////////////////////////
//
//	Macros
//
//////////////////////////////////////////////////////////////////////////////

IR_ROOT_OPCODE get_root(Opcode opc) 
{
   return ((IR_ROOT_OPCODE) (opc & ROOT_MASK)) ;
}

IR_ROOT_OPCODE get_root(IR_BASE_OPCODE opc) 
{
   return ((IR_ROOT_OPCODE) (opc & ROOT_MASK)) ;
}


IR_BASE_OPCODE get_base(Opcode opc) 
{
  assert (is_cmpp(opc));
  return ((IR_BASE_OPCODE) (opc & IR_CMPP_BASE_MASK)) ;
}

///////////////////////////////////////////////////////////////////////////////
//
//	Branch queries
//
//////////////////////////////////////////////////////////////////////////////

bool is_control_switch(Op* op_ptr)
{
   return is_control_switch(op_ptr->opcode()) ;
}

bool is_control_switch(Opcode opc)
{
   if (opc == BRDVI ||
	opc == BRDVF ||
	opc == BRU ||
	opc == BRCT ||
	opc == BRCF ||
        opc == BRL ||
	opc == BRLC ||
	opc == BRDIR ||
	opc == BRIND ||
	opc == BRF_B_B_F ||
	opc == BRF_B_F_F ||
	opc == BRF_F_B_B ||
	opc == BRF_F_F_B ||
	opc == BRF_F_F_F ||
	opc == BRW_B_B_F ||
	opc == BRW_B_F_F ||
	opc == BRW_F_B_B ||
	opc == BRW_F_F_B ||
	opc == BRW_F_F_F ||
	opc == RTS ||
        opc == DUMMY_BR ) {
      return true ;
   } else {
      return false ;
   }
}

bool is_branch(Op* op_ptr)
{
   return is_branch(op_ptr->opcode()) ;
}

bool is_branch(Opcode opc)
{
   if (opc == BRDVI ||
	opc == BRDVF ||
	opc == BRU ||
	opc == BRCT ||
	opc == BRCF ||
        opc == BRLC ||
        opc == BRDIR ||
        opc == BRIND ||
	opc == BRF_B_B_F ||
	opc == BRF_B_F_F ||
	opc == BRF_F_B_B ||
	opc == BRF_F_F_B ||
	opc == BRF_F_F_F ||
	opc == BRW_B_B_F ||
	opc == BRW_B_F_F ||
	opc == BRW_F_B_B ||
	opc == BRW_F_F_B ||
	opc == BRW_F_F_F ||
	opc == RTS ||
	opc == DUMMY_BR ) {
      return true ;
   } else {
      return false ;
   }
}

bool is_proper_branch(Op* op_ptr)
{
   return is_proper_branch(op_ptr->opcode()) ;
}

bool is_proper_branch(Opcode opc)
{
   if (opc == BRDVI ||
	opc == BRDVF ||
	opc == BRU ||
	opc == BRCT ||
	opc == BRCF ||
        opc == BRLC ||
        opc == BRDIR ||
        opc == BRIND ||
	opc == BRF_B_B_F ||
	opc == BRF_B_F_F ||
	opc == BRF_F_B_B ||
	opc == BRF_F_F_B ||
	opc == BRF_F_F_F ||
	opc == BRW_B_B_F ||
	opc == BRW_B_F_F ||
	opc == BRW_F_B_B ||
	opc == BRW_F_F_B ||
	opc == BRW_F_F_F ) {
      return true ;
   } else {
      return false ;
   }
}

bool is_dummy_branch(Op* op_ptr)
{
   return is_dummy_branch(op_ptr->opcode()) ;
}

bool is_dummy_branch(Opcode opc)
{
  if (opc == DUMMY_BR) {
    return true ;
  } else {
    return false ;
  }
}

bool is_normalized_branch(Op* op_ptr)
{
   return is_normalized_branch(op_ptr->opcode()) ;
}

bool is_normalized_branch(Opcode opc)
{
  if (opc == BRDIR||
      opc == BRIND) 
    return true;
  else
    return false;	 
}

bool is_traditional_branch(Op* op_ptr)
{
   return is_traditional_branch(op_ptr->opcode()) ;
}

bool is_traditional_branch(Opcode opc)
{
   if (	opc == BRU ||
	opc == BRCT ||
	opc == BRCF ||
	opc == DUMMY_BR||
	opc == BRDIR||
	opc == BRIND) {
	return true ;
   } else {
      return false ;
   }
}

bool is_conditional_branch(Op* op_ptr)
{
  if(is_brdir(op_ptr))
    return !op_ptr->src(SRC1).is_undefined();
  else
    return is_conditional_branch(op_ptr->opcode());
}

bool is_conditional_branch(Opcode opc)
{
   if (	opc == BRCT ||
	opc == BRCF ) {
      return true ;
   } else {
      return false ;
   }
}

bool is_unconditional_branch(Op* op_ptr)
{
  if(is_brdir(op_ptr))
    return op_ptr->src(SRC1).is_undefined();
  else
    return is_unconditional_branch(op_ptr->opcode()) ;
}

bool is_unconditional_branch(Opcode opc)
{
   if (	opc == BRU ||
        opc == DUMMY_BR||
	opc == BRIND) {
      return true ;
   } else {
      return false ;
   }
}

bool is_brl(Op* op_ptr)
{
  return is_brl(op_ptr->opcode());
}

bool is_brl(Opcode opc)
{
  if (opc == BRL) {
    return true;
  } else {
    return false;
  }
}

bool is_rts(Op* op_ptr)
{
  return is_rts(op_ptr->opcode());
}

bool is_rts(Opcode opc)
{
  if (opc == RTS) {
    return true;
  } else {
    return false;
  }
}

bool is_brlc(Op* op_ptr)
{
  return is_brlc(op_ptr->opcode());
}

bool is_brlc(Opcode opc)
{
  if (opc == BRLC) {
    return true;
  } else {
    return false;
  }
}

bool is_brind(Op* op_ptr) 
{
  return is_brind(op_ptr->opcode());
}

bool is_brind(Opcode opc) 
{
  return (opc == BRIND);
}


bool is_brdir(Op* op_ptr)
{
  return is_brdir(op_ptr->opcode());
}

bool is_brdir(Opcode opc)
{
  return (opc == BRDIR);
}

bool is_brct(Op* op_ptr)
{
  return is_brct(op_ptr->opcode());
}

bool is_brct(Opcode opc)
{
  if (opc == BRCT) {
    return true;
  } else {
    return false;
  }
}


bool is_brcf(Op* op_ptr)
{
  return is_brcf(op_ptr->opcode());
}

bool is_brcf(Opcode opc)
{
  if (opc == BRCF) {
    return true;
  } else {
    return false;
  }
}

bool is_bru(Op* op_ptr)
{
  return is_bru(op_ptr->opcode());
}

bool is_bru(Opcode opc)
{
  if (opc == BRU) {
    return true;
  } else {
    return false;
  }
}

bool is_brdv(Op* op_ptr)
{
  return is_brdv(op_ptr->opcode());
}

bool is_brdv(Opcode opc)
{
  if (opc == BRDVI || opc == BRDVF) {
    return true;
  } else {
    return false;
  }
}

bool is_brf(Opcode opc)
{
    if (opc==BRF_B_B_F || opc==BRF_B_F_F || opc==BRF_F_B_B ||
	opc==BRF_F_F_B || opc==BRF_F_F_F)
	return (true);
    else
	return (false);
}

bool is_brf(Op* op_ptr)
{
  return is_brf(op_ptr->opcode());
}

bool is_brw(Opcode opc)
{
    if (opc==BRW_B_B_F || opc==BRW_B_F_F || opc==BRW_F_B_B ||
	opc==BRW_F_F_B || opc==BRW_F_F_F)
	return (true);
    else
	return (false);
}

bool is_brw(Op* op_ptr)
{
  return is_brw(op_ptr->opcode());
}

bool is_swp_branch(Opcode opc)
{
    return (is_brf(opc)||is_brw(opc));
}

bool is_swp_branch(Op* op_ptr)
{
  return is_swp_branch(op_ptr->opcode());
}

bool is_call(Op* op_ptr) 
{
  return (op_ptr->opcode() == BRL);
}

bool is_return(Op* op_ptr) 
{
  return (op_ptr->opcode() == RTS);
}

bool is_movelb(Op* op_ptr)
{
  return (op_ptr->opcode() == MOVELB);
}

bool is_movelb(Opcode opc)
{
  return (opc == MOVELB);
}

bool is_movelbx(Op* op_ptr)
{
  return (op_ptr->opcode() == MOVELBX);
}

bool is_movelbx(Opcode opc)
{
  return (opc == MOVELBX);
}

bool is_movelbs(Op* op_ptr)
{
  return (op_ptr->opcode() == MOVELBS);
}

bool is_movelbs(Opcode opc)
{
  return (opc == MOVELBS);
}

bool is_pbr(Op* op_ptr)
{
  return is_pbr(op_ptr->opcode());
}

bool is_pbr(Opcode opc)
{
  if (opc == PBRA ||
      opc == PBRR ||
      opc == PBRAL ||
      opc == PBRRL ||
      opc == PBRALBS ||  // new pbr ops -- Marnix.
      opc == PBRRLBS
      ) {
    return true;
  } else {
    return false;
   }
}

bool requires_pbr(Op* op_ptr)
{
   return requires_pbr(op_ptr->opcode()) ;
}

bool requires_pbr(Opcode opc)
{
   if (opc == BRDVI ||
        opc == BRDVF ||
        opc == BRU ||
        opc == BRCT ||
        opc == BRCF ||
        opc == BRL ||
        opc == BRLC ||
        opc == BRDIR ||
        opc == BRIND ||
        opc == BRF_B_B_F ||
        opc == BRF_B_F_F ||
        opc == BRF_F_B_B ||
        opc == BRF_F_F_B ||
        opc == BRF_F_F_F ||
        opc == BRW_B_B_F ||
        opc == BRW_B_F_F ||
        opc == BRW_F_B_B ||
        opc == BRW_F_F_B ||
        opc == BRW_F_F_F ||
        opc == RTS) {
      return true ;
   } else {
      return false ;
   }
}

///////////////////////////////////////////////////////////////////////////////
//
//	Comparison queries
//
//////////////////////////////////////////////////////////////////////////////

bool is_int_leq_cmpr(Op* op_ptr)
{
  return is_int_leq_cmpr(op_ptr->opcode());
}

bool is_int_leq_cmpr(Opcode opc)
{
  if (opc == CMPR_W_LLEQ ||
      opc == CMPR_W_LEQ) {
    return true;
  } else {
    return false;
  }
}

bool is_int_geq_cmpr(Op* op_ptr)
{
  return is_int_geq_cmpr(op_ptr->opcode());
}

bool is_int_geq_cmpr(Opcode opc)
{
  if (opc == CMPR_W_LGEQ ||
      opc == CMPR_W_GEQ) {
    return true;
  } else {
     return false;
  }
}

bool is_int_lt_cmpr(Op* op_ptr)
{
  return is_int_lt_cmpr(op_ptr->opcode());
}

bool is_int_lt_cmpr(Opcode opc)
{
  if (opc == CMPR_W_LLT ||
      opc == CMPR_W_LT) {
    return true;
  } else {
    return false;
  }
}

bool is_int_gt_cmpr(Op* op_ptr)
{
  return is_int_gt_cmpr(op_ptr->opcode());
}

bool is_int_gt_cmpr(Opcode opc)
{
  if (opc == CMPR_W_LGT ||
      opc == CMPR_W_GT) {
    return true;
  } else {
    return false;
  }
}

///////////////////////////////////////////////////////////////////////////////
//
//	Predicate comparison/setting queries
//
///////////////////////////////////////////////////////////////////////////////

Opcode get_cmpp_dest1_modifier(Opcode opc)
{
    return (Opcode) (opc & IR_DEST1_MASK);
}

Opcode get_cmpp_dest2_modifier(Opcode opc)
{
    return (Opcode) (opc & IR_DEST2_MASK);
}

bool is_cmpp(Op* op_ptr) {
   return is_cmpp(op_ptr->opcode()) ;
}

bool is_cmpp(Opcode opc) {
   IR_ROOT_OPCODE t = get_root(opc) ;

   if ( (t == ROOT_CMPP) ||
        (t == ROOT_FCMPP))  {
      return true ;
   } else {
      return false ;
   }
}

bool is_icmpp(Op* op_ptr) {
   return is_icmpp(op_ptr->opcode()) ;
}

bool is_icmpp(Opcode opc) {
   IR_ROOT_OPCODE t = get_root(opc) ;

   if (t == ROOT_CMPP) {
      return true ;
   } else {
      return false ;
   }
}

bool is_fcmpp(Op* op_ptr) {
   return is_fcmpp(op_ptr->opcode()) ;
}

bool is_fcmpp(Opcode opc) {
   IR_ROOT_OPCODE t = get_root(opc) ;

   if (t == ROOT_FCMPP) {
      return true ;
   } else {
      return false ;
   }
}

bool is_predicate_clear(Op* op_ptr) 
{
  return (is_predicate_clear(op_ptr->opcode()));
}

bool is_predicate_clear(Opcode opc)
{
    if (opc == PRED_CLEAR)
        return true;
    else
	return false;
}

bool is_predicate_set(Op* op_ptr) 
{
  return (is_predicate_set(op_ptr->opcode()));
} 

bool is_predicate_set(Opcode opc)
{
    if (opc == PRED_SET)
        return true;
    else
	return false;
}

bool is_clear_all_rotating(Op* op_ptr) 
{
  return (is_clear_all_rotating(op_ptr->opcode()));
}

bool is_clear_all_rotating(Opcode opc)
{
    if (opc == PRED_CLEAR_ALL_ROTATING)
        return true;
    else
	return false;
}

bool is_U_pred(Op* op, Port_num dest)
{
  return (is_U_pred(op->opcode(), dest));
}

bool is_U_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_UN || x == IR_DEST1_UC);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_UN || x == IR_DEST2_UC);
  }
  else {
    assert (0);
    return false;  // make CC happy
  }
}

bool is_UN_pred(Op* op, Port_num dest)
{
  return (is_UN_pred(op->opcode(), dest));
}

bool is_UN_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_UN);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_UN);
  }
  else {
    assert (0);
    return false;  // make CC happy
  }
}

bool is_UC_pred(Op* op, Port_num dest)
{
  return (is_UC_pred(op->opcode(), dest));
}

bool is_UC_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_UC);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_UC);
  }
  else {
    assert (0);
    return false;  // make CC happy
  }
}

bool is_C_pred(Op* op, Port_num dest)
{
  return (is_C_pred(op->opcode(), dest));
}

bool is_C_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_CN || x == IR_DEST1_CC);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_CN || x == IR_DEST2_CC);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

bool is_CN_pred(Op* op, Port_num dest)
{
  return (is_CN_pred(op->opcode(), dest));
}

bool is_CN_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_CN);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_CN);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

bool is_CC_pred(Op* op, Port_num dest)
{
  return (is_CC_pred(op->opcode(), dest));
}

bool is_CC_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_CC);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_CC);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

bool is_O_pred(Op* op, Port_num dest)
{
  return (is_O_pred(op->opcode(), dest));
}

bool is_O_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_ON || x == IR_DEST1_OC);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_ON || x == IR_DEST2_OC);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

bool is_ON_pred(Op* op, Port_num dest)
{
  return is_ON_pred(op->opcode(), dest);
}

bool is_ON_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_ON);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_ON);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

bool is_OC_pred(Op* op, Port_num dest)
{
  return is_OC_pred(op->opcode(), dest);
}

bool is_OC_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_OC);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_OC);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

bool is_A_pred(Op* op, Port_num dest)
{
  return is_A_pred(op->opcode(), dest);
}

bool is_A_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_AN || x == IR_DEST1_AC);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_AN || x == IR_DEST2_AC);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

bool is_AN_pred(Op* op, Port_num dest)
{
  return is_AN_pred(op->opcode(), dest);
}

bool is_AN_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_AN);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_AN);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

bool is_AC_pred(Op* op, Port_num dest)
{
  return is_AC_pred(op->opcode(), dest);
}

bool is_AC_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    int x = opc & IR_DEST1_MASK;
    return (x == IR_DEST1_AC);
  }
  else if (dest == DEST2) {
    int x = opc & IR_DEST2_MASK;
    return (x == IR_DEST2_AC);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

bool is_normal_pred(Op* op, Port_num dest)
{
  return is_normal_pred(op->opcode(), dest);
}

bool is_normal_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  return (!is_complement_pred(opc, dest));
}

bool is_complement_pred(Op* op, Port_num dest)
{
  return is_complement_pred(op->opcode(), dest);
}

bool is_complement_pred(Opcode opc, Port_num dest)
{
  if (!is_cmpp(opc)) return false;

  if (dest == DEST1) {
    return (opc & IR_DEST1_CBIT_MASK);
  }
  else if (dest == DEST2) {
    return (opc & IR_DEST2_CBIT_MASK);
  }
  else {
    assert (0);
    return false; // make CC happy
  }
}

Opcode cmpp_dest1_to_dest2(Opcode opc)
{ 
  assert(is_cmpp(opc));
  Opcode new_opc = (Opcode)(opc & IR_DEST1_MASK);
  return (Opcode)(new_opc << 4);
}

Opcode cmpp_dest2_to_dest1(Opcode opc)
{
  assert(is_cmpp(opc));
  Opcode new_opc = (Opcode)(opc & IR_DEST1_MASK);
  return (Opcode)(new_opc >> 4);
}

Opcode make_complement_pred(Op* op, Port_num dest)
{
  return make_complement_pred(op->opcode(), dest);
}

Opcode make_complement_pred(Opcode opc, Port_num dest)
{
  assert (is_cmpp (opc));
  if (dest == DEST1) {
    if(opc & IR_DEST1_CBIT_MASK)
      {
	return (Opcode)(opc & ~IR_DEST1_CBIT_MASK);
      }
    else
      {
	return (Opcode)(opc | IR_DEST1_CBIT_MASK);
      }
  }
  else if (dest == DEST2) {
    if(opc & IR_DEST2_CBIT_MASK)
      {
	return (Opcode)(opc & ~IR_DEST2_CBIT_MASK);
      }
    else
      {
	return (Opcode)(opc | IR_DEST2_CBIT_MASK);
      }
  }
  El_punt("make_complement_pred: illegal value for dest");
  return ((Opcode) 0);
}

/*
 *  This function returns the opcode to be used when we want to make the
 *  destination predicate UN type.
 */

Opcode make_UN_pred(Opcode opc, Port_num dest)
{
  Opcode new_opc = opc;
  
  IR_ROOT_OPCODE root = get_root(opc);
  
  switch(root)
    {
    case ROOT_CMPP:
    case ROOT_FCMPP:
    {
      if (dest == DEST1)
	{
	  new_opc = (Opcode) (opc & ~IR_DEST1_MASK);
	  new_opc = (Opcode) (new_opc | IR_DEST1_UN);
	}
      else if (dest == DEST2)
	{
	  new_opc = (Opcode) (opc & ~IR_DEST2_MASK);
	  new_opc = (Opcode) (new_opc | IR_DEST2_UN);
	}
      return new_opc;
    }

    default:
      return (Opcode)0;
    }

  El_punt("make_UN_pred: unknown opc");
  return (Opcode)0;  
  
}

/*
 *  This function returns the opcode to be used when we want to make the
 *  destination predicate UC type.
 */

Opcode make_UC_pred(Opcode opc, Port_num dest)
{
  Opcode new_opc = opc;

  IR_ROOT_OPCODE root = get_root(opc);

  switch(root)
    {
    case ROOT_CMPP:
    case ROOT_FCMPP:
    {
      if (dest == DEST1)
        {
          new_opc = (Opcode) (opc & ~IR_DEST1_MASK);
          new_opc = (Opcode) (new_opc | IR_DEST1_UC);
        }
      else if (dest == DEST2)
        {
          new_opc = (Opcode) (opc & ~IR_DEST2_MASK);
          new_opc = (Opcode) (new_opc | IR_DEST2_UC);
        }
      return new_opc;
    }

    default:
      return (Opcode)0;
    }

  El_punt("make_UC_pred: unknown opc");
  return (Opcode)0;

}


/*
 *  This function returns the opcode to be used when we want to make the
 *  destination predicate ON type.
 */

Opcode make_ON_pred(Opcode opc, Port_num dest)
{
  Opcode new_opc = opc;
  
  IR_ROOT_OPCODE root = get_root(opc);
  
  switch(root)
    {
    case ROOT_CMPP:
    case ROOT_FCMPP:
    {
      if (dest == DEST1)
	{
	  new_opc = (Opcode) (opc & ~IR_DEST1_MASK);
	  new_opc = (Opcode) (new_opc | IR_DEST1_ON);
	}
      else if (dest == DEST2)
	{
	  new_opc = (Opcode) (opc & ~IR_DEST2_MASK);
	  new_opc = (Opcode) (new_opc | IR_DEST2_ON);
	}
      return new_opc;
    }

    default:
      return (Opcode)0;
    }

  El_punt("make_ON_pred: unknown opc");
  return (Opcode)0;  
  
}

/*
 *  This function returns the opcode to be used when we want to make the
 *  destination predicate OC type.
 */

Opcode make_OC_pred(Opcode opc, Port_num dest)
{
  Opcode new_opc = opc;
  
  IR_ROOT_OPCODE root = get_root(opc);
  
  switch(root)
    {
    case ROOT_CMPP:
    case ROOT_FCMPP:
    {
      if (dest == DEST1)
	{
	  new_opc = (Opcode) (opc & ~IR_DEST1_MASK);
	  new_opc = (Opcode) (new_opc | IR_DEST1_OC);
	}
      else if (dest == DEST2)
	{
	  new_opc = (Opcode) (opc & ~IR_DEST2_MASK);
	  new_opc = (Opcode) (new_opc | IR_DEST2_OC);
	}
      return new_opc;
    }

    default:
      return (Opcode)0;
    }

  El_punt("make_OC_pred: unknown opc");
  return (Opcode)0;  
  
}

/*
 *  This function returns the opcode to be used when we want to make the
 *  destination predicate OC type.
 */

Opcode make_AN_pred(Opcode opc, Port_num dest)
{
  Opcode new_opc = opc;
  
  IR_ROOT_OPCODE root = get_root(opc);
  
  switch(root)
    {
    case ROOT_CMPP:
    case ROOT_FCMPP:
    {
      if (dest == DEST1)
        {
          new_opc = (Opcode) (opc & ~IR_DEST1_MASK);
          new_opc = (Opcode) (new_opc | IR_DEST1_AN);
        }
      else if (dest == DEST2)
        {
          new_opc = (Opcode) (opc & ~IR_DEST2_MASK);
          new_opc = (Opcode) (new_opc | IR_DEST2_AN);
        }
      return new_opc;
    }

    default:
      return (Opcode)0;
    }

  El_punt("make_AN_pred: unknown opc");
  return (Opcode)0;

}

/*
 *  This function returns the opcode to be used when we want to make the
 *  destination predicate OC type.
 */

Opcode make_AC_pred(Opcode opc, Port_num dest)
{
  Opcode new_opc = opc;

  IR_ROOT_OPCODE root = get_root(opc);

  switch(root)
    {
    case ROOT_CMPP:
    case ROOT_FCMPP:
    {
      if (dest == DEST1)
        {
          new_opc = (Opcode) (opc & ~IR_DEST1_MASK);
          new_opc = (Opcode) (new_opc | IR_DEST1_AC);
        }
      else if (dest == DEST2)
        {
          new_opc = (Opcode) (opc & ~IR_DEST2_MASK);
          new_opc = (Opcode) (new_opc | IR_DEST2_AC);
        }
      return new_opc;
    }

    default:
      return (Opcode)0;
    }

  El_punt("make_AC_pred: unknown opc");
  return (Opcode)0;

}


/* 
** Changes an or type predicate to an unconditional type predicate
*/

Opcode make_U_pred(Opcode opc, Port_num dest)
{
  Opcode new_opc = opc;
  
  IR_ROOT_OPCODE root = get_root(opc);
  
  switch(root)
    {
    case ROOT_CMPP:
    case ROOT_FCMPP:
    {
      if (dest == DEST1)
	{
	  if(is_ON_pred(opc, DEST1))
	    {
	      new_opc = (Opcode) (opc & ~IR_DEST1_MASK);
	      new_opc = (Opcode) (new_opc | IR_DEST1_UN);
	    }
	  if(is_OC_pred(opc, DEST1))
	    {
	      new_opc = (Opcode) (opc & ~IR_DEST1_MASK);
	      new_opc = (Opcode) (new_opc | IR_DEST1_UC);
	    }
	}
      else if (dest == DEST2)
	{	
	  if(is_ON_pred(opc, DEST2))
	    {
	      new_opc = (Opcode) (opc & ~IR_DEST2_MASK);
	      new_opc = (Opcode) (new_opc | IR_DEST2_UN);
	    }
	  if(is_OC_pred(opc, DEST2))
	    {
	      new_opc = (Opcode) (opc & ~IR_DEST2_MASK);
	      new_opc = (Opcode) (new_opc | IR_DEST2_UC);
	    }
	}
      return new_opc;
    }

    default:
      return (Opcode)0;
    }

  El_punt("Something is SERIOUSLY wrong.  The world is coming to an end.");
  return (Opcode)0;  
  
}


/*
** This function makes any compare instruction into an OR type CMPP.
** The first dest in ON and the second dest is OC.
*/

Opcode make_O_cmpp(Opcode opc)
{
  Opcode new_opc = opc;
  
  IR_ROOT_OPCODE root = get_root(opc);
  
  switch(root)
    {
    case ROOT_CMPP:
    case ROOT_FCMPP:
    {
      new_opc = make_ON_pred(opc, DEST1);
      new_opc = make_OC_pred(new_opc, DEST2); 
    }

    case ROOT_CMPR:
    {
      if(opc == CMPR_W_EQ) new_opc = (Opcode) BASE_CMPP_W_EQ;
      if(opc == CMPR_W_NEQ) new_opc = (Opcode) BASE_CMPP_W_NEQ;
      
      if(opc == CMPR_W_LT) new_opc = (Opcode) BASE_CMPP_W_LT;
      if(opc == CMPR_W_GT) new_opc = (Opcode) BASE_CMPP_W_GT;
      
      if(opc == CMPR_W_LEQ) new_opc = (Opcode) BASE_CMPP_W_LEQ;
      if(opc == CMPR_W_GEQ) new_opc = (Opcode) BASE_CMPP_W_GEQ;
      
      new_opc = make_ON_pred(opc, DEST1);
      new_opc = make_OC_pred(new_opc, DEST2);
    }

    case ROOT_FCMPR:
    {
      if(opc == FCMPR_S_EQ) new_opc = (Opcode) BASE_FCMPP_S_EQ;
      if(opc == FCMPR_S_NEQ) new_opc = (Opcode) BASE_FCMPP_S_NEQ;
      
      if(opc == FCMPR_S_LT) new_opc = (Opcode) BASE_FCMPP_S_LT;
      if(opc == FCMPR_S_GT) new_opc = (Opcode) BASE_FCMPP_S_GT;
      
      if(opc == FCMPR_S_LEQ) new_opc = (Opcode) BASE_FCMPP_S_LEQ;
      if(opc == FCMPR_S_GEQ) new_opc = (Opcode) BASE_FCMPP_S_GEQ;

      if(opc == FCMPR_D_EQ) new_opc = (Opcode) BASE_FCMPP_D_EQ;
      if(opc == FCMPR_D_NEQ) new_opc = (Opcode) BASE_FCMPP_D_NEQ;
      
      if(opc == FCMPR_D_LT) new_opc = (Opcode) BASE_FCMPP_D_LT;
      if(opc == FCMPR_D_GT) new_opc = (Opcode) BASE_FCMPP_D_GT;
      
      if(opc == FCMPR_D_LEQ) new_opc = (Opcode) BASE_FCMPP_D_LEQ; 
      if(opc == FCMPR_D_GEQ) new_opc = (Opcode) BASE_FCMPP_D_GEQ;

      new_opc = make_ON_pred(opc, DEST1);
      new_opc = make_OC_pred(new_opc, DEST2);
      
    }

    default:
      return (Opcode)0;
    }

  El_punt("Something is SERIOUSLY wrong.  The world is coming to an end.");
  return (Opcode)0;  
  
}

bool is_int_leq_cmpp(Op* op_ptr)
{
  return is_int_leq_cmpp(op_ptr->opcode());
}

bool is_int_leq_cmpp(Opcode opc)
{
  IR_BASE_OPCODE base_opc = get_base(opc);
  if (base_opc == BASE_CMPP_W_LLEQ ||
      base_opc == BASE_CMPP_W_LEQ) {
    return true;
  } else {
    return false;
  }
}

bool is_int_geq_cmpp(Op* op_ptr)
{
  return is_int_geq_cmpp(op_ptr->opcode());
}

bool is_int_geq_cmpp(Opcode opc)
{
  IR_BASE_OPCODE base_opc = get_base(opc);
  if (base_opc == BASE_CMPP_W_LGEQ ||
      base_opc == BASE_CMPP_W_GEQ) {
    return true;
  } else {
    return false;
  }
}

bool is_int_lt_cmpp(Op* op_ptr)
{
  return is_int_lt_cmpp(op_ptr->opcode());
}

bool is_int_lt_cmpp(Opcode opc)
{
  IR_BASE_OPCODE base_opc = get_base(opc);
  if (base_opc == BASE_CMPP_W_LLT ||
      base_opc == BASE_CMPP_W_LT) {
    return true;
  } else {
    return false;
  }
}

bool is_int_gt_cmpp(Op* op_ptr)
{
  return is_int_gt_cmpp(op_ptr->opcode());
}

bool is_int_gt_cmpp(Opcode opc)
{
  IR_BASE_OPCODE base_opc = get_base(opc);
  if (base_opc == BASE_CMPP_W_LGT ||
      base_opc == BASE_CMPP_W_GT) {
    return true;
  } else {
    return false;
  }
}

bool is_int_neq_cmpp(Op* op_ptr)
{
  return is_int_neq_cmpp(op_ptr->opcode());
}

bool is_int_neq_cmpp(Opcode opc)
{
  IR_BASE_OPCODE base_opc = get_base(opc);
  if (base_opc == BASE_CMPP_W_NEQ) {
    return true;
  } else {
    return false;
  }
}

bool is_conditionally_executed(Op* op_ptr)
{
   if (!op_ptr->predicated()) return false ;
   for (Op_predicate_sources ii(op_ptr) ; ii != 0 ; ii++) {
      Operand& oprnd = *ii ;
      if (!oprnd.is_predicate_true()) return true ;
   }
   return false ;
}

Opcode exchange_cmpp_dest_modifiers(Opcode opc)
{
    Opcode mod1, mod2, new_mod1, new_mod2, new_opc;

    mod1 = get_cmpp_dest1_modifier(opc);
    mod2 = get_cmpp_dest2_modifier(opc);

    /* Figure out new modifier for dest2 */
    switch ((IR_MODIFIERS) mod1) {
	case IR_DEST1_UN:
	    new_mod2 = (Opcode) IR_DEST2_UN;
	    break;
	case IR_DEST1_UC:
	    new_mod2 = (Opcode) IR_DEST2_UC;
	    break;
	case IR_DEST1_CN:
	    new_mod2 = (Opcode) IR_DEST2_CN;
	    break;
	case IR_DEST1_CC:
	    new_mod2 = (Opcode) IR_DEST2_CC;
	    break;
	case IR_DEST1_ON:
	    new_mod2 = (Opcode) IR_DEST2_ON;
	    break;
	case IR_DEST1_OC:
	    new_mod2 = (Opcode) IR_DEST2_OC;
	    break;
	case IR_DEST1_AN:
	    new_mod2 = (Opcode) IR_DEST2_AN;
	    break;
	case IR_DEST1_AC:
	    new_mod2 = (Opcode) IR_DEST2_AC;
	    break;
	default:
	    El_punt("exchange_cmpp_dest_modifiers: unknown dest1 modifier!");
    }

    /* Figure out new modifier for dest1 */
    switch ((IR_MODIFIERS) mod2) {
        case IR_DEST2_UN:
            new_mod1 = (Opcode) IR_DEST1_UN;
            break;
        case IR_DEST2_UC:
            new_mod1 = (Opcode) IR_DEST1_UC;
            break;
        case IR_DEST2_CN:
            new_mod1 = (Opcode) IR_DEST1_CN;
            break;
        case IR_DEST2_CC:
            new_mod1 = (Opcode) IR_DEST1_CC;
            break;
        case IR_DEST2_ON:
            new_mod1 = (Opcode) IR_DEST1_ON;
            break;
        case IR_DEST2_OC:
            new_mod1 = (Opcode) IR_DEST1_OC;
            break;
        case IR_DEST2_AN:
            new_mod1 = (Opcode) IR_DEST1_AN;
            break;
        case IR_DEST2_AC:
            new_mod1 = (Opcode) IR_DEST1_AC;
            break;
        default:
            El_punt("exchange_cmpp_dest_modifiers: unknown dest2 modifier!");
    }

    /* Construct the new opcode */
    new_opc = opc;
    new_opc = (Opcode) (new_opc & (~IR_DEST1_MASK));
    new_opc = (Opcode) (new_opc & (~IR_DEST2_MASK));
    new_opc = (Opcode) (new_opc | new_mod1);
    new_opc = (Opcode) (new_opc | new_mod2);

    return (new_opc);
}


///////////////////////////////////////////////////////////////////////////////
//
//	Load/Store queries
//
//////////////////////////////////////////////////////////////////////////////

bool is_postincrement(Opcode opc)
{
    if (opc & IR_INCREMENT)
	return (true);
    else
	return (false);
}

bool is_postincrement(Op* op_ptr)
{
   return is_postincrement(op_ptr->opcode());
}

Opcode get_mem_src_modifier(Opcode opc)
{
    return (Opcode) (opc & (IR_SRC_C1|IR_SRC_C2|IR_SRC_C3|IR_SRC_V1));
}

Opcode get_mem_dest_modifier(Opcode opc)
{
    return (Opcode) (opc & (IR_DEST_C1|IR_DEST_C2|IR_DEST_C3|IR_DEST_V1));
}

// Load ops that differ only in DEST field share same MDES entry
// Load ops are therefore translated to a base load with DEST set to C1
Opcode get_C1_dest_load(Opcode opc)
{
  assert (is_load(opc));
  IR_ROOT_OPCODE t = get_root(opc) ;
  if (t == ROOT_DVLD || t == ROOT_FDVLD) return opc;

  if (t == ROOT_LD || t == ROOT_FLD || 
      t == ROOT_DSLD || t == ROOT_FDSLD)
    // opc_XX_C1
    return ((Opcode) ((opc & (~IR_DEST_MASK)) | IR_DEST_C1));
  
  // tmp. hack: new loads only with opc_C1_C1  -- Marnix.
  return ((Opcode) ((opc & (~IR_SRC_MASK | ~IR_DEST_MASK)) |
		     (IR_SRC_C1 | IR_DEST_C1)) );
}

bool is_load(Op* op_ptr)
{
  return is_load(op_ptr->opcode()) ;
}

bool is_load(Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_LD || 
	  t == ROOT_FLD || 
	  t == ROOT_DSLD || 
	  t == ROOT_FDSLD ||
	  t == ROOT_DVLD || 
	  t == ROOT_FDVLD ||
	  t == ROOT_LDX ||
	  t == ROOT_LG ||
	  t == ROOT_LM ||
	  t == ROOT_LGX ||
	  t == ROOT_LMX ||
	  t == ROOT_FLG ||
	  t == ROOT_FLM ||
	  t == ROOT_RESTORE ||      // Restore/unspill ops for GPR & FPR
	  t == ROOT_FRESTORE ||
	  t == ROOT_BRESTORE ||
	  t == ROOT_LL ||	// SAM 10-98, add local mem opcodes
	  t == ROOT_LLX ||
	  t == ROOT_FLL ||
	  t == ROOT_LLG ||
	  t == ROOT_LLGX ||
	  t == ROOT_FLLG);
}

bool is_sign_extend_load(Op *op_ptr)
{
  return is_sign_extend_load(op_ptr->opcode()) ;
}

bool is_sign_extend_load(Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_LDX ||
	  t == ROOT_LGX ||
	  t == ROOT_LMX ||
	  t == ROOT_LLX ||	// SAM 10-98, add local mem opcodes
	  t == ROOT_LLGX);
}

bool is_load_from_C1(Op* op_ptr)
{
  return is_load_from_C1(op_ptr->opcode()) ;
}

bool is_load_from_C1(Opcode opc)
{
  if (!is_load(opc)) return (false);
  return ((opc & IR_SRC_MASK) == IR_SRC_C1);
}

bool is_store(Op* op_ptr)
{
  return is_store(op_ptr->opcode()) ;
}

bool is_store(Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_ST || 
	  t == ROOT_FST ||
	  t == ROOT_SG ||
	  t == ROOT_SM ||
	  t == ROOT_FSG ||
	  t == ROOT_FSM ||
	  t == ROOT_SAVE ||       // To save/spill GPR, FPR and BTR
	  t == ROOT_FSAVE ||
	  t == ROOT_BSAVE ||
	  t == ROOT_SL ||	// SAM 10-98, add local mem opcodes
	  t == ROOT_FSL ||
	  t == ROOT_SLG ||
	  t == ROOT_FSLG);
}

bool is_memory(Op* op_ptr)
{
   return is_memory(op_ptr->opcode()) ;
}

bool is_memory(Opcode opc)
{
   return(is_load(opc) || is_store(opc)) ;
}

bool is_mem_base_plus_offset(Op *op_ptr)
{
  return is_mem_base_plus_offset(op_ptr->opcode());
}

bool is_mem_base_plus_offset(Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_LG  ||
	  t == ROOT_LM  ||
	  t == ROOT_LGX ||
	  t == ROOT_LMX ||	  
	  t == ROOT_FLG ||
	  t == ROOT_FLM ||
	  t == ROOT_SG  ||
	  t == ROOT_SM  ||
	  t == ROOT_FSG ||
	  t == ROOT_FSM ||
	  t == ROOT_LLG ||	// SAM 10-98, add local mem opcodes
	  t == ROOT_LLGX ||
	  t == ROOT_FLLG ||
	  t == ROOT_SLG ||
	  t == ROOT_FSLG);
}

bool is_memref(Op* op_ptr)
{
   return is_memref(op_ptr->opcode()) ;
}

bool is_memref(Opcode opc)
{
   return(is_load(opc) || is_store(opc) || is_brl(opc) || is_rts(opc)) ;
}

bool is_save(Opcode opc)
{
    return (opc == (Opcode) SAVE) ;
}

bool is_save(Op *op_ptr)
{
    return (is_save(op_ptr->opcode()));
}

bool is_restore(Opcode opc)
{
    return (opc == (Opcode) RESTORE);
}

bool is_restore(Op *op_ptr)
{
    return (is_restore(op_ptr->opcode()));
}
    
bool is_gpr_save_restore(Opcode opc)
{
    return (opc == (Opcode) SAVE || opc == (Opcode) RESTORE);
}

bool is_gpr_save_restore(Op *op_ptr)
{
    return (is_gpr_save_restore(op_ptr->opcode()));
}

bool is_fpr_save_restore(Opcode opc)
{
    return (opc == (Opcode) FSAVE || opc == (Opcode) FRESTORE);
}

bool is_fpr_save_restore(Op *op_ptr)
{
    return (is_fpr_save_restore(op_ptr->opcode()));
}

bool is_single_fpr_save_restore(Op *op_ptr)
{
    Opcode opc;
    Operand operand;

    opc = op_ptr->opcode();
    if (! is_fpr_save_restore(opc))
       return (false);

    if (opc == (Opcode) FSAVE) {
	operand = op_ptr->src(SRC2);
    }
    else {
	operand = op_ptr->dest(DEST1);
    }

    if (operand.data_type() == EL_DT_FLOAT)
        return (true);
    else
	return (false);
}

bool is_btr_save_restore(Opcode opc)
{
    return (opc == (Opcode) BSAVE || opc == (Opcode) BRESTORE);
}

bool is_btr_save_restore(Op *op_ptr)
{
    return (is_btr_save_restore(op_ptr->opcode()));
}

bool is_save_restore(Opcode opc)
{
    return (is_gpr_save_restore(opc) ||
            is_fpr_save_restore(opc) ||
            is_btr_save_restore(opc));
}

bool is_save_restore(Op *op_ptr)
{
    return (is_gpr_save_restore(op_ptr) ||
            is_fpr_save_restore(op_ptr) ||
	    is_btr_save_restore(op_ptr));
}

Opcode remove_post_increment(Opcode opc)
{
    Opcode new_opc;

    if (! is_postincrement(opc))
	El_punt("remove_post_increment: opc is not a post increment");

    new_opc = opc;
    new_opc = (Opcode) (new_opc & (~IR_INCREMENT));

    return (new_opc);
}

Opcode extract_increment_from_post_increment(Opcode opc)
{
    if (! is_postincrement(opc))
	El_punt("extract_increment_from_post_increment: opc is not a post inc");

    return (ADD_W);
}

bool is_pred_load_all(Op* op_ptr)
{
  return is_pred_load_all(op_ptr->opcode()) ;
}

bool is_pred_load_all(Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_PRED_LOAD_ALL);
}

bool is_pred_store_all(Op* op_ptr)
{
  return is_pred_store_all(op_ptr->opcode()) ;
}

bool is_pred_store_all(Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_PRED_STORE_ALL);
}

bool is_local_mem_load(Op *op_ptr)
{
  return is_local_mem_load(op_ptr->opcode());
}

bool is_local_mem_load(Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_LL ||
	  t == ROOT_LLX ||
	  t == ROOT_FLL ||
	  t == ROOT_LLG ||
	  t == ROOT_LLGX ||
	  t == ROOT_FLLG);
}

bool is_local_mem_store(Op *op_ptr)
{
  return is_local_mem_store(op_ptr->opcode());
}

bool is_local_mem_store(Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_SL ||
	  t == ROOT_FSL ||
	  t == ROOT_SLG ||
	  t == ROOT_FSLG);
}

bool is_local_mem(Op *op_ptr)
{
    return is_local_mem(op_ptr->opcode());
}

bool is_local_mem(Opcode opc)
{
    return (is_local_mem_load(opc) || is_local_mem_store(opc));
}


///////////////////////////////////////////////////////////////////////////////
//
//	Arithmetic queries
//
//////////////////////////////////////////////////////////////////////////////

bool is_no_op(Op* op_ptr)
{
  return is_no_op(op_ptr->opcode());
}

bool is_no_op(Opcode opc)
{
  return (opc == NO_OP || opc == M_NO_OP);
}

bool is_add(Op* op_ptr)
{
   return is_add(op_ptr->opcode()) ;
}

bool is_add(Opcode opc)
{
   return(opc == ADD_W) ;
}

bool is_move(Op* op_ptr)
{
   return is_move(op_ptr->opcode()) ;
}

bool is_move(Opcode opc)
{
  if ((opc == MOVE ||
       opc == MOVEGF_L ||
       opc == MOVEGF_U ||
       opc == MOVEF_S ||
       opc == MOVEF_D ||
       opc == MOVEFG_L ||
       opc == MOVEFG_U ||
       opc == MOVEPG ||
       opc == MOVEGG ||
       opc == MOVEGC ||
       opc == MOVECG ||
       opc == MOVEBB ||
       opc == MOVELG ||
       opc == MOVELGS ||
       opc == MOVELGX ||
       opc == MOVELF ||
       opc == MOVELFS ||
       opc == MOVELB ||
       opc == MOVELBS ||
       opc == MOVELBX 
//     opc == MOVEGBP ||    // To restore predicate and speculative tag bits 
//       opc == MOVEGCM
       )
      || is_pbr(opc)) {
    return true ;
  }
  else {
    return false ;
  }
}

bool is_int_div(Op* op_ptr)
{
   return is_int_div(op_ptr->opcode()) ;
}

bool is_int_div(Opcode opc)
{
   return (opc == DIV_W ||
           opc == DIVL_W);
}

bool is_int_rem(Op* op_ptr)
{
   return is_int_rem(op_ptr->opcode()) ;
}

bool is_int_rem(Opcode opc)
{
   return (opc == REM_W ||
           opc == REML_W);
}

bool is_extract(Op* op_ptr)
{
    return is_extract(op_ptr->opcode());
}

bool is_extract(Opcode opc)
{
   return (opc == EXTS_B ||
           opc == EXTS_H);
}

bool is_ialu(Op* op_ptr)
{
  return is_ialu(op_ptr->opcode());
}

bool is_ialu(Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_ABS ||
          t == ROOT_ADD ||
          t == ROOT_ADDL ||
          t == ROOT_AND ||
          t == ROOT_ANDCM ||
          t == ROOT_DIV ||
          t == ROOT_DIVL ||
          t == ROOT_MPY ||
          t == ROOT_MPYL ||
          t == ROOT_NAND ||
          t == ROOT_NOR ||
          t == ROOT_OR ||
          t == ROOT_ORCM ||
          t == ROOT_REM ||
          t == ROOT_REML ||
          t == ROOT_SH1ADDL ||
          t == ROOT_SH2ADDL ||
          t == ROOT_SH3ADDL ||
          t == ROOT_SHL ||
          t == ROOT_SHR ||
          t == ROOT_SHLA ||
          t == ROOT_SHRA ||
          t == ROOT_SUB ||
          t == ROOT_SUBL ||
          t == ROOT_XOR ||
          t == ROOT_XORCM ||
          t == ROOT_EXTS ||
          t == ROOT_MOVE ||
          t == ROOT_MOVEGF_L ||
          t == ROOT_MOVEGF_U ||
          t == ROOT_MOVEPG ||
	  t == ROOT_MOVELG ||
	  t == ROOT_MOVELGS ||
	  t == ROOT_MOVELGX ||
          t == ROOT_MOVEGG ||
          t == ROOT_MOVEGC ||
          t == ROOT_MOVECG ||
          t == ROOT_MOVEBB ||
          t == ROOT_CMPR   ||
	  t == ROOT_MOVEGBP ||  // To restore predicates and tag bits
	  t == ROOT_MOVEGCM
	  );
}

// note: Sumedh
// all ops with a single binary operation are simple binary;
//          e.g. add, addl, and, or etc
//
// all ops with more than one binary operations bundled into one are complex
// binary;
//          e.g. andcm (AND and complement), sh1addl (shift left by 1 and add)
//
// simple binary ops have exactly two operands
// complex ops have more than two operands, some of which may be implicit.
//

bool is_ialu_simple_binary_op (Op* op_ptr)
{
  return is_ialu_simple_binary_op (op_ptr->opcode());
}

bool is_ialu_simple_binary_op (Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_ADD ||
          t == ROOT_ADDL ||
          t == ROOT_AND ||
          t == ROOT_OR ||
          t == ROOT_DIV ||
          t == ROOT_DIVL ||
          t == ROOT_MPY ||
          t == ROOT_MPYL ||
          t == ROOT_REM ||
          t == ROOT_REML ||
          t == ROOT_SHL ||
          t == ROOT_SHR ||
          t == ROOT_SHLA ||
          t == ROOT_SHRA ||
          t == ROOT_SUB ||
          t == ROOT_SUBL ||
          t == ROOT_XOR);
}

bool is_ialu_complex_binary_op (Op* op_ptr)
{
  return is_ialu_complex_binary_op (op_ptr->opcode());
}

bool is_ialu_complex_binary_op (Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_ANDCM ||
          t == ROOT_NAND ||
          t == ROOT_NOR ||
          t == ROOT_ORCM ||
          t == ROOT_SH1ADDL ||
          t == ROOT_SH2ADDL ||
          t == ROOT_SH3ADDL ||
          t == ROOT_XORCM);
}

bool is_falu (Op* op_ptr)
{
  return is_falu(op_ptr->opcode());
}

bool is_falu (Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_FADD ||
          t == ROOT_FABS ||
          t == ROOT_FDIV ||
          t == ROOT_FMAX ||
          t == ROOT_FMIN ||
          t == ROOT_FMPY ||
          t == ROOT_FMPYADD ||
          t == ROOT_FMPYADDN ||
          t == ROOT_FMPYRSUB ||
          t == ROOT_FMPYSUB ||
          t == ROOT_FRCP ||
          t == ROOT_FSQRT ||
          t == ROOT_FSUB ||
          t == ROOT_CONVWS ||
          t == ROOT_CONVWD ||
          t == ROOT_CONVSW ||
          t == ROOT_CONVDW ||
          t == ROOT_CONVSD ||
          t == ROOT_CONVDS ||
          t == ROOT_MOVEF ||
          t == ROOT_MOVEFG_L ||
          t == ROOT_MOVEFG_U ||
          t == ROOT_FCMPR ||
	  t == ROOT_MOVELF ||
	  t == ROOT_MOVELFS ||
	  t == ROOT_MOVELB ||
	  t == ROOT_MOVELBS ||
	  t == ROOT_MOVELBX
	  );
}

// note:
// convention similar to the ialus...
//
bool is_falu_simple_binary_op (Op* op_ptr)
{
  return is_falu_simple_binary_op (op_ptr->opcode());
}

bool is_falu_simple_binary_op (Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_FADD ||
          t == ROOT_FSUB ||
          t == ROOT_FDIV ||
          t == ROOT_FMAX ||
          t == ROOT_FMIN ||
          t == ROOT_FMPY ||
          t == ROOT_FRCP);
}

bool is_falu_complex_binary_op (Op* op_ptr)
{
  return is_falu_complex_binary_op (op_ptr->opcode());
}

bool is_falu_complex_binary_op (Opcode opc)
{
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_FMPYADD ||
          t == ROOT_FMPYADDN ||
          t == ROOT_FMPYRSUB ||
          t == ROOT_FMPYSUB);
}

bool is_literal_move(Op* op_ptr) {
  return is_literal_move(op_ptr->opcode());
}

bool is_literal_move(Opcode opc) {
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_MOVELG  ||
	  t == ROOT_MOVELGS ||
	  t == ROOT_MOVELGX ||
	  t == ROOT_MOVELF  ||
	  t == ROOT_MOVELFS ||
	  t == ROOT_MOVELB  ||
	  t == ROOT_MOVELBS ||
	  t == ROOT_MOVELBX ||
	  t == ROOT_PBRRL   ||
	  t == ROOT_PBRAL   ||
	  t == ROOT_PBRRLBS ||
	  t == ROOT_PBRALBS
	  );
}

bool is_literal_move_with_shift(Op* op_ptr) {
  return is_literal_move_with_shift(op_ptr->opcode());
}

bool is_literal_move_with_shift(Opcode opc) {
  IR_ROOT_OPCODE t = get_root(opc) ;
  return (t == ROOT_MOVELGS ||
	  t == ROOT_MOVELGX ||
	  t == ROOT_MOVELFS ||
	  t == ROOT_MOVELBS ||
	  t == ROOT_MOVELBX ||
	  t == ROOT_PBRRLBS ||
	  t == ROOT_PBRALBS
	  );
}

///////////////////////////////////////////////////////////////////////////////
//
//	Pseudo Op queries
//
//////////////////////////////////////////////////////////////////////////////

bool is_pseudo(Op* op)
{
  return (is_pseudo(op->opcode()));
}

bool is_pseudo(Opcode opc)
{
  return ((IR_PSEUDO & opc) != 0);
}

bool is_control_merge(Op* op_ptr) 
{
  return (is_control_merge(op_ptr->opcode()));
} 

bool is_control_merge(Opcode opc)
{
    if (opc==C_MERGE)
	return (true);
    else
	return (false);
}

bool is_merge(Op* op_ptr)
{
  return (op_ptr->opcode() == D_MERGE);
} 

bool is_switch(Op* op_ptr) 
{
  return (op_ptr->opcode() == D_SWITCH);
} 

bool is_use(Op* op_ptr) 
{
  return (op_ptr->opcode() == USE);
}

bool is_def(Op* op_ptr) 
{
  return is_def(op_ptr->opcode());
}

bool is_def(Opcode opc) 
{
  return (opc == DEF);
}

bool is_remap(Op* op_ptr) 
{
  return is_remap(op_ptr->opcode());
}

bool is_remap(Opcode opc) 
{
  return (opc == REMAP);
}

bool is_define(Op* op_ptr) 
{
  return is_define(op_ptr->opcode());
}

bool is_define(Opcode opc) 
{
  return (opc == DEFINE);
}

///////////////////////////////////////////////////////////////////////////////
//
//	Miscellaneous queries
//
///////////////////////////////////////////////////////////////////////////////

Op* real_op (Op* op)
{
  if (is_merge(op) || is_switch(op)) {
    List<Op*>& relops = op->get_relops();
    return relops.head();
  } else {
    return op;
  }
}

bool has_side_effect(Op* op)
{
  return has_side_effect(op->opcode());
}

bool has_side_effect(Opcode opc)
{
  IR_ROOT_OPCODE root = get_root(opc);
  
  switch(root)
    {
    case ROOT_LD:      
    case ROOT_FLD:  
    case ROOT_ST:   
    case ROOT_FST:   
    case ROOT_DSLD:
    case ROOT_FDSLD:  
    case ROOT_DVLD:   
    case ROOT_FDVLD: 
    case ROOT_BRU:    
    case ROOT_RTS:    
    case ROOT_BRCT:   
    case ROOT_BRCF:   
    case ROOT_BRL:    
    case ROOT_BRLC:  
    case ROOT_BRF:    
    case ROOT_BRW:
      return true;
      break;
    default:
      return false;
    }
  return false;  
}

/*
 *  Reverse operation support function
 *
 *  This function returns the opcode to be used when the order of the operands
 *  are switched.  This is only defined for 2 operand instructions.  Returns 0
 *  if no reverse op exists or the number of operands is not 2.  (Even though
 *  0 is NO_OP, this is OK since NO_OP has no reverse op.)
 */

Opcode get_reverse_op(Opcode opc)
{
  Opcode new_opc = opc;
  
  IR_ROOT_OPCODE root = get_root(opc);
  
  switch(root)
    {
    case ROOT_ADD:
    case ROOT_ADDL:
    case ROOT_AND:
    case ROOT_MPY:
    case ROOT_MPYL:
    case ROOT_NAND: 
    case ROOT_NOR:
    case ROOT_OR: 
    case ROOT_XOR:
    case ROOT_FADD:
    case ROOT_FMAX:
    case ROOT_FMIN:
    case ROOT_FMPY:
      return new_opc;
      
    case ROOT_CMPP:
    {
      IR_BASE_OPCODE base = get_base(opc);
      new_opc = (Opcode)(new_opc & ~base);
      
      if(base == BASE_CMPP_W_EQ) return (Opcode)(new_opc | BASE_CMPP_W_EQ);
      if(base == BASE_CMPP_W_NEQ) return (Opcode)(new_opc | BASE_CMPP_W_NEQ);
      
      if(base == BASE_CMPP_W_LT) return (Opcode)(new_opc | BASE_CMPP_W_GT);
      if(base == BASE_CMPP_W_GT) return (Opcode)(new_opc | BASE_CMPP_W_LT);
      
      if(base == BASE_CMPP_W_LEQ) return (Opcode)(new_opc | BASE_CMPP_W_GEQ);
      if(base == BASE_CMPP_W_GEQ) return (Opcode)(new_opc | BASE_CMPP_W_LEQ);
      
      if(base == BASE_CMPP_W_LLT) return (Opcode)(new_opc | BASE_CMPP_W_LGT);
      if(base == BASE_CMPP_W_LGT) return (Opcode)(new_opc | BASE_CMPP_W_LLT);
      
      if(base == BASE_CMPP_W_LLEQ) return (Opcode)(new_opc | BASE_CMPP_W_LGEQ);
      if(base == BASE_CMPP_W_LGEQ) return (Opcode)(new_opc | BASE_CMPP_W_LLEQ);
    }

    case ROOT_FCMPP:
    {
      IR_BASE_OPCODE base = get_base(opc);
      new_opc = (Opcode)(new_opc & ~base);

      if(base == BASE_FCMPP_S_EQ) return (Opcode)(new_opc | BASE_FCMPP_S_EQ);
      if(base == BASE_FCMPP_S_NEQ) return (Opcode)(new_opc | BASE_FCMPP_S_NEQ);
      
      if(base == BASE_FCMPP_S_LT) return (Opcode)(new_opc | BASE_FCMPP_S_GT);
      if(base == BASE_FCMPP_S_GT) return (Opcode)(new_opc | BASE_FCMPP_S_LT);
      
      if(base == BASE_FCMPP_S_LEQ) return (Opcode)(new_opc | BASE_FCMPP_S_GEQ);
      if(base == BASE_FCMPP_S_GEQ) return (Opcode)(new_opc | BASE_FCMPP_S_LEQ);
      
      if(base == BASE_FCMPP_D_EQ) return (Opcode)(new_opc | BASE_FCMPP_D_EQ);
      if(base == BASE_FCMPP_D_NEQ) return (Opcode)(new_opc | BASE_FCMPP_D_NEQ);
      
      if(base == BASE_FCMPP_D_LT) return (Opcode)(new_opc | BASE_FCMPP_D_GT);
      if(base == BASE_FCMPP_D_GT) return (Opcode)(new_opc | BASE_FCMPP_D_LT);
      
      if(base == BASE_FCMPP_D_LEQ) return (Opcode)(new_opc | BASE_FCMPP_D_GEQ);
      if(base == BASE_FCMPP_D_GEQ) return (Opcode)(new_opc | BASE_FCMPP_D_LEQ);
    }

    case ROOT_CMPR:
    {
      if(opc == CMPR_W_EQ) return (Opcode)(CMPR_W_EQ);
      if(opc == CMPR_W_NEQ) return (Opcode)(CMPR_W_NEQ);
      
      if(opc == CMPR_W_LT) return (Opcode)(CMPR_W_GT);
      if(opc == CMPR_W_GT) return (Opcode)(CMPR_W_LT);
      
      if(opc == CMPR_W_LEQ) return (Opcode)(CMPR_W_GEQ);
      if(opc == CMPR_W_GEQ) return (Opcode)(CMPR_W_LEQ);
    }

    case ROOT_FCMPR:
    {
      if(opc == FCMPR_S_EQ) return (Opcode)(FCMPR_S_EQ);
      if(opc == FCMPR_S_NEQ) return (Opcode)(FCMPR_S_NEQ);
      
      if(opc == FCMPR_S_LT) return (Opcode)(FCMPR_S_GT);
      if(opc == FCMPR_S_GT) return (Opcode)(FCMPR_S_LT);
      
      if(opc == FCMPR_S_LEQ) return (Opcode)(FCMPR_S_GEQ);
      if(opc == FCMPR_S_GEQ) return (Opcode)(FCMPR_S_LEQ);

      if(opc == FCMPR_D_EQ) return (Opcode)(FCMPR_D_EQ);
      if(opc == FCMPR_D_NEQ) return (Opcode)(FCMPR_D_NEQ);
      
      if(opc == FCMPR_D_LT) return (Opcode)(FCMPR_D_GT);
      if(opc == FCMPR_D_GT) return (Opcode)(FCMPR_D_LT);
      
      if(opc == FCMPR_D_LEQ) return (Opcode)(FCMPR_D_GEQ);
      if(opc == FCMPR_D_GEQ) return (Opcode)(FCMPR_D_LEQ);
    }

    default:
      return (Opcode)0;
    }

  El_punt("Something is SERIOUSLY wrong.  The world is coming to an end.");
  return (Opcode)0;  
  
}

/*
 *  Reverse condition support function
 *
 *  This function returns the opcode to be used when we want to compute
 *  the negation of the current opcode.
 */

Opcode get_opposite_cond(Opcode opc)
{
  Opcode new_opc = opc;
  
  IR_ROOT_OPCODE root = get_root(opc);
  
  switch(root)
    {
    case ROOT_CMPP:
    {
      IR_BASE_OPCODE base = get_base(opc);
      new_opc = (Opcode)(new_opc & ~base);
      
      if(base == BASE_CMPP_W_EQ) return (Opcode)(new_opc | BASE_CMPP_W_NEQ);
      if(base == BASE_CMPP_W_NEQ) return (Opcode)(new_opc | BASE_CMPP_W_EQ);
      
      if(base == BASE_CMPP_W_LT) return (Opcode)(new_opc | BASE_CMPP_W_GEQ);
      if(base == BASE_CMPP_W_GT) return (Opcode)(new_opc | BASE_CMPP_W_LEQ);
      
      if(base == BASE_CMPP_W_LEQ) return (Opcode)(new_opc | BASE_CMPP_W_GT);
      if(base == BASE_CMPP_W_GEQ) return (Opcode)(new_opc | BASE_CMPP_W_LT);
      
      if(base == BASE_CMPP_W_LLT) return (Opcode)(new_opc | BASE_CMPP_W_LGEQ);
      if(base == BASE_CMPP_W_LGT) return (Opcode)(new_opc | BASE_CMPP_W_LLEQ);
      
      if(base == BASE_CMPP_W_LLEQ) return (Opcode)(new_opc | BASE_CMPP_W_LGT);
      if(base == BASE_CMPP_W_LGEQ) return (Opcode)(new_opc | BASE_CMPP_W_LLT);
    }

    case ROOT_FCMPP:
    {
      IR_BASE_OPCODE base = get_base(opc);
      new_opc = (Opcode)(new_opc & ~base);

      if(base == BASE_FCMPP_S_EQ) return (Opcode)(new_opc | BASE_FCMPP_S_NEQ);
      if(base == BASE_FCMPP_S_NEQ) return (Opcode)(new_opc | BASE_FCMPP_S_EQ);
      
      if(base == BASE_FCMPP_S_LT) return (Opcode)(new_opc | BASE_FCMPP_S_GEQ);
      if(base == BASE_FCMPP_S_GT) return (Opcode)(new_opc | BASE_FCMPP_S_LEQ);
      
      if(base == BASE_FCMPP_S_LEQ) return (Opcode)(new_opc | BASE_FCMPP_S_GT);
      if(base == BASE_FCMPP_S_GEQ) return (Opcode)(new_opc | BASE_FCMPP_S_LT);
      
      if(base == BASE_FCMPP_D_EQ) return (Opcode)(new_opc | BASE_FCMPP_D_NEQ);
      if(base == BASE_FCMPP_D_NEQ) return (Opcode)(new_opc | BASE_FCMPP_D_EQ);
      
      if(base == BASE_FCMPP_D_LT) return (Opcode)(new_opc | BASE_FCMPP_D_GEQ);
      if(base == BASE_FCMPP_D_GT) return (Opcode)(new_opc | BASE_FCMPP_D_LEQ);
      
      if(base == BASE_FCMPP_D_LEQ) return (Opcode)(new_opc | BASE_FCMPP_D_GT);
      if(base == BASE_FCMPP_D_GEQ) return (Opcode)(new_opc | BASE_FCMPP_D_LT);
    }

    case ROOT_CMPR:
    {
      if(opc == CMPR_W_EQ) return (Opcode)(CMPR_W_NEQ);
      if(opc == CMPR_W_NEQ) return (Opcode)(CMPR_W_EQ);
      
      if(opc == CMPR_W_LT) return (Opcode)(CMPR_W_GEQ);
      if(opc == CMPR_W_GT) return (Opcode)(CMPR_W_LEQ);
      
      if(opc == CMPR_W_LEQ) return (Opcode)(CMPR_W_GT);
      if(opc == CMPR_W_GEQ) return (Opcode)(CMPR_W_LT);
    }

    case ROOT_FCMPR:
    {
      if(opc == FCMPR_S_EQ) return (Opcode)(FCMPR_S_NEQ);
      if(opc == FCMPR_S_NEQ) return (Opcode)(FCMPR_S_EQ);
      
      if(opc == FCMPR_S_LT) return (Opcode)(FCMPR_S_GEQ);
      if(opc == FCMPR_S_GT) return (Opcode)(FCMPR_S_LEQ);
      
      if(opc == FCMPR_S_LEQ) return (Opcode)(FCMPR_S_GT);
      if(opc == FCMPR_S_GEQ) return (Opcode)(FCMPR_S_LT);

      if(opc == FCMPR_D_EQ) return (Opcode)(FCMPR_D_NEQ);
      if(opc == FCMPR_D_NEQ) return (Opcode)(FCMPR_D_EQ);
      
      if(opc == FCMPR_D_LT) return (Opcode)(FCMPR_D_GEQ);
      if(opc == FCMPR_D_GT) return (Opcode)(FCMPR_D_LEQ);
      
      if(opc == FCMPR_D_LEQ) return (Opcode)(FCMPR_D_GT);
      if(opc == FCMPR_D_GEQ) return (Opcode)(FCMPR_D_LT);
    }

    default:
      return (Opcode)0;
    }

  El_punt("Something is SERIOUSLY wrong.  The world is coming to an end.");
  return (Opcode)0;  
  
}

Opcode convert_CMPP_to_CMPR(Opcode opc)
{
   Opcode new_opc = opc;
  
   IR_ROOT_OPCODE root = get_root(opc);
   if ((root == ROOT_CMPP) || (root == ROOT_FCMPP))
   {
      new_opc = (Opcode)(IR_CMPP_BASE_MASK & opc) ;
      if (root == ROOT_CMPP) return (Opcode)((new_opc^ROOT_CMPP) | ROOT_CMPR) ;
      if (root == ROOT_FCMPP) return (Opcode)((new_opc^ROOT_FCMPP) | ROOT_FCMPR) ;
   }
   return(new_opc) ;
}

bool is_excepting_op(Op *op_ptr)
{
    return is_excepting_op(op_ptr->opcode());
}

bool is_excepting_op(Opcode opc)
{
    return (is_load(opc) || is_store(opc) || is_falu(opc) || is_int_div(opc) ||
	    is_int_rem(opc));
}

/*
 *	This function is not complete yet for all opcodes, but a start
 */
Opcode convert_to_local_memory(Opcode opc, IR_MODIFIERS lm_spec)
{
    IR_ROOT_OPCODE root, new_root;
    Opcode new_opc;

    root = get_root(opc);
    switch (root) {
        case ROOT_LD:
	    new_root = ROOT_LL;
	    break;
	case ROOT_FLD:
	    new_root = ROOT_FLL;
	    break;
	case ROOT_ST:
	    new_root = ROOT_SL;
	    break;
	case ROOT_FST:
	    new_root = ROOT_FSL;
	    break;
	default:
	    El_punt("convert_to_local_memory: unknown opc %s",
			(char *)el_opcode_to_string_map.value(opc));
    }
    new_opc = (Opcode) ((opc^root) | new_root);
    new_opc = (Opcode) (new_opc & (~IR_SRC_MASK));
    new_opc = (Opcode) (new_opc & (~IR_DEST_MASK));
    new_opc = (Opcode) (new_opc | lm_spec);
    return (new_opc);
}



///////////////////////////////////////////////////////////////////////////////
//
//	Op generating queries/functions
//
///////////////////////////////////////////////////////////////////////////////

Opcode get_move_opcode_for_operand(Operand &operand)
{
    Data_type d_type;

    if (operand.is_reg() || operand.is_macro_reg()) {
        d_type = operand.data_type();
	switch (d_type) {
	    case EL_DT_VOID:
	    case EL_DT_bool:
	    case EL_DT_CHAR:
	    case EL_DT_UCHAR:
	    case EL_DT_SHORT:
	    case EL_DT_USHORT:
	    case EL_DT_INT:
	    case EL_DT_UINT:
	    case EL_DT_LONG:
	    case EL_DT_ULONG:
	    case EL_DT_LLONG:
	    case EL_DT_ULLONG:
	    case EL_DT_LLLONG:
	    case EL_DT_ULLLONG:
	    case EL_DT_POINTER:
		return (MOVE);
	    case EL_DT_FLOAT:
		return (MOVEF_S);
	    case EL_DT_DOUBLE:
		return (MOVEF_D);
	    case EL_DT_BRANCH:
		return (MOVE);
		// El_punt("get_move_opcode_for_operand: no move for branch tgt");
		// break;
	    case EL_DT_PREDICATE:
		El_punt("get_move_opcode_for_operand: no move for predicate");
		break;
	    default:
		El_punt("get_move_opcode_for_operand: uknown data type");
	}
    }
    else if (operand.is_int() || operand.is_string() || operand.is_label()) {
	return (MOVE);
    }
    else if (operand.is_float())
	return (MOVEF_S);
    else if (operand.is_double())
	return (MOVEF_D);
    else 
	El_punt("get_move_opcode_for_operand: unknown operand type");

    return ((Opcode)0);
}

Opcode get_add_opcode_for_operand(Operand &operand)
{
    Data_type d_type;

    if (operand.is_reg() || operand.is_macro_reg()) {
        d_type = operand.data_type();
	switch (d_type) {
	    case EL_DT_VOID:
	    case EL_DT_bool:
	    case EL_DT_CHAR:
	    case EL_DT_SHORT:
	    case EL_DT_INT:
	    case EL_DT_LONG:
	    case EL_DT_LLONG:
	    case EL_DT_LLLONG:
	    case EL_DT_POINTER:
		return (ADD_W);
	    case EL_DT_UCHAR:
	    case EL_DT_USHORT:
	    case EL_DT_UINT:
	    case EL_DT_ULONG:
	    case EL_DT_ULLONG:
	    case EL_DT_ULLLONG:
		return (ADDL_W);
	    case EL_DT_FLOAT:
		return (FADD_S);
	    case EL_DT_DOUBLE:
		return (FADD_D);
	    case EL_DT_BRANCH:
	        El_punt("get_add_opcode_for_operand: no add for branch tgt");
	        break;
            case EL_DT_PREDICATE:
	        El_punt("get_add_opcode_for_operand: no add for predicate");
	        break;
	    default:
	        El_punt("get_add_opcode_for_operand: uknown data type!");
	}
    }
    else if (operand.is_int() || operand.is_string() || operand.is_label())
	return (ADD_W);
    else if (operand.is_float())
	return (FADD_S);
    else if (operand.is_double())
	return (FADD_D);
    else 
	El_punt("get_add_opcode_for_operand: unknown operand type");

    return ((Opcode)0);
}

Opcode get_sub_opcode_for_operand(Operand &operand)
{
    Data_type d_type;

    if (operand.is_reg() || operand.is_macro_reg()) {
        d_type = operand.data_type();
	switch (d_type) {
	    case EL_DT_VOID:
	    case EL_DT_bool:
	    case EL_DT_CHAR:
	    case EL_DT_SHORT:
	    case EL_DT_INT:
	    case EL_DT_LONG:
	    case EL_DT_LLONG:
	    case EL_DT_LLLONG:
	    case EL_DT_POINTER:
		return (SUB_W);
	    case EL_DT_UCHAR:
	    case EL_DT_USHORT:
	    case EL_DT_UINT:
	    case EL_DT_ULONG:
	    case EL_DT_ULLONG:
	    case EL_DT_ULLLONG:
		return (ADDL_W);
	    case EL_DT_FLOAT:
		return (FSUB_S);
	    case EL_DT_DOUBLE:
		return (FSUB_D);
	    case EL_DT_BRANCH:
	        El_punt("get_sub_opcode_for_operand: no sub for branch tgt");
	        break;
            case EL_DT_PREDICATE:
	        El_punt("get_sub_opcode_for_operand: no sub for predicate");
	        break;
	    default:
	        El_punt("get_sub_opcode_for_operand: uknown data type!");
	}
    }
    else if (operand.is_int() || operand.is_string() || operand.is_label())
	return (SUB_W);
    else if (operand.is_float())
	return (FSUB_S);
    else if (operand.is_double())
	return (FSUB_D);
    else 
	El_punt("get_sub_opcode_for_operand: unknown operand type");

    return ((Opcode)0);
}

Opcode get_mpy_opcode_for_operand(Operand &operand)
{
    Data_type d_type;

    if (operand.is_reg() || operand.is_macro_reg()) {
        d_type = operand.data_type();
	switch (d_type) {
	    case EL_DT_VOID:
	    case EL_DT_bool:
	    case EL_DT_CHAR:
	    case EL_DT_SHORT:
	    case EL_DT_INT:
	    case EL_DT_LONG:
	    case EL_DT_LLONG:
	    case EL_DT_LLLONG:
	    case EL_DT_POINTER:
		return (MPY_W);
	    case EL_DT_UCHAR:
	    case EL_DT_USHORT:
	    case EL_DT_UINT:
	    case EL_DT_ULONG:
	    case EL_DT_ULLONG:
	    case EL_DT_ULLLONG:
		return (MPYL_W);
	    case EL_DT_FLOAT:
		return (FMPY_S);
	    case EL_DT_DOUBLE:
		return (FMPY_D);
	    case EL_DT_BRANCH:
	        El_punt("get_mpy_opcode_for_operand: no mpy for branch tgt");
	        break;
            case EL_DT_PREDICATE:
	        El_punt("get_mpy_opcode_for_operand: no mpy for predicate");
	        break;
	    default:
	        El_punt("get_mpy_opcode_for_operand: uknown data type!");
	}
    }
    else if (operand.is_int() || operand.is_string() || operand.is_label())
	return (MPY_W);
    else if (operand.is_float())
	return (FMPY_S);
    else if (operand.is_double())
	return (FMPY_D);
    else 
	El_punt("get_mpy_opcode_for_operand: unknown operand type");

    return ((Opcode)0);
}

// * Assume C1/C1 cache specifiers for this function
// * At this time do not account for signed/unsigned, needs to be fixed
//   for the future.
Opcode get_load_opcode_for_operand(Operand &operand)
{
    Data_type d_type;

    if (operand.is_reg() || operand.is_macro_reg()) {
        d_type = operand.data_type();
	switch (d_type) {
	    case EL_DT_CHAR:
	    case EL_DT_UCHAR:
		return ((Opcode) L_B_C1_C1);
	    case EL_DT_SHORT:
	    case EL_DT_USHORT:
		return ((Opcode) L_H_C1_C1);
	    case EL_DT_VOID:
	    case EL_DT_INT:
	    case EL_DT_LONG:
	    case EL_DT_LLONG:
	    case EL_DT_LLLONG:
	    case EL_DT_POINTER:
	    case EL_DT_UINT:
	    case EL_DT_ULONG:
	    case EL_DT_ULLONG:
	    case EL_DT_ULLLONG:
		return ((Opcode) L_W_C1_C1);
	    case EL_DT_FLOAT:
		return ((Opcode) FL_S_C1_C1);
	    case EL_DT_DOUBLE:
		return ((Opcode) FL_D_C1_C1);
	    case EL_DT_BRANCH:
	        El_punt("get_load_opcode_for_operand: no load for branch tgt");
	        break;
            case EL_DT_PREDICATE:
	        El_punt("get_load_opcode_for_operand: no load for predicate");
	        break;
	    case EL_DT_bool:
	        El_punt("get_load_opcode_for_operand: no load for bool");
	        break;
	    default:
	        El_punt("get_load_opcode_for_operand: uknown data type!");
	}
    }
    else 
	El_punt("get_load_opcode_for_operand: unknown operand type");

    return ((Opcode)0);
}

// Again, create C1 versions only
Opcode get_store_opcode_for_operand(Operand &operand)
{
    Data_type d_type;

    if (operand.is_reg() || operand.is_macro_reg()) {
        d_type = operand.data_type();
        switch (d_type) {
            case EL_DT_CHAR:
            case EL_DT_UCHAR:
                return ((Opcode) S_B_C1);
            case EL_DT_SHORT:
            case EL_DT_USHORT:
                return ((Opcode) S_H_C1);
            case EL_DT_VOID:
            case EL_DT_INT:
            case EL_DT_LONG:
            case EL_DT_LLONG:
            case EL_DT_LLLONG:
            case EL_DT_POINTER:
            case EL_DT_UINT:
            case EL_DT_ULONG:
            case EL_DT_ULLONG:
            case EL_DT_ULLLONG:
                return ((Opcode) S_W_C1);
            case EL_DT_FLOAT:
                return ((Opcode) FS_S_C1);
            case EL_DT_DOUBLE:
                return ((Opcode) FS_D_C1);
            case EL_DT_BRANCH:
                El_punt("get_store_opcode_for_operand: no store for branch tgt");
                break;
            case EL_DT_PREDICATE:
                El_punt("get_store_opcode_for_operand: no store for predicate");
                break;
            case EL_DT_bool:
                El_punt("get_store_opcode_for_operand: no store for bool");
                break;
            default:
                El_punt("get_store_opcode_for_operand: uknown data type!");
        }
    }
    else
        El_punt("get_store_opcode_for_operand: unknown operand type");

    return ((Opcode)0);
}

Op *El_generate_move_op(Operand &d, Operand &s, Operand &p)
{
    Opcode opc;
    Op *new_op;

    if (! (d.is_reg() || d.is_macro_reg()))
	El_punt("El_generate_move_op: cannot create move with specifed dest");

    opc = get_move_opcode_for_operand(d);
    new_op = new Op(opc);
    new_op->set_dest(DEST1, d);
    new_op->set_src(SRC1, s);
    new_op->set_src(PRED1, p);

    return (new_op);
}

Op *El_generate_add_op(Operand &d, Operand &s1, Operand &s2, Operand &p)
{
    Opcode opc;
    Op *new_op;

    if (! (d.is_reg() || d.is_macro_reg()))
	El_punt("El_generate_add_op: cannot create add with specifed dest");

    opc = get_add_opcode_for_operand(d);
    new_op = new Op(opc);
    new_op->set_dest(DEST1, d);
    new_op->set_src(SRC1, s1);
    new_op->set_src(SRC2, s2);
    new_op->set_src(PRED1, p);

    return (new_op);
}

Op *El_generate_sub_op(Operand &d, Operand &s1, Operand &s2, Operand &p)
{
    Opcode opc;
    Op *new_op;

    if (! (d.is_reg() || d.is_macro_reg()))
	El_punt("El_generate_sub_op: cannot create sub with specifed dest");

    opc = get_sub_opcode_for_operand(d);
    new_op = new Op(opc);
    new_op->set_dest(DEST1, d);
    new_op->set_src(SRC1, s1);
    new_op->set_src(SRC2, s2);
    new_op->set_src(PRED1, p);

    return (new_op);
}

Op *El_generate_mpy_op(Operand &d, Operand &s1, Operand &s2, Operand &p)
{
    Opcode opc;
    Op *new_op;

    if (! (d.is_reg() || d.is_macro_reg()))
	El_punt("El_generate_mpy_op: cannot create mpy with specifed dest");

    opc = get_mpy_opcode_for_operand(d);
    new_op = new Op(opc);
    new_op->set_dest(DEST1, d);
    new_op->set_src(SRC1, s1);
    new_op->set_src(SRC2, s2);
    new_op->set_src(PRED1, p);

    return (new_op);
}

