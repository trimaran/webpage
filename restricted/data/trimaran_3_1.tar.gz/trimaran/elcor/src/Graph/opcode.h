/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1994 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           opcode.h
//      Authors:        Sadun Anik, Scott Mahlke, Richard Johnson
//      Created:        December 1994
//      Description:    Enums for the opcodes 
//
/////////////////////////////////////////////////////////////////////////////

#ifndef _OPCODE_H
#define _OPCODE_H

#include<iostream.h>
#include "map.h"
#include "hash_map.h"
#include "string_class.h"

enum IR_ROOT_OPCODE {
   ROOT_NO_OP    = 0,
   ROOT_ABS      = 1,
   ROOT_ADD      = 2, 
   ROOT_ADDL     = 3,
   ROOT_AND      = 4,
   ROOT_ANDCM    = 5,
   ROOT_DIV      = 6,
   ROOT_DIVL     = 7,
   ROOT_MPY      = 8,
   ROOT_MPYL     = 9,
   ROOT_NAND     = 10,
   ROOT_NOR      = 11,
   ROOT_OR       = 12,
   ROOT_ORCM     = 13,
   ROOT_REM      = 14,
   ROOT_REML     = 15,
   ROOT_SH1ADDL  = 16,
   ROOT_SH2ADDL  = 17,
   ROOT_SH3ADDL  = 18,
   ROOT_SHL      = 19,
   ROOT_SHR      = 20,
   ROOT_SHLA     = 21,
   ROOT_SHRA     = 22,
   ROOT_SUB      = 23,
   ROOT_SUBL     = 24,
   ROOT_XOR      = 25,
   ROOT_XORCM    = 26,
   ROOT_FADD     = 27,	// S|D
   ROOT_FABS     = 28,	// S|D
   ROOT_FDIV     = 29,	// S|D
   ROOT_FMAX     = 30,	// S|D  30
   ROOT_FMIN     = 31,	// S|D
   ROOT_FMPY     = 32,	// S|D
   ROOT_FMPYADD  = 33,	// S|D	
   ROOT_FMPYADDN = 34,	// S|D
   ROOT_FMPYRSUB = 35,	// S|D
   ROOT_FMPYSUB  = 36,	// S|D
   ROOT_FRCP     = 37,	// S|D
   ROOT_FSQRT    = 38,	// S|D
   ROOT_FSUB     = 39,	// S|D
   ROOT_CONVWS   = 40, // 40
   ROOT_CONVWD   = 41,
   ROOT_CONVSW   = 42,
   ROOT_CONVDW   = 43,
   ROOT_CONVSD   = 44,
   ROOT_CONVDS   = 45,
   ROOT_EXTS     = 46,	// B|H
   ROOT_MOVE     = 47,
   ROOT_MOVEGF_L = 48,
   ROOT_MOVEGF_U = 49,
   ROOT_MOVEF    = 50, // 50
   ROOT_MOVEFG_L = 51,
   ROOT_MOVEFG_U = 52,
   ROOT_MOVEPG   = 53,
   ROOT_LDCM     = 54,  // This operation is no longer supported.
                        // It is replaced by MOVEGCM. We should remove it soon
   ROOT_CMPR     = 55,	// <I-cond>
   ROOT_FCMPR    = 56,	// S|D | <F-cond> 
   ROOT_CMPP     = 57,	// <I-cond> <D-action> <D-action>
   ROOT_FCMPP    = 58,	// S|D | <F-cond> <D-action> <D-action>
   ROOT_LD       = 59,		// INC B|H|W <cache> <cache>
   ROOT_FLD      = 60,		// INC S|D <cache> <cache>      60
   ROOT_ST       = 61,		// INC B|H|W <cache> <cache>
   ROOT_FST      = 62,		// INC S|D <cache> <cache>
   ROOT_DSLD     = 63,
   ROOT_FDSLD    = 64,
   ROOT_DVLD     = 65,
   ROOT_FDVLD    = 66,

   ROOT_BRDVI    = 67,
   ROOT_BRDVF    = 68,
   ROOT_PBRR     = 69,
   ROOT_PBRA     = 70,    // 70
   ROOT_BRU      = 71,
   ROOT_RTS      = 72,
   ROOT_BRCT     = 73,
   ROOT_BRCF     = 74,
   ROOT_BRL      = 75,
   ROOT_BRLC     = 76,
   ROOT_BRF      = 77,
   ROOT_BRW      = 78,
   
   // Extensions from IMPACT
   ROOT_PROLOGUE  = 79,
   ROOT_EPILOGUE = 80,  // 80
   ROOT_DEFINE   = 81,
   ROOT_ALLOC    = 82,
   ROOT_SIM_DIR  = 83,
   
   // IR Extensions
   ROOT_D_SWITCH   = 84,
   ROOT_D_MERGE    = 85,
   ROOT_C_MERGE    = 86,

   ROOT_USE      = 87,
   ROOT_DEF      = 88,

   ROOT_REMAP    = 89,
   ROOT_PRED_CLEAR		= 90,
   ROOT_PRED_CLEAR_ALL		= 91,
   ROOT_PRED_SET		= 92,
   ROOT_PRED_AND		= 93,
   ROOT_PRED_COMPL		= 94,
   ROOT_BRDIR                   = 95,   // Pseudo branch for control-flow xforms
   ROOT_BRIND                   = 96,   // Pseudo branch for control-flow xforms
   ROOT_PRED_LOAD_ALL		= 97,
   ROOT_PRED_STORE_ALL		= 98,

   // SUIF extensions
   ROOT_DIVFLOOR                =  99,
   ROOT_DIVCEIL                 = 100,
   ROOT_MIN                     = 101,
   ROOT_MAX                     = 102,

   // Literal codegen extensions
   ROOT_MOVELG                  = 103,
   ROOT_MOVELGS                 = 104,
   ROOT_MOVELGX                 = 105,

   ROOT_MOVELF                  = 106,
   ROOT_MOVELFS                 = 107,

   ROOT_MOVELB                  = 108,
   ROOT_MOVELBS                 = 109,
   ROOT_MOVELBX                 = 110,
   ROOT_PBRAL                   = 111,
   ROOT_PBRRL                   = 112,
   ROOT_PBRALBS                 = 113,
   ROOT_PBRRLBS                 = 114,

   // Memory ops with base + offset
   ROOT_LG                      = 115, // offset is gpr or short literal
   ROOT_LM                      = 116, // offset is medium (m) literal
   ROOT_SG                      = 117,
   ROOT_SM                      = 118,
   ROOT_FLG                     = 119,
   ROOT_FLM                     = 120,
   ROOT_FSG                     = 121,
   ROOT_FSM                     = 122,
   ROOT_LDX                     = 123, // with sign extension
   ROOT_LGX                     = 124,
   ROOT_LMX                     = 125,

   // move ops to support restricted IO formats
   ROOT_MOVEGG                  = 126,
   ROOT_MOVEGC                  = 127,
   ROOT_MOVECG                  = 128,
   ROOT_MOVEBB                  = 129,

// New opocodes for register save/restore and spill/unspill -- VK/5/22/98
   // New load/store operations for GPRs, FPRs and BTRs. These operations 
   // ignore the speculative tag bit of the register being loaded or stored.
   ROOT_SAVE                    = 130,
   ROOT_RESTORE                 = 131,
   ROOT_FSAVE                   = 132,
   ROOT_FRESTORE                = 133,
   ROOT_BSAVE                   = 134,
   ROOT_BRESTORE                = 135,
   // New move operations used for predicate registers.
   ROOT_MOVEGBP                 = 136,
   ROOT_MOVEGCM                 = 137,

   // PlayDoh 2.0 local memory loads and stores.  Added SAM 10-98.
   ROOT_LL       		= 138, // INC B|H|W <lm>
   ROOT_LLX       		= 139, // INC B|H|W <lm>
   ROOT_FLL      		= 140, // INC S|D <lm>
   ROOT_SL       		= 141, // INC B|H|W <lm>
   ROOT_FSL      		= 142, // INC S|D <lm>

   ROOT_LLG                     = 143, // INC B|H|W <lm>
   ROOT_LLGX                    = 144, // INC B|H|W <lm>
   ROOT_FLLG                    = 145, // INC B|H|W <lm>
   ROOT_SLG                     = 146, // INC B|H|W <lm>
   ROOT_FSLG                    = 147, // INC B|H|W <lm>

   ROOT_MASK = 0xFF
} ;

enum IR_MODIFIERS {
   IR_PSEUDO =                0x100,
   
   IR_DOUBLE =                0x200,
   IR_BYTE =                  0x400,
   IR_HALFWORD =              0x800,
   IR_INCREMENT =            0x1000,

   IR_MULTI_CYCLE =          0x1000,	// modifier for no-ops

   IR_FALSE =                0x2000,
   IR_EQ =                   0x4000,
   IR_LT =                   0x8000,
   IR_LEQ =                  0xc000,
   IR_GT =                  0x10000,
   IR_GEQ =                 0x14000,
   IR_SV =                  0x18000,
   IR_OD =                  0x1c000,
   IR_TRUE =                0x20000,
   IR_NEQ =                 0x24000,
   IR_LLT =                 0x28000,
   IR_LLEQ =                0x2c000,
   IR_LGT =                 0x30000,
   IR_LGEQ =                0x34000,
   IR_NSV =                 0x38000,
   IR_EV =                  0x3c000,

   IR_CMPP_BASE_MASK =      0x3ffff,

   // Unordered comparison currently not supported!!
   // See SAM if you have questions.
   IR_F_FALSE =              0x2000,
   // IR_F_FALSE_UNO =          0x4000,
   IR_F_EQ =                 0x8000,
   // IR_F_EQ_UNO =             0xc000,
   IR_F_LT =                0x10000,
   // IR_F_LT_UNO =            0x14000,
   IR_F_LEQ =               0x18000,
   // IR_F_LEQ_UNO =           0x1c000,
   IR_F_GT =                0x20000,
   // IR_F_GT_UNO =            0x24000,
   IR_F_GEQ =               0x28000,
   // IR_F_GEQ_UNO =           0x2c000,
   IR_F_NEQ =               0x30000,
   // IR_F_NEQ_UNO =           0x34000,
   IR_F_TRUE =              0x38000,
   // IR_F_TRUE_UNO =          0x3c000,

   // CLEAR_ALL modifiers
   IR_ALL =	    0x2000,
   IR_STATIC =	    0x4000,
   IR_ROTATING =    0x8000,
    

   // destination modifiers for compare-to-predicate ops
   //   - 3 bits for kind, 1 bit for normal/complement

   IR_DEST1_XX =            0x00000, // no dest1 modifier
   IR_DEST1_UN =            0x80000,
   IR_DEST1_UC =            0xc0000,
   IR_DEST1_CN =           0x100000,
   IR_DEST1_CC =           0x140000,
   IR_DEST1_ON =           0x180000,
   IR_DEST1_OC =           0x1c0000,
   IR_DEST1_AN =           0x200000,
   IR_DEST1_AC =           0x240000,
   IR_DEST1_CBIT_MASK =     0x40000, // mask for complement bit
   IR_DEST1_MASK =         0x3c0000,
   
   IR_DEST2_XX =           0x000000, // no dest2 modifier
   IR_DEST2_UN =           0x800000,
   IR_DEST2_UC =           0xc00000,
   IR_DEST2_CN =          0x1000000,
   IR_DEST2_CC =          0x1400000,
   IR_DEST2_ON =          0x1800000,
   IR_DEST2_OC =          0x1c00000,
   IR_DEST2_AN =          0x2000000,
   IR_DEST2_AC =          0x2400000,
   IR_DEST2_CBIT_MASK =    0x400000, // mask for complement bit
   IR_DEST2_MASK =        0x3c00000,
   
   IR_SRC_C1 =              0x40000, 
   IR_SRC_C2 =              0x80000,
   IR_SRC_C3 =              0xC0000,
   IR_SRC_V1 =             0x100000,
   IR_SRC_MASK =	   0x1C0000,  // mask for isolating IR_SRC_C/V field
   
   IR_DEST_C1 =            0x200000,
   IR_DEST_C2 =            0x400000,
   IR_DEST_C3 =            0x600000,
   IR_DEST_V1 =            0x800000,
   IR_DEST_MASK =          0xE00000,  // mask for removing IR_DEST_C/V modifiers

   IR_LM_L1 =              0x40000,   // Local memory specifier, any numbered are allowed,
   IR_LM_L2 =              0x80000,   // 4 declared for now.
   IR_LM_L3 =              0xC0000,
   IR_LM_L4 =              0x100000,
   IR_LM_MASK =            0x1C0000,  // mask for isolating LM specifier

   IR_LOOP_CONTINUE =     0x1000000,
   IR_LOOP_RAMP =         0x2000000,
   IR_LOOP_STOP =         0x4000000
} ;

enum IR_BASE_OPCODE {
   BASE_CMPP_W_FALSE = ROOT_CMPP | IR_FALSE,
   BASE_CMPP_W_EQ = ROOT_CMPP | IR_EQ ,
   BASE_CMPP_W_LT = ROOT_CMPP | IR_LT,
   BASE_CMPP_W_LEQ = ROOT_CMPP | IR_LEQ,
   BASE_CMPP_W_GT = ROOT_CMPP | IR_GT ,
   BASE_CMPP_W_GEQ = ROOT_CMPP | IR_GEQ ,
   BASE_CMPP_W_SV = ROOT_CMPP | IR_SV ,
   BASE_CMPP_W_OD = ROOT_CMPP | IR_OD ,
   BASE_CMPP_W_TRUE = ROOT_CMPP | IR_TRUE ,
   BASE_CMPP_W_NEQ = ROOT_CMPP | IR_NEQ,
   BASE_CMPP_W_LLT = ROOT_CMPP | IR_LLT,
   BASE_CMPP_W_LLEQ = ROOT_CMPP | IR_LLEQ,
   BASE_CMPP_W_LGT = ROOT_CMPP | IR_LGT ,
   BASE_CMPP_W_LGEQ = ROOT_CMPP | IR_LGEQ ,
   BASE_CMPP_W_NSV = ROOT_CMPP | IR_NSV ,
   BASE_CMPP_W_EV = ROOT_CMPP | IR_EV ,

   BASE_FCMPP_S_FALSE = ROOT_FCMPP | IR_F_FALSE ,
   BASE_FCMPP_S_EQ = ROOT_FCMPP | IR_F_EQ ,
   BASE_FCMPP_S_LT = ROOT_FCMPP | IR_F_LT,
   BASE_FCMPP_S_LEQ = ROOT_FCMPP | IR_F_LEQ,
   BASE_FCMPP_S_GT = ROOT_FCMPP | IR_F_GT ,
   BASE_FCMPP_S_GEQ = ROOT_FCMPP | IR_F_GEQ ,
   BASE_FCMPP_S_NEQ = ROOT_FCMPP | IR_F_NEQ,
   BASE_FCMPP_S_TRUE = ROOT_FCMPP | IR_F_TRUE,
   
   BASE_FCMPP_D_FALSE = ROOT_FCMPP | IR_DOUBLE | IR_FALSE ,
   BASE_FCMPP_D_EQ = ROOT_FCMPP | IR_DOUBLE | IR_EQ ,
   BASE_FCMPP_D_LT = ROOT_FCMPP | IR_DOUBLE | IR_LT,
   BASE_FCMPP_D_LEQ = ROOT_FCMPP | IR_DOUBLE | IR_LEQ,
   BASE_FCMPP_D_GT = ROOT_FCMPP | IR_DOUBLE | IR_GT ,
   BASE_FCMPP_D_GEQ = ROOT_FCMPP | IR_DOUBLE | IR_GEQ ,
   BASE_FCMPP_D_NEQ = ROOT_FCMPP | IR_DOUBLE | IR_NEQ,
   BASE_FCMPP_D_TRUE = ROOT_FCMPP | IR_DOUBLE | IR_TRUE

} ;

enum Opcode {

//
//	Standard INT Arithmetic
//

   NO_OP = ROOT_NO_OP,
   M_NO_OP = ROOT_NO_OP | IR_MULTI_CYCLE,
   ABS_W = ROOT_ABS,
   ADD_W = ROOT_ADD, 
   ADDL_W = ROOT_ADDL,
   AND_W = ROOT_AND,
   ANDCM_W = ROOT_ANDCM,
   DIV_W = ROOT_DIV,
   DIVL_W = ROOT_DIVL,
   MPY_W = ROOT_MPY,
   MPYL_W = ROOT_MPYL,
   NAND_W = ROOT_NAND,
   NOR_W = ROOT_NOR,
   OR_W = ROOT_OR,
   ORCM_W = ROOT_ORCM,
   REM_W = ROOT_REM,
   REML_W = ROOT_REML,
   SH1ADDL_W = ROOT_SH1ADDL,
   SH2ADDL_W = ROOT_SH2ADDL,
   SH3ADDL_W = ROOT_SH3ADDL,
   SHL_W = ROOT_SHL,
   SHR_W = ROOT_SHR,
   SHLA_W = ROOT_SHLA,
   SHRA_W = ROOT_SHRA,
   SUB_W = ROOT_SUB,
   SUBL_W = ROOT_SUBL,
   XOR_W = ROOT_XOR,
   XORCM_W = ROOT_XORCM,

   DIVFLOOR_W = ROOT_DIVFLOOR,
   DIVCEIL_W = ROOT_DIVCEIL,
   MIN_W = ROOT_MIN,
   MAX_W = ROOT_MAX,

//
//	Standard FP Arithmetic
//

   FADD_S = ROOT_FADD,
   FADD_D = ROOT_FADD | IR_DOUBLE,

   FABS_S = ROOT_FABS,
   FABS_D = ROOT_FABS | IR_DOUBLE,

   FDIV_S = ROOT_FDIV,
   FDIV_D = ROOT_FDIV | IR_DOUBLE,

   FMAX_S = ROOT_FMAX,
   FMAX_D = ROOT_FMAX | IR_DOUBLE,

   FMIN_S = ROOT_FMIN,
   FMIN_D = ROOT_FMIN | IR_DOUBLE,

   FMPY_S = ROOT_FMPY,
   FMPY_D = ROOT_FMPY | IR_DOUBLE,

   FMPYADD_S = ROOT_FMPYADD,
   FMPYADD_D = ROOT_FMPYADD | IR_DOUBLE,

   FMPYADDN_S = ROOT_FMPYADDN,
   FMPYADDN_D = ROOT_FMPYADDN | IR_DOUBLE,

   FMPYRSUB_S = ROOT_FMPYRSUB,
   FMPYRSUB_D = ROOT_FMPYRSUB | IR_DOUBLE,

   FMPYSUB_S = ROOT_FMPYSUB,
   FMPYSUB_D = ROOT_FMPYSUB | IR_DOUBLE,

   FRCP_S = ROOT_FRCP,
   FRCP_D = ROOT_FRCP | IR_DOUBLE,

   FSQRT_S = ROOT_FSQRT,
   FSQRT_D = ROOT_FSQRT | IR_DOUBLE,

   FSUB_S = ROOT_FSUB,
   FSUB_D = ROOT_FSUB | IR_DOUBLE,

//
//	Conversion operations
//

   CONVWS = ROOT_CONVWS,
   CONVWD = ROOT_CONVWD,
   CONVSW = ROOT_CONVSW,
   CONVDW = ROOT_CONVDW,
   CONVSD = ROOT_CONVSD,
   CONVDS = ROOT_CONVDS,

   EXTS_B = ROOT_EXTS | IR_BYTE,
   EXTS_H = ROOT_EXTS | IR_HALFWORD,

//
//	Move operations
//

   MOVE = ROOT_MOVE,

   MOVEGF_L = ROOT_MOVEGF_L,
   MOVEGF_U = ROOT_MOVEGF_U,
   MOVEF_S = ROOT_MOVEF,
   MOVEF_D = ROOT_MOVEF | IR_DOUBLE,
   MOVEFG_L = ROOT_MOVEFG_L,
   MOVEFG_U = ROOT_MOVEFG_U,
   MOVEPG = ROOT_MOVEPG,
   LDCM = ROOT_LDCM,


//
//      Long int literal synthesis operations
//

   MOVELG  = ROOT_MOVELG,
   MOVELGS = ROOT_MOVELGS,
   MOVELGX = ROOT_MOVELGX,

//
//      Long float literal synthesis operations
//

   MOVELF  = ROOT_MOVELF,
   MOVELFS = ROOT_MOVELFS,


//
//  Compare to register operations
//	Note: currently the list has not been fully populated with Unordered
//	comparisons because I got sick of typing all this crap out.. SAM 5-95
//

   CMPR_W_FALSE = ROOT_CMPR | IR_FALSE,
   CMPR_W_EQ = ROOT_CMPR | IR_EQ,
   CMPR_W_LT = ROOT_CMPR | IR_LT,
   CMPR_W_LEQ = ROOT_CMPR | IR_LEQ,
   CMPR_W_GT = ROOT_CMPR | IR_GT,
   CMPR_W_GEQ = ROOT_CMPR | IR_GEQ,
   CMPR_W_SV = ROOT_CMPR | IR_SV,
   CMPR_W_OD = ROOT_CMPR | IR_OD,
   CMPR_W_TRUE = ROOT_CMPR | IR_TRUE,
   CMPR_W_NEQ = ROOT_CMPR | IR_NEQ,
   CMPR_W_LLT = ROOT_CMPR | IR_LLT,   
   CMPR_W_LLEQ = ROOT_CMPR | IR_LLEQ,   
   CMPR_W_LGT = ROOT_CMPR | IR_LGT,      
   CMPR_W_LGEQ = ROOT_CMPR | IR_LGEQ,
   CMPR_W_NSV = ROOT_CMPR | IR_NSV,
   CMPR_W_EV = ROOT_CMPR | IR_EV,
   
   FCMPR_S_FALSE = ROOT_FCMPR | IR_F_FALSE,
   FCMPR_S_EQ = ROOT_FCMPR | IR_F_EQ,
   FCMPR_S_LT = ROOT_FCMPR | IR_F_LT,
   FCMPR_S_LEQ = ROOT_FCMPR | IR_F_LEQ,
   FCMPR_S_GT = ROOT_FCMPR | IR_F_GT,
   FCMPR_S_GEQ = ROOT_FCMPR | IR_F_GEQ,
   FCMPR_S_NEQ = ROOT_FCMPR | IR_F_NEQ,
   FCMPR_S_TRUE= ROOT_FCMPR | IR_F_TRUE,
   
   FCMPR_D_FALSE = ROOT_FCMPR | IR_DOUBLE | IR_F_FALSE,
   FCMPR_D_EQ = ROOT_FCMPR | IR_DOUBLE | IR_F_EQ,
   FCMPR_D_LT = ROOT_FCMPR | IR_DOUBLE | IR_F_LT,
   FCMPR_D_LEQ = ROOT_FCMPR | IR_DOUBLE | IR_F_LEQ,
   FCMPR_D_GT = ROOT_FCMPR | IR_DOUBLE | IR_F_GT,
   FCMPR_D_GEQ = ROOT_FCMPR | IR_DOUBLE | IR_F_GEQ,
   FCMPR_D_NEQ = ROOT_FCMPR | IR_DOUBLE | IR_F_NEQ,
   FCMPR_D_TRUE= ROOT_FCMPR | IR_DOUBLE | IR_F_TRUE,

////////////////////////////////////////////////////////////////////////////////////
//
// Playdoh's mongo set of compare to predicate operations
//  ==> moved to opcode_cmpp.h
//
////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////
//
// Playdoh's mongo set of memory system opcodes
//  ==> moved to opcode_load_store.h
//
////////////////////////////////////////////////////////////////////////////////////

//	Data verify loads to GPR
//

   LDV_B = ROOT_DVLD | IR_BYTE,
   LDV_H = ROOT_DVLD | IR_HALFWORD,
   LDV_W = ROOT_DVLD,

//
//	Data verify loads to FPR
//

   FLDV_S = ROOT_FDVLD,
   FLDV_D = ROOT_FDVLD | IR_DOUBLE,
  
////////////////////////////////////////////////////////////////////////////////////
//
// Playdoh branch opcodes
//
////////////////////////////////////////////////////////////////////////////////////

//
//	Data verify branches
//
 
   BRDVI = ROOT_BRDVI,
   BRDVF = ROOT_BRDVF,

//	Prepare to branch ops
//

   PBRR = ROOT_PBRR,
   PBRA = ROOT_PBRA,

//       Address literal synthesis to BTR
//

   MOVELB  = ROOT_MOVELB,
   MOVELBS = ROOT_MOVELBS,
   MOVELBX = ROOT_MOVELBX,

   PBRAL   = ROOT_PBRAL,
   PBRRL   = ROOT_PBRRL,

   PBRALBS = ROOT_PBRALBS,
   PBRRLBS = ROOT_PBRRLBS,

//
//
//	Standard branches
//

   BRU = ROOT_BRU,
   BRCT = ROOT_BRCT,
   BRCF = ROOT_BRCF,
   BRL = ROOT_BRL,
   BRLC = ROOT_BRLC,
   RTS = ROOT_RTS,
   BRDIR = ROOT_BRDIR | IR_PSEUDO,
   BRIND = ROOT_BRIND | IR_PSEUDO,

//
//	SWP branches
//

   BRF_B_B_F = ROOT_BRF | IR_LOOP_CONTINUE | IR_LOOP_RAMP,
   BRF_B_F_F = ROOT_BRF | IR_LOOP_CONTINUE,
   BRF_F_B_B = ROOT_BRF | IR_LOOP_RAMP | IR_LOOP_STOP,
   BRF_F_F_B = ROOT_BRF | IR_LOOP_STOP,
   BRF_F_F_F = ROOT_BRF,
   
   BRW_B_B_F = ROOT_BRW | IR_LOOP_CONTINUE | IR_LOOP_RAMP,
   BRW_B_F_F = ROOT_BRW | IR_LOOP_CONTINUE,
   BRW_F_B_B = ROOT_BRW | IR_LOOP_RAMP | IR_LOOP_STOP,
   BRW_F_F_B = ROOT_BRW | IR_LOOP_STOP,
   BRW_F_F_F = ROOT_BRW,

//
//      Move ops to support restricted IO formats
//

   MOVEGG = ROOT_MOVEGG,
   MOVEGC = ROOT_MOVEGC,
   MOVECG = ROOT_MOVECG,
   MOVEBB = ROOT_MOVEBB,

//
//	Ops to support Lcode/Elcor IRs
//

   PROLOGUE = ROOT_PROLOGUE | IR_PSEUDO,
   EPILOGUE = ROOT_EPILOGUE | IR_PSEUDO,
   DEFINE = ROOT_DEFINE | IR_PSEUDO,
   ALLOC = ROOT_ALLOC | IR_PSEUDO,
   SIM_DIR = ROOT_SIM_DIR | IR_PSEUDO,
   
   DUMMY_BR = ROOT_BRU | IR_PSEUDO,
   C_MERGE = ROOT_C_MERGE | IR_PSEUDO,
   D_SWITCH = ROOT_D_SWITCH | IR_PSEUDO,
   D_MERGE = ROOT_D_MERGE | IR_PSEUDO,
   
   USE = ROOT_USE | IR_PSEUDO,
   DEF = ROOT_DEF | IR_PSEUDO,

   REMAP = ROOT_REMAP | IR_PSEUDO,
   PRED_CLEAR = ROOT_PRED_CLEAR,
   PRED_CLEAR_ALL = ROOT_PRED_CLEAR_ALL | IR_ALL,
   PRED_CLEAR_ALL_STATIC = ROOT_PRED_CLEAR_ALL | IR_STATIC,
   PRED_CLEAR_ALL_ROTATING = ROOT_PRED_CLEAR_ALL | IR_ROTATING,
   PRED_SET = ROOT_PRED_SET,
   PRED_AND = ROOT_PRED_AND,
   PRED_COMPL = ROOT_PRED_COMPL,
   PRED_LOAD_ALL = ROOT_PRED_LOAD_ALL,
   PRED_STORE_ALL = ROOT_PRED_STORE_ALL,

   // New move operations used to save/restore and spill/unspill predicate 
   // registers -- VK/5/22/98
   MOVEGBP = ROOT_MOVEGBP,
   MOVEGCM = ROOT_MOVEGCM,

   LAST_OPCODE = 0xF000000
};

extern Hash_map<eString,Opcode> el_string_to_opcode_map;
extern Hash_map<Opcode,eString> el_opcode_to_string_map;

unsigned hash_opcode(Opcode& i) ; 
unsigned hash_IR_BASE_OPCODE(IR_BASE_OPCODE& i) ; 

extern void el_init_elcor_opcode_maps(void);

ostream& operator<<(ostream&,const Opcode) ;
ostream& operator<<(ostream&,const IR_BASE_OPCODE) ;
istream& operator>>(istream&,Opcode&) ;

extern Opcode opcode_or(Opcode& opc, Opcode& modifier);
   
#endif
