#define _MODULE_ "libdependence.a"
#pragma implementation "named_nli_merge.h"

#include <stdio.h>
#include <suif.h>
#include <suifmath.h>
#include "dependence.h"
#include <builder.h>


