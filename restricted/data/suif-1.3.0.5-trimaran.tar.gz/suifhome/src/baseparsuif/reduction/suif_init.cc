#include <suif.h>

extern void start_suif(int &argc, char *argv[])
  {
    init_suif(argc, argv);
  }
