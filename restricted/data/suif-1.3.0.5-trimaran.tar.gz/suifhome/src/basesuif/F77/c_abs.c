#include "sf2c.h"

double c_abs(z)
complex *z;
{
double f77_cabs();

return( f77_cabs( z->_r, z->_i ) );
}
