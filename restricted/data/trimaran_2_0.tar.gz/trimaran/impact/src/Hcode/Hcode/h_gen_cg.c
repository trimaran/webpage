/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.30  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 14, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_gen_cg.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>


/*===========================================================================*\
 *	The output file is input.cg
 *	For example, if the input file is X.ccode, the
 *	call graph file is X.ccode.cg
 *
 *	(global/static fn_name%s
 *		(id %d)
 *		(weight %f)
 *		(size %d)
 *		(sf_size %d)
 *		(cs call_site%d weight%f callee_name%s (callee_id%d weight%f)*)*
 *	)*
 *	(pset fn_name%s)*
 *	
 *	$$$PTR = callee_name for call thru pointer
 *
 *	The function size and frame size are estimates.
 *	The number may not correspond to the actual object
 *	code size; but should provide sufficient information
 *	to the inline analyzer, to avoid hazards (code explosion,
 *	control stack explosion).
\*===========================================================================*/

static int DcltrSize();

static FILE *F = NULL /*stderr*/;
static char fname[512];
static Punt(mesg)
char *mesg;
{
    fprintf(stderr, "Generate Call Graph: %s\n", mesg);
    exit(-1);
}

/*-------------------------------------------------------------------*/
/*
 *	Set up the output file.
 */
static int init = 0;
InitCallGraph() {
    if (init) return;
    init = 1;
    sprintf(fname, "%s.cg", F_output);
    F = fopen(fname, "w");
    if (F==0) Punt("InitCallGraph: cannot open .cg file");
}
/*-------------------------------------------------------------------*/
/*
 *	Estimate the size of the function.
 *	This is only a rough estimate. The leaf nodes are
 *	assumed to be absorbed in a higher level operation.
 *	This is true since most variable accesses can be
 *	register allocated. OP_expr_size and OP_type_size
 *	are compile-time generated constants and do not
 *	count as an operation. OP_common does not appear
 *	in the RTL at all. OP_cast are machine dependent.
 *	Since OP_cast (which will remain in RTL) operations
 *	are not that many, it is OK not to count them here
 *	(the casting introduces many explicit type casting
 *	operations than will appear in RTL).
 */
static int ExprSize(expr)
Expr expr;
{
    int size;
    Expr op;
    int i;
    if (expr==0) return 0;	/* this is actually illegal */
    switch (expr->opcode) {
    case OP_var:	/* assumed register allocated */
    case OP_enum:		case OP_signed:
    case OP_unsigned:		case OP_float:
    case OP_char:		case OP_string:
    /* BCC - added - 8/5/96 */
    case OP_double:
	size = 0; /* assume can be converted into constant literal field */
	break;
    case OP_cast: /* most cast operations are unnecessary */
    case OP_expr_size:
    case OP_type_size:
    case OP_comma:
	size = 0; 
	break;
    default :
	size = 1;
	break;
    }
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	size += ExprSize(op);	/* process the operands */
    }
    return size;
}
static int CodeSize(func)
FuncDcl func;
{
    int total = 0;
    Block bb;
    Expr expr;
    for (bb=func->blocks; bb!=0; bb=bb->next) {
	for (expr=bb->first; expr!=0; expr=expr->next) {
	    total += ExprSize(expr);
	}
    }
    return total;
}
/*-------------------------------------------------------------------*/
/*
 *	The data type sizes are machine dependent.
 *	Here, we will just assume some reasonable sizes.
 *	Since the only purpose is to prevent control stack
 *	explosion, we only need to be optimistic about the
 *	sizes.
 */
static int BasicTypeSize(type)
Type type;
{
    int t;
    if (type==0) Punt("BasicTypeSize: nil type");
    t = type->type;
    if (t & TY_STRUCT) {
 	StructDcl st;
	Field f;
	int size = 0;
	st = FindStruct(type->struct_name);
	if (st==0) Punt("BasicTypeSize: undefined structure");
	for (f=st->fields; f!=0; f=f->next) {
	    size += DcltrSize(f->type);
	}
	return size;
    } else
    if (t & TY_UNION) {
 	UnionDcl st;
	Field f;
	int size = 0;
	st = FindUnion(type->struct_name);
	if (st==0) Punt("BasicTypeSize: undefined structure");
	for (f=st->fields; f!=0; f=f->next) {
	    size += DcltrSize(f->type);
	}
	return size;
    } else
    if (t & (TY_DOUBLE|TY_FLOAT)) {
	return 8;
    } else
    if (t & (TY_SHORT|TY_INT|TY_LONG|TY_SIGNED|TY_UNSIGNED|TY_ENUM)) {
	return 4;
    } else
    if (t & TY_CHAR) {
	return 1;
    } else
    if (t & TY_VOID) {
	return 0;
    } else {
	return 4;	/* assume integer */
    }
}
/*
 *	Convert OP_type_size and OP_expr_size operators
 *	to estimate size of the specified type.
 */
static Expr ConvertTypeSize(expr)
Expr expr;
{
    int i;
    Expr new, op;
    if (expr==0) return 0;
    if (expr->opcode==OP_expr_size) {
	op = GetOperand(expr, 1);		/* 1st operand */
	new = NewIntExpr(DcltrSize(op->type));
	return new;
    } else
    if (expr->opcode==OP_type_size) {		/* type is in value.type */
	new = NewIntExpr(DcltrSize(expr->value.type));
	return new;
    } else {
	for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	    new = ConvertTypeSize(op);
	    if (op!=new)
	    	ChangeOperand(expr, i, new);
	}
	return expr;
    }
}
static int Expr2Int(expression)
Expr expression;
{
    Expr expr, reduce;
    extern Expr ReduceExpr();	/* reduce.c */
    int value;
    expr = CopyExpr(expression);
    /*
     *	Convert all OP_type_size and OP_expr_size nodes.
     */
    expr = ConvertTypeSize(expr);
    reduce = ReduceExpr(expr);
    RemoveExpr(expr);
    if (IsIntegralExpr(reduce)) {
	value = IntegralExprValue(reduce);
	RemoveExpr(reduce);
	return value;
    } else
	Punt("Expr2Int: expr cannot be reduced to an integer");
    return -1;
}
static int DcltrSize(type)
Type type;
{
    Dcltr dcltr;
    Expr index;
    int size;
    if (type==0) Punt("DcltrSize: nil type");
    dcltr = type->dcltr;
    if (dcltr==0)			/* BASIC data types */
	return BasicTypeSize(type);
    switch (dcltr->method) {
    case D_PTR :
	return 4;	/* assume a pointer takes 4 bytes */
    case D_FUNC :
	return 0;	/* it is only a forward declaration */
    case D_ARRY :
	index = dcltr->index;
	if (index==0) 	/* this is another way to write pointer */
	    return 4;
	type->dcltr = dcltr->next;
	size = DcltrSize(type);		/* compute the size of an element */
	type->dcltr = dcltr;
	/*
	 * Need to find out what the dimension is.
	 */
	return (size * Expr2Int(index));
    default :
	Punt("DcltrSize: illegal dcltr");
	return -1;
    }
}
/*
 *	Estimate the size of the stack frame (in bytes).
 */
static int VariableSize(var)
VarDcl var;
{
    Type type;
    if (var==0) return 0;		/* this should not happen */
    type = var->type;
    if (type->type & TY_EXTERN)		/* do not count TY_EXTERN */
	return 0;
    if (type->type & TY_STATIC)		/* do not count TY_STATIC */
	return 0;
    return DcltrSize(type);
}
static int StackFrameSize(func)
FuncDcl func;
{
    VarList ptr;
    int size = 0;
    for (ptr=func->param; ptr!=0; ptr=ptr->next) 
	size += VariableSize(ptr->var);
    for (ptr=func->local; ptr!=0; ptr=ptr->next)
	size += VariableSize(ptr->var);
    return (size+8);	/* pc + sp needs at least 8 bytes */
}
/*-------------------------------------------------------------------*/
/*
 *	Print call sites.
 */
static PrintCallSites(expr, cs, weight)
Expr expr;
ProfCS cs;
double weight;
{
    Expr op;
    int i, call_site;
    if (expr==0) return;
    if (expr->opcode==OP_call) {
	Pragma pragma;
	ProfCS ptr;
	char *fn_name;
	pragma = FindExprPragma(expr, "\"cs");
	if (pragma==0)
	    Punt("cs pragma is missing");
	i=sscanf(pragma->specifier, "\"cs.%d", &call_site);
	if (i!=1)
	    Punt("cs pragma is incorrect");
	op = GetOperand(expr, 1);	/* fn */
	if ((op->opcode==OP_var) && IsFunctionType(op->type)) {
	    fn_name = op->value.string;
	} else {
	    fn_name = "$$$PTR";	/* call thru pointer */
	}
	fprintf(F, "\t(cs %d %f %s", call_site, weight, fn_name);
	for (ptr=cs; ptr!=0; ptr=ptr->next) {
	    /*
	     *	Print calls which are profiled (monitored callee +
	     *	execute at least once).
	     */
	    if (ptr->call_site_id==call_site) {
		fprintf(F, " (%d %f)", ptr->callee_id, ptr->weight);
	    }
	}
	fprintf(F, ")\n");
    }
    for (i=1; (op=GetOperand(expr, i))!=0; i++) 
	PrintCallSites(op, cs, weight);
}
/*-------------------------------------------------------------------*/
/*
 *	Generate a call graph node.
 */
Gen_CallGraphNode(func)
FuncDcl func;
{
    Pragma pragma;
    Block bb;
    Expr expr;
    Type type;
    if (! init) {
	InitCallGraph();
    }
    pragma = FindFunctionPragma(func, "\"profiled");
    if (pragma==0) 
	Punt("-x control: function is not profiled");
    fprintf(F, "(");
    /*
     *	See if func is static/global.
     */
    type = func->type;
    if (type->type & TY_STATIC) {
	fprintf(F, "static %s\n", func->name);
    } else {
	fprintf(F, "global %s\n", func->name);
    }
    /*
     *	Print other statistics about the function.
     */
    fprintf(F, "\t(id %d) (weight %f) (size %d) (sf_size %d)\n",
	func->profile.fn_id, func->profile.weight,
	CodeSize(func), StackFrameSize(func));
    /*
     *	Print call sites.
     */
    for (bb=func->blocks; bb!=0; bb=bb->next) {
	for (expr=bb->first; expr!=0; expr=expr->next) {
	    PrintCallSites(expr, func->profile.calls, bb->profile.weight);
    	}
    }
    fprintf(F, ")\n");
    /*
     *	Find addition to Pset.
     */
    for (bb=func->blocks; bb!=0; bb=bb->next) {
	for (expr=bb->first; expr!=0; expr=expr->next) {
	    PrintPset(expr);
    	}
    }
}
/*-------------------------------------------------------------------*/
/*
 *	Print all possible functions which may be called thru pointer.
 *	We simply detect functions which are envolved in computations.
 *	(except the 1st argument to OP_call)
 */
PrintPset(expr)
Expr expr;
{
    Expr op;
    int i;
    static int tbl_id = -1;
    if (! init) {
	InitCallGraph();
    }
    if (tbl_id==-1) {
	tbl_id = NewSymTbl(MAX_FUNC_TBL_SIZE);
	if (tbl_id==-1)
	    Punt("PrintPset: cannot open a symbol table");
    }
    if (expr==0) return;
    if (expr->opcode==OP_var) {
	if (IsFunctionType(expr->type)) {
	    Symbol sym;
	    char *fn_name;
	    /*
	     *	For each file, we only need to print out the
	     *	name of a function once.
	     */
	    fn_name = expr->value.string;
	    sym = FindSym(tbl_id, fn_name, 0);
	    if (sym==0) {
		AddSym(tbl_id, fn_name, 0);
	    	fprintf(F, "(pset %s)\n", fn_name);
	    }
	}
    } else
    if (expr->opcode==OP_call) {
	op = GetOperand(expr, 1);
	/*
	 *	Except when used as the first operand of OP_call.
	 */
	if (! ((op->opcode==OP_var) && IsFunctionType(op->type)))
	    PrintPset(op);
    	for (i=2; (op=GetOperand(expr, i))!=0; i++) 
	    PrintPset(op);
    } else {
    	for (i=1; (op=GetOperand(expr, i))!=0; i++) 
	    PrintPset(op);
    }
}
/*-------------------------------------------------------------------*/
Stop_Gen_CallGraph() {
    fflush(F);
    fclose(F);
}
/*-------------------------------------------------------------------*/
