/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_profile.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>


extern FILE *SwitchFile(FILE *F);	/* list.c */

/*---------------------------------------------------------------------*/
/*
 *	The internal structure is hidden in this file.
 *	The interface for all profile module should be
 *	consistent.
 */
typedef struct _LnProfile {
	int		dest_bb;	/* destination bb id */
	double		weight;		/* transition weight */
	struct _LnProfile *next;
} _LnProfile, *LnProfile;

typedef struct _SwProfile {
	int		case_id;	/* switch case id */
	double		weight;		/* taken count */
	struct _SwProfile *next;
} _SwProfile, *SwProfile;

typedef struct _BbProfile {
	double		weight;		/* basic block weight */
	LnProfile	dest_arcs;	/* outgoing arcs */
	SwProfile	sw_cases;	/* switch cases */
} _BbProfile, *BbProfile;

typedef struct _CsProfile {
	int		callee_id;	/* callee */
	double		weight;		/* weight */
	struct _CsProfile *next;
} _CsProfile, *CsProfile;

typedef struct _FnProfile {
	int		fn_id;		/* function id */
	double		weight;		/* execution weight */
	int		max_bb_id;	/* maximum basic block id */
	int		max_cs_id;	/* maximum call site id */
	struct _FnProfile *next;
} _FnProfile, *FnProfile;

typedef struct _Profile {
	int		count;		/* profile count */
	FnProfile	active_fn;	/* the current function */
	FnProfile	fn_list;	/* all functions */
	int		bb_hash_tbl;	/* basic block hash table */
	int		cs_hash_tbl;	/* call site hash table */
} _Profile, *Profile;

/*
 *	In order to allow combining several profile databases,
 *	it is necessary to keep several logically independent
 *	profile data structure in this program.
 *	To simplify (and speed up) the internal computation,
 *	it is assumed that simple database operations are
 *	applied on the active profile database. The user
 *	can selectively activate a profile database.
 */
static _Profile active_profile = {0, 0, 0, -1, -1};
static _Profile backup_profile1 = {0, 0, 0, -1, -1};
static _Profile backup_profile2 = {0, 0, 0, -1, -1};
#define P0 active_profile
#define P1 backup_profile1
#define P2 backup_profile2

/*----------------------------------------------------------------*/
static Punt(mesg)
char *mesg;
{
    fprintf(stderr, ":error in PROFILE: %s\n", mesg);
    exit(-1);
}
char *pmalloc(size)
int size;
{
    char *new = (char *) malloc (size);
    if (new==0) Punt("out of memory");
    return new;
}
#define PALLOCATE(type) ((type *) pmalloc (sizeof(type)))
/*----------------------------------------------------------------*/
/*
 *	Add a new function if necessary.
 */
static FnProfile AddNewFunction(profile, fn_id)
Profile profile;
int fn_id;
{
    FnProfile fn, ptr;
    fn = profile->active_fn;
    if ((fn!=0) && (fn->fn_id==fn_id))
	return fn;
    for (fn=profile->fn_list; fn!=0; fn=fn->next)
	if (fn->fn_id==fn_id) {
	    profile->active_fn = fn;
	    return fn;
	}
    fn = PALLOCATE(_FnProfile);	/* create a new one */
    fn->fn_id = fn_id;
    fn->weight = 0;
    fn->max_bb_id = 0;
    fn->max_cs_id = 0;
    fn->next = 0;
    ptr = profile->fn_list;
    if (ptr==0) {
	profile->fn_list = fn;
    } else {
	while (ptr->next!=0) ptr = ptr->next;
	ptr->next = fn;
    }
    return fn;
}
/*
 *	Find a call site, if not found, return 0.
 *	if (callee_id==-1) return all links corresponding to the call site.
 */
static CsProfile FindCallSite(profile, caller_id, call_site, callee_id)
Profile profile;
int caller_id, call_site, callee_id;
{
    int index;
    Entry ent;
    CsProfile cs;
    if (call_site>=MAX_CALL_SITE_IN_FN)
	Punt("FindCallSite: internal error 1");
    index = (caller_id*MAX_CALL_SITE_IN_FN) + call_site;
    ent = FindEntry(profile->cs_hash_tbl, index, 0);
    if (ent==0) return 0;	/* call site is not defined */
    cs = (CsProfile) ent->ptr;	/* call list for the call site */
    if (callee_id==-1)		/* return the entire list */
	return cs;
    for (; cs!=0; cs=cs->next)	/* find the corresponding entry */
	if (cs->callee_id==callee_id)
	    return cs;
    return 0;			/* not found */
}
/*
 *	Create a new call site entry if not already exist.
 */
static CsProfile AddCallSite(profile, caller_id, call_site, callee_id)
Profile profile;
int caller_id, call_site, callee_id;
{
    int index;
    Entry ent;
    CsProfile cs, new;
    FnProfile fn;
    fn = AddNewFunction(profile, caller_id);	/* increment max_cs_id */
    if (fn->max_cs_id<call_site)
	fn->max_cs_id = call_site;
    if (call_site>=MAX_CALL_SITE_IN_FN)
	Punt("FindCallSite: internal error 1");
    index = (caller_id*MAX_CALL_SITE_IN_FN) + call_site;
    ent = FindEntry(profile->cs_hash_tbl, index, 0);
    if (ent==0) {	/* call site is not defined */
	ent = AddEntry(profile->cs_hash_tbl, index, 0);
	ent->ptr = 0;
    }
    cs = (CsProfile) ent->ptr;	/* call list for the call site */
    for (; cs!=0; cs=cs->next)	/* find the corresponding entry */
	if (cs->callee_id==callee_id)
	    return cs;		/* found */
    new = PALLOCATE(_CsProfile);	/* create a new entry */
    new->callee_id = callee_id;
    new->weight = 0.0;
    new->next = 0;
    cs = (CsProfile) ent->ptr;
    if (cs==0) {
    	ent->ptr = new;
    } else {
	while (cs->next!=0) cs=cs->next;
	cs->next = new;
    }
    return new;
}
/*
 *	Find a basic block. If not defined, return 0.
 */
static BbProfile FindBasicBlock(profile, fn_id, bb_id)
Profile profile;
int fn_id, bb_id;
{
    int index;
    Entry ent;
    if (bb_id>=MAX_BB_IN_FN)
	Punt("FindBasicBlock: internal error 1");
    index = (fn_id*MAX_BB_IN_FN) + bb_id;
    ent = FindEntry(profile->bb_hash_tbl, index, 0);
    if (ent==0) return 0;
    return ((BbProfile) ent->ptr);
}
/*
 *	Create a new basic block definition if necessary.
 */
static BbProfile AddBasicBlock(profile, fn_id, bb_id)
Profile profile;
int fn_id, bb_id;
{
    int index;
    Entry ent;
    BbProfile new;
    FnProfile fn;
    fn = AddNewFunction(profile, fn_id);	/* increment max_bb_id */
    if (fn->max_bb_id<bb_id)
	fn->max_bb_id = bb_id;
    if (bb_id>=MAX_BB_IN_FN)
	Punt("FindBasicBlock: internal error 1");
    index = (fn_id*MAX_BB_IN_FN) + bb_id;
    ent = FindEntry(profile->bb_hash_tbl, index, 0);
    if (ent!=0)	/* if already exist, return as it is */
    	return ((BbProfile) ent->ptr);
    new = PALLOCATE(_BbProfile);	/* otherwise, create a new entry */
    new->weight = 0.0;		/* initialize it */
    new->dest_arcs = 0;
    new->sw_cases = 0;
    ent = AddEntry(profile->bb_hash_tbl, index, 0);
    ent->ptr = new;
    return new;
}
/*----------------------------------------------------------------*/
/*
 *	Operate on the active profile database.
 */
/*
 *	Initialize the active profile database.
 */
_InitProfileDatabase() {
    P0.count = 0;
    P0.active_fn = 0;
    P0.fn_list = 0;
    P0.bb_hash_tbl = NewHashTbl(MAX_BB);
    if (P0.bb_hash_tbl==-1)
	Punt("_InitProfileDatabase: out of memory");
    P0.cs_hash_tbl = NewHashTbl(MAX_CS);
    if (P0.cs_hash_tbl==-1)
	Punt("_InitProfileDatabase: out of memory");
}
/*
 *	Increment the profile count by n.
 */
_IncrementProfileRun(n)
int n;
{
    P0.count += n;
}
_AddCall(caller_id, call_site_id, callee_id, weight)
int caller_id, call_site_id, callee_id;
double weight;
{
    CsProfile cs;
    cs = AddCallSite(&P0, caller_id, call_site_id, callee_id);
    cs->weight += weight;
}
/*
 *	last_bb==0 is the special case, when new_bb is
 *	the ENTRY block of the function.
 */
_AddMove(fn_id, last_bb, new_bb, weight)
int fn_id, last_bb, new_bb;
double weight;
{
    BbProfile bb;
    LnProfile arc, ptr;
    bb = AddBasicBlock(&P0, fn_id, last_bb);  /* find the block */
    if (last_bb==0) {	/* special case */
    	FnProfile fn;
    	fn = AddNewFunction(&P0, fn_id);
    	bb->weight += weight;
	fn->weight += weight;
    }
    if (new_bb<=0)
	Punt("PROFILE: basic block id must be greater than 0");
    for (arc=bb->dest_arcs; arc!=0; arc=arc->next)	/* find arc */
	if (arc->dest_bb==new_bb)
	    break;
    if (arc==0) {	/* if not found, create a new arc */
	arc = PALLOCATE(_LnProfile);
	arc->dest_bb = new_bb;
	arc->weight = 0.0;
	arc->next = 0;
	ptr = bb->dest_arcs;
	if (ptr==0) {		/* preserve the order */
	    bb->dest_arcs = arc;
	} else {
	    while (ptr->next!=0) ptr=ptr->next;
	    ptr->next = arc;
	}
    }
    arc->weight += weight;	/* increment arc weight */
    bb = AddBasicBlock(&P0, fn_id, new_bb);	/* go to the new_bb */
    bb->weight += weight;	/* increment basic block weight */
}
_AddSwitch(fn_id, bb_id, case_id, weight)
int fn_id, bb_id, case_id;
double weight;
{
    BbProfile bb;
    SwProfile cas, ptr;
    bb = AddBasicBlock(&P0, fn_id, bb_id);	/* find the block */
    for (cas=bb->sw_cases; cas!=0; cas=cas->next)	/* find case */
	if (cas->case_id==case_id)
	    break;
    if (cas==0) {	/* if not found, create a new case */
	cas = PALLOCATE(_SwProfile);
	cas->case_id = case_id;
	cas->weight = 0.0;
	cas->next = 0;
	ptr = bb->sw_cases;
	if (ptr==0) {		/* preserve the order */
	    bb->sw_cases = cas;
	} else {
	    while (ptr->next!=0) ptr=ptr->next;
	    ptr->next = cas;
	}
    }
    cas->weight += weight;	/* increment weight */
}
/*----------------------------------------------------------------*/
_SetCall(caller_id, call_site_id, callee_id, weight)
int caller_id, call_site_id, callee_id;
double weight;
{
    CsProfile cs;
    cs = AddCallSite(&P0, caller_id, call_site_id, callee_id);
    cs->weight = weight;
}
_SetArc(fn_id, last_bb, new_bb, weight)
int fn_id, last_bb, new_bb;
double weight;
{
    BbProfile bb;
    LnProfile arc, ptr;
    bb = AddBasicBlock(&P0, fn_id, last_bb);  /* find the block */
    if (new_bb<=0)
	Punt("PROFILE: basic block id must be greater than 0");
    for (arc=bb->dest_arcs; arc!=0; arc=arc->next)	/* find arc */
	if (arc->dest_bb==new_bb)
	    break;
    if (arc==0) {	/* if not found, create a new arc */
	arc = PALLOCATE(_LnProfile);
	arc->dest_bb = new_bb;
	arc->weight = 0.0;
	arc->next = 0;
	ptr = bb->dest_arcs;
	if (ptr==0) {		/* preserve the order */
	    bb->dest_arcs = arc;
	} else {
	    while (ptr->next!=0) ptr=ptr->next;
	    ptr->next = arc;
	}
    }
    arc->weight = weight;	/* set arc weight */
}
/*
 *	bb_id==0 is the special case, also set the function weight.
 */
_SetNode(fn_id, bb_id, weight)
int fn_id, bb_id;
double weight;
{
    BbProfile bb;
    bb = AddBasicBlock(&P0, fn_id, bb_id);	/* find the block */
    if (bb_id==0) {	/* special case */
    	FnProfile fn;
    	fn = AddNewFunction(&P0, fn_id);
	fn->weight = weight;
    }
    bb->weight = weight;	/* set basic block weight */
}
_SetSwitch(fn_id, bb_id, case_id, weight)
int fn_id, bb_id, case_id;
double weight;
{
    BbProfile bb;
    SwProfile cas, ptr;
    bb = AddBasicBlock(&P0, fn_id, bb_id);	/* find the block */
    for (cas=bb->sw_cases; cas!=0; cas=cas->next)	/* find case */
	if (cas->case_id==case_id)
	    break;
    if (cas==0) {	/* if not found, create a new case */
	cas = PALLOCATE(_SwProfile);
	cas->case_id = case_id;
	cas->weight = 0.0;
	cas->next = 0;
	ptr = bb->sw_cases;
	if (ptr==0) {		/* preserve the order */
	    bb->sw_cases = cas;
	} else {
	    while (ptr->next!=0) ptr=ptr->next;
	    ptr->next = cas;
	}
    }
    cas->weight = weight;	/* set weight */
}
/*----------------------------------------------------------------*/
/*
 *	Query operations.
 */
int _ProfileCount() {
    return (P0.count);
}
double _FunctionWeight(fn_id)
int fn_id;
{
    FnProfile fn;
    fn = AddNewFunction(&P0, fn_id);
    return (fn->weight);
}
double _NodeWeight(fn_id, bb_id)
int fn_id, bb_id;
{
    BbProfile bb;
    bb = FindBasicBlock(&P0, fn_id, bb_id);
    if (bb==0) return 0.0;
    return (bb->weight);
}
double _ArcWeight(fn_id, src_bb, dst_bb)
int fn_id, src_bb, dst_bb;
{
    BbProfile bb;
    LnProfile arc;
    bb = FindBasicBlock(&P0, fn_id, src_bb);
    if (bb==0) return 0.0;
    for (arc=bb->dest_arcs; arc!=0; arc=arc->next)
	if (arc->dest_bb==dst_bb)
	    return (arc->weight);
    return 0.0;
}
double _CaseWeight(fn_id, bb_id, case_id)
int fn_id, bb_id, case_id;
{
    BbProfile bb;
    SwProfile ptr;
    bb = FindBasicBlock(&P0, fn_id, bb_id);
    if (bb==0) return 0.0;
    for (ptr=bb->sw_cases; ptr!=0; ptr=ptr->next)
	if (ptr->case_id==case_id)
	    return (ptr->weight);
    return 0.0;
}
/*
 *	Fill up to N (fn, call_site, callee) entries in buffers.
 *	If there are less than N entries, unfilled entries will
 *	be set to 0. This function returns the total number of
 *	callees invoked by the call_site. This provides a way for usr
 *	to check if the buffers (size=N) are large enough to
 *	contain all entries.
 */
int _CallSiteWeight(fn_id, N, site_buf, callee_buf, weight_buf)
int fn_id, N;
int site_buf[], callee_buf[];
double weight_buf[];
{
    FnProfile fn;
    CsProfile cs;
    int i, call_site;
    for (i=0; i<N; i++) {
	site_buf[i] = 0;
	callee_buf[i] = 0;
 	weight_buf[i] = 0.0;
    }
    fn = AddNewFunction(&P0, fn_id);
    i = 0;
    for (call_site=0; call_site<=fn->max_cs_id; call_site++) {
    	cs = FindCallSite(&P0, fn_id, call_site, -1);
	if (cs==0)
	    continue;
    	for (; cs!=0; cs=cs->next) {
	    if (cs->weight==0.0)  /* should not happen, but check anyway */
	    	continue;
	    if (i<N) {
		site_buf[i] = call_site;
	    	callee_buf[i] = cs->callee_id;
	   	weight_buf[i] = cs->weight;
	   }
	   i++;
    	}
    }
    return i;
}
/*----------------------------------------------------------------*/
/*
 *	File accesses.
 */
_ReadProfileFile(file_name)
char *file_name;
{
    LIST list;
    FILE *F, *old_F;
    F = fopen(file_name, "r");
    if (F==0) Punt("_ReadProfileFile: cannot open input file");
    old_F = SwitchFile(F);	/* list.c */
    while ((list=GetNode()) != 0) {
	LIST opcode, arg;
	char *op;
	if (NodeType(list)==T_EOF) break;
 	if (NodeType(list)!=T_LIST) continue;
	opcode = ChildOf(list);
	if ((opcode==0) || (NodeType(opcode)!=T_ID)) {
	    Punt("_ReadProfileFile: illegal format");
	}
	arg = SiblingOf(opcode);
	op = StringOf(opcode);
	if (! strcmp(op, "count")) {
	    if ((arg==0) || (NodeType(arg)!=T_INT))
		Punt("_ReadProfileFile: illegal (count) specifier");
	    P0.count = IntegerOf(arg);
	} else
 	if (! strcmp(op, "fn")) {
	    int fn_id;
	    double fn_weight;
	    FnProfile fn;
	    if ((arg==0) || (NodeType(arg)!=T_INT))
		Punt("_ReadProfileFile: illegal (fn) specifier (1)");
	    fn_id = IntegerOf(arg);
	    arg = SiblingOf(arg);
	    if ((arg==0) || (NodeType(arg)!=T_REAL))
		Punt("_ReadProfileFile: illegal (fn) specifier (2)");
	    fn_weight = RealOf(arg);
	    fn = AddNewFunction(&P0, fn_id);
	    fn->weight = fn_weight;
	    arg = SiblingOf(arg);
	    for (; arg!=0; arg=SiblingOf(arg)) {
		LIST cmd, option;
		char *cmd_name;
		if (NodeType(arg)!=T_LIST) continue;
		cmd = ChildOf(arg);
		if ((cmd==0) || (NodeType(cmd)!=T_ID))
		    Punt("_ReadProfileFile: illegal (fn) specifier (3)");
		cmd_name = StringOf(cmd);
	  	option = SiblingOf(cmd);
		if (! strcmp(cmd_name, "bb")) {
		    int bb_id;
		    double bb_weight;
		    BbProfile bb;
		    if ((option==0) || (NodeType(option)!=T_INT))
			Punt("_ReadProfileFile: illegal (bb) descriptor (1)");
		    bb_id = IntegerOf(option);
		    option = SiblingOf(option);
		    if ((option==0) || (NodeType(option)!=T_REAL))
			Punt("_ReadProfileFile: illegal (bb) descriptor (2)");
		    bb_weight = RealOf(option);
		    option = SiblingOf(option);
		    bb = AddBasicBlock(&P0, fn_id, bb_id);
		    bb->weight = bb_weight;
		    for (; option!=0; option= SiblingOf(option)) {
			LIST dest, arc_weight;
			int dest_id;
			LnProfile arc;
			if (NodeType(option)!=T_LIST) continue;
			dest = ChildOf(option);
			if ((dest==0) || (NodeType(dest)!=T_INT))
			    Punt("_ReadProfile: illegal (bb) connection");
			dest_id = IntegerOf(dest);
		  	arc_weight = SiblingOf(dest);
			if ((arc_weight==0) || (NodeType(arc_weight)!=T_REAL))
			    Punt("_ReadProfile: illegal (bb) connection");
			/* find the arc */
			for (arc=bb->dest_arcs; arc!=0; arc=arc->next)
			    if (dest_id==arc->dest_bb)
				break;
			if (arc==0) {	/* not found, create one */
			    LnProfile ptr;
			    arc = PALLOCATE(_LnProfile);
			    arc->dest_bb = dest_id;
			    arc->weight = 0.0;
			    arc->next = 0;
			    ptr = bb->dest_arcs;
			    if (ptr==0) {
				bb->dest_arcs = arc;
			    } else {
				while (ptr->next!=0) ptr=ptr->next;
				ptr->next = arc;
			    }
			}
			arc->weight = RealOf(arc_weight);
		    }
		} else
		if (! strcmp(cmd_name, "sw")) {
		    int bb_id;
		    if ((option==0) || (NodeType(option)!=T_INT))
			Punt("_ReadProfile: illegal (sw) descriptor (1)");
		    bb_id = IntegerOf(option);
		    option = SiblingOf(option);
		    for (; option!=0; option=SiblingOf(option)) {
			LIST case_id, case_weight;
			if (NodeType(option)!=T_LIST) continue;
			case_id = ChildOf(option);
			if ((case_id==0) || (NodeType(case_id)!=T_INT))
			    Punt("_ReadProfile: illegal (sw) descriptor 2");
			case_weight = SiblingOf(case_id);
			if ((case_weight==0) || (NodeType(case_weight)!=T_REAL))
			    Punt("_ReadProfile: illegal (sw) descriptor 3");
			_SetSwitch(fn_id, bb_id, IntegerOf(case_id),
				RealOf(case_weight));
		    }
		} else
		if (! strcmp(cmd_name, "cg")) {
		    int call_site;
		    CsProfile cs;
		    if ((option==0) || (NodeType(option)!=T_INT))
			Punt("_ReadProfile: illegal (cg) descriptor 1");
		    call_site = IntegerOf(option);
		    option = SiblingOf(option);
		    for (; option!=0; option=SiblingOf(option)) {
		 	LIST callee, weight;
			if (NodeType(option)!=T_LIST) continue;
			callee = ChildOf(option);
			if ((callee==0) || (NodeType(callee)!=T_INT))
			    Punt("_ReadProfile: illegal (cg) descriptor 2");
			weight = SiblingOf(callee);
			if ((weight==0) || (NodeType(weight)!=T_REAL))
			    Punt("_ReadProfile: illegal (cg) descriptor 3");
			cs = AddCallSite(&P0, fn_id, call_site,
				IntegerOf(callee));
			cs->weight = RealOf(weight);
		    }
		} else
		    Punt("_ReadProfileFile: unknown (fn) descriptor");
	    }
	}
    }
    if (P0.count==0)	/* after reading */
	Punt("_ReadProfileFile: profile count cannot be zero");
    SwitchFile(old_F);      /* list.c */

}
/*----------------------------------------------------------------*/
_WriteProfileFile(file_name)
char *file_name;
{
    register FILE *F;
    register FnProfile fn;
    register int i, fn_id;
    F = fopen(file_name, "w");
    if (F==0) Punt("_WriteProfileFile: cannot open output file");
    if (P0.count==0)
	Punt("_WriteProfileFile: profile count cannot be zero");
    fprintf(F, "(count %d)\n", P0.count);
    for (fn=P0.fn_list; fn!=0; fn=fn->next) {
	fn_id = fn->fn_id;
	fprintf(F, "(fn %d %e\n", fn_id, fn->weight);
	for (i=0; i<=fn->max_bb_id; i++) {
    	    BbProfile bb;
    	    LnProfile arcs;
    	    SwProfile cases;
	    bb = FindBasicBlock(&P0, fn_id, i);
	    if (bb==0) continue;		/* (bb) */
	    fprintf(F, "\t(bb %d %e", i, bb->weight);
	    for (arcs=bb->dest_arcs; arcs!=0; arcs=arcs->next) {
	 	fprintf(F, " (%d %e)", arcs->dest_bb, arcs->weight);
	    }
	    fprintf(F, ")\n");
	    cases = bb->sw_cases;
	    if (cases==0) continue;		/* (sw) */
	    fprintf(F, "\t(sw %d", i);
	    for (; cases!=0; cases=cases->next) {
		fprintf(F, " (%d %e)", cases->case_id, cases->weight);
	    }
	    fprintf(F, ")\n");
	}
	for (i=0; i<=fn->max_cs_id; i++) {	/* (cg)* */
    	    CsProfile cs;
	    cs = FindCallSite(&P0, fn_id, i, -1);	/* find all */
	    if (cs==0) continue;
	    fprintf(F, "\t(cg %d", i);
	    for (; cs!=0; cs=cs->next) {
		fprintf(F, " (%d %e)", cs->callee_id, cs->weight);
	    }
	    fprintf(F, ")\n");
	}
	fprintf(F, ")\n");
	fflush(F);
    }
}
/*----------------------------------------------------------------*/
/*
 *	Move P1 to P2
 *	Move P0 to P1
 *	Create a new P0.
 */
static PushProfile() {
    int bb_hash_tbl = P2.bb_hash_tbl;
    int cs_hash_tbl = P2.cs_hash_tbl;
    P2.count = P1.count;
    P2.active_fn = P1.active_fn;
    P2.fn_list = P1.fn_list;
    P2.bb_hash_tbl = P1.bb_hash_tbl;
    P2.cs_hash_tbl = P1.cs_hash_tbl;
    P1.count = P0.count;
    P1.active_fn = P0.active_fn;
    P1.fn_list = P0.fn_list;
    P1.bb_hash_tbl = P0.bb_hash_tbl;
    P1.cs_hash_tbl = P0.cs_hash_tbl;
    P0.count = 0;
    P0.active_fn = 0;
    P0.fn_list = 0;
    if (bb_hash_tbl==-1) {
	P0.bb_hash_tbl = NewHashTbl(MAX_BB);
    	if (P0.bb_hash_tbl==-1)
	    Punt("_InitProfileDatabase: out of memory");
    } else {	/* recycle */
    	P0.bb_hash_tbl = bb_hash_tbl;
	ClearHashTbl(bb_hash_tbl);
    }
    if (cs_hash_tbl==-1) {
	P0.cs_hash_tbl = NewHashTbl(MAX_CS);
    	if (P0.cs_hash_tbl==-1)
	    Punt("_InitProfileDatabase: out of memory");
    } else {	/* recycle */
    	P0.cs_hash_tbl = cs_hash_tbl;
	ClearHashTbl(cs_hash_tbl);
    }
}
/*
 *	P0.weight += (profile->weight * ratio)
 */
static ScaleProfile(profile, ratio)
Profile profile;
double ratio;
{
    register FnProfile fn0, fn1;
    register int i, fn_id;
    for (fn1=profile->fn_list; fn1!=0;  fn1=fn1->next) {
	fn_id = fn1->fn_id;
	fn0 = AddNewFunction(&P0, fn_id);
	fn0->weight += (fn1->weight * ratio);	/* fn weight */
	for (i=0; i<=fn1->max_bb_id; i++) {	/* bb */
	    BbProfile bb0, bb1;
	    LnProfile arc0, arc1;
	    SwProfile case0, case1;
	    bb1 = FindBasicBlock(profile, fn_id, i);
	    if (bb1==0)
		continue;
	    bb0 = AddBasicBlock(&P0, fn_id, i);
	    bb0->weight += (bb1->weight * ratio);	/* bb weight */
	    for (arc1=bb1->dest_arcs; arc1!=0; arc1=arc1->next) {
		/* try to find the corresponding arc0 */
	   	arc0 = bb0->dest_arcs;
	 	while ((arc0!=0) && (arc0->dest_bb!=arc1->dest_bb))
		    arc0 = arc0->next;
		if (arc0==0) {		/* create a new arc */
		    LnProfile ptr;
		    ptr = bb0->dest_arcs;
		    arc0 = PALLOCATE(_LnProfile);
		    arc0->dest_bb = arc1->dest_bb;
		    arc0->weight = 0.0;
		    arc0->next = 0;
		    if (ptr==0) {
			bb0->dest_arcs = arc0;
		    } else {
			while (ptr->next!=0) ptr=ptr->next;
			ptr->next = arc0;
		    }
		}
		arc0->weight += (arc1->weight * ratio);	/* arc weight */
	    }
	    case1 = bb1->sw_cases;
	    if (case1==0)
		continue;
	    for (; case1!=0; case1=case1->next) {
		/* try to find the corresponding case0 */
		for (case0=bb0->sw_cases; case0!=0; case0=case0->next)
		    if (case0->case_id==case1->case_id)
			break;
		if (case0==0) {	/* need to create a new entry */
		    SwProfile ptr;
		    case0 = PALLOCATE(_SwProfile);
		    case0->case_id = case1->case_id;
		    case0->weight = 0.0;
		    case0->next = 0;
		    ptr = bb0->sw_cases;
		    if (ptr==0) {
			bb0->sw_cases = case0;
		    } else {
			while (ptr->next!=0) ptr=ptr->next;
			ptr->next = case0;
		    }
		}
		case0->weight += (case1->weight * ratio);  /* case weight */
	    }
	}
	for (i=0; i<=fn1->max_cs_id; i++) { /* cg */
	    CsProfile cs0, cs1;
	    cs1 = FindCallSite(profile, fn_id, i, -1);	/* all */
	    for (; cs1!=0; cs1=cs1->next) {
		cs0 = AddCallSite(&P0, fn_id, i, cs1->callee_id);
		cs0->weight += (cs1->weight * ratio);	/* call weight */
	    }
	}
    }
}
/*
 *	Merge two profile databases together.
 */
_CombineProfile(fin1, fin2, fout)
char *fin1, *fin2, *fout;
{
    double p1_ratio, p2_ratio;
    _ReadProfileFile(fin1);
    PushProfile();
    _ReadProfileFile(fin2);
    PushProfile();
    p1_ratio = ((double) P1.count) / ((double) (P1.count + P2.count));
    p2_ratio = 1 - p1_ratio;
    ScaleProfile(&P1, p1_ratio);
    ScaleProfile(&P2, p2_ratio);
    P0.count = P1.count + P2.count;
    _WriteProfileFile(fout);
}
/*----------------------------------------------------------------*/

