/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   h_main.c
 *      Author: Pohua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>


extern void H_process_hcode();


/*
 *	Enviroment debugging info
 */
static void print_enviroment_info()
{
    fprintf(Ferr, ".. [%s]\n", H_curr_pass_name);
    fprintf(Ferr, ".. verbose mode is ON\n");
    if (H_debug_yes) fprintf(Ferr, ".. debug mode is ON\n");
    else fprintf(Ferr, ".. debug mode is OFF\n");
    fprintf(Ferr, ".. input is from %s\n", F_input);
    fprintf(Ferr, ".. output is to %s\n", F_output);
    fprintf(Ferr, ".. message is to %s\n", F_error);
    if (H_do_flatten) fprintf(Ferr, ".. remove && || and ?:\n");
    else fprintf(Ferr, ".. leave && || and ?: alone\n");
    if (H_do_insert_profile_probes)
        fprintf(Ferr, ".. add profile probe (%d)\n",
                H_profile_starting_fn_id);
    if (H_do_merge_profile)
        fprintf(Ferr, ".. get profile information form %s\n",
                H_profile_database_file);
    switch (H_output_form) {
    case OUTPUT_NONE:
        fprintf(Ferr, ".. no output\n");
        break;
    case OUTPUT_C:
        fprintf(Ferr, ".. output in C\n");
        break;
    case OUTPUT_CCODE:
        fprintf(Ferr, ".. output in CCODE\n");
        break;
    case OUTPUT_RTL:
        H_punt("print_enviroment_info: illegal output format");
        break;
    default:
        H_punt("print_enviroment_info: illegal output format");
    }
    if (H_ext_option&EXT_CNT_FLOW)
        fprintf(Ferr, ".. extract control flow\n");
    if (H_ext_option&EXT_DATA_FLOW)
        fprintf(Ferr, ".. extract data flow\n");
    if (H_do_trace_selection)
        fprintf(Ferr, ".. apply trace selection (degree %d)\n",
                H_trace_selection_method);
    if (H_do_constant_folding)
        fprintf(Ferr, ".. apply constant folding\n");
    fprintf (Ferr, ".. target is %s architecture, model %s\n",
        H_arch, H_model);
    switch (H_dat_format) {
    case DAT_LITTLE_ENDIAN:
        fprintf(Ferr, ".. little indian\n");
        break;
    case DAT_BIG_ENDIAN:
        fprintf(Ferr, ".. big indian\n");
        break;
    default:
        fprintf(Ferr, ".. ??? indian\n");
        break;
    }
}

/*==============================================================================*/
/*
 *	HCODE main routine!
 */
/*==============================================================================*/

int main(int argc, char **argv, char **envp)
{
    C_Arg arg[C_MAX_ARG];
    char *H_parm_file;
    Parm_Macro_List *external_list;
    int n_arg, i, j, read_i, read_o;


    /*
     * Initialize these string defaults using strdup since
     * they are run-time configurable and may be malloced/freed
     * (They are no longer freed, statics may be used.)
     */
    H_arch = "impact";
    H_model = "v1.0";
    F_input = "stdin";
    F_output = "stdout";
    F_error = "stderr";
    Fin = stdin;
    Fout = stdout;
    Ferr = stderr;

    /* save the current Hcode pass name for error messages */
    H_curr_pass_name = argv[0];

    /*
     * Get macro definitions from command line and environment.
     * This is the updated version of command_line_macro_list,
     * any it may be used in the same way.
     */
    external_list = L_create_external_macro_list (argv, envp);

    /*
     * Get H_parm_file from command line (-p path), or environment
     * variable "STD_PARMS_FILE", or default to "./STD_PARMS"
     */
    H_parm_file = L_get_std_parm_name(argv, envp, "STD_PARMS_FILE",
                                          "./STD_PARMS");

    /* Read Hcode parms first to get dump_parm parameters set properly 
     * JCG 7/12/95
     */
    L_load_parameters(H_parm_file, external_list, 
                          "(Hcode", H_read_parm_Hcode);
    /* Renamed 'architecture' to 'Larchitecture' -JCG 5/26/98 */
    L_load_parameters_aliased(H_parm_file, external_list, 
                          "(Larchitecture", "(architecture", H_read_parm_arch);
    /* Renamed 'file' to 'Lfile' -JCG 5/26/98 */
    L_load_parameters_aliased(H_parm_file, external_list, 
			  "(Lfile", "(file", H_read_parm_file);

    
    /*
     * If the first argument does not contain an -, it is
     * ignored by Lcode.  Punt if this is the case.
     */
    if ((argv[1] != NULL) && (argv[1][0] != '-'))
    {
        H_punt ("main: Unknown command line option '%s'.", argv[1]);
    }

    /* Mark that we have not read the input or output file yet */
    read_i = 0;
    read_o = 0;

    /* Process the rest of the command line arguments */
    n_arg = C_get_arg(argc-1, argv+1, arg, C_MAX_ARG);
    for (i=0; i < n_arg; i++)
    {
        char *option;
        option = arg[i].option;

        /* Get input file name */
        if (! strcmp(option, "-i"))
        {
            /* Punt if input file specified twice */
            if (read_i)
                H_punt ("Parsing command line: -i specified twice.\n");

            /* Make sure file name specified */
            if (arg[i].count < 1)
                H_punt("Parsing command line: -i needs input_file_name.");
            /* Make sure that only one file name specified */
            if (arg[i].count > 1)
            {
                fprintf (stderr, "Error parsing command line: -i");
                for (j = 0; j < arg[i].count; j++)
                    fprintf (stderr, " %s", arg[i].spec[j]);
                fprintf (stderr, "\n");
                H_punt ("Cannot specify more than one input file with -i.");
            }

            F_input = C_findstr(arg[i].spec[0]);

            /* Mark that we have read an input file name */
            read_i = 1;
        }

        /* Get output file name */
        else if (! strcmp(option, "-o"))
        {
            /* Punt if output file specified twice */
            if (read_o)
                H_punt ("Parsing command line: -o specified twice.\n");

            /* Make sure file name specified */
            if (arg[i].count < 1)
                H_punt("Parsing command line: -o needs output_file_name.");
            /* Make sure only one file name specified */
            if (arg[i].count > 1)
            {
                fprintf (stderr, "Parsing command line: -o");
                for (j = 0; j < arg[i].count; j++)
                    fprintf (stderr, " %s", arg[i].spec[j]);
                fprintf (stderr, "\n");
                H_punt ("Cannot specify more than one output file with -o.");
            }

            F_output = C_findstr(arg[i].spec[0]);

            /* Mark that we have read an output file */
            read_o = 1;
        }

        /* Ignore -p */
        else if (strcmp (option, "-p") == 0)
            ;

        /* Ignore -P, -F  (and for now -D), accept to make sure there
         * are no argument after it.
         */
        else if ((option[0] == '-') &&
                 ((option[1] == 'P') || (option[1] == 'D') ||
                  (option[1] == 'F')))
        {
            /* Make sure there is nothing after the -Pmacro_name=val */
            if (arg[i].count > 0)
            {
                H_punt ("Unknown command line option '%s'.",
                        arg[i].spec[0]);
            }

        }

        /* Otherwise, punt, unknown commmand line arguments */
        else
        {
            /* Print out what we are punting on */
            fprintf (stderr, "Error parsing command line: %s", option);
            for (j = 0; j < arg[i].count; j++)
                fprintf (stderr, " %s", arg[i].spec[j]);
            fprintf (stderr, "\n");

            H_punt ("Unknown command line option.");
        }
    }


    /* renice the Hcode process, arent we such a nice person */
#ifndef __WIN32__
/* ADA 5/29/96: Win95/NT has diffenent way to change priority but IMPACT
   		module running on Win95/NT doesn't really care about it */
    setpriority(PRIO_PROCESS, 0, H_nice_value);
#endif

    /* open input/output/error files */
    if (strcmp(F_input, "stdin")) {
        Fin = fopen(F_input, "r");
        if (Fin==NULL) H_punt("cannot open input file");
    }
    if (strcmp(F_output, "stdout")) {
        Fout = fopen(F_output, "w");
        if (Fout==NULL) H_punt("cannot open output file");
    }
    if (strcmp(F_error, "stderr")) {
        Ferr = fopen(F_error, "w");
        if (Ferr==NULL) H_punt("cannot open log file");
    }

    /*
     *	Set up the enviroment
     */
    M_set_machine(H_arch, H_model);
    if (M_layout_order()==M_LITTLE_ENDIAN)
        H_dat_format = DAT_LITTLE_ENDIAN;
    else if (M_layout_order()==M_BIG_ENDIAN)
        H_dat_format = DAT_BIG_ENDIAN;
    else
        H_punt("main: unknown layout ordering!");
    if (H_verbose_yes)
	print_enviroment_info();

    if (H_generate_control_flow_file)
        H_ext_option |= EXT_CNT_FLOW;
    if (H_generate_data_flow_file)
        H_ext_option |= EXT_DATA_FLOW;

    if (! strcmp(H_output_form_name, "C"))
        H_output_form = OUTPUT_C;
    else if (! strcmp(H_output_form_name, "Hcode"))
        H_output_form = OUTPUT_CCODE;
    else if (! strcmp(H_output_form_name, "Lcode"))
	H_punt("main: no longer may specify Lcode as output form, use HtoL");
    else
        H_punt("main: illegal output_format");

/* BCC - read the size of integer types ( char, short, int, long) - 6/8/95 */
    H_GetIntegerSize();

    /* call Hcode main routine */
    H_process_hcode();


    /* Print out warning about unused command line parameter settings 
     * JCG 7/12/95
     */
    L_warn_about_unused_macros (stderr, external_list);

    /* DIA - For Makefile friendliness */
    exit (0);
}
