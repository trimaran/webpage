/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_struct.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>


/*===========================================================================*\
 *	In this file, we place all functions which operate on
 *	the internal CCODE data structure.
\*===========================================================================*/

#undef FANCY_MEMORY_ALLOC
#undef DEBUG_MEMORY_ALLOC
#undef CHECK_MEMORY_ALLOC

#undef TEST_VARLIST

/*-------------------------------------------------------------*/
static int total_alloc = 0;
imp_print_alloc() {
#ifdef VERBOSE
	fprintf(stderr, "heap space management (%d)\n", total_alloc);
	fflush(stderr);
#endif
}

#ifdef FANCY_MEMORY_ALLOC
static char *ialloc(size)
int size;
{
	char *new;
	new = (char *) malloc (size);
	if (new==0) Punt("out of memory space");
	total_alloc += size;
	return new;
}
/* 
 * We will implement our own garbage collection.
 * This is extremely space inefficient. When I have
 * time, I will write a better heap management algorithm.
 */
typedef struct _Buf {
	char		*ptr;
	struct _Buf	*next;
} _Buf, *Buf;
typedef struct _Recycle {
	int		size;
	struct _Buf	*link;
	struct _Recycle *next;
} _Recycle, *Recycle;
static Buf buf_list = 0;	/* keep unused buf_list */
static Recycle live_list = 0;

char *imp_alloc(size)
int size;
{
	char *new;
	Recycle ptr;
	Buf buf;
	/* search the live_list for a buffer of the same size */
	for (ptr=live_list; ptr!=0; ptr=ptr->next)
	    if (ptr->size==size)
		break;
	/* if not found, allocate new space */
	if (ptr==0) {
	    new = ialloc(size);
#ifdef DEBUG_MEMORY_ALLOC
fprintf(stderr, "allocate (%d) (new)\n", size);
#endif
	} else {
	    buf = ptr->link;
	    if (buf==0) {	/* empty link, allocate new space */
	      	new = ialloc(size);
#ifdef DEBUG_MEMORY_ALLOC
fprintf(stderr, "allocate (%d) (new)\n", size);
#endif
	    } else {
	    	new = buf->ptr;		/* issue the requested space */
		buf->ptr = 0;
	    	/* release the buffer from the live_list */
		ptr->link = buf->next;	/* release the buffer */
		buf->next = buf_list;	/* put on the buf_list */
		buf_list = buf;
#ifdef DEBUG_MEMORY_ALLOC
fprintf(stderr, "allocate (%d) (recycle)\n", size);
#endif
	    }
	}
	return new;
}
imp_free(pointer, size)
char *pointer;
int size;
{
	Recycle ptr;
	Buf buf;
	/* search the live_list for a buffer of the same size */
	for (ptr=live_list; ptr!=0; ptr=ptr->next)
	    if (ptr->size==size)
		break;
	/* if not found, allocate new recycle entry */
	if (ptr==0) {
	    ptr = (Recycle) ialloc (sizeof(_Recycle));
	    ptr->size = size;
	    ptr->link = 0;
	    ptr->next = live_list;
	    live_list = ptr;
	}
#ifdef CHECK_MEMORY_ALLOC
	for (buf=ptr->link; buf!=0; buf=buf->next) {
	    if (buf->ptr == pointer) {
		printf("address=0x%x, size=%d\n", pointer, size);
		Punt("imp_free: should not free an object twice");
	    }
	}
#else
	/*
	 *  Already in the garbage list. So do nothing now.
	 *  ++++ But definitely need to fix this bug ASAP.
	 */
	for (buf=ptr->link; buf!=0; buf=buf->next) {
	    if (buf->ptr == pointer) {
		return 0;
	    }
	}
#endif
	/* create a new buffer */
 	if (buf_list!=0) {
	    buf = buf_list;
	    buf_list = buf_list->next;
	} else {
	    buf = (Buf) ialloc (sizeof(_Buf));
	}
	buf->next = ptr->link;
	ptr->link = buf;
	buf->ptr = pointer;
#ifdef DEBUG_MEMORY_ALLOC
fprintf(stderr, "free (%d)\n", size);
#endif
	return 0;
}
#else
char *imp_alloc(size)
int size;
{
	char *new;
	new = (char *) malloc (size);
	if (new==0) Punt("out of memory space");
	total_alloc += size;
	return new;
}
imp_free(pointer, size)
char *pointer;
int size;
{
	total_alloc -= size;
	free(pointer);
}
#endif
/*-------------------------------------------------------------*/
/*
 * Allocate space for a new FuncDcl.
 */
FuncDcl	NewFuncDcl() {
	FuncDcl new;
	new = ALLOCATE(_FuncDcl);
	new->name = "???";
	new->type = 0;
	new->param = 0;
	new->local = 0;
	new->entry_bb = 0;
	new->blocks = 0;
	new->pragma = 0;
	new->profile.fn_id = 0;
	new->profile.weight = 0.0;
	new->profile.calls = 0;
	new->ext = 0;
	return new;
}
/*-------------------------------------------------------------*/
/*
 * Allocate space for a new VarDcl.
 */
VarDcl NewVarDcl() {
	VarDcl new;
	new = ALLOCATE(_VarDcl);
	new->name = 0;
	new->type = 0;
	new->init = 0;
	new->ext = 0;
	return new;
}
/*-------------------------------------------------------------*/
/*
 * Allocate space for a new VarList.
 */
VarList NewVarList() {
	VarList new;
	new = ALLOCATE(_VarList);
	new->name = 0;
	new->var = 0;
	new->next = 0;
	return new;
}
/*-------------------------------------------------------------*/
/*
 * Allocate space for a new EnumDcl.
 */
EnumDcl NewEnumDcl() {
	EnumDcl new = ALLOCATE(_EnumDcl);
	new->name = 0;
	new->fields = 0;
	return new;
}
/*
 * Allocate space for a new EnumField.
 */
EnumField NewEnumField() {
	EnumField new = ALLOCATE(_EnumField);
	new->name = 0;
	new->value = 0;
	new->next = 0;
	return new;
}
/*-------------------------------------------------------------*/
/* 
 * Allocate space for a new StructDcl.
 */
StructDcl NewStructDcl() {
	StructDcl new = ALLOCATE(_StructDcl);
	new->name = 0;
	new->fields = 0;
	new->ext = 0;
	return new;
}
/*
 * Allocate space for a new UnionDcl.
 */
UnionDcl NewUnionDcl() {
	UnionDcl new = ALLOCATE(_UnionDcl);
	new->name = 0;
	new->fields = 0;
	new->ext = 0;
	return new;
}
/* 
 * Allocate space for a new field.
 */
Field NewField() {
	Field new = ALLOCATE(_Field);
	new->name = 0;
	new->type = 0;
	new->bit_field = 0;
	new->next = 0;
	new->ext = 0;
	return new;
}
/*-------------------------------------------------------------*/
/* 
 * BCC - Allocate space for a new param. - 1/21/96 
 */
Param NewParam() {
	Param new = ALLOCATE(_Param);
	new->type = 0;
	new->next = 0;
	return new;
}
/*
 * Allocate space for a new type.
 */
Type NewType() {
	Type new = ALLOCATE(_Type);
	new->type = 0;
	new->struct_name = 0;
	new->dcltr = 0;
	return new;
}
/* 
 * Allocate space for a new dcltr.
 */
Dcltr NewDcltr() {
	Dcltr new = ALLOCATE(_Dcltr);
	new->method = 0;
	new->index = 0;
	new->next = 0;
	/* BCC - added for function prototype parameters - 1/21/96 */
	new->param = 0;
	/* GEH - added for virtual C++ and ANSI C stuff - 1/21/96 */
	new->qualifier = 0;
	return new;
}
/*-------------------------------------------------------------*/
/*
 * Allocate space for a new Initializer. 
 */
Init NewInit() {
	Init new = ALLOCATE(_Init);
	new->expr = 0;
	new->set = 0;
	new->next = 0;
	new->ext = 0;
	return new;
}
/*-------------------------------------------------------------*/
/*
 * Allocate space for a new basic block.
 */
Block NewBlock() {
	Block new = ALLOCATE(_Block);
	new->id = 0;
	new->status = 0;
	new->source = 0;
	new->destination = 0;
	new->first = 0;
	new->last = 0;
	new->next = 0;
	new->pragma = 0;
	new->profile.weight = 0.0;
	new->profile.destination = 0;
	new->ext = 0;
	return new;
}
/*-------------------------------------------------------------*/
/*
 * Allocate space for a new BLink.
 */
BLink NewBLink() {
	BLink new = ALLOCATE(_BLink);
	new->status = 0;
	new->condition = 0;
	new->source = 0;
	new->destination = 0;
	new->next = 0;
	new->ext = 0;
	return new;
}
/*-------------------------------------------------------------*/
/*
 * Allocate space for a new expression.
 */
Expr NewExpr(opcode)
int opcode;
{
	Expr new = ALLOCATE(_Expr);
	new->opcode = opcode;
	new->status = 0;
	new->type = 0;
	new->value.scalar = 0;
	new->sibling = 0;
	new->operands = 0;
	new->next = 0;
	new->previous = 0;
	new->pragma = 0;
	new->ext = 0;
	return new;
}
/*
 * Allocate space for a pragma.
 */

DepInfo 
NewDepInfo()
{
    DepInfo new;

    new = ALLOCATE(_DepInfo);

    new->num = 0;
    new->certainty = 'M';
    new->freq = 'S';
    new->dist = 0;
    new->flags = 0;
    new->next = NULL;

    return (new);
}

Pragma NewPragma(str)
char *str;
{
	Pragma new = ALLOCATE(__Pragma);
	new->specifier = str;
	new->dep_info = 0;
	new->next = 0;
	return new;
}
/*
 * Allocate space for a new call site.
 */
ProfCS NewProfCS() {
	ProfCS new = ALLOCATE(_ProfCS);
	new->call_site_id = 0;
	new->callee_id = 0;
	new->weight = 0.0;
	new->next = 0;
	return new;
}
/* 
 * Allocate space for a new arc.
 */
ProfArc NewProfArc() {
	ProfArc new = ALLOCATE(_ProfArc);
	new->bb_id = 0;
	new->condition = 0;
	new->weight = 0;
	new->next = 0;
	return new;
}
/*-------------------------------------------------------------*/
/*
 * Defines a basic type.
 */
Type NewBasicType(type)
int type;
{
    	Type new = NewType();
	new->type = type;
	return new;
}
/*-------------------------------------------------------------*/
/* remove profile record */
static RemoveProfArc(a)
ProfArc a;
{
	if (a==0) return;
	if (a->next!=0) RemoveProfArc(a->next);
	a->next = 0;
	DISPOSE(a);
}
/* remove pragma */
static RemovePragma(p)
Pragma p;
{
	if (p==0) return;
	if (p->next!=0) RemovePragma(p->next);
	p->next = 0;
	if (p->dep_info != NULL) {
	    DISPOSE(p->dep_info);
	    p->dep_info = NULL;
	}
	DISPOSE(p);
}
/* BCC - remove param - 1/22/96 */
RemoveParam(param)
     Param param;
{
	extern RemoveType();     /* forward */
	if (param == 0) return;
	RemoveParam(param->next);
	RemoveType(param->type);
	param->next = 0;
	param->type = 0;
	DISPOSE(param);
}

/* remove dcltr */
RemoveDcltr(dcltr)
Dcltr dcltr;
{
	extern RemoveExpr();	/* forward */
	if (dcltr==0) return;
	RemoveDcltr(dcltr->next);
	RemoveExpr(dcltr->index);
	/* BCC - 1/22/96 */
	RemoveParam(dcltr->param);
	dcltr->index = 0;
	dcltr->qualifier = 0;
	DISPOSE(dcltr);
}
/* remove type */
RemoveType(type)
Type type;
{
	if (type==0) return;
	/* remove dcltr */
	RemoveDcltr(type->dcltr);
	type->dcltr = 0;
	DISPOSE(type);
}
/* remove the space allocated to an expression */
RemoveExpr(expr)
Expr expr;
{
	if (expr==0) return;
	/* remove type */
	if (expr->type!=0) RemoveType(expr->type);
	expr->type = 0;
	/* remove operands */
	if (expr->sibling!=0) RemoveExpr(expr->sibling);
	if (expr->operands!=0) RemoveExpr(expr->operands);
	if (expr->pragma!=0) RemovePragma(expr->pragma);
	expr->sibling = 0;
	expr->operands = 0;
	expr->pragma = 0;
	DISPOSE(expr);
}
static RemoveExprs(list)
Expr list;
{
	if (list==0) return;
	if (list->next!=0) RemoveExprs(list->next);
	list->next = 0;
	RemoveExpr(list);
}
static RemoveInit(init)
Init init;
{
	if (init==0) return;
	if (init->set!=0) RemoveInit(init->set); 
	init->set = 0;
	if (init->next!=0) RemoveInit(init->next); 
	init->next = 0;
	if (init->expr!=0) RemoveExpr(init->expr);
	init->expr = 0;
	DISPOSE(init);
}
RemoveVarDcl(var)
VarDcl var;
{
	if (var==0) return;
	/* remove type */
	RemoveType(var->type);
	var->type = 0;
	/* remove init */
	if (var->init!=0) RemoveInit(var->init);
	var->init = 0;
	DISPOSE(var);
}
RemoveVarList(list)
VarList list;
{
	if (list==0) return;
	RemoveVarList(list->next);
	list->next = 0;
	RemoveVarDcl(list->var);
	list->var = 0;
	DISPOSE(list);
}
RemoveVarList2(list)
VarList list;
{
	if (list==0) return;
	RemoveVarList2(list->next);
	list->next = 0;
	/** do not remove the VarDcl **/
	list->var = 0;
	DISPOSE(list);
}
static RemoveBLink(link)
BLink link;
{
	if (link==0) return;
	if (link->next!=0) RemoveBLink(link->next);
	link->next = 0;
	RemoveExpr(link->condition);
	link->condition = 0;
	DISPOSE(link);
}
RemoveBlocks(bb)
Block bb;
{
	if (bb==0) return;
	RemoveBlocks(bb->next);
	bb->next = 0;
	/* remove source and destination links */
	RemoveBLink(bb->source);
	RemoveBLink(bb->destination);
	bb->source = bb->destination = 0;
	/* remove expressions */
	RemoveExprs(bb->first);
	bb->first = bb->last = 0;
	if (bb->pragma!=0) RemovePragma(bb->pragma);
	if (bb->profile.destination!=0) 
	    RemoveProfArc(bb->profile.destination);
	DISPOSE(bb);
}
/*
 * First, dispose all internal structures.
 * Then, dispose itself.
 * !! The (type) field must not be destroyed. It is linked to
 *	the function symbol table, and will be used in the future.
 */
FuncDcl RemoveFuncDcl(fn)
FuncDcl fn;
{
	if (fn==0) return 0;
	/* remove parameter and local variable lists */
	RemoveVarList(fn->param); fn->param = 0;
	RemoveVarList(fn->local); fn->local = 0;
	/* remove basic blocks */
	RemoveBlocks(fn->blocks); fn->blocks = 0;
	RemovePragma(fn->pragma); fn->pragma = 0;
	DISPOSE(fn);
	return 0;
}
/*-------------------------------------------------------------*/
/* 
 * Add operand to an expression.
 * !! The sibling field of expr2 must not be changed, so we
 *	can simulate adding several operands at once.
 */
void AddOperand(expr1, expr2)
Expr expr1, expr2;
{
	Expr ptr;
	if (expr1==0)
	    Punt("AddOperand: expr1 is nil");
	ptr = expr1->operands;
	if (ptr==0) {
	    expr1->operands = expr2;
	} else {
	    while (ptr->sibling!=0) ptr = ptr->sibling;
	    ptr->sibling = expr2;
	}
}
/*
 * Get the Nth operand. 0 means itself.
 */
Expr GetOperand(expr, N)
Expr expr;
int N;
{
	if (N<=0) return expr;
	expr = expr->operands;
	while ((--N)!=0) {
	    if (expr==0)	/* not found, return 0 */
		return 0;
	    expr = expr->sibling;
	}
	return expr;
}
/*
 * Change the Nth operand. do nothing if the Nth operand
 * does not exist.
 */
void ChangeOperand(expr, N, operand)
Expr expr, operand;
int N;
{
	Expr ptr;
	if (N<=0) return;
	if (operand->sibling!=0)
	    Punt("ChangeOperand: illegal operand");
	/** first find the operand **/
	ptr = expr->operands;
	while ((--N)!=0) {
	    if (ptr==0)	/* not found, return */
		return;
	    ptr = ptr->sibling;
	}
	/** replace the operand by the formal parameter **/
	operand->sibling = ptr->sibling;
	ptr->sibling = 0;
	if (ptr==expr->operands) {
	    expr->operands = operand;
	} else {
	    expr = expr->operands;
	    while (expr->sibling!=ptr)
		expr = expr->sibling;
	    expr->sibling = operand;
	}
}
/*-------------------------------------------------------------*/
/*
 * Create an arbitrary expression, whose type is known.
 * The actual parameter is absorbed. Therefore, the caller
 * must duplicate the formal parameter before calling this
 * function (or sharing will occur: which is an error).
 * The caller must fill in the (value) field.
 */
Expr NewInstExpr(opcode, type)
int opcode;
Type type;
{
	Expr new = NewExpr(opcode);
	new->type = type;
	return new;
}
/*
 * Create PRIMITIVE expressions.
 */
Expr NewVarExpr(var_name)
char *var_name;
{
	Expr new = NewExpr(OP_var);
	new->value.var_name = var_name;
	CastExpr(new);
	return new;
}
Expr NewIntExpr(value)
int value;
{
	Expr new = NewExpr(OP_signed);
	new->value.scalar = value;
	CastExpr(new);
	return new;
}
/* BCC - added 1/30/96 */
Expr NewUnsignedIntExpr(value)
unsigned int value;
{
	Expr new = NewExpr(OP_unsigned);
	new->value.uscalar = value;
	CastExpr(new);
	return new;
}
Expr NewRealExpr(value)
double value;
{
	/* BCC - double is the default - 8/5/96 */
	Expr new = NewExpr(OP_double);
	new->value.real = value;
	CastExpr(new);
	return new;
}

/* BCC - added - 8/5/96 */
Expr NewFloatExpr(value)
double value;
{
	Expr new = NewExpr(OP_float);
	new->value.real = value;
	CastExpr(new);
	return new;
}

/* BCC - added - 8/5/96 */
Expr NewDoubleExpr(value)
double value;
{
	Expr new = NewExpr(OP_double);
	new->value.real = value;
	CastExpr(new);
	return new;
}

Expr NewCharExpr(ch)
char *ch;
{
	Expr new = NewExpr(OP_char);
	new->value.string = ch;
	CastExpr(new);
	return new;
}
Expr NewStringExpr(str)
char *str;
{
	Expr new = NewExpr(OP_string);
	new->value.string = str;
	CastExpr(new);
	return new;
}
/*-------------------------------------------------------------*/
/*
 * Return a TRUE expression (1)
 */
Expr TrueExpr() {
	return NewIntExpr(1);
}
/*
 * Return a FALSE expression (0)
 */
Expr FalseExpr() {
	return NewIntExpr(0);
}
/* 
 * Return a DEFAULT expression (DEFAULT)
 */
Expr DefaultExpr() {
	return NewIntExpr(DEFAULT_VALUE);
}
/*
 * Query functions.
 */
IsTrueExpr(expr)
Expr expr;
{
	if ((expr==0)||(expr->opcode!=OP_signed)) return 0;
	return (expr->value.scalar==1);
}
IsFalseExpr(expr)
Expr expr;
{
	if ((expr==0)||(expr->opcode!=OP_signed)) return 0;
	return (expr->value.scalar==0);
}
IsDefaultExpr(expr)
Expr expr;
{
	if ((expr==0)||(expr->opcode!=OP_signed)) return 0;
	return (expr->value.scalar==DEFAULT_VALUE);
}
/*-------------------------------------------------------------*/
/* 
 *	ENUM
 */
static struct {
        char    *name;
        int     value;
} enum_field[HC_MAX_ENUM_FIELD];
static n_enum_field = 0;

void HC_assign_enum(EnumDcl en)
{
    EnumField field;
    int val, next_val;
/* REH 10/7/93 */
    int enum_val;
/* HER */
    if (en==0)
        return;
    next_val = HC_BASE_ENUM_VALUE;
    for (field=en->fields; field!=0; field=field->next) {
        /** the user can define it **/
        if (field->value!=0) {
            if (! IsIntegralExpr(field->value))
                Punt("enum field can be initialized only be a constant");
            val = IntegralExprValue(field->value);
#if 0
            if (val<next_val) {
                fprintf(stderr, "enum field: %s\n", field->name);
                Punt("illegal user-defined enum constant: too small");
            }
            if (val>=next_val)
#endif
                next_val = val+1;
        } else {
            val = next_val++;
        }
        /** look up our internal table **/
/* REH 10/7/93 - It's okay to have enum fields with the same name,
                 as long as they evaluate to the same value */
        enum_val = HC_enum(field->name);
        if ( enum_val  != HC_ILLEGAL_ENUM_VALUE )  {
            /* the field exists it is legal if enum_val == val */
            if ( enum_val != val )  {
                fprintf(stderr,"enum fields with same names\n");
                fprintf(stderr,"must have the same value.\n");
                fprintf(stderr,"offending enum = %s\n",field->name);
                fprintf(stderr,"current value = %d, previous value %d\n",
                                        val,enum_val);
                Punt("illegal enum field");
            }
            else
                continue;
        }
/* old code
        if (HC_enum(field->name) != HC_ILLEGAL_ENUM_VALUE) {
            fprintf(stderr, "all enum fields must have unique names\n");
            fprintf(stderr, "offending enum = %s\n", field->name);
            Punt("illegal enum field");
        }
*/
/* HER */
        if (n_enum_field>=HC_MAX_ENUM_FIELD)
            Punt("too many enum fields");
        enum_field[n_enum_field].name = C_findstr(field->name);
        enum_field[n_enum_field].value = val;
#ifdef DEBUG
printf("HC_assign_enum: %s = %d\n", field->name, val);
#endif
        n_enum_field += 1;
    }
}

int HC_enum(field_name)
char *field_name;
{
    int i;
    for (i=0; i<n_enum_field; i++) {
        if (! strcmp(field_name, enum_field[i].name))
            return enum_field[i].value;
    }
    return HC_ILLEGAL_ENUM_VALUE;
}
/*-------------------------------------------------------------*/
int IsVarExpr(expr)
Expr expr;
{
    if (expr==0) return 0;
    return (expr->opcode == OP_var);
}
/*
 *	ignore OP_type_size and OP_expr_size.
 *	OP_enum nodes must be replaced by OP_signed nodes
 *	before calling this routine.
 */
extern int H_gen_lcode;

/* BCC - added to help determine the type of the index of an array -  5/24/95 */
int IsIntegralExprForArray(expr)
Expr expr;
{
	int opcode;
	if (expr==0) return 0;
	opcode = expr->opcode;
	switch (opcode) {
	case OP_signed:
	case OP_unsigned:
	case OP_char:
	case OP_enum:   
	    return 1;
	case OP_cast:
	    if ((expr->type->type & TY_INTEGRAL) && (expr->type->dcltr == 0))
	    	return (IsIntegralExprForArray(expr->operands));
	    else return 0;
	/* BCC - check more integral expressions - 6/2/95 */
	case OP_add:
	case OP_sub:
	case OP_mul:
	case OP_div:
	    return ( IsIntegralExprForArray(expr->operands) &&
	    	     IsIntegralExprForArray(expr->operands->sibling) );
	default:
	    return 0;
	}
}

/* BCC - added to help determine the type of the index of an array -  5/24/95 */
int IntegralExprValueForArray(expr)
Expr expr;
{
	int opcode, value;
/* BCC - use ReduceExpr to handle cast inside to get the result 6/10/95 */
	Expr new;

	if (expr==0) return 0;
	new = ReduceExpr(expr);
	/* BCC - 6/10/95 */
	opcode = new->opcode;
	switch (opcode) {
	case OP_signed:
	    return expr->value.scalar;
	case OP_unsigned:
	    return expr->value.uscalar;
	case OP_char:
	    return C_str2char(expr->value.string);
	case OP_enum:	
	    return HC_enum(expr->value.string);
	default:
	    Punt("IntegralExprValue: not an integral expression");
	    return 0;
	}
}

int IsIntegralExpr(expr)
Expr expr;
{
	int opcode;
	if (expr==0) return 0;
	opcode = expr->opcode;
	switch (opcode) {
	case OP_signed:
	case OP_unsigned:
	case OP_char:
	    return 1;
/* REH 9/1/93 when generating Hcode or 'C' you do not
	      want the enum evaluated, thus OP_enum
	      IsIntegeralExpr iff generating Lcode  

*/
#if 0
	case OP_enum:   /* 2-6-1991 */
	    return 1;
#endif

	case OP_enum:
/*
	    if ( H_gen_lcode )
*/
		return(1);
/*
	    return 0;
*/
/* HER 9/1/93 */

#if 0  /* REH 8/9/94 backed out this fix for backward compatibility */
/* DMG - added cast - 8/94 */
	case OP_cast:
	    return (IsIntegralExpr(expr->operands));
#endif
	default:
	    return 0;
	}
}
int IntegralExprValue(expr)
Expr expr;
{
	int opcode, value;

	if (expr==0) return 0;
	opcode = expr->opcode;
	switch (opcode) {
	case OP_signed:
	    return expr->value.scalar;
	case OP_unsigned:
	    return expr->value.uscalar;
	case OP_char:
	    return C_str2char(expr->value.string);
	case OP_enum:	/* 2-6-1991 */
	    return HC_enum(expr->value.string);
#if 0  /* REH 8/9/94 backed out this fix for backward compatibility */
/* DMG added cast 8/94 */
	case OP_cast:
	    return (IntegralExprValue(expr->operands));
#endif
	default:
	    Punt("IntegralExprValue: not an integral expression");
	    return 0;
	}
}
/* BCC - added - 8/5/96 */
int IsRealExpr(expr)
Expr expr;
{
	if (expr==0) return 0;
	return (expr->opcode==OP_float || expr->opcode==OP_double);
}
int IsFloatExpr(expr)
Expr expr;
{
	if (expr==0) return 0;
	return (expr->opcode==OP_float);
}
/* BCC - added - 8/5/96 */
int IsDoubleExpr(expr)
Expr expr;
{
	if (expr==0) return 0;
	return (expr->opcode==OP_double);
}
double FloatExprValue(expr)
Expr expr;
{
	return expr->value.real;
}
int IsConstNumber(expr)
Expr expr;
{
	/* BCC - use IsRealExpr instead - 8/5/96 */
	return (IsIntegralExpr(expr) || IsRealExpr(expr));
}
IsConstOne(expr)
Expr expr;
{
	/* BCC - use IsRealExpr instead - 8/5/96 */
	return ((IsIntegralExpr(expr) && (IntegralExprValue(expr)==1)) ||
		(IsRealExpr(expr) && (FloatExprValue(expr)==1.0)));
}
IsConstZero(expr)
Expr expr;
{
	/* BCC - use IsRealExpr instead - 8/5/96 */
	return ((IsIntegralExpr(expr) && (IntegralExprValue(expr)==0)) ||
		(IsRealExpr(expr) && (FloatExprValue(expr)==0.0)));
}
IsConstNonZero(expr)
Expr expr;
{
	/* BCC - use IsRealExpr instead - 8/5/96 */
	return ((IsIntegralExpr(expr) && (IntegralExprValue(expr)!=0)) ||
		(IsRealExpr(expr) && (FloatExprValue(expr)!=0.0)));
}
/*-------------------------------------------------------------*/
void AddExpr2BB(bb, expr)
Block bb;
Expr expr;
{
	if ((bb==0)||(expr==0))
	    return;
	if (bb->first==0) bb->first = bb->last = expr;
	else {
	    bb->last->next = expr;
	    expr->previous = bb->last;
	    bb->last = expr;
	}
}
Block FindBlock(fn, bb_id)
FuncDcl fn;
int bb_id;
{
    Block bb;
    for (bb=fn->blocks; bb!=0; bb=bb->next)
	if (bb->id==bb_id)
	    return bb;
    return 0;
}

/* BCC - Completely duplicate a Param - 1/21/96 */
Param CopyParam(param)
     Param param;
{
  Param new;
  if (param == 0) return 0;
  new = NewParam();
  new->type = CopyType(param->type);
  if (param->next!=0)
    new->next = CopyParam(param->next);
  return new;
}

/*-------------------------------------------------------------*/
/*
 * Completely duplicate a Dcltr.
 */
Dcltr CopyDcltr(dcltr)
Dcltr dcltr;
{
	Dcltr new;
	if (dcltr==0) return 0;
	new = NewDcltr();
	new->method = dcltr->method;
	if (dcltr->index!=0)
	    new->index = CopyExpr(dcltr->index);
	new->qualifier = dcltr->qualifier;
	new->next = CopyDcltr(dcltr->next);
	/* BCC - 1/21/96 */
	if (dcltr->param!=0)
	    new->param = CopyParam(dcltr->param);
	return new;
}
Dcltr ConcatDcltr(A, B)
Dcltr A, B;
{
        Dcltr ptr;
        if (A==0) return B;
        if (B==0) return A;
        for (ptr=A; ptr->next!=0; ptr=ptr->next) ;
        ptr->next = B;
        return A;
}
Dcltr ReverseDcltr(A)
Dcltr A;
{
        Dcltr ptr;
        if (A==0) return 0;
        ptr = A->next;
        A->next = 0;
        return (ConcatDcltr(ReverseDcltr(ptr), A));
}
/*-------------------------------------------------------------*/
ProfCS CopyProfCS(cs)
ProfCS cs;
{
	ProfCS new;
	if (cs==0) return 0;
	new = NewProfCS();
	new->call_site_id = cs->call_site_id;
	new->callee_id = cs->callee_id;
	new->weight = cs->weight;
	new->next = CopyProfCS(cs->next);
	return cs;
}
ProfArc CopyProfArc(arc)
ProfArc arc;
{
	ProfArc new;
 	if (arc==0) return 0;
	new = NewProfArc();
	new->bb_id = arc->bb_id;
	new->condition = arc->condition;
	new->weight = arc->weight;
	new->next = CopyProfArc(arc->next);
	return new;
}

DepInfo
CopyDepInfo (DepInfo dep_info)
{
    DepInfo new;

    new = NewDepInfo();
    new->num = dep_info->num;
    new->certainty = dep_info->certainty;
    new->freq = dep_info->freq;
    new->dist = dep_info->dist;
    new->flags = dep_info->flags;

    return (new);
}

Pragma CopyPragma(pragma)
Pragma pragma;
{
   	Pragma new;
	if (pragma==0) return 0;
	new = NewPragma(pragma->specifier);
	if (pragma->dep_info != NULL)
	    new->dep_info = CopyDepInfo (pragma->dep_info);
	new->next = CopyPragma(pragma->next);
	return new;
}
/*
 * Completely duplicate a Type. (all fields)
 */
Type CopyType(type)
Type type;
{
	Type new;
	if (type==0) return 0;
	new = NewType();
	new->type = type->type;
	new->struct_name = type->struct_name;
	new->dcltr = CopyDcltr(type->dcltr);
	return new;
}
/*
 * Completely duplicate an Expr. (all fields, except ext)
 */
Expr CopyExpr(expr)
Expr expr;
{
	Expr new, ptr;
	if (expr==0) return 0;
	new = NewExpr(expr->opcode);
	new->status = expr->status;
	new->type = CopyType(expr->type);
	switch (expr->opcode) {
	case OP_var:
		new->value.var_name = expr->value.var_name;
		break;
	case OP_signed:
		new->value.scalar = expr->value.scalar;
		break;
	case OP_unsigned:
		new->value.uscalar = expr->value.uscalar;
		break;
	/* BCC - added - 8/5/96 */
	case OP_double:
	case OP_float:
		new->value.real = expr->value.real;
		break;
	case OP_enum:
	case OP_char:
	case OP_string:
	case OP_dot:
	case OP_arrow:
		new->value.string = expr->value.string;
		break;
	case OP_cast:
		new->value.type = new->type;
		break;
	case OP_type_size:
		new->value.type = CopyType(expr->value.type);
		break;
	default:
		/* do nothing */
		break;
	}
	/* copy the pragma */
	new->pragma = CopyPragma(expr->pragma);
	/* copy the operands */
	for (ptr=expr->operands; ptr!=0; ptr=ptr->sibling)
	    AddOperand(new, CopyExpr(ptr));
	return new;
}
/*-------------------------------------------------------------*/
/*
 *	Add/find a structure definition in the symbol table.
 */
AddStruct(name, st)
char *name;
StructDcl st;
{
	Symbol sym;
	sym = AddSym(SymbolTable[ST_STRUCT], name, 0);
	sym->ptr = st;
}
StructDcl FindStruct(name)
char *name;
{
	Symbol sym;
	sym = FindSym(SymbolTable[ST_STRUCT], name, 0);
	if (sym==0) 
	    return 0;
	else
	    return ((StructDcl) sym->ptr);
}
AddUnion(name, un)
char *name;
UnionDcl un;
{
	Symbol sym;
	sym = AddSym(SymbolTable[ST_UNION], name, 0);
	sym->ptr = un;
}
UnionDcl FindUnion(name)
char *name;
{
	Symbol sym;
	sym = FindSym(SymbolTable[ST_UNION], name, 0);
	if (sym==0) 
	    return 0;
	else
	    return ((UnionDcl) sym->ptr);
}
Field FindStructField(st, name)
StructDcl st;
char *name;
{
	Field ptr;
	if (st==0) return 0;
	for (ptr=st->fields; ptr!=0; ptr=ptr->next) {
	    if (! strcmp(ptr->name, name))
		break;
	}
	return ptr;
}
Field FindUnionField(un, name)
UnionDcl un;
char *name;
{
	Field ptr;
	if (un==0) return 0;
	for (ptr=un->fields; ptr!=0; ptr=ptr->next) {
	    if (! strcmp(ptr->name, name))
		break;
	}
	return ptr;
}
AddEnum(name, en)
char *name;
EnumDcl en;
{
	Symbol sym;
	sym = AddSym(SymbolTable[ST_ENUM], name, 0);
	sym->ptr = en;
}
EnumDcl FindEnum(name)
char *name;
{
	Symbol sym;
	sym = FindSym(SymbolTable[ST_ENUM], name, 0);
	if (sym==0)
	    return 0;
	else
	    return (EnumDcl) sym->ptr;
}
EnumField FindEnumField(en, name)
EnumDcl en;
char *name;
{
	EnumField ptr;
	if (en==0) return 0;
	for (ptr=en->fields; ptr!=0; ptr=ptr->next) {
	    if (! strcmp(ptr->name, name))
		break;
	}
	return ptr;
}
AddVar(name, var)
char *name;
VarDcl var;
{
	Symbol sym;
	sym = AddSym(SymbolTable[ST_VAR], name, 0);
	sym->ptr = var;
}
VarDcl FindVar(name)
char *name;
{
	Symbol sym;
	sym = FindSym(SymbolTable[ST_VAR], name, 0);
	if (sym==0)
	    return 0;
	else
	    return (VarDcl) sym->ptr;
}
AddFunction(name, return_type)
char *name;
Type return_type;
{
	Symbol sym;
	sym = AddSym(SymbolTable[ST_FUNC], name, 0);
	sym->ptr = return_type;
}
Symbol FindFunction(name)
char *name;
{
	Symbol sym;
	sym = FindSym(SymbolTable[ST_FUNC], name, 0);
	if (sym==0)
	    return 0;
	else
	    return sym;
}
/*-------------------------------------------------------------*/
static FuncDcl cur_func = 0;
static next_bb_id = -1;
static Block cur_bb = 0;
static Pragma bb_pragma = 0;
OpenFunction(func)
FuncDcl func;
{
    if (cur_func!=0)
	Punt("OpenFunction: the previous function has not been closed yet");
    cur_func = func;
    next_bb_id = 1;
}
CloseFunction(func)
FuncDcl func;
{
    if (cur_func!=func)
	Punt("CloseFunction: the previous function has not been closed yet");
    cur_func = 0;
    next_bb_id = -1;
}
Block CreateNewBlock() {
    Block new;
    int bb_id;
    bb_id = next_bb_id++;
    new = NewBlock();
    new->id = bb_id;
    return new;
}
/*
 *	A basic block is added to the (cur_func) at the
 *	time it is activated. A basic block can be activated
 *	no more than once.
 */
ActivateBlock(bb)
Block bb;
{
    Block ptr;
    Pragma p;
    cur_bb = bb;
    ptr = cur_func->blocks;
    if (ptr==0) {
  	cur_func->blocks = bb;
    } else {
	while (ptr->next!=0) {
	    if (ptr==bb)
		Punt("ActivateBlock: a basic block can be activated only once");
	    ptr = ptr->next;
	}
	ptr->next = bb;
    }
    p = bb->pragma;
    if (p==0) {
	bb->pragma = CopyPragma(bb_pragma);
    } else {
	while (p->next!=0) p=p->next;
	p->next = CopyPragma(bb_pragma);
    }
}
Block ActiveBlock() {
    if (cur_bb==0)
	Punt("ActiveBlock: no active block");
    return cur_bb;
}
ConnectBlocks(src_bb, dst_bb, cond)
Block src_bb, dst_bb;
Expr cond;
{
    BLink new, ptr;
    if ((src_bb==0)||(dst_bb==0))
	Punt("ConnectBlocks: missing one of the connecting blocks");
    if ((src_bb->id==0)||(dst_bb->id==0))
	Punt("ConnectBlocks: basic block id cannot be zero");
    new = NewBLink();
    new->src_bb = src_bb;
    new->dest_bb = dst_bb;
    new->source = src_bb->id;
    new->destination = dst_bb->id;
    new->condition = cond;
    ptr = src_bb->destination;
    if (ptr==0) {
    	src_bb->destination = new;
    } else {
	while (ptr->next!=0) ptr=ptr->next;
	ptr->next = new;
    }
    new = NewBLink();
    new->src_bb = src_bb;
    new->dest_bb = dst_bb;
    new->source = src_bb->id;
    new->destination = dst_bb->id;
    new->condition = CopyExpr(cond);
    ptr = dst_bb->source;
    if (ptr==0) {
    	dst_bb->source = new;
    } else {
	while (ptr->next!=0) ptr=ptr->next;
	ptr->next = new;
    }
}
AddExpr(expr)
Expr expr;
{
    if (cur_bb==0) Punt("AddExpr: nil cur_bb");
    AddExpr2BB(cur_bb, expr);
}
EnableBlockPragma(pragma)
Pragma pragma;
{
    bb_pragma = pragma;
}
DisableBlockPragma() {
    bb_pragma = 0;
}
/*-------------------------------------------------------------*/
/*
 *	return 1 if the prefix is found in the string.
 *	return 0 if otherwise.
 */
int PrefixMatch(prefix, string)
char *prefix, *string;
{
    while (*prefix!='\0') {
	if (*string=='\0') return 0;	/* string is shorter than prefix */
	if (*prefix!=*string) return 0;	/* no match */
	prefix++;
	string++;
    }
    return 1;
}
AddFunctionPragma(func, specifier)
FuncDcl func;
char *specifier;
{
    Pragma new;
    new = NewPragma(specifier);
    new->next = func->pragma;
    func->pragma = new;
}
Pragma FindFunctionPragma(func, prefix)
FuncDcl func;
char *prefix;
{
    Pragma ptr;
    for (ptr=func->pragma; ptr!=0; ptr=ptr->next)
	if (PrefixMatch(prefix, ptr->specifier))
	    return ptr;
    return 0;
}
/*
 *	if (pragma==0) remove all pragmas.
 *	else only remove a single pragma if found.
 */
RemoveFunctionPragma(func, pragma)
FuncDcl func;
Pragma pragma;
{
    Pragma ptr;
    if (pragma==0) {
    	RemovePragma(func->pragma);
	func->pragma = 0;
    }
    for (ptr=func->pragma; ptr!=0; ptr=ptr->next)
	if (ptr==pragma)
	    break;
    if (ptr==0) return 0;	/* not found */
    ptr = func->pragma;
    if (pragma==ptr) {
	func->pragma = pragma->next;
    } else {
	while (ptr->next!=pragma) ptr=ptr->next;
	ptr->next = pragma->next;
    }
    pragma->next = 0;
    RemovePragma(pragma);
    return 0;
}
AddBlockPragma(bb, specifier)
Block bb;
char *specifier;
{
    Pragma new;
    new = NewPragma(specifier);
    new->next = bb->pragma;
    bb->pragma = new;
}
Pragma FindBlockPragma(bb, prefix)
Block bb;
char *prefix;
{
    Pragma ptr;
    for (ptr=bb->pragma; ptr!=0; ptr=ptr->next)
	if (PrefixMatch(prefix, ptr->specifier))
	    return ptr;
    return 0;
}
/*
 *	if (pragma==0) remove all pragmas.
 *	else only remove a single pragma if found.
 */
RemoveBlockPragma(bb, pragma)
Block bb;
Pragma pragma;
{
    Pragma ptr;
    if (pragma==0) {
    	RemovePragma(bb->pragma);
	bb->pragma = 0;
    }
    for (ptr=bb->pragma; ptr!=0; ptr=ptr->next)
	if (ptr==pragma)
	    break;
    if (ptr==0) return 0;	/* not found */
    ptr = bb->pragma;
    if (pragma==ptr) {
	bb->pragma = pragma->next;
    } else {
	while (ptr->next!=pragma) ptr=ptr->next;
	ptr->next = pragma->next;
    }
    pragma->next = 0;
    RemovePragma(pragma);
    return 0;
}
AddExprPragma(expr, specifier)
Expr expr;
char *specifier;
{
    Pragma new;
    new = NewPragma(specifier);
    new->next = expr->pragma;
    expr->pragma = new;
}
Pragma FindExprPragma(expr, prefix)
Expr expr;
char *prefix;
{
    Pragma ptr;
    for (ptr=expr->pragma; ptr!=0; ptr=ptr->next)
	if (PrefixMatch(prefix, ptr->specifier))
	    return ptr;
    return 0;
}
/*
 *	if (pragma==0) remove all pragmas.
 *	else only remove a single pragma if found.
 */
RemoveExprPragma(expr, pragma)
Expr expr;
Pragma pragma;
{
    Pragma ptr;
    if (pragma==0) {
    	RemovePragma(expr->pragma);
	expr->pragma = 0;
    }
    for (ptr=expr->pragma; ptr!=0; ptr=ptr->next)
	if (ptr==pragma)
	    break;
    if (ptr==0) return 0;	/* not found */
    ptr = expr->pragma;
    if (pragma==ptr) {
	expr->pragma = pragma->next;
    } else {
	while (ptr->next!=pragma) ptr=ptr->next;
	ptr->next = pragma->next;
    }
    pragma->next = 0;
    RemovePragma(pragma);
    return 0;
}
/*--------------------------------------------------------------------------*/
/* 
 *	Returns true if the expression tree is completely 
 *	side-effect-free. The following operators cause side-effect :
 * 	assign, preinc, predec, postinc, postdec,
 * 	Aadd, Asub, Amul, Adiv, Amod, Arshft,
 * 	Alshft, Aand, Aor, Axor, call.
 */
int IsSideEffectFree(expr)
Expr expr;
{
    int i;
    Expr op;
    if (expr==0) return 1;
    switch (expr->opcode) {
    case OP_assign :         case OP_preinc :         case OP_predec :
    case OP_postinc :        case OP_postdec :        case OP_Aadd :
    case OP_Asub :           case OP_Amul :           case OP_Adiv :
    case OP_Amod :           case OP_Arshft :         case OP_Alshft :
    case OP_Aand :           case OP_Aor :            case OP_Axor :
    case OP_call :
        return 0;
    default :
        for (i=1; (op=GetOperand(expr, i))!=0; i++)
            if (! IsSideEffectFree(op))
                 return 0;
        return 1;
    }
}
/*--------------------------------------------------------------------------*/
/*
 *	In many cases, when an expression is known to produce
 *	boolean result, the upper (!=0) operation can be eliminated.
 */
int IsBooleanExpr(expr)
Expr expr;
{
    Expr op1, op2;
    if (expr==0) return 0;
    switch (expr->opcode) {
    case OP_eq:		case OP_ne:
    case OP_lt:		case OP_le:
    case OP_gt:		case OP_ge:
    case OP_conj:	case OP_disj:
	return 1;
    case OP_or:
    case OP_xor:
    case OP_and:
 	op1 = GetOperand(expr, 1);
 	op2 = GetOperand(expr, 2);
	return (IsBooleanExpr(op1) && IsBooleanExpr(op2));
    default:
	return 0;
    }
}
/*--------------------------------------------------------------------------*/
/*
 *	Ignore the array dimension.
 */
static int SameDcltr(d1, d2)
Dcltr d1, d2;
{
    if ((d1==0) && (d2==0)) return 1;
    if ((d1==0) || (d2==0)) return 0;
    if (d1->method != d2->method) return 0;
    return SameDcltr(d1->next, d2->next);
}
/*
 *	Ignore qualifier and class.
 */
static int SameType(t1, t2)
Type t1, t2;
{
    if ((t1==0) && (t2==0)) return 1;
    if ((t1==0) || (t2==0)) return 0;
    if ((t1->type&TY_MASK) != (t2->type&TY_MASK)) return 0;
    return SameDcltr(t1->dcltr, t2->dcltr);
}
static int SameExpr(e1, e2)
Expr e1, e2;
{
    int i;
    Expr op1, op2;
    if ((e1==0) && (e2==0)) return 1;
    if ((e1==0) || (e2==0)) return 0;
    if (e1->opcode != e2->opcode) return 0;
    switch (e1->opcode) {
    case OP_var:
	return (! strcmp(e1->value.var_name, e2->value.var_name));
    case OP_char:
    case OP_string:
    case OP_enum:
	return (! strcmp(e1->value.string, e2->value.string));
    case OP_signed:
	return (e1->value.scalar == e2->value.scalar);
    case OP_unsigned:
	return (e1->value.uscalar == e2->value.uscalar);
    /* BCC - added - 8/5/96 */
    case OP_double:
    case OP_float:
	return (e1->value.real == e2->value.real);
    default:		/* simply assume the others match */
	for (i=1; (op1=GetOperand(e1, i))!=0; i++) {
	    op2 = GetOperand(e2, i);
	    if (! SameExpr(op1, op2))
		return 0;
	}
	if ((op2=GetOperand(e2, i))!=0) return 0;
	return 1;
    }
}
static int SameEnumField(f1, f2)
EnumField f1, f2;
{
    if ((f1==0) && (f2==0)) return 1;
    if ((f1==0) || (f2==0)) return 0;
    if (strcmp(f1->name, f2->name)) return 0;
    if (! SameExpr(f1->value, f2->value)) return 0;
    return SameEnumField(f1->next, f2->next);
}
static int SameField(f1, f2)
Field f1, f2;
{
    if ((f1==0) && (f2==0)) return 1;
    if ((f1==0) || (f2==0)) return 0;
    if (strcmp(f1->name, f2->name)) return 0;
    if (! SameType(f1->type, f2->type)) return 0;
    if (! SameExpr(f1->bit_field, f2->bit_field)) return 0;
    return SameField(f1->next, f2->next);
}
/*
 *	1: name must match.
 *	2: structure must match.
 */
int SameStructDcl(st1, st2)
StructDcl st1, st2;
{
    if (st1==st2) return 1;
    if (strcmp(st1->name, st2->name)) return 0;
    return SameField(st1->fields, st2->fields);
}
int SameUnionDcl(un1, un2)
UnionDcl un1, un2;
{
    if (un1==un2) return 1;
    if (strcmp(un1->name, un2->name)) return 0;
    return SameField(un1->fields, un2->fields);
}
int SameEnumDcl(en1, en2)
EnumDcl en1, en2;
{
    if (en1==en2) return 1;
    if (strcmp(en1->name, en2->name)) return 0;
    return SameEnumField(en1->fields, en2->fields);
}
/*--------------------------------------------------------------------------*/
static Field CopyField(f)
Field f;
{
    Field new;
    if (f==0) return 0;
    new = NewField();
    new->name = f->name;
    new->type = CopyType(f->type);
    new->bit_field = CopyExpr(f->bit_field);
    new->next = CopyField(f->next);
    return new;
}
static EnumField CopyEnumField(f)
EnumField f;
{
    EnumField new;
    if (f==0) return 0;
    new = NewEnumField();
    new->name = f->name;
    new->value = CopyExpr(f->value);
    new->next = CopyEnumField(f->next);
    return new;
}
StructDcl CopyStructDcl(st)
StructDcl st;
{
    StructDcl new;
    new = NewStructDcl();
    new->name = st->name;
    new->fields = CopyField(st->fields);
    return new;
}
UnionDcl CopyUnionDcl(un)
UnionDcl un;
{
    UnionDcl new;
    new = NewUnionDcl();
    new->name = un->name;
    new->fields = CopyField(un->fields);
    return new;
}
EnumDcl CopyEnumDcl(en)
EnumDcl en;
{
    EnumDcl new;
    new = NewEnumDcl();
    new->name = en->name;
    new->fields = CopyEnumField(en->fields);
    return new;
}
static Init CopyInit(i)
Init i;
{
    Init new;
    if (i==0) return 0;
    new = NewInit();
    new->expr = CopyExpr(i->expr);
    new->set = CopyInit(i->set);
    new->next = CopyInit(i->next);
    return new;  
}
VarDcl CopyVarDcl(var)
VarDcl var;
{
    VarDcl new;
    new = NewVarDcl();
    new->name = var->name;
    new->type = CopyType(var->type);
    new->init = CopyInit(var->init);
    return new;
}
static VarList CopyVarList(list)
VarList list;
{
    VarList new;
    if (list==0) return 0;
    new = NewVarList();
    new->name = list->name;
    new->var = CopyVarDcl(list->var);
    new->next = CopyVarList(list->next);
    return new;
}
/*
 *	copy bb content, except connections.
 */
static Block CopyBlock(bb)
Block bb;
{
    Block new;
    Expr expr;
    new = NewBlock();
    new->id = bb->id;
    new->status = bb->status;
    new->cnt_type = bb->cnt_type;
    new->source = 0;
    new->destination = 0;
    for (expr=bb->first; expr!=0; expr=expr->next) {
	Expr nexp;
	nexp = CopyExpr(expr);
	AddExpr2BB(new, nexp);
    }
    new->pragma = CopyPragma(bb->pragma);
    /* profile information is not copied **/
    return new;
}
FuncDcl CopyFuncDcl(fn)
FuncDcl fn;
{
    FuncDcl new;
    Block bb, last_bb;
    new = NewFuncDcl();
    new->name = fn->name;
    new->type = CopyType(fn->type);
    new->param = CopyVarList(fn->param);
    new->local = CopyVarList(fn->local);
    new->entry_bb = fn->entry_bb;
    /*
     *	First create all blocks.
     */
    last_bb = 0;
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	Block nbb;
	nbb = CopyBlock(bb);
	/*
	 *	Also copy the profile information exactly.
  	 */
	nbb->profile.weight = bb->profile.weight;
	nbb->profile.destination = CopyProfArc(bb->profile.destination);
  	if (last_bb==0) {
	    new->blocks = nbb;
	    last_bb = nbb;
	} else {
	    last_bb->next = nbb;
	    last_bb = nbb;
	}
    }   
    /*
     *	Then connect the blocks.
     */
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	BLink link;
	Block src, dest;
	src = FindBlock(new, bb->id);
	if (src==0) Punt("CopyFuncDcl: internal error (src missing)");
	for (link=bb->destination; link!=0; link=link->next) {
	    dest = FindBlock(new, link->destination);
	    if (dest==0) Punt("CopyFuncDcl: internal error (dest missing)");
	    ConnectBlocks(src, dest, CopyExpr(link->condition));
	}
    }
    new->pragma = CopyPragma(fn->pragma);
    /*
     *	copy the profile information exactly.
     */
    new->profile.fn_id = fn->profile.fn_id;
    new->profile.weight = fn->profile.weight;
    new->profile.calls = CopyProfCS(fn->profile.calls);
    return new;
}
/*--------------------------------------------------------------------------*/
/*
 *	Returns true if dcltr1==dcltr2.
 *	We do not check the array dimension.
 *		int a[100];
 *		extern int a[];		is OK
 */
int EqualDcltr(d1, d2)
Dcltr d1, d2;
{
    if ((d1==0) && (d2==0)) return 1;
    if ((d1==0) || (d2==0)) return 0;
    if (d1->method != d2->method) return 0;
    return EqualDcltr(d1->next, d2->next);
}
int EqualType(t1, t2)
Type t1, t2;
{
    int ty1, ty2;
    if ((t1==0) || (t2==0)) Punt("EqualType: nil formal parameter");
    if (! EqualDcltr(t1->dcltr, t2->dcltr)) return 0;
    /*
     *	Also need to check the basic type.
     */
    ty1 = t1->type & TY_MASK;
    ty2 = t2->type & TY_MASK;
    if (ty1 & TY_VOID) {
	return (ty2 & TY_VOID);
    } else
    if (ty1 & TY_CHAR) {
	return (ty2 & TY_CHAR);
    } else
    if (ty1 & TY_SHORT) {
	return (ty2 & TY_SHORT);
    } else
    if (ty1 & (TY_INT | TY_SIGNED | TY_UNSIGNED)) {
	return (ty2 & (TY_INT | TY_SIGNED | TY_UNSIGNED));
    } else
    if (ty1 & TY_LONG) {
	return (ty2 & TY_LONG);
    } else
    if (ty1 & TY_FLOAT) {
	return (ty2 & TY_FLOAT);
    } else
    if (ty1 & TY_DOUBLE) {
	return (ty2 & TY_DOUBLE);
    } else
    if (ty1 & (TY_STRUCT | TY_UNION | TY_ENUM)) {
	if (ty1 != ty2) return 0;
	return (! strcmp(t1->struct_name, t2->struct_name));
    } else {
	return (ty1==ty2);
    } 
}
/*--------------------------------------------------------------------------*/
int RemoveDQ(str, buf, N)
char *str;
char buf[];
int N;
{
    int len = strlen(str);
    int i;
    if (len<2) return -1;
    if (str[0] != '"') return -1;
    if (str[len-1] != '"') return -1;
    for (i=1; i<(len-1); i++) {
	if (i>=N) Punt("RemoveDQ failed: buffer is not large enough");
	buf[i-1] = str[i];
    }
    buf[i-1] = '\0';
    return (i-1);
}
/*--------------------------------------------------------------------------*/
int CheckSourceLink(bb)
Block bb;
{
    BLink link;
    if (bb==0) return 0;
    for (link=bb->source; link!=0; link=link->next) {
	if (link->source == 0) {
	    fprintf(stderr, "> bb %d\n", bb->id);
	    Punt("CheckSourceLink failed: error 1");
	}
	if (link->destination == 0) {
	    fprintf(stderr, "> bb %d\n", bb->id);
	    Punt("CheckSourceLink failed: error 2");
	}
    }
    for (link=bb->destination; link!=0; link=link->next) {
	if (link->source == 0) {
	    fprintf(stderr, "> bb %d\n", bb->id);
	    Punt("CheckSourceLink failed: error 3");
	}
	if (link->destination == 0) {
	    fprintf(stderr, "> bb %d\n", bb->id);
	    Punt("CheckSourceLink failed: error 4");
	}
    }
    CheckSourceLink(bb->next);
    return 0;
}
/*--------------------------------------------------------------------------*/
int ScaleFunctionWeight(fn, scale)
FuncDcl fn;
double scale;
{
    Block bb;
    ProfCS cs;
    ProfArc arc;
    if (fn==0) return;
    fn->profile.weight *= scale;
    for (cs=fn->profile.calls; cs!=0; cs=cs->next) {
	cs->weight *= scale;
    }
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	bb->profile.weight *= scale;
	for (arc=bb->profile.destination; arc!=0; arc=arc->next) {
	    arc->weight *= scale;
	}
    }
}
/*--------------------------------------------------------------------------*/
int LengthOfBLink(link)
BLink link;
{
    register int n = 0;
    register BLink l;
    for (l=link; l!=0; l=l->next) {
	n++;
    }
    return n;
}
/*--------------------------------------------------------------------------*/
VarDcl FindVarList(list, name)
VarList list;
char *name;
{
    register VarList l;
    if ((name==0) || (name[0]=='\0'))
	Punt("FindVarList: argument cannot be a NULL string"); /* 6-90 */
    for (l=list; l!=0; l=l->next) {
	char *nm = l->name;
    	if ((nm==0) || (nm[0]=='\0')) {
	    Punt("FindVarList: corrupted argument list"); /* 6-90 */
	}
	if (! strcmp(nm, name))
	    return l->var;
    }
    return 0;
}

VarList AddVar2List(list, var)
VarList list;
VarDcl var;
{
    register VarList new, l;
#ifdef TEST_VARLIST
  {
    VarList l;  int n=0;
    printf("-------------------------------------------------\n");
    printf("### List (before) = (\n");
    for (l=list; l!=0; l=l->next) {
	printf("(0x%x) ", l);
	fflush(stdout);
	printf("%s, ", l->name);
	n++;
	if ((n%3)==0) printf("\n");
	fflush(stdout);
    }
    printf(")\n");
  }
#endif
    if (FindVarList(list, var->name) != 0)
	return list;
    new = NewVarList();
    new->name = var->name;
    new->var = var;
    if (list==0) {
	list = new;
    } else {
    	l = list;
    	while (l->next!=0)
	    l = l->next;
    	l->next = new;
    }
#ifdef TEST_VARLIST
  {
    VarList l; int n=0;
    printf("### AddVar2List(%s, 0x%x)\n", new->name, new);
    printf("### List (after) = (\n");
    for (l=list; l!=0; l=l->next) {
	printf("(0x%x) ", l);
	fflush(stdout);
	printf("%s, ", l->name);
	n++;
	if ((n%3)==0) printf("\n");
	fflush(stdout);
    }
    printf(")\n");
  }
#endif
    return list;
}
/*--------------------------------------------------------------------------*/



