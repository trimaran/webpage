/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_init.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>


#undef DEBUG_FIX
#undef DEBUG_INIT

/*
 *	In this file, we will treat all initializers in a consistent
 *	manner. A final format will be guaranteed after applying the
 *	following functions.
 *	The IMPACT frontend automatically convert initializations of
 *	automatic variables into the body of functions. Therefore,
 *	we only need to worry about initialization of global/static
 *	variables.
 *
 *	In C, [K&R]
 *	1) An initializer is a list of initializers or a list of
 *		initializers nested in braces.
 *	2) All the expressions in the initializer for a static
 *		object or array must be constant expressions.
 *	3) A static object not explicitely initialized is initialized
 *		as if it (or its members) were assigned the constant 0.
 *	4) The initializer for a pointer or an object of arithmetic type
 *		is a single expression. Perhaps in braces.
 *	5) The initializer for a structure is either an expression of
 *		the same type, or a brace-enclosed list of initializers
 *		for its members in order. If there are fewer initializers
 *		in the list than members of the structure, the trailing
 *		members are initialized with 0. There may not be more
 *		initializers than members.
 *	6) The initializer for an array is a brace-enclosed list of
 *		initializers for its members. If the array has unknown
 *		size, the number of initializers determines the size
 *		of the array, and its type becomes complete. If the
 *		array has fixed size, the number of initializers may not
 *		exceed the number of members of the array; if there are
 *		fewer, the trailing members are initialzed with 0.
 *	7) As a special case, a character array may be initialized by
 *		a string literal. If the array has unknown size, the
 *		number of characters in the string, including the terminating
 *		null character, determines the size. If its size is fixed,
 *		the number of characters in the string, not counting the
 *		terminating null character, must not exceed the size of
 *		the array.
 *	8) The initializer for a union is either a single expression of
 *		the same type, or a brace-enclosed initializer for the
 *		first member of the union.
 *	9) An aggregate is a structure or array. If an aggregate contains
 *		members of aggregate type, the initialization rules apply
 *		recursively. Braces may be elided in the initialization
 *		as follows: if the initializer for an aggregate member
 *		that is itself an aggregate begins with a left brace, then
 *		the succeeding comma-separated list of initializers 
 *		initializes the members of the sbaggregate; it is erroneous
 *		for there to be more initializers than members. If, however,
 *		the initializer for a subaggregate does not begin with a
 *		left brace, then only enough elements from the list are taken 
 *		to account for the members of the subaggregate; any remaining
 *		members are left to initialize the next member of the aggregate
 *		of which the subaggregate is a part.	
 *
 *	The desirable final CCODE internal format:
 *	1) The initializer for a pointer or an object of arithmetic type
 *		is a single expression. (init->expr)
 *	2) The initializer for a structure is a list of initializers
 *		for its members. (init->set)
 *		f1 = init->set;
 *		f2 = init->set->next;
 *		f3 = init->set->next->next; ..... and so on.
 *	3) The initializer for a union is a set containing only one element.
 *		f1 = init->set;
 *	4) The initializer for an array is a list of initializers for its
 *		elements. (init->set)
 *		a[0] = init->set;
 *		a[1] = init->set->next;
 *		a[2] = init->set->next->next; ..... and so on.
 *	5) As a special case, a character array may be initialized by a
 *		string literal. (init->expr)
 *	6) !!! we do not allow initialization of union.
 */
char *VarName = "???";
static Punt(mesg)
char *mesg;
{
    fprintf(stderr, "illegal initialization of (%s)\n", VarName);
    fprintf(stderr, "because, %s\n", mesg);
    exit(-1);
}
static Punt2(mesg)
char *mesg;
{
    fprintf(stderr, "illegal initialization of (%s)\n", VarName);
    fprintf(stderr, "because, %s\n", mesg);
#ifndef DEBUG_INIT
    exit(-1);
#endif
}
/*-----------------------------------------------------------------------*/
/* 9-28-90 */
FixInitializerType(expr, type)
Expr expr;
Type type;
{
    Type otype;
    int t;
#ifdef DEBUG_FIX
printf("### FixType ");
Gen_C_Type(stdout, type);
Gen_C_Expr(stdout, expr);
printf("\n");
#endif
    if (type==0) return;
    if (type->dcltr!=0) return;
    t = type->type;
    /*
     *	we only repair very limited number of types.
     */
    switch (expr->opcode) {
    case OP_signed:
	if (IsRealType(type)) {
	    /* BCC - added OP_double - 8/5/96 */
	    expr->opcode = IsFloatType(type) ? OP_float : OP_double;
	    expr->value.real = expr->value.scalar;
	    otype = expr->type;
	    expr->type = CopyType(type);
	    RemoveType(otype);
	}
	break;
    case OP_unsigned:
	if (IsRealType(type)) {
	    /* BCC - added OP_double - 8/5/96 */
	    expr->opcode = IsFloatType(type) ? OP_float : OP_double;
	    expr->value.real = expr->value.uscalar;
	    otype = expr->type;
	    expr->type = CopyType(type);
	    RemoveType(otype);
	}
	break;
    case OP_float:
    /* BCC - added - 8/5/96 */
    case OP_double:
	if (IsIntegralType(type)) {
	    if (type->type & TY_UNSIGNED) {
	    	expr->opcode = OP_unsigned;
	    	expr->value.uscalar = expr->value.real;
	    } else {
	    	expr->opcode = OP_signed;
	    	expr->value.scalar = expr->value.real;
	    }
	    otype = expr->type;
	    expr->type = CopyType(type);
	    RemoveType(otype);
	} else
	if (IsRealType(type)) {
	    /* BCC - added - 8/5/96 */
	    expr->opcode = IsFloatType(type) ? OP_float : OP_double;
	    otype = expr->type;
	    expr->type = CopyType(type);
	    RemoveType(otype);
	}
	break;
    default:
	/* no change */
	break;
    }
}
/*-----------------------------------------------------------------------*/
/* TLJ 2/8/96 - modified so handles octal char representations correctly. */
static int HC_string(str, buf, buf_len)
char *str, buf[];
int buf_len;
{
    int i, length, k, octal_cnt;
    length = strlen(str) - 1;
    k = 0;
    for (i=1; i<length; i++) {
        if (k>buf_len)          /* buffer overflows */
            return k;
        if (str[i]=='\\') {
            i += 1;
            if (i==length)      /* this is not a good string */
                break;
            switch (str[i]) {
            case 'a':   buf[k] = '\a';          break;
            case 'b':   buf[k] = '\b';          break;
            case 'f':   buf[k] = '\f';          break;
            case 'n':   buf[k] = '\n';          break;
            case 'r':   buf[k] = '\r';          break;
            case 't':   buf[k] = '\t';          break;
            case 'v':   buf[k] = '\v';          break;
            case '\n':  k -= 1;                 break;
	    case '0':
	    case '1':
	    case '2':
	    case '3':
		sscanf(&str[i-1],"%o",&buf[k]);
		octal_cnt = 1;
		while (octal_cnt <= 3 && str[i+1] >= '0' && str[i+1] <= '7')
		{
		    octal_cnt++;
		    i++;
		}
		break;
	    case '4':
	    case '5':
	    case '6':
	    case '7':
		sscanf(&str[i-1],"%o",&buf[k]);
		octal_cnt = 1;
		while (octal_cnt <= 2 && str[i+1] >= '0' && str[i+1] <= '7')
		{
		    octal_cnt++;
		    i++;
		}
		break;
            default :   buf[k] = str[i];        break;
            }
            k += 1;
        } else {
            buf[k] = str[i];
            k += 1;
        }
    }
    buf[k] = '\0';
    return k;
}
/*-----------------------------------------------------------------------*/
Init FormatInit(type, init, nested)
Type type;
Init init;
int nested;
{
    Dcltr dcltr;
    Init new_init;
    if (type==0) Punt("internal error 0001");
    /*
     *	case 1: if there is no initializer, nothing should be done.
     */
    if (init==0) 
	return 0;
    /*
     *	case 2: see if the type is a structure.
     */
    dcltr = type->dcltr;
    if ((dcltr==0) && (type->type & (TY_STRUCT|TY_UNION))) {
	StructDcl st=0;
	Field field;
#ifdef DEBUG_INIT
printf("> see a structure %s\n", type->struct_name);
#endif
	if (type->type & TY_STRUCT) {
	    st = FindStruct(type->struct_name);
	    if (st==0) {
		fprintf(stderr, "> struct %s\n", type->struct_name);
		Punt("cannot initialize a struct before its body is defined");
	    }
	    field = st->fields;
	} else {
	    /*
	     *	Currently, we do not allow initialization of union.
	     */
	    Punt("union structure cannot be initialized");
	}
	if (init->set == 0) { /* need to pull out the first N elements */
	    Field f;
	    Init ptr, first, last;	
	    Init previous;
	    ptr = init;			/* follow the init list */
#ifdef DEBUG_INIT
printf("> the {} was elided\n");
#endif
	    /*
	     *	Recursively format each of the fields in the struct.
	     *	or until we run out of initializers.
	     */
	    first = last = 0;	/* the first and the last initializer */
	    previous = 0;
	    for (f=field; f!=0; f=f->next) {
		if (ptr==0) {
		    /* run out of initializers */
		    break;
		} else {
		    ptr = FormatInit(f->type, ptr, 1);
		    if ((previous!=0)&&(ptr!=previous->next)) {
			previous->next = ptr;
		    }
		    previous = ptr;
		    if (first==0) 	/* see if it is the first field */
			first = ptr;
		    last = ptr;		/* keep track of the last field */
		    ptr = ptr->next;
		}
	    }
	    if (first==0) {
		fprintf(stderr, "> cannot initialize an empty structure\n");
		Punt("there is no field to be initialized");
	    }
	    new_init = NewInit();
	    new_init->next = last->next;
	    last->next = 0;
	    new_init->set = first;
	    return new_init;
	} else {
	    Field f;
	    Init ptr, first, last, previous;	
#ifdef DEBUG_INIT
printf("> the {} was there\n");
#endif
	    /*
	     *	Remove the outer bracket.
	     *	Assume, immediately within the brancket is the
	     *	initializer for the first field.
	     */
	    ptr = init->set;		/* follow the init list */
	    /*
	     *	Recursively format each of the fields in the struct.
	     *	or until we run out of initializers.
	     */
	    first = last = 0;	/* the first and the last initializer */
	    previous = 0;
	    for (f=field; f!=0; f=f->next) {
		if (ptr==0) {
		    /* run out of initializers */
		    break;
		} else {
		    ptr = FormatInit(f->type, ptr, 1);
		    if ((previous!=0)&&(ptr!=previous->next)) {
			previous->next = ptr;
		    }
		    previous = ptr;
		    if (first==0) 	/* see if it is the first field */
			first = ptr;
		    last = ptr;		/* keep track of the last field */
		    ptr = ptr->next;
		}
	    }
	    if (first==0) {
		fprintf(stderr, "> cannot initialize an empty structure\n");
		Punt("there is no field to be initialized");
	    }
	    if (ptr!=0) {
	  	Punt("number of initializers exceeds the number of fields");
	    }
	    init->set = first;
	    return init;
	}
    }
    /*
     *	case 2: see if the type is a simple type. (pointer/arithmetic)
     */
    if ((dcltr==0) || (dcltr->method==D_PTR)) {
	Init next_init;
	/*
	 * Then the result should be (init->expr)
	 * But since it is possible, the user may put braces around
	 * the single expression, we need to move it up.
	 */
	if (init->expr!=0) {
	    if (init->set!=0) Punt("internal error 0002");
	} else {
	    next_init = init->next;/* make sure that init->next is preserved */
	    while (init->set!=0) {
	    	init = init->set;
	    	if (init->expr!=0) {
		    init->next = next_init;
		    break;
		}
	    }
	} 
	/* 6-28-90: promote initializer type */
	if (init->expr!=0) {
	    FixInitializerType(init->expr, type);
	}
	return init;
    } 
    /*
     *	case 3: it is illegal to initialize a function.
     */
    if (dcltr->method==D_FUNC)
	Punt("it is illegal to initialize a function");
    /*
     *	case 4: initialization of an array.
     *	cannot initialized undimensioned array in the nested level.
     *  e.g.
     *	    struct {
     *		int a[];
     *		char b;
     *	    };
     */
    if (dcltr->method==D_ARRY) {
	if ((dcltr->index==0) && nested) {
	    Punt("cannot initialize an undimensioned array in an aggregate");
	}
	/*
	 *  Take care of the special case of character array.
	 */
	if ((dcltr->next==0) && (type->type&TY_CHAR) &&
	    (init->expr!=0) && (init->expr->opcode==OP_string)) {
             /* GEH - combined both if's into one, fixed bug - 9/7/94 */

#ifdef DEBUG_INIT
printf("see a character array\n");
#endif
	/*  if (init->expr!=0) { */
	    	Expr string;
		int length;
		/* BCC - extended the following 1204's to 2500 - 6/27/96 */
		char buffer[2500];
		string = init->expr;
		/* GEH - no longer needed */
		/* 
		if (string->opcode != OP_string)
		    Punt("illegal character array initialization");
		*/
		length = HC_string(string->value.string, buffer, 2500);
		if (length>=2500) 
		    Punt("string must be fewer than 2500 characters");
		/*
		 *  If the array dimension is still undefined,
		 *  set it to (length+1).
		 */
		if (dcltr->index==0) {
#ifdef DEBUG_INIT
printf("define its size to %d\n", length+1);
#endif
		    dcltr->index = NewIntExpr(length+1);
		} else { /* GEH - added string length bound check - 9/7/94 */
		  Expr sz;
		  sz = ReduceExpr(dcltr->index);
		  /* BCC - use temporary IsIntegralExprForArray - 5/24/95 */
		  if (! IsIntegralExprForArray(sz))
		    Punt("cannot reduce array size to a constant number");
		  /* BCC - use temporary IntegralExprValueForArray - 5/24/95 */
		  if (length+1>IntegralExprValueForArray(sz))
		    Punt("string initializer too long for a bounded character array");
		  RemoveExpr(sz);
		}

		/*
		 *  The format is fine, just return it as is.
		 */
		return init;
	    /* GEH - don't need anymore, handled below */
#if 0
	    } else {
	    	Init ptr, new;
		int length = 0;
	 	type->dcltr = 0;
		for (ptr=init->set; ptr!=0; ptr=ptr->next) {
		    /*
		     *	Make sure all initializers are single
		     *	expressions.
		     */
		    new = FormatInit(type, ptr, 1);
		    if (new!=ptr) {
			Punt("illegal character string initializer");
		    }
		    length += 1;
		}
		type->dcltr = dcltr;
		/*
		 *  If the array dimension is still undefined,
		 *  set it to (length).
		 */
		if (dcltr->index==0)
		    dcltr->index = NewIntExpr(length);
		/*
		 *  The format is fine, just return it as is.
		 */
		return init;
	    }
#endif
	} else
	if (init->set == 0) {	/* when braces are elided */
	    Expr size;
	    int s, i;
	    Init new_init, ptr, last, first;
	    Init previous;
	    /*
	     *	It is illegal to initialize an undimensioned array
	     *	without a bracketes list.
	     */
	    if (dcltr->index==0) {
		fprintf(stderr, "it is not legal to initialize an ");
		fprintf(stderr, "undimensioned array with unbracketed ");
		fprintf(stderr, "initializer list.\n");
		fprintf(stderr, "the format of the initializer is incorrect.");
	    }
	    size = ReduceExpr(dcltr->index);
	    /* BCC - use temporary IsIntegralExprForArray - 5/24/95 */
	    if (! IsIntegralExprForArray(size)) {
		fprintf(stderr, "non-constant array size\n");
		Punt("failed to reduce the array size to a constant number");
	    }
	    /* BCC - use temporary IntegralExprValueForArray - 5/24/95 */
	    s = IntegralExprValueForArray(size);
	    RemoveExpr(size);
	    /*
	     *	Get the first (s) elements from the init list.
	     */
	    type->dcltr = dcltr->next;	/* fake the element's type */
	    first = last = 0;
	    ptr = init;
	    previous = 0;
	    for (i=0; i<s; i++) {
		if (ptr==0) {
		    /* run out of initializers */
		    break;
		} else {
		    ptr = FormatInit(type, ptr, 1);
		    if ((previous!=0)&&(ptr!=previous->next)) {
			previous->next = ptr;
		    }
		    previous = ptr;
		    if (first==0) first = ptr;
		    last = ptr;
		    ptr = ptr->next;
		}
	    }
	    if (first==0) {
		Punt("internal error 0006");
	    }
	    type->dcltr = dcltr;	/* recover the original type */
	    new_init = NewInit();
	    new_init->next = last->next;
	    last->next = 0;
	    new_init->set = first;
	    return new_init;
	} else {		/* the neat programmer's format */
	    int N;
	    Init ptr, first, last, previous;
	    ptr = init->set;		/* follow the init list */
	    /*
	     *	Apply recursively to each element.
	     */
	    type->dcltr = dcltr->next;	/* fake the element's type */
	    first = last = 0;
	    N = 0;
	    previous = 0;
	    while (ptr!=0) {
		ptr = FormatInit(type, ptr, 1);
		if ((previous!=0)&&(ptr!=previous->next)) {
		    previous->next = ptr;
		}
		previous = ptr;
		if (first==0)
		    first = ptr;
		last = ptr;
		ptr = ptr->next;
		N += 1;
	    }
	    type->dcltr = dcltr;	/* recover to the original type */
	    if (first==0) {
		Punt("internal error 0005");
	    }
	    if (dcltr->index==0) {
		/*
		 *  Now, we know the size.
		 */
		dcltr->index = NewIntExpr(N);
	    } else {
		Expr sz;
		sz = ReduceExpr(dcltr->index);
		/* BCC - use temporary IsIntegralExprForArray - 5/24/95 */
		if (! IsIntegralExprForArray(sz))
		    Punt("cannot reduce array size to a constant number");
		/* BCC - use temporary IntegralExprValueForArray - 5/24/95 */
		if (N>IntegralExprValueForArray(sz))
		    Punt("too many initializers for a bounded array");
		RemoveExpr(sz);
	 	/* 
		 *  Otherwise, it is fine.
		 */
	    }
	    init->set = first;
	    return init;
	}
    }
    Punt("internal error 0004");
    return 0;
}
/*-----------------------------------------------------------------------*/
CheckInitFormat(type, init)
Type type;
Init init;
{
    Dcltr dcltr;
    if (type==0) return;
    if (init==0) return;
    dcltr = type->dcltr;
    if ((dcltr==0) && (type->type & (TY_UNION|TY_STRUCT))) {
	Field field;
	Init ptr;
	if (init->expr != 0)
	    Punt2("CheckInitFormat: internal error 0001");
	if (init->set == 0)
	    Punt2("CheckInitFormat: internal error 0002");
	if (type->type & TY_UNION) {
	    /*
	     *	Currently, we do not allow initialization of union.
	     */
	    Punt("union structure cannot be initialized");
	    Punt2("CheckInitFormat: internal error 0003");
	} else {
	    StructDcl st;
	    st = FindStruct(type->struct_name);
	    if (st==0)
		Punt2("CheckInitFormat: internal error 0004");
	    field = st->fields;
	}
	for (ptr=init->set; ptr!=0; ptr=ptr->next) {
	    if (field==0)
	    	Punt2("CheckInitFormat: internal error 0005");
	    CheckInitFormat(field->type, ptr);
	    field = field->next;
	}
    } else
    if ((dcltr==0) || (dcltr->method==D_PTR)) {
	if (init->expr==0)
	    Punt2("CheckInitFormat: internal error 0006");
	if (init->set!=0)
	    Punt2("CheckInitFormat: internal error 0007");
    } else
    if (dcltr->method==D_ARRY) {
	if ((dcltr->next==0) && (type->type&TY_CHAR)) {
	    if (init->expr!=0) {
		if (init->expr->opcode != OP_string)
	    	    Punt2("CheckInitFormat: internal error 0008");
	    } else {
		Init p;
		if (init->set==0)
	    	    Punt2("CheckInitFormat: internal error 0009");
		for (p=init->set; p!=0; p=p->next) {
		    if (p->expr==0)
	    	    	Punt2("CheckInitFormat: internal error 0010");
		    if (p->set!=0)
	    	    	Punt2("CheckInitFormat: internal error 0011");
		}
	    }
	} else {
	    Init element;
	    if (init->expr!=0)
	    	Punt2("CheckInitFormat: internal error 0012");
	    if (init->set==0)
	    	Punt2("CheckInitFormat: internal error 0013");
	    type->dcltr = dcltr->next;	/* fake the element's type */
	    for (element=init->set; element!=0; element=element->next) {
		CheckInitFormat(type, element);
	    }
	    type->dcltr = dcltr;	/* recover the original type */
	}
    } else
    if (dcltr->method==D_FUNC) {
	Punt2("CheckInitFormat: cannot initialize a function");
    } else {
	Punt2("CheckInitFormat: unknown dcltr");
    }
}
/*-----------------------------------------------------------------------*/
ProcessInit(var)
VarDcl var;
{
    Init init;
    Type type;
    if (var==0) return;
#ifdef DEBUG_INIT
printf("> var %s\n", var->name);
#endif
    init = var->init;
    if (init==0) return;
#ifdef DEBUG_FIX
printf("> var %s\n", var->name);
#endif
    type = var->type;
    VarName = var->name;	/* for reporting clear error messages */
    var->init = FormatInit(type, init, 0);
    CheckInitFormat(type, var->init);
}
/*-----------------------------------------------------------------------*/


