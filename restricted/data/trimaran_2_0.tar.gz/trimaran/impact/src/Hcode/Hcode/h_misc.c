/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.31  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 21, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_misc.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Revised: Scott Mahlke 5-94
\*****************************************************************************/
#include "h_main.h"


/*===========================================================================*/
/*
 *	Hcode parameters
 */
/*===========================================================================*/

char *H_arch="impact";
char *H_model="v1.0";
char *H_lmdes_file_name=NULL;

int H_nice_value=10;
char *H_output_form_name=NULL;

/* If yes, inserts *unnecessary* type conversion code which prevents Lopti
 * from making type-unaware optimizations at the expense of
 * generating very serial, stupid, and slow code for those cases.
 * This is the quick, but not best, way to make Lopti handle corner
 * cases properly.  
 */
int H_conservative_type_promotion = 0; /* -JCG 6/99 */

int H_do_flatten=0;		/* remove && || ?: */
int H_do_trace_selection=0;	/* trace selection optimization */
int H_trace_selection_method=2;	/* method to do trace selection, see h_trace_opti.c */
int H_do_constant_folding=0;	/* evaluate expression with all constant operands */
int H_do_insert_profile_probes=0;
int H_do_merge_profile=0;
int H_profile_starting_fn_id=0;
char *H_profile_database_file=NULL;
double H_profile_multiplier = 1.0; /* Scales hcode profile - JCG 2/14/95 */




int H_use_static_weights = 0;	/* JCG 7/12/95 Normally no */
/* JCG 7/12/95 to facilitate static profiling need a list of funcs 
 * we have the source for (gen_Hmerge generates this file using a grep)
 */
char *H_func_list_name = "func_list";

int H_debug_yes=0;		/* do all checks */
int H_verbose_yes=0;		/* print debugging messages */
int H_generate_control_flow_file=0;
int H_generate_data_flow_file=0;



/*===========================================================================*/
/*
 *	Hcode global variables
 */
/*===========================================================================*/

char *F_input=NULL;		/* program input */
FILE *Fin=NULL;
char *F_output=NULL;		/* program output */
FILE *Fout=NULL;
char *F_error=NULL;		/* error log */
FILE *Ferr=NULL;

int H_output_form=OUTPUT_NONE;	/* the style of the output */
int H_ext_option = 0;		/* output additional information */
char *H_parm_file = NULL;
int H_dat_format = DAT_LITTLE_ENDIAN;

/*=======================================================================*/
/*
 *      Error handling rountines 
 */
/*=======================================================================*/

char *H_curr_pass_name = NULL;

void H_punt(char *fmt, ...)
{
    va_list     args;

    fprintf(stderr, "Error while %s was processing %s:\n    ",
                H_curr_pass_name, F_input);
    va_start (args, fmt);
    vfprintf (stderr, fmt, args);
    va_end(args);
    fprintf (stderr,"\n");
    exit(-1);
}

/*===========================================================================*/
/*
 *	Hcode parameter reading 
 */
/*===========================================================================*/

void H_read_parm_arch (Parm_Parse_Info *ppi)
{
        /* See if read parameter matches one of the defined parameters */

    L_read_parm_s(ppi, "arch", &H_arch);
    L_read_parm_s(ppi, "model", &H_model);
    L_read_parm_s(ppi, "lmdes", &H_lmdes_file_name);

}

void H_read_parm_file (Parm_Parse_Info *ppi) {
        /* See if read parameter matches one of the defined parameters */

    L_read_parm_s(ppi, "input_file_name", &F_input);
    L_read_parm_s(ppi, "output_file_name", &F_output);
    L_read_parm_s(ppi, "filelist_file_name", &F_output);

}

void H_read_parm_Hcode(Parm_Parse_Info *ppi)
{
    /* Added to aid debugging  JCG 7/12/95 */
    L_read_parm_b(ppi, "?dump_parms", &L_dump_parms);
    L_read_parm_s(ppi, "?parm_dump_file_name", &L_parm_dump_file_name);

    L_read_parm_i(ppi, "nice_value",&H_nice_value);
    L_read_parm_s(ppi, "output_form",&H_output_form_name);
    L_read_parm_b(ppi, "conservative_type_promotion", 
		  &H_conservative_type_promotion); 
    L_read_parm_b(ppi, "do_flatten",&H_do_flatten);
    L_read_parm_b(ppi, "do_trace_selection",&H_do_trace_selection);
    L_read_parm_i(ppi, "trace_selection_method", &H_trace_selection_method);
    L_read_parm_b(ppi, "do_constant_folding",&H_do_constant_folding);
    L_read_parm_b(ppi, "do_insert_profile_probes",&H_do_insert_profile_probes);
    L_read_parm_b(ppi, "do_merge_profile",&H_do_merge_profile);
    L_read_parm_i(ppi, "profile_starting_fn_id",&H_profile_starting_fn_id);
    L_read_parm_s(ppi, "profile_database_file", &H_profile_database_file);
    L_read_parm_lf(ppi, "profile_multiplier", &H_profile_multiplier);
    L_read_parm_b(ppi, "?use_static_weights", &H_use_static_weights);
    L_read_parm_s(ppi, "?func_list_name", &H_func_list_name);
    L_read_parm_b(ppi, "debug_yes",&H_debug_yes);
    L_read_parm_b(ppi, "verbose_yes",&H_verbose_yes);
    L_read_parm_b(ppi, "generate_control_flow_file",
                                        &H_generate_control_flow_file);
    L_read_parm_b(ppi, "generate_data_flow_file",
                                        &H_generate_data_flow_file);
}
