/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_prag.c
 *	Author:	Grant Haab and Wen-mei Hwu
 *	Revised: 
\*****************************************************************************/
#include <assert.h>
#include <Hcode/h_main.h>
#include <library/c_basic.h>

/*
 * Functions for generating and reading Hcode pragmas which are automatically 
 * converted to Lcode attributes.
 *
 *  Make the following assumption for pragma format
 *  since pragma only has string component:
 *
 *          pragma->specifier = \"<name><field>*\"
 *          <field> = \$<string> |
 *                    \!<label> |
 *                    \%<integer> |
 *                    \#<real>
 *
 *  <name> must be a valid Lcode identifier and becomes the attribute name.
 *
 *  <string> must be a string which does not contain any pragma delimiter: 
 *           {\$,\!,\%,\#} and becomes a string attribute field.
 *
 *  <label> must be a valid Lcode identifier and becomes a label attribute 
 *          field.
 *
 *  <integer> becomes an integer attribute field.
 *
 *  <real> becomes a double (floating-point) attribute field.
 * 
 *  Fields are converted to attribute field of appropriate type during Lcode
 *  generation.
 */

static char *HC_find_invalid_char_for_Lcode_ident(char *string)
{
    return strpbrk(string, "#{}()<>[] \b\f\n\r\t\v");
}

static int HC_num_prefix_backslashes(char *string, char *pos)
{
    int i;

    assert(string <= pos);
    for (i=-1; pos+i >= string && pos[i] == '\\'; i--);
    return -(i+1);
}

static char *HC_find_first_pragma_delimiter(char *string)
{
    char *delim, *first = string+strlen(string);

    delim = C_strstr(string, "\\$");
    if (delim != NULL && delim < first &&
        (HC_num_prefix_backslashes(string, delim) % 2 == 0))
        first = delim;

    delim = C_strstr(string, "\\!");
    if (delim != NULL && delim < first &&
        (HC_num_prefix_backslashes(string, delim) % 2 == 0))
        first = delim;

    delim = C_strstr(string, "\\%");
    if (delim != NULL && delim < first &&
        (HC_num_prefix_backslashes(string, delim) % 2 == 0))
        first = delim;

    delim = C_strstr(string, "\\#");
    if (delim != NULL && delim < first &&
        (HC_num_prefix_backslashes(string, delim) % 2 == 0))
        first = delim;

    return (first == string+strlen(string)) ? NULL : first;
}


/**********************/
/* Exported Functions */
/**********************/


/* 
 * Write pragma name into pragma string.  Signal error if pragma delimiters
 * are present in name or if name is not a valid Lcode identifier.
 */
void HC_write_name_to_pragma_str(char *pragma, char *name)
{
    char *delim;
    char errmsg[256];

    if (delim = HC_find_first_pragma_delimiter(name)) {
        sprintf(errmsg, "Pragma name contains \"%s\" delimiter.", delim);
        Punt(errmsg);
    }

    if ((delim = HC_find_invalid_char_for_Lcode_ident(name)) != NULL) {
        sprintf(errmsg,
                "Pragma name \"%s\"\n\tcontains invalid character '%c' for Lcode identifier",
                name, delim[0]);
        Punt(errmsg);
    }

    strcpy(pragma, name);
}

/*
 * Append string attribute field to pragma string.  Signal error if pragma 
 * delimiters are present in string.
 */
void HC_append_string_to_pragma_str(char *pragma, char *string)
{
    char *delim;
    char errmsg[80];

#if 0
    /* In order to enhance the usefulness of pragmas, now allow
     * delimiters to be embedded in the strings. -JCG 6/99
     */
    if (delim = HC_find_first_pragma_delimiter(string)) {
	delim[2] = '\0';
        sprintf(errmsg, "Pragma string contains \"%s\" delimiter.", delim);
        Punt(errmsg);
    }
#endif

    sprintf(pragma+strlen(pragma), "\\$%s", string);
}

/*
 * Append label attribute field to pragma string.  Signal error if pragma 
 * delimiters are present in label or if label is not a valid Lcode identifier.
 */
void HC_append_label_to_pragma_str(char *pragma, char *label)
{
    char *delim;
    char errmsg[256];

    if ((delim = HC_find_invalid_char_for_Lcode_ident(label)) != NULL) {
        sprintf(errmsg,
                "Pragma label \"%s\"\n\tcontains invalid character '%c' for Lcode identifier",
                label, delim[0]);
        Punt(errmsg);
    }

    if (delim = HC_find_first_pragma_delimiter(label)) {
        sprintf(errmsg, "Pragma label contains \"%s\" delimiter.", delim);
        Punt(errmsg);
    }

    sprintf(pragma+strlen(pragma), "\\!%s", label);
}

/*
 * Append integer attribute field to pragma string.
 */
void HC_append_int_to_pragma_str(char *pragma, long int integer)
{
    sprintf(pragma+strlen(pragma), "\\%%%ld", integer);
}

/*
 * Append double attribute field to pragma string.
 */
void HC_append_real_to_pragma_str(char *pragma, double real)
{
/* GEH - added one more significant digit to prevent rounding error 4-27-95 */
    sprintf(pragma+strlen(pragma), "\\#%1.16e", real);
}

/* 
 * Returns attribute name in 'name' formal parameter.  
 * 'Name' parameter must contain enough buffer space for attribute name.
 * Returns pointer to remaining pragma string as function return value.
 */
char *HC_read_attr_name_from_pragma_str(char *pragmastr, char *name)
{
    char *delim, *inval, save;
    char errmsg[256];
    assert(pragmastr != NULL && pragmastr[0] == '\"');

    delim = HC_find_first_pragma_delimiter(pragmastr);
    if (delim) {
	save = delim[0];
	delim[0] = '\0';
    }

    if ((inval = strpbrk(pragmastr, "#{}()<>[] \b\f\n\r\t\v")) != 0) {
        sprintf(errmsg,
            "Pragma name \"%s\" contains invalid character ascii=%d (%c) for Lcode identifier",
                pragmastr, inval[0], inval[0]);
        Punt(errmsg);
    }
    strcpy(name, pragmastr+1); /* skip '\"' prefix */

    if (delim) delim[0] = save;
    else if (name[strlen(name)-1] == '\"') name[strlen(name)-1] = '\0';
	/* remove trailing '\"' from pragma string if no attr fields */
   
    return delim;
}

/*
 * Returns pointer to attribute field in one of 'string', 'integer', 
 * or 'real' formal parameters.  Attribute field type returned by 'type'
 * parameter which contains pointer to delimiter string.  Both 'label' and
 * 'string' attribute fields are returned in 'string' formal parameter.
 * 'String' parameter must contain enough buffer space to copy the field into.
 * Returns pointer to remaining pragma string as function return value.
 */
char *HC_read_attr_field_from_pragma_str(char *pragmastr, char *string, 
			    		 long int *integer, double *real, 
					 char **delim_type)
{
    char *delim1, *delim2, *inval, errmsg[256], save;
    int end;

    assert(pragmastr != NULL);    
    delim1 = HC_find_first_pragma_delimiter(pragmastr);

    if (delim1 != pragmastr)
	Punt("Pragma string must begin with delimiter to read attr field");

    delim2 = HC_find_first_pragma_delimiter(&delim1[2]);
    if (delim2) {
	save = delim2[0];
	delim2[0] = '\0';
    }

    switch (delim1[1]) {
      case '$':
	string[0] = '\"';
        strcpy(string+1, &delim1[2]);
        if (string[(end = strlen(string))-1] != '\"' || delim2) {
	    string[end] = '\"';		/* add trailing quote */
	    string[end+1] = '\0';
	}
        break;

      case '!':
	if ((inval = strpbrk(&delim1[2], "#{}()<>[] \b\f\n\r\t\v")) != 0) {
	    sprintf(errmsg,
		    "Pragma label-field \"%s\"\n\tcontains invalid character ascii=%d (%c) for Lcode label attr",
		    &delim1[2], inval[0], inval[0]);
	    Punt(errmsg);
	}
        strcpy(string, &delim1[2]);
        if (!delim2 && string[strlen(string)-1] == '\"')
	    string[strlen(string)-1] = '\0';	/* remove trailing quote */
        break;

      case '%':
	if (!sscanf(&delim1[2], "%ld", integer))
	    Punt("Empty integer attr field in pragma string");
	break;

      case '#':
	if (!sscanf(&delim1[2], "%le", real))
	    Punt("Empty double attr field in pragma string");
	break;

      default:
	Punt("Internal error: unknown pragma delimiter type");
    }

    if (delim2) delim2[0] = save;
    *delim_type = delim1;
    return delim2;
}

