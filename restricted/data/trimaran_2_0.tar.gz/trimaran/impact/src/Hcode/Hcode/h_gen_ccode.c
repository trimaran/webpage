/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.30  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 14, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_gen_ccode.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Modified by:  Nancy Warter
\*****************************************************************************/
#include <Hcode/h_main.h>


static int do_output = 1;
#define OUTPUT		do_output
#define DO_OUTPUT(x)	(do_output = x)
#define BLOCK_OUTPUT	(do_output == 0)

static GenExpr();
static GenParamDataDcl();
static GenLocalDataDcl();
static GenDcltr();	/* BCC - forward - 1/25/96 */

static FILE *F = NULL;

/* EXPORT FUNCTION :
 *	Gen_CCODE_Include(F, file) char *file;
 *	Gen_CCODE_LinePos(F, n, file) int n; char *file;
 *	Gen_CCODE_Struct(F, st) Struct st;
 *	Gen_CCODE_Union(F, un) Union un;
 *	Gen_CCODE_Enum(F, en) Enum en;
 *	Gen_CCODE_Var(F, var) VarDcl var;
 *	Gen_CCODE_Func(F, fn) FuncDcl fn;
 */
/*========================================================================*/

/*========================================================================*/
static Punt(mesg)
char *mesg;
{
	fprintf(stderr, "# gen_ccode: %s\n", mesg);
	exit(-1);
}
/*========================================================================*/
/* print type information. */
static GenType(type, option)
Type type;
int option;	/* 0 : print no class, 1 : print class */
{
	int t;
	if (type==0) return;
	t = type->type;
	if (t==0) {
	    fprintf(F, "TYPE_LESS ");
	    return;
	}
	/* storage class */
	if (option!=0) {
		/* class */
		if (t & TY_REGISTER) fprintf(F, "(REGISTER)");
		if (t & TY_STATIC) fprintf(F, "(STATIC)");
		if (t & TY_EXTERN) fprintf(F, "(EXTERN)");
		if (t & TY_AUTO) fprintf(F, "(AUTO)");
		if (t & TY_GLOBAL) fprintf(F, "(GLOBAL)");
		if (t & TY_PARAMETER) fprintf(F, "(PARAMETER)");
		/* qualifier */
		if (t & TY_CONST) fprintf(F, "(CONST)");
		if (t & TY_VOLATILE) fprintf(F, "(VOLATILE)");
		if (t & TY_NOALIAS) fprintf(F, "(NOALIAS)");
	}
	/* type */ 
	if (t & TY_SIGNED) fprintf(F, "(SIGNED)");
	if (t & TY_UNSIGNED) fprintf(F, "(UNSIGNED)");
	if (t & TY_VOID) fprintf(F, "(VOID)");
	if (t & TY_SHORT) fprintf(F, "(SHORT)");
	if (t & TY_LONG) fprintf(F, "(LONG)");
	if (t & TY_CHAR) fprintf(F, "(CHAR)");
	if (t & TY_INT) fprintf(F, "(INT)");
	if (t & TY_FLOAT) fprintf(F, "(FLOAT)");
	if (t & TY_DOUBLE) fprintf(F, "(DOUBLE)");
	if (t & TY_STRUCT) fprintf(F, "(STRUCT %s)", type->struct_name);
	if (t & TY_UNION) fprintf(F, "(UNION %s)", type->struct_name);
	/* BCC - temporary fix, change enum type to int    5/23/95 */
	/* if (t & TY_ENUM) fprintf(F, "(ENUM %s)", type->struct_name); */
	if (t & TY_ENUM) fprintf(F, "(INT)");
	if (t & TY_VARARG) fprintf(F, "(VARARG)");   /* BCC - added - 1/24/96 */
}

/* BCC - 1/22/96 */
static GenParamTypeList(param)
     Param param;
{
    fprintf(F, " (");
    while (param) {
	fprintf(F, "(FPARAM (");
	GenType(param->type);
	GenDcltr(param->type->dcltr, 0);
	fprintf(F, "))");
	param = param->next;
    }
    fprintf(F, ")");
}

static GenDcltr(dcltr)
Dcltr dcltr;
{
    fprintf(F, "(");
    while (dcltr!=0) {
        switch (dcltr->method) {
        case D_ARRY:
            if (dcltr->index!=0) {
                fprintf(F, "(A ");
                GenExpr(dcltr->index);
                fprintf(F, ")");
            } else {
                fprintf(F, "(A)");
            }
            if (dcltr->next!=0) fprintf(F, " ");
            break;
        case D_PTR:
            if (dcltr->qualifier!=0) fprintf(F, "(");
            fprintf(F, "P");
            /* GEH - print out pointer qualifiers */
            if (dcltr->qualifier & DQ_CONST) fprintf(F, " CONST");
            if (dcltr->qualifier & DQ_VOLATILE) fprintf(F, " VOLATILE");
            if (dcltr->qualifier!=0) fprintf(F, ")");
            if (dcltr->next!=0) fprintf(F, " ");
            break;
        case D_FUNC:
#if 0
            fprintf(F, "F");
            if (dcltr->next!=0) fprintf(F, " ");
#endif
            /*
             * BCC - 1/22/96
             * Changed the format of a function declarator from "F" to
             * "(F (..) (..))" where "(..)" is the type of the parameters.
             */
            fprintf(F, "(F");

            /* GEH - print out function qualifiers */
            if (dcltr->qualifier & DQ_CDECL) fprintf(F, " CDECL");
            if (dcltr->qualifier & DQ_STDCALL) fprintf(F, " STDCALL");
            if (dcltr->qualifier & DQ_FASTCALL) fprintf(F, " FASTCALL");

            if (dcltr->param!=0)
                GenParamTypeList(dcltr->param);
            fprintf(F, ")");
            if (dcltr->next!=0) fprintf(F, " ");
            break;
        default:
            Punt("illegal dcltr");
        }
        dcltr = dcltr->next;
    }
    fprintf(F, ")");
}
/*========================================================================*/
static GenOpcode(opcode)
int opcode;
{
    switch (opcode) {
/* NJW */
    case OP_sync :		fprintf(F, "sync ");	break;
/* WJN */
    /* LCW - 10/24/96 */
    case OP_nulldefine :        fprintf(F, "nulldefine ");	break;
    case OP_quest :		fprintf(F, "quest ");	break;
    case OP_disj :		fprintf(F, "disj ");	break;
    case OP_conj :		fprintf(F, "conj ");	break;
    case OP_comma :		fprintf(F, "comma ");	break;
    case OP_assign :	fprintf(F, "assign ");	break;
    case OP_or :		fprintf(F, "or ");	break;
    case OP_xor :		fprintf(F, "xor ");	break;
    case OP_and :		fprintf(F, "and ");	break;
    case OP_eq :		fprintf(F, "eq ");	break;
    case OP_ne :		fprintf(F, "ne ");	break;
    case OP_lt :		fprintf(F, "lt ");	break;
    case OP_le :		fprintf(F, "le ");	break;
    case OP_ge :		fprintf(F, "ge ");	break;
    case OP_gt :		fprintf(F, "gt ");	break;
    case OP_rshft :		fprintf(F, "rshft ");	break;
    case OP_lshft :		fprintf(F, "lshft ");	break;
    case OP_add :		fprintf(F, "add ");	break;
    case OP_sub :		fprintf(F, "sub ");	break;
    case OP_mul :		fprintf(F, "mul ");	break;
    case OP_div :		fprintf(F, "div ");	break;
    case OP_mod :		fprintf(F, "mod ");	break;
    case OP_neg :		fprintf(F, "neg ");	break;
    case OP_not :		fprintf(F, "not ");	break;
    case OP_inv :		fprintf(F, "inv ");	break;
    case OP_abs :		fprintf(F, "abs ");	break;
    case OP_preinc :	fprintf(F, "preinc ");	break;
    case OP_predec :	fprintf(F, "predec ");	break;
    case OP_postinc :	fprintf(F, "postinc ");	break;
    case OP_postdec :	fprintf(F, "postdec ");	break;
    case OP_Aadd :		fprintf(F, "Aadd ");	break;
    case OP_Asub :		fprintf(F, "Asub ");	break;
    case OP_Amul :		fprintf(F, "Amul ");	break;
    case OP_Adiv :		fprintf(F, "Adiv ");	break;
    case OP_Amod :		fprintf(F, "Amod ");	break;
    case OP_Arshft :	fprintf(F, "Arshft ");	break;
    case OP_Alshft :	fprintf(F, "Alshft ");	break;
    case OP_Aand :		fprintf(F, "Aand ");	break;
    case OP_Aor :		fprintf(F, "Aor ");	break;
    case OP_Axor :		fprintf(F, "Axor ");	break;
    case OP_indr :		fprintf(F, "indr ");	break;
    case OP_addr :		fprintf(F, "addr ");	break;
    case OP_index :		fprintf(F, "index ");	break;
    case OP_call :		fprintf(F, "call ");	break;
    case OP_dot :		fprintf(F, "dot ");	break;
    case OP_arrow :		fprintf(F, "arrow ");	break;
	case OP_var :	
	case OP_enum :
	case OP_signed :
	case OP_unsigned :
	case OP_float :
	/* BCC - added - 8/5/96 */
	case OP_double :
	case OP_char :
	case OP_string :
	case OP_cast :	
	case OP_expr_size :
	case OP_type_size :	
	case OP_return :
	case OP_goto :
	case OP_if :
	case OP_switch :
			Punt("no opcode for this instruction");
			break;
	default :
		Punt("GenOpcode : illegal opcode");
	}
}
static GenExprPragma(pragma)
Pragma pragma;
{
    DepInfo dep_info;

    for (; pragma!=0; pragma=pragma->next) {
	if (strcmp (pragma->specifier,"\"DEP\"") )
	    fprintf(F, " (EXPR_PRAGMA %s)", pragma->specifier);
	else {
	    dep_info = pragma->dep_info;
	    fprintf(F, " (EXPR_PRAGMA %s (%d %c%c %d %d))", 
			pragma->specifier, dep_info->num, dep_info->certainty,
			dep_info->freq, dep_info->dist, dep_info->flags);
	}
    }
}
/* generate expression. */
static GenExpr(expr)
Expr expr;
{
	int opcode, n;
	Expr arg;
	if (expr==0) Punt("GenExpr : nil expr");
	/*
	 *	print expressions.
	 */
	switch (opcode=expr->opcode) {
	case OP_var :
		fprintf(F, "(var %s", expr->value.var_name); 
		    /* DMG */
		if (expr->pragma!=0) 
		    GenExprPragma(expr->pragma);
		fprintf(F, ")");
		break;
	case OP_enum :
	/* BCC - temporary fix, print constant instead of enum field 5/23/95 */
	/*	fprintf(F, "(enum %s)", expr->value.string); break;          */
		fprintf(F, "(signed %d)", HC_enum(expr->value.string));	break;
	case OP_signed :
		fprintf(F, "(signed %d)", expr->value.scalar);	break;
	case OP_unsigned :
		fprintf(F, "(unsigned %u)", expr->value.uscalar); break;
	case OP_float :
/*** SAM 9-24-91
		fprintf(F, "(float %e)", expr->value.real);	break;
***/
/* GEH - added one more significant digit to prevent rounding error 4-27-95 */
		/* BCC - use 8 digits for float - 8/22/96 */
	        fprintf(F, "(float %1.8e)", (float)expr->value.real);	break;
	/* BCC - added - 8/5/96 */
	case OP_double :
	        fprintf(F, "(double %1.16e)", expr->value.real);break;
	case OP_char :
		fprintf(F, "(char %s)", expr->value.string);	break;
	case OP_string :
		fprintf(F, "(string %s)", expr->value.string);	break;
	case OP_cast :
		fprintf(F, "(cast (");
		GenType(expr->type, 0);
		GenDcltr(expr->type->dcltr);
		fprintf(F, ") ");
		GenExpr(ExprOperand(1, expr));
		fprintf(F, ")");
		break;
	case OP_type_size :
		fprintf(F, "(type_size (");
		GenType(expr->value.type, 0);
		GenDcltr(expr->value.type->dcltr);
		fprintf(F, "))");
		break;
	case OP_expr_size :
		arg = ExprOperand(1, expr);
		if (arg==0) Punt("GenExpr : sizeof missing argument");
		fprintf(F, "(expr_size ");
		GenExpr(arg);
		fprintf(F, ")");
		break;
	case OP_return :
	case OP_goto :
	case OP_if :
	case OP_switch :
		Punt("GenExpr : premature return/jump/cond_br/switch");
		break;
/* NJW */
	case OP_sync :
	        fprintf(F, "(");
		GenOpcode(opcode);
		if (expr->pragma!=0)
		    GenExprPragma(expr->pragma);
	        else
		   Warning("sync without a pragma");
		fprintf(F, ")");
		break;
/* WJN */
	/* LCW - nulldefine is for passing Pprofiler probe info to Lcode.
	 * Probe number is put in pragma. - 10/24/96
	 */
	case OP_nulldefine :
	        fprintf(F, "(");
		GenOpcode(opcode);
		if (expr->pragma!=0)
		    GenExprPragma(expr->pragma);
	        else
		   Warning("nulldefine without a pragma");
		fprintf(F, ")");
		break;
		   
	case OP_quest :
		fprintf(F, "(quest ");
		GenExpr(ExprOperand(1, expr));
		fprintf(F, " ");
		GenExpr(ExprOperand(2, expr));
		fprintf(F, " ");
		GenExpr(ExprOperand(3, expr));
		if (expr->pragma!=0) 
		    GenExprPragma(expr->pragma);
		fprintf(F, ")");
		break;
	case OP_comma :
		fprintf(F, "(comma ");
		GenExpr(ExprOperand(1, expr));
		fprintf(F, " ");
		GenExpr(ExprOperand(2, expr));
		if (expr->pragma!=0) 
		    GenExprPragma(expr->pragma);
		fprintf(F, ")");
		break;
	case OP_call :
		fprintf(F, "(call");
		for (n=1; (arg=ExprOperand(n, expr)) != 0; n++) {
			fprintf(F, " ");
			GenExpr(arg);
		}
		if (expr->pragma!=0) 
		    GenExprPragma(expr->pragma);
		fprintf(F, ")");
		break;
	case OP_index :
		fprintf(F, "(index ");
		GenExpr(ExprOperand(1, expr));
		fprintf(F, " ");
		GenExpr(ExprOperand(2, expr));
		if (expr->pragma!=0) 
		    GenExprPragma(expr->pragma);
		fprintf(F, ")");
		break;
	/* binary */
	case OP_disj :
	case OP_conj :
	case OP_assign :
	case OP_or :
	case OP_xor :
	case OP_and :
	case OP_eq :
	case OP_ne :
	case OP_lt :
	case OP_le :
	case OP_ge :
	case OP_gt :
	case OP_rshft :
	case OP_lshft :
	case OP_add :
	case OP_sub :
	case OP_mul :
	case OP_div :
	case OP_mod :
	case OP_Aadd :
	case OP_Asub :
	case OP_Amul :
	case OP_Adiv :
	case OP_Amod :
	case OP_Arshft :
	case OP_Alshft :
	case OP_Aand :
	case OP_Aor :
	case OP_Axor :
		fprintf(F, "(");
		GenOpcode(opcode);
		GenExpr(ExprOperand(1, expr));
		fprintf(F, " ");
		GenExpr(ExprOperand(2, expr));
		if (expr->pragma!=0) 
		    GenExprPragma(expr->pragma);
		fprintf(F, ")");
		break;
	/* the second operand is in value.string */
	case OP_dot :
	case OP_arrow :
		fprintf(F, "(");
		GenOpcode(opcode);
		GenExpr(ExprOperand(1, expr));
		fprintf(F, " %s", expr->value.string);
		    /* DMG */
		if (expr->pragma!=0) 
		    GenExprPragma(expr->pragma);
		fprintf(F, ")");
		break;
	/* unary */
	case OP_neg :
	case OP_not :
	case OP_inv :
	case OP_abs :
	case OP_preinc :
	case OP_predec :
	case OP_indr :
	case OP_addr :
	case OP_postinc :
	case OP_postdec :
		fprintf(F, "(");
		GenOpcode(opcode);
		GenExpr(ExprOperand(1, expr));
		if (expr->pragma!=0) 
		    GenExprPragma(expr->pragma);
		fprintf(F, ")");
		break;
	default :
		Punt("GenExpr : illegal expression");
	}
}
/*========================================================================*/
static GenBasicBlock(bb)
Block bb;
{
	ProfArc arc;
	Pragma pragma;
	Expr expr;
	BLink link;

	if ((bb==0) || (bb->first==0)) {
	    fprintf(F, " (#warning BB %d is empty)\n", bb->id);
	    return;
	}

	/* print basic block header */
	fprintf(F, " (BB %d ", bb->id);

	/* print profile information */
	fprintf(F, "(PROFILE %f", bb->profile.weight);
	for (arc=bb->profile.destination; arc!=0; arc=arc->next) {
	    fprintf(F, " (%d %d %f)", 
		arc->bb_id, arc->condition, arc->weight);
	}
	fprintf(F, ")\n");

	/* print pragma */
	for (pragma=bb->pragma; pragma!=0; pragma=pragma->next) {
	    fprintf(F, "  (BB_PRAGMA %s)\n", pragma->specifier);
	}

	/* generate expressions in the basic block. */
	for (expr=bb->first; expr!=0; expr=expr->next) {
		/* skip over the last expression */
		if (expr==bb->last)
			break;
		fprintf(F, "\t");
		GenExpr(expr);
		fprintf(F, "\n");
	}

	/* generate branch condition. */
	switch (bb->last->opcode) {
	case OP_return :
		/* generate return(expr); */
		{ Expr exp = ExprOperand(1, bb->last);
		  if (exp!=0) {
			fprintf(F, "\t(RETURN ");
			GenExpr(exp);
			fprintf(F, ") ");
		  } else
			fprintf(F, "\t(RETURN) ");
		}
		break;
	case OP_goto :
		/* goto L??; */
		link = bb->destination;
		fprintf(F, "\t(GOTO %d) ", link->destination);
		break;
	case OP_if :
		/* if (cond) goto L??; else goto L??; */
		/* find true link */
		for (link=bb->destination; link!=0; link=link->next)
			if (IsTrueExpr(link->condition))
				break;
		if (link==0)
			Punt("GenBasicBlock : OP_if missing true BLink");
		fprintf(F, "\t(IF ");
		GenExpr(ExprOperand(1, bb->last));
		fprintf(F, " (THEN %d)", link->destination);
		/* find false link */
		for (link=bb->destination; link!=0; link=link->next)
			if (IsFalseExpr(link->condition))
				break;
		if (link==0)
			Punt("GenBasicBlock : OP_if missing false BLink");
		fprintf(F, " (ELSE %d) ", link->destination);
		/* SAM 6-93 print pragma of IF */
		if (expr->pragma!=0) {
		    GenExprPragma(expr->pragma);
		}
		fprintf(F, ")");
		break;
	case OP_switch :
		/* switch (cond) {
		 * case cond1 : goto L??;
		 * default : goto L ??;
		 * }
		 */
		if (bb->destination==0)
			Punt("GenBasicBlock : missing BLink");
		fprintf(F, "\t(SWITCH ");
		GenExpr(ExprOperand(1, bb->last));
		/* generate switch body */
		for (link=bb->destination; link!=0; link=link->next) {
		    /* case expr : goto L??; */
		    if (link->condition==0)
			Punt("GenBasicBlock : no case condition");
		    if (IsDefaultExpr(link->condition))
			continue;
		    fprintf(F, " (");
		    GenExpr(link->condition);
		    fprintf(F, " %d)", link->destination);
		}
		/* generate the default case */
		for (link=bb->destination; link!=0; link=link->next) {
		    /* there may be several conditions
		     * leading to the same destination block.
		     */
		    if (IsDefaultExpr(link->condition)) {
		    	fprintf(F, " (DEFAULT %d)", link->destination);
			break;
		    }
		}
		/* complete the switch */
		fprintf(F, ") ");
		break;
	default :
		Punt("GenBasicBlock : illegal last instruction");
	}

	fprintf(F, ")\n");
}
/* print function definition. */
static GenFunction(func)
FuncDcl func;
{
	VarList ptr;
	Pragma pragma;
	Block bb;
	ProfCS cs;
	if (func==0) Punt("GenFunction : nil input");
	if (func->type==0) Punt("GenFunction : no return type");
	if (func->name==0) Punt("GenFunction : no name");
	fprintf(F, "(BEGIN_FN %s)\n", func->name);
	fprintf(F, " (PROFILE %d %f",
		func->profile.fn_id, func->profile.weight);
	for (cs=func->profile.calls; cs!=0; cs=cs->next) {
		fprintf(F, " (%d %d %f)", cs->call_site_id,
		cs->callee_id, cs->weight);
	}
	fprintf(F, ")\n");
	fprintf(F, " (RETURN_TYPE (");
	GenType(func->type, 1);		/* return type */
	GenDcltr(func->type->dcltr);
	fprintf(F, "))\n");
	/* print parameter definition */
	for (ptr=func->param; ptr!=0; ptr=ptr->next) {
		fprintf(F, " ");
		GenParamDataDcl(ptr->var);
	}
	/* print local variable definition */
	for (ptr=func->local; ptr!=0; ptr=ptr->next) {
		fprintf(F, " ");
		GenLocalDataDcl(ptr->var);
	}
	/* print pragma */
	for (pragma=func->pragma; pragma!=0; pragma=pragma->next) {
		fprintf(F, " (FN_PRAGMA %s)\n", pragma->specifier);
	}
	/* print function body */
	fprintf(F, " (ENTRY %d)\n", func->entry_bb);
	for (bb=func->blocks; bb!=0; bb=bb->next) {
		GenBasicBlock(bb);
	}
	fprintf(F, "(END_FN %s)\n", func->name);
  	fflush(F);
}
/*========================================================================*/
/* print enum type definition. */
static GenEnumDcl(E)
EnumDcl E;
{
/* 
 * BCC - since all enum fields have been converted to the corresponding 
 *	 constants, there is no need to print out the DEF_ENUM information.
 *	 Printing this may cause problem for duplicated enum fields which have
 *	 the same name but different values. 2-3/96 
 */
#if 0
	EnumField ptr;
	if (E==0) Punt("GenEnumDcl : nil E");
	fprintf(F, "(DEF_ENUM %s ", E->name);
	ptr=E->fields;
	while (ptr!=0) {	/* print fields. */
	    fprintf(F, " (%s", ptr->name);
	    if (ptr->value!=0) {	
		fprintf(F, " ");
		    GenExpr(ptr->value);
	    }
	    fprintf(F, ")");
	    ptr = ptr->next;
	}
	fprintf(F, ")\n");
#endif
}
/*========================================================================*/
/* print a struct/union field. */
static GenStructField(field)
Field field;
{
	if (field==0) return;
	fprintf(F, "(");
	if (field->name!=0) {
	    fprintf(F, "%s", field->name);
	} else {
	    fprintf(F, "\"\"");
	}
	fprintf(F, " (");
	GenType(field->type, 1);
	GenDcltr(field->type->dcltr);
	fprintf(F, ")");
	if (field->bit_field!=0) {
		fprintf(F, " ");
		GenExpr(field->bit_field);
	}
	fprintf(F, ")\n");
}
/* print struct structure definition. */
static GenStructDcl(S)
StructDcl S;
{
	Field ptr;
	if (S==0) Punt("GenStructDcl : nil S");
	fprintf(F, "(DEF_STRUCT %s\n", S->name);
	for (ptr=S->fields; ptr!=0; ptr=ptr->next) {
		fprintf(F, " ");
		GenStructField(ptr);
	}
	fprintf(F, ")\n");
}
/* print union structure definition. */
static GenUnionDcl(U)
StructDcl U;
{
	Field ptr;
	if (U==0) Punt("GenUnionDcl : nil U");
	fprintf(F, "(DEF_UNION %s\n", U->name);
	for (ptr=U->fields; ptr!=0; ptr=ptr->next) {
		fprintf(F, " ");
		GenStructField(ptr);
	}
	fprintf(F, ")\n");
}
/*========================================================================*/
static GenInit(init)
Init init;
{
	int n;
	/*
 	 * initializer :
	 *	expression?
	 *	(AGGR initializer*)?
	 */
	if (init==0) return;	/* init is only optional. */
	if (init->expr!=0) {
		fprintf(F, " ");
		GenExpr(init->expr);
	} else
	if (init->set!=0) {
		Init ptr;
		fprintf(F, " (AGGR");
		ptr=init->set;
		n = 0;
		while (ptr!=0) {
			GenInit(ptr);
			ptr = ptr->next;
			n++;
			if ((n%4)==0) fprintf(F, "\n");
		}
		fprintf(F, ")");
	} else
		Punt("GenInit : unknown data type");
}
/*========================================================================*/
/* print parameter definition. */
static GenParamDataDcl(V)
VarDcl V;
{
	if (V==0) Punt("GenParamDataDcl : nil V");
	/* (PARAMETER name%s DeclSpec) */
	fprintf(F, "(PARAMETER %s (", V->name);
	GenType(V->type, 1);			/* type */
	GenDcltr(V->type->dcltr);
	fprintf(F, "))\n");
}
/* print local variable definition. */
static GenLocalDataDcl(V)
VarDcl V;
{
	if (V==0) Punt("GenLocalDataDcl : nil V");
	/* (LVAR name%s DeclSpec) */
	fprintf(F, "(LVAR %s (", V->name);
	GenType(V->type, 1);			/* type */
	GenDcltr(V->type->dcltr);
	fprintf(F, "))\n");
}
/* print global variable definition. */
/* the type definition is what's recorded at that instance of the
 * global variable definition. If it is extern class, the initialization
 * section is not printed.
 */
static GenGlobalDataDcl(V, type, dcltr)
VarDcl V;
Type type;
Dcltr dcltr;
{
	/*
	 * (GVAR name%s DeclSpec Initializer)
	 */
	if (V==0) Punt("GenGlobalDataDcl : nil V");
	fprintf(F, "(GVAR %s (", V->name);
	GenType(type, 1);				/* type */
	GenDcltr(dcltr);				/* dcltr */
	fprintf(F, ")");
	if (! (type->type & TY_EXTERN)) {
	    if (V->init!=0) {
		fprintf(F, "\n");
		GenInit(V->init);
	    }
	}
	fprintf(F, ")\n");
}
/*========================================================================*/
Gen_CCODE_LinePos(F, n, src_file)
FILE *F;
int n;
char *src_file;
{
	if (BLOCK_OUTPUT) return;
	fprintf(F, "(POSITION %d %s)\n", n, src_file);
}
Gen_CCODE_Struct(FL, st)
FILE *FL;
StructDcl st;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenStructDcl(st);
}
Gen_CCODE_Union(FL, un) 
FILE *FL;
UnionDcl un;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenUnionDcl(un);
}
Gen_CCODE_Enum(FL, en) 
FILE *FL;
EnumDcl en;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenEnumDcl(en);

/* REH 9/8/93 - assign a value to the enum
   so that it may be evaluated later */
/*
	if (H_output_form == OUTPUT_CCODE)
*/
        HC_assign_enum(en);
/***/
}
Gen_CCODE_Var(FL, var) 
FILE *FL;
VarDcl var;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenGlobalDataDcl(var, var->type, var->type->dcltr);
}
Gen_CCODE_Func(FL, fn) 
FILE *FL;
FuncDcl fn;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenFunction(fn);
}
Gen_CCODE_Include(FL, file)
FILE *FL;
char *file;
{
	int buf;	/* must handle multi-level inclusion correctly */
	if (! BLOCK_OUTPUT) {
	    fprintf(FL, "(INCLUDE %s)\n", file);
	}
	buf = OUTPUT;
	DO_OUTPUT(0);
	ReadIncludeFile(file);
	DO_OUTPUT(buf);
}
/*========================================================================*/
/* 
 *	The following functions are provided for debugging purpose
 *	only and should not be used in normal operational mode.
 */
Gen_CCODE_Init(FL, init)
FILE *FL;
Init init;
{
	F = FL;
	GenInit(init);
}
/*========================================================================*/
