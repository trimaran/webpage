/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_profile2.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include "h_main.h"
#include <library/dynamic_symbol.h>
#include <Hcode/h_prag.h>

extern char *FindString();	/* list.c */

STRING_Symbol_Table	*func_id_table = NULL;



/*-----------------------------------------------------------------*/
/*
 *	assign fn_id
 *	assign sw_case_id
 *	assign call_site_id
 */
static call_site;
static AssignCallSite(expr)
Expr expr;
{
    int i, call_id;
    Expr op;
    char line[200];
    if (expr==0) return;
    if (expr->opcode==OP_call) {
	call_id = call_site++;
    	sprintf(line, "\"cs.%d\"", call_id);
    	AddExprPragma(expr, FindString(line));
    }
    for (i=1; (op=GetOperand(expr, i))!=0; i++)
	AssignCallSite(op);
}
static AssignID(fn)
FuncDcl fn;
{
    Block bb;
    Expr expr;
    call_site = 1;
    fn->profile.fn_id = H_profile_starting_fn_id++;	/* function ID */
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	for (expr=bb->first; expr!=0; expr=expr->next) {
	    AssignCallSite(expr);		/* call site ID */
	}
	/* switch case ID is implicit: the user specified order
	 * we only need to make sure that reading CCODE does not
	 * change the order.
 	 */
	if (bb->last->opcode==OP_switch) {
	    BLink link;
	    int case_id = 1;
	    for (link=bb->destination; link!=0; link=link->next) {
		if (IsDefaultExpr(link->condition)) {
		    link->status = 0;	/* default case */
		} else {
		    link->status = case_id++;
		}
	    }
	}
    }
}

/*-----------------------------------------------------------------*/
static int site_buf[MAX_CALL_SITE_IN_FN];
static int callee_buf[MAX_CALL_SITE_IN_FN];
static double weight_buf[MAX_CALL_SITE_IN_FN];

static double ExtractProfPragWeight(pragma, bb, fn)
Pragma pragma;
Block bb;
FuncDcl fn;
{
    double weight;
    long int di;
    char pragname[256], *delim, *spec;

    if (pragma == NULL) {
	H_punt ("Cannot find STAT_PROF pragma for: %s bb %i\n",
		fn->name, bb->id);
    }
    spec = pragma->specifier;
    spec = HC_read_attr_name_from_pragma_str(spec, pragname);
    if (spec == NULL) {
	H_punt ("STAT_PROF pragma has no fields for: %s bb %i\n",
		fn->name, bb->id);
    }
    spec = HC_read_attr_field_from_pragma_str(spec, pragname, &di, 
					      &weight, &delim);
    if (delim[1] != '#' || spec != NULL) {
	H_punt ("STAT_PROF pragma has incorrect format for: %s bb %i\n",
		fn->name, bb->id);
    }
    return weight;
}

static GetCallSiteProfInfo(expr, bb, fn)
Expr expr;
Block bb;
FuncDcl fn;
{
    Pragma pragma;
    int target_id;

    if (expr == 0) return;

    /* Only care about calls */
    if (expr->opcode == OP_call && 
	expr->operands->opcode == OP_var) {

	target_id = (int) STRING_find_symbol_data (func_id_table,
				  expr->operands->value.var_name); 
	if (target_id == 0) {
#if 0
	    printf ("%s bb %i call to library function %s!\n",
		    fn->name, bb->id, 
		    expr->operands->value.var_name);
#endif
	} 
	else {
	    ProfCS cs, ptr;
	    int call_site_id; 

	    /* Get call site from pragma of form "cs.%d"
	     * (the quotes are part of the string!)
	     */
	    pragma = FindExprPragma(expr, "\"cs.");
	    if (pragma != 0) 
	    {
		call_site_id = atol (&pragma->specifier[4]);

		if (call_site_id == 0)
		{
		    H_punt ("Error parsing call site pragma '%s'!",
			    pragma->specifier);
		}
	    }
	    else {
		H_punt ("Cannot find call site for: %s bb %i call to user function %s id %i!\n",
			fn->name, bb->id, 
			expr->operands->value.var_name, target_id);
	    }

	    cs = NewProfCS();
	    cs->call_site_id = call_site_id; /* ? */
	    cs->callee_id =  target_id;
	    cs->weight = 
		ExtractProfPragWeight(FindBlockPragma(bb, "\"STAT_PROF"), 
				      bb, fn);

	    ptr = fn->profile.calls;
	    if (ptr==0) {
		fn->profile.calls = cs;
	    } else {
		while (ptr->next!=0) ptr=ptr->next;
		ptr->next = cs;
	    }

#if 0			
	    printf ("%s bb %i call to user function %s id %i!\n",
		    fn->name, bb->id, 
		    expr->operands->value.var_name, target_id);
#endif
	    
	}
	
    }

    for (expr = expr->operands; expr != 0; expr = expr->sibling) {
	GetCallSiteProfInfo(expr, bb, fn);
    }
}

static GetProfileInfo(fn)
FuncDcl fn;
{
    Block bb;
    Expr expr;
    Pragma pragma;
    FILE *list_in;
    int fn_id, target_id;
    static int init = 0;
    register int i, N;
    char buf[200];

    if (!H_use_static_weights) {    /* JCG 7/12/95 */
	if (! init) {
	    init = 1;
	    _InitProfileDatabase();		/* PROFILER */
	    _ReadProfileFile(H_profile_database_file);
	}
    }
    else {
	/* Read in function id table (if necessary) */
	if (func_id_table == NULL)
	{
	    func_id_table = STRING_new_symbol_table ("func id", 128);

	    /* Read function list into table */
	    if ((list_in = fopen (H_func_list_name, "r")) == NULL)  
		H_punt ("Unable to open func list '%s'!\n", H_func_list_name);

	    fn_id = 1;
	    /* Read in line of the form '(BEGIN_FN name)\n'.
	     * Have to read in ending ) as part of string for fscanf to work.
	     */
	    while (fscanf (list_in, "(BEGIN_FN %s\n", buf) > 0)
	    {
		/* Remove ending ')' */
		buf[strlen(buf)-1] = 0;

#if 0
		printf ("Read '%s' for id %i\n", buf, fn_id);
#endif

		/* Add function name with this id to table */
		STRING_add_symbol (func_id_table, buf, (void *) fn_id);

		/* Increment fn_id for next function */
		fn_id++;
	    }
	    fclose (list_in);
	}
    }

    fn_id = fn->profile.fn_id;		/* get function weight */

    if (!H_use_static_weights) { /* JCG 7/12/95 */
	fn->profile.weight = _FunctionWeight(fn_id) * H_profile_multiplier;
    } 
    else {
	fn->profile.weight = 
		ExtractProfPragWeight(FindFunctionPragma(fn, "\"STAT_PROF"),
				      0, fn);
    }

    /*
     *	get call site weight.
     */
/* JCG 7/12/95 */

    /* If using static weights have to figure out the call sites on our
     * own!
     */
    if (!H_use_static_weights) { /* JCG 7/12/95 */
	N = _CallSiteWeight(fn_id, MAX_CALL_SITE_IN_FN, site_buf,
			    callee_buf, weight_buf);
	if (N>MAX_CALL_SITE_IN_FN)
	    Punt("GetProfileInfo: call site buffer overflow");
	fn->profile.calls = 0;
	for (i=0; i<N; i++) {
	    ProfCS cs, ptr;
	    cs = NewProfCS();
	    cs->call_site_id = site_buf[i];
	    cs->callee_id = callee_buf[i];
	    cs->weight = weight_buf[i] * H_profile_multiplier;
	    ptr = fn->profile.calls;
	    if (ptr==0) {
		fn->profile.calls = cs;
	    } else {
		while (ptr->next!=0) ptr=ptr->next;
		ptr->next = cs;
	    }
	}
    }
    else {
	/* Scan each bb for calls.  If call to a user function (in
	 * func_id_table), then add arc for this call (otherwise 
	 * do nothing).
	 */
	for (bb=fn->blocks; bb != NULL; bb = bb->next) {
	    for (expr=bb->first; expr != NULL; expr = expr->next)
	    {
		GetCallSiteProfInfo(expr, bb, fn);
	    }
	}
    }
    /*
     *	get basic block and control transfer weights.
     */
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	BLink ln;
	if (!H_use_static_weights) { /* JCG 7/12/95 */
	    bb->profile.weight = _NodeWeight(fn_id, bb->id) *
		H_profile_multiplier;
	} else {
	    bb->profile.weight = 
		ExtractProfPragWeight(FindBlockPragma(bb, "\"STAT_PROF"), 
				      bb, fn);
	}

 
	bb->profile.destination = 0;
	if (bb->last->opcode==OP_switch) {
	    for (ln=bb->destination; ln!=0; ln=ln->next) {
		int case_id;
		ProfArc pc, ptr;
		double weight;
		case_id = ln->status;

		if (!H_use_static_weights) { /* JCG 7/12/95 */
		    weight = _CaseWeight(fn_id, bb->id, case_id) *
			H_profile_multiplier;
		} else {
		    weight = bb->profile.weight;
		}

		if (weight==0.0)
		    continue;
		pc = NewProfArc();
	 	pc->bb_id = ln->destination;
		pc->condition = case_id;
		pc->weight = weight;
		ptr = bb->profile.destination;
		if (ptr==0) {
		    bb->profile.destination = pc;
		} else {
		    while (ptr->next!=0) ptr=ptr->next;
		    ptr->next = pc;
		}
	    }
	} else {
	    /*
	     *	here I assume that two-way branches
	     *	do not go to the same destination.
	     *	(already converted to OP_goto)
	     */
	    for (ln=bb->destination; ln!=0; ln=ln->next) {
		int dest_bb, condition;
		double weight;
		ProfArc pc, ptr;
		dest_bb = ln->destination;

		if (!H_use_static_weights) { /* JCG 7/12/95 */
		    weight = _ArcWeight(fn_id, bb->id, dest_bb) *
			H_profile_multiplier;
		} else {
		    weight = bb->profile.weight;
		}

		if (weight==0.0)
		    continue;
		condition = IsTrueExpr(ln->condition);
		pc = NewProfArc();
	 	pc->bb_id = dest_bb;
		pc->condition = condition;
		pc->weight = weight;
		ptr = bb->profile.destination;
		if (ptr==0) {
		    bb->profile.destination = pc;
		} else {
		    while (ptr->next!=0) ptr=ptr->next;
		    ptr->next = pc;
		}
	    }
	}
    }
}
/*-----------------------------------------------------------------*/
/*
 *	If H_do_insert_profile_probes, insert profile probe.
 *	If H_do_merge_profile, get profile information.
 */
Profile(fn)
FuncDcl fn;
{
    Pragma pragma;
    char spec[200], *fn_name;
    /*
     *	We do not allow user to define [setjmp and longjmp]
     *	functions.
     */
    fn_name = fn->name;
    if (! (strcmp(fn_name, "setjmp") &&
	   strcmp(fn_name, "_setjmp") &&
	   strcmp(fn_name, "__setjmp") &&/*for linux profiling - JCG 7/18/95*/
	   strcmp(fn_name, "sigsetjmp") &&
	   strcmp(fn_name, "longjmp") &&
	   strcmp(fn_name, "_longjmp") &&
	   strcmp(fn_name, "siglongjmp")) ) {
	fprintf(stderr, "reserved names [setjmp,_setjmp,__setjmp, sigsetjmp,longjmp,");
	fprintf(stderr, "_longjmp,siglongjmp] cannot be named");
	fprintf(stderr, " after a user function\n");
	Punt("illegal LIBPROF interface");
    }
    /*
     *	If H_do_insert_profile_probes, assign various IDs
     *	including fn_id, switch_case_id, call_site_id.
     */
    if (H_profile_starting_fn_id == 0)  {
	if (H_do_merge_profile)
	    Punt("Probe_starting_fn_id must be supplied");
	return;
    }
    if ((!H_do_merge_profile) && (H_output_form!=OUTPUT_C))
	Punt("Profile: -f c option must be used");
    pragma = FindFunctionPragma(fn, "\"flatten\"");
    if (pragma==0)
	Punt("Profile: function has not yet been flattened");
    while (pragma = FindFunctionPragma(fn, "\"optimize\"")) {
	if (H_do_merge_profile)
	    Punt("Profile: version problem");
	RemoveFunctionPragma(fn, pragma);
    }
    AssignID(fn);		/* assign various IDs */
    if (H_do_merge_profile) {
	GetProfileInfo(fn);
	sprintf(spec, "\"profiled.%d\"", fn->profile.fn_id);
	AddFunctionPragma(fn, FindString(spec));
    }
}

