/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.10  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Apr. 12, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright 1999 IMPACT Technologies, Inc; Champaign, Illinois
 * For commercial license rights, contact: Marketing Office via
 * electronic mail: marketing@impactinc.com
 *
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	hl_gen.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Creation Date:	June 1990
 *      Modified by:  Nancy Warter
 *	Modified by:  Roger A. Bringmannn 2/8/93
 *	    Modified to support new Lcode parenthesization format
 *      Revised: Dave Gallagher, Scott Mahlke - June 1994
 *              Build Lcode structure rather than just printing out text file
 *      Revised by: Ben-Chung Cheng - June 1995
 *              Change M_SIZE_INT, M_SIZE_CHAR to H_INT_SIZE, H_CHAR_SIZE
 *              Those should be determined in runtime, not compile time
\*****************************************************************************/
#include "hl_main.h"

#undef DEBUG_PCODE

/*
 *	figured a way to change Lsun4 instead.
 */
#undef GEN_RET_STRUCT_ATTR	/* 5-20-1991, pohua */

#define MASK_FOR_CHAR_CAST
#undef NO_BIT_FIELD_FOR_COMPLEX_ASSIGNMENT	/* --, ++, op= */

static void HC_reset_ret(HC_Ret ret);
static void gen_var_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_indr_addr(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_index_addr(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_dot_addr(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_arrow_addr(L_Cb *cb, Expr expr, HC_Ret ret);
static int is_indr_expr(Expr expr);
static void gen_load_data(L_Cb *cb, Expr expr, HC_Ret addr, 
			HC_Ret data, Type type);
static void gen_store_data(L_Cb *cb, Expr expr, HC_Ret addr, 
			HC_Ret data, Type type);
static void gen_extract_bit_field(L_Cb *cb,HC_Ret data,int bit_shift, 
			long bit_mask);
static void gen_insert_bit_field(L_Cb *cb, HC_Ret data, HC_Ret field,
                            int bit_shift, long bit_mask);
static void gen_dot_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_arrow_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_cast_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_indr_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_index_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_call_data(L_Cb *cb, Expr expr, HC_Ret result);
static void gen_assign_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_incr_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_Aarith_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_logic_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_compare_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_shift_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_sync_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_add_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_sub_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_mul_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_div_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_mod_data(L_Cb *cb, Expr expr, HC_Ret ret);
static void gen_unary_data(L_Cb *cb, Expr expr, HC_Ret ret);
/* LCW - 10/24/96 */
static void gen_nulldefine_data(L_Cb *cb, Expr expr, HC_Ret ret);

/* BCC - from hl_pr.c - 6/15/95 */
extern void bcc_cast_char(L_Cb *, HC_Operand , HC_Operand , int );
extern void bcc_cast_short(L_Cb *, HC_Operand , HC_Operand , int );
extern void bcc_cast_integer(L_Cb *, HC_Operand , HC_Operand , int );
extern void bcc_cast_float(L_Cb *, HC_Operand , HC_Operand , int );
extern void bcc_cast_double(L_Cb *, HC_Operand , HC_Operand , int );

/* REH 09/05/94 - global to aid alloc removal */
HC_Operand HC_func_return_struct = NULL;
/* HER */

/*---------------------------------------------------------------------------*/
/* REH 2/7/96 - These worked for 2 years, but not in general :( */
#if 0 
short	HC_is_bit_field;
int	HC_bit_field_shift;
long	HC_bit_field_mask;
/* REH 9/12/93 */
int	HC_bit_field_type;	/* TY_INT, TY_SHORT, TY_CHAR */
/* HER */
int     HC_bit_field_length;    /* DMC 8/3/95 */
#endif
/*---------------------------------------------------------------------------*/
void HC_ret_mulC(L_Cb *cb, HC_Ret ret, int n)
{
    HC_Operand op;
    if (ret->type!=HC_RET_SIMPLE)
	HC_simplify(cb, ret);
    op = &(ret->op1);
    if (op->type==HC_I) {
	op->value.i *= n;
    } else
    if (op->type==HC_F) {
	op->value.f *= n;
    } else
    if (op->type==HC_F2) {
	op->value.f2 *= n;
    } else {
	_HC_Operand dest, op2;
	HC_new_int(&op2, n, 0);
/* BCC - suppose we want to calculate a[b]; where a is int and b is char.
	 So the effective address is a+b*4, and we should use a int register
	 to hold b*4, instead of the type of b. 		- 6/19/95 
	HC_new_register(&dest, HC_next_reg_id(), op->data_type);             */
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	/* LCW -- add an additional argument 0 (attr1) - 8/9/95 */
	HC_gen_mul(cb, &dest, op, &op2, 0, 0);
	ret->op1 = dest;
	ret->type = HC_RET_SIMPLE;
    }
}
/* assume unsigned add/sub */
void HC_ret_add(L_Cb *cb, HC_Ret sum, HC_Ret x, HC_Ret y)
{
    int unsign; 

    unsign = x->op1.unsign && y->op1.unsign;

    if ((x->type==HC_RET_SIMPLE) & (x->op1.type==HC_I)) {
    	if ((y->type==HC_RET_SIMPLE) & (y->op1.type==HC_I)) {
	    HC_reset_ret(sum);
	    sum->type = HC_RET_SIMPLE;
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_int(&(sum->op1), x->op1.value.i + y->op1.value.i, unsign);
	    else
	      HC_new_int(&(sum->op1), x->op1.value.i + y->op1.value.i, 0);
	} else
    	if ((y->type==HC_RET_ADD) & (y->op2.type==HC_I)) {
	    sum->type = HC_RET_ADD;
	    sum->op1 = y->op1;
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_int(&(sum->op2), x->op1.value.i + y->op2.value.i, unsign);
	    else
	      HC_new_int(&(sum->op2), x->op1.value.i + y->op2.value.i, 0);
	} else
    	if ((y->type==HC_RET_ADD) & (y->op1.type==HC_I)) {
	    sum->type = HC_RET_ADD;
	    sum->op1 = y->op2;
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_int(&(sum->op2), x->op1.value.i + y->op1.value.i, unsign);
	    else
	      HC_new_int(&(sum->op2), x->op1.value.i + y->op1.value.i, 0);
	} else {
	    HC_simplify(cb, x);
	    HC_simplify(cb, y);
	    sum->type = HC_RET_ADD;
	    sum->op1 = x->op1;
	    sum->op2 = y->op1;
	}
    } else
    if ((y->type==HC_RET_SIMPLE) & (y->op1.type==HC_I)) {
    	if ((x->type==HC_RET_SIMPLE) & (x->op1.type==HC_I)) {
	    HC_reset_ret(sum);
	    sum->type = HC_RET_SIMPLE;
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_int(&(sum->op1), y->op1.value.i + x->op1.value.i, unsign);
	    else
	      HC_new_int(&(sum->op1), y->op1.value.i + x->op1.value.i, 0);
	} else
    	if ((x->type==HC_RET_ADD) & (x->op2.type==HC_I)) {
	    sum->type = HC_RET_ADD;
	    sum->op1 = x->op1;
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_int(&(sum->op2), y->op1.value.i + x->op2.value.i, unsign);
	    else
	      HC_new_int(&(sum->op2), y->op1.value.i + x->op2.value.i, 0);
	} else
    	if ((x->type==HC_RET_ADD) & (x->op1.type==HC_I)) {
	    sum->type = HC_RET_ADD;
	    sum->op1 = x->op2;
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_int(&(sum->op2), y->op1.value.i + x->op1.value.i, unsign);
	    else
	      HC_new_int(&(sum->op2), y->op1.value.i + x->op1.value.i, 0);
	} else {
	    HC_simplify(cb, x);
	    HC_simplify(cb, y);
	    sum->type = HC_RET_ADD;
	    sum->op1 = x->op1;
	    sum->op2 = y->op1;
	}
    } else {
	HC_simplify(cb, x);
	HC_simplify(cb, y);
	sum->type = HC_RET_ADD;
	sum->op1 = x->op1;
	sum->op2 = y->op1;
    }
}
/*---------------------------------------------------------------------------*/
static void HC_reset_ret(HC_Ret ret)
{
    if (ret==0) Punt("HC_reset_ret: nil argument");
    ret->type = HC_RET_SIMPLE;
    ret->op1.type = HC_I;
    ret->op1.data_type = M_TYPE_INT;
    ret->op1.value.i = 0;
    ret->op2.type = HC_I;
    ret->op2.data_type = M_TYPE_INT;
    ret->op2.value.i = 0;
}

void HC_simplify(L_Cb *cb, HC_Ret ret)
{
    _HC_Operand dest;
    HC_Operand src1, src2;

    int unsign;

    if (L_propagate_sign_size_ctype_info)
      unsign = ret->op1.unsign && ret->op2.unsign;
    else
      unsign = 0;

    if (ret==0)
      Punt("HC_simplify: nil argument");
    switch (ret->type) {
    case HC_RET_NONE:
    	HC_reset_ret(ret);	/* initialize to 0 */
	break;
    case HC_RET_SIMPLE:		/* already simple */
	break;
    case HC_RET_ADD:
        src1 = &(ret->op1);
        src2 = &(ret->op2);
	if ((src1->type==HC_I) & (src2->type==HC_I)) {
	  HC_new_int(src1, src1->value.i + src2->value.i, unsign);
	  HC_new_int(src2, 0, unsign); 
	  ret->type = HC_RET_SIMPLE;
	} else
	if ((src1->type==HC_I) & (src1->value.i==0)) {
	  HC_dup(src1, src2);
	  HC_new_int(src2, 0, unsign);
	  ret->type = HC_RET_SIMPLE;
	} else
	if ((src2->type==HC_I) & (src2->value.i==0)) {
	    ret->type = HC_RET_SIMPLE;
	} else {
	  HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
	  HC_gen_add(cb, &dest, src1, src2, 1, 0);
	  HC_dup(src1, &dest);
	  HC_new_int(src2, 0, unsign);
	  ret->type = HC_RET_SIMPLE;
	}
	break;
    case HC_RET_SUB:
	src1 = &(ret->op1);
	src2 = &(ret->op2);
	if ((src1->type==HC_I) & (src2->type==HC_I)) {
	  HC_new_int(src1, src1->value.i - src2->value.i, unsign);
	  HC_new_int(src2, 0, unsign); 
	  ret->type = HC_RET_SIMPLE;
	} else
	if ((src2->type==HC_I) & (src2->value.i==0)) {
	  ret->type = HC_RET_SIMPLE;
	} else {
	  HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
	  /* LCW - add an additional argument 0 (attr1) -8/9/95 */
	  HC_gen_sub(cb, &dest, src1, src2, 1, 0);
	  HC_dup(src1, &dest);
	  HC_new_int(src2, 0, unsign);
	  ret->type = HC_RET_SIMPLE;
	}
	break;
    case HC_RET_OR:
      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_or(cb, &dest, &(ret->op1), &(ret->op2), 0);
      HC_dup(&(ret->op1), &dest);
      HC_new_int(&(ret->op2), 0, unsign);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_AND:
      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_and(cb, &dest, &(ret->op1), &(ret->op2), 0);
      HC_dup(&(ret->op1), &dest);
      HC_new_int(&(ret->op2), 0, unsign);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_XOR:
      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_xor(cb, &dest, &(ret->op1), &(ret->op2), 0);
      HC_dup(&(ret->op1), &dest);
      HC_new_int(&(ret->op2), 0, unsign);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_EQ:
      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_eq(cb, &dest, &(ret->op1), &(ret->op2), NULL, 0);
      HC_dup(&(ret->op1), &dest);
      HC_new_int(&(ret->op2), 0, unsign);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_NE:
      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_ne(cb, &dest, &(ret->op1), &(ret->op2), 0);
      HC_dup(&(ret->op1), &dest);
      HC_new_int(&(ret->op2), 0, unsign);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_GT:
      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_gt(cb, &dest, &(ret->op1), &(ret->op2), 0, 0);
      HC_dup(&(ret->op1), &dest);
      HC_new_int(&(ret->op2), 0, unsign);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_GT_U:
      if (L_propagate_sign_size_ctype_info) 
        HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 1);
      else
        HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_gt(cb, &dest, &(ret->op1), &(ret->op2), 1, 0);
      HC_dup(&(ret->op1), &dest);
      if (L_propagate_sign_size_ctype_info) 
	HC_new_int(&(ret->op2), 0, 1);
      else
	HC_new_int(&(ret->op2), 0, 0);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_GE:
      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_ge(cb, &dest, &(ret->op1), &(ret->op2), 0, 0);
      HC_dup(&(ret->op1), &dest);
      HC_new_int(&(ret->op2), 0, unsign);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_GE_U:
      if (L_propagate_sign_size_ctype_info) 
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 1);
      else
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_ge(cb, &dest, &(ret->op1), &(ret->op2), 1, 0);
      HC_dup(&(ret->op1), &dest);
      if (L_propagate_sign_size_ctype_info) 
	HC_new_int(&(ret->op2), 0, 1);
      else
	HC_new_int(&(ret->op2), 0, 0);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_LT:
      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_lt(cb, &dest, &(ret->op1), &(ret->op2), 0, 0);
      HC_dup(&(ret->op1), &dest);
      HC_new_int(&(ret->op2), 0, unsign);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_LT_U:
      if (L_propagate_sign_size_ctype_info) 
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 1);
      else
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_lt(cb, &dest, &(ret->op1), &(ret->op2), 1, 0);
      HC_dup(&(ret->op1), &dest);
      if (L_propagate_sign_size_ctype_info) 
	HC_new_int(&(ret->op2), 0, 1);
      else
	HC_new_int(&(ret->op2), 0, 0);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_LE:
      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, unsign);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_le(cb, &dest, &(ret->op1), &(ret->op2), 0, 0);
      HC_dup(&(ret->op1), &dest);
      HC_new_int(&(ret->op2), 0, unsign);
      ret->type = HC_RET_SIMPLE;
      break;
    case HC_RET_LE_U:
      if (L_propagate_sign_size_ctype_info) 
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 1);
      else
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
      /* LCW - add an additional argument 0 (attr1) -8/9/95 */
      HC_gen_le(cb, &dest, &(ret->op1), &(ret->op2), 1, 0);
      HC_dup(&(ret->op1), &dest);
      if (L_propagate_sign_size_ctype_info) 
	HC_new_int(&(ret->op2), 0, 1);
      else
	HC_new_int(&(ret->op2), 0, 0);
      ret->type = HC_RET_SIMPLE;
      break;
    default:
	Punt("HC_simplify: illegal type");
    }
}
/*--------------------------------------------------------------------------*/
#define VAR_IN_REGISTER	  0
#define VAR_IN_MEMORY	  1

static void gen_var_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    _HC_Ret addr;
    int in_reg;
    _M_Type mtype;
    in_reg = (gen_var_addr(cb, expr, &addr)==VAR_IN_REGISTER);
    if (in_reg) {
	*ret = addr;
    } else
    if (is_addr_expr(expr)) {
	*ret = addr;
    } else {
	_HC_Operand dest, zero;
	L_Attr *attr= NULL; /* LCW 8/3/95 */
	HC_hcode2lcode_type(expr->type, &mtype);
	if (L_propagate_sign_size_ctype_info)
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
	else
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);
	HC_new_int(&zero, 0, 0);

	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);


	if (addr.type==HC_RET_SIMPLE) {
	    /* LCW -- change the last argument from 0 to attr - 8/3/95 */
	    HC_gen_load(cb, expr,&dest, &(addr.op1), &zero, mtype.unsign, attr);
	} else
	if (addr.type==HC_RET_ADD) {
	    /* LCW -- change the last argument from 0 to attr - 8/3/95 */ 
	    HC_gen_load(cb, expr,&dest, &(addr.op1), &(addr.op2), mtype.unsign, attr);
	} else
	if ((addr.type==HC_RET_SUB) & (addr.op2.type==HC_I)) {
	    addr.op2.value.i = - addr.op2.value.i;
	    addr.type = HC_RET_ADD;
	    /* LCW -- change the last argument from 0 to attr - 8/3/95 */
	    HC_gen_load(cb, expr,&dest, &(addr.op1), &(addr.op2), mtype.unsign, attr);
	} else {
	    HC_simplify(cb, &addr);
	    /* LCW -- change the last argument from 0 to attr - 8/3/95 */
	    HC_gen_load(cb, expr,&dest, &(addr.op1), &zero, mtype.unsign, attr);
	}
	ret->type = HC_RET_SIMPLE;
	ret->op1 = dest;
	ret->op2 = zero;
    }
}

int gen_var_addr(L_Cb *cb, Expr expr, HC_Ret ret)
{
    _M_Type type, mtype;
    int in_reg, reg_id, mem_offset;
    char *mem_base_macro;
    if (HC_find_local_var(expr->value.var_name,
		&type, &in_reg, &reg_id, &mem_base_macro, &mem_offset)) {
        if (L_propagate_sign_size_ctype_info)
	  M_eval_type2(&type, &mtype);
	else
	  M_eval_type(&type, &mtype);
	if (in_reg) {
	    ret->type = HC_RET_SIMPLE;
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_register(&(ret->op1), reg_id, mtype.type, mtype.unsign);
	    else
	      HC_new_register(&(ret->op1), reg_id, mtype.type, 0);
	    HC_new_int(&(ret->op2), 0, 0);
	    return VAR_IN_REGISTER;
	} else {
	    ret->type = HC_RET_ADD;
	    HC_new_macro(&(ret->op1), mem_base_macro, M_TYPE_POINTER, 0);
	    HC_new_int(&(ret->op2), mem_offset, 0);
	    return VAR_IN_MEMORY;
	}
    } else
    if (HC_find_param_var(expr->value.var_name,
		&type, &in_reg, &reg_id, &mem_base_macro, &mem_offset)) {
        if (L_propagate_sign_size_ctype_info)
	  M_eval_type2(&type, &mtype);
	else
	  M_eval_type(&type, &mtype);
	if (in_reg) {
	    ret->type = HC_RET_SIMPLE;
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_register(&(ret->op1), reg_id, mtype.type, mtype.unsign);
	    else
	      HC_new_register(&(ret->op1), reg_id, mtype.type, 0);
	    HC_new_int(&(ret->op2), 0, 0);
	    return VAR_IN_REGISTER;
	} else {
	    ret->type = HC_RET_ADD;
	    HC_new_macro(&(ret->op1), mem_base_macro, M_TYPE_POINTER, 0);
	    HC_new_int(&(ret->op2), mem_offset, 0);
	    return VAR_IN_MEMORY;
	}
    } else {
	ret->type = HC_RET_SIMPLE;
	HC_new_label(&(ret->op1), expr->value.var_name);
	HC_new_int(&(ret->op2), 0, 0);
	return VAR_IN_MEMORY;
    }
}
static void gen_indr_addr(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1;
    op1 = GetOperand(expr, 1);
    if (op1==0) Punt("gen_indr_addr: missing operand");
    HC_gen_data(cb, op1, ret);
}

static void gen_index_addr(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1, op2;
    int size;
    _HC_Ret x, y;
    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    size = H_lcode_typesize(expr->type);
    HC_gen_data(cb, op1, &x);
    HC_gen_data(cb, op2, &y);
    HC_ret_mulC(cb, &y, size);	/* y * size */
    HC_ret_add(cb, ret, &x, &y);	/* x + (y * size) */
}
static void gen_dot_addr(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1;
    long offset, bit_mask;
    int is_bit, bit_offset, length;
    _M_Type mtype;
    _HC_Ret x, y;
    op1 = GetOperand(expr, 1);
    if (! IsStructureType(op1->type))
	Punt("gen_dot_addr: LHS is not a structure");
    HC_gen_addr(cb, op1, &x);
    if (op1->type->type & TY_STRUCT) {
/* REH 9/12/93 - added length parameter */
	HC_struct_field_info(
		op1->type->struct_name,
		expr->value.string,
		&offset, &mtype, &is_bit, &bit_offset, &bit_mask, &length);
    } else {
/* REH 9/12/93 - added length parameter */
	HC_union_field_info(
		op1->type->struct_name,
		expr->value.string,
		&offset, &mtype, &is_bit, &bit_offset, &bit_mask, &length);
    }
    /* REH 2/7/96 */
    /* These global variables are no longer necessary.  Whether a */
    /* field access is a bit field or not can be determined       */
    /* directly from the type field (TY_BIT_FIELD).  The size and */
    /* offset information is determined by calling the function   */
    /* HC_struct(union)_field_info for the field when necessary.  */
#if 0
    HC_is_bit_field = is_bit;
    HC_bit_field_shift = bit_offset;
    HC_bit_field_mask = bit_mask;

    HC_bit_field_length = length;     /* DMC 8/3/95 */
#endif

    if (is_bit) {
/* REH 2/2/96 - determine size base upon type not length */
	if ( mtype.type == M_TYPE_BIT_CHAR )
	    expr->type->type = TY_BIT_FIELD|TY_CHAR|TY_UNSIGNED;
	/*
	    HC_bit_field_type = TY_CHAR|TY_UNSIGNED;
	    */
	else if ( mtype.type == M_TYPE_BIT_SHORT )  {
	    expr->type->type = TY_BIT_FIELD|TY_SHORT|TY_UNSIGNED;
	    /*
	    HC_bit_field_type = TY_SHORT|TY_UNSIGNED;
	    */
	    offset &= ~(0x1);
  	}
	else if ( mtype.type == M_TYPE_BIT_LONG ) {
	    expr->type->type = TY_BIT_FIELD|TY_INT|TY_UNSIGNED;
	    /*
	    HC_bit_field_type = TY_INT|TY_UNSIGNED;
	    */
	    offset &= ~(0x3);
	}
#if 0
        if ( length <= M_type_size(M_TYPE_CHAR) )  
	    HC_bit_field_type = TY_CHAR|TY_UNSIGNED;
        else if ( length <= M_type_size(M_TYPE_SHORT) ) {
	    HC_bit_field_type = TY_SHORT|TY_UNSIGNED;
	    offset &= ~(0x1);
        }
        else if ( length <= M_type_size(M_TYPE_INT) )  {
	    HC_bit_field_type = TY_INT|TY_UNSIGNED;
	    offset &= ~(0x3);
        }
#endif
    }
    HC_reset_ret(&y);
    y.type = HC_RET_SIMPLE;
    HC_new_int(&(y.op1), offset, 0);
    HC_ret_add(cb, ret, &x, &y);
}
static void gen_arrow_addr(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1;
    Type type, lhs_type;
    Dcltr dcltr;
    long offset, bit_mask;
    int is_bit, bit_offset,length;
    _M_Type mtype;
    _HC_Ret x, y, z;
    op1 = GetOperand(expr, 1);
    if (! IsPointerType(op1->type))
	Punt("gen_arrow_addr: LHS is not a pointer");
    type = op1->type;
    dcltr = type->dcltr;
    type->dcltr = dcltr->next;
    if (! IsStructureType(op1->type))
	Punt("gen_arrow_addr: LHS is not a pointer to structure");
    type->dcltr = dcltr;
    HC_gen_data(cb, op1, &x);
    if (op1->type->type & TY_STRUCT) {
/* REH 9/12/93 - added length parameter */
	HC_struct_field_info(
		op1->type->struct_name,
		expr->value.string,
		&offset, &mtype, &is_bit, &bit_offset, &bit_mask, &length);
    } else {
/* REH 9/12/93 - added length parameter */
	HC_union_field_info(
		op1->type->struct_name,
		expr->value.string,
		&offset, &mtype, &is_bit, &bit_offset, &bit_mask, &length);
    }
    /* REH 2/7/96 */
    /* These global variables are no longer necessary.  Whether a */
    /* field access is a bit field or not can be determined       */
    /* directly from the type field (TY_BIT_FIELD).  The size and */
    /* offset information is determined by calling the function   */
    /* HC_struct(union)_field_info for the field when necessary.  */
#if 0
    HC_is_bit_field = is_bit;
    HC_bit_field_shift = bit_offset;
    HC_bit_field_mask = bit_mask;
    HC_bit_field_length = length;    /* DMC 8/3/95 */
#endif

    if (is_bit) {
/* REH 2/2/96 - determine size base upon type not length */
	if ( mtype.type == M_TYPE_BIT_CHAR )  {
	    expr->type->type = TY_BIT_FIELD|TY_CHAR|TY_UNSIGNED;
	    /*
	    HC_bit_field_type = TY_CHAR|TY_UNSIGNED;
	    */
	}
	else if ( mtype.type == M_TYPE_BIT_SHORT )  {
	    expr->type->type = TY_BIT_FIELD|TY_SHORT|TY_UNSIGNED;
	    /*
	    HC_bit_field_type = TY_SHORT|TY_UNSIGNED;
	    */
	    offset &= ~(0x1);
  	}
	else if ( mtype.type == M_TYPE_BIT_LONG ) {
	    expr->type->type = TY_BIT_FIELD|TY_INT|TY_UNSIGNED;
	    /*
	    HC_bit_field_type = TY_INT|TY_UNSIGNED;
	    */
	    offset &= ~(0x3);
	}
#if 0
        if ( length <= M_type_size(M_TYPE_CHAR) )
            HC_bit_field_type = TY_CHAR|TY_UNSIGNED;
        else if ( length <= M_type_size(M_TYPE_SHORT) ) {
            HC_bit_field_type = TY_SHORT|TY_UNSIGNED;
	    offset &= ~(0x1);
        }
        else if ( length <= M_type_size(M_TYPE_INT) )  {
            HC_bit_field_type = TY_INT|TY_UNSIGNED;
	    offset &= ~(0x3);
        }
#endif
    }

    HC_reset_ret(&y);
    y.type = HC_RET_SIMPLE;
    HC_new_int(&(y.op1), offset, 0);
    HC_ret_add(cb, ret, &x, &y);
}
/*
 *	if the returned type is a struct/union/array/function,
 *	then we consider it to be an address. HC_gen_data()
 *	will not try to load the value, but returns its
 *	starting address.
 */

int is_addr_expr(Expr expr)
{
    Type type = expr->type;
    Dcltr dcltr = type->dcltr;
    if (dcltr==0) {
	return ((type->type&TY_STRUCTURE)!=0);
    } else {
	    /* DMG - Because we now represent array variables as pointers,
		(which have an index expr), we also return 1 if the index
		field is present */
	return ( (dcltr->method!=D_PTR) || (dcltr->index != NULL));
    }
}

/* RAB - 3/25/94 */
static int is_indr_expr(Expr expr)
{
    Type type = expr->type;
    Dcltr dcltr = type->dcltr;
    if (dcltr==0) {
	return 0;
    } else {
	if ((type->type&TY_STRUCTURE)!=0)
	    return (dcltr->method==D_PTR);
	else return 0;
    }
}
/* BAR - 3/25/94 */

int HC_gen_addr(L_Cb *cb, Expr expr, HC_Ret ret)
{
    int opcode = expr->opcode;
#if 0
    HC_is_bit_field = 0;
    HC_bit_field_shift = 0;
    HC_bit_field_mask = 0;
#endif
    switch (opcode) {
    case OP_var:
	return gen_var_addr(cb, expr, ret);
	break;
    case OP_addr:
	Punt("it is illegal to take address of &");
	break;
    case OP_indr:
	gen_indr_addr(cb, expr, ret);
	return VAR_IN_MEMORY;
	break;
    case OP_index:
	gen_index_addr(cb, expr, ret);
	return VAR_IN_MEMORY;
	break;
    case OP_dot:
	gen_dot_addr(cb, expr, ret);
	return VAR_IN_MEMORY;
	break;
    case OP_arrow:
	gen_arrow_addr(cb, expr, ret);
	return VAR_IN_MEMORY;
	break;
    /* 
     * BCC - 2/26/96 
     * Consider ((int *)p)++; where p is a char pointer. All we have to do here
     * is generate the address the address of p. As for the size of increment
     * (1 or 4), that's gen_incr_data's business.
     */
    case OP_cast:
	return (HC_gen_addr(cb, expr->operands, ret));
    default:
	if (is_addr_expr(expr)) {
	    HC_gen_data(cb, expr, ret);
	    return VAR_IN_MEMORY;
	} else {
	    Gen_C_Expr(stderr, expr);
	    Punt("HC_gen_addr: incomplete coverage");
	}
    }
    return (0);
}
/*==========================================================================*/
/*
 *	!!! expr must have been ReduceExpr()ed.
 */
void HC_gen_data(L_Cb *cb,Expr expr, HC_Ret ret)
{
    int opcode;
    Expr op1, op2;
    Type type;
    VarList ptr;
    VarDcl var;
    char *var_name;

    if (expr==0) Punt("HC_gen_data: nil expr");
    HC_reset_ret(ret);
    opcode = expr->opcode;
    switch (opcode) {
    case OP_var:
	gen_var_data(cb, expr, ret);
	break;
    case OP_enum:  /* 2-6-1991 */
	HC_new_int(&(ret->op1), H_lcode_enum_value(expr->value.string), 0);
	ret->type = HC_RET_SIMPLE;
	break;
    case OP_char:
      if (L_propagate_sign_size_ctype_info) 
	HC_new_char(&(ret->op1), IntegralExprValue(expr), expr->type->type & TY_UNSIGNED);
      else
	HC_new_int(&(ret->op1), IntegralExprValue(expr), 0);
      ret->type = HC_RET_SIMPLE;
      break;
    case OP_signed:
      if (L_propagate_sign_size_ctype_info) {
	if (expr->type->type & TY_CHAR)
	  HC_new_char(&(ret->op1), IntegralExprValue(expr), 0);
	if (expr->type->type & TY_SHORT)
	  HC_new_short(&(ret->op1), IntegralExprValue(expr), 0);
	if (expr->type->type & TY_INT)
	  HC_new_int(&(ret->op1), IntegralExprValue(expr), 0);
	if (expr->type->type & TY_LONG)
	  HC_new_long(&(ret->op1), IntegralExprValue(expr), 0);
      }
      else 
	HC_new_int(&(ret->op1), IntegralExprValue(expr), 0);
      ret->type = HC_RET_SIMPLE;
      break;
    case OP_unsigned:
      if (L_propagate_sign_size_ctype_info) {
	if (expr->type->type & TY_CHAR)
	  HC_new_char(&(ret->op1), IntegralExprValue(expr), 1);
	if (expr->type->type & TY_SHORT)
	  HC_new_short(&(ret->op1), IntegralExprValue(expr), 1);
	if (expr->type->type & TY_INT)
	  HC_new_int(&(ret->op1), IntegralExprValue(expr), 1);
	if (expr->type->type & TY_LONG)
	  HC_new_long(&(ret->op1), IntegralExprValue(expr), 1);
      }
      else 
	HC_new_int(&(ret->op1), IntegralExprValue(expr), 0);
      ret->type = HC_RET_SIMPLE;
      break;
    case OP_float:
#if 0
	if (IsFloatType(expr->type)) {
/*** SAM 9-25-91
	    HC_new_float(&(ret->op1), (float) expr->value.real);
***/
            HC_new_float(&(ret->op1), expr->value.real);
	} else {
	    HC_new_double(&(ret->op1), expr->value.real);
	}
#endif
	/* BCC - added OP_double for double - 8/5/96 */
	HC_new_float(&(ret->op1), expr->value.real);
	if (!IsFloatType(expr->type)) 
	    Punt("OP_float type mismatch");
	ret->type = HC_RET_SIMPLE;
	break;
    /* BCC - added - 8/5/96 */
    case OP_double:
	HC_new_double(&(ret->op1), expr->value.real);
	if (!IsDoubleType(expr->type))
	    Punt("OP_double type mismatch");
	ret->type = HC_RET_SIMPLE;
	break;
    case OP_expr_size:
            /* DMG - for arrays, the type of the variable reference is D_PTR;
                to correctly compute sizeof(A), we must use type from symbol
                table, not the variable itself */
	op1 = GetOperand(expr, 1);
/*
	if ( (op1->opcode == OP_var) && (op1->type->dcltr != NULL) &&
             (op1->type->dcltr->method == D_PTR) ) { 
	    type = NULL;
            var_name = op1->value.var_name;

            if (currentFuncDcl!=0) {
              for (ptr=currentFuncDcl->local; ptr!=0; ptr=ptr->next) {
                if (! strcmp(ptr->var->name, var_name)) {
                    type = ptr->var->type;
                }
              }
            }
            if ( (type == NULL) && (currentFuncDcl!=0) ){
              for (ptr=currentFuncDcl->param; ptr!=0; ptr=ptr->next) {
                if (! strcmp(ptr->var->name, var_name)) {
                    type = ptr->var->type;
                }
              }
            }

            if ( type == NULL ) {
                var = FindVar (var_name);
                if (var != NULL) {
                    type = var->type;
                }
                else {
                    Punt("illegal sizeof expression: var not found in tables");
                }
            }
        }
        else {
            type = op1->type;
        }
*/

	type = op1->type;

	HC_new_int(&(ret->op1), H_lcode_typesize(type), 0);
	ret->type = HC_RET_SIMPLE;
	break;
    case OP_type_size:
	HC_new_int(&(ret->op1), H_lcode_typesize(expr->value.type), 0);
	ret->type = HC_RET_SIMPLE;
	break;
    case OP_string:
	HC_new_string(&(ret->op1), expr->value.string);
	ret->type = HC_RET_SIMPLE;
	break;
    case OP_dot:
	gen_dot_data(cb, expr, ret);
	break;
    case OP_arrow:
	gen_arrow_data(cb, expr, ret);
	break;
    case OP_cast:
	gen_cast_data(cb, expr, ret);
	break;
    case OP_quest:
    case OP_disj:
    case OP_conj:
	Punt("HCODE must have been flattened before generating LCODE");
	break;
    case OP_comma:
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	HC_gen_data(cb, op1, ret);	/* ignore the result */
	HC_gen_data(cb, op2, ret);
	break;
    case OP_assign:
	gen_assign_data(cb, expr, ret);
	break;
    case OP_or:
    case OP_xor:
    case OP_and:
	gen_logic_data(cb, expr, ret);
	break;
    case OP_eq:
    case OP_ne:
    case OP_lt:
    case OP_le:
    case OP_ge:
    case OP_gt:
	gen_compare_data(cb, expr, ret);
	break;
    case OP_rshft:
    case OP_lshft:
	gen_shift_data(cb, expr, ret);
	break;
/* NJW */
    case OP_sync:
	gen_sync_data(cb, expr, ret);
	break;
/* WJN */
    /* LCW - new Hcode opcode OP_nulldefine - 10/24/96 */
    case OP_nulldefine:
        gen_nulldefine_data(cb, expr, ret);
	break;
    case OP_add:
	gen_add_data(cb, expr, ret);
	break;
    case OP_sub:
	gen_sub_data(cb, expr, ret);
	break;
    case OP_mul:
	gen_mul_data(cb, expr, ret);
	break;
    case OP_div:
	gen_div_data(cb, expr, ret);
	break;
    case OP_mod:
	gen_mod_data(cb, expr, ret);
	break;
    case OP_neg:
    case OP_not:
    case OP_inv:
    case OP_abs:
	gen_unary_data(cb, expr, ret);
	break;
    case OP_preinc:
    case OP_predec:
    case OP_postinc:
    case OP_postdec:
	gen_incr_data(cb, expr, ret);
	break;
    case OP_Aadd:
    case OP_Asub:
    case OP_Amul:
    case OP_Adiv:
    case OP_Amod:
    case OP_Arshft:
    case OP_Alshft:
    case OP_Aand:
    case OP_Aor:
    case OP_Axor:
	gen_Aarith_data(cb, expr, ret);
	break;
    case OP_indr:
	gen_indr_data(cb, expr, ret);
	break;
    case OP_addr:
	op1 = GetOperand(expr, 1);
	if (HC_gen_addr(cb, op1, ret)==VAR_IN_REGISTER) {
	    Punt("HC_gen_data: cannot compute memory address of a register");
	}
	break;
    case OP_index:
	gen_index_data(cb, expr, ret);
	break;
    case OP_call:
	gen_call_data(cb, expr, ret);
	break;
    case OP_return:
    case OP_goto:
    case OP_if:
    case OP_switch:
	Punt("HC_gen_data: cannot handle control operations");
	break;
    default:
	Punt("HC_gen_data: illegal opcode");
    }
}

/*--------------------------------------------------------------------------*/
static void gen_load_data(L_Cb *cb, Expr expr, HC_Ret addr, 
				HC_Ret data, Type type)
{
    _M_Type mtype;
    _HC_Operand dest, zero;
    L_Attr *attr= NULL; /* LCW 8/3/95 */
    HC_hcode2lcode_type(type, &mtype);
    if (L_propagate_sign_size_ctype_info)
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
    else
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);
    HC_new_int(&zero, 0, 0);

    /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
    if (expr->pragma != 0)
       attr = HC_gen_attr_from_pragma(expr->pragma);

    if (addr->type==HC_RET_SIMPLE) {
	/* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_load(cb, expr, &dest, &(addr->op1), &zero, mtype.unsign, attr);
    } else
    if (addr->type==HC_RET_ADD) {
	/* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_load(cb, expr,&dest,&(addr->op1),&(addr->op2), mtype.unsign, attr);
    } else
    if ((addr->type==HC_RET_SUB) & (addr->op2.type==HC_I)) {
	addr->op2.value.i = - addr->op2.value.i;
	addr->type = HC_RET_ADD;
	/* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_load(cb,expr,&dest,&(addr->op1), &(addr->op2), mtype.unsign, attr);
    } else {
	HC_simplify(cb, addr);
	/* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_load(cb, expr, &dest, &(addr->op1), &zero, mtype.unsign, attr);
    }
    data->type = HC_RET_SIMPLE;
    data->op1 = dest;
    data->op2 = zero;
}

static void gen_store_data(L_Cb *cb, Expr expr, HC_Ret addr, 
				HC_Ret data, Type type)
{
    _M_Type mtype;
    _HC_Operand zero;
    L_Attr *attr= NULL; /* LCW 8/3/95 */
    HC_hcode2lcode_type(type, &mtype);
    HC_simplify(cb, data);
    HC_new_int(&zero, 0, 0);

    /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
    if (expr->pragma != 0)
       attr = HC_gen_attr_from_pragma(expr->pragma);

    if (addr->type==HC_RET_SIMPLE) {
       /* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_store(cb, expr, &(addr->op1), &zero, &(data->op1), mtype.type, attr);
    } else
    if (addr->type==HC_RET_ADD) {
       /* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_store(cb, expr, &(addr->op1),&(addr->op2),&(data->op1),mtype.type,attr);
    } else
    if ((addr->type==HC_RET_SUB) & (addr->op2.type==HC_I)) {
	addr->op2.value.i = - addr->op2.value.i;
	addr->type = HC_RET_ADD;
	/* LCW -- change the last argument from NULL to attr - 8/3/95 */
	HC_gen_store(cb, expr,&(addr->op1),&(addr->op2),&(data->op1),mtype.type,attr);
    } else {
	HC_simplify(cb, addr);
	/* LCW -- change the last argument from NULL to attr - 8/3/95 */
	HC_gen_store(cb, expr,&(addr->op1),&zero,&(data->op1),mtype.type,attr);
    }
}

int
HC_is_bit_mask_block(mask,mask_length)
int mask;
int *mask_length;
{
  int cnt = 0;
  *mask_length =0;
  while ( !(mask & 0x01) ) {
    mask >>= 1;
    cnt += 1;
  }

  if (cnt==32)
     return 0;

  while ( (mask & 0x01) ) {
    mask >>= 1;
    *mask_length = *mask_length + 1;
    cnt += 1;
  }

 if (mask==0)
   return 1;

 return 0;
}


/*--------------------------------------------------------------------------*/
static void gen_extract_bit_field(L_Cb *cb, HC_Ret data, int bit_shift, 
			long bit_mask)
{
    _HC_Operand dest, src1, src2,src3;
    int length;
    HC_simplify(cb, data);
    src1 = data->op1;
    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
    /* masking */

    if (HL_gen_bit_field_operations) {

	if (HC_is_bit_mask_block(bit_mask,&length)) {
   	    HC_new_int(&src2, bit_shift, 0);
	    HC_new_int(&src3, length, 0);
	    HC_gen_extract_bits(cb,&dest,&src1,&src2,&src3);
    	    data->type = HC_RET_SIMPLE;
            data->op1 = dest;
            HC_new_int(&(data->op2), 0, 0);
 	    return;
	}
       /* Else need to generate original bit field extraction */

    }
    HC_new_int(&src2, bit_mask, 0);
    /* LCW -- add an additional argument 0 (attr1) - 8/9/95 */
    HC_gen_and(cb, &dest, &src1, &src2, 0);
    src1 = dest;
    /* shift */
    if (bit_shift!=0) {
	HC_new_int(&src2, bit_shift, 0);
	/* LCW -- add an additional argument 0 (attr1) - 8/9/95 */
	HC_gen_lsr(cb, &dest, &src1, &src2, 0);
    } else {
	dest = src1;
    }
    data->type = HC_RET_SIMPLE;
    data->op1 = dest;
    HC_new_int(&(data->op2), 0, 0);
 
}

static void gen_insert_bit_field(L_Cb *cb, HC_Ret data, HC_Ret field, 
			    int bit_shift, long bit_mask)
{
    _HC_Operand dest1, dest2, src1, src2, src3, src4;
    int length;
    HC_simplify(cb, data);
    HC_simplify(cb, field);

    if (HL_gen_bit_field_operations) {

	/* Need to check that mask is block */
	if (HC_is_bit_mask_block(bit_mask,&length)) {
	   src1 = data->op1;
	   src2 = field->op1;
      	   HC_new_register(&dest1, HC_next_reg_id(), M_TYPE_INT, 0);
           HC_gen_mov(cb, &dest1, &src1,0);
   	   HC_new_int(&src3, bit_shift, 0);
	   HC_new_int(&src4, length, 0);
	   HC_gen_deposit_bits(cb,&dest1,&src2,&src3,&src4,&dest1);
    	   data->type = HC_RET_SIMPLE;
           data->op1 = dest1;
           HC_new_int(&(data->op2), 0, 0);
	   return;
	}
       /* Else need to generate original bit field extraction */
    }

    /*
     *	dest1 = data & ~mask
     */
    src1 = data->op1;
    HC_new_int(&src2, ~bit_mask, 0);
    HC_new_register(&dest1, HC_next_reg_id(), M_TYPE_INT, 0);
    /* LCW - add an additional argument 0 (attr1) -8/9/95 */
    HC_gen_and(cb, &dest1, &src1, &src2, 0);
    /*
     *	field = field << shift
     */
    src1 = field->op1;
    HC_new_int(&src2, bit_shift, 0);
    HC_new_register(&dest2, HC_next_reg_id(), M_TYPE_INT, 0);
    /* LCW - add an additional argument 0 (attr1) -8/9/95 */
    HC_gen_lsl(cb, &dest2, &src1, &src2, 0);
    /*
     *	dest2 = field & mask
     */
    src1 = dest2;
    HC_new_int(&src2, bit_mask, 0);
    /* LCW - add an additional argument 0 (attr1) -8/9/95 */
    HC_gen_and(cb, &dest2, &src1, &src2, 0);
    /*
     *	data = dest1 | dest2
     */
    src1 = dest1;
    src2 = dest2;
    /* LCW - add an additional argument 0 (attr1) -8/9/95 */
    HC_gen_or(cb, &dest2, &src1, &src2, 0);
    data->type = HC_RET_SIMPLE;
    data->op1 = dest2;
    HC_new_int(&(data->op2), 0, 0);
}
/*==========================================================================*/
static void gen_dot_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    _HC_Ret addr, data;
    int bit_field_shift, bit_field_length; 
    long bit_field_mask;
    gen_dot_addr(cb, expr, &addr);
    if (! is_addr_expr(expr)) {
	_M_Type mtype;
	HC_hcode2lcode_type(expr->type, &mtype);
	/* The expression type indicates whether or not we are */
	/* accessing a bit field			       */
	if ( expr->type->type & TY_BIT_FIELD ) {
	/*
	if (HC_is_bit_field) {
	*/
	    _Type type;
	    /* REH 2/7/96 */
	    Expr op1;
	    _M_Type mtype;
	    long dummy1;
	    int dummy2;

/* REH 9/12/93 
	    type.type = TY_INT;
*/	     
	    /* REH 2/7/96 
	    type.type = HC_bit_field_type;
	    */
	    	
/* HER */
	    /* The bit field type is now in the expression type */
	    type.type = expr->type->type;
	    type.dcltr = 0;
	    type.struct_name = 0;

	    /* REH 2/7/96 
            bit_field_shift = HC_bit_field_shift;
            bit_field_length = HC_bit_field_length;
	    */
	

	    /* REH 2/7/96 - Determine bit field information directly */
	    /* from the symbol table.				     */
	    op1 = GetOperand(expr, 1);
	    if (op1->type->type & TY_STRUCT) {
	          HC_struct_field_info(op1->type->struct_name,
				 expr->value.string,
				 &dummy1, &mtype, &dummy2, &bit_field_shift, 
				 &bit_field_mask, &bit_field_length);
	    } else {
	          HC_union_field_info(op1->type->struct_name,
				      expr->value.string,
				      &dummy1, &mtype, &dummy2, &bit_field_shift, 
				      &bit_field_mask, &bit_field_length);
            }
	    /* HER */

            if ((bit_field_shift == 0) &&                     /* DMC 8/3/95 */
                ((bit_field_length == M_type_size(M_TYPE_CHAR)) ||
                 (bit_field_length == M_type_size(M_TYPE_SHORT)) ||
                 (bit_field_length == M_type_size(M_TYPE_INT))))
            {
                gen_load_data(cb, expr, &addr, &data, &type);
            } else {
	        gen_load_data(cb, expr, &addr, &data, &type);
	        gen_extract_bit_field(cb, &data, bit_field_shift,
			bit_field_mask);
            }
	} else {
	    gen_load_data(cb, expr, &addr, &data, expr->type);
 	}
	*ret = data;
    } else {
	*ret = addr;
    }
}
/*--------------------------------------------------------------------------*/
static void gen_arrow_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    _HC_Ret addr, data;
    int bit_field_shift, bit_field_length; 
    long bit_field_mask;
    gen_arrow_addr(cb, expr, &addr);
    if (! is_addr_expr(expr)) {
	_M_Type mtype;
	HC_hcode2lcode_type(expr->type, &mtype);
	/* The expression type indicates whether or not we are */
	/* accessing a bit field			       */
	if ( expr->type->type & TY_BIT_FIELD ) {
	/*
	if (HC_is_bit_field) {
	*/
	    _Type type;
	    /* REH 2/7/96 */
	    Expr op1;
	    _M_Type mtype;
	    long dummy1;
	    int dummy2;
	    
/* REH 9/12/93 
	    type.type = TY_INT;
*/
	    /* REH 2/7/96
	    type.type = HC_bit_field_type;
	    */
/* HER */
	    /* The bit field type is now in the expression type */
	    type.type = expr->type->type;
	    type.dcltr = 0;
	    type.struct_name = 0;

	    
#if 0
	    /* REH 2/7/96
            bit_field_shift = HC_bit_field_shift;
            bit_field_length = HC_bit_field_length;
	    */
#endif

	    /* REH 2/7/96 - Determine bit field information directly */
	    /* from the symbol table.				     */
	    op1 = GetOperand(expr, 1);
	    if (op1->type->type & TY_STRUCT) {
	          HC_struct_field_info(op1->type->struct_name,
				 expr->value.string,
				 &dummy1, &mtype, &dummy2, &bit_field_shift, 
				 &bit_field_mask, &bit_field_length);
	    } else {
	          HC_union_field_info(op1->type->struct_name,
				      expr->value.string,
				      &dummy1, &mtype, &dummy2, &bit_field_shift, 
				      &bit_field_mask, &bit_field_length);
            }
	    /* HER */
	    
            if ((bit_field_shift == 0) &&                     /* DMC 8/3/95 */
                ((bit_field_length == M_type_size(M_TYPE_CHAR)) ||
                 (bit_field_length == M_type_size(M_TYPE_SHORT)) ||
                 (bit_field_length == M_type_size(M_TYPE_INT))))
            {
                gen_load_data(cb, expr, &addr, &data, &type);
            } else {
	        gen_load_data(cb, expr, &addr, &data, &type);
	        gen_extract_bit_field(cb, &data, bit_field_shift,
			bit_field_mask);
            }
	} else {
	    gen_load_data(cb, expr, &addr, &data, expr->type);
	}
	*ret = data;
    } else {
	*ret = addr;
    }
}
/*--------------------------------------------------------------------------*/
static void gen_jsr_cast_attr(L_Cb *cb, HC_Ret ret, Type type)
/* This is used solely by the static branch prediction software to determine
 * the type of the destination variable used to hold the return value
 * of a jsr call.  If the cast is associated with a jsr return value, the
 * Lcode attribute, "jsr_cast", gets created and put onto the jsr.  It allows
 * the static branch prediction software to be able to intelligently group
 * generic function calls. */
{
    L_Operand *macro_operand;
    int operand_reg_id;
    L_Oper *oper;
    L_Attr *attr;

    if (!type->dcltr || type->dcltr->method != D_PTR) /* only continue if a
                                                       * pointer is involved */
	return;
    if (ret->op1.type != HC_R) /* only continue if a register is used in the
                                * cast */
	return;

    operand_reg_id = ret->op1.value.r;
    for (oper = cb->last_op; oper; oper = oper->prev_op)
	if (L_int_move_opcode (oper) && L_is_register (oper->dest[0]) &&
	    oper->dest[0]->value.r == operand_reg_id) {
 	/* only worry about move operations, and follow the def-use chain until
	 * a macro is encountered as a move source */
	    if (L_is_macro (oper->src[0])) {
		macro_operand = oper->src[0];
		break;
	    }
	    else if (L_is_register (oper->src[0]))
		operand_reg_id = oper->src[0]->value.r;
	    else /* this is not a valid situation, so give up */
		return;
	}

    if (!oper) /* did not determine that a jsr is involved, so give up */
	return;

    for (oper = oper->prev_op; oper; oper = oper->prev_op)
	if (L_subroutine_call_opcode (oper)) {
	    if (attr = L_find_attr (oper->attr, "ret")) {
		if (L_same_operand (attr->field[0], macro_operand)) {
		    char *attr_name;
		    L_Attr *new_attr;
		    int struct_name_size = 0;

		    if (type->struct_name)
			struct_name_size = 1 + strlen (type->struct_name);
		    attr_name = (char *) Lcode_malloc (struct_name_size + 20);
		    sprintf (attr_name, "\"%d_\0", type->type);
		    if (type->struct_name)
			strcat (attr_name, type->struct_name);
		    strcat (attr_name, "\"");

		    new_attr = L_new_attr ("jsr_cast", 1);
		    L_set_string_attr_field (new_attr, 0, attr_name);
		    oper->attr = L_concat_attr (oper->attr, new_attr);
		    Lcode_free (attr_name);
		}
	    }
	    return;
	}
}
/*--------------------------------------------------------------------------*/
static void gen_cast_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op;
    Type type, op_type;
    _M_Type tm, mtype, op_mtype;
    _HC_Operand dest;

    type = expr->type;
    HC_hcode2lcode_type(type, &tm);
    if (L_propagate_sign_size_ctype_info)
      M_eval_type2(&tm, &mtype);
    else
      M_eval_type(&tm, &mtype);
    op = GetOperand(expr, 1);
    op_type = op->type;
    HC_hcode2lcode_type(op_type, &tm);
    if (L_propagate_sign_size_ctype_info)
      M_eval_type2(&tm, &op_mtype);
    else
      M_eval_type(&tm, &op_mtype);
    HC_gen_data(cb, op, ret);
    HC_simplify(cb, ret);

    if (IsFloatType(type)) {
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	bcc_cast_float(cb, &dest, &(ret->op1), type->type & TY_UNSIGNED);
	ret->op1 = dest;
	ret->type = HC_RET_SIMPLE;
    } else 
    if (IsDoubleType(type)) {
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	bcc_cast_double(cb, &dest, &(ret->op1), type->type & TY_UNSIGNED);
	ret->op1 = dest;
	ret->type = HC_RET_SIMPLE;
    } else
    if (IsIntegralType(type)) {
	if (type->type & TY_CHAR) {
  	    if (L_propagate_sign_size_ctype_info)
	      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_CHAR, type->type & TY_UNSIGNED);
	    else
	      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_CHAR, 0);
	    bcc_cast_char(cb, &dest, &(ret->op1), type->type & TY_UNSIGNED);
	}
	else if (type->type & TY_SHORT) {
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_SHORT, type->type & TY_UNSIGNED);
	    else
	      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_SHORT, 0);
	    bcc_cast_short(cb, &dest, &(ret->op1), type->type & TY_UNSIGNED);
	}
	else {
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, type->type & TY_UNSIGNED);
	    else
	      HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    bcc_cast_int(cb, &dest, &(ret->op1), type->type & TY_UNSIGNED);
	};
	ret->op1 = dest;
	ret->type = HC_RET_SIMPLE;
    } 

    if (HL_generate_static_branch_attrs) /* only check into adding the jsr
			* check attribute if using static branch prediction */
	gen_jsr_cast_attr(cb, ret, type);
}

/*--------------------------------------------------------------------------*/
static void gen_indr_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    _HC_Ret addr;
    HC_gen_addr(cb, expr, &addr);
    if (! is_addr_expr(expr)) {
	gen_load_data(cb, expr, &addr, ret, expr->type);
    } else {
	*ret = addr;
    }
}
/*--------------------------------------------------------------------------*/
static void gen_index_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    _HC_Ret addr;
    HC_gen_addr(cb, expr, &addr);
    if (! is_addr_expr(expr)) {
	gen_load_data(cb, expr, &addr, ret, expr->type);
    } else {
	*ret = addr;
    }
}
/*==========================================================================*/
static void gen_call_data(L_Cb *cb, Expr expr, HC_Ret result)
{
Expr temp_expr[HC_MAX_PARAM_VAR];
_M_Type temp_mtype[HC_MAX_PARAM_VAR];
long temp_offset[HC_MAX_PARAM_VAR];
int temp_mode[HC_MAX_PARAM_VAR];
int temp_reg[HC_MAX_PARAM_VAR];
int temp_paddr[HC_MAX_PARAM_VAR];
char *temp_base_macro;
L_Attr *new_attr;

/******    variables added for X86 patch  *******/
Expr rev_expr[HC_MAX_PARAM_VAR];
_M_Type rev_type[HC_MAX_PARAM_VAR];
long rev_offset[HC_MAX_PARAM_VAR];
int rev_mode[HC_MAX_PARAM_VAR];
int rev_reg[HC_MAX_PARAM_VAR];
int rev_paddr[HC_MAX_PARAM_VAR];
/***********************************************/

    /* regular */
    int i, num, size, is_structure;
    Expr op, fn;
    _HC_Ret ret, fn_addr;
    _HC_Operand dest, src1, src2, src3;
    _M_Type mtype;
    _HC_Operand param[HC_MAX_PARAM_VAR];
    L_Attr *attr;
    int tmcount;
    char line[128];
#ifdef GEN_J1
    /*
    sprintf(attr_line, "(j1 %d)", HC_next_call_site_id());
    attr = attr_line;
    */
    attr = L_new_attr("j1",1);
    L_set_int_attr_field(attr,0,HC_next_call_site_id());
#else
    attr = NULL;
#endif
    /*
     *	handle special functions.
     */
    is_structure = IsStructureType(expr->type);
    fn = GetOperand(expr, 1);
    if (IsVarExpr(fn)) {
	char *name = fn->value.var_name;
    	num = 0;
    	for (i=2; (op=GetOperand(expr, i))!=0; i++) {
	    temp_expr[num] = op;
	    num++;
    	}
	if (! strcmp(name, HCfn_SELECT_I)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_select_i(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_SELECT_F)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_select_f(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_SELECT_F2)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_select_f2(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_REV)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_rev(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_BIT_POS)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_bit_pos(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_ABS_I)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_abs_i(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_ABS_F)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_abs_f(cb, &dest, param, num);
	    return;
	} else
/* REH 4/7/94 - Inline floating point absolute value
	if (! strcmp(name, HCfn_ABS_F2)) {
*/
	if (! strcmp(name, "fabs") && HL_generate_abs_instructions) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_abs_f2(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_CO_PROC)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_co_proc(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_FETCH_AND_ADD)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_fetch_add(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_FETCH_AND_OR)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_fetch_or(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_FETCH_AND_AND)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_fetch_and(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_FETCH_AND_ST)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_fetch_st(cb, &dest, param, num);
	    return;
	} else
	if (! strcmp(name, HCfn_FETCH_AND_COND_ST)) {
	    for (i=0; i<num; i++) {
		HC_gen_data(cb, temp_expr[i], &ret);
		HC_simplify(cb, &ret);
		param[i] = ret.op1;
	    }
	    HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
	    result->type = HC_RET_SIMPLE;
	    result->op1 = dest;
	    HC_new_int(&(result->op2), 0, 0);
	    HC_gen_lcode_fetch_cond_st(cb, &dest, param, num);
	    return;
	} 
    }
    /*
     *	figure out how to pass parameters.
     */
    num = 0;
    for (i=2; (op=GetOperand(expr, i))!=0; i++) {
	temp_expr[num] = op;
	HC_hcode2lcode_type(op->type, &mtype);
	if (L_propagate_sign_size_ctype_info)
	  M_call_type2(&mtype, temp_mtype+num);
	else
	  M_call_type(&mtype, temp_mtype+num);
	num++;
    }

    if (num > HC_MAX_PARAM_VAR)
        H_punt ("gen_call_data: number of parameters exceeds max allowed\n");

    /*
     *	Here, we are preparing arguments to be sent out to a callee
     *	function. We need to worry about passing structure.
     */
    size = M_fnvar_layout(num, temp_mtype, temp_offset, 
		temp_mode, temp_reg, temp_paddr,
		&temp_base_macro, is_structure, M_PUT_FNVAR);
    size /= H_CHAR_SIZE;
    for (i=0; i<num; i++) {
	temp_offset[i] /= H_CHAR_SIZE;
	temp_paddr[i] /= H_CHAR_SIZE;
    }

/*******************************************************
          Patch for X86 - reverses the order of all function
          parameters, so they will be generated right-to-left,
          per X86 standard.
**********************************************************/
    if (M_arch == M_X86)  {
        for(i=0; i<num; i++)  {
            rev_expr[i] = temp_expr[i];
            rev_type[i] = temp_mtype[i];
            rev_mode[i] = temp_mode[i];
            rev_reg[i] = temp_reg [i];
            rev_offset[i] = temp_offset[i];
            rev_paddr[i] = temp_paddr[i];

        }

        for(i=0; i<num; i++)  {
            temp_expr[num-1-i] = rev_expr[i];
            temp_mtype[num-1-i] = rev_type[i];
            temp_mode[num-1-i] = rev_mode[i];
            temp_reg[num-1-i] = rev_reg [i];
            temp_offset[num-1-i] = rev_offset[i];
            temp_paddr[num-1-i] = rev_paddr[i];

        }
    }
/*******************************************************/

    /*
     *	generate arguments.
     */
    tmcount = L_TM_START_VALUE;
    for (i=0; i<num; i++) {
	L_Attr *new_attr;
  	HC_gen_data(cb, temp_expr[i], &ret);
 	HC_simplify(cb, &ret);
	switch (temp_mode[i]) {
	case M_THRU_REGISTER:
	    param[i] = ret.op1;
	    break;
	case M_THRU_MEMORY:
	    new_attr = L_new_attr("tm",1);
	    L_set_int_attr_field(new_attr,0,tmcount++);
	    /* mem[base_macro+offset] = ret */
	    if (IsStructureType(temp_expr[i]->type)) {
		HC_new_macro(&dest, temp_base_macro, M_TYPE_POINTER, 0);
		src1 = ret.op1;
		HC_gen_block_mov(cb, temp_expr[i], &dest, temp_offset[i], 
			&src1, 0, temp_mtype+i, new_attr);
	    } else {
		/* need to promote type */
		HC_hcode2lcode_type(temp_expr[i]->type, &mtype);
		if (mtype.type != temp_mtype[i].type) {
		    if (L_propagate_sign_size_ctype_info)
		      HC_new_register(&src3,HC_next_reg_id(),temp_mtype[i].type, temp_mtype[i].unsign);
		    else
		      HC_new_register(&src3,HC_next_reg_id(),temp_mtype[i].type, 0);
		    HC_gen_mov(cb, &src3, &(ret.op1), 0);
		} else {
		    src3 = ret.op1;
		}
		HC_new_macro(&src1, temp_base_macro, M_TYPE_POINTER, 0);
		HC_new_int(&src2, temp_offset[i], 0);
		HC_gen_store(cb, 0, &src1,&src2,&src3, temp_mtype[i].type, 
						new_attr);
	    }    
	    break;
	case M_INDIRECT_THRU_REGISTER:
	    /*
	     *	move_block ret -> temp_paddr
	     *	temp_paddr + temp_base_macro -> param[i]
	     */
	    if (IsStructureType(temp_expr[i]->type)) {
		/* REH 5/20/95  - Add the "tms" attribute to all operations
		   involved in the block copy of a struture passed as a param. */
	        new_attr = L_new_attr("tms",1);
		L_set_int_attr_field(new_attr,0,temp_paddr[i]);
		/* HER */
		HC_new_macro(&dest, temp_base_macro, M_TYPE_POINTER, 0);
		src1 = ret.op1;
		HC_gen_block_mov(cb, temp_expr[i], &dest, temp_paddr[i], 
			&src1, 0, temp_mtype+i, L_copy_attr(new_attr));

		HC_new_register(&dest, HC_next_reg_id(), M_TYPE_POINTER, 0);
		HC_new_macro(&src1, temp_base_macro, M_TYPE_POINTER, 0);
		HC_new_int(&src2, temp_paddr[i], 0);
		HC_gen_add(cb, &dest, &src1, &src2, 1, new_attr);

		param[i] = dest;
	    } else {
Punt("M_INDIRECT_THRU_REGISTER mode can be used to pass structure only");
	    }
	    break;
	case M_INDIRECT_THRU_MEMORY:
	    /*
	     *	move_block ret -> temp_paddr
	     *	temp_paddr + temp_base_macro -> memory[temp_base_macro+offset]
	     */
	    if (IsStructureType(temp_expr[i]->type)) {
		/* REH 5/20/95  - Add the "tms" attribute to all operations
		   involved in the block copy of a struture passed as a param. */
	        new_attr = L_new_attr("tms",1);
		L_set_int_attr_field(new_attr,0,temp_paddr[i]);
		/* HER */
		HC_new_macro(&dest, temp_base_macro, M_TYPE_POINTER, 0);
		src1 = ret.op1;
		HC_gen_block_mov(cb, temp_expr[i], &dest, temp_paddr[i], 
			&src1, 0, temp_mtype+i, L_copy_attr(new_attr));

		HC_new_register(&dest, HC_next_reg_id(), M_TYPE_POINTER, 0);
		HC_new_macro(&src1, temp_base_macro, M_TYPE_POINTER, 0);
		HC_new_int(&src2, temp_paddr[i], 0);
		HC_gen_add(cb, &dest, &src1, &src2, 1, L_copy_attr(new_attr));

		src3 = dest;
		HC_new_macro(&src1, temp_base_macro, M_TYPE_POINTER, 0);
		HC_new_int(&src2, temp_offset[i], 0);
		HC_gen_store(cb, 0, &src1, &src2, &src3, M_TYPE_POINTER, new_attr);
	    } else {
Punt("M_INDIRECT_THRU_MEMORY mode can be used to pass structure only");
	    }
	    break;
	default:
	    Punt("illegal argument mode returned by M_fnvar_layout");
	}
    }
    /*
     *	now, move into $P registers.
     */
    for (i=0; i<num; i++) {
	switch (temp_mode[i]) {
	case M_THRU_REGISTER:
	    /* $Pi = ret.op1 */
	    sprintf(line, "$P%d", temp_reg[i]);
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_macro(&dest, line, temp_mtype[i].type, temp_mtype[i].unsign);
	    else
	      HC_new_macro(&dest, line, temp_mtype[i].type, 0);
	    HC_gen_mov(cb, &dest, param+i, attr);
	    break;
	case M_INDIRECT_THRU_REGISTER:
	    /* $Pi = ret.op1 */
	    sprintf(line, "$P%d", temp_reg[i]);
	    HC_new_macro(&dest, line, M_TYPE_POINTER, 0);
	    HC_gen_mov(cb, &dest, param+i, attr);
	    break;
	default:
	    break;
	}
    }
    /*
     *	if the function returns a structure, need to allocate
     *	space for it.
     */
    if (is_structure) {
	char name[128];
	_HC_Operand offset;

	/* 09/05/94
	 * REH - Generate the address of the local structure to
	 *       be written by the callee
	 */
	HC_hcode2lcode_type(expr->type, &mtype);
	sprintf(name, "$P%d", M_structure_pointer(M_PUT_FNVAR));
	HC_new_macro(&dest, C_findstr(name), M_TYPE_POINTER, 0);
	HC_new_int(&offset,0, 0);

	if ( HC_func_return_struct == NULL )
	    H_punt("gen_call_data: structure return address is null!");

	HC_gen_add(cb, &dest, HC_func_return_struct, &offset, 1, NULL);
	HC_func_return_struct = NULL;

/* REH 09/05/94 - replaced by above code */
#if 0 
	char name[128];
	HC_hcode2lcode_type(expr->type, &mtype);
	sprintf(name, "$P%d", M_structure_pointer(M_PUT_FNVAR));
	HC_new_macro(&dest, C_findstr(name), M_TYPE_POINTER, 0);
	HC_gen_alloc(cb, &dest, mtype.size/H_CHAR_SIZE, mtype.align/H_CHAR_SIZE);
#ifdef GEN_RET_STRUCT_ATTR
/* to clean up Sparc code generator, pohua 5-91 */
	if (attr==0) {
	    sprintf(attr_line, "(jsize %d)(jalign %d)", 
		mtype.size/H_CHAR_SIZE, mtype.align/H_CHAR_SIZE);
	    attr = attr_line;
	} else {
	    sprintf(line, "%s(jsize %d)(jalign %d)",
		attr, mtype.size/H_CHAR_SIZE, mtype.align/H_CHAR_SIZE);
	    attr = attr_line;
	}
#endif
#endif
/* HER */
    }
    /*
     *	generate header.
     */
    fn = GetOperand(expr, 1);
    if (IsVarExpr(fn)) {
	VarDcl var;
	HC_reset_ret(&fn_addr);
	var = FindVar(fn->value.var_name);
  	if (var==0) {
	    /*
	     *	it should be an external function of (int) type.
	     */
	    HC_gen_addr(cb, fn, &fn_addr);
	} else {
	    Symbol sym;
	    sym = FindFunction(fn->value.var_name);
	    if (sym==0) {
	 	if (IsFunctionType(var->type)) {
	    	    HC_gen_addr(cb, fn, &fn_addr);
		} else {
	    	    HC_gen_data(cb, fn, &fn_addr);
		}
	    } else {
	    	HC_gen_addr(cb, fn, &fn_addr);
	    }
	}
    } else {
	HC_gen_data(cb, fn, &fn_addr);
    }
    HC_simplify(cb, &fn_addr);
/* REH 3/7/93 add attirbutes to jsr to identify parameters used */
    {
    _M_Type mtype;
    char mac_attr[32];
    L_Attr *func_attr = NULL;
    int trcount = 0;
    int tmcount = 0;
    L_Attr *tr_attr = NULL;
    L_Attr *tm_attr = NULL;
    L_Attr *tmo_attr = NULL; 
    L_Attr *tmso_attr = NULL; 
    
    for ( i = 0; i < num ; i++ )  {
        char *data_type;
	
	if ((temp_mode[i]==M_THRU_REGISTER) ||
	   (temp_mode[i]==M_INDIRECT_THRU_REGISTER))
	{
	    if ( trcount == 0 )
	    {
		tr_attr = L_new_attr("tr",0);
	    }

	    if (L_propagate_sign_size_ctype_info)

	    {
	      L_set_macro_attr_field(tr_attr, trcount++, L_MAC_P0 + temp_reg[i],
				     L_ctype_id(HC_typename2(temp_mtype[i].type, temp_mtype[i].unsign)),
				     L_PTYPE_NULL);
	    }
	    else
	    {
	      L_set_macro_attr_field(tr_attr, trcount++, L_MAC_P0 + temp_reg[i],
				     L_ctype_id(HC_typename(temp_mtype[i].type)),
				     L_PTYPE_NULL);
	    }
	    /* Also, add structure offsets for indirect thru 
	     * register -ITI/JCG 3/99
	     */
	    if (temp_mode[i]==M_INDIRECT_THRU_REGISTER)
	    {
		if (tmso_attr == NULL)
		{
		    tmso_attr = L_new_attr("tmso",0);
		}
		L_set_int_attr_field(tmso_attr, i, temp_paddr[i]);
	    }
	}
	else  {
	    if ( tmcount == 0 )
	    {
		tm_attr = L_new_attr("tm",0);
		tmo_attr = L_new_attr("tmo",0);
	    }
	    L_set_int_attr_field(tm_attr,tmcount,L_TM_START_VALUE+tmcount);

	    /* To make Lemulate robust, explicitly specify memory offsets
	     * for thru-memory parameters on JSRs.  -ITI/JCG 3/99 
	     */
	    L_set_int_attr_field(tmo_attr,tmcount,temp_offset[i]);

	    /* Also, add structure offsets for indirect thru 
	     * memory -ITI/JCG 3/99
	     */
	    if (temp_mode[i]==M_INDIRECT_THRU_MEMORY)
	    {
		if (tmso_attr == NULL)
		{
		    tmso_attr = L_new_attr("tmso",0);
		}
		L_set_int_attr_field(tmso_attr, i, temp_paddr[i]);
	    }
	    tmcount++;
	}
    }
    if ( tr_attr != NULL )
	func_attr = L_concat_attr(func_attr,tr_attr);
    if ( tm_attr != NULL )
	func_attr = L_concat_attr(func_attr,tm_attr);
    if ( tmo_attr != NULL )
	func_attr = L_concat_attr(func_attr,tmo_attr);
    if ( tmso_attr != NULL )
	func_attr = L_concat_attr(func_attr,tmso_attr);
    
    HC_hcode2lcode_type(expr->type,&mtype);
    /* If the function returns a structure, denote that the 
	return value register is actually used by the subroutine call */

    if ( is_structure )  {
	/* REH - 3/3/95  Sparc doesn't pass structure return address thru reg */
	if ( M_arch != M_SPARC )  {
	    /* If the jsr returns a structure add a use of the return macro */
	    if ( tr_attr == NULL ) {
	    	tr_attr = L_new_attr("tr",0);
	    	func_attr = L_concat_attr(func_attr,tr_attr);
  	    } 
	    if (L_propagate_sign_size_ctype_info)
	      L_set_macro_attr_field(tr_attr, trcount, 
			       L_MAC_P0 + M_return_register(mtype.type,M_GET_FNVAR),
			       L_ctype_id(HC_typename2(mtype.type, mtype.unsign)),
			       L_PTYPE_NULL);
	    else
	      L_set_macro_attr_field(tr_attr, trcount, 
			       L_MAC_P0 + M_return_register(mtype.type,M_GET_FNVAR),
			       L_ctype_id(HC_typename(mtype.type)),
			       L_PTYPE_NULL);
	}	
/* RAB - 3/25/94 */
	new_attr = L_new_attr("ret_st", 0);
        func_attr = L_concat_attr (func_attr, new_attr);
    }
    if (is_indr_expr(expr))
    {
	new_attr = L_new_attr("ret_ptr_st",0);
        func_attr = L_concat_attr (func_attr, new_attr);
    }
/* BAR - 3/25/94 */

    /* Provide the return register macro name */

    new_attr = L_new_attr("ret",1);
    if (L_propagate_sign_size_ctype_info)
      L_set_macro_attr_field(new_attr,0,L_MAC_P0 + M_return_register(mtype.type,M_GET_FNVAR),
			     L_ctype_id(HC_typename2(mtype.type, mtype.unsign)),
			     L_PTYPE_NULL);
    else
      L_set_macro_attr_field(new_attr,0,L_MAC_P0 + M_return_register(mtype.type,M_GET_FNVAR),
			     L_ctype_id(HC_typename(mtype.type)),
			     L_PTYPE_NULL);
    
    func_attr = L_concat_attr (func_attr, new_attr);

    new_attr = L_new_attr("param_size", 1);
    L_set_int_attr_field(new_attr, 0, size);
    func_attr = L_concat_attr (func_attr, new_attr);

    HC_gen_jsr(cb, expr, &(fn_addr.op1), num, func_attr);
    }
    /*
     *	move the return value to appropriate location.
     */
    if (IsVoidType(expr->type)) {
	HC_reset_ret(result);
    } else
    if (is_structure) {
#if 0 /* REH 09/05/94 - without allocs, this is not needed */
	/* r <- $Pn, n = M_return_register(M_TYPE_POINTER) */
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_POINTER, 0);
	sprintf(line, "$P%d", M_return_register(M_TYPE_POINTER, M_GET_FNVAR));
	HC_new_macro(&src1, C_findstr(line), M_TYPE_POINTER, 0);
	HC_gen_mov(cb, &dest, &src1, attr);
	result->type = HC_RET_SIMPLE;
	result->op1 = dest;
	HC_new_int(&(result->op2), 0, 0);
#endif
    } else {
	/* r <- $Pn, n = M_return_register(mtype.type) */
	_M_Type tm;
	HC_hcode2lcode_type(expr->type, &tm);
	if (L_propagate_sign_size_ctype_info)
	  M_eval_type2(&tm, &mtype);
	else
	  M_eval_type(&tm, &mtype);
	if (L_propagate_sign_size_ctype_info)
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
	else
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);
	sprintf(line, "$P%d", M_return_register(mtype.type, M_GET_FNVAR));
	if (L_propagate_sign_size_ctype_info)
	  HC_new_macro(&src1, C_findstr(line), mtype.type, mtype.unsign);
	else
	  HC_new_macro(&src1, C_findstr(line), mtype.type, 0);
	HC_gen_mov(cb, &dest, &src1, attr);
	result->type = HC_RET_SIMPLE;
	result->op1 = dest;
	HC_new_int(&(result->op2), 0, 0);
    }   
}
/*==========================================================================*/
static void gen_assign_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    int is_structure, in_reg, is_bit_field, bit_field_shift, bit_field_length;
    long bit_field_mask;
/* REH 9/12/93 */
    int bit_field_type;
/* HER */
    Expr LHS, RHS;
    _HC_Ret x, y;
    _M_Type mtype;
    L_Attr *attr= NULL; /* LCW 8/3/95 */

    int LHS_addr = 0;

    LHS = GetOperand(expr, 1);
    RHS = GetOperand(expr, 2);
    if (LHS->type->dcltr!=0) {
	int method = LHS->type->dcltr->method;
	if (method==D_ARRY) {
	    /*
	     *	It is not wise, but some people actually
	     *	define some parameter to be char XXX[];
	     *	and later say  XXX++
	     */
	    if (LHS->type->dcltr->index != 0) {
	    	Gen_C_Expr(stderr, LHS);
	    	Gen_C_Type(stderr, LHS->type);
	    	Punt("x=y: x cannot be an array");
	    }
	} else
	if (method==D_FUNC) {
	    Gen_C_Expr(stderr, LHS);
	    Gen_C_Type(stderr, LHS->type);
	    Punt("x=y: x cannot be a function");
	}
    }
    /*
     * 	generate the RHS.
     *	> there are some ambiquity here:
     *		*x = (x=&y)	depends on whether
     *		RHS or LHS is evaluated first.
     *		I choose RHS first (so consistent when x in register)
     */
    /* REH 09/05/94 - modified to eliminate need for alloc */
    if ( IsStructureType(expr->type) && RHS->opcode == OP_call ) { 
 	in_reg = (HC_gen_addr(cb, LHS, &x)==VAR_IN_REGISTER);	
	LHS_addr = 1;
	HC_simplify(cb, &x);
	HC_func_return_struct = &(x.op1);
    }
    HC_gen_data(cb, RHS, &y);
    HC_simplify(cb, &y);
    /*
     *	generate the LHS.
     */
    HC_hcode2lcode_type(expr->type, &mtype);
    is_structure = IsStructureType(expr->type);
    if ( LHS_addr == 0 )
    in_reg = (HC_gen_addr(cb, LHS, &x)==VAR_IN_REGISTER);

    /* Determine if bit field from expression type */
    is_bit_field = LHS->type->type & TY_BIT_FIELD;
    bit_field_type = LHS->type->type;
#if 0
    /* REH 2/7/96 - These global are not longer necessary */
    is_bit_field = HC_is_bit_field;
    bit_field_shift = HC_bit_field_shift;
    bit_field_mask = HC_bit_field_mask;
/* REH 9/12/93 */
    bit_field_type = HC_bit_field_type;
/* HER */
    bit_field_length = HC_bit_field_length;   /* DMC 8/3/95 */
#endif

    /*
     *	generate the assignment.
     */
    if (is_structure ) {
	/* REH 09/05/94 - modified to eliminate need for alloc */
	if ( RHS->opcode != OP_call )  {
	HC_simplify(cb, &x);
        /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
        if (expr->pragma != 0)
           attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_block_mov(cb, LHS,&(x.op1), 0, &(y.op1), 0, &mtype, attr);
        }
    } else
    if (in_reg) {
	HC_simplify(cb, &x);
        /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
        if (expr->pragma != 0)
           attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_mov(cb, &(x.op1), &(y.op1), attr);
    } else
    if (is_bit_field) {
	_HC_Ret data;
	_Type type;

	/* REH 2/7/96 */
	Expr op1;
	_M_Type mtype;
        long dummy1;
        int dummy2;
	
/* REH 9/12/93 
	type.type = TY_INT;
*/
/* REH 2/7/96 */
	type.type = bit_field_type;
/* HER */
	/* Determine bit field type from the expression type */
	type.type = LHS->type->type;
	type.dcltr = 0;
	type.struct_name = 0;

	/* REH 2/7/96 - Determine bit field information directly */
	/* from the symbol table.				 */
        op1 = GetOperand(LHS, 1);
	if (op1->type->type & TY_STRUCT) {
	    HC_struct_field_info(
		op1->type->struct_name,
		LHS->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
	} else {
	    HC_union_field_info(
		op1->type->struct_name,
		LHS->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
        }
	/* HER */

        if ((bit_field_shift == 0) &&                     /* DMC 8/3/95 */
            ((bit_field_length == M_type_size(M_TYPE_CHAR)) || 
             (bit_field_length == M_type_size(M_TYPE_SHORT)) || 
             (bit_field_length == M_type_size(M_TYPE_INT))))
        {
            gen_store_data(cb, LHS, &x, &y, &type);
        } else { 
       	    gen_load_data(cb, LHS, &x, &data, &type);
	    gen_insert_bit_field(cb, &data, &y, 
		bit_field_shift, bit_field_mask);
	    gen_store_data(cb, LHS, &x, &data, &type);
	}
    } else {
	gen_store_data(cb, LHS, &x, &y, expr->type);
    }
    *ret = y;
}
/*--------------------------------------------------------------------------*/
static void gen_incr_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1;
    int increment, in_reg, opcode;
    _HC_Ret x, y;
    _HC_Operand dest, src1, src2, result;
    _M_Type mtype;
    int is_bit_field, bit_field_shift,bit_field_length;
    long bit_field_mask;
    
/* REH 9/12/93  */
    int bit_field_type;
/* HER */
    L_Attr *attr= NULL; /* LCW 8/3/95 */


    HC_reset_ret(ret);
    op1 = GetOperand(expr, 1);
    if (IsStructureType(op1->type))
	Punt("gen_incr_data: cannot pre/post increment a structure");
    /*
     *	determine the increment amount.
     */
    increment = 1;
    if (IsPointerType(op1->type)) {
	Type type = op1->type;
	Dcltr dcltr = type->dcltr;
	type->dcltr = dcltr->next;
	increment = H_lcode_typesize(type);
	type->dcltr = dcltr;
    }
    /*
     *	compute the address of x.
     */
    in_reg = (HC_gen_addr(cb, op1, &x)==VAR_IN_REGISTER);
#ifdef NO_BIT_FIELD_FOR_COMPLEX_ASSIGNMENT
    if (HC_is_bit_field)
	Punt("sorry, we do not support pre/post increment on bit fields");
#endif
    
    /* REH 2/7/96 */
    /* Determine if bit field from expression type */
    is_bit_field = op1->type->type & TY_BIT_FIELD;
    bit_field_type = op1->type->type;
#if 0
    is_bit_field = HC_is_bit_field;
    bit_field_shift = HC_bit_field_shift;
    bit_field_mask = HC_bit_field_mask;
/* REH 9/12/93 */
    bit_field_type = HC_bit_field_type;
/* HER */
    bit_field_length = HC_bit_field_length;    /* DMC 8/3/95 */
#endif
    
    /*
     *	get the original value of x.
     */
    HC_hcode2lcode_type(expr->type, &mtype);   

/* BCC - mtype sould not be changed by M_eval_type in gen_var_addr()  
   sometimes char/short types are changed to int in gen_var_addr() 7/10/95 */
    if (x.type == HC_RET_SIMPLE) {
	/* BCC - bug fix - 4/14/96
	 * e.g. (*db)++
	 * The final type for the above expression is a double but we
	 * shouldn't change the type for db to be double. The type of db
	 * should stay to be INT or whatever it was. We only do the
	 * conversion when the mtype.type is integer type.
	 */
	switch (mtype.type) {
	    /* equivalent to is_integer */
	    case M_TYPE_BIT_LONG:
	    case M_TYPE_BIT_CHAR:
	    case M_TYPE_CHAR:
	    case M_TYPE_SHORT:
	    case M_TYPE_INT:
	    case M_TYPE_LONG:
	    case M_TYPE_POINTER:
	    case M_TYPE_BLOCK:          
		if (x.op1.data_type != M_TYPE_POINTER) 
		    x.op1.data_type = mtype.type;
		break;
	}
    };

    if (in_reg) {
	if (is_bit_field) Punt("bit field cannot be in register");
	y = x;
    } else
    if (is_bit_field) {
	_Type type;
	/* REH 2/7/96 */
	Expr op2;
	_M_Type mtype;
        long dummy1;
        int dummy2;
	
/* REH 9/12/93 
	type.type = TY_INT;
*/
/* REH 2/7/96 */
	type.type = bit_field_type;
/* HER */
	type.type = op1->type->type;
	type.dcltr = 0;
	type.struct_name = 0;

	
	/* REH 2/7/96 - Determine bit field information directly */
	/* from the symbol table.				     */
        op2 = GetOperand(op1, 1);
	if (op2->type->type & TY_STRUCT) {
	    HC_struct_field_info(
		op2->type->struct_name,
		op1->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
	} else {
	    HC_union_field_info(
		op2->type->struct_name,
		op1->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
        }
	/* HER */
	
        if ((bit_field_shift == 0) &&                   /* DMC 8/3/95 */
            ((bit_field_length == M_type_size(M_TYPE_CHAR)) ||
             (bit_field_length == M_type_size(M_TYPE_SHORT)) ||
             (bit_field_length == M_type_size(M_TYPE_INT))))
        {
            gen_load_data(cb, op1, &x, &y, &type);
        } else {
	    gen_load_data(cb, expr, &x, &y, &type);
	    gen_extract_bit_field(cb, &y, bit_field_shift, bit_field_mask);
	}
    } else {
	gen_load_data(cb, op1, &x, &y, op1->type);
    }
    HC_simplify(cb, &y);
    if (y.op1.type==HC_R)
    	result = y.op1;
    else
	if (L_propagate_sign_size_ctype_info)
	  HC_new_register(&result, HC_next_reg_id(), mtype.type, mtype.unsign);
	else
	  HC_new_register(&result, HC_next_reg_id(), mtype.type, 0);
    /*
     *	generate the operation.
     */
    src1 = y.op1;
    HC_new_int(&src2, increment, 0);
    opcode = expr->opcode;

    /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
    if (expr->pragma != 0)
       attr = HC_gen_attr_from_pragma(expr->pragma);

    if (opcode==OP_preinc) {
	/* result = reg = reg + increment */
	/* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_add(cb, &result, &src1, &src2, mtype.unsign, attr);
	dest = result;
    } else
    if (opcode==OP_predec) {
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_sub(cb, &result, &src1, &src2, mtype.unsign, attr);
	dest = result;
    } else
    if (opcode==OP_postinc) {
	/* result = reg; reg = reg + increment */
	if (L_propagate_sign_size_ctype_info)
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
	else
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);
        /* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_mov(cb, &dest, &src1, attr);
	/* LCW - create another copy of attr - 8/5/97 */
	HC_gen_add(cb, &result, &src1, &src2, mtype.unsign, L_copy_attr(attr));
    } else
    if (opcode==OP_postdec) {
	if (L_propagate_sign_size_ctype_info)
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
	else
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);
        /* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_mov(cb, &dest, &src1, attr);
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_sub(cb, &result, &src1, &src2, mtype.unsign, L_copy_attr(attr));
    } else {
	Punt("gen_incr_data: illegal opcode");
    }
    /*
     *	update x.
     */
    if (in_reg) {
	/* already updated */
    } else
    if (is_bit_field) {
	_HC_Ret data;
	_Type type;
	/* REH 2/7/96 */
	Expr op2;
	_M_Type mtype;
        long dummy1;
        int dummy2;
	
/* REH 9/12/93 
	type.type = TY_INT;
*/
/* REH 2/7/96 */
	type.type = bit_field_type;
/* HER */
	type.type = op1->type->type;
	type.dcltr = 0;
	type.struct_name = 0;

	/* REH 2/7/96 - Determine bit field information directly */
	/* from the symbol table.				     */
        op2 = GetOperand(op1, 1);
	if (op2->type->type & TY_STRUCT) {
	    HC_struct_field_info(
		op2->type->struct_name,
		op1->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
	} else {
	    HC_union_field_info(
		op2->type->struct_name,
		op1->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
        }
	/* HER */
	y.op1 = result;
	y.type = HC_RET_SIMPLE;

	if ((bit_field_shift == 0) &&                   /* DMC 8/3/95 */
	    ((bit_field_length == M_type_size(M_TYPE_CHAR)) ||
	     (bit_field_length == M_type_size(M_TYPE_SHORT)) ||
	     (bit_field_length == M_type_size(M_TYPE_INT))))
	{
	    gen_store_data(cb, op1, &x, &y, &type);
	} else {
	    gen_load_data(cb, expr, &x, &data, &type);
	    gen_insert_bit_field(cb,&data, &y, bit_field_shift, bit_field_mask);
	    gen_store_data(cb, op1, &x, &data, &type);
	}
    } else {
	y.op1 = result;
	y.type = HC_RET_SIMPLE;
	gen_store_data(cb, op1, &x, &y, op1->type);
    }
    ret->type = HC_RET_SIMPLE;
    ret->op1 = dest;
}
/*--------------------------------------------------------------------------*/
static void gen_Aarith_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    int increment, opcode, is_structure, in_reg;
    Expr LHS, RHS;
    _HC_Ret x, y, addr;
    _M_Type mtype;
    _HC_Operand dest, src1, src2, tm, inc;
    int lhs_is_ptr, rhs_is_ptr;
    int is_bit_field, bit_field_shift, bit_field_length;
    long bit_field_mask;
/* REH 9/12/93 */
    int bit_field_type;
/* BCC determine if the result should be masked or not - 7/6/95 */
    int second_pass=0;

/* HER */

    L_Attr *attr= NULL; /* LCW 8/3/95 */

    opcode = expr->opcode;
    LHS = GetOperand(expr, 1);
    RHS = GetOperand(expr, 2);
    if (LHS->type->dcltr!=0) {
	int method = LHS->type->dcltr->method;
	if (method==D_ARRY) {
	    /*
	     *	It is not wise, but some people actually
	     *	define some parameter to be char XXX[];
	     *	and later say  XXX++
	     */
	    if (LHS->type->dcltr->index != 0) {
	    	Gen_C_Expr(stderr, LHS);
	    	Gen_C_Type(stderr, LHS->type);
	    	Punt("x op= y: x cannot be an array");
	    }
	} else
	if (method==D_FUNC) {
	    Gen_C_Expr(stderr, LHS);
	    Gen_C_Type(stderr, LHS->type);
	    Punt("x op= y: x cannot be a function");
	}
    }
    lhs_is_ptr = (IsPointerType(LHS->type) || IsArrayType(LHS->type));
    rhs_is_ptr = (IsPointerType(RHS->type) || IsArrayType(RHS->type));
    is_structure = IsStructureType(expr->type);
    if (is_structure) {
	/* need to get this to work in order to compile gcc */
	Punt("sorry, we do not support op= on structures");
    }
    /*
     * 	generate the RHS.
     */
    HC_gen_data(cb, RHS, &y);
    HC_simplify(cb, &y);
    /*
     *	generate the LHS.
     */
    HC_hcode2lcode_type(expr->type, &mtype);
    in_reg = (HC_gen_addr(cb, LHS, &x)==VAR_IN_REGISTER);
#ifdef NO_BIT_FIELD_FOR_COMPLEX_ASSIGNMENT
    if (HC_is_bit_field)
	Punt("sorry, we do not yet support op= on bit fields");
#endif
    

    /* REH 2/7/96 */
    /* Determine if bit field from expression type */
    is_bit_field = LHS->type->type & TY_BIT_FIELD;
    bit_field_type = LHS->type->type;
#if 0
    is_bit_field = HC_is_bit_field;
    bit_field_shift = HC_bit_field_shift;
    bit_field_mask = HC_bit_field_mask;
/* REH 9/12 93 */
    bit_field_type = HC_bit_field_type;
/* HER */
    bit_field_length = HC_bit_field_length;   /* DMC 8/3/95 */
#endif
    
    HC_simplify(cb, &x);
    addr = x;
    if (in_reg) {
	if (is_bit_field) Punt("bit field cannot be in register");
    } else
    if (is_bit_field) {
	_Type type;
	/* REH 2/7/96 */
	Expr op1;
	_M_Type mtype;
        long dummy1;
        int dummy2;
	
/* REH 9/12/93 
	type.type = TY_INT;
*/
/* REH 2/7/96 */
	type.type = bit_field_type;
/* HER */
	type.type = LHS->type->type;
	type.dcltr = 0;
	type.struct_name = 0;
	
	/* REH 2/7/96 - Determine bit field information directly */
	/* from the symbol table.				     */
        op1 = GetOperand(LHS, 1);
	if (op1->type->type & TY_STRUCT) {
	    HC_struct_field_info(
		op1->type->struct_name,
		LHS->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
	} else {
	    HC_union_field_info(
		op1->type->struct_name,
		LHS->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
        }
	/* HER */


        if ((bit_field_shift == 0) &&                     /* DMC 8/3/95 */
            ((bit_field_length == M_type_size(M_TYPE_CHAR)) ||
             (bit_field_length == M_type_size(M_TYPE_SHORT)) ||
             (bit_field_length == M_type_size(M_TYPE_INT))))
        {
            gen_load_data(cb, expr->operands, &addr, &x, &type);
	} else {
	    gen_load_data(cb, expr->operands, &addr, &x, &type);
	    gen_extract_bit_field(cb, &x, bit_field_shift, bit_field_mask);
	}
    } else {
	gen_load_data(cb, expr->operands, &addr, &x, LHS->type);
    }
    /*
     *	find out what the increment is.
     */
    increment = 1;
    if ((opcode==OP_Aadd) | (opcode==OP_Asub)) {
	if (IsPointerType(LHS->type) | IsArrayType(LHS->type)) {
	    Type type;
	    Dcltr dcltr;
	    type = LHS->type;
	    dcltr = type->dcltr;
	    type->dcltr = dcltr->next;
	    increment = H_lcode_typesize(type);
	    type->dcltr = dcltr;
	}
    }
    /*
     *	evaluate.
     */
    if (in_reg)
	dest = addr.op1;
    else
	if (L_propagate_sign_size_ctype_info)
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
	else
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);

    src1 = x.op1;
    src2 = y.op1;
    switch (opcode) {
    case OP_Aadd:
	/*
	 *  dest = src1 + (src2 * increment).
	 */
	if (increment!=1) {
	    if (src2.type==HC_I) {
	 	HC_new_int(&tm, src2.value.i * increment, 0);
	    } else {
	    	HC_new_register(&tm, HC_next_reg_id(), M_TYPE_INT, 0);
	    	HC_new_int(&inc, increment, 0);
    		/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
    		if (expr->pragma != 0)
       		   attr = HC_gen_attr_from_pragma(expr->pragma);
		/* LCW -- add an additional argument attr - 8/9/95 */
	    	HC_gen_mul(cb, &tm, &src2, &inc, 0, attr);
	    }
	} else {
	    tm = src2;
	}
    	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
    	if (expr->pragma != 0)
           attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_add(cb, &dest, &src1, &tm, mtype.unsign, attr);
	/* BCC - in a += 5; if a is not a pointer, we have to mask the result */
	if (!lhs_is_ptr) second_pass = 1;
	break;
    case OP_Asub:
	if (lhs_is_ptr & rhs_is_ptr) {
	    Punt("sorry, (pointer -= pointer) is not allowed");
	    /*
	     *	dest = (src1 - src2) / increment.
	     */
	    if (increment==0)
		Punt("cannot apply -= on (void*)");
	    /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	    if (expr->pragma != 0)
	       attr = HC_gen_attr_from_pragma(expr->pragma);
            /* LCW -- add an additional argument attr - 8/9/95 */
	    HC_gen_sub(cb, &dest, &src1, &src2, mtype.unsign, attr);
	    if (increment!=1) {
		tm = dest;
	    	HC_new_int(&inc, increment, 0);
		/* REH 4/16/96 - Cannot generate unsigned divide */
		/* on a pointer subtract since the result may    */
		/* very well be a negative integer.              */
		/*
	    	HC_gen_div(cb, &dest, &tm, &inc, 1);
		*/
		/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
		if (expr->pragma != 0)
		   attr = HC_gen_attr_from_pragma(expr->pragma);
	        /* LCW -- add an additional argument attr - 8/9/95 */
		HC_gen_div(cb, &dest, &tm, &inc, 0, attr);
	    }
	} else {
	    /*
	     *  dest = src1 - (src2 * increment).
	     */
	    if (increment!=1) {
		if (src2.type==HC_I) {
		    HC_new_int(&tm, src2.value.i * increment, 0);
		} else {
	    	    HC_new_register(&tm, HC_next_reg_id(), M_TYPE_INT, 0);
	    	    HC_new_int(&inc, increment, 0);
		    /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
		    if (expr->pragma != 0)
		       attr = HC_gen_attr_from_pragma(expr->pragma);
		    /* LCW -- add an additional argument attr - 8/9/95 */
	    	    HC_gen_mul(cb, &tm, &src2, &inc, 1, attr);
		}
	    } else {
		tm = src2;
	    }
	    /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	    if (expr->pragma != 0)
	       attr = HC_gen_attr_from_pragma(expr->pragma);
	    /* LCW -- add an additional argument attr - 8/9/95 */
	    HC_gen_sub(cb, &dest, &src1, &tm, mtype.unsign, attr);
	}
	/* BCC - in a -= 5; if a is not a pointer, we have to mask the result */
	if (!lhs_is_ptr) second_pass = 1;
	break;
    case OP_Amul:
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_mul(cb, &dest, &src1, &src2, mtype.unsign, attr);
	/* BCC - need a second pass to mask the result */
	second_pass = 1;
	break;
    case OP_Adiv:
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_div(cb, &dest, &src1, &src2, mtype.unsign, attr);
	/* BCC - need a second pass to mask the result */
	second_pass = 1;
	break;
    case OP_Amod:
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
#ifdef OLD_MOD
	/*
	 *	tm = src1 / src2
	 *	tm = tm * src2
	 *	dest = src1 - tm
	 */
	if (L_propagate_sign_size_ctype_info)
	  HC_new_register(&tm, HC_next_reg_id(), mtype.type, mtype.unsign);
	else
	  HC_new_register(&tm, HC_next_reg_id(), mtype.type, 0);
	tm2 = tm;
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_div(cb, &tm, &src1, &src2, mtype.unsign, attr);
	HC_gen_mul(cb, &tm2, &tm, &src2, mtype.unsign, L_copy_attr(attr));
	HC_gen_sub(cb, &dest, &src1, &tm2, mtype.unsign, L_copy_attr(attr));
#else
	HC_gen_mod(cb, &dest, &src1, &src2, mtype.unsign, attr);
#endif
	break;
    case OP_Arshft:
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- add an additional argument attr - 8/9/95 */
	if (mtype.unsign)
	    HC_gen_lsr(cb, &dest, &src1, &src2, attr);
	else
	    HC_gen_asr(cb, &dest, &src1, &src2, attr);
	second_pass = 1;
	break;
    case OP_Alshft:
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_lsl(cb, &dest, &src1, &src2, attr);
	second_pass = 1;
	break;
    case OP_Aand:
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_and(cb, &dest, &src1, &src2, attr);
	second_pass = 1;
	break;
    case OP_Aor:
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_or(cb, &dest, &src1, &src2, attr);
	second_pass = 1;
	break;
    case OP_Axor:
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_xor(cb, &dest, &src1, &src2, attr);
	second_pass = 1;
	break;
    default:
	Punt("gen_Aop: illegal opcode");
    }

    /* BCC - if second_pass == 1, then result will be masked */
    if (second_pass == 1) {
	if (mtype.type == M_TYPE_CHAR) {
    /* BCC - use the same register to hold the value after being masked 7/6/95*/
            dest.data_type = M_TYPE_CHAR;
	    bcc_cast_char(cb, &dest, &dest, mtype.unsign);
	}
	else if (mtype.type == M_TYPE_SHORT) {
    /* BCC - use the same register to hold the value after being masked 7/6/95*/
            dest.data_type = M_TYPE_SHORT;
	    bcc_cast_short(cb, &dest, &dest, mtype.unsign);
	}
    };

    /*
     *	update result.
     */
    ret->type = HC_RET_SIMPLE;
/* BCC - 7/6/95 */
    ret->op1 = dest;
    if (in_reg) {
    } else
    if (is_bit_field) {
	_HC_Ret data;
	_Type type;
	/* REH 2/7/96 */
	Expr op1;
	_M_Type mtype;
        long dummy1;
        int dummy2;
	
/* REH 9/12/93 
	type.type = TY_INT;
*/
/* REH 2/7/96 */
	type.type = bit_field_type;
/* HER */
	type.type = LHS->type->type;
	type.dcltr = 0;
	type.struct_name = 0;
	
	/* REH 2/7/96 - Determine bit field information directly */
	/* from the symbol table.				     */
        op1 = GetOperand(LHS, 1);
	if (op1->type->type & TY_STRUCT) {
	    HC_struct_field_info(
		op1->type->struct_name,
		LHS->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
	} else {
	    HC_union_field_info(
		op1->type->struct_name,
		LHS->value.string,
		&dummy1, &mtype, &dummy2, &bit_field_shift, 
		&bit_field_mask, &bit_field_length);
        }
	/* HER */

	y.op1 = dest;
	y.type = HC_RET_SIMPLE;

	if ((bit_field_shift == 0) &&                     /* DMC 8/3/95 */
	    ((bit_field_length == M_type_size(M_TYPE_CHAR)) ||
	     (bit_field_length == M_type_size(M_TYPE_SHORT)) ||
	     (bit_field_length == M_type_size(M_TYPE_INT))))
	{
	    gen_store_data(cb, expr->operands, &addr, ret, &type);
	} else {
	    gen_load_data(cb, expr->operands, &addr, &data, &type);
	    gen_insert_bit_field(cb,&data, &y, bit_field_shift, bit_field_mask);
	    gen_store_data(cb, expr->operands, &addr, &data, &type);
	}
    } else {
	gen_store_data(cb, expr->operands, &addr, ret, expr->type);
    }
}
/*==========================================================================*/
static void gen_logic_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1, op2;
    _HC_Ret x, y;
    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    HC_gen_data(cb, op1, &x);
    HC_simplify(cb, &x);
    HC_gen_data(cb, op2, &y);
    HC_simplify(cb, &y);
    switch (expr->opcode) {
    case OP_or:		ret->type = HC_RET_OR;		break;
    case OP_xor:	ret->type = HC_RET_XOR;		break;
    case OP_and:	ret->type = HC_RET_AND;		break;
    default:
	Punt("gen_logic_data: illegal opcode");
    }
    ret->op1 = x.op1;
    ret->op2 = y.op1;
}
/*--------------------------------------------------------------------------*/
static void gen_compare_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1, op2;
    _HC_Ret x, y;
    _M_Type mtype;
    int is_unsign, is_float;

    L_Attr *attr= NULL; /* LCW 8/9/95 */

    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    HC_gen_data(cb, op1, &x);
    HC_simplify(cb, &x);
    HC_gen_data(cb, op2, &y);
    HC_simplify(cb, &y);
    HC_hcode2lcode_type(expr->type, &mtype);
    is_unsign = ((op1->type->type & TY_UNSIGNED) != 0) |
    		((op2->type->type & TY_UNSIGNED) != 0);
    is_float = IsRealType(op1->type) | IsRealType(op2->type);

    if (is_float) {
	_HC_Operand dest, src1, src2;
	src1 = x.op1;
	src2 = y.op1;
/* BCC - use a integer register to hold the result of comparison - 6/19/95 */
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
        /* LCW -- transfer the pragmas to attributes  -- 8/9/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
/* LCW -- add an additional argument attr to each HC_gen_xxx below - 8/9/95 */
	switch (expr->opcode) {
	case OP_eq:
	    HC_gen_eq(cb, &dest, &src1, &src2, NULL, attr);
	    break;
	case OP_ne:
	    HC_gen_ne(cb, &dest, &src1, &src2, attr);
	    break;
	case OP_gt:
	    HC_gen_gt(cb, &dest, &src1, &src2, is_unsign, attr);
	    break;
	case OP_ge:
	    HC_gen_ge(cb, &dest, &src1, &src2, is_unsign, attr);
	    break;
	case OP_lt:
	    HC_gen_lt(cb, &dest, &src1, &src2, is_unsign, attr);
	    break;
	case OP_le:
	    HC_gen_le(cb, &dest, &src1, &src2, is_unsign, attr);
	    break;
	default:
	    Punt("gen_compare_data: illegal opcode");
 	}
	ret->type = HC_RET_SIMPLE;
	ret->op1 = dest;
    } else {
	if (is_unsign) {
    	    switch (expr->opcode) {
    	    case OP_eq:	ret->type = HC_RET_EQ;		break;
     	    case OP_ne:	ret->type = HC_RET_NE;		break;
    	    case OP_gt:	ret->type = HC_RET_GT_U;	break;
    	    case OP_ge:	ret->type = HC_RET_GE_U;	break;
    	    case OP_lt:	ret->type = HC_RET_LT_U;	break;
    	    case OP_le:	ret->type = HC_RET_LE_U;	break;
    	    default:
		Punt("gen_compare_data: illegal opcode");
    	    }
	} else {
    	    switch (expr->opcode) {
    	    case OP_eq:	ret->type = HC_RET_EQ;		break;
     	    case OP_ne:	ret->type = HC_RET_NE;		break;
    	    case OP_gt:	ret->type = HC_RET_GT;		break;
    	    case OP_ge:	ret->type = HC_RET_GE;		break;
    	    case OP_lt:	ret->type = HC_RET_LT;		break;
    	    case OP_le:	ret->type = HC_RET_LE;		break;
    	    default:
		Punt("gen_compare_data: illegal opcode");
    	    }
	}
    	ret->op1 = x.op1;
    	ret->op2 = y.op1;
    }
}
/*--------------------------------------------------------------------------*/
static void gen_shift_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1, op2;
    _HC_Ret x, y;
    _M_Type mtype;
    _HC_Operand dest, src1, src2;

    L_Attr *attr= NULL; /* LCW 8/9/95 */

    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    HC_gen_data(cb, op1, &x);
    HC_simplify(cb, &x);
    HC_gen_data(cb, op2, &y);
    HC_simplify(cb, &y);
    HC_hcode2lcode_type(expr->type, &mtype);
    src1 = x.op1;
    src2 = y.op1;
    if (L_propagate_sign_size_ctype_info)
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
    else
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);

    /* LCW -- transfer the pragmas to attributes  -- 8/9/95 */
    if (expr->pragma != 0)
       attr = HC_gen_attr_from_pragma(expr->pragma);

    switch (expr->opcode) {
    case OP_rshft:
	if (mtype.unsign)
	    /* LCW -- add an additional argument attr - 8/9/95 */
	    HC_gen_lsr(cb, &dest, &src1, &src2, attr);
	else
	    /* LCW -- add an additional argument attr - 8/9/95 */
	    HC_gen_asr(cb, &dest, &src1, &src2, attr);
	break;
    case OP_lshft:
	/* LCW -- add an additional argument attr - 8/9/95 */
	HC_gen_lsl(cb, &dest, &src1, &src2, attr);
 	break;
    default:
	Punt("gen_shift: illegal opcode");
    }
    ret->type = HC_RET_SIMPLE;
    ret->op1 = dest;
}
/*--------------------------------------------------------------------------*/
/* NJW */
/* GEH - updated pragma format - 3/95 */
static void gen_sync_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    int i;
    char *pragma;
    long int marker, distance;
    double real;
    char label[256], name[256], label2[256], *type;
    L_Oper *new_oper;
    L_Attr *attr;

    pragma = expr->pragma->specifier;
    if (pragma == 0) Punt("gen_sync_data: Sync opcode has no pragma");
#ifdef DEBUG_PCODE
  fprintf(stderr, "pragma specifier = %s\n", pragma);
#endif
    pragma = HC_read_attr_name_from_pragma_str(pragma, name);
    if(!strcmp(name, "ADVANCE"))  {
	pragma = HC_read_attr_field_from_pragma_str(pragma, label, &marker,
						    &real, &type);
	if (type[1] != '%') 
	    Punt("gen_sync_data: Invalid ADVANCE pragma - integer field expected");
	if (pragma != NULL) 
	    Punt("gen_sync_data: Invalid ADVANCE pragma - extra field present");
#ifdef DEBUG_PCODE
  fprintf(stderr, "marker = %d\n", marker);
#endif
	new_oper = L_create_new_op(Lop_ADVANCE);
	new_oper->src[0] = L_new_gen_int_operand(marker);
    } 
    else if(!strcmp(name, "AWAIT")) {
	pragma = HC_read_attr_field_from_pragma_str(pragma, label, &marker,
						    &real, &type);
	if (type[1] != '%') 
	    Punt("gen_sync_data: Invalid AWAIT pragma - integer field expected");
	pragma = HC_read_attr_field_from_pragma_str(pragma, label, &distance,
						    &real, &type);
	if (type[1] != '%') 
	    Punt("gen_sync_data: Invalid AWAIT pragma - integer field expected");
	if (pragma != NULL) 
	    Punt("gen_sync_data: Invalid AWAIT pragma - extra fields present");
	new_oper = L_create_new_op(Lop_AWAIT);
	new_oper->src[0] = L_new_gen_int_operand(marker);
	new_oper->src[1] = L_new_gen_int_operand(distance);
#ifdef DEBUG_PCODE
  fprintf(stderr, "marker = %d, distance = %d\n", marker, distance);
#endif
    }
    else if(!strcmp(name, "MUTEXBEGIN")) {
	pragma = HC_read_attr_field_from_pragma_str(pragma, label, &marker,
						    &real, &type);
	if (type[1] != '!') 
	    Punt("gen_sync_data: Invalid MUTEXBEGIN pragma - label field expected");
	if (pragma != NULL) 
	    Punt("gen_sync_data: Invalid MUTEXBEGIN pragma - extra fields present");
	new_oper = L_create_new_op(Lop_MUTEX_B);
	new_oper->src[0] = L_new_gen_label_operand(label);

    } 
    else if(!strcmp(name, "MUTEXEND")) {
	pragma = HC_read_attr_field_from_pragma_str(pragma, label, &marker,
						    &real, &type);
	if (type[1] != '!') 
	    Punt("gen_sync_data: Invalid MUTEXEND pragma - label field expected");
	if (pragma != NULL) 
	    Punt("gen_sync_data: Invalid MUTEXEND pragma - extra fields present");
	new_oper = L_create_new_op(Lop_MUTEX_E);
	new_oper->src[0] = L_new_gen_label_operand(label);
    } 
    /* GEH - added translation of stats_on and stats_off sync opers to Lcode */
    else if(!strcmp(name, "stats_on") || !strcmp(name, "stats_off")) {
        pragma = HC_read_attr_field_from_pragma_str(pragma, label, &marker,
                                                    &real, &type);

        if (type[1] != '$')
            Punt("gen_sync_data: Invalid stats_{on,off} pragma - string field expected");

        pragma = HC_read_attr_field_from_pragma_str(pragma, label, &marker,
                                                    &real, &type);

        if (type[1] != '%')
            Punt("gen_sync_data: Invalid stats_{on,off} pragma - integer field expected");

        pragma = HC_read_attr_field_from_pragma_str(pragma, label2, &marker,
                                                    &real, &type);

        if (type[1] != '$')
            Punt("gen_sync_data: Invalid stats_{on,off} pragma - string field expected");

        if (pragma != NULL)
            Punt("gen_sync_data: Invalid stats_{on,off} pragma - extra fields present");

        /* GEH - instead of putting fields into attribute, use oper sources */
        new_oper = L_create_new_op(Lop_SIM_DIR);
        attr = L_new_attr(name, 0);
        new_oper->src[0] = L_new_gen_string_operand(label);
        new_oper->src[1] = L_new_gen_int_operand(marker);
        new_oper->src[2] = L_new_gen_string_operand(label2);
        /*
        L_set_string_attr_field(attr, 0, label);
        L_set_int_attr_field(attr, 1, marker);
        L_set_string_attr_field(attr, 2, label2);
        */
        new_oper->attr = L_concat_attr(new_oper->attr, attr);
    }
    else Punt("gen_sync_data: Invalid sync pragma name");

    ret->type = HC_RET_NONE;
    L_insert_oper_after (cb, cb->last_op, new_oper);
}
  
/* WJN */
/*--------------------------------------------------------------------------*/
/* LCW - generate Lcode define opcode with attribute preserving the Profiler
 * probe information - 10/24/96
 */
static void gen_nulldefine_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    L_Oper *new_oper;
    L_Attr *attr= NULL;

    new_oper = L_create_new_op(Lop_DEFINE);

    /* propagate Hcode pragma to Lcode attribute */
    if (expr->pragma != 0) {
       attr = HC_gen_attr_from_pragma(expr->pragma);
       new_oper->attr = L_concat_attr(new_oper->attr, attr);
    }

    L_insert_oper_after(cb, cb->last_op, new_oper);
    ret->type = HC_RET_NONE;
}
/*--------------------------------------------------------------------------*/
static void gen_add_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1, op2;
    _HC_Ret x, y;
    _M_Type mtype;
    int is_ptr, increment;
    L_Attr *attr= NULL; /* LCW 8/3/95 */

    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    HC_hcode2lcode_type(expr->type, &mtype);
    is_ptr = 0;
    if (IsPointerType(op1->type) | IsArrayType(op1->type)) {
	is_ptr = 1;
    	if (IsPointerType(op2->type) | IsArrayType(op2->type)) 
	    Punt("gen_add: cannot add two pointers");
    } else
    if (IsPointerType(op2->type) | IsArrayType(op2->type)) {
	Expr temp;
	temp = op1;
	op1 = op2;
	op2 = temp;
	is_ptr = 1;
    } 
    HC_gen_data(cb, op1, &x);
    HC_simplify(cb, &x);
    HC_gen_data(cb, op2, &y);
    HC_simplify(cb, &y);

    if (is_ptr) {
	Type type = op1->type;
	Dcltr dcltr = type->dcltr;
	type->dcltr = dcltr->next;
	increment = H_lcode_typesize(type);
	type->dcltr = dcltr;
	HC_ret_mulC(cb, &y, increment);
    }
    if ((mtype.unsign==0) | IsRealType(expr->type)) {
	_HC_Operand dest, src1, src2;
	src1 = x.op1;
	src2 = y.op1;
	if (L_propagate_sign_size_ctype_info)
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
	else
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
        /* LCW -- change the last argument from 0 to attr - 8/3/95 */
	HC_gen_add(cb, &dest, &src1, &src2, mtype.unsign, attr);
	ret->type = HC_RET_SIMPLE;
	ret->op1 = dest;
    } else {
	/* assume unsigned */
    	HC_ret_add(cb, ret, &x, &y);
    }
}
/*--------------------------------------------------------------------------*/
static void gen_sub_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1, op2;
    _HC_Ret x, y;
    int op1_is_ptr, op2_is_ptr;
    _HC_Operand dest, src1, src2, tm, inc;
    int increment;
    _M_Type mtype;
    L_Attr *attr= NULL; /* LCW 8/9/95 */

    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    op1_is_ptr = op2_is_ptr = 0;
    if (IsPointerType(op1->type) | IsArrayType(op1->type)) {
	op1_is_ptr = 1;
    	if (IsPointerType(op2->type) | IsArrayType(op2->type)) {
	    op2_is_ptr = 1;
	}
    } else
    if (IsPointerType(op2->type) | IsArrayType(op2->type)) {
	Punt("x-y: y cannot be a pointer, if x is not");
    }
    HC_gen_data(cb, op1, &x);
    HC_simplify(cb, &x);
    HC_gen_data(cb, op2, &y);
    HC_simplify(cb, &y);
    increment = 1;

    if (op1_is_ptr) {
	Type type;
	Dcltr dcltr;
	type = op1->type;
	dcltr = type->dcltr;
	type->dcltr = dcltr->next;
	increment = H_lcode_typesize(type);
	type->dcltr = dcltr;
    }
    src1 = x.op1;
    src2 = y.op1;
    HC_hcode2lcode_type(expr->type, &mtype);
    if (L_propagate_sign_size_ctype_info)
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
    else
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);
    if (op1_is_ptr & op2_is_ptr) {
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- add an additional argument attr -- 8/9/95 */
	HC_gen_sub(cb, &dest, &src1, &src2, mtype.unsign, attr);
	if (increment!=1) {
	    tm = dest;
	    HC_new_int(&inc, increment, 0);
	    /* REH 4/16/96 - Cannot generate unsigned divide */
	    /* on a pointer subtract since the result may    */
	    /* very well be a negative integer.              */
	    /*
	    HC_gen_div(cb, &dest, &tm, &inc, 1);
	    */
	    /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	    if (expr->pragma != 0)
	       attr = HC_gen_attr_from_pragma(expr->pragma);
	    /* LCW -- add an additional argument attr -- 8/9/95 */
	    HC_gen_div(cb, &dest, &tm, &inc, 0, attr);
	}
    } else {
    	if (increment!=1) {
	    if (src2.type==HC_I) {
		HC_new_int(&tm, src2.value.i * increment, 0);
	    } else {
		HC_new_register(&tm, HC_next_reg_id(), M_TYPE_INT, 0);
		HC_new_int(&inc, increment, 0);
		/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
		if (expr->pragma != 0)
		   attr = HC_gen_attr_from_pragma(expr->pragma);
		/* LCW -- add an additional argument attr -- 8/9/95 */
		HC_gen_mul(cb, &tm, &src2, &inc, 1, attr);
	    }
    	} else {
	    tm = src2;
	}
	/* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
	if (expr->pragma != 0)
	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW -- add an additional argument attr -- 8/9/95 */
	HC_gen_sub(cb, &dest, &src1, &tm, mtype.unsign, attr);
    }
    ret->type = HC_RET_SIMPLE;
    ret->op1 = dest;
}
/*--------------------------------------------------------------------------*/
static void gen_mul_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1, op2;
    _HC_Ret x, y;
    _M_Type mtype;
    _HC_Operand dest, src1, src2;

    L_Attr *attr= NULL; /* LCW 8/9/95 */

    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    HC_gen_data(cb, op1, &x);
    HC_simplify(cb, &x);
    HC_gen_data(cb, op2, &y);
    HC_simplify(cb, &y);
    HC_hcode2lcode_type(expr->type, &mtype);
    src1 = x.op1;
    src2 = y.op1;

    if (L_propagate_sign_size_ctype_info)
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
    else
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);
    /* LCW -- transfer the pragmas to attributes  -- 8/9/95 */
    if (expr->pragma != 0)
       attr = HC_gen_attr_from_pragma(expr->pragma);
    /* LCW -- add an additional argument attr -- 8/9/95 */
    HC_gen_mul(cb, &dest, &src1, &src2, mtype.unsign, attr);
    ret->type = HC_RET_SIMPLE;
    ret->op1 = dest;
}
/*--------------------------------------------------------------------------*/
static void gen_div_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1, op2;
    _HC_Ret x, y;
    _M_Type mtype;
    _HC_Operand dest, src1, src2;

    L_Attr *attr= NULL; /* LCW 8/9/95 */

    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    HC_gen_data(cb, op1, &x);
    HC_simplify(cb, &x);
    HC_gen_data(cb, op2, &y);
    HC_simplify(cb, &y);
    HC_hcode2lcode_type(expr->type, &mtype);
    src1 = x.op1;
    src2 = y.op1;

    if (L_propagate_sign_size_ctype_info)
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
    else
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);
    /* LCW -- transfer the pragmas to attributes  -- 8/9/95 */
    if (expr->pragma != 0)
       attr = HC_gen_attr_from_pragma(expr->pragma);
    /* LCW -- add an additional argument attr - 8/9/95 */
    HC_gen_div(cb, &dest, &src1, &src2, mtype.unsign, attr);
    ret->type = HC_RET_SIMPLE;
    ret->op1 = dest;
}
/*--------------------------------------------------------------------------*/
static void gen_mod_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1, op2;
    _HC_Ret x, y;
    _M_Type mtype;
    _HC_Operand dest, src1, src2;

    L_Attr *attr= NULL; /* LCW 8/9/95 */

    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    HC_gen_data(cb, op1, &x);
    HC_simplify(cb, &x);
    HC_gen_data(cb, op2, &y);
    HC_simplify(cb, &y);
    HC_hcode2lcode_type(expr->type, &mtype);
    src1 = x.op1;
    src2 = y.op1;
    if (L_propagate_sign_size_ctype_info)
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
    else
      HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);

    /* LCW -- transfer the pragmas to attributes  -- 8/9/95 */
    if (expr->pragma != 0)
       attr = HC_gen_attr_from_pragma(expr->pragma);

#ifdef OLD_MOD
    /*
     *	dest = src1 / src2
     *	dest = dest * src2
     *	dest = src1 - dest
     */
    tm = dest;
    /* LCW -- add an additional argument attr -- 8/9/95 */
    HC_gen_div(cb,&dest, &src1, &src2, mtype.unsign, attr);
    HC_gen_mul(cb,&dest, &tm, &src2, mtype.unsign, L_copy_attr(attr));
    HC_gen_sub(cb,&dest, &src1, &tm, mtype.unsign, L_copy_attr(attr));
#else
    HC_gen_mod(cb,&dest, &src1, &src2, mtype.unsign, attr);
#endif
    ret->type = HC_RET_SIMPLE;
    ret->op1 = dest;
}
/*--------------------------------------------------------------------------*/
static void gen_unary_data(L_Cb *cb, Expr expr, HC_Ret ret)
{
    Expr op1;
    _HC_Ret x;
    _M_Type mtype;
    _HC_Operand dest, src1, zero, all;

    L_Attr *attr= NULL; /* LCW 8/9/95 */

    op1 = GetOperand(expr, 1);
    HC_gen_data(cb, op1, &x);
    HC_simplify(cb, &x);
    HC_hcode2lcode_type(expr->type, &mtype);
    src1 = x.op1;

/* BCC - depending on the type of src1, zero could be 0.0 or 0 - 6/19/95 */
    if (src1.data_type == M_TYPE_FLOAT)
	HC_new_float(&zero, (double) 0.0);
    else if (src1.data_type == M_TYPE_DOUBLE)
	HC_new_double(&zero, (double) 0.0);
    else
	HC_new_int(&zero, 0, 0);

    HC_new_int(&all, 0xFFFFFFFF, 0);
/* BCC - not and inv use M_TYPE_INT as the dest register type - 6/19/95 */
    if (expr->opcode == OP_not || expr->opcode == OP_inv) 
	HC_new_register(&dest, HC_next_reg_id(), M_TYPE_INT, 0);
    else
 	if (L_propagate_sign_size_ctype_info)
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, mtype.unsign);
	else
	  HC_new_register(&dest, HC_next_reg_id(), mtype.type, 0);

    /* LCW -- transfer the pragmas to attributes  -- 8/9/95 */
    if (expr->pragma != 0)
       attr = HC_gen_attr_from_pragma(expr->pragma);

    switch (expr->opcode) {
    case OP_neg:
	    /* DMG - 24 May 94 - added missing 4th arg */
	/* LCW -- add an additional argument attr -- 8/9/95 */
	HC_gen_sub(cb,&dest, &zero, &src1, mtype.unsign, attr);
	break;
    case OP_not:
	/* LCW -- add an additional argument attr -- 8/9/95 */
	HC_gen_eq(cb,&dest, &zero, &src1, op1, attr);
	break;
    case OP_inv:
	/* LCW -- add an additional argument attr -- 8/9/95 */
	HC_gen_xor(cb,&dest, &all, &src1, attr);
	break;
    case OP_abs:
	/* LCW -- add an additional argument attr -- 8/9/95 */
	HC_gen_abs(cb,&dest, &src1, attr);
	break;
    default:
	Punt("gen_unary: illegal opcode");
    }
    ret->type = HC_RET_SIMPLE;
    ret->op1 = dest;
}
/*==========================================================================*/
