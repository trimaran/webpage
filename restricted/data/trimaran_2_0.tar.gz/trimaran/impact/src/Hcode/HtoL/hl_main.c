/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.10  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Apr. 12, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File :          hl_main.c
 *      Description :   main routine for H to L conversion
 *      Authors :       Scott Mahlke, Dave Gallagher, Wen-mei Hwu
 *
\*****************************************************************************/
#include "hl_main.h"

/* external functions */
extern void HL_process_input();


/*=======================================================================*/
/*
 *	Parameters for HtoL
 */
/*=======================================================================*/

int HL_do_flatten=0;
int HL_generate_hashing_branches=1;
int HL_ignore_hash_profile_weight=0;
int HL_ignore_hash_br_seq_weight=0;
int HL_generate_abs_instructions=0;
int HL_generate_sync_arcs=0;
int HL_generate_label_attrs=0;
int HL_generate_static_branch_attrs=0;
int HL_generate_acc_name_attrs=0;
int HL_verbose_yes=0;
int HL_retain_sync_nums=0;
int HL_debug_sync_arcs=0;
int HL_gen_bit_field_operations=0;
int HL_generate_sign_extend_operations=0;
int HL_use_subroutine_call=0;
/* LCW - emit source information - 8/5/97 */
int HL_emit_source_info = 0;
/* Allow emitting of subset of source info that Lemulate needs -ITI/JCG 4/99 */
int HL_emit_data_type_info = 0;

/*===========================================================================*/
/*
 *      HtoL parameter reading
 */
/*===========================================================================*/

void H_read_parm_HtoL (Parm_Parse_Info *ppi)
{
        /* See if read parameter matches one of the defined parameters */

    L_read_parm_b(ppi, "do_flatten", &HL_do_flatten);
    L_read_parm_b(ppi, "generate_hashing_branches",
		&HL_generate_hashing_branches);
    L_read_parm_b(ppi, "ignore_hash_profile_weight",
		&HL_ignore_hash_profile_weight);
    L_read_parm_b(ppi, "ignore_hash_br_seq_weight",
		&HL_ignore_hash_br_seq_weight);
    L_read_parm_b(ppi, "generate_abs_instructions", 
		&HL_generate_abs_instructions);
    L_read_parm_b(ppi, "generate_sync_arcs", &HL_generate_sync_arcs);
    L_read_parm_b(ppi, "generate_label_attrs", &HL_generate_label_attrs);
    L_read_parm_b(ppi, "generate_static_branch_attrs",
                &HL_generate_static_branch_attrs);
    L_read_parm_b(ppi, "generate_acc_name_attrs",
		&HL_generate_acc_name_attrs);
    L_read_parm_b(ppi, "retain_sync_nums", &HL_retain_sync_nums);
    L_read_parm_b(ppi, "debug_sync_arcs", &HL_debug_sync_arcs);
    L_read_parm_b(ppi, "verbose_yes", &HL_verbose_yes);
    L_read_parm_b(ppi, "generate_bit_field_operations", 
		&HL_gen_bit_field_operations);
    L_read_parm_b(ppi, "generate_sign_extend_operations", 
		&HL_generate_sign_extend_operations);
    L_read_parm_b(ppi, "substitute_subroutine_call_for_operation", 
		&HL_use_subroutine_call);
    L_read_parm_b(ppi, "emit_source_info", &HL_emit_source_info); /* LCW */
    L_read_parm_b(ppi, "emit_data_type_info", 
		  &HL_emit_data_type_info); /* -ITI/JCG 4/99 */
}


/*===========================================================================*/
/*
 *      HtoL Alloc Pools
 */
/*===========================================================================*/

L_Alloc_Pool *L_alloc_sync_hash = NULL;
L_Alloc_Pool *L_alloc_tail_list = NULL;


void 
H_setup_alloc_pools()
{
    L_alloc_sync_hash = L_create_alloc_pool("L_Sync_Hash",
                        sizeof(struct L_Sync_Hash), 64);

    L_alloc_tail_list = L_create_alloc_pool("L_Tail_List",
                        sizeof(struct L_Tail_List), 128);

}

void
H_check_alloc_for_func()
{
    L_print_alloc_info(stderr, L_alloc_sync_hash,
                            L_debug_data_struct_alloc);
    L_print_alloc_info(stderr, L_alloc_tail_list,
                            L_debug_data_struct_alloc);
}


/*=======================================================================*/
/*
 *	MAIN
 *
 *	This procedure has to initialize both Hcode and Lcode parameters
 *	and global variables.  This is necessary since both Hcode and
 *	Lcode routines are used to do this conversion.
 */
/*=======================================================================*/

void main(int argc, char **argv, char **envp)
{
    C_Arg arg[C_MAX_ARG];
    int n_arg, i, j;
    Parm_Macro_List *external_list;
    int read_i, read_o;

    /* Initialize Hcode parameters */
    H_arch = "impact";
    H_model = "v1.0";
    F_input = "stdin";
    F_output = "stdout";
    F_error = "stderr";
    Fin = stdin;
    Fout = stdout;
    Ferr = stderr;

    /* Initialize Lcode parameters */
    L_arch = "impact";
    L_model = "v1.0";
    L_input_file = "stdin";
    L_output_file = "stdout";

    /* save the current Hcode/Lcode pass name for error messages */
    H_curr_pass_name = argv[0];
    L_curr_pass_name = argv[0];

    /*
     * Get macro definitions from command line and environment.
     * This is the updated version of command_line_macro_list,
     * any it may be used in the same way.
     */
    external_list = L_create_external_macro_list (argv, envp);

    /*
     * Get L_parm_file from command line (-p path), or environment
     * variable "STD_PARMS_FILE", or default to "./STD_PARMS"
     */
    H_parm_file = L_get_std_parm_name (argv, envp, "STD_PARMS_FILE",
                                       "./STD_PARMS");
    L_parm_file = H_parm_file;

    /*
     * Load HtoL, Hcode, and Lcode parameters now, so that command line
     * arguements will override them if specified.  Pass in all command line
     * macro definitions.
     */
    /* Renamed 'architecture' to 'Larchitecture' -JCG 5/26/98 */
    L_load_parameters_aliased (H_parm_file, external_list, 
                          "(Larchitecture", "(architecture", H_read_parm_arch);
    /* Renamed 'file' to 'Lfile' -JCG 5/26/98 */
    L_load_parameters_aliased (H_parm_file, external_list, 
			       "(Lfile", "(file", H_read_parm_file);
    L_load_parameters (H_parm_file, external_list, 
                          "(Hcode", H_read_parm_Hcode);
    L_load_parameters (H_parm_file, external_list, 
			  "(HtoL", H_read_parm_HtoL);

    /* Renamed 'architecture' to 'Larchitecture' -JCG 5/26/98 */
    L_load_parameters_aliased (L_parm_file, external_list,
                       "(Larchitecture", "(architecture", L_read_parm_arch);
    /* Renamed 'file' to 'Lfile' -JCG 5/26/98 */
    L_load_parameters_aliased (L_parm_file, external_list,
                       "(Lfile", "(file", L_read_parm_file);
    /* Renamed 'global' to 'Lglobal' -JCG 5/26/98 */
    L_load_parameters_aliased (L_parm_file, external_list,
                       "(Lglobal", "(global", L_read_parm_global);

    /*
     * If the first argument does not contain an -, it is
     * ignored.  Punt if this is the case.
     */
    if ((argv[1] != NULL) && (argv[1][0] != '-')) {
        H_punt ("main: Unknown command line option '%s'.", argv[1]);
    }

    /* Mark that we have not read the input or output file yet */
    read_i = 0;
    read_o = 0;

    /* Process the rest of the command line arguments */
    n_arg = C_get_arg(argc-1, argv+1, arg, C_MAX_ARG);
    for (i=0; i < n_arg; i++)
    {
        char *option;
        option = arg[i].option;

        /* Get input file name - Hcode file */
        if (! strcmp(option, "-i"))
        {
            /* Punt if input file specified twice */
            if (read_i)
                H_punt ("main: Parsing command line: -i specified twice.\n");

            /* Make sure file name specified */
            if (arg[i].count < 1)
                H_punt("Parsing command line: -i needs input_file_name.");
            /* Make sure that only one file name specified */
            if (arg[i].count > 1)
            {
                fprintf (stderr, "Error parsing command line: -i");
                for (j = 0; j < arg[i].count; j++)
                    fprintf (stderr, " %s", arg[i].spec[j]);
                fprintf (stderr, "\n");
                H_punt ("Cannot specify more than one input file with -i.");
            }

            F_input = C_findstr(arg[i].spec[0]);
	    L_input_file = F_input;

            /* Mark that we have read an input file name */
            read_i = 1;
        }

        /* Get output file name - Lcode file */
        else if (! strcmp(option, "-o"))
        {
            /* Punt if output file specified twice */
            if (read_o)
                H_punt ("Parsing command line: -o specified twice.\n");

            /* Make sure file name specified */
            if (arg[i].count < 1)
                H_punt("Parsing command line: -o needs output_file_name.");
            /* Make sure only one file name specified */
            if (arg[i].count > 1)
            {
                fprintf (stderr, "Parsing command line: -o");
                for (j = 0; j < arg[i].count; j++)
                    fprintf (stderr, " %s", arg[i].spec[j]);
                fprintf (stderr, "\n");
                H_punt ("Cannot specify more than one output file with -o.");
            }

            L_output_file = C_findstr(arg[i].spec[0]);

            /* Mark that we have read an output file */
            read_o = 1;
        }

        /* Ignore -p */
        else if (strcmp (option, "-p") == 0)
            ;

        /* Ignore -P, -F  (and for now -D), accept to make sure there
         * are no argument after it.
         */
        else if ((option[0] == '-') &&
                 ((option[1] == 'P') || (option[1] == 'D') ||
                  (option[1] == 'F')))
        {
            /* Make sure there is nothing after the -Pmacro_name=val */
            if (arg[i].count > 0)
            {
                H_punt ("Unknown command line option '%s'.",
                        arg[i].spec[0]);
            }

        }

        /* Otherwise, punt, unknown commmand line arguments */
        else
        {
            /* Print out what we are punting on */
            fprintf (stderr, "Error parsing command line: %s", option);
            for (j = 0; j < arg[i].count; j++)
                fprintf (stderr, " %s", arg[i].spec[j]);
            fprintf (stderr, "\n");

            H_punt ("Unknown command line option.");
        }
    }

    /*
     * Renice this process to L_nice_value.
     * Ignore the error codes that will be returned if
     * already reniced or L_nice_value is invalid.
     */
#ifndef __WIN32__
/* ADA 5/29/96: Win95/NT has diffenent way to change priority but IMPACT
   		module running on Win95/NT doesn't really care about it */
    setpriority(PRIO_PROCESS, 0, IMPACT_MAX(L_nice_value, H_nice_value));
#endif

    /* open input/output/error files */
    if (strcmp(F_input, "stdin")) {
        Fin = fopen(F_input, "r");
        if (Fin==NULL) H_punt("main: cannot open input file");
    }
    if (strcmp(F_error, "stderr")) {
        Ferr = fopen(F_error, "w");
        if (Ferr==NULL) H_punt("main: cannot open log file");
    }


    /*
     *  Initialize Lcode symbols
     */
    L_init_symbol();

    L_OUT = L_open_output_file(L_output_file);

    /*
     *  Create pools for Lcode data structs
     */
    L_setup_alloc_pools();

    /*
     *  Create pools for Hcode data structs
     */
    H_setup_alloc_pools();

    /*
     *  Set up the enviroment
     */
    M_set_machine(L_arch, L_model);
    M_define_macros(L_macro_symbol_table);
    M_define_opcode_name(L_opcode_symbol_table);

    if (M_layout_order()==M_LITTLE_ENDIAN)
        H_dat_format = DAT_LITTLE_ENDIAN;
    else if (M_layout_order()==M_BIG_ENDIAN)
        H_dat_format = DAT_BIG_ENDIAN;
    else
        H_punt("main: unknown layout ordering!");

    H_output_form = OUTPUT_RTL;

/* BCC - read the size of integer types ( char, short, int, long) - 6/8/95 */
    H_GetIntegerSize();

    /* call process routine */
    HL_process_input();

    /* close the output files */
    L_close_output_file(L_OUT);

    /* check Lcode data struct allocation */
    if (L_check_data_struct_alloc) {
        L_check_alloc_for_func();
        L_check_alloc_for_data();
        H_check_alloc_for_func();
    }

    exit(0);

}
