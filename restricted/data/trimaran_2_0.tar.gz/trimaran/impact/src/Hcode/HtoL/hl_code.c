/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.10  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Apr. 12, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * Copyright 1999 IMPACT Technologies, Inc; Champaign, Illinois
 * For commercial license rights, contact: Marketing Office via
 * electronic mail: marketing@impactinc.com
 *
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	hl_code.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Creation Date:	June, 1990
 *	Revised: Dave Gallagher, Scott Mahlke - June 1994
 *		Build Lcode structure rather than just printing out text file
 *      Revised by: Ben-Chung Cheng - June 1995
 *              Change M_SIZE_INT, M_SIZE_CHAR to H_INT_SIZE, H_CHAR_SIZE
 *              Those should be determined in runtime, not compile time
\*****************************************************************************/
#include "hl_main.h"

#define TEST_SIZE

#undef DEBUG
#undef DEBUG_STRUCT_LAYOUT

/* forward declarations */
static void HC_layout_struct(StructDcl st);
static void HC_layout_union(UnionDcl un);

/*------------------------------------------------------------------------*/
int H_gen_lcode = 0;

/*------------------------------------------------------------------------*/
/*
 *	EXPORT FUNCTIONS.
 */

void H_gen_lcode_include(char *file_name)
{
    if (HC_EXPAND_INCLUDE_FILE)
	ReadIncludeFile(file_name);
}

/* LCW - added new parameter "list" for debugging info - 4/14/96 */
void H_gen_lcode_struct(L_Datalist *list, StructDcl st)
{
    H_gen_lcode = 1;
    HC_layout_struct(st);
    if (HL_emit_source_info || HL_emit_data_type_info)
       HC_gen_struct(list, st); /* LCW */
    H_gen_lcode = 0;
}

/* LCW - added new parameter "list" for debugging info - 4/14/96 */
void H_gen_lcode_union(L_Datalist *list, UnionDcl un)
{
    H_gen_lcode = 1;
    HC_layout_union(un);
    if (HL_emit_source_info || HL_emit_data_type_info)
       HC_gen_union(list, un); /* LCW */
    H_gen_lcode = 0;
}

/* LCW - added new parameter "list" for debugging info - 4/14/96 */
void H_gen_lcode_enum(L_Datalist *list, EnumDcl en)
{
    H_gen_lcode = 1;
    HC_assign_enum(en);
    if (HL_emit_source_info || HL_emit_data_type_info)
       HC_gen_enum(list, en); /* LCW */
    H_gen_lcode = 0;
}

void H_gen_lcode_var(L_Datalist *list, VarDcl var)
{
    H_gen_lcode = 1;
    HC_gen_var(list, var);
    H_gen_lcode = 0;
}

void H_gen_lcode_func(FuncDcl fn)
{
    Type old_param_type[HC_MAX_PARAM_VAR];
    Type new_param_type[HC_MAX_PARAM_VAR];
    VarList list;
    int num, i;
    /*
     *	Need to fix the parameter type.
     *	So array means pointer.
     */
    num = 0;
    for (list=fn->param; list!=0; list=list->next) {
	old_param_type[num] = list->var->type;
	new_param_type[num] = CopyType(list->var->type);
	list->var->type = new_param_type[num];
	num += 1;
	if (num>=HC_MAX_PARAM_VAR)
	    Punt("H_gen_lcode_func: too many parameters");
    }
    for (i=0; i<num; i++) {
	Dcltr dcltr;
	dcltr = new_param_type[i]->dcltr;
	if (dcltr!=0) {
	    if (dcltr->method==D_ARRY) {
		dcltr->method = D_PTR;
	    }
	}
    }
    /*
     *	Generate code.
     */
    H_gen_lcode = 1;
    HC_gen_func(fn);
    H_gen_lcode = 0;
    /*
     *	Restore parameter type.
     */
    num = 0;
    for (list=fn->param; list!=0; list=list->next) {
	list->var->type = old_param_type[num];
	RemoveType(new_param_type[num]);
	num += 1;
    }
}

int H_lcode_typesize(Type type)
{
    _M_Type mtype;
    HC_hcode2lcode_type(type, &mtype);
    return (mtype.size / H_CHAR_SIZE);	/* return byte count instead */
}

int H_lcode_enum_value(char *field_name)
{
    return HC_enum(field_name);
}

/*------------------------------------------------------------------------*/
/*
 *	bit field representation.
 *	|<-------- M_TYPE_LONG --------->|
 *	+--------------------------------+
 *	|00000000111111000000000000000000| <--- bit_mask
 *	+--------------------------------+
 *		      |<---------------->| bit_offset
 *
 *	To read a bit field,
 *	1. data = fetch long word
 *	2. data = data & bit_mask
 *	3. data >> bit_offset (logical shift)
 */
static long bit_mask(int length, int shift)
{
    long mask, i;
    mask = 0;
    for (i=0; i<length; i++)
	mask = (mask<<1) | 0x01;
    mask = mask << shift;
    return mask;
}

typedef struct _HC_StructField {
	char		*name;
	_M_Type		mtype;
	long		offset;
	short		is_bit_field;
	int		nbits;
	int		bit_offset;
	long		bit_mask;
} _HC_StructField, *HC_StructField;

typedef struct _HC_Struct {
	char		*name;
	_M_Type		mtype;
	HC_StructField	fields;
	int		n_fields;
} _HC_Struct, *HC_Struct;

static _HC_Struct struct_def[HC_MAX_STRUCT];
static _HC_Struct union_def[HC_MAX_UNION];
static int n_struct_def = 0;
static int n_union_def = 0;

static HC_Struct find_struct(char *name)
{
    int i;
    for (i=0; i<n_struct_def; i++) {
	if (! strcmp(struct_def[i].name, name)) {
#ifdef DEBUG
printf("find_struct(%s) = %d\n", name, i);
#endif
	     return (struct_def + i);
	}
    }
    return 0;
}

static HC_Struct add_struct(char *name, int n)
{
    int i;
    if (find_struct(name)!=0)
	Punt("multiple definition of a struct layout");
    i = n_struct_def++;
    if (i>=HC_MAX_STRUCT)
	Punt("too many struct");
    struct_def[i].name = C_findstr(name);
    struct_def[i].fields = (HC_StructField) malloc (n*sizeof(_HC_StructField));
    struct_def[i].n_fields = n;
    if (struct_def[i].fields==0)
	Punt("out of memory");
#ifdef DEBUG
printf("add_struct(%s) = %d\n", name, i);
#endif
    return (struct_def + i);
}

static HC_Struct find_union(char *name)
{
    int i;
    for (i=0; i<n_union_def; i++) {
	if (! strcmp(union_def[i].name, name)) {
#ifdef DEBUG
printf("find_union(%s) = %d\n", name, i);
#endif
	     return (union_def + i);
	}
    }
    return 0;
}

static HC_Struct add_union(char *name, int n)
{
    int i;
    if (find_union(name)!=0)
	Punt("multiple definition of a union layout");
    i = n_union_def++;
    if (i>=HC_MAX_UNION)
	Punt("too many union");
    union_def[i].name = C_findstr(name);
    union_def[i].fields = (HC_StructField) malloc (n*sizeof(_HC_StructField));
    union_def[i].n_fields = n;
    if (union_def[i].fields==0)
	Punt("out of memory");
#ifdef DEBUG
printf("add_union(%s) = %d\n", name, i);
#endif
    return (union_def + i);
}

HC_StructField find_struct_field(char *name, char *fname)
{
    HC_Struct st;
    int i;
    st = find_struct(name);
    if (st==0) return 0;
    for (i=0; i<st->n_fields; i++)
	if (! strcmp(st->fields[i].name, fname))
	    return (st->fields + i);
    return 0;
}

static HC_StructField find_union_field(char *name, char *fname)
{
    HC_Struct st;
    int i;
    st = find_union(name);
    if (st==0) return 0;
    for (i=0; i<st->n_fields; i++)
	if (! strcmp(st->fields[i].name, fname))
	    return (st->fields + i);
    return 0;
}

/*
 *	STRUCT 
 */
static void HC_layout_struct(StructDcl st)
{
    int offset[HC_MAX_STRUCT_FIELD];
    int bit_offset[HC_MAX_STRUCT_FIELD];
    char *fname[HC_MAX_STRUCT_FIELD];
    _M_Type mtype[HC_MAX_STRUCT_FIELD];
    int i, k;
    Field field;
    HC_Struct str;
    int struct_align, struct_size;
    /*
     *	layout fields.
     */
    i = 0;
    for (field=st->fields; field!=0; field=field->next) {
	fname[i] = C_findstr(field->name);
	HC_hcode2lcode_type(field->type, mtype+i);
	i += 1;
	if (i>=HC_MAX_STRUCT_FIELD)
	    Punt("too many struct fields");
    }
    /* Pass struct name so can use layout database -ITI(JCG) 2/99 */
    struct_align = M_struct_align(i,mtype, st->name);
    /*
      fprintf(stdout,"Max struct align = %d\n",struct_align);
    */
    i = 0;
    for (field=st->fields; field!=0; field=field->next) {
	fname[i] = C_findstr(field->name);
	HC_hcode2lcode_type(field->type, mtype+i);
	if (field->bit_field!=0) {
	    Expr expr;
	    int length;
	    int t;
	    expr = HC_ReduceExpr(field->bit_field);
	    length = IntegralExprValue(expr);
	    RemoveExpr(expr);
	    /* Phase in use of unsigned/signed info -ITI(JCG) 2/99 */
	    t = field->type->type;
	    /* REH 9/12/93 - proper handling of bit fields */
	    if ( length <= M_type_size(M_TYPE_CHAR) )
		M_bit_char(mtype+i, length, (t&TY_UNSIGNED)!=0);
	    else if ( length <= M_type_size(M_TYPE_SHORT) )
		M_bit_short(mtype+i, length, (t&TY_UNSIGNED)!=0);
	    else if ( length <= M_type_size(M_TYPE_LONG) )
		M_bit_long(mtype+i, length, (t&TY_UNSIGNED)!=0);
	    /* HER */
	}
#ifdef DEBUG_STRUCT_LAYOUT
	printf("struct %s field %s: type=%d, unsign=%d, align=%d, "
	       "size=%d, nbits=%d\n",
	       st->name, field->name, mtype[i].type, mtype[i].unsign,
	       mtype[i].align, mtype[i].size, mtype[i].nbits);
#endif
	i += 1;
	if (i>=HC_MAX_STRUCT_FIELD)
	    Punt("too many struct fields");
    }

    /* Pass struct & field names so can use layout database -ITI(JCG) 2/99 */
    M_struct_layout(i, mtype, offset, bit_offset, st->name, fname);
    
    /* Pass struct name so can use layout database -ITI(JCG) 2/99 */
    struct_size = M_struct_size (i, mtype, struct_align, st->name);

    /*
     *	define the struct.
     */
    str = add_struct(st->name, i);
    M_struct(&(str->mtype), struct_align, struct_size);
    for (k=0; k<i; k++) {
	str->fields[k].name = fname[k];
	str->fields[k].mtype = mtype[k];
	str->fields[k].offset = offset[k] / H_CHAR_SIZE; /* use byte count */
	str->fields[k].is_bit_field = 0;
	if ( (mtype[k].type==M_TYPE_BIT_LONG) ||
/* REH 9/15/93 */
	     (mtype[k].type==M_TYPE_BIT_SHORT) ||
/* HER */
	     (mtype[k].type==M_TYPE_BIT_CHAR)) {
	    int length, shift;
	    length = mtype[k].nbits;
	    switch (mtype[k].type)  {
		case M_TYPE_BIT_LONG:
		    shift = bit_offset[k] % M_type_size(M_TYPE_LONG);
		    break;
		case M_TYPE_BIT_SHORT:
		    shift = bit_offset[k] % M_type_size(M_TYPE_SHORT);
		    break;
		case M_TYPE_BIT_CHAR:
		    shift = bit_offset[k] % M_type_size(M_TYPE_CHAR);
		    break;
	    }
/* HER */
	    str->fields[k].is_bit_field = 1;
	    str->fields[k].nbits = length;
	    str->fields[k].bit_offset = shift;
	    str->fields[k].bit_mask = bit_mask(length, shift);
	}
		/* DMG 4/22/95 - added else stmt */
	else {
	    str->fields[k].nbits = M_type_size(mtype[k].type);
	    str->fields[k].bit_offset = 0;
	    str->fields[k].bit_mask = 0;
	}
#ifdef DEBUG_STRUCT_LAYOUT
printf("HC_layout_struct: %s{%s}: align=%d, size=%d, type=%d, unsign=%d, offset=%d\n", 
	st->name, fname[k], mtype[k].align, mtype[k].size, mtype[k].type,
	mtype[k].unsign, str->fields[k].offset);
printf("\tnbits=%d, offset=%d, mask=0x%x\n", 
	str->fields[k].nbits,
	str->fields[k].bit_offset,
	str->fields[k].bit_mask);
#endif
    }
}

     /*	UNION */
static void HC_layout_union(UnionDcl un)
{
    int offset[HC_MAX_STRUCT_FIELD];
    int bit_offset[HC_MAX_STRUCT_FIELD];
    char *fname[HC_MAX_STRUCT_FIELD];
    _M_Type mtype[HC_MAX_STRUCT_FIELD];
    int i, k;
    Field field;
    HC_Struct str;
    /*
     *	layout fields.
     */
    i = 0;
    for (field=un->fields; field!=0; field=field->next) {
	fname[i] = C_findstr(field->name);
	HC_hcode2lcode_type(field->type, mtype+i);
	if (field->bit_field != 0) {
	    fprintf(stderr, "union %s field %s\n",
		un->name, field->name);
	    Punt("bit field is not allowed in union");
	}
#ifdef DEBUG_STRUCT_LAYOUT
printf("union %s field %s: type=%d, unsign=%d, align=%d, size=%d, nbits=%d\n",
un->name, field->name, mtype[i].type, mtype[i].unsign,
mtype[i].align, mtype[i].size, mtype[i].nbits);
#endif
	i += 1;
	if (i>=HC_MAX_UNION_FIELD)
	    Punt("too many union fields");
    }
    M_union_layout(i, mtype, offset, bit_offset, un->name, fname);
    /*
     *	define the union
     */
    str = add_union(un->name, i);
    M_union(&(str->mtype), M_union_align(i, mtype, un->name), 
	    M_union_size(i, mtype, un->name));
    for (k=0; k<i; k++) {
	str->fields[k].name = fname[k];
	str->fields[k].mtype = mtype[k];
	str->fields[k].offset = offset[k] / H_CHAR_SIZE; /* use byte count */
	str->fields[k].is_bit_field = 0;
#ifdef DEBUG_STRUCT_LAYOUT
printf("HC_layout_union: %s{%s}: align=%d, size=%d, type=%d, unsign=%d, offset=%d\n", 
	un->name, fname[k], mtype[k].align, mtype[k].size, mtype[k].type,
	mtype[k].unsign, offset[k]);
#endif
    }
}

/*------------------------------------------------------------------------*/
/*
 *	ENUM 
 *		This has been moved to struct.c in the Hcode directory
 *		because it makes more sense there.  SAM 5-94
 */
/*------------------------------------------------------------------------*/
void HC_hcode2lcode_type(Type type, M_Type mtype)
{
    Dcltr dcltr;
    int t;
    HC_Struct st;
    if ((type==0)|(mtype==0))
	Punt("HC_hcode2lcode_type: nil argument");
    dcltr = type->dcltr;
    if (dcltr==0) {
	t = type->type;
	if (t & TY_STRUCT) {
	    st = find_struct(type->struct_name);

	    /* BCC - handle extern null struct - 5/29/95 */
	    if (st==0) {
		if ((type->type & TY_EXTERN) == 0) {
		    fprintf(stderr, "struct %s is not defined", 
			    type->struct_name);
		    Punt("can not determine size");
		}
		else M_struct(mtype, 0, 0);
	    }
	    else M_struct(mtype, st->mtype.align, st->mtype.size);
	} else
	if (t & TY_UNION) {
	    st = find_union(type->struct_name);
	    /* BCC - handle extern null struct - 5/29/95 */
	    if (st==0) {
		if ((type->type & TY_EXTERN) == 0) {
		    fprintf(stderr, "union %s is not defined", 
			    type->struct_name);
		    Punt("can not determine size");
		}
		else M_union(mtype, 0, 0);  /* added 'else' keyword - GEH */
	    } /* added 'else' keyword - GEH */
	    else M_union(mtype, st->mtype.align, st->mtype.size);
	} else
	if (t & TY_ENUM) {
	    M_int(mtype, 0);
	} else
	if (t & TY_DOUBLE) {
	    M_double(mtype, (t&TY_UNSIGNED)!=0);
	} else
	if (t & TY_FLOAT) {
	    M_float(mtype, (t&TY_UNSIGNED)!=0);
	} else
	if (t & TY_LONG) {
	    M_long(mtype, (t&TY_UNSIGNED)!=0);
	} else
	if (t & TY_SHORT) {
	    M_short(mtype, (t&TY_UNSIGNED)!=0);
	} else
	if (t & TY_CHAR) {
	    M_char(mtype, (t&TY_UNSIGNED)!=0);
	} else
	if (t & TY_VOID) {
	    M_void(mtype);
	} else {
	    M_int(mtype, (t&TY_UNSIGNED)!=0);
	}
    } else {
	    /* DMG - arrays references are now handled as pointers; however,
		they will have an index field */
	if ( (dcltr->method==D_PTR) && (dcltr->index == NULL) ){
	    M_pointer(mtype);
	} else
	if (dcltr->method==D_FUNC) {
	    M_pointer(mtype);
	} else 
	if ( (dcltr->method==D_ARRY) ||
	     ( (dcltr->method==D_PTR) && (dcltr->index != NULL) ) ) {
	    if (dcltr->index==0) {
	    	M_pointer(mtype);
	    } else {
		Expr index;
		_M_Type etype;
		int dim, align, size;
		index = HC_ReduceExpr(dcltr->index);
		/* BCC - use temporary IsIntegralExprForArray - 5/24/95 */
		if (! IsIntegralExprForArray(index)) {
		    Punt("array dimension must be a constant");
		}
		/* BCC - use temporary IntegralExprValueForArray - 5/24/95 */
		dim = IntegralExprValueForArray(index);
		RemoveExpr(index);
		type->dcltr = dcltr->next;
		HC_hcode2lcode_type(type, &etype);
		type->dcltr = dcltr;
		align = M_array_align(&etype);
		size = M_array_size(&etype, dim);
#ifdef TEST_SIZE
if (size<0) {
    Punt("H_hcode2lcode_type: size must not be negative (arry)");
}
if (align<0) {
    Punt("H_hcode2lcode_type: align must not be negative (arry)");
}
#endif
		M_block(mtype, align, size);
	    }
	} else {
	    Punt("unknown dcltr type");
	}
    }
}
/*------------------------------------------------------------------------*/
void HC_struct_info(char *name, int *size, int *align)
{
    HC_Struct st;
    st = find_struct(name);
    if (st==0) {
	fprintf(stderr, "struct %s\n", name);
	Punt("HC_struct_info: undefined struct");
    } else {
	*size = st->mtype.size / H_CHAR_SIZE;	/* return byte count */
	*align = st->mtype.align / H_CHAR_SIZE;
    }
}

void HC_union_info(char *name, int *size, int *align)
{
    HC_Struct st;
    st = find_union(name);
    if (st==0) {
	fprintf(stderr, "union %s\n", name);
	Punt("HC_union_info: undefined union");
    } else {
	*size = st->mtype.size / H_CHAR_SIZE;	/* return byte count */
	*align = st->mtype.align / H_CHAR_SIZE;
    }
}

/* REH 9/12/93 - added length parameter */
void HC_struct_field_info(char *sname, char *fname, long *offset, M_Type mtype,
	int *is_bit, int *bit_offset, long *bit_mask, int *length)
{
    HC_StructField f;
    f = find_struct_field(sname, fname);
    if (f==0) {
	fprintf(stderr, "struct %s field %s\n", sname, fname);
	Punt("HC_struct_field_info: undefined field");
    } else {
	*offset = f->offset;
	*mtype = f->mtype;
	*is_bit = f->is_bit_field;
	*bit_offset = f->bit_offset;
	*bit_mask = f->bit_mask;
	*length = f->nbits;
    }
}

/* REH 9/12/93 - added length parameter */
void HC_union_field_info(char *sname, char *fname, long *offset, M_Type mtype,
	int *is_bit, int *bit_offset, long *bit_mask, int *length)
{
    HC_StructField f;
    f = find_union_field(sname, fname);
    if (f==0) {
	fprintf(stderr, "union %s field %s\n", sname, fname);
	Punt("HC_union_field_info: undefined field");
    } else {
	*offset = f->offset;
	*mtype = f->mtype;
	*is_bit = f->is_bit_field;
	*bit_offset = f->bit_offset;
	*bit_mask = f->bit_mask;
	*length = f->nbits;
    }
}
/*------------------------------------------------------------------------*/
