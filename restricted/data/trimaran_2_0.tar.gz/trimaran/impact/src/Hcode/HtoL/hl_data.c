/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.32  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 28, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	hl_data.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Creation Date:	June 1990
 *	 Revised: Dave Gallagher, Scott Mahlke - 6/94
 *              Build Lcode structure rather than just printing out text file
 *      Revised by: Ben-Chung Cheng - June 1995
 *              Change M_SIZE_INT, M_SIZE_CHAR to H_INT_SIZE, H_CHAR_SIZE
 *              Those should be determined in runtime, not compile time
\*****************************************************************************/
#include "hl_main.h"

#undef DEBUG_STRUCT_INIT


#undef TEST_SIZE

#define MIN_BSS_OBJECT_SIZE	8	/* 8 bytes */

/*
 * Swaps byte order in word 'W'.  Used to convert architectures with
 * different byte orders (assumes 32 bit words).
 * Please report bugs found in this macro to John Gyllenhaal.
 */
#define SWAP_BYTES_32(W)        ((((unsigned long) W) << 24) | \
	   		        ((((unsigned long) W) >> 24) & 0xff) | \
			        ((((unsigned long) W) >> 8) & 0xff00) | \
				((((unsigned long) W) & 0xff00) << 8))

#define SWAP_BYTES_16(H)        (((((unsigned long) H) << 8) & 0xff00) | \
	   		         ((((unsigned long) H) >> 8) & 0xff))

/* extern declarations */
extern void Gen_C_Expr(FILE *, Expr);
extern char *M_fn_label_name(char *, int (*is_func)(char *is_func_label));


/* forward declarations */
static void gen_var(L_Datalist *list, VarDcl var);
static void gen_init(L_Datalist *list, Type type, Init init, char *label,
                        long offset, M_Type mtype);
static L_Expr *L_gen_expr(Expr expr);
static L_Expr *gen_expr2(Expr expr);

/* BCC - added to handle the offset calculation of a->b->c->d - 5/31/95 */
static L_Expr *L_reduce_int_expr (L_Expr *expr);

/*-------------------------------------------------------------------------*/
static char *last_ms = "???";

void HC_ms(L_Datalist *list, char *name)
{
    L_Data *new_data;

    if (strcmp(name, last_ms)) {

	new_data = L_new_data (L_INPUT_MS);

	new_data->N = L_ms_id(name);

        L_concat_datalist_element (list, L_new_datalist_element(new_data));

	last_ms = name;
    }
}

/* SAM 8-97 */
void HC_invalidate_last_ms()
{
    last_ms = "??bla??";
}


/*-------------------------------------------------------------------------*/
/* LCW - add one more parameter to pass the type information of a variable
   to lcode for debugging - 4/12/96 */
void HC_gen_global (L_Datalist *list, char *name, Type type)
{
    L_Data *new_data;
    L_Expr *new_expr;
    char temp_name[256], *temp_ptr;
    
    new_data = L_new_data (L_INPUT_GLOBAL);

    new_expr = L_new_expr (L_EXPR_STRING);
    sprintf(temp_name, "_%s", name);
    temp_ptr = C_findstr(temp_name);
    
    new_expr->value.s = temp_ptr;

    new_data->address = new_expr;

    /* LCW - insert L_Type in L_Data structure - 4/12/96 */
    if (HL_emit_source_info || HL_emit_data_type_info)
       new_data->h_type = L_gen_type(type);
    else
       new_data->h_type = NULL;

    L_concat_datalist_element (list, L_new_datalist_element(new_data));
}

/*-------------------------------------------------------------------------*/
void HC_gen_var(L_Datalist *list, VarDcl var)
{
    Type type;
    int t, size;
    /*
     *	map big array that does not require initialization
     *	to (ms bss)
     */
    type = var->type;
    t = type->type;
    size = H_lcode_typesize(type);
    if (t & TY_STATIC) {
    	if ((var->init==0) && (size>=MIN_BSS_OBJECT_SIZE)) {
    	    HC_ms(list, "bss");
    	} else {
    	    HC_ms(list, "data");
    	}
	gen_var(list, var);
    } else
    if (t & TY_GLOBAL) {
	/* SAM 12-15-91 */
	if ((type->dcltr) && (type->dcltr->method==D_FUNC))
	    return;
	/* end SAM 12-15-91 */
    	if ((var->init==0) && (size>=MIN_BSS_OBJECT_SIZE)) {
    	    HC_ms(list, "bss");
    	} else {
    	    HC_ms(list, "data");
    	}
	/* LCW - pass type information for debugging - 4/12/96 */
	HC_gen_global (list, var->name, type);
	gen_var(list, var);
    } else
    if (t & TY_EXTERN) {
	/* do nothing for external variables */
    }
}

/*-------------------------------------------------------------------------*/
static void HC_gen_void (L_Datalist *list, char *name)
{
    L_Data *new_data;
    L_Expr *new_expr;
    char temp_name[256], *temp_ptr;

    new_data = L_new_data (L_INPUT_VOID);

    new_expr = L_new_expr (L_EXPR_STRING);
    sprintf(temp_name, "_%s", name);
    temp_ptr = C_findstr(temp_name);
    new_expr->value.s = temp_ptr;

    new_data->address = new_expr;

    L_concat_datalist_element (list, L_new_datalist_element(new_data));
}

/*-------------------------------------------------------------------------*/

static void HC_gen_scalar (L_Datalist *list, int type, int size, 
		Expr expr, char *name)
{
    L_Data *new_data;
    L_Expr *new_expr;
    char temp_name[256], *temp_ptr;

    new_data = L_new_data (type);

    new_expr = L_new_expr (L_EXPR_STRING);
    sprintf(temp_name, "_%s", name);
    temp_ptr = C_findstr(temp_name);
    new_expr->value.s = temp_ptr;

    new_data->N = size;
    new_data->address = new_expr;

    if (expr != NULL) {
	new_expr = L_gen_expr(expr);
	new_data->value = new_expr;
    }

    L_concat_datalist_element (list, L_new_datalist_element(new_data));
}

/*-------------------------------------------------------------------------*/
static void HC_gen_align (L_Datalist *list, int size, char *name)
{
    L_Data *new_data;
    L_Expr *new_expr;
    char temp_name[256], *temp_ptr;

    new_data = L_new_data (L_INPUT_ALIGN);

    new_expr = L_new_expr (L_EXPR_STRING);
    sprintf(temp_name, "_%s", name);
    temp_ptr = C_findstr(temp_name);
    new_expr->value.s = temp_ptr;

    new_data->address = new_expr;
    new_data->N = size;

    L_concat_datalist_element (list, L_new_datalist_element(new_data));
}

/*-------------------------------------------------------------------------*/
static void HC_gen_reserve (L_Datalist *list, int size)
{
    L_Data *new_data;

    new_data = L_new_data (L_INPUT_RESERVE);

    new_data->N = size;

    L_concat_datalist_element (list, L_new_datalist_element(new_data));
}

/*-------------------------------------------------------------------------*/
static void HC_gen_element_size (L_Datalist *list, int size, char *name)
{
    L_Data *new_data;
    L_Expr *new_expr;
    char temp_name[256], *temp_ptr;

    new_data = L_new_data (L_INPUT_ELEMENT_SIZE);

    new_expr = L_new_expr (L_EXPR_STRING);
    sprintf(temp_name, "_%s", name);
    temp_ptr = C_findstr(temp_name);
    new_expr->value.s = temp_ptr;

    new_data->address = new_expr;
    new_data->N = size;

    L_concat_datalist_element (list, L_new_datalist_element(new_data));
}

/*-------------------------------------------------------------------------*/
static void gen_var(L_Datalist *list, VarDcl var)
{
    Type type;
    Dcltr dcltr;
    Init init;
    _M_Type mtype, etype;
    char *name;
    name = var->name;
    type = var->type;
    dcltr = type->dcltr;
    init = var->init;
    if (name==0)
	name = HC_DEFAULT_LABEL;
    HC_hcode2lcode_type(type, &mtype);
    if (dcltr==0) {
	switch (mtype.type) {
	case M_TYPE_VOID:
	    HC_gen_void (list, name);
	    break;
  	case M_TYPE_CHAR:
	    if ((init!=0)&&(init->expr!=0))
	        HC_gen_scalar (list, L_INPUT_BYTE, 1, init->expr, name);
	    else 
	        HC_gen_scalar (list, L_INPUT_BYTE, 1, NULL, name);
	    break;
	case M_TYPE_SHORT:
	    if (! M_no_short_int()) {
	        if ((init!=0)&&(init->expr!=0))
	            HC_gen_scalar (list, L_INPUT_WORD, 1, init->expr, name);
		else
	            HC_gen_scalar (list, L_INPUT_WORD, 1, NULL, name);
	    } else {
	        if ((init!=0)&&(init->expr!=0))
	            HC_gen_scalar (list, L_INPUT_LONG, 1, init->expr, name);
		else
	            HC_gen_scalar (list, L_INPUT_LONG, 1, NULL, name);
	    }
	    break;
	case M_TYPE_INT:
	case M_TYPE_LONG:
	case M_TYPE_POINTER:
	    if ((init!=0)&&(init->expr!=0))
	        HC_gen_scalar (list, L_INPUT_LONG, 1, init->expr, name);
	    else 
	        HC_gen_scalar (list, L_INPUT_LONG, 1, NULL, name);
	    break;
	case M_TYPE_FLOAT:
	    if ((init!=0)&&(init->expr!=0))
	        HC_gen_scalar (list, L_INPUT_FLOAT, 1, init->expr, name);
	    else 
	        HC_gen_scalar (list, L_INPUT_FLOAT, 1, NULL, name);
	    break;
	case M_TYPE_DOUBLE:
	    if ((init!=0)&&(init->expr!=0))
	        HC_gen_scalar (list, L_INPUT_DOUBLE, 1, init->expr, name);
	    else 
	        HC_gen_scalar (list, L_INPUT_DOUBLE, 1, NULL, name);
	    break;
	case M_TYPE_UNION:
	case M_TYPE_STRUCT:
	case M_TYPE_BLOCK:
	    HC_gen_align (list, mtype.align/H_CHAR_SIZE, name);

	    HC_gen_reserve (list, mtype.size/H_CHAR_SIZE);
	    if (init!=0)
		gen_init(list, type, init, name, 0, &mtype);
	    break;
	default:
	    Punt("gen_var: illegal mtype");
	}
    } else {
	switch (dcltr->method) {
	case D_PTR:
	    if ((init!=0)&&(init->expr!=0))
	        HC_gen_scalar (list, L_INPUT_LONG, 1, init->expr, name);
	    else 
	        HC_gen_scalar (list, L_INPUT_LONG, 1, NULL, name);
	    break;
	case D_ARRY:
	    HC_gen_align (list, mtype.align/H_CHAR_SIZE, name);

	    /* Determine the array element size */
	    type->dcltr = dcltr->next;
	    HC_hcode2lcode_type(type, &etype);
	    type->dcltr = dcltr;

	    HC_gen_element_size (list, etype.size/H_CHAR_SIZE, name);

	    HC_gen_reserve (list, mtype.size/H_CHAR_SIZE);

	    if (init!=0)
		gen_init(list, type, init, name, 0, &mtype);
#ifdef TEST_SIZE
    	    if (mtype.align < 0) {
		Punt("gen_var: align of structure must not be negative (arry)");
    	    }
    	    if (mtype.size < 0) {
		Punt("gen_var: size of structure must not be negative (arry)");
    	    }
#endif
	    break;
	case D_FUNC:
	    /** do nothing **/
	    break;
	default:
	    Punt("gen_var: illegal dcltr");
	}
    }
}

L_Expr *L_new_addr(char *label, int offset)
{
    L_Expr *new_expr;
    new_expr = L_new_expr_addr((char *)M_fn_label_name (label,HC_is_function), offset);
    return (new_expr);
}

L_Expr *L_new_addr_no_underscore(char *label, int offset)
{
    L_Expr *new_expr;

    if (offset == 0) {
	new_expr = L_new_expr_label_no_underscore( (char *)M_fn_label_name (label,HC_is_function));
    }
    else {
	new_expr=L_new_expr_add( L_new_expr_label_no_underscore((char *)M_fn_label_name (label,HC_is_function)), L_new_expr_int(offset));
    }

    return (new_expr);
}
static void gen_init(L_Datalist *list, Type type, Init init, char *label, 
			long offset, M_Type mtype)
{
    Dcltr dcltr = type->dcltr;
    int t = type->type;
    int input_type;
    L_Data *new_data = NULL;


    if (init==0)
	return;
    if (dcltr==0) {
	if (t & TY_UNION) {
	    UnionDcl un;
	    Field field;
	    _M_Type f_mtype;
	    long f_offset, f_bit_mask;
	    int f_is_bit, f_bit_offset, f_length;
	    /*
	     *	For union structure, we initialize the first field.
	     */
	    un = FindUnion(type->struct_name);
	    if (un==0) {
		fprintf(stderr, "union %s\n", type->struct_name);
		Punt("cannot initialize an undefined union structure");
	    }
	    field = un->fields;
	    if (field==0) {
		fprintf(stderr, "union %s\n", type->struct_name);
		Punt("cannot initialize an empty union structure");
	    }
/* REH 9/12/93 added f_length parameter */
	    HC_union_field_info(type->struct_name, field->name,
		&f_offset, &f_mtype, &f_is_bit, &f_bit_offset, &f_bit_mask, &f_length);
	    gen_init(list, field->type, init, label, offset + f_offset, &f_mtype);
	    return;
	} else
	if (t & TY_STRUCT) {
	    StructDcl st;
	    Field field;
	        
	    /* REH 2/96 - New bit field changes */
    	    int is_bit, word_mask, start_offset;
	    Field ptr,start,last;
	    
	    _M_Type f_mtype;
	    long f_offset, f_bit_mask;
	    int f_is_bit, f_bit_offset, f_length;
	    Init initializer;
	    st = FindStruct(type->struct_name);
	    if (st==0) {
		fprintf(stderr, "struct %s\n", type->struct_name);
		Punt("cannot initialize an undefined struct structure");
	    }
	    field = st->fields;
	    if (field==0) {
		fprintf(stderr, "struct %s\n", type->struct_name);
		Punt("cannot initialize an empty struct structure");
	    }
	    initializer = init->set;
	    if (initializer==0) {
		fprintf(stderr, "struct %s\n", type->struct_name);
		fprintf(stderr, "expecting an aggregate initializer\n");
		Punt("bad initializer for struct");
	    }
	    /*
	     *	need to handle bit fields very carefully.
	     */
	    word_mask = ~( (H_INT_SIZE/H_CHAR_SIZE) - 1 );
	    
	    for ( ; field != NULL; field = last )  {

	        /* handle one word each time through loop JEM 5/23/96 */

		start = field;		/* first field in the word */
		last = NULL;
		
		HC_struct_field_info(type->struct_name, start->name,
			&f_offset, &f_mtype, &f_is_bit, 
			&f_bit_offset, &f_bit_mask,&f_length);

		is_bit = f_is_bit;		
		start_offset = f_offset;

#ifdef DEBUG_STRUCT_INIT
fprintf(stdout,"Start word:\n");
fprintf(stdout,"  %s.%s (%d): type = %d, align = %d, size = %d, off = %d, boff = %d, mask = %x\n",
		type->struct_name,start->name,f_is_bit,f_mtype.type,f_mtype.align,
		f_mtype.size,f_offset, f_bit_offset, f_bit_mask);
#endif

		/* Find end of word, and determine if word contains bitfields.
		   JEM 5/23/96 */
		for ( ptr = start->next; ptr != NULL; ptr = ptr->next )  {
		    _M_Type p_mtype;
		    long p_offset, p_bit_mask;
		    int p_is_bit, p_bit_offset, p_length;
			
		    HC_struct_field_info(type->struct_name, ptr->name,
				&p_offset, &p_mtype, &p_is_bit, 
				&p_bit_offset, &p_bit_mask,&p_length);

		    if ( (f_offset & word_mask) != (p_offset & word_mask) )
			break;	/* we have gone into the next word */ 
		    
		    /* is_bit test must be after word test, otherwise will
		     * misclassify non-bit fields as bit fields in 
		     * 124.m88ksim -JCG 6/99
		     */
		    is_bit |= p_is_bit;	/* determine if word has bitfield */

#ifdef DEBUG_STRUCT_INIT
fprintf(stdout,"  %s.%s (%d): type = %d, align = %d, size = %d, off = %d, boff = %d, mask = %x, p_is_bit = %i, is_bit = %i\n",
		type->struct_name,ptr->name,p_is_bit,p_mtype.type,p_mtype.align,
		p_mtype.size,p_offset, p_bit_offset, p_bit_mask, p_is_bit, is_bit);
#endif

		}

		last = ptr;	/* first field in next word */

#ifdef DEBUG_STRUCT_INIT
fprintf(stdout,"Stop word: is_bit = %i\n", is_bit);		
#endif

/* I heavily modfied this section below.  If you would like to see what
   the code looked like before I modified it, you can get it from cvs with 
   the command "cvs co -D 960425 HtoL" (Rick and I put in some initial,
   wrong modifications on 4/26/96) - JEM 5/23/96 */

		if ( is_bit )  {
		    Expr expr;
		    int shift, data_size, total_size;
		    unsigned long data;
		    long value = 0;
		    int initializer_type;

		    total_size = 0;

		    /* The current word contains a bit field */
		    /* pack it into one word.		     */
		    for ( ptr = start; ptr != last; ptr = ptr->next )  {

			HC_struct_field_info(type->struct_name, ptr->name,
					     &f_offset, &f_mtype, &f_is_bit, 
					     &f_bit_offset, &f_bit_mask,
					     &f_length);

			if ( initializer == 0 )  /* uninitialized field */
			    break;

			if ( initializer->expr == 0 ) {
			    Punt("illegal initializer for a bit field");
			}

			expr = HC_ReduceExpr(initializer->expr);

			if (! IsIntegralExpr(expr)) {
			    fprintf(stderr, "cannot reduce expression to constant\n");
			    Gen_C_Expr(stderr, initializer->expr);
			    Punt("illegal initializer for a bit field");
			}

			data = IntegralExprValue(expr);

#ifdef DEBUG_STRUCT_INIT
fprintf(stdout,"  %s.%s : type = %d, align = %d, size = %d, off = %d, boff = %d, mask = %x\n",
		type->struct_name,ptr->name,f_mtype.type,f_mtype.align,
		f_mtype.size,f_offset, f_bit_offset, f_bit_mask);
printf("start_offset = %d\n", start_offset);
#endif
#ifdef DEBUG_STRUCT_INIT
printf("original initializer = %d\n", data);
#endif 
			RemoveExpr(expr);
			
			initializer = initializer->next;


			/* get the data size (in bits) of load unit */

			switch(f_mtype.type) {
			    case M_TYPE_BIT_CHAR:
			        data_size = H_CHAR_SIZE;
			        break;
			    case M_TYPE_BIT_SHORT:
			        data_size = H_SHORT_SIZE;
			        break;
			    case M_TYPE_BIT_LONG:
			        data_size = H_LONG_SIZE;
			        break;
			    default:
			        /* field is not a bitfield */
			        data_size = f_mtype.size;
			}

			/* keep track of total size used in this word so far */

			total_size += f_mtype.size;

			/* Place bit field in proper location in its load
			   unit.  	
				f_bit_offset - bit offset from LSB of load unit. 
			       	f_bit_mask - mask off everything in load unit 
			       		     except for bitfield.  */ 

			/* The "load unit" is the unit (e.g. char, long, short)
                           that must be loaded to access the bitfield. */

			data = (data << f_bit_offset) & f_bit_mask;


			/* Place bit field in proper location in word. 
				f_offset - memory byte offset from byte 0
					   in bitfield major unit.  
			    	start_offset - the memory byte offset of byte 0
					       in the current word from byte
					       0 of the bitfield major unit.
			    	               (4 if in second word of long 
						bitfield.  0 otherwise.) 
				(f_offset - start_offset) is the memory byte
				offset from the base of the current word.   */

			/* Byte 0 corresponds to the least significant byte
			   on a BIG ENDIAN machine and the most significant
			   byte on a LITTLE ENDIAN machine. */

			/* The "bitfield major unit" referred to is the unit
			   which is declared in the source code to hold the 
			   bitfields.  For example:
				     struct  TEST1{
					  unsigned int         op:8,
					                       dest: 6,
					                       src1: 6,
					                       src2: 6;
					};
			   unsigned int is the "bitfield major unit." */
 

			if ( M_layout_order() == M_LITTLE_ENDIAN )  {

			    /* Shift from least significant end towards most 
			       significant end for memory byte offset */

			    data = data << ((f_offset - start_offset) << 3);

#ifdef DEBUG_STRUCT_INIT
printf("LITTLE ENDIAN: initializer in proper word location = %d\n", data);
#endif

			}
			else {	/* BIG ENDIAN */
			    /* The f_offset for BIG ENDIAN machines is 
			       measured from the most significant end of
			       the word.  Right now, the bitfield load unit is 
			       at the least significant end.  Move it to the 
			       most significant end. */

			    data = data << (H_INT_SIZE - data_size);

			    /* shift from most significant end toward least 
			       significant end for memory byte offset */

			    data = data >> ((f_offset - start_offset) << 3);
#ifdef DEBUG_STRUCT_INIT
printf("BIG ENDIAN: initializer in proper word location = %d\n", data);
#endif
			}

			/* or data for current field into word value */
		        value |= data;

#ifdef DEBUG_STRUCT_INIT		        
printf("value so far = %d\n", value);
#endif

		    }



		    /* Create the initializer.  JEM 5/23/96 */

		    /* For BIG ENDIAN machines, we have packed the 
		       bitfield load units with reference to the upper end of 
		       the word.  If we don't need the whole word, then we 			       need to shift the data so that it is correctly offset
		       from the new upper end. JEM 5/23/96 */

		    if ( total_size <= H_CHAR_SIZE )  {
		        initializer_type = L_INPUT_WB;
		        if ( M_layout_order() == M_BIG_ENDIAN )  {
		            value = value >> (H_INT_SIZE - H_CHAR_SIZE);
		        }
		    }
		    else if ( total_size <= H_SHORT_SIZE ) {
		        initializer_type = L_INPUT_WW;
		        if ( M_layout_order() == M_BIG_ENDIAN )  {
		            value = value >> (H_INT_SIZE - H_SHORT_SIZE);
		        }
		    }
		    else {
		        initializer_type = L_INPUT_WI;
		        if ( M_layout_order() == M_BIG_ENDIAN )  {
		            value = value >> (H_INT_SIZE - H_INT_SIZE);
		        }
		    }

#ifdef DEBUG_STRUCT_INIT		        
printf("final value = %d\n", value);
#endif

		    new_data = L_new_data_w(initializer_type,
		    		            L_new_addr(label,
		                  	               (offset+start_offset)),
		                            L_new_expr_int(value));
		}

/* End modified section.  JEM 5/23/96 */

		else {
		    /* The current word contains no bit fields */
		    /* handle it the "normal" way.	       */
		    for ( ptr = start; ptr != last; ptr = ptr->next )  {
			HC_struct_field_info(type->struct_name, ptr->name,
					     &f_offset, &f_mtype, &f_is_bit, 
					     &f_bit_offset, &f_bit_mask,&f_length);
#ifdef DEBUG_STRUCT_INIT		        
printf ("Normal word initialization: has initializer =  %d\n", 
	initializer);
#endif
			
			if ( initializer == 0 )  /* some fields uninitialized */
			    return;

			/* BCC - 2/13/96
			 * bug fix, should give ptr->type, instead of field-type
			 * because filed is is not the up-to-date field pointer
			 */
			gen_init(list, ptr->type, initializer, label, 
				 offset + f_offset, &f_mtype);
		    	initializer = initializer->next;
		    }
		}
	    }
#if 0
	    for (; field!=0; field=field->next) {
/* REH 9/15/93 */
		int bit_init_length = 0;
/* HER */
		if (initializer==0)	/* left some fields uninitialized */
		    return;
/* REG 9/12/93 added f_length parameter */
	    	HC_struct_field_info(type->struct_name, field->name,
			&f_offset, &f_mtype, &f_is_bit, 
			&f_bit_offset, &f_bit_mask,&f_length);
		if (f_is_bit) {
		    Field ptr, last;
		    long value = 0;
		    last = 0;
		    for (ptr=field; ptr!=0; ptr=ptr->next) {
	    		_M_Type p_mtype;
	    		long p_offset, p_bit_mask;
			int p_is_bit, p_bit_offset, p_length;
			Expr expr;
			long data;
/* REG 9/12/93 added f_length parameter */
	    		HC_struct_field_info(type->struct_name, ptr->name,
				&p_offset, &p_mtype, &p_is_bit, 
				&p_bit_offset, &p_bit_mask,&p_length);
			if (! p_is_bit)
			    break;
			if (p_offset != f_offset)
			    break;
			last = ptr;	/* last bit field used up */
			/*
			 *  Now add its share into the value field.
			 */
			if (initializer==0)
			    break;
			if (initializer->expr==0) {
			    Punt("illegal initializer for a bit field");
			}
			expr = HC_ReduceExpr(initializer->expr);
			if (! IsIntegralExpr(expr)) {
fprintf(stderr, "cannot reduce expression to constant\n");
Gen_C_Expr(stderr, initializer->expr);
			    Punt("illegal initializer for a bit field");
			}
			data = IntegralExprValue(expr);
			RemoveExpr(expr);
			initializer = initializer->next;
			data = (data<<p_bit_offset) & p_bit_mask;
			value |= data;
/* REH 9/15/93 */
			bit_init_length += p_length;
/* HER */
		    }
		    if (last==0)
			Punt("gen_init: internal error 0002");
		    /*
		     *	Generate the initialization.
		     *	Bit fields can only be M_BYTE or M_LONG.
		     */
		    /* Bit fields can know be M_BYTE,M_SHORT,or M_LONG */
   		    if ( bit_init_length <= M_type_size(M_TYPE_CHAR) )
			input_type = L_INPUT_WB;
    		    else if ( bit_init_length <= M_type_size(M_TYPE_SHORT) )
			input_type = L_INPUT_WW;
    		    else if ( bit_init_length <= M_type_size(M_TYPE_INT) )
			input_type = L_INPUT_WI;

		    new_data = L_new_data_w(input_type, 
				L_new_addr(label,(offset+f_offset)),
				L_new_expr_int(value & 0xFF));
		    /*
		     *	Prepare for the next field.
		     */
		    field = last;
		} else {
	    	    gen_init(list, field->type, 
			initializer, label, offset + f_offset, &f_mtype);
		    initializer = initializer->next;
		}
	    }
#endif
	} else {
	    switch (mtype->type) {
	    case M_TYPE_CHAR:
		new_data = L_new_data_w(L_INPUT_WB, L_new_addr(label,offset),
				L_gen_expr(init->expr));
		break;
	    case M_TYPE_SHORT:
	 	if (! M_no_short_int()) {
		    new_data = L_new_data_w(L_INPUT_WW,L_new_addr(label,offset),
				L_gen_expr(init->expr));
		} else {
		    new_data = L_new_data_w(L_INPUT_WI,L_new_addr(label,offset),
				L_gen_expr(init->expr));
		}
		break;
	    case M_TYPE_INT:
	    case M_TYPE_LONG:
	    case M_TYPE_POINTER:
		new_data = L_new_data_w(L_INPUT_WI, L_new_addr(label,offset),
				L_gen_expr(init->expr));
		break;
	    case M_TYPE_FLOAT:
		new_data = L_new_data_w(L_INPUT_WF, L_new_addr(label,offset),
				L_gen_expr(init->expr));
		break;
	    case M_TYPE_DOUBLE:
		new_data = L_new_data_w(L_INPUT_WF2, L_new_addr(label,offset),
				L_gen_expr(init->expr));
		break;
	    default:
		Punt("gen_init: illegal expression");
	    }
	}	
    } else {
	Expr expr = init->expr;
	if ((dcltr->method==D_ARRY)&(dcltr->next==0)
		&((t&TY_CHAR)!=0)&(expr!=0)&&(expr->opcode==OP_string)) {
	    new_data = L_new_data_w(L_INPUT_WS, L_new_addr(label,offset),
				L_new_expr_string(expr->value.string));
	} else
	if (dcltr->method==D_ARRY) {
	    Init initializer;
	    long local_offset, element_size;
	    _M_Type etype;
	    if (init->set==0) {
		fprintf(stderr, "expecting an aggregate initializer\n");
		Punt("illegal array initializer");
	    }
	    initializer = init->set;
	    if (initializer==0)
		return;
	    /*
	     *	The simplest way is to call gen_init recursively
	     *	for each of the element.
	     */
	    type->dcltr = dcltr->next;
	    element_size = H_lcode_typesize(type);
	    local_offset = offset;
	    HC_hcode2lcode_type(type, &etype);
	    for (; initializer!=0; initializer=initializer->next) {
		gen_init(list, type, initializer, label, local_offset, &etype);
		local_offset += element_size;
	    }
	    type->dcltr = dcltr;
	    return;
	} else
	if (dcltr->method==D_PTR) {
	    /*
	     *	A pointer is treated as long.
	     */
	    if (init->expr==0)
		Punt("initializer of a pointer must be a simple expression");
	    new_data = L_new_data_w(L_INPUT_WI, L_new_addr(label,offset),
				L_gen_expr(init->expr));
	} else
	if (dcltr->method==D_FUNC) {
	    Punt("cannot initialize a function");
	} else {
	    Punt("gen_init: internal error 001");
	}
    }
    if (new_data)
        L_concat_datalist_element (list, L_new_datalist_element(new_data));
}

static L_Expr *L_gen_expr(Expr expr)
{
    Expr reduced;
    L_Expr *new_expr;

    reduced = HC_ReduceExpr(expr);
    new_expr = gen_expr2(reduced);
    RemoveExpr(reduced);

    return (new_expr);
}

static L_Expr *gen_expr2(Expr expr)
{
    Type type;
    Dcltr dcltr;
    Expr op1, op2;
    long value;
    L_Expr *new_expr;
    char *var_name;
    VarList ptr;
    VarDcl var;

    if (expr==0)
	return (NULL);
    type = expr->type;
    dcltr = type->dcltr;
    switch (expr->opcode) {
    case OP_var:
	if (dcltr==0) {
	    if (! IsStructureType(type)) {
	    	fprintf(stderr, "var %s\n", expr->value.var_name);
	    	Punt("cannot propagate variable value");
		return (NULL);
	    }
	} 
	    /* DMG - If the PTR is an array ptr, it will have an index field,
		and is a legal expr */

	else if ( (dcltr->method==D_PTR) && (dcltr->index == NULL) ) {
	    fprintf(stderr, "var %s\n", expr->value.var_name);
	    Punt("cannot propagate pointer value");
	    return (NULL);
	}

	new_expr = L_new_expr_label ((char*)M_fn_label_name(expr->value.var_name,HC_is_function));
	break;
    case OP_enum:
	value = H_lcode_enum_value(expr->value.string);
	new_expr = L_new_expr_int(value);
	break;
    case OP_signed:
    case OP_unsigned:
	value = IntegralExprValue(expr);
	new_expr = L_new_expr_int(value);
	break;
    case OP_char:
	value = IntegralExprValue(expr);
	new_expr = L_new_expr_int(value & 0xFF);
	break;
    case OP_float:
#if 0
	if (IsFloatType(expr->type)) {
	    new_expr = L_new_expr_float(expr->value.real);
	} else {
	    new_expr = L_new_expr_double(expr->value.real);
	}
#endif
	new_expr = L_new_expr_float(expr->value.real);
	if (!IsFloatType(expr->type)) 
	    Punt("OP_float type mismatch");
	break;
    /* BCC - added - 8/5/96 */
    case OP_double:
	new_expr = L_new_expr_double(expr->value.real);
	if (!IsDoubleType(expr->type)) 
	    Punt("OP_cwdouble type mismatch");
	break;
    case OP_string:
	new_expr = L_new_expr_string(expr->value.string);
	break;
    /* NJW - ignore cast for initializations (2/93) */
    case OP_cast:
        new_expr = L_gen_expr(GetOperand(expr,1));
        break;
    /* WJN */
    case OP_neg:
        new_expr = L_new_expr(L_EXPR_NEG);
	new_expr->A = L_gen_expr(GetOperand(expr,1));
	break;
    case OP_inv:
        new_expr = L_new_expr(L_EXPR_COM);
	new_expr->A = L_gen_expr(GetOperand(expr,1));
	break;
    case OP_expr_size:
	op1 = GetOperand(expr, 1);
	    /* DMG - for arrays, the type of the variable reference is D_PTR;
		to correctly compute sizeof(A), we must use type from symbol
		table, not the variable itself */
/*
	if ( (op1->opcode == OP_var) && (op1->type->dcltr != NULL) && 
	     (op1->type->dcltr->method == D_PTR) ) {
	    type = NULL;
	    var_name = op1->value.var_name;

            if (currentFuncDcl!=0) {
              for (ptr=currentFuncDcl->local; ptr!=0; ptr=ptr->next) {
                if (! strcmp(ptr->var->name, var_name)) {
		    type = ptr->var->type;
		}
	      }
	    }
	    
            if ( (type == NULL) && (currentFuncDcl!=0) ){
              for (ptr=currentFuncDcl->param; ptr!=0; ptr=ptr->next) {
                if (! strcmp(ptr->var->name, var_name)) {
		    type = ptr->var->type;
		}
	      }
	    }

	    if ( type == NULL ) {
		var = FindVar (var_name);
		if (var != NULL) {
		    type = var->type;
		}
		else {
	    	    Punt("illegal sizeof expression: var not found in tables");
		}
	    }
	}
	else {
	    type = op1->type;
	}
*/
	type = op1->type;

	value = H_lcode_typesize(type);
	new_expr = L_new_expr_int(value);
	break;
    case OP_type_size:
	value = H_lcode_typesize(expr->value.type);
	new_expr = L_new_expr_int(value);
	break;
    case OP_add: {
	int is_ptr1;
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	is_ptr1 = IsPointerType(op1->type) | IsArrayType(op1->type);
	if (is_ptr1) {
	    Dcltr dcltr;
	    Type type;
	    int size;
	    type = op1->type;
	    dcltr = type->dcltr;
	    type->dcltr = dcltr->next;
	    size = H_lcode_typesize(type);
	    type->dcltr = dcltr;

	    new_expr = L_new_expr_add (L_gen_expr(op1),
			L_new_expr_mul(L_gen_expr(op2),L_new_expr_int(size)));
	} else {
	    new_expr = L_new_expr_add (L_gen_expr(op1), L_gen_expr(op2));
	}
	break;
    }
    case OP_sub: {
	int is_ptr1, is_ptr2;
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	is_ptr1 = IsPointerType(op1->type) | IsArrayType(op1->type);
	is_ptr2 = IsPointerType(op2->type) | IsArrayType(op2->type);
	if (is_ptr1 | is_ptr2) {
	    Dcltr dcltr;
	    Type type;
	    int size;
	    type = op1->type;
	    dcltr = type->dcltr;
	    type->dcltr = dcltr->next;
	    size = H_lcode_typesize(type);
	    type->dcltr = dcltr;
	    if (is_ptr1 & !is_ptr2) {
	        new_expr = L_new_expr_sub (L_gen_expr(op1),
			L_new_expr_mul(L_gen_expr(op2),L_new_expr_int(size)));
	    } else
	    if (is_ptr1 & is_ptr2) {
	        new_expr = L_new_expr_div (L_new_expr_sub(L_gen_expr(op1),
			L_gen_expr(op2)),L_new_expr_int(size));
	    } else {
	        new_expr = L_new_expr_sub (L_gen_expr(op1), L_gen_expr(op2));
	    }
	} else {
	    new_expr = L_new_expr_sub (L_gen_expr(op1), L_gen_expr(op2));
	}
	break;
    }
    case OP_mul:
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	new_expr = L_new_expr_mul (L_gen_expr(op1), L_gen_expr(op2));
	break;
    case OP_div:
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	new_expr = L_new_expr_div (L_gen_expr(op1), L_gen_expr(op2));
	break;
    case OP_addr:
	/*
	 *  The operand must be a OP_var.
	 */
	op1 = GetOperand(expr, 1);
	if (op1==0)
	    Punt("illegal initializer: & can be applied only on variables");
	if (op1->opcode==OP_var) {
	    new_expr = L_new_expr_label ((char*)M_fn_label_name(op1->value.var_name,HC_is_function));
	} else {
	    int opcode = op1->opcode;
	    /* BCC - adding OP_arrow - 5/29/95 */
	    if ((opcode!=OP_index) && (opcode!=OP_dot) && (opcode!=OP_arrow))
		Punt("illegal initializer: & can be applied only on variables and . []");
	    new_expr = L_gen_expr(op1);
	}
	break;
/******************************************************************************\
 * BCC - adding the new case to handle indr initialization      -      6/3/95 *
\******************************************************************************/
    case OP_indr: {
	/*
	 *  The operand must be a pointer
	 */
	op1 = GetOperand(expr, 1);
	if (op1==0)
	    Punt("illegal initializer: operand missing for (*)");
	if (! IsPointerType(op1->type) && ! IsArrayType(op1->type))
	    Punt("illegal initializer: * can be applied only on pointers");
	op1->type->dcltr = op1->type->dcltr->next;
	new_expr = L_gen_expr(op1);
	break;
    }

/******************************************************************************\
 * BCC - adding the new case to handle arrow initialization     -      6/1/95 *
\******************************************************************************/
    case OP_arrow: {
	long offset, bit_mask;
	int is_bit, bit_offset, length;
	_M_Type mtype;
	/* BCC - used for reducing a L_Expr - 6/1/95 */
	L_Expr *before_reduce;
	op1 = GetOperand(expr, 1);
	if (op1==0)
	    Punt("illegal initializer: x->y: corrupted x");
	if ( ! ((op1->type->type & (TY_STRUCT | TY_UNION)) &&
		IsPointerType(op1->type)))
	    Punt("illegal initializer: \
		  x->y: x must be a pointer to a structure");
	if (op1->type->type & TY_STRUCT) {
	    HC_struct_field_info(op1->type->struct_name, expr->value.string,
		&offset, &mtype, &is_bit, &bit_offset, &bit_mask, &length);
	} else {
	    HC_union_field_info(op1->type->struct_name, expr->value.string,
		&offset, &mtype, &is_bit, &bit_offset, &bit_mask, &length);
	}
	if (offset==0) {
	    before_reduce = L_gen_expr(op1);
	    new_expr = L_reduce_int_expr(before_reduce);
	} else {
	    before_reduce = L_new_expr_add (L_gen_expr(op1),
					    L_new_expr_int(offset));
	    new_expr = L_reduce_int_expr(before_reduce);
	}
	break;
    }
    case OP_dot: {
	long offset, bit_mask;
	int is_bit, bit_offset, length;
	_M_Type mtype;
	/* BCC - used for reducing a L_Expr - 6/1/95 */
	L_Expr *before_reduce;
	op1 = GetOperand(expr, 1);
	if (op1==0)
	    Punt("illegal initializer: x.y: corrupted x");
	if (! IsStructureType(op1->type))
	    Punt("illegal initializer: x.y: x must be a structure");
	if (op1->type->type & TY_STRUCT) {
/* REH 9/12/93 added length parameter */
	    HC_struct_field_info(op1->type->struct_name, expr->value.string,
		&offset, &mtype, &is_bit, &bit_offset, &bit_mask, &length);
	} else {
/* REG 9/12/93 added length parameter */
	    HC_union_field_info(op1->type->struct_name, expr->value.string,
		&offset, &mtype, &is_bit, &bit_offset, &bit_mask, &length);
	}
	if (offset==0) {
/* BCC - reduce it before return - 6/1/95 */
	    before_reduce = L_gen_expr(op1);
	    new_expr = L_reduce_int_expr(before_reduce);
	} else {
/* BCC - reduce it before return - 6/1/95 */
	    before_reduce = L_new_expr_add (L_gen_expr(op1),
					    L_new_expr_int(offset));
	    new_expr = L_reduce_int_expr(before_reduce);
	}
	break;
    }
    case OP_index: {
	Expr base, offset;
	int size, N;
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	if ((op1==0)|(op2==0))
	    Punt("illegal initializer: x[y]");
	base = HC_ReduceExpr(op1);
	offset = HC_ReduceExpr(op2);
	if (! IsIntegralExpr(offset)) {
	    fprintf(stderr, "(a[x]) in initailizer: x must be a constant");
	    Punt("the initializer is too complex");
	}
	N = IntegralExprValue(offset);
	size = H_lcode_typesize(expr->type);	/* size of 1 element */
	if (N==0) {
	    new_expr = L_gen_expr(base);
	} else {
            /* The addition is:
             *          base_addr + (offset_into_array * size_of_elements) */
	    new_expr = L_new_expr_add (L_gen_expr(base), 
					L_new_expr_int(size * N));
	}
	RemoveExpr(base);
	RemoveExpr(offset);
	break;
    }
    default:
	Gen_C_Expr(stderr, expr);
	Punt("illegal initializer: too complex");
    }
    return (new_expr);
}
/*-------------------------------------------------------------------------*/
/* Added by REH 4/14/93 for HPPA */
int HC_is_function(char *fn_name)
{
    VarDcl var;
    Dcltr ptr;
    int is_ptr = 0,is_func = 0;

    /* check to see if the label is in the function symbol table */
    if ( FindFunction(fn_name) )
        is_func = 1;

    /* check to see if the label is a global variable */
    if ( !is_func && ((var = (VarDcl)FindVar(fn_name)) != NULL) )  {
        ptr = var->type->dcltr;
        while ( ptr != NULL )  {
            if ( ptr->method == D_PTR )  { is_ptr = 1; }
            if ( ptr->method == D_FUNC )  { break; }
            ptr = ptr->next;
        }
        if ( ptr && !is_ptr )
            is_func = 1;
    }

    /* check to see if the label is a local variable for the current function */
    if ( !is_func && currentFuncDcl &&
         ((var=(VarDcl)FindVarList(currentFuncDcl->local,fn_name)) != NULL) )  {
        ptr = var->type->dcltr;
        while ( ptr != NULL )  {
            if ( ptr->method == D_PTR )  { is_ptr = 1; }
            if ( ptr->method == D_FUNC )  { break; }
            ptr = ptr->next;
        }
        if ( ptr && !is_ptr )
            is_func = 1;
    }

    return(is_func);
}
int HC_is_not_function(char *fn_name)
{ 
    return(0);
}
/*-------------------------------------------------------------------------*/

/* BCC - added to reduce offset calculation - 5/31/95 */
static L_Expr *L_reduce_int_expr(L_Expr *expr)
{
    L_Expr *new_expr, *expr1, *expr2;

    switch (expr->type) {
	case L_EXPR_ADD    :
	    expr1 = L_reduce_int_expr(expr->A);
	    if (expr1 == expr->A) {
		expr->A = 0;
	    }
	    else {
		L_delete_expr_element(expr->A);
		expr->A = 0;
	    }
	    expr2 = L_reduce_int_expr(expr->B);
	    if (expr2 == expr->B) {
		expr->B = 0;
	    }
	    else {
		L_delete_expr_element(expr->B);
		expr->B = 0;
	    }

	    if (expr1->type == L_EXPR_INT && expr2->type == L_EXPR_INT) {
		new_expr = L_new_expr(L_EXPR_INT);
		new_expr->value.i = expr1->value.i + expr2->value.i;
		L_delete_expr_element(expr);
		L_delete_expr_element(expr1);
		L_delete_expr_element(expr2);
	    }
	    else {
		new_expr = expr;
		new_expr->A = expr1;
		new_expr->B = expr2;
	    }
	    break;
	default:
	    new_expr = expr;
	    break;
    }
    return new_expr;
}


/* LCW - convert Hcode type structure to Lcode type structure - 4/12/96 */

L_Type *L_gen_type(Type htype)
{
    L_Type *ltype;
    
    if (htype == NULL)
      return NULL;
    ltype = (L_Type *) L_alloc(L_alloc_type);
    ltype->type = htype->type;
    if (htype->struct_name != NULL) {
      ltype->struct_name = (char *)malloc(strlen(htype->struct_name)+1);
      strcpy(ltype->struct_name, htype->struct_name);
    }
    else
      ltype->struct_name = NULL;
    if (htype->dcltr != NULL)
      ltype->dcltr = L_gen_dcltr(htype->dcltr);
    else
      ltype->dcltr = NULL;
    
    return ltype;
}    

/* LCW - convert Hcode dcltr structure to Lcode dcltr structure - 4/12/96 */

L_Dcltr *L_gen_dcltr(Dcltr hdcltr)
{
    L_Dcltr *ldcltr;

    if (hdcltr == NULL)
      return NULL;
    ldcltr = (L_Dcltr *) L_alloc(L_alloc_dcltr);

    if ((ldcltr->method = hdcltr->method) == L_D_ARRY) {
      if (hdcltr->index != NULL)
        ldcltr->index = L_gen_expr(hdcltr->index);
      else
        ldcltr->index = NULL;
    }
    else
      ldcltr->index = NULL;

    if (hdcltr->next != NULL)
      ldcltr->next = L_gen_dcltr(hdcltr->next);
    else
      ldcltr->next = NULL;

    return ldcltr;
}

/* LCW -- strip the double quotes of a string - 4/21/96 */
static char * StripDoubleQuotes(char *dst_str, char *src_str)
{
   char *ptr1, *ptr2;

   ptr1 = dst_str;
   ptr2 = src_str;
   while (*ptr2 != '\0')
      if (*ptr2 != '\"')
         *ptr1++ = *ptr2++;
      else
         ptr2++;
   *ptr1 = '\0';
   return dst_str;
}

/* LCW - generate L_Data for structure and union fields - 4/15/96 */
void HC_gen_field(L_Datalist *list, Field fld)
{
    L_Data *new_data;
    L_Expr *new_expr;
    
    new_data = L_new_data (L_INPUT_FIELD);

    new_expr = L_new_expr (L_EXPR_LABEL);

    if (fld->name != NULL) {
      new_expr->value.l = (char*)malloc(strlen(fld->name)+1);
      /*      strcpy(new_expr->value.l, fld->name); */
      StripDoubleQuotes(new_expr->value.l, fld->name);
    }
    else
      new_expr->value.l = NULL;

    new_data->address = new_expr;

    if (fld->bit_field != NULL)
      new_data->value = L_gen_expr(fld->bit_field);

    new_data->h_type = L_gen_type(fld->type);

    L_concat_datalist_element (list, L_new_datalist_element(new_data));
}


/* LCW - generate L_Data for structure type - 4/15/96 */
void HC_gen_struct(L_Datalist *list, StructDcl st)
{
    L_Data *new_data;
    L_Expr *new_expr;
    struct _Field *fldptr;
    
    new_data = L_new_data (L_INPUT_DEF_STRUCT);

    new_expr = L_new_expr (L_EXPR_LABEL);
    
    if (st->name != NULL) {
      new_expr->value.l = (char *)malloc(strlen(st->name)+1);
      strcpy(new_expr->value.l, st->name);
    }
    else
      new_expr->value.l = NULL;

    new_data->address = new_expr;

    if (strcmp(last_ms, "bss") && strcmp(last_ms, "data"))
      HC_ms(list, "bss");

    L_concat_datalist_element (list, L_new_datalist_element(new_data));

    for (fldptr = st->fields; fldptr != NULL; fldptr = fldptr->next)
      HC_gen_field(list, fldptr);
}

/* LCW - generate L_Data for union type - 4/15/96 */
void HC_gen_union(L_Datalist *list, UnionDcl un)
{
    L_Data *new_data;
    L_Expr *new_expr;
    struct _Field *fldptr;
    
    new_data = L_new_data (L_INPUT_DEF_UNION);

    new_expr = L_new_expr (L_EXPR_LABEL);
    
    if (un->name != NULL) {
      new_expr->value.l = (char *)malloc(strlen(un->name)+1);
      strcpy(new_expr->value.l, un->name);
    }
    else
      new_expr->value.l = NULL;

    new_data->address = new_expr;

    if (strcmp(last_ms, "bss") && strcmp(last_ms, "data"))
      HC_ms(list, "bss");

    L_concat_datalist_element (list, L_new_datalist_element(new_data));

    for (fldptr = un->fields; fldptr != NULL; fldptr = fldptr->next)
      HC_gen_field(list, fldptr);
}

/* LCW - generate L_Data for enumerator - 4/15/96 */
void HC_gen_enumerator(L_Datalist *list, EnumField fld)
{
    L_Data *new_data;
    L_Expr *new_expr;
    
    new_data = L_new_data (L_INPUT_ENUMERATOR);

    new_expr = L_new_expr (L_EXPR_LABEL);

    if (fld->name != NULL) {
      new_expr->value.s = (char*)malloc(strlen(fld->name)+1);
      /*      strcpy(new_expr->value.l, fld->name); */
      StripDoubleQuotes(new_expr->value.l, fld->name);
    }
    else
      new_expr->value.l = NULL;

    new_data->address = new_expr;

    if (fld->value != NULL)
      new_data->value = L_gen_expr(fld->value);

    L_concat_datalist_element (list, L_new_datalist_element(new_data));
}

/* LCW - generate L_Data for enum type - 4/15/96 */
void HC_gen_enum(L_Datalist *list, EnumDcl en)
{
    L_Data *new_data;
    L_Expr *new_expr;
    struct _EnumField *fldptr;
    
    new_data = L_new_data (L_INPUT_DEF_ENUM);

    new_expr = L_new_expr (L_EXPR_LABEL);
    
    if (en->name != NULL) {
      new_expr->value.l = (char *)malloc(strlen(en->name)+1);
      strcpy(new_expr->value.l, en->name);
    }
    else
      new_expr->value.l = NULL;

    new_data->address = new_expr;

    if (strcmp(last_ms, "bss") && strcmp(last_ms, "data"))
      HC_ms(list, "bss");

    L_concat_datalist_element (list, L_new_datalist_element(new_data));

    for (fldptr = en->fields; fldptr != NULL; fldptr = fldptr->next)
      HC_gen_enumerator(list, fldptr);
}
