/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   hl_sync.c
 *      Author: Dave Gallagher, Wen-mei Hwu
 *      Creation Date:  July 1994
\*****************************************************************************/

#include "hl_main.h"

static void HC_print_dep_arcs (L_Oper *oper, Pragma pragma);
static int HC_is_stack_operand (HC_Operand src);

/*********************************************************************
	Adding sync arcs into lcode
*********************************************************************/


static L_Sync *
L_create_numbered_sync (int num, char prob, char freq, int dist, int flags, int prof)
{
    L_Sync *new_sync;
    short info;

    new_sync = L_new_sync ((L_Oper *) num);
    new_sync->dist = (char) dist;
    new_sync->prof_info = (char) prof;

    info = (short) flags;
    info &= 0x1fff;
    if ( (prob == 'D') || (prob == 'd') )
        info |= 0x8000;
    switch (freq) {
        case 'A':
        case 'a':
            break;
        case 'F':
        case 'f':
            info |= 0x2000;
            break;
        case 'S':
        case 's':
            info |= 0x4000;
            break;
        case 'I':
        case 'i':
            info |= 0x6000;
            break;
        default:
            L_punt ("L_create_numbered_sync: unexpected freq type");
    }
    new_sync->info = info;

    return (new_sync);
}


static void
HC_print_dep_arcs (L_Oper *oper, Pragma pragma)
{
    DepInfo dep_info;
    L_Sync *new_sync;
    L_Attr *new_attr;

	/* expected pragma format:  ( (3,H,H,0,0), (1,D,A,3,4),(7,M,F,5,6) )
	   desired dep arc output {(1 D A 3 4) (7 M F 5 6)} attr DEP 3   */

    dep_info = pragma->dep_info;

    if (dep_info == NULL)
	Punt ("HC_print_dep_arcs: no dep expr in pragma");
    while (dep_info != NULL) {

	    /* if certainty field is 'H', then this is head pointer; simply
		put sync num in attr field */

	if (dep_info->certainty == 'H') {
	    new_attr = L_new_attr("DEP", 1);
	    L_set_int_attr_field(new_attr, 0, dep_info->num);
	    oper->attr = L_concat_attr(oper->attr, new_attr);
	}

	    /* if tail pointer, add new sync arc */
	else {
	    new_sync = L_create_numbered_sync(dep_info->num,dep_info->certainty,
			 dep_info->freq, dep_info->dist, dep_info->flags, 0);
	    L_insert_tail_sync_in_oper (oper, new_sync);
	}

	dep_info = dep_info->next;
    }    
}

#if 0
static int
HC_is_stack_operand (HC_Operand src)
{
    char *base_macro;

    if (src->type == HC_MAC) {

	base_macro = M_get_base_macro ();
  
        if (! strcmp (base_macro, src->value.mac) )
	    return (1);
	else
	    return (0);
    }
    else
        return (0);
}
#endif

void
HC_gen_dep_arcs (L_Oper *oper, Expr expr, HC_Operand src1, HC_Operand src2, 
					int is_store)
{
    Pragma pragma;
    int found_dep_prag;

	/* if the expr has a dep pragma, print it.  If not, then
	   punt if the load/store is not to the stack */

    found_dep_prag = 0;

    if (expr == NULL)
	return;

    pragma = expr->pragma;

    while (pragma != NULL) {

        if (! strcmp (pragma->specifier, "\"DEP\"") ) {
	    HC_print_dep_arcs (oper,pragma);
	    found_dep_prag = 1;
	}
	pragma = pragma->next;
    }


    if ( (! found_dep_prag) && (HL_debug_sync_arcs) ) {
	if (is_store) {
            if ( (! M_is_stack_operand (oper->src[0])) &&
                 (! M_is_stack_operand (oper->src[1])) )
	        printf("HC_gen_dep_arcs: No dep pragma for store oper %d\n",oper->id);
	}
	else
	    printf("HC_gen_dep_arcs: No dep pragma for load oper %d\n",oper->id);
    }
}



/*********************************************************************
	Maintaining sync hash table
*********************************************************************/

#define SYNC_HASH_SIZE 1024
#define SYNC_HASH_BITS 10

static L_Sync_Hash *Sync_Hash_Table[SYNC_HASH_SIZE];
 

static void
L_init_sync_hash ()
{
    int i;

    for (i=0; i < SYNC_HASH_SIZE; i++)
	Sync_Hash_Table[i] = NULL;
}


static L_Tail_List *
L_new_tail_list (L_Oper *oper)
{
    L_Tail_List *new_list;

    new_list = (L_Tail_List *) L_alloc (L_alloc_tail_list);
    new_list->tail_oper = oper;
    new_list->next_list = NULL;

    return (new_list);
}


static L_Sync_Hash *
L_new_sync_hash (int sync_num)
{
    L_Sync_Hash *new_hash;

    new_hash = (L_Sync_Hash *) L_alloc (L_alloc_sync_hash);
    new_hash->num = sync_num;
    new_hash->head_oper = NULL;
    new_hash->tail_list = NULL;
    new_hash->next_hash = NULL;

    return (new_hash);
}



static L_Sync_Hash *
L_find_and_add_sync_hash (int sync_num)
{
    L_Sync_Hash *sync_hash, *curr_hash;
    int hash_num;
    
	/* we search if sync_num is in table; if not create and add to table */

    hash_num = sync_num - ( (sync_num >> SYNC_HASH_BITS) << SYNC_HASH_BITS);

    curr_hash = Sync_Hash_Table[hash_num];

    while (curr_hash != NULL) {
	if (curr_hash->num == sync_num)
	    break;
	curr_hash = curr_hash->next_hash;
    }

    if (curr_hash == NULL) {
	sync_hash = L_new_sync_hash (sync_num);
	sync_hash->next_hash = Sync_Hash_Table[hash_num];
	Sync_Hash_Table[hash_num] = sync_hash;
    }
    else
	sync_hash = curr_hash;

    return (sync_hash);
}


static void
L_add_tail_to_sync_hash (L_Sync_Hash *sync_hash, L_Oper *oper)
{
    L_Tail_List *new_tail;

    new_tail = L_new_tail_list (oper);

    new_tail->next_list = sync_hash->tail_list;
    sync_hash->tail_list = new_tail;
}


static L_Tail_List *
L_copy_sync_tail_list (L_Tail_List *tail_list)
{
    L_Tail_List *head_list, *end_list, *new_list, *curr_list;

    head_list = NULL;
    end_list = NULL;
    curr_list = tail_list;

    while (curr_list) {

	new_list = L_new_tail_list (curr_list->tail_oper);

	if (head_list == NULL)
	    head_list = new_list;
	else 
	    end_list->next_list = new_list;
	end_list = new_list;

	curr_list = curr_list->next_list;
    }

    return (head_list);
}


static void
L_delete_sync_hash_table()
{
    int i;
    L_Tail_List *tail_list, *next_tail_list;
    L_Sync_Hash *sync_hash, *next_sync_hash;

    for (i=0; i < SYNC_HASH_SIZE; i++) {
	for (sync_hash=Sync_Hash_Table[i];sync_hash!=NULL;sync_hash=next_sync_hash){

	    next_sync_hash = sync_hash->next_hash;

	    for (tail_list=sync_hash->tail_list;tail_list!=NULL;tail_list=next_tail_list){

		next_tail_list = tail_list->next_list;

		tail_list->tail_oper = NULL;
		tail_list->next_list = NULL;
		L_free (L_alloc_tail_list, tail_list);
	    }
	    sync_hash->head_oper = NULL;
	    sync_hash->tail_list = NULL;
	    sync_hash->next_hash = NULL;
	    L_free (L_alloc_sync_hash, sync_hash);
	    
	}
	Sync_Hash_Table[i] = NULL;
    }
}


/*********************************************************************
	Removing redundant sync head numbers
*********************************************************************/

static void
L_add_renamed_sync (L_Oper *oper, int old_num, int new_num)
{
    L_Sync *new_sync;
    L_Sync_Info *sync_info;
    int i;


	/* find sync arc in oper with old_num, copy this arc,
	   giving it a new_num; then insert new arc in oper */

    if (oper == NULL)
	L_punt ("L_add_renamed_sync: null oper");

    sync_info = oper->sync_info;
    if (sync_info == NULL)
	L_punt ("L_add_renamed_sync: null sync_info");

    for (i = 0; i < sync_info->num_sync_in; i++) {
        if (sync_info->sync_in[i]->dep_oper == (L_Oper *) old_num) {
	    new_sync = L_copy_sync (sync_info->sync_in[i]);
	    new_sync->dep_oper = (L_Oper *) new_num;
	    L_insert_tail_sync_in_oper (oper, new_sync);
        }
    }
}



    /* Multiple loads and stores can have the same sync head number
	coming out of PCode, e.g. increments.  At this point, the 
	sync head number is in an attr DEP.  We need to find two opers
	with redundant SYNC numbers, rename one, and then duplicate all
	tails with this number */

void
L_remove_redundant_sync_numbers (L_Func *fn)
{
    L_Cb *cb;
    L_Oper *oper;
    L_Attr *attr;
    int max_sync_num = 0;
    int i, dep_oper_num, new_sync_num;
    L_Sync_Hash *sync_hash, *new_hash;
    L_Tail_List *tail_list;

    L_init_sync_hash ();

    /* walk all opers in fn.  add tail sync info to hash
	table; ignore head this paass */

    for (cb = fn->first_cb; cb != NULL; cb = cb->next_cb) {
	for (oper = cb->first_op; oper != NULL; oper = oper->next_op) {
	    if ( (attr = L_find_attr (oper->attr, "DEP")) != NULL) {
		if (attr->field[0]->value.i > max_sync_num)
		    max_sync_num = attr->field[0]->value.i;
	    }

	    if (oper->sync_info != NULL) {
		for (i = 0; i < oper->sync_info->num_sync_in; i++) {
		    dep_oper_num =(int) oper->sync_info->sync_in[i]->dep_oper;
		    if (dep_oper_num > max_sync_num)
			max_sync_num = dep_oper_num;
		    sync_hash = L_find_and_add_sync_hash (dep_oper_num);
		    L_add_tail_to_sync_hash (sync_hash, oper);
		}
	    }
/*
	    else {
		if ((oper->sync_info==NULL)||(oper->sync_info->num_sync_in!=0))
		    L_punt ("L_remove_redundant_sync_numbers: tail sync with no head");
	    }
*/
	}
    }


    /* walk all opers in fn.  add head sync pointer; if head
	sync pointer is already there, then this is redundant;
	if redundant, get new number and duplicate sync arc for
	all tails in list */

    for (cb = fn->first_cb; cb != NULL; cb = cb->next_cb) {
	for (oper = cb->first_op; oper != NULL; oper = oper->next_op) {

	    if ( (attr = L_find_attr (oper->attr, "DEP")) != NULL) {

		sync_hash = L_find_and_add_sync_hash (attr->field[0]->value.i);
		if (sync_hash->head_oper == NULL) {
		    sync_hash->head_oper = oper;
		}
		else {
			/* here is a redundant number */

		    new_sync_num = ++max_sync_num;
		    new_hash = L_find_and_add_sync_hash (new_sync_num);
		    new_hash->head_oper = oper;
		    new_hash->tail_list = 
			L_copy_sync_tail_list (sync_hash->tail_list);

		        /* now copy sync arcs for every oper in tail list */

		    for (tail_list = new_hash->tail_list; 
			 tail_list != NULL; tail_list = tail_list->next_list ) {

			L_add_renamed_sync (tail_list->tail_oper, 
				attr->field[0]->value.i, new_sync_num);
		    }
		}
	    }
	}
    }
}






/*********************************************************************
	Renaming all sync variables to use oper id
*********************************************************************/

    /* The sync arcs have been renamed to remove redundant head nums.
	Now we convert the sync->dep_oper pointers to really point
	to the dep_oper, vice holding the sync number. */

void
L_rename_sync_arcs(L_Func *fn)
{
    L_Cb *cb;
    L_Oper *oper;
    L_Attr *attr;
    int i, num;
    L_Sync_Hash *sync_hash;
    L_Sync_Info *sync_info;

    /* walk all opers in fn.  for every sync arc found, look up num in
	hash table and change num to dep_oper */

    for (cb = fn->first_cb; cb != NULL; cb = cb->next_cb) {
	for (oper = cb->first_op; oper != NULL; oper = oper->next_op) {

	    sync_info = oper->sync_info;

	    if (oper->sync_info != NULL) {
	        for (i = 0; i < sync_info->num_sync_in; i++) {
		    num = (int) sync_info->sync_in[i]->dep_oper;
		    sync_hash = L_find_and_add_sync_hash (num);
		    if (sync_hash->head_oper != NULL)
		        sync_info->sync_in[i]->dep_oper = sync_hash->head_oper;
		    else
    /* - temporarily removed - DMG
		        L_punt ("L_rename_sync_arcs: head oper not found");
    */
		    {
		        L_delete_tail_sync (oper, sync_info->sync_in[i]);
		        i--;
		    }
	        }
	    }

	    if ( ! HL_retain_sync_nums )
		if ( (attr = L_find_attr (oper->attr, "DEP") ) != NULL)
		    oper->attr = L_delete_attr (oper->attr, attr);
	}
    }

    L_delete_sync_hash_table();
}



