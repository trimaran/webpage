/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*===========================================================================
 *      File :          l_data_flow.c
 *      Description :   data flow functions
 *      Creation Date : February 1993
 *      Author :        Scott Mahlke, David August, Wen-mei Hwu
 *
 *==========================================================================*/

#include <Lcode/l_main.h>

#undef PRINT_FLOW_ANALYSIS_CALLS

#if 0
void L_do_partial_dead_code_removal(L_Func *fn)
{
  /* initialize dataflow library structures */
  D_setup_dataflow(fn, PF_ALL_OPERANDS);
  
  /* do the analysis */
  D_dataflow_analysis(PF_default_flow, LIVE_VARIABLE);

  PF_dead_code_removal(PF_default_flow);
}
#endif

void L_do_flow_analysis(L_Func *fn, int mode)
{
  int dom_mode;

#ifdef PRINT_FLOW_ANALYSIS_CALLS
  fprintf(stderr,"L_do_flow_analysis...");
#endif

  dom_mode = mode & (DOMINATOR | POST_DOMINATOR | 
		     DOMINATOR_CB | POST_DOMINATOR_CB |
		     DOMINATOR_INT | POST_DOMINATOR_INT);
  if (dom_mode)
    L_dominator_analysis(fn, mode);

  mode = mode & ~dom_mode;

  if(!mode)
    return;

  if(mode == LIVE_VARIABLE)
    {
      /*
      PDF_new_dataflow_live_variable(fn);
      */
      L_start_time(&L_module_global_dataflow_time);

      D_setup_dataflow(fn, PF_STD_OPERANDS); 
      D_dataflow_analysis(PF_default_flow, mode);

      L_stop_time(&L_module_global_dataflow_time);
    }
  else
    {
      /* initialize dataflow library structures */
      /* Current dataflow operates in a predicate-aware manner on registers
       * and macros, but does not support analysis on predicate registers
       * themselves
       */
      D_setup_dataflow(fn, PF_STD_OPERANDS); 
      D_dataflow_analysis(PF_default_flow, mode);  
    }
}

void L_update_flow_analysis(L_Func *fn, int mode)
{
  if(!D_dataflow_valid())
    L_do_flow_analysis(fn, mode);
}

void L_invalidate_dataflow(void)
{
  D_invalidate_dataflow();
}

void L_do_sched_flow_analysis(L_Func *fn, int mode)
{
  L_do_pred_flow_analysis(fn, mode);
}

void L_do_pred_flow_analysis(L_Func *fn, int mode)
{
  int dom_mode;

  dom_mode = mode & (DOMINATOR | POST_DOMINATOR | 
		     DOMINATOR_CB | POST_DOMINATOR_CB |
		     DOMINATOR_INT | POST_DOMINATOR_INT);
  if (dom_mode)
    L_dominator_analysis(fn, mode);

  mode = mode & ~dom_mode;

  if(!mode)
    return;

  /* initialize dataflow library structures */
  /* Current dataflow operates in a predicate-aware manner on registers
   * and macros, but does not support analysis on predicate registers
   * themselves
   */
  D_setup_dataflow(fn, PF_ALL_OPERANDS); 
 
  D_dataflow_analysis(PF_default_flow, mode);  
  
}

void L_dataflow_analysis(int mode)
{
  int dom_mode;

  dom_mode = mode & (DOMINATOR | POST_DOMINATOR | 
		     DOMINATOR_CB | POST_DOMINATOR_CB |
		     DOMINATOR_INT | POST_DOMINATOR_INT);
  if (dom_mode)
    L_dominator_analysis(L_fn, mode);

  mode = mode & ~dom_mode;

  if(!mode)
    return;

  mode = mode & ~dom_mode;

  D_dataflow_analysis(PF_default_flow, mode);
}

void L_setup_dataflow(L_Func *fn)
{
  D_setup_dataflow(fn, PF_STD_OPERANDS);
}

void L_setup_dataflow_no_operands(L_Func *fn)
{
  D_setup_dataflow(fn, PF_NO_OPERANDS);
}

void L_delete_dataflow(L_Func *fn)
{
  D_delete_dataflow(fn);
}

void L_add_src_operand_reg(L_Oper *oper, int reg, 
			   int transparent, int unconditional)
{
  D_add_src_operand(PF_default_flow, oper, reg, transparent, unconditional);
}

void L_add_dest_operand_reg(L_Oper *oper, int reg, 
			   int transparent, int unconditional)
{
  D_add_dest_operand(PF_default_flow, oper, reg, transparent, unconditional);
}

void L_partial_dead_code_removal(L_Func *fn)
{
  if (!L_EXTRACT_BIT_VAL(fn->flags, L_FUNC_HYPERBLOCK))
    return;

  if(PF_default_flow != PF_pred_flow)
    return;

  PF_partial_dead_code_removal(PF_default_flow);
}

/*========================================================================
 *
 * Live Variable Analysis Information
 *
 *========================================================================*/

int L_in_cb_IN_set(L_Cb *cb, L_Operand *operand)
{
  if (operand==NULL)
    return 0;
  return D_in_cb_IN_set(PF_default_flow, cb, L_REG_MAC_INDEX(operand));
}

int L_in_cb_OUT_set(L_Cb *cb, L_Operand *operand)
{
  if (operand==NULL)
    return 0;
  return D_in_cb_OUT_set(PF_default_flow, cb, L_REG_MAC_INDEX(operand));
}

int L_in_cb_IN_set_reg(L_Cb *cb, int reg)
{
  return D_in_cb_IN_set(PF_default_flow, cb, reg);
}

int L_in_cb_OUT_set_reg(L_Cb *cb, int reg)
{
  return D_in_cb_OUT_set(PF_default_flow, cb, reg);
}

Set L_get_cb_IN_set(L_Cb *cb)
{
  return (D_get_cb_IN_set(PF_default_flow, cb));
}

Set L_get_cb_OUT_set(L_Cb *cb)
{
  return (D_get_cb_OUT_set(PF_default_flow, cb));
}

int L_in_oper_IN_set(L_Oper *oper, L_Operand *operand)
{
  if (operand==NULL)
    return 0;
  return D_in_oper_IN_set(PF_default_flow, oper, L_REG_MAC_INDEX(operand));
}

int L_in_oper_OUT_set(L_Cb *cb, L_Oper *oper, L_Operand *operand, int path)
{
  if (operand==NULL)
    return 0;
  return D_in_oper_OUT_set(PF_default_flow, cb, oper, L_REG_MAC_INDEX(operand), path);
}

int L_in_oper_IN_set_reg(L_Oper *oper, int reg)
{
  return (D_in_oper_IN_set(PF_default_flow, oper, reg));
}

int L_in_oper_OUT_set_reg(L_Cb *cb, L_Oper *oper, int reg, int path)
{
  return (D_in_oper_OUT_set(PF_default_flow, cb, oper, reg, path));
}

Set L_get_oper_IN_set(L_Oper *oper)
{
  return (D_get_oper_IN_set(PF_default_flow, oper));
}

Set L_get_oper_OUT_set(L_Cb *cb, L_Oper *oper, int path)
{
  return (D_get_oper_OUT_set(PF_default_flow, cb, oper, path));
}




/*========================================================================
 *
 * Reaching Definition Analysis Information
 *
 *========================================================================*/

Set L_get_oper_RIN_set(L_Oper *oper)
{
  return (D_get_oper_RIN_set(PF_default_flow, oper));
}

Set L_get_oper_ROUT_set(L_Oper *oper)
{
  return (D_get_oper_ROUT_set(PF_default_flow, oper));
}

int L_in_oper_RIN_set(L_Oper *oper, L_Oper *reaching_oper, L_Operand *operand)
{
  if (operand==NULL)
    return 0;
  return D_in_oper_RIN_set(PF_default_flow, oper, reaching_oper,
			   L_REG_MAC_INDEX(operand));
}

int L_in_oper_RIN_set_reg(L_Oper *oper, L_Oper *reaching_oper, int reg)
{
  return D_in_oper_RIN_set(PF_default_flow, oper, reaching_oper, reg);
}

int L_in_oper_ROUT_set(L_Oper *oper, L_Oper *reaching_oper, L_Operand *operand,
                int path)
{
  if (operand==NULL)
    return 0;
  return D_in_oper_ROUT_set(PF_default_flow, oper, reaching_oper,
			    L_REG_MAC_INDEX(operand), path);
}

Set L_get_cb_RIN_set(L_Cb *cb)
{
  return (L_get_oper_RIN_set(cb->first_op));
}

int L_in_cb_RIN_set(L_Cb *cb, L_Oper *reaching_oper, L_Operand *operand)
{
  return (L_in_oper_RIN_set(cb->first_op, reaching_oper, operand));
}

/* Warning this creates a set, caller must free it */
Set L_get_cb_RIN_defining_opers(L_Cb *cb, L_Operand *operand)
{
  return D_get_oper_RIN_defining_opers(PF_default_flow, cb->first_op, 
				       L_REG_MAC_INDEX(operand));
}

/* Warning this creates a set, caller must free it */
Set L_get_oper_RIN_defining_opers(L_Oper *oper, L_Operand *operand)
{
  return D_get_oper_RIN_defining_opers(PF_default_flow, oper, 
				       L_REG_MAC_INDEX(operand));
}



/*========================================================================
 *
 * Available Definition Analysis Information
 *
 *========================================================================*/

Set L_get_oper_AIN_set(L_Oper *oper)
{
  return (D_get_oper_AIN_set(PF_default_flow, oper));
}

Set L_get_oper_AOUT_set(L_Oper *oper)
{
  return (D_get_oper_AOUT_set(PF_default_flow, oper));
}

int L_in_oper_AIN_set(L_Oper *oper, L_Oper *reaching_oper, L_Operand *operand)
{
  if (operand==NULL)
    return 0;
  return D_in_oper_AIN_set(PF_default_flow, oper, reaching_oper,
			   L_REG_MAC_INDEX(operand));
}

int L_in_oper_AOUT_set(L_Oper *oper, L_Oper *reaching_oper, L_Operand *operand,
		int path)
{
  if (operand==NULL)
    return 0;
  return D_in_oper_AOUT_set(PF_default_flow, oper, reaching_oper,
			    L_REG_MAC_INDEX(operand), path);
}

int L_in_cb_AIN_set(L_Cb *cb, L_Oper *reaching_oper, L_Operand *operand)
{
  return (L_in_oper_AIN_set(cb->first_op, reaching_oper, operand));
}

Set L_get_cb_AIN_set(L_Cb *cb)
{
  return (L_get_oper_AIN_set(cb->first_op));
}

/* Warning this creates a set, caller must free it */
Set L_get_cb_AIN_defining_opers(L_Cb *cb, L_Operand *operand)
{
  return D_get_oper_AIN_defining_opers(PF_default_flow, cb->first_op, 
				       L_REG_MAC_INDEX(operand));
}




/*========================================================================
 *
 * Available Expression Analysis Information
 *
 *========================================================================*/

Set L_get_oper_EIN_set(L_Oper *oper)
{
  return (D_get_oper_EIN_set(PF_default_flow, oper));
}

Set L_get_oper_EOUT_set(L_Oper *oper)
{
  return (D_get_oper_EOUT_set(PF_default_flow, oper));
}


int L_in_oper_EIN_set(L_Oper *oper, L_Oper *reaching_oper)
{
  if (reaching_oper==NULL)
    return NULL;
  return (D_in_oper_EIN_set(PF_default_flow, oper, reaching_oper));
}

int L_in_oper_EOUT_set(L_Oper *oper, L_Oper *reaching_oper)
{
  if (reaching_oper==NULL)
    return NULL;
  return (D_in_oper_EOUT_set(PF_default_flow, oper, reaching_oper));
}

int L_in_cb_EIN_set(L_Cb *cb, L_Oper *reaching_oper)
{
  return (L_in_oper_EIN_set(cb->first_op, reaching_oper));
}

Set L_get_cb_EIN_set(L_Cb *cb)
{
  return (L_get_oper_EIN_set(cb->first_op));
}

void L_remove_from_oper_EIN_set(L_Oper *oper, L_Oper *reaching_oper)
{
  D_remove_from_oper_EIN_set(PF_default_flow, oper, reaching_oper);
}

void L_remove_from_all_EIN_set(L_Oper *reaching_oper)
{
  L_Cb *cb;
  L_Oper *oper;

  for (cb = L_fn->first_cb; cb; cb = cb->next_cb) 
    {
      /* Don't update global EIN information for operations in */
      /* exit boundary cbs.  :)				 */
      if ( L_EXTRACT_BIT_VAL(cb->flags,L_CB_EXIT_BOUNDARY) )
	continue;
      for(oper = cb->first_op; oper; oper = oper->next_op)
	L_remove_from_oper_EIN_set(oper, reaching_oper);
    }
}



/*
 *	The INDEX macros should be setup up to return unique id's for any
 *	operands you perform dataflow analysis on which may have overlapping
 *	values.  In the current implementation, dataflow is performed for
 *	registers and macros, each of which are numbered from 1..k, therefore
 *	the numbers are shifted left by 1 and the LSB is used to distinguish.
 *	If more types of operands are required to be analyzed by dataflow
 *	analysis, serveral of the lower bits should be used to distinguish
 *	among overlapping numbers.
 */

Set L_map_reg_set(Set in)
{
    int size, i, *buf;
    Set out=NULL;

    size = Set_size(in);
    if (size==0)
        return (NULL);
  
    buf = (int *) malloc(sizeof(int)*size);
    for (i=0; i<size; i++) {
        out = Set_add(out, L_REG_INDEX(buf[i]));
    }
    free(buf);

    return (out);
}

Set L_map_macro_set(Set in)
{
    int i, *buf, size;
    Set out=NULL;

    size = Set_size(in);
    if (size==0)
	return (NULL);

    buf = (int *) malloc(sizeof(int)*size);
    for (i=0; i<size; i++) {
	out = Set_add(out, L_MAC_INDEX(buf[i]));
    }
    free(buf);

    return (out);
}

/* Extract registers from in, return set of actual registers numbers */
Set L_unmap_reg_set(Set in)
{
    int i, *buf, size;
    Set out=NULL;

    size = Set_size(in);
    if (size==0)
	return (NULL);
    buf = (int *) malloc(sizeof(int)*size);
    Set_2array(in, buf);
    for (i=0; i<size; i++) {
	if (L_IS_MAPPED_REG(buf[i]))
	    out = Set_add(out, L_UNMAP_REG(buf[i]));
    }
    free(buf);

    return (out);
}

/* Extract macros from in, return set of actual macro numbers */
Set L_unmap_macro_set(Set in)
{
    int i, *buf, size;
    Set out=NULL;

    size = Set_size(in);
    if (size==0)
        return (NULL);
    buf = (int *) malloc(sizeof(int)*size);
    Set_2array(in, buf);
    for (i=0; i<size; i++) {
        if (L_IS_MAPPED_MAC(buf[i]))
            out = Set_add(out, L_UNMAP_MAC(buf[i]));
    }
    free(buf);

    return (out);
}

/* Extract fragile macros from in, return set of actual macro numbers */
Set L_unmap_fragile_macro_set(Set in)
{
    int i, *buf, size;
    Set out=NULL;

    size = Set_size(in);
    if (size==0)
        return (NULL);
    buf = (int *) malloc(sizeof(int)*size);
    Set_2array(in, buf);
    for (i=0; i<size; i++) {
        if (L_IS_MAPPED_MAC(buf[i]) && M_fragile_macro(buf[i]))
            out = Set_add(out, L_UNMAP_MAC(buf[i]));
    }
    free(buf);

    return (out);
}


void L_unmap_rdid(int rdid, int *oper_id, int *operand_id)
{
  D_unmap_rdid(PF_default_flow, rdid,oper_id, operand_id);
}

