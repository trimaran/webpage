/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File :          l_callgraph.c
 *      Description :   Routines to manipulate the callgraph structures.
 *      Original : Brian Deitrich, Wen-mei Hwu 1997 (adapted from Roger 
 *                 Bringmann's work)
 *
\*****************************************************************************/

#include <Lcode/l_main.h>

char *input_filename;
int total_arcs = 0;
int total_nodes = 0;
FILE *GRAPH_OUT;

/******************************************************************************\
 *
 * Call graph arcs
 *
\******************************************************************************/

L_CG_Arc *L_CG_copy_arc (L_CG_Arc *arc)
{
   L_CG_Arc *copy_arc;

   copy_arc = (L_CG_Arc *) L_alloc (L_alloc_l_cg_arc);
   copy_arc->id = total_arcs++;
   copy_arc->flags = arc->flags;
   copy_arc->jsr_id = arc->jsr_id;
   copy_arc->type = arc->type;
   copy_arc->weight = arc->weight;
   copy_arc->src_node = arc->src_node;
   copy_arc->prev_dst_arc = arc->prev_dst_arc;
   copy_arc->next_dst_arc = arc->next_dst_arc;
   copy_arc->dst_node = arc->dst_node;
   copy_arc->prev_src_arc = arc->prev_src_arc;
   copy_arc->next_src_arc = arc->next_src_arc;
   copy_arc->ext = NULL;

   return (copy_arc);
}

void L_CG_delete_only_arc (L_CG_Arc *arc)
{
   L_free (L_alloc_l_cg_arc, arc);
}

void L_CG_delete_arc (L_CG_Arc *arc)
{
   L_CG_Node *node;

   if (!arc) return;

   /* Remove the link from the src node */
   node = arc->src_node;
   if (node->first_dst_arc == arc)
      node->first_dst_arc = arc->next_dst_arc;
   if (node->last_dst_arc == arc)
      node->last_dst_arc = arc->prev_dst_arc;
   if (arc->prev_dst_arc)
      arc->prev_dst_arc->next_dst_arc = arc->next_dst_arc;
   if (arc->next_dst_arc)
      arc->next_dst_arc->prev_dst_arc = arc->prev_dst_arc;

   /* Remove the link to the dst node */
   node = arc->dst_node;
   if (node->first_src_arc == arc)
      node->first_src_arc = arc->next_src_arc;
   if (node->last_src_arc == arc)
      node->last_src_arc = arc->prev_src_arc;
   if (arc->prev_src_arc)
      arc->prev_src_arc->next_src_arc = arc->next_src_arc;
   if (arc->next_src_arc)
      arc->next_src_arc->prev_src_arc = arc->prev_src_arc;

   L_CG_delete_only_arc (arc);
}

void L_CG_delete_all_dst_arcs (L_CG_Arc *first_dst_arc)
{
   L_CG_Arc *arc, *next_dst_arc;

   for (arc = first_dst_arc; arc != NULL; arc = next_dst_arc) {
      next_dst_arc = arc->next_dst_arc;
      L_CG_delete_arc(arc);
   }
}

void L_CG_delete_all_src_arcs (L_CG_Arc *first_src_arc)
{
   L_CG_Arc *arc, *next_src_arc;

   for (arc = first_src_arc; arc != NULL; arc = next_src_arc) {
      next_src_arc = arc->next_src_arc;
      L_CG_delete_arc(arc);
   }
}

void L_CG_remove_arc_from_src_and_dst (L_CG_Arc *arc)
{
   /* remove this arc from the dst arc list of src_node. */
   if (arc->src_node->first_dst_arc == arc->src_node->last_dst_arc) {
      arc->src_node->first_dst_arc = NULL;
      arc->src_node->last_dst_arc = NULL;
   }
   else if (arc->src_node->last_dst_arc == arc) {
      arc->src_node->last_dst_arc = arc->prev_dst_arc;
      arc->prev_dst_arc->next_dst_arc = NULL;
   }
   else if (arc->src_node->first_dst_arc == arc) {
      arc->src_node->first_dst_arc = arc->next_dst_arc;
      arc->next_dst_arc->prev_dst_arc = NULL;
   }
   else {
      arc->prev_dst_arc->next_dst_arc = arc->next_dst_arc;
      arc->next_dst_arc->prev_dst_arc = arc->prev_dst_arc;
   }

   /* remove this arc from the src arc list of dst_node. */
   if (arc->dst_node->first_src_arc == arc->dst_node->last_src_arc) {
      arc->dst_node->first_src_arc = NULL;
      arc->dst_node->last_src_arc = NULL;
   }
   else if (arc->dst_node->last_src_arc == arc) {
      arc->dst_node->last_src_arc = arc->prev_src_arc;
      arc->prev_src_arc->next_src_arc = NULL;
   }
   else if (arc->dst_node->first_src_arc == arc) {
      arc->dst_node->first_src_arc = arc->next_src_arc;
      arc->next_src_arc->prev_src_arc = NULL;
   }
   else {
      arc->prev_src_arc->next_src_arc = arc->next_src_arc;
      arc->next_src_arc->prev_src_arc = arc->prev_src_arc;
   }
}

void L_CG_add_arc (L_CG_Node *src_node, L_Oper *oper, L_Operand *operand,
                   L_CallGraph *callgraph)
{
   L_Attr *attr;

   if (L_is_label (operand)) {
      L_CG_Node *dst_node = L_CG_find_node (operand->value.l, callgraph);
      L_CG_Arc *arc = (L_CG_Arc *) L_alloc (L_alloc_l_cg_arc);

      arc->id = total_arcs++;
      arc->flags = 0;
      arc->jsr_id = oper->id;
      if (!(attr = L_find_attr (oper->attr, "CALLNAME")))
         arc->type = NORMAL_JSR;
      else if (attr->max_field == 1)
         arc->type = RESOLVED_IND_JSR;
      else
         arc->type = UNRESOLVED_IND_JSR;
      arc->weight = oper->weight;

      /* Append the arc to the end of the chain of dst arcs for this src node */
      arc->src_node = src_node;

      arc->next_dst_arc = NULL;
      if (!src_node->first_dst_arc) {
         src_node->first_dst_arc = arc;
      }

      if (src_node->last_dst_arc) {
         arc->prev_dst_arc = src_node->last_dst_arc;
         src_node->last_dst_arc->next_dst_arc = arc;
      }
      else {
          arc->prev_dst_arc = NULL;
      }
      src_node->last_dst_arc = arc;

      /* Append the arc to the end of the chain of src arcs for this dst node */
      arc->dst_node = dst_node;
      arc->next_src_arc = NULL;

      if (!dst_node->first_src_arc)
         dst_node->first_src_arc = arc;

      if (dst_node->last_src_arc) {
         arc->prev_src_arc = dst_node->last_src_arc;
         dst_node->last_src_arc->next_src_arc = arc;
      }
      else {
          arc->prev_src_arc = NULL;
      }
      dst_node->last_src_arc = arc;

      arc->ext = NULL;
   }
   else if (L_is_register(operand) &&
            (attr = L_find_attr (oper->attr, "CALLNAME"))) {
   /* Handle case of an indirect jsr, where the CALLNAME attribute is present.
    * If no attribute is present, don't add any arcs. */
      L_Operand temp_operand;
      int num_targets, i, j, attr_name_length, temp_index;
      char temp_str[4096], temp_name[4096];

      num_targets = attr->max_field;
      if (num_targets == 0)
         L_punt ("INLINER's callgraph made an invalid assumption!");

      for (i = 0; i < num_targets; i++) {
         L_assign_type_label (&temp_operand);
   
         /* cluge fix to account for extra pair of "" in the name. */
         attr_name_length = strlen (attr->field[i]->value.l) + 1;
         temp_index = 0;
         for (j = 0; j < attr_name_length; j++)
            if (attr->field[i]->value.l[j] != '\"')
               temp_name[temp_index++] = attr->field[i]->value.l[j];

         strcpy (temp_str, "_\0");
         strcat (temp_str, temp_name);
         temp_operand.value.l = (char *) Lcode_malloc (strlen (temp_str) + 1);
         strcpy (temp_operand.value.l, temp_str);

         L_CG_add_arc (src_node, oper, &temp_operand, callgraph);
         Lcode_free (temp_operand.value.l);
      }
   }
}

void L_CG_print_arc (L_CG_Arc *arc)
{
   printf ("---------- ARC ----------\n");
   printf ("   id = %d\n", arc->id);
   printf ("   jsr_id = %d\n", arc->jsr_id);
   printf ("   weight = %lf\n", arc->weight);
   printf ("   src node = %s [%d]\n", arc->src_node->func_name,
                                      arc->src_node->id);
   printf ("   dst node = %s [%d]\n", arc->dst_node->func_name,
                                      arc->dst_node->id);
}

/******************************************************************************\
 *
 * Call graph nodes
 *
\******************************************************************************/

L_CG_Node *L_CG_new_node(char *name)
{
   L_CG_Node *node;

   node = (L_CG_Node *) L_alloc (L_alloc_l_cg_node);

   node->id = total_nodes++;
   node->func_name = name;
   if (L_fn && !strcmp (L_fn->name, name)) {
      node->filename = (char *) Lcode_malloc (strlen (input_filename) + 1);
      strcpy (node->filename, input_filename);
   }
   else
      node->filename = NULL;
   node->func_file_num = 0;
   node->fn = NULL;

   node->first_src_arc = NULL;
   node->last_src_arc = NULL;

   node->first_dst_arc = NULL;
   node->last_dst_arc = NULL;

   node->prev_node = NULL;
   node->next_node = NULL;

   node->dfs = NULL;
   node->ext = NULL;

   return node;
}

void L_CG_add_node(L_CG_Node *node, L_CallGraph *callgraph)
{
   if (callgraph->last_node) {
      callgraph->last_node->next_node = node;
      node->prev_node = callgraph->last_node;
      callgraph->last_node = node;
   }
   else {
      callgraph->first_node = node;
      callgraph->last_node = node;
   }
}

void L_CG_delete_node(L_CG_Node *node)
{
   if (node->fn) {
      L_fn = node->fn;
      L_delete_func(node->fn);
   }
   if (node->filename)
      Lcode_free (node->filename);
   L_CG_delete_all_src_arcs(node->first_src_arc);
   L_CG_delete_all_dst_arcs(node->first_dst_arc);
   if (node->dfs)
      L_free (L_alloc_cg_dfs_info, node->dfs);

   L_free (L_alloc_l_cg_node, node);
}

L_CG_Node *L_CG_find_node(char *fn_name, L_CallGraph *callgraph)
{
   L_CG_Node *node;
   char *name;

   name = M_fn_name_from_label(fn_name);

   /* Determine if the func exists in the list */
   for (node = callgraph->first_node; node != NULL; node = node->next_node) {
      if (!strcmp (node->func_name, name)) {
         if (!node->filename && L_fn && !strcmp(L_fn->name, name)) {
            node->filename = (char *) Lcode_malloc (strlen(input_filename) + 1);
            strcpy (node->filename, input_filename);
         }

         return node;
      }
   }

   /*
    * Since the func does not exist in the list, we will create an entry
    * for it.
    */
   node = L_CG_new_node(name);
   L_CG_add_node(node, callgraph);

   return node;
}

void L_CG_print_node (L_CG_Node *node)
{
   printf ("*********** NODE ************\n");
   printf ("   id = %d\n", node->id);
   printf ("   func_name = %s\n", node->func_name);
   printf ("   filename = %s\n", node->filename);
   printf ("   func_file_num = %d\n", node->func_file_num);
}

L_Func *L_read_node_func (L_CG_Node *node)
{
   int count = 0;
   L_Func *func = NULL;

   if (!node || !node->filename)
      return (NULL);

   if (node->fn) {
      L_fn = node->fn;
      return (node->fn);
   }

   L_open_input_file (node->filename);
   while (L_get_input() != L_INPUT_EOF) {
      if (L_token_type == L_INPUT_FUNCTION) {
         if (++count == node->func_file_num) {
            if (strcmp (node->func_name, M_fn_name_from_label (L_fn->name)))
               L_punt ("ERROR: L_read_node_func could not find the correct \
func.\n");
            func = L_fn;
         }
         else
            L_delete_func (L_fn);
      }
      else
         L_delete_data (L_data);
   }
   L_close_input_file (node->filename);

   L_fn = func;
   node->fn = func;
   return (func);
}

void L_delete_node_func (L_CG_Node *node)
{
   if (!node->fn) return;

   L_fn = node->fn;
   L_delete_func (node->fn);
   L_fn = NULL;
   node->fn = NULL;
}

/******************************************************************************\
 *
 * L_CallGraph support routines
 *
\******************************************************************************/

L_CallGraph *L_CG_new_callgraph (void)
{
   L_CallGraph *callgraph;

   callgraph = (L_CallGraph *) Lcode_malloc (sizeof (L_CallGraph));
   callgraph->first_node = NULL;
   callgraph->last_node = NULL;

   return callgraph;
}

void L_CG_callgraph_delete (L_CallGraph *callgraph)
{
   L_CG_Node *node, *next_node;

   if (!callgraph) return;

   for (node = callgraph->first_node; node != NULL; node = next_node) {
      next_node = node->next_node;
      L_CG_delete_node(node);
   }

   Lcode_free (callgraph);
   callgraph = NULL;
}

L_CallGraph *L_CG_callgraph_build (FILE *file_list,
                                   void (*user_init_func)(L_CG_Node *))
{
   L_Cb *cb;
   L_Oper *oper;
   L_CG_Node *node;
   char buf[256];
   L_CallGraph *callgraph;
   int input_func_num;

   callgraph = L_CG_new_callgraph ();

   /* Process all data and functions within a file */
   while (fgets(buf, sizeof(buf), file_list) != NULL) {
      buf[strlen(buf)-1] = NULL;
      L_open_input_file(buf);
      input_func_num = 0;

      input_filename = buf;

      while (L_get_input() != L_INPUT_EOF) {
         if (L_token_type==L_INPUT_FUNCTION) {
            input_func_num++;
            node = L_CG_find_node (L_fn->name, callgraph);
            node->fn = L_fn;
            node->func_file_num = input_func_num;
            L_compute_oper_weight(L_fn, 0, 1);

            for (cb = L_fn->first_cb; cb != NULL; cb = cb->next_cb) {
               for (oper = cb->first_op; oper != NULL; oper = oper->next_op) {
                  if (L_subroutine_call_opcode(oper))
                     L_CG_add_arc(node, oper, oper->src[0], callgraph);
               }
            }

            user_init_func (node);

            L_delete_func (node->fn);
            node->fn = NULL;
         }
         else
            L_delete_data(L_data);
      }

      L_close_input_file(buf);
   }

   /* Print callgraph to file for graphical interface */
   if (L_print_davinci_callgraph)
      L_CG_print_davinci_callgraph (callgraph);

   return callgraph;
}

void L_CG_print_callgraph (L_CallGraph *callgraph)
{
   L_CG_Node *node;
   L_CG_Arc *arc;

   printf ("FOLLOWING IS PRINT OUT OF CALLGRAPH\n");
   for (node = callgraph->first_node; node; node = node->next_node) {
      L_CG_print_node (node);
      printf("source arcs:\n");
      for (arc = node->first_dst_arc; arc; arc = arc->next_dst_arc)
         L_CG_print_arc (arc);
      printf("dest arcs:\n");
      for (arc = node->first_src_arc; arc; arc = arc->next_src_arc)
         L_CG_print_arc (arc);
   }
}

void L_CG_davinci_visit(L_CG_Node *node)
{
   L_CG_Arc *arc;

   /* Define Node */
   if (node->dfs->color == BLACK) {
      fprintf (GRAPH_OUT, "r(\"FN %d\")", node->id);
      return;
   }
   node->dfs->color = BLACK;

   fprintf (GRAPH_OUT, "l(\"FN %d\",", node->id);

   if (!strncmp (node->func_name, "_$fn", 4))
      fprintf (GRAPH_OUT, "n(\"anything\", [a(\"OBJECT\", \"FN %s\")],",
               (node->func_name)+4);
   else
      fprintf (GRAPH_OUT, "n(\"anything\", [a(\"OBJECT\", \"FN %s\")],",
               node->func_name);

   fprintf (GRAPH_OUT, "[");

   /* Print destination arcs */
   for (arc = node->first_dst_arc; arc; arc = arc->next_dst_arc) {
      fprintf (GRAPH_OUT, "e(\"anything\",[a(\"OBJECT\", \"%d\")],",
               arc->id, arc->weight);

      L_CG_davinci_visit (arc->dst_node);
      fprintf (GRAPH_OUT, ")");

      if (arc->next_dst_arc)
         fprintf (GRAPH_OUT, ",");
   }
   fprintf (GRAPH_OUT, "]))\n");
}

void L_CG_print_davinci_callgraph (L_CallGraph *callgraph)
{
   L_CG_Node *node;

   /* Check if file exists on server */
   if ((GRAPH_OUT = fopen (L_davinci_callgraph_file, "w")) == NULL)  {
      fprintf(stderr, "L_CG_print_davinci_callgraph: can not open %s for \
writing\n", L_davinci_callgraph_file );
      exit(1);
   }

  /* daVinci_print_header */
  fprintf (GRAPH_OUT, "[\n");

  /* Clear the visited bit flag */
  for (node = callgraph->first_node; node; node = node->next_node) {
     node->dfs = (L_DFS_Info *) L_alloc (L_alloc_cg_dfs_info);
     node->dfs->color = WHITE;
  }

  /* need to start with the top node */
  for (node = callgraph->first_node; node; node = node->next_node) {
     if (!strcmp (node->func_name, "_main"))
        break;
  }

  if (node==NULL)
     L_punt ("L_CG_print_davinci_callgraph: cannot find _main node");

  L_CG_davinci_visit (node);

  /* daVinci_print_footer */
  fprintf (GRAPH_OUT, "]\n");

  fclose (GRAPH_OUT);
}
