/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.32  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 28, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright 1999 IMPACT Technologies, Inc; Champaign, Illinois
 * For commercial license rights, contact: Marketing Office via
 * electronic mail: marketing@impactinc.com
 *
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   split.c
 *      Author: Ben-Chung Cheng, Wen-mei Hwu
\*****************************************************************************/


#include <stdio.h>
#include <library/c_basic.h>
#include <library/l_parms.h>
#include <library/list.h>
#include <Pcode/pcode.h>
#include <Pcode/struct.h>
#include <Pcode/symtree.h>
#include <Pcode/gen_pcode.h>
#include <Pcode/gen_hcode.h>
#include <Pcode/parms.h>
#include <Pcode/read_pcode.h>
#include <Pcode/cf_contr-flow.h>
#include <library/dynamic_symbol.h>

#define MAX_FILES               2000
#define MAX_VAR                 8000
#define MAX_STRUCTURE           8000

/* BCC - parms for Psplit - 10/22/96 */
char *sp_output_dir_string;
char *sp_input_spec;
char *sp_output_spec; 
/* ITI(JCG) -2/10/99 */
char *sp_layout_info_desc="(none)";
int group_global_vars;

/* BCC - for new Pcode module - 5/8/96 */
int num_struct = 0;
int num_union = 0;
int num_enum = 0;
int num_gvar = 0;
int num_func = 0;
int num_total_func_call = 0;
int num_expandable_func = 0;
STRING_Symbol_Table *struct_union_tbl, *dummy_struct_union_tbl;

int layout_file_generated = 0;

int dep_pragmas_generated;

typedef enum st_un_type {
    struct_type,
    union_type
} st_un_type;

/* 
 * BCC - generating an extra file where the file names inside the mapping file
 *	 is .pcp for profiling information.	12/14/95
 */
static FILE *Fmapping, *Fdata, *Fstruct, *Fextern, *Ffile, *Fdata_per_file;

static struct {
    char *file_name;
    int file_id;
} files[MAX_FILES];

static struct {
    char *name;
    int modified;
    VarDcl var;
    int printed;
} var_list[MAX_VAR];

static struct {
    char *name;
    st_un_type type;
    Void *ptr;
} st_list[MAX_STRUCTURE];

static int var_list_len = 0;
static int st_list_len = 0;
static int fc = 0;
static char *active_file = 0;           /* the file being processed */
static int active_file_id = 0;          /* the file_id */
static char *active_fn = 0;             /* the function now being processed */
static int sp_output_form;
static VarDcl f2c_generated;

static char *base_type_name[6]={"char",
				"short",
				"int",
				"long",
				"float",
				"double"};
static PrintGlobal()
{
    int i;

    for (i=0; i < var_list_len; i++) {
	VarDcl var;
	Type type;
	Init init;
	int class;

	var = var_list[i].var;
	type = var->type;
	/*
	 *      print the DATA copy.
	 */
	if (!(type->type & TY_EXTERN) && group_global_vars) {
	    switch (sp_output_form) {
		case OUTPUT_PCODE:
		    Gen_PCODE_Var(Fdata, var);
		    break;
		case OUTPUT_HCODE:
		    Gen_HCODE_Var(Fdata, var);
		    break;
	    }
	};
	/*
	 *      print the EXTERN copy.
	 */
	/* don't insert this var to extern.xxx because it will influence other
	   files which are not generated by f2c */
	if (!strcmp(var->name, "IMPACT_F2C_GENERATED")) continue;
	init = var->init;
	var->init = 0;          /* do not print the init section */
	class = (type->type & (TY_STATIC|TY_EXTERN));
	type->type &= ~class;
	type->type |= TY_EXTERN;
	switch (sp_output_form) {
	    case OUTPUT_PCODE:
		Gen_PCODE_Var(Fextern, var);
		break;
	    case OUTPUT_HCODE:
		Gen_HCODE_Var(Fextern, var);
	    /* BCC - only print function which returns a pointer - 5/2/96 */
	    case OUTPUT_NONE:
		if ((var->type->type & TY_EXTERN) && IsFunctionType(var->type)){
		    Dcltr dcltr;
		    dcltr = var->type->dcltr;
		    while (dcltr->next) dcltr = dcltr->next;
		    /* BCC - need prototypes for TY_VOID - 11/2/96 */
		    if ( (var->type->type & TY_VOID) ||
			 (dcltr->method == D_PTR) ||
			 (dcltr->method == D_ARRY && dcltr->index == 0) ||
			 (dcltr->method == D_ARRY && 
			  dcltr->index->value.scalar == 1)) {
			Gen_PCODE_Var(Fextern, var);
		    }
		}
		break;
	}
	type->type &= ~TY_EXTERN;
	type->type |= class;
	var->init = init;
    }
}

static AddVarDcl(var, replace)
VarDcl var;
int replace;
{
    int i;
    VarDcl temp;

    if (!strcmp(var->name, "IMPACT_F2C_GENERATED")) {
	f2c_generated = SP_CopyVarDcl(var);
	f2c_generated->type->type |= TY_EXTERN;
    };
    for (i = 0; i < var_list_len; i++) {
	if (!strcmp(var_list[i].name, var->name)) {
	    if ((var->type->type & TY_EXTERN) && (replace == 0)) return;	
	    /* new one is not an extern , replace the old one */
	    else {
		temp = var_list[i].var;
		var_list[i].var = SP_CopyVarDcl(var);
		RemoveVarDcl(temp);
		var_list[i].modified = 1;
		if (group_global_vars == 0 &&
		    (var->type->type & TY_EXTERN) == 0 &&
		    var_list[i].printed == 0) {
		    Gen_PCODE_Var(Fdata_per_file, var);
		    var_list[i].printed == 1;
		}
		return;
	    }
	}
    }

    if (i == MAX_VAR) Punt("too many global declarations");
    var_list[i].name = C_findstr(var->name);
    var_list[i].var = SP_CopyVarDcl(var); 
    var_list[i].modified = 1;
    if (group_global_vars == 0 &&
	(var->type->type & TY_EXTERN) == 0 &&
	var_list[i].printed == 0) {
	Gen_PCODE_Var(Fdata_per_file, var);
	var_list[i].printed == 1;
    }
    var_list_len++;
}
		
static AddStructUnionDcl(ptr, type)
void *ptr;
st_un_type type;
{
    int i;

    if (st_list_len==MAX_STRUCTURE) Punt("too many struct/union declarations");

    /* BCC - 9/11/96 */
    for (i=0; i < st_list_len; i++) {
      if (st_list[i].ptr == ptr) {
	st_list[i].ptr = 0;
	st_list[i].type = 0;
      }
    }

    st_list[st_list_len].type = type;
    st_list[st_list_len++].ptr = ptr;
}

/*-------------------------------------------------------------*/
static PropogateToTypes(type)
Type type;
{
    int i;

    if (type->type==0) {
	Punt("ILLEGAL TYPE SPECIFICATION: NULL");
	return 0;
    }
    if (type->type & TY_STRUCTURE) {
	for (i=0; i<max_struct_union_pool; i++) {
	    if ( (!strcmp(type->struct_name, StructUnion_Pool[i].name) &&
	           strcmp(type->struct_name, StructUnion_Pool[i].new_name) 
		 ) ||
		 ( !strncmp(type->struct_name, StructUnion_Pool[i].name,
			    strlen(StructUnion_Pool[i].name)) &&
		   !strncmp(type->struct_name+strlen(StructUnion_Pool[i].name),
			    "_impact", 7) && 
	           strcmp(type->struct_name, StructUnion_Pool[i].new_name) 
		 ) ) {
		break;
	    }
	}

	/* this struct is not in the renaming pool */
	if ( i == max_struct_union_pool )
	    return 0;
	else {
	    type->struct_name =  StructUnion_Pool[i].new_name;
	    return 1;
	}
    }
    else return 0;
}


/*-------------------------------------------------------------*/
static PropogateToFields(field)
Field field;
{
  if (field->type == 0)
    return 0;
  return PropogateToTypes(field->type);
}


/*-------------------------------------------------------------*/
static PropogateNewStructs()
{
    int i, j, change;
    Field cur_field_decl;
    StructDcl S, S2;
    UnionDcl U, U2;
    StructUnionPoolElem elem, new_elem;
    char buffer[256];

    if (st_list_len == 0) return;
    while (new_struct_union_created) {
        new_struct_union_created = 0;
        for (i=0; i < st_list_len; i++) {
            if (st_list[i].type == 0 && st_list[i].ptr == 0) continue;
	    change = 0;
            if (st_list[i].type == struct_type) {
		S = (StructDcl)st_list[i].ptr;
		cur_field_decl = S->fields;
		while (cur_field_decl != NULL) {
		    change = change | PropogateToFields(cur_field_decl);
		    cur_field_decl = cur_field_decl->next;
		}
            }
            else if (st_list[i].type == union_type) {
		U = (UnionDcl)st_list[i].ptr;
		cur_field_decl = U->fields;
		while (cur_field_decl != NULL) {
		    change = change | PropogateToFields(cur_field_decl);
		    cur_field_decl = cur_field_decl->next;
		}
            };
	    if (change) {
		if (st_list[i].type == struct_type) {
		    for (j=0; j < max_struct_union_pool; j++) {
			if (!strcmp(StructUnion_Pool[j].name, S->name)) break;
		    }

		    /* BCC - this struct has aliases - 7/3/96 */
		    if ( j != max_struct_union_pool) {
			elem = StructUnion_Pool[j].elem;
			while (elem) {
			    if (elem->type == TY_STRUCT && 
				SameStructDcl(S, elem->ptr.st, 0)) break;
			    elem = elem->next;
			}
			/* Yet another alias */
			if (elem == NULL) {
			    sprintf(buffer, "%s_impact%d", S->name, SUE_counter++);
			    S->name = strdup(buffer);
			    printf("new name = %s\n", buffer);
			    /* BCC - 10/29/96
			     * Because this function is called from ProcessFuncDcl,
			     * the current scope number is not 0, and since all 
			     * structs are defined at scope 0, so we cheated a 
			     * little bit here to use 0 directly to search 
			     */
			    AddStruct(S->name, S->new_name, S, 0);

			    new_elem = NewStructUnionPoolElem(TY_STRUCT);
			    new_elem->ptr.st = S;
			    new_elem->next = StructUnion_Pool[j].elem;
			    StructUnion_Pool[j].elem = new_elem;
			    StructUnion_Pool[j].new_name = S->name;
			}
			else {
			    StructUnion_Pool[j].new_name = elem->ptr.st->name;
			    S->name = elem->ptr.st->name;
			}
		    }
		    else {
			/* BCC - 10/29/96
			 * Because this function is called from ProcessFuncDcl, the
			 * current scope number is not 0, and since all structs
			 * are defined at scope 0, so we cheated a little bit here
			 * to use 0 directly to search 
			 */
			S2 = FindStruct(S->name, 0);
			if (S != S2) {
			    if (S2->fields == 0) {
				S2->fields = S->fields;
				S->fields = 0;
			    }
			    else {
				if (! SameStructDcl(S, S2, 1)) {
				    if (max_struct_union_pool == MAX_STRUCT_UNION_POOL_SIZE)
					Punt("StructUnion_Pool overflow");
				    sprintf(buffer, "%s_impact%d", S->name, SUE_counter++);
				    printf("new name = %s\n", buffer);
				    new_elem = NewStructUnionPoolElem(TY_STRUCT);
				    new_elem->ptr.st = S;
				    new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
				    StructUnion_Pool[max_struct_union_pool].elem = new_elem;
				    StructUnion_Pool[max_struct_union_pool].name = strdup(S->name);
				    StructUnion_Pool[max_struct_union_pool].new_name = strdup(buffer);
				    new_elem = NewStructUnionPoolElem(TY_STRUCT);
				    new_elem->ptr.st = S2;
				    new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
				    StructUnion_Pool[max_struct_union_pool].elem = new_elem;
				    max_struct_union_pool++;
				    S->name = strdup(buffer);
				    /* rename the new one and add to the symbol table */
			    /* BCC - 10/29/96
			     * Because this function is called from ProcessFuncDcl,
			     * the current scope number is not 0, and since all 
			     * structs are defined at scope 0, so we cheated a 
			     * little bit here to use 0 directly to search 
			     */
				    AddStruct(S->name, S->new_name, S, 0);
				}
			    }
			}
		    }
		}
		else if (st_list[i].type == union_type) {
		    for (j=0; j < max_struct_union_pool; j++) {
			if (!strcmp(StructUnion_Pool[j].name, U->name)) break;
		    }

		    /* BCC - this struct has aliases - 7/3/96 */
		    if ( j != max_struct_union_pool) {
			elem = StructUnion_Pool[j].elem;
			while (elem) {
			    if (elem->type == TY_UNION &&
				SameUnionDcl(U, elem->ptr.un, 0)) break;
			    elem = elem->next;
			}
			/* Yet another alias */
			if (elem == NULL) {
			    sprintf(buffer, "%s_impact%d", U->name, SUE_counter++);
			    U->name = strdup(buffer);
			    printf("new name = %s\n", buffer);
			    /* BCC - 10/29/96
			     * Because this function is called from ProcessFuncDcl,
			     * the current scope number is not 0, and since all 
			     * structs are defined at scope 0, so we cheated a 
			     * little bit here to use 0 directly to search 
			     */
			    AddUnion(U->name, U->new_name, U, 0);

			    new_elem = NewStructUnionPoolElem(TY_UNION);
			    new_elem->ptr.un = U;
			    new_elem->next = StructUnion_Pool[j].elem;
			    StructUnion_Pool[j].elem = new_elem;
			    StructUnion_Pool[j].new_name = U->name;
			}
			else {
			    StructUnion_Pool[j].new_name = elem->ptr.un->name;
			    U->name = elem->ptr.un->name;
			}
		    }
		    else {
			/* BCC - 10/29/96
			 * Because this function is called from ProcessFuncDcl, the
			 * current scope number is not 0, and since all structs
			 * are defined at scope 0, so we cheated a little bit here
			 * to use 0 directly to search 
			 */
			U2 = FindUnion(U->name, 0);
			if (U != U2) {
			    if (U2->fields == 0) {
				U2->fields = U->fields;
				U->fields = 0;
			    }
			    else {
				if (! SameUnionDcl(U, U2, 1)) {
				    if (max_struct_union_pool == MAX_STRUCT_UNION_POOL_SIZE)
					Punt("StructUnion_Pool overflow");
				    sprintf(buffer, "%s_impact%d", U->name, SUE_counter++);
				    printf("new name = %s\n", buffer);
				    new_elem = NewStructUnionPoolElem(TY_UNION);
				    new_elem->ptr.un = U;
				    new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
				    StructUnion_Pool[max_struct_union_pool].elem = new_elem;
				    StructUnion_Pool[max_struct_union_pool].name = strdup(U->name);
				    StructUnion_Pool[max_struct_union_pool].new_name = strdup(buffer);
				    new_elem = NewStructUnionPoolElem(TY_UNION);
				    new_elem->ptr.un = U2;
				    new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
				    StructUnion_Pool[max_struct_union_pool].elem = new_elem;
				    max_struct_union_pool++;
				    U->name = strdup(buffer);
				    /* rename the new one and add to the symbol table */
			    /* BCC - 10/29/96
			     * Because this function is called from ProcessFuncDcl,
			     * the current scope number is not 0, and since all 
			     * structs are defined at scope 0, so we cheated a 
			     * little bit here to use 0 directly to search 
			     */
				    AddUnion(U->name, U->new_name, U, 0);
				}
			    }
			}
		    }
		}
	    }
	    new_struct_union_created = new_struct_union_created | change;
        }
    }
}

/*-------------------------------------------------------------*/
static PropogateToGlobalVariables()
{
    int i;

    for (i=0; i < var_list_len; i++) {
	if (var_list[i].modified) {
	    var_list[i].modified = 0;
#if 0
	    /* BCC - debug */
	    if (var_list[i].var->type->type & TY_STRUCTURE) {
		printf("old name = %s\n", var_list[i].var->type->struct_name);
	    }
#endif
	    PropogateToTypes(var_list[i].var->type);
#if 0
	    if (var_list[i].var->type->type & TY_STRUCTURE) {
		printf("new name = %s\n", var_list[i].var->type->struct_name);
	    }
#endif
	}
    }
}

/*-------------------------------------------------------------*/
/* ITI/BCC - 2/2/99 */
static char *type2str(int type)
{
    char type_str[1024];

    type_str[0] = 0;
    if (type & TY_SIGNED)
        strcat(type_str, "signed ");
    if (type & TY_UNSIGNED)
        strcat(type_str, "unsigned ");
    if (type & TY_VOID)
        strcat(type_str, "void ");
    if (type & TY_CHAR)
        strcat(type_str, "char ");
    if (type & TY_SHORT)
        strcat(type_str, "short ");
    if (type & TY_INT)
        strcat(type_str, "int ");
    if (type & TY_LONG)
        strcat(type_str, "long ");
    if (type & TY_FLOAT)
        strcat(type_str, "float ");
    if (type & TY_DOUBLE)
        strcat(type_str, "double ");
    if (type & TY_ENUM)
        strcat(type_str, "int ");
    return C_findstr(type_str);
}

/* ITI/BCC - 2/2/99 */
static void annotate_name_with_dcltr(char *, Dcltr);

/* ITI/BCC - 2/2/99 */
static void gen_expr(char *expr_str, Expr expr)
{
    char lhs[1024], rhs[1024];
    char typesize[1024], typesize_dcltr[1024];

    switch (expr->opcode) {
        case OP_int:
            sprintf(expr_str, "%d", expr->value.scalar);
            break;
        case OP_real:
        case OP_double:
        case OP_float:
            sprintf(expr_str, "%lf", expr->value.real);
            break;
        case OP_char:
            sprintf(expr_str, "'%c'", expr->value.scalar);
            break;
        case OP_type_size:
            if (expr->type->struct_name == 0)
                sprintf(typesize, "%s",
                        type2str(expr->type->type));
            else {
                if (FindStruct(expr->type->struct_name, 0))
                    sprintf(typesize, "struct %s",
                            expr->type->struct_name);
                else
                    sprintf(typesize, "union %s",
                            expr->type->struct_name);
            }
            typesize_dcltr[0] = 0;
            annotate_name_with_dcltr(typesize_dcltr,
                                     expr->type->dcltr);
            sprintf(expr_str, "sizeof(%s%s)", typesize, typesize_dcltr);
            break;
        case OP_compexpr:
            gen_expr(lhs, expr->operands);
            sprintf(expr_str, "(%s)", lhs);
            break;
        case OP_rshft:
            gen_expr(lhs, expr->operands);
            gen_expr(rhs, expr->operands->sibling);
            sprintf(expr_str, "%s >> %s", lhs, rhs);
            break;
        case OP_lshft:
            gen_expr(lhs, expr->operands);
            gen_expr(rhs, expr->operands->sibling);
            sprintf(expr_str, "%s << %s", lhs, rhs);
            break;
        case OP_add:
            gen_expr(lhs, expr->operands);
            gen_expr(rhs, expr->operands->sibling);
            sprintf(expr_str, "%s + %s", lhs, rhs);
            break;
        case OP_sub:
            gen_expr(lhs, expr->operands);
            gen_expr(rhs, expr->operands->sibling);
            sprintf(expr_str, "%s - %s", lhs, rhs);
            break;
        case OP_mul:
            gen_expr(lhs, expr->operands);
            gen_expr(rhs, expr->operands->sibling);
            sprintf(expr_str, "%s * %s", lhs, rhs);
            break;
        case OP_div:
            gen_expr(lhs, expr->operands);
            gen_expr(rhs, expr->operands->sibling);
            sprintf(expr_str, "%s / %s", lhs, rhs);
            break;
        case OP_mod:
            gen_expr(lhs, expr->operands);
            gen_expr(rhs, expr->operands->sibling);
            sprintf(expr_str, "%s % %s", lhs, rhs);
            break;
        case OP_neg:
            gen_expr(lhs, expr->operands);
            sprintf(expr_str, "(-%s)", lhs, rhs);
            break;
        default:
            Punt("gen_expr: unexpected opcode ");
    }
}

/* ITI/BCC - 2/2/99 */
static void annotate_name_with_dcltr(char *str, Dcltr dcltr_list)
{
    Dcltr dcltr, prev_dcltr;
    char buffer[1024], index_str[1024];
    Expr index;

    prev_dcltr = 0;
    for (dcltr = dcltr_list; dcltr; dcltr = dcltr->next) {
        switch (dcltr->method) {
            case D_PTR:
                sprintf(buffer, "*%s", str);
                strcpy(str, buffer);
                break;
            case D_FUNC:
                sprintf(buffer, "(%s)()", str);
                strcpy(str, buffer);
                break;
            case D_ARRY:
                index = dcltr->index;

                if (prev_dcltr && prev_dcltr->method == D_PTR) {
                    if (index == 0) {
                        sprintf(buffer, "(%s)[]", str);
                        strcpy(str, buffer);
                    }
                    else {
                        gen_expr(index_str, index);
                        sprintf(buffer, "(%s)[%s]", str, index_str);
                        strcpy(str, buffer);
                    }
                }
                else {
                    if (index == 0) {
                        sprintf(buffer, "%s[]", str);
                        strcpy(str, buffer);
                    }
                    else {
                        gen_expr(index_str, index);
                        sprintf(buffer, "%s[%s]", str, index_str);
                        strcpy(str, buffer);
                    }
                }
                break;
        }
        prev_dcltr = dcltr;
    }
}

PrintLayoutInfo()
{
    int i;
    StructDcl S1;
    UnionDcl U1;
    Field field, prev_field, bit_field;
    Dcltr dcltr;
    FILE *Flayout;
    char dcltr_str1[8096], dcltr_str2[8096], dcltr_str3[8096];
    STRING_Symbol *symbol;
    st_un_type s_u_type;

    /* ITI/BCC - generate code to measure the size of data types and field
     * offsets - 2/2/99
     *
     * ITI/JCG - enhanced to use libmd.a to simplify use by Mspec -2/99
     * ITI/JCG - added struct/union alignment determination -2/99
     * ITI/JCG - added bit-field placement detection -2/99
     */
    
    for (symbol = dummy_struct_union_tbl->head_symbol;
         symbol;
	 symbol = symbol->next_symbol) {
	if (!STRING_find_symbol(struct_union_tbl, symbol->name))
	    STRING_add_symbol(struct_union_tbl, symbol->name, symbol->data);
    }
    if (sp_create_layout_info_generator)
    {
	/* Sanity check, make sure we didn't call this twice! */
	if (layout_file_generated != 0)
	{
	    L_punt ("\n"
		    "Psplit: gen_host_layout_info.c generated twice!\n"
		    "        Information will be lost!\n");
	}

	/* Flag that we are generating a layout file */
	layout_file_generated=1;

	Flayout = fopen("gen_host_layout_info.c", "wt");
	fprintf (Flayout, 
		 "/* Automatically generated by IMPACT to determine host compiler's\n"
		 " * structure/union layout rules for this particular application.\n"
		 " * Must be linked to 'libimpact.a' and compiled with host compiler.\n"
		 " * All structures/unions prefixed with _HT_ to prevent conflicts with\n"
		 " * definitions in md.h and stdio.h."
		 " *\n"
		 " * Developed by IMPACT Technologies Inc (BCC/JCG) 2/99.\n"
		 " */\n");
	fprintf (Flayout, "#include <library/md.h>\n\n");
	
	for (i=0; i < 6; i++)
	{
	    fprintf (Flayout, 
		     "struct {\n"
		     "    char base;\n"
		     "    %s field;\n"
		     "} _HT__align__%s;\n\n",
		     base_type_name[i], base_type_name[i]);
	}
	
	/* Do special case for void * */
	fprintf (Flayout, 
		 "struct {\n"
		 "    char base;\n"
		 "    void *field;\n"
		 "} _HT__align__void_ptr;\n\n");
	
        for (symbol = struct_union_tbl->head_symbol;
             symbol;
             symbol = symbol->next_symbol) {
            s_u_type = (st_un_type) symbol->data;
	    if (s_u_type == struct_type) 
	    {
		S1 = FindStruct(symbol->name, 0);
		if (S1->fields == 0)
		    continue;
		dcltr_str2[0] = 0;
		
		fprintf(Flayout, "struct _HT_%s {\n", S1->name);
		bit_field = prev_field = 0;
		for (field = S1->fields; field; field = field->next) {
		    if (field->type->struct_name == 0)
		    {
			sprintf(dcltr_str1, "%s",
				type2str(field->type->type));
		    }
		    else 
		    {
			if (FindStruct(field->type->struct_name, 0))
			    sprintf(dcltr_str1, "struct _HT_%s",
				    field->type->struct_name);
			else
			    sprintf(dcltr_str1, "union _HT_%s",
				    field->type->struct_name);
		    }
		    sprintf(dcltr_str2, "%s", field->name);
		    annotate_name_with_dcltr(dcltr_str2, field->type->dcltr);
		    if (field->bit_field) 
		    {
			fprintf(Flayout, "    %s %s:%d;\n", dcltr_str1, 
				dcltr_str2, field->bit_field->value.scalar);
		    }
		    else
		    {
			fprintf(Flayout, "    %s %s;\n", dcltr_str1, 
				dcltr_str2);
		    }
		    prev_field = field;
		}
		fprintf(Flayout, "} _HT_%s;\n\n", S1->name);
		
		/* Create structure to get alignment info */
		fprintf (Flayout, 
			 "struct {\n"
			 "    char base;\n"
			 "    struct _HT_%s field;\n"
			 "} _HT__align__%s;\n\n",
			 S1->name, S1->name);
	    }
	    else 
	    {
		U1 = FindUnion(symbol->name, 0);
		if (U1->fields == 0)
		    continue;
		dcltr_str2[0] = 0;
		fprintf(Flayout, "union _HT_%s {\n", U1->name);
		for (field = U1->fields; field; field = field->next) 
		{
		    if (field->type->struct_name == 0)
		    {
			sprintf(dcltr_str1, "%s",
				type2str(field->type->type));
		    }
		    else 
		    {
			if (FindStruct(field->type->struct_name, 0))
			    sprintf(dcltr_str1, "struct _HT_%s",
				    field->type->struct_name);
			else
			    sprintf(dcltr_str1, "union _HT_%s",
				    field->type->struct_name);
		    }
		    sprintf(dcltr_str2, "%s", field->name);
		    annotate_name_with_dcltr(dcltr_str2, field->type->dcltr);
		    if (field->bit_field) 
		    {
			fprintf(Flayout, "    %s %s:%d;\n", dcltr_str1, 
				dcltr_str2, field->bit_field->value.scalar);
		    }
		    else
		    {
			fprintf(Flayout, "    %s %s;\n", dcltr_str1, 
				dcltr_str2);
		    }
		}
		fprintf(Flayout, "} _HT_%s;\n\n", U1->name);
		
		/* Create structure to get alignment info */
		fprintf (Flayout, 
			 "struct {\n"
			 "    char base;\n"
			 "    union _HT_%s field;\n"
			 "} _HT__align__%s;\n\n",
			 U1->name, U1->name);
	    }
	}
	
	fprintf(Flayout,
		"\n"
		"/* Global variables */\n"
		"    MD *type_info;\n"
		"\n"
		"/* Add integer in the place specified, creating whatever we need to\n"
		" * to place it there.\n"
		" */\n"
		"void add_info_i (char *section_name, char *entry_name, char *field_name,\n"
		"	       int value)\n"
		"{\n"
		"    MD_Section *section;\n"
		"    MD_Entry *entry;\n"
		"    MD_Field_Decl *field_decl;\n"
		"    MD_Field *field;\n"
		"\n"
		"    /* Find or create desired section */\n"
		"    if ((section = MD_find_section (type_info, section_name)) == NULL)\n"
		"       section = MD_new_section (type_info, section_name, 0, 0);\n"
		"\n"
		"    /* Find or create desired field declaration in section */\n"
		"    if ((field_decl = MD_find_field_decl (section, field_name)) == NULL)\n"
		"    {\n"
		"	field_decl = MD_new_field_decl (section, field_name, \n"
		"					MD_OPTIONAL_FIELD);\n"
		"	MD_require_int (field_decl, 0);\n"
		"    }\n"
		"\n"
		"    /* Find or create desired entry in section */\n"
		"    if ((entry = MD_find_entry (section, entry_name)) == NULL)\n"
		"	entry = MD_new_entry (section, entry_name);\n"
		"\n"
		"    /* Make sure field not already present for this entry */\n"
		"    if ((field = MD_find_field (entry, field_decl)) != NULL)\n"
		"    {\n"
		"	L_punt (\"Error: %%s->%%s->%%s already exists!\",\n"
		"		section_name, entry_name, field_name);\n"
		"    }\n"
		"\n"
		"    /* Create the desired field */\n"
		"    field = MD_new_field (entry, field_decl, 1);\n"
		"    \n"
		"    /* Set the first element to the desired value */\n"
		"    MD_set_int (field, 0, value);\n"
		"}\n"
		"\n"
		"/* Add string in the place specified, creating whatever we need to\n"
		" * to place it there.\n"
		" */\n"
		"void add_info_s (char *section_name, char *entry_name, char *field_name,\n"
		"	       char *value)\n"
		"{\n"
		"    MD_Section *section;\n"
		"    MD_Entry *entry;\n"
		"    MD_Field_Decl *field_decl;\n"
		"    MD_Field *field;\n"
		"\n"
		"    /* Find or create desired section */\n"
		"    if ((section = MD_find_section (type_info, section_name)) == NULL)\n"
		"       section = MD_new_section (type_info, section_name, 0, 0);\n"
		"\n"
		"    /* Find or create desired field declaration in section */\n"
		"    if ((field_decl = MD_find_field_decl (section, field_name)) == NULL)\n"
		"    {\n"
		"	field_decl = MD_new_field_decl (section, field_name, \n"
		"					MD_OPTIONAL_FIELD);\n"
		"	MD_require_string (field_decl, 0);\n"
		"    }\n"
		"\n"
		"    /* Find or create desired entry in section */\n"
		"    if ((entry = MD_find_entry (section, entry_name)) == NULL)\n"
		"	entry = MD_new_entry (section, entry_name);\n"
		"\n"
		"    /* Make sure field not already present for this entry */\n"
		"    if ((field = MD_find_field (entry, field_decl)) != NULL)\n"
		"    {\n"
		"	L_punt (\"Error: %%s->%%s->%%s already exists!\",\n"
		"		section_name, entry_name, field_name);\n"
		"    }\n"
		"\n"
		"    /* Create the desired field */\n"
		"    field = MD_new_field (entry, field_decl, 1);\n"
		"    \n"
		"    /* Set the first element to the desired value */\n"
		"    MD_set_string (field, 0, value);\n"
		"}\n"
		"\n"
		"/* Zero out structure, in preparation for find_offset() */\n"
		"void zero_struct (char *ptr, int size)\n"
		"{\n"
		"    int i;\n"
		"\n"
		"    for (i=0; i < size; i++)\n"
		"	ptr[i] = 0;\n"
		"}\n"
		"\n"
		"/* Create an all-one value that should fit exactly in a bit-field of 'size' */\n"
		"unsigned int all_ones (int size)\n"
		"{\n"
		"    int i, value;\n"
		"    value = 1;\n"
		"\n"
		"    for (i=0; i < size; i++)\n"
		"	value = (value << 1) + 1;\n"
		"\n"
		"    return (value);\n"
		"}\n"
		"/* Returns the offset of the first bit set to one\n"
		" * Now scans using ints to handle little endian platforms -JCG 6/99\n"
		" */\n"
		"int find_offset (char *ptr, int size)\n"
		"{\n"
		"    int i, k, offset;\n"
		"    unsigned int value;\n"
		"\n"
		"    offset = 0;\n"
		"    for (i=0; i < size; i+=4)\n"
		"    {\n"
		"	value = *((unsigned int *)(void *)(ptr + i));\n"
		"	if (value != 0)\n"
		"	{\n"
		"	    for (k=0; k < 32; k++)\n"
		"	    {\n"
		"		/* Find the uppermost bit set, return offset for it */\n"
		"		if (((0x80000000 >> k) & value) != 0)\n"
		"		    return (offset + k);\n"
		"	    }\n"
		"	}\n"
		"	else\n"
		"	{\n"
		"	    offset +=32;\n"
		"	}\n"
		"    }\n"
		"    L_punt (\"find_offset: No bit set in structure\");\n"
		"}\n"
		"\n");
	
	fprintf(Flayout, "main()\n{\n");
	fprintf(Flayout, "    char *base_addr, *field_addr;\n");
	fprintf(Flayout, "    char endian_buf[4];\n");
	fprintf(Flayout, "    int size;\n");
	
	fprintf(Flayout, 
		"\n"
		"    /* Create md table to store all the size/align info */\n"
		"    type_info = MD_new_md (\"host_type_info\", 0);\n");
	
        fprintf(Flayout,
		"\n"
		"    /* Add description to aid debugging problems later */\n"
                "    add_info_i (\"_HT__info\", \"%s\", \"gen_CtoP\", 232);\n\n",
		sp_layout_info_desc);

        fprintf(Flayout,
		"\n"
		"    /* Determine if big or little endian platform */\n"
		"    *((int *)(void *)endian_buf) = 1;\n"
		"    if (endian_buf[0] == 1)\n"
		"    {\n"
                "       add_info_i (\"_HT__info\", \"little_endian\", \"value\", 1);\n"
		"    \n"
		"    }\n"
		"    else if (endian_buf[3] == 1)\n"
		"    {\n"
                "       add_info_i (\"_HT__info\", \"little_endian\", \"value\", 0);\n"
		"    \n"
		"    }\n"
		"    else\n"
		"    {\n"
                "       L_punt (\"Little endian test failed!\");\n"
		"    \n"
		"    }\n"
		"    \n");

	fprintf(Flayout, 
		"\n"
		"    /* Generate sizeof() results for all base types */\n");
	for (i=0; i < 6; i++)
	{
	    fprintf (Flayout,
		     "    add_info_i (\"_HT__base_types\", \"%s\", \"size\", 8*sizeof(%s));\n",
		     base_type_name[i], base_type_name[i]);
	    fprintf (Flayout,
		     "    base_addr = (char *) &_HT__align__%s.base;\n",
		     base_type_name[i]);
	    fprintf (Flayout,
		     "    field_addr = (char *) &_HT__align__%s.field;\n",
		     base_type_name[i]);
	    fprintf (Flayout,
		     "    add_info_i (\"_HT__base_types\", \"%s\", \"align\", 8*(field_addr - base_addr));\n\n",
		     base_type_name[i]);
	}
	
	/* Do special case for void * */
	fprintf (Flayout,
		 "    add_info_i (\"_HT__base_types\", \"void *\", \"size\", 8*sizeof(void *));\n");
	fprintf (Flayout,
		 "    base_addr = (char *) &_HT__align__void_ptr.base;\n",
		 base_type_name[i]);
	fprintf (Flayout,
		 "    field_addr = (char *) &_HT__align__void_ptr.field;\n",
		 base_type_name[i]);
	fprintf (Flayout,
		 "    add_info_i (\"_HT__base_types\", \"void *\", \"align\", 8*(field_addr - base_addr));\n\n");
	
	
	fprintf(Flayout, 
		"\n"
		"    /* Generate sizeof () results for each structure or union */\n");
	
	for (symbol = struct_union_tbl->head_symbol;
             symbol;
             symbol = symbol->next_symbol) {
            s_u_type = (st_un_type) symbol->data;
	    if (s_u_type == struct_type) {
		S1 = FindStruct(symbol->name, 0);
		if (S1->fields == 0)
		    continue;
		fprintf (Flayout,
			 "    add_info_i (\"_HT__user_types\", \"%s\", \"size\", 8*sizeof(_HT_%s));\n",
			 S1->name, S1->name);
		fprintf (Flayout,
			 "    base_addr = (char *) &_HT__align__%s.base;\n",
			 S1->name);
		fprintf (Flayout,
			 "    field_addr = (char *) &_HT__align__%s.field;\n",
			 S1->name);
		fprintf (Flayout,
			 "    add_info_i (\"_HT__user_types\", \"%s\", \"align\", 8*(field_addr - base_addr));\n",
			 S1->name);	    
		fprintf (Flayout,
                         "    add_info_i (\"_HT__user_types\", \"%s\", \"union\", 0);\n\n",
                         S1->name);
	    }
	    else {
		U1 = FindUnion(symbol->name, 0);
		if (U1->fields == 0)
		    continue;
		fprintf (Flayout,
			 "    add_info_i (\"_HT__user_types\", \"%s\", \"size\", 8*sizeof(_HT_%s));\n",
			 U1->name, U1->name);
		fprintf (Flayout,
			 "    base_addr = (char *) &_HT__align__%s.base;\n",
			 U1->name);
		fprintf (Flayout,
			 "    field_addr = (char *) &_HT__align__%s.field;\n",
			 U1->name);
		fprintf (Flayout,
			 "    add_info_i (\"_HT__user_types\", \"%s\", \"align\", 8*(field_addr - base_addr));\n",
			 U1->name);	    
		fprintf (Flayout,
                         "    add_info_i (\"_HT__user_types\", \"%s\", \"union\", 1);\n\n",
                         U1->name);
	    }
	}
	
	for (symbol = struct_union_tbl->head_symbol;
             symbol;
             symbol = symbol->next_symbol) {
            s_u_type = (st_un_type) symbol->data;
	    if (s_u_type == struct_type) {
		S1 = FindStruct(symbol->name, 0);
		if (S1->fields == 0)
		    continue;
		fprintf(Flayout, 
			"\n    /* Processing struct %s */\n", S1->name);
		fprintf(Flayout, 
			"    base_addr = (char *) &_HT_%s;\n", S1->name);
		for (field = S1->fields; field; field = field->next) {
		    if (field->type->struct_name == 0)
		    {
			sprintf(dcltr_str1, "%s",
				type2str(field->type->type));
			/* Remove trailing space, if exists */
			if (dcltr_str1[strlen(dcltr_str1)-1] == ' ')
			    dcltr_str1[strlen(dcltr_str1)-1] = 0;
		    }
		    else 
		    {
			if (FindStruct(field->type->struct_name, 0))
			    sprintf(dcltr_str1, "struct %s",
				    field->type->struct_name);
			else
			    sprintf(dcltr_str1, "union %s",
				    field->type->struct_name);
		    }
		    sprintf(dcltr_str2, "%s", field->name);
		    annotate_name_with_dcltr(dcltr_str2, field->type->dcltr);
		    if (field->bit_field) 
		    {
			sprintf(dcltr_str3, "%s %s:%d", dcltr_str1, 
				dcltr_str2, field->bit_field->value.scalar);
		    }
		    else
		    {
			sprintf(dcltr_str3, "%s %s", dcltr_str1, dcltr_str2);
		    }

		    fprintf (Flayout,
			     "\n"
			     "    add_info_s(\"%s\", \"%s\", \"decl\", \"%s\");\n",
			     S1->name, field->name, dcltr_str3);
			     
		    if (field->bit_field) {
			fprintf (Flayout,
				 "    add_info_i(\"%s\", \"%s\", \"size\", %i);\n",
				 S1->name, field->name, 
				 field->bit_field->value.scalar);
			fprintf (Flayout, 
				 "    zero_struct((char *)&_HT_%s, sizeof(_HT_%s));\n",
				 S1->name, S1->name);
			fprintf (Flayout, 
				 "    _HT_%s.%s = all_ones(%i);\n",
				 S1->name, field->name, 
				 field->bit_field->value.scalar);
			fprintf (Flayout,
				 "    add_info_i(\"%s\", \"%s\", \"offset\",\n"
				 "             find_offset((char *)&_HT_%s, sizeof(_HT_%s)));\n",
				 S1->name, field->name, S1->name, S1->name);
		    }
		    else {
			fprintf(Flayout, 
				"    field_addr = (char *) &_HT_%s.%s;\n",
				S1->name, field->name);
			fprintf (Flayout,
				 "    add_info_i(\"%s\", \"%s\", \"offset\", 8*(field_addr - base_addr));\n",
				 S1->name, field->name);
			fprintf (Flayout,
				 "    add_info_i(\"%s\", \"%s\", \"size\", 8*sizeof(_HT_%s.%s));\n",
				 S1->name, field->name, S1->name, field->name);
		    }
		}
	    }
	    else {
		U1 = FindUnion(symbol->name, 0);
		if (U1->fields == 0)
		    continue;
		fprintf(Flayout, 
			"\n    /* Processing union %s */\n", U1->name);
		fprintf(Flayout, 
			"    base_addr = (char *) &_HT_%s;\n", U1->name);
		for (field = U1->fields; field; field = field->next) {
		    if (field->bit_field) 
		    {
			L_punt ("\nError: unexpected bitfield inside union!\n"
				"Not allowed when Psplit implemented!");
		    }
		    if (field->type->struct_name == 0)
		    {
			sprintf(dcltr_str1, "%s",
				type2str(field->type->type));
			/* Remove trailing space, if exists */
			if (dcltr_str1[strlen(dcltr_str1)-1] == ' ')
			    dcltr_str1[strlen(dcltr_str1)-1] = 0;
		    }
		    else 
		    {
			if (FindStruct(field->type->struct_name, 0))
			    sprintf(dcltr_str1, "struct %s",
				    field->type->struct_name);
			else
			    sprintf(dcltr_str1, "union %s",
				    field->type->struct_name);
		    }
		    sprintf(dcltr_str2, "%s", field->name);
		    annotate_name_with_dcltr(dcltr_str2, field->type->dcltr);
		    if (field->bit_field) 
		    {
			sprintf(dcltr_str3, "%s %s:%d", dcltr_str1, 
				dcltr_str2, field->bit_field->value.scalar);
		    }
		    else
		    {
			sprintf(dcltr_str3, "%s %s", dcltr_str1, dcltr_str2);
		    }
		    fprintf (Flayout,
			     "\n"
			     "    add_info_s(\"%s\", \"%s\", \"decl\", \"%s\");\n",
			     U1->name, field->name, dcltr_str3);
		    fprintf(Flayout, "    field_addr = (char *) &_HT_%s.%s;\n",
			    U1->name, field->name);
		    fprintf (Flayout,
			     "    add_info_i(\"%s\", \"%s\", \"offset\", 8*(field_addr - base_addr));\n",
			     U1->name, field->name);
		    fprintf (Flayout,
			     "    add_info_i(\"%s\", \"%s\", \"size\", 8*sizeof(_HT_%s.%s));\n",
			     U1->name, field->name, U1->name, field->name);
		}
		fprintf(Flayout, "\n");
	    }
	}
	
#if 1
	fprintf(Flayout, 
		"\n"
		"    /* Write md to stdout in binary form*/\n"
		"    MD_write_md (stdout, type_info);\n");
#else
	fprintf(Flayout, 
		"\n"
		"    /* Print type_info out for reading*/\n"
		"    MD_print_md (stdout, type_info, 80);\n");
#endif
	
	fprintf(Flayout, 
		"\n"
		"    return (0);\n"
		"}\n");


	fclose(Flayout);
    }
}

PrintStruct()
{
    int i;
    StructDcl S1, S2;
    UnionDcl U1, U2;

    /* BCC - 7/26/96
     * since all structs/unions are placed before the first function, it is 
     * safe now to dump struct/union decls.
     */
    if (st_list_len != 0) {
	if (edg_generated) {
	    PropogateNewStructs();
	    PropogateToGlobalVariables();
	};
	update_st_un_name = 1;
	for (i=0; i < st_list_len; i++) {
	    if (st_list[i].type == 0 && st_list[i].ptr == 0) continue;
	    if (st_list[i].type == struct_type) {
		S1 = (StructDcl) st_list[i].ptr;
		S2 = FindStruct(S1->name, 0);
		if (S1 != S2 && S2 && SameStructDcl(S1, S2, 1)) continue;
		if (!STRING_find_symbol(dummy_struct_union_tbl, S1->name))
		    STRING_add_symbol(dummy_struct_union_tbl, S1->name,
				      (void *) struct_type);
		if (S1->fields)
		    STRING_add_symbol(struct_union_tbl, S1->name, 
				      (void *) struct_type);
		switch (sp_output_form) {
		    case OUTPUT_PCODE:
			Gen_PCODE_Struct(Fstruct, (StructDcl) st_list[i].ptr);
			break;
		    case OUTPUT_HCODE:
			Gen_HCODE_Struct(Fstruct, (StructDcl) st_list[i].ptr);
			break;
		};
	    }
	    else {
		U1 = (UnionDcl) st_list[i].ptr;
		U2 = FindUnion(U1->name, 0);
		if (U1 != U2 && U2 && SameUnionDcl(U1, U2, 1)) continue;
		if (!STRING_find_symbol(dummy_struct_union_tbl, U1->name))
		    STRING_add_symbol(dummy_struct_union_tbl, U1->name,
				      (void *) union_type);
		if (U1->fields)
		    STRING_add_symbol(struct_union_tbl, U1->name, 
				      (void *) union_type);
		switch (sp_output_form) {
		    case OUTPUT_PCODE:
			Gen_PCODE_Union(Fstruct, (UnionDcl) st_list[i].ptr);
			break;
		    case OUTPUT_HCODE:
			Gen_HCODE_Union(Fstruct, (UnionDcl) st_list[i].ptr);
			break;
		};
	    }
	}
/* BCC - 2/8/97
 * If we turn off update_st_un_name now, the local ones which reference the
 * renamed structures will use the old names. Try to turn it off when finishing
 * compiling each file.
 */
#if 0
	update_st_un_name = 0;
#endif
    }
    st_list_len = 0;
}

/*-------------------------------------------------------------*/
ProcessFuncDcl(func)
FuncDcl func;
{
    static int f_index = 0;
    char f_name[256];
    FILE *Fout;

    VarDcl var;		/* add the function definiton to extern file */
    Type type;
    Dcltr dcltr;
    /* BCC - 7/31/96 */
    VarList params;
    Param last, new;

    if (st_list_len) 
	PrintStruct();

    var = NewVarDcl();
    var->name = func->name;
    type = CopyType(func->type);
    type->type &= ~TY_STATIC; 
    type->type |= TY_EXTERN;

    /* BCC - parm types have been added in BeginFunc() - 8/3/96 */
#if 0
    /* BCC - reproduce the types of the params into D_FUNC - 7/31/96 */
    dcltr = type->dcltr;
    assert(dcltr->method == D_FUNC);
    params = func->param;
    last = NULL;
    while (params) {
	new = NewParam();
	new->type = CopyType(params->var->type);
	if (last) {
	    last->next = new;
	    last = new;
	}
	else {
	    dcltr->param = new;
	    last = new;
	}
	params = params->next;
    }
#endif

    var->type = type;

/* e.g. in bench.c s_stop is declared as int s_stop(); but in s_stop.c, it's
   type is void, so we always replace the old declaration by the one from
   function definition 							      */

    /* BCC - 4/9/96
     * VARARG (...) is not conveyed by func->type. Therefore updating the var 
     * dcl list by func->type may ruin the "..." conveyed by the prototype 
     * declaration. The AddVarDcl here always generates foo1(), skipping the 
     * params. Therefore it generates a inconsistent forward declaration and 
     * may introduce compilation errors in H->C translation.
     * But we cannot eliminate this AddVarDcl because if foo1() and foo2() are 
     * in the same file, spliting them makes foo1() invisible to foo2() unless 
     * we put foo1() to extern.h. So the current solution is to change 
     * AddVarDcl(var,1) to AddVarDcl(var,0).
     */
    AddVarDcl(var,1);
    active_fn = func->name;

    CF_Build_CFG_Function(func);
    dep_pragmas_generated = FALSE;

    switch (sp_output_form) {
	case OUTPUT_PCODE:
	    /* BCC - use the new convention .pcs to name the file - 5/4/96 */
	    sprintf(f_name, "%s/f_%d.pcs", sp_output_dir_string, f_index++);
	    Fout = fopen(f_name, "wt");
	    if (Fout == 0) Punt("Can't open output file");
	    fprintf(Fout, "( INCLUDE \"extern.pch\")\n");
	    if (f2c_generated != 0)
		Gen_PCODE_Var(Fout, f2c_generated);
	    Gen_PCODE_Func(Fout, func, NO_PRETTY_PRINT_PCODE);
	    fflush(Fout);
	    fclose(Fout);
	    /* BCC - "1" means inlinable - 7/9/96 */
	    /* BCC - don't inline alloca and find_stack_direction - 1/9/97 */
	    if (!strncmp(active_fn, "alloca", 6) || 
		!strncmp(active_fn, "find_stack_direction", 20))
		fprintf(Fmapping, "(map 0 (./%s %s) to (%s %s))\n", 
			active_file, active_fn, f_name, active_fn);
	    else
		fprintf(Fmapping, "(map 1 (./%s %s) to (%s %s))\n", 
			active_file, active_fn, f_name, active_fn);
	    break;
    	case OUTPUT_HCODE:
            /* BCC - use the new convention .pcs to name the file - 5/4/96 */
	    sprintf(f_name, "%s/f_%d.hcs", sp_output_dir_string, f_index++);
	    Fout = fopen(f_name, "wt");
	    if (Fout == 0) Punt("Can't open output file");
	    fprintf(Fout, "( INCLUDE \"extern.hch\")\n");
	    if (f2c_generated != 0)
		Gen_HCODE_Var(Fout, f2c_generated);
	    Gen_HCODE_Func(Fout, func);
	    fflush(Fout);
	    fclose(Fout);
	    /* BCC - "1" means inlinable - 7/9/96 */
	    /* BCC - don't inline alloca and find_stack_direction - 1/9/97 */
	    if (!strncmp(active_fn, "alloca", 6) || 
		!strncmp(active_fn, "find_stack_direction", 20))
		fprintf(Fmapping, "(map 0 (./%s %s) to (%s %s))\n", 
			active_file, active_fn, f_name, active_fn);
	    else
		fprintf(Fmapping, "(map 1 (./%s %s) to (%s %s))\n", 
			active_file, active_fn, f_name, active_fn);
	    break;
	case OUTPUT_NONE:
	    /* BCC - report all the functions with source code */
	    sprintf(f_name, "%s/f_%d.pcs", sp_output_dir_string, f_index++);
	    fprintf(Fmapping, "(map 1 (./%s %s) to (%s %s))\n", 
		    active_file, active_fn, f_name, active_fn);
	    break;
    }	
    active_fn = "????";

    /* BCC - clear the useless_var_table - 2/26/97 */
    if (do_flatten == 1) 
	Clear_Useless_Var_Table();
}

/*-------------------------------------------------------------*/
ProcessGlobalVar(var)
VarDcl var;
{
    AddVarDcl(var,0);
}
    
/* BCC - 8/2/96 
 * To support structs renaming, we rely on EDG to move all the struct 
 * definitions before the forward reference. After definition, Pcode can 
 * determine if that struct needs to be renamed. If so, Pcode guarantees
 * that the following references will use the new name.
 */
/*-------------------------------------------------------------*/
ProcessStruct(st)
StructDcl st;
{
/* BCC - pending the print until all structs are properly renamed - 7/26/96 */
#if 0
    switch (sp_output_form) {
	case OUTPUT_PCODE:
	    Gen_PCODE_Struct(Fstruct, st);
	    break;
	case OUTPUT_HCODE:
	    Gen_HCODE_Struct(Fstruct, st);
	    break;
    };
#endif
    AddStructUnionDcl((void *)st, struct_type);
}
/*-------------------------------------------------------------*/
ProcessUnion(un)
UnionDcl un;
{
/* BCC - pending the print until all unions are properly renamed - 7/26/96 */
#if 0
    switch (sp_output_form) {
	case OUTPUT_PCODE:
	    Gen_PCODE_Union(Fstruct, un);
	    break;
	case OUTPUT_HCODE:
	    Gen_HCODE_Union(Fstruct, un);
	    break;
    };
#endif
    AddStructUnionDcl((void *)un, union_type);
}

/*-------------------------------------------------------------*/
ProcessEnum(en)
EnumDcl en;
{
    /* Do nothing, since all enum fields are translated to the corresponding
       int values */
    return 0;
}

/*-------------------------------------------------------------*/
PostProcess()
{
    /* Do nothing */
    return 0;
}

/*-------------------------------------------------------------*/
ProcessInclude()
{
    Punt("Can't handle INCLUDE in Psplit");
}

/******************************************************************************\
 *      Add a new file (to be processed) to the system.			      *
\******************************************************************************/
static AddFile(file_name)
char *file_name;
{
    int i;
    char buffer[2047], *dot;

    if (fc >= MAX_FILES) Punt("too many input files");
    for (i=0; i<fc; i++) {
        if (! strcmp(files[i].file_name, file_name)) {
            fprintf(stderr, "# file name (%s) has been used more than once\n",
                file_name);
            Punt("sorry");
        }
    }
    files[fc].file_name = C_findstr(file_name);
    files[fc].file_id = fc;
    fc ++;

    /* BCC - print filename name into impact_filelist - 6/2/98 */
    if (strrchr(file_name, '/'))
	sprintf(buffer, strrchr(file_name, '/')+1);
    else
	sprintf(buffer, file_name);
    dot = buffer + strlen(buffer) - 1;
    if (*dot == 'p' && *(dot-1) == '.')
        dot -= 2;
    while (*dot != '.')
        dot--;
    *dot = 0;
    strcat(buffer, ".pci");
    fprintf(Ffile, "%s\n", buffer);
    /* BCC - end of change - 6/2/98 */

    return (fc - 1);
}

/******************************************************************************\
 *      Read input spec.						      *
 *      Input Format:							      *
 *            file1.{pc,hc}  						      *
 *            file2.{pc,hc}  						      *
 *            file3.{pc,hc}  						      *
 *                :							      *
 *                :							      *
\******************************************************************************/
static ReadInputSpec(input_spec)
char *input_spec;
{
    FILE *FI;
    char file_name[1024];

    FI = fopen(input_spec, "rt");
    if (FI == 0) Punt("cannot open input_spec file");
    while (1) {
	if (fscanf(FI, "%s", file_name) == EOF) break;
	AddFile(file_name);
    }
}

static OpenFileScope(file_name, file_id)
char *file_name;
int file_id;
{
    active_file = file_name;
    active_file_id = file_id;
}

static SP_ClearSymbolTable()
{
    int i;

    ClearSymTbl(SymbolTable[TBT_FUNC]);
    ClearSymTbl(SymbolTable[TBT_TYPEDEF]);
    /* BCC - for files with global vars but no functions - 10/29/96 */
    if (st_list_len)
	PrintStruct();
    if (f2c_generated != 0) {
	RemoveVarDcl(f2c_generated);
	f2c_generated = 0;
    };
    for (i=0; i < max_struct_union_pool; i++) 
	StructUnion_Pool[i].new_name = StructUnion_Pool[i].name;
    for (i = 0; i < var_list_len; i++) 
	var_list[i].modified = 0;
    C_clear(struct_T_name_table);
}

static ProcessFile(i)
int i;
{
    char *file_name;
    int file_id;
    LIST list;
    file_name = files[i].file_name;
    file_id = files[i].file_id;
    printf("Process input file : %s\n", file_name);
    if (lexOpen(file_name, 0)==0)
        Punt("cannot open input file");
#if 0
    for (; (list=GetNode())!=0; DisposeNode(list)) {
        if (NodeType(list)==T_EOF)
            break;
        ProcessList(list);      /* ccode */
    }
#endif
    /* BCC - for new Pcode - 5/8/96 */
    while (P_get_input() != P_INPUT_EOF)
    {
        process_input();
    }
    lexClose(file_name);
    SP_ClearSymbolTable();         /* undefine all declarations */
    /* BCC - reset the update flag at the end of each compilation unit */
    update_st_un_name = 0;
}

static ProcessFiles()
{
    int i;
    char data_file_name[1024];

    for (i=0; i<fc; i++) {
	new_struct_union_created = 0;
        OpenFileScope(files[i].file_name, files[i].file_id);
	if (!group_global_vars) {
	    sprintf(data_file_name, "%s/data_%d.pcs", sp_output_dir_string, i);
	    Fdata_per_file = fopen(data_file_name, "wt");
	}
        ProcessFile(i);
	/* 
	 * BCC - 4/7/96
	 * Since in 126.gcc there are 2000+ functions and we cannot link them
	 * all after splition, so we plan to profile it first then split it.
	 * But now we have to free the symbol tables to avoid duplications.
	 */
	RemoveLocalSymT(TT_VAR);
	RemoveLocalSymT(TT_ENUM);
	RemoveLocalSymT(TT_ENUMFIELD);
	if (!group_global_vars)
	    fclose(Fdata_per_file);
    }
}

/*
 *      Create the working directory.
 */
static MakeImpactDirectory() {
    /* BCC - keep the directory if it is already there */
    if (sp_output_form == OUTPUT_NONE) return;
#if 0
    printf("Removing output directory : %s\n", sp_output_dir_string);
    Rmdir(sp_output_dir_string);
#endif
    Mkdir(sp_output_dir_string);
}
    
void P_read_parm_Psplit(ppi)
    Parm_Parse_Info *ppi;
{
    L_read_parm_s(ppi, "sp_format", &sp_output_format_string);
    L_read_parm_s(ppi, "sp_dir", &sp_output_dir_string);
    L_read_parm_s(ppi, "input_spec", &sp_input_spec);
    L_read_parm_s(ppi, "output_spec", &sp_output_spec);
    /* ITI (JCG) - 2/10/99 */
    L_read_parm_b(ppi, "create_layout_info_generator",
		  &sp_create_layout_info_generator);
    L_read_parm_s(ppi, "layout_info_desc", &sp_layout_info_desc);
    L_read_parm_b(ppi, "group_global_vars", &group_global_vars);
}

/*
 *      Read in parameters
 */
ReadParms(argc, argv, envp)
int argc;
char** argv;
char** envp;
{
    char *prog_name;                /* program name */
    char *P_parm_file;

    /* get program arguments */
    prog_name = *argv;

    P_parm_file = L_get_std_parm_name(argv, envp, "STD_PARMS_FILE",
				      "./STD_PARMS");

    L_load_parameters(P_parm_file,
		      L_create_external_macro_list(argv, envp),
		      "(Pcode", P_read_parm_Pcode);
    
    L_load_parameters(P_parm_file,
		      L_create_external_macro_list(argv, envp),
		      "(Psplit", P_read_parm_Psplit);
    
    /* BCC/ITI - 2/10/99 */
    if (resolve_machine_dependent_information) {
	/* 
	 * BCC - 4/2/96
	 * In order to invode Mspec, so needs to know $arch and $model 
	 */
	/* Renamed 'architecture' to 'Larchitecture' -JCG 5/26/98 */
	L_load_parameters_aliased (P_parm_file,
				   L_create_external_macro_list(argv, envp),
				   "(Larchitecture", "(architecture", 
				   P_read_parm_arch);
	
	/* 
	 * BCC - 4/2/96
	 * Now set the machine related information 
	 */
	M_set_machine(P_arch, P_model);
	
	/* 
	 * BCC - 4/2/96
	 * Then get the size of each integer type
	 */
	P_GetIntegerSize(); 
    }

    if (!strcmp(sp_output_format_string, "Pcode")) 
	sp_output_form = OUTPUT_PCODE;
    else if (!strcmp(sp_output_format_string, "Hcode")) 
	sp_output_form = OUTPUT_HCODE;
    else if (!strcmp(sp_output_format_string, "None")) {
	sp_output_form = OUTPUT_NONE;
	do_flatten = 0;
	fast_mode = 1;
    }
    else Punt("Illegal output format for Psplit");
}

main(argc, argv, envp)
int argc;
char **argv;
char **envp;
{
    char file_name[256];

    /*
     *  Read parms
     */
    ReadParms(argc, argv, envp);
    /*
     *  Open output spec.
     */
    Fmapping = fopen(sp_output_spec, "w");
    Ffile = fopen("impact_filelist", "w");
    if (Fmapping==0) Punt("cannot open output_spec file");
    /*
     *  Read input spec.
     */
    ReadInputSpec(sp_input_spec);
    /*
     *  Open output files
     */
    /* BCC - assume the directory is already there - 5/4/96 */
#if 0
    MakeImpactDirectory();
#endif

    struct_union_tbl = STRING_new_symbol_table("struct_union_tbl", 1024);
    dummy_struct_union_tbl = STRING_new_symbol_table("dummy_struct_union_tbl", 
						     1024);
    switch (sp_output_form) {
	case OUTPUT_PCODE:
	    if (group_global_vars) {
		/* BCC  use the new convention .pcs to name the file  5/4/96 */
		sprintf(file_name, "%s/data.pcs", sp_output_dir_string);
		Fdata = fopen(file_name, "wt");
		if (Fdata == 0) Punt("Can't open output data file");
		fprintf(Fdata, "( INCLUDE \"extern.pch\")\n");
		/* BCC  put the data file filename to impact_mapping  11/9/95 */
		fprintf(Fmapping, "(data %s)\n", file_name);
	    }

	    sprintf(file_name, "%s/extern.pch", sp_output_dir_string);
	    Fextern = fopen(file_name, "wt");
	    if (Fextern == 0) Punt("Can't open output extern file");
	    fprintf(Fextern, "( INCLUDE \"struct.pch\")\n");
	    /* BCC - put the extern file filename to impact_mapping - 11/9/95 */
	    fprintf(Fmapping, "(extern %s)\n", file_name);

	    sprintf(file_name, "%s/struct.pch", sp_output_dir_string);
	    Fstruct = fopen(file_name, "wt");
	    if (Fstruct == 0) Punt("Can't open output struct file");
	    /* BCC - put the struct file filename to impact_mapping - 11/9/95 */
	    fprintf(Fmapping, "(struct %s)\n", file_name);

	    break;
	case OUTPUT_HCODE:
	    if (group_global_vars) {
		/* BCC  use the new convention .pcs to name the file  5/4/96 */
		sprintf(file_name, "%s/data.hcs", sp_output_dir_string);
		Fdata = fopen(file_name, "wt");
		if (Fdata == 0) Punt("Can't open output data file");
		fprintf(Fdata, "( INCLUDE \"extern.hch\")\n");
		/* BCC  put the data file filename to impact_mapping  11/9/95 */
		fprintf(Fmapping, "(data %s)\n", file_name);
	    }

	    sprintf(file_name, "%s/extern.hch", sp_output_dir_string);
	    Fextern = fopen(file_name, "wt");
	    if (Fextern == 0) Punt("Can't open output extern file");
	    fprintf(Fextern, "( INCLUDE \"struct.hch\")\n");
	    /* BCC - put the extern file filename to impact_mapping - 11/9/95 */
	    fprintf(Fmapping, "(extern %s)\n", file_name);

	    sprintf(file_name, "%s/struct.hch", sp_output_dir_string);
	    Fstruct = fopen(file_name, "wt");
	    if (Fstruct == 0) Punt("Can't open output struct file");
	    /* BCC - put the struct file filename to impact_mapping - 11/9/95 */
	    fprintf(Fmapping, "(struct %s)\n", file_name);

	    break;
	case OUTPUT_NONE:
	    sprintf(file_name, "functype.pch");
	    Fextern = fopen(file_name, "wt");
	    if (Fextern == 0) Punt("Can't open functype file");

	    break;
	default:
	    Punt("Illegal output format for Psplit");
    }

    /* 
     *  Inform Pcode now is doing spliting 
     */
    split = 1;
    /*
     *  Process files one by one.
     */
    ProcessFiles();

    /* 
     * If generating gen_host_layout_info.c, make sure PrintStruct()
     * is called even if there are no structures or global variables
     * defined. -ITI (JCG) 2/99 
     */
    if (sp_create_layout_info_generator)
	PrintLayoutInfo();
    
    /* 
     *  Close output files
     */
    PrintGlobal();
    /* Make sure file pointers are not NULL! -JCG 5/99 */
    if (Fdata != NULL)
	fclose(Fdata);
    if (Fextern != NULL)
	fclose(Fextern);
    if (Fstruct != NULL)
	fclose(Fstruct);
    if (Fmapping != NULL)
	fclose(Fmapping);
    if (Ffile != NULL)
	fclose(Ffile);
    STRING_delete_symbol_table(struct_union_tbl, 0);
    STRING_delete_symbol_table(dummy_struct_union_tbl, 0);
    return 0;
}

