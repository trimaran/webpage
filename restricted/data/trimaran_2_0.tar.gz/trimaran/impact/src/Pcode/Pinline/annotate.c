/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   annotate.c
 *      Author: Ben-Chung Cheng, Wen-mei Hwu
\*****************************************************************************/


#include <stdio.h>
#include <string.h>
#include <library/list.h>
#include "inline.h"

static int arc_id = 1;

static Add_Callname_Pragmas(expr, var_name)
Expr expr;
char *var_name;
{
    AliasInfo alias;
    CalleeInfo callee;
    Pragma pragma;

    if (ActiveCG_Node->alias == NIL) {
	return;
    }
    alias = ActiveCG_Node->alias;
    while (alias) {
	if (!strcmp(var_name, alias->name)) break;
	alias = alias->next;
    }
    if (alias == NIL) {
	if (print_inline_stats) {
	    fprintf(Flog, "No alias info with this callee\n");
	    fprintf(Flog, "Call site name : %s\n", ActiveCG_Node->funcname);
	    fprintf(Flog, "Callee name : %s\n", var_name);
	}
	return;
    }
    callee = alias->callee;
    while (callee) {
	char str[256];
	int dup;

        sprintf(str, "\"%s\"", callee->name);
	pragma = expr->pragma;
	dup = 0;
	while (pragma) {
	    if (!strcmp(pragma->specifier, "\"CALL\"") && 
		!strcmp(pragma->expr->value.string, str)) {
		dup = 1;
		break;
	    }
	    pragma = pragma->next;
	}
	if (dup == 0) {
	    /* BCC - garbage collection - 8/25/96 */
    	    Expr exp;
	    exp = NewStringExpr(C_findstr(str));
	    AddExprPragma(expr, "\"CALL\"", exp);
	    RemoveExpr(exp);
	}
	callee = callee->next;
    }
}

static void Add_CG_Arc(expr, direct, first_op_weight)
Expr expr;
int direct;
double first_op_weight;
{
    int dummy;
    char *func_name;
    CG_Node cg_node;
    Pragma pragma;
    CG_Arc new_arc;
    double weight, key;

    if (expr->profile != NIL) 
	weight = expr->profile->count;
    else {
	if (size_only == 0)
	    weight = 0.0;
	else
	    weight = 1.0;
    }
    if (size_only == 0) {
	if (expr->profile == NIL || 
	    expr->profile->count <= min_expansion_weight) {
	    /* remove the arc_id of the insignificant function */
	    pragma = FindExprPragma(expr, "\"ARC_ID\"");
	    if (pragma) RemoveExprPragma(expr, pragma);
	}
    }
    if (direct == 1) {		
	assert(expr->operands->opcode == OP_var);
	func_name = expr->operands->value.var_name;

	if (C_find(mapping_table_ID,func_name,0,&dummy,(Pointer *)&cg_node)) {
	    /* BCC - record indirect weight - 10/23/96 */
	    if (find_indirect_weight && weight > 0.0) 
		cg_node->indir_weight += weight;
	    /* vararg function */
	    if (cg_node->noninlinable) return;

	    /* Don't inline other functions after inlining itself. That is, 
	       after inlining self-recursion, only inling of itself is allowed.
	    */
	    if (ActiveCG_Node->myself > 1.0 && cg_node != ActiveCG_Node) return;
	}
	/* don't put library calls to the heap. e.g., printf() */
	else return;	
    }
    else {
	if (print_inline_stats)
	    fprintf(Flog, "*** Call through pointer is encountered in %s ***\n",
		    ActiveCG_Node->funcname);
	cg_node = 0;
    }
    if (weight == 0.0) return;	/* insignificant function */
    pragma = FindExprPragma(expr, "\"ARC_ID\"");
    if (pragma == NIL) {
	/* BCC - garbage collection - 8/25/96 */
        Expr exp;
	exp = NewIntExpr(arc_id);
	AddExprPragma(expr, "\"ARC_ID\"", exp);
	RemoveExpr(exp);
    }
    else 
	pragma->expr->value.scalar = arc_id;		/* Recycle old pragma */
    new_arc = NewCG_Arc();
    new_arc->status = 0;
    new_arc->arc_id = arc_id++;
    new_arc->callsite = ActiveCG_Node;
    new_arc->callee = cg_node;
    if (size_only == 0)
	new_arc->weight = weight = expr->profile->count;	/* arc weight */
    else
	new_arc->weight = 1;
    /* 
     * In a chain of call nodes, postpone the inline expansion of 
     * self-recursive or indirect calls because they will block out the
     * chance of the subsquent inline expansions 
     */
    if (RECURSIVE(new_arc) || INDIRECT(new_arc)) 
	weight *= 0.8;
    /* expr_w / node_w */
    new_arc->fraction = new_arc->weight / new_arc->callsite->weight;	

    /* absorbed portion */
    new_arc->discount = new_arc->callsite->discount * new_arc->fraction;  

    /* ratio of the current call to the first op */
    if (size_only == 0 && 
	first_op_weight == 0.0 && 
	new_arc->weight != 0.0) {
	if (print_inline_stats)
	    fprintf(Flog, 
		"Warning : first_op weight is zero but the call arc isn't\n");
    }
    new_arc->ratio = new_arc->weight / first_op_weight;

    /* Link the arc to the callsite */
    if (ActiveCG_Node->last == 0) 
	ActiveCG_Node->first = ActiveCG_Node->last = new_arc;
    else {
	new_arc->prev = ActiveCG_Node->last;
	ActiveCG_Node->last->next = new_arc;
	ActiveCG_Node->last = new_arc;
    }
    key = keyof(new_arc);
    Heap_Insert(arc_heap, new_arc, key);
}

static void Annotate_Call_Expr(stmt, first_op_weight, no_inline)
Stmt stmt;
double first_op_weight;
int no_inline;
{
    char *var_name;
    Expr expr = stmt->stmtstruct.expr;
    Expr indr, callee;
    Pragma pragma;

    if (expr->next != NIL) return;   /* expr list "a(),b()" won't be inlined */
    switch (expr->opcode) {
	case OP_call:	/* inlining a() */
	    /* The following code works as follows:
	     * 1) no_inline == 0 : Normally annotating. If a "DONTINLINE" arc
	     *    is found, just quit.
	     * 2) no_inline == 1 : Used to annotate arcs to be "DONTINLINE".
	     *    If a arc is found without "DONTINLINE", add "DONTINLINE" to it
	     */
	    if (no_inline == 0) {
		if (FindExprPragma(expr, "\"DONTINLINE\"")) { 
		    pragma = FindExprPragma(expr, "\"ARC_ID\"");
		    if (pragma) RemoveExprPragma(expr, pragma);
		    return;
		}
	    }
	    else {
		if (FindExprPragma(expr, "\"DONTINLINE\"") == 0) {
		    /* BCC - garbage collection - 8/25/96 */
		    Expr exp;
		    exp = NewIntExpr(0);
		    AddExprPragma(expr, "\"DONTINLINE\"", exp);
		    RemoveExpr(exp);
		}
		pragma = FindExprPragma(expr, "\"ARC_ID\"");
		if (pragma) RemoveExprPragma(expr, pragma);
		return;
	    }
	    /* annotating call through pointer */
	    indr = GetOperand(expr, 1);
	    switch (indr->opcode) {
	    	case OP_var:		/* direct call */
		    Add_CG_Arc(expr, 1, first_op_weight);
		    break;
		case OP_indr:		/* indirect call */
		    /* BCC - don't insert indirect callsites 
		    Add_CG_Arc(expr, 0, first_op_weight);
		    */
		    break;
		case OP_compexpr:	/* should reduce (foo)() to foo() */
		    if (print_inline_stats)
			fprintf(Flog, "Warning: Unflattened function call\n");
		    break;
		default:
		    if (print_inline_stats)
			fprintf(Flog, "Error: Illegal call expr : %d\n", 
				indr->opcode);
		    exit(1);
	    }
	    break;
	case OP_assign:	/* inlining b = a(); */
	    {
		Expr op1, op2;

		op1 = GetOperand(expr, 1);
		op2 = GetOperand(expr, 2);
		if (op2->opcode != OP_call) return;
		/* The following code is explained as above */
		if (no_inline == 0) {
		    if (FindExprPragma(op2, "\"DONTINLINE\"")) {
			pragma = FindExprPragma(op2, "\"ARC_ID\"");
			if (pragma) RemoveExprPragma(op2, pragma);
			return;
		    }
		}
		else {
		    if (FindExprPragma(op2, "\"DONTINLINE\"") == 0) {
			/* BCC - garbage collection - 8/25/96 */
			Expr exp;
			exp = NewIntExpr(0);
			AddExprPragma(op2, "\"DONTINLINE\"", exp);
			RemoveExpr(exp);
		    }
		    pragma = FindExprPragma(op2, "\"ARC_ID\"");
		    if (pragma) RemoveExprPragma(op2, pragma);
		    return;
		}
		/* annotating call through pointer */
		indr = GetOperand(op2, 1);
		switch (indr->opcode) {
		    case OP_var:	/* direct call */
			Add_CG_Arc(op2, 1, first_op_weight);
		    	break;
		    case OP_indr:
			/* BCC - don't insert indirect callsites 
			Add_CG_Arc(op2, 0, first_op_weight);
			*/
			break;
		    case OP_compexpr:	/* should reduce (foo)() to foo() */
			if (print_inline_stats)
			    fprintf(Flog, 
				    "Warning: Unflattened function call\n");
			break;
		    default:
			if (print_inline_stats)
			    fprintf(Flog, "Error: Illegal call expr : %d\n",
				    indr->opcode);
			exit(1);
		}
		break;
	    }
    }
}

static void Find_Call_Exprs(stmt, first_op_weight, no_inline)
Stmt stmt;
double first_op_weight;
int no_inline;
{
    SerLoop serloop;
    ParLoop parloop;

    while (stmt != NIL) {
	if (ActiveCG_Node->weight == 0.0 && stmt->profile)  
	    ActiveCG_Node->weight = stmt->profile->count;
        switch (stmt->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
            case ST_RETURN:
                break;
            case ST_COMPOUND:
                Find_Call_Exprs(stmt->stmtstruct.compound->stmt_list, 
				first_op_weight, no_inline);
                break;
            case ST_IF:
                Find_Call_Exprs(stmt->stmtstruct.ifstmt->then_block,
				first_op_weight, no_inline);
                if (stmt->stmtstruct.ifstmt->else_block != NIL)
                    Find_Call_Exprs(stmt->stmtstruct.ifstmt->else_block,
				    first_op_weight, no_inline);
                break;
            case ST_SWITCH:
                Find_Call_Exprs(stmt->stmtstruct.switchstmt->switchbody,
				first_op_weight, no_inline);
                break;
            case ST_EXPR:
		if (ActiveCG_Node->weight == 0.0 && 
		    stmt->stmtstruct.expr->profile) 
		    ActiveCG_Node->weight=stmt->stmtstruct.expr->profile->count;
		    Annotate_Call_Expr(stmt, first_op_weight, no_inline);
                break;
            case ST_PSTMT:
                Find_Call_Exprs(stmt->stmtstruct.pstmt->stmt,
				first_op_weight, no_inline);
		break;
            case ST_MUTEX:
                Find_Call_Exprs(stmt->stmtstruct.mutex->statement,
				first_op_weight, no_inline);
                break;
            case ST_COBEGIN:
                Find_Call_Exprs(stmt->stmtstruct.cobegin->statements,
				first_op_weight, no_inline);
                break;
            case ST_SERLOOP:
                serloop = stmt->stmtstruct.serloop;
                Find_Call_Exprs(serloop->loop_body, first_op_weight, no_inline);
                break;
            case ST_PARLOOP:
                parloop = stmt->stmtstruct.parloop;
                Find_Call_Exprs(Parloop_Stmts_Prologue_Stmt(stmt),
				first_op_weight, no_inline);
                break;
            case ST_BODY:
                Find_Call_Exprs(stmt->stmtstruct.bodystmt->statement,
				first_op_weight, no_inline);
                break;
            case ST_EPILOGUE:
                Find_Call_Exprs(stmt->stmtstruct.epiloguestmt->statement,
				first_op_weight, no_inline);
                break;
            default:
                Punt("Find_Call_Exprs: Invalid statement type", stmt);
        }
        stmt = stmt->lex_next;
    }
}

void PreprocessFunc(func, no_inline)
FuncDcl func;
int no_inline;
{
/*
 * BCC - 3/7/96
 * foo1()
 * {
 *	foo2()
 *	{
 *		first_op;
 *		another call;
 *	}
 * }
 *
 * Purpose : (1) get the weight of the first op of foo2
 *	     (2) mesure the body size and stack size of the function
 */
    Stmt stmt;

    if (ActiveCG_Node->bodysize == 0 && ActiveCG_Node->stacksize == 0) {
	VarList var_list;

	StackSize = BodySize = 0;
	MeasureFunctionSize(func);
	ActiveCG_Node->bodysize = BodySize;
	ActiveCG_Node->stacksize = StackSize;
	TotalBodySize += BodySize;
	TotalStackSize += StackSize;
	if (print_inline_stats)
	    fprintf(Flog, "Bodysize  = %d\nStackSize = %d\n", 
		    BodySize, StackSize);
        
	/* BCC - calculate the number of parms - 4/21/96 */
	var_list = func->param;
	ActiveCG_Node->num_parms=0;
	while (var_list) {
	    ActiveCG_Node->num_parms++;
	    var_list = var_list->next; 
	}

	/* BCC - determine if the function is a vararg func - 4/21/96 */
	ActiveCG_Node->vararg = IsVarargCallee(func);
    }

    /* BCC - for Brian's experiment - 9/9/97 */
    if (size_only == 0) {
	stmt = func->stmt->stmtstruct.compound->stmt_list;
	while (stmt && stmt->profile == 0) {
	    switch (stmt->type) {
		case ST_COMPOUND : 
		    stmt = stmt->stmtstruct.compound->stmt_list;
		    break;
		case ST_NOOP :
		    stmt = stmt->lex_next;
		    break;
		default :
		    Punt("Need to extend annotate.c");
		    break;
	    }
	}

	if (stmt == 0)
	    Find_Call_Exprs(func->stmt, (double) 0.0, no_inline);
	else
	    Find_Call_Exprs(func->stmt, stmt->profile->count, no_inline);
    }
    else {
	ActiveCG_Node->weight = 1.0;
	Find_Call_Exprs(func->stmt, (double) 1.0, no_inline);
    }
}

