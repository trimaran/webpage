/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.30  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 14, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	parms.c
 *	Author:	David August, Grant Haab, Nancy Warter and Wen-mei Hwu
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <Pcode/parms.h>
#include <library/l_parms.h>

/*
 * 	This file is used to process the Pcode execution parameters.
 */
char *F_input = "stdin";		/* program input */
FILE *Fin = NULL;
char *F_hcode_output = "stdout";	/* used internally, do not use */
char *F_pcode_output = "stdout";	/* used internally, do not use */
char *F_nm_output = "stdout";		/* BCC - 10/7/96 */
char *F_output = "stdout";		/* program output */
FILE *Fout = NULL;
char *F_output2 = "stdout";		/* program output */
FILE *Fout2 = NULL;
char *F_out_ip = "impact.pc.ip";
FILE *Fout_ip;
char *F_input_ip = "impact.pc.ip1";
FILE *Finput_ip;
char *F_error = "stderr";		/* error file */
FILE *Ferr = NULL;
char *F_log = "stderr";			/* log file */
FILE *Flog = NULL;
char *F_out_gvar = "impact.pc.gvar";	/* BCC - 2/25/97 */
FILE *Fout_gvar;

char *F_stat_pcode = "stderr";	 /* file to record statistics for Pcode */
FILE *Fstpcode = NULL;

char *F_annot = "stdin";	/* file with annotation info */
FILE *Fannot = NULL;
char *F_annot_index = "stdin";	/* file with annotation info */
FILE *Fannot_index = NULL;
char *F_pcode_position = "stdout"; /* file for pcode positions/profile info */
FILE *Fpcode_position = NULL;

/* LCW - file handler for probing information and profiling files  - 10/12/95 */
FILE *Fallprobe;
FILE *Fdump_probe_code;
FILE *Fprofile;
FILE *Fnull;  /* LCW - 2/19/96 */

int debug_yes = FALSE;		/* do all checks */
int verbose_yes = FALSE;	/* be verbose */
int line_yes = FALSE;		/* include line #'s in output */
int static_array = TRUE;   	/* make local arrays static */
int do_dependence = FALSE;   	/* force dependence analysis for debugging */
int parallel_flag = FALSE;  	/* parallelize and report pstmt errors */
int print_pcode_stats = FALSE;	/* print out number of top-level pcode defs
				   and dcls */
int hcode_loop_prags = FALSE;	/* generate loop type prag info, Hcode output */
int hcode_swp_prags = FALSE;	/* Generate SWP_INFO pragmas, Hcode output. */
int hcode_loop_sim_prags = FALSE;/* generate loop sim prag info, Hcode output*/
int hcode_func_prags = FALSE;	/* generate function pragma info, Hcode output*/
int hcode_dep_prags = FALSE;    /* generate dependence expression pragma info,
				   Hcode output*/
int hcode_static_prof = FALSE;	/* generate static profile information in
				   Hcode output*/
double hcode_stat_loop_weight = 10.0;
				/* estimated number of loop iters for static 
				   profile for Hcode */
double hcode_stat_func_weight = 100.0;
				/* estimated number of func invok. for static 
				   profile for Hcode */
int do_merge_profiling = FALSE; /* merge Lcode profiling back into Pcode */
int do_dep_anal_for_C = FALSE; /* if true, allow dep anal for non-fortran progs;
				   do not use simplifying Fortran
                                   assumptions for dependence analysis */
                                /* Convert for loops to doserial for C code */
int do_loop_conversion_on_C = FALSE;
int loop_conv_if_unpromoted_iter_var = TRUE;  /* for Fortran programs, convert
                                                 loop even if address of the
                                                 iteration variable is taken */
int pcode_nice_value = 10;    /* automatic renice value for Pcode executable*/

int generate_gvar_address_taken = FALSE;
int generate_intraprocedural_data = FALSE;    /* BCC 11/13/97 */

int generate_jsr_dependences = TRUE;

bool OPEN_STAT_PCODE = FALSE;

/* show loop transformations in log file */
int DEMO_OUTPUT = FALSE;
/* warn about possibly uninitialized automatic variables */
int warn_uninitialized_automatic_vars = FALSE;

int DEBUG_GEN_PCODE = FALSE;
int DEBUG_GEN_HCODE = FALSE;
int DEBUG_GEN_CHARLIE = FALSE;
int DEBUG_PRINT_PCODE = FALSE;
int DEBUG_INIT = FALSE;
int DEBUG_LINKS = FALSE;
int DEBUG_FUNC = FALSE;
int DEBUG_SYMTREE = FALSE;
/* BCC - 1/7/96 */
int DEBUG_FLATTENING = FALSE;

int output_form = OUTPUT_NONE;	/* the style of the output */

int trans_named_funcs_only = FALSE; /* for debugging transformations */
char *named_funcs_to_trans = "";    /* if above TRUE, list of function names */

/* character strings for parsing parameters into configuration variables */
char *output_format_string;
char *transform_string;

/* BCC - for flattening - 11/26/95 */
int do_flatten = FALSE;

/* BCC - interface for Mspec - 6/12/95 */
char *P_arch="impact";
char *P_model="v1.0";
char *P_lmdes_file_name=0;

/* BCC - no CFG, no analysis, no cast, no reduce, just plain translation - 11/6/96 */
int fast_mode=FALSE;

/* LCW - flag for probe insertion for Pcode profiler - 10/06/95 */
int DO_INSERT_PROBE = 0;

/* LCW - flag for annotating Pcode - 10/21/95 */
int DO_ANNOTATE_PCODE = 0;

/* LCW - flag for inserting pseudo probe which pass probe id numbers to Lcode.
 * When this flag is set, DO_INSERT_PROBE will also be set - 10/24/96
 */
int DO_INSERT_PSEUDO_PROBE = 0;

/* LCW - flags for loop trip count profiling - 3/24/99 */
int DO_INSERT_LOOP_TRIP_COUNT_PROBE = 0;
int DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT = 0;

/* LCW - flag for emitting source information (file name, scope number,
   line number, etc) to Hcode - 7/24/97 */
int EMIT_SOURCE_INFO = 0;

/* BCC - reorganized parameters for dependence analysis in Pcode - 11/9/97 */
int multi_alias_relation = 0;         /* turn on multi-alias relations */
int generate_access_name = 0;         /* generate access names only */
int generate_access_name_by_type = 0; /* generate access type names only */
int remove_dead_function = 0;         /* remove dead functions */

int build_acc_tbl = 0;                /* internal parameter */
int calculate_alias = 0;              /* internal parameter */
/* BCC/ITI - for brand names - 1/29/99 */
int verify_brand_names = 0;
/* BCC/ITI - for processing layout.c - 2/10/99 */
int resolve_machine_dependent_information = 1;

/* GEH - changed to match new function in Lcode/Lcode/l_error.c */
/*void L_punt (char *fmt, ...)
{
    va_list     args;

    va_start (args, fmt);
    vfprintf (Ferr, fmt, args);
    va_end(args);
    fprintf (Ferr,"\n");
    exit (-1);
}*/

void P_read_parm_Pcode(ppi)
    Parm_Parse_Info *ppi;
{

        /* Parameter file configuration - these parms must be read first */
    L_read_parm_b (ppi, "warn_parm_not_defined", &L_warn_parm_not_defined);
    L_read_parm_b (ppi, "warn_parm_defined_twice", &L_warn_parm_defined_twice);
    L_read_parm_b (ppi, "warn_parm_not_used", &L_warn_parm_not_used);
    L_read_parm_b (ppi, "dump_parms", &L_dump_parms);
    L_read_parm_s (ppi, "parm_warn_file_name", &L_parm_warn_file_name);
    L_read_parm_s (ppi, "parm_dump_file_name", &L_parm_dump_file_name);

    L_read_parm_s(ppi, "input_file", &F_input);
    L_read_parm_s(ppi, "hcode_output_file", &F_hcode_output);
    L_read_parm_s(ppi, "pcode_output_file", &F_pcode_output);
    L_read_parm_s(ppi, "nm_output_file", &F_nm_output);
    L_read_parm_s(ppi, "log_file", &F_log);
    L_read_parm_s(ppi, "error_file", &F_error);
    L_read_parm_s(ppi, "pcode_statistics_file", &F_stat_pcode);
    L_read_parm_s(ppi, "annot_file", &F_annot);
    L_read_parm_s(ppi, "annot_index_file", &F_annot_index);
    L_read_parm_s(ppi, "pcode_position_file", &F_pcode_position);
    L_read_parm_b(ppi, "debug_log", &debug_yes);
    L_read_parm_b(ppi, "verbose_log", &verbose_yes);
    L_read_parm_s(ppi, "output_file_format", &output_format_string);

    /* BCC - for flattening - 11/26/95 */
    L_read_parm_b(ppi, "do_flatten", &do_flatten);

    /* BCC - fast mode - 11/6/96 */
    L_read_parm_b (ppi, "fast_mode", &fast_mode);

    L_read_parm_b(ppi, "generate_source_pos_in_output", &line_yes);
    L_read_parm_b(ppi, "generate_p_statement_warnings",&parallel_flag);
    L_read_parm_b(ppi, "make_local_arrays_static", &static_array);
    L_read_parm_b(ppi, "print_pcode_statistics", &print_pcode_stats);
    L_read_parm_lf(ppi, "hcode_static_loop_weight", &hcode_stat_loop_weight);
    L_read_parm_lf(ppi, "hcode_static_func_weight", &hcode_stat_func_weight);
    L_read_parm_b(ppi, "do_merge_profiling", &do_merge_profiling);
    L_read_parm_b(ppi, "do_dep_anal_for_C", &do_dep_anal_for_C);
    L_read_parm_b(ppi, "generate_gvar_address_taken", 
			&generate_gvar_address_taken);
    L_read_parm_b(ppi, "do_loop_conv_if_unpromoted_iter_var", 
                                          &loop_conv_if_unpromoted_iter_var);
    L_read_parm_i(ppi, "nice_value", &pcode_nice_value);
    L_read_parm_s(ppi, "transformation_list", &transform_string);
    L_read_parm_b(ppi, "debug_trans_named_funcs_only", &trans_named_funcs_only);
    L_read_parm_s(ppi, "debug_named_funcs_to_trans", &named_funcs_to_trans);
    L_read_parm_b(ppi, "log_demo_output", &DEMO_OUTPUT);
    L_read_parm_b(ppi, "warn_uninitialized_vars", &warn_uninitialized_automatic_vars);
    L_read_parm_b(ppi, "debug_gen_pcode", &DEBUG_GEN_PCODE);
    L_read_parm_b(ppi, "debug_gen_hcode", &DEBUG_GEN_HCODE);
    L_read_parm_b(ppi, "debug_gen_charlie", &DEBUG_GEN_CHARLIE);
    L_read_parm_b(ppi, "debug_print_pcode", &DEBUG_PRINT_PCODE);
    L_read_parm_b(ppi, "debug_links", &DEBUG_LINKS);
    L_read_parm_b(ppi, "debug_init", &DEBUG_INIT);
    L_read_parm_b(ppi, "debug_func", &DEBUG_FUNC);
    L_read_parm_b(ppi, "debug_symtree", &DEBUG_SYMTREE);
    /* BCC - 1/7/97 */
    L_read_parm_b(ppi, "debug_flattening", &DEBUG_FLATTENING);
    /* LCW - parameters for probing and profiling - 10/25/95 */
    L_read_parm_b(ppi, "do_insert_probe", &DO_INSERT_PROBE);
    L_read_parm_b(ppi, "do_annotate_pcode", &DO_ANNOTATE_PCODE);
    /* LCW - pseudo probes which propagate probe numbers to Lcode - 10/24/96 */
    L_read_parm_b(ppi, "do_insert_pseudo_probe", &DO_INSERT_PSEUDO_PROBE);
    /* LCW - parameters for loop trip count profiling - 3/24/99 */
    L_read_parm_b(ppi, "do_insert_loop_trip_count_probe", &DO_INSERT_LOOP_TRIP_COUNT_PROBE);
    L_read_parm_b(ppi, "do_annotate_pcode_with_loop_trip_count", &DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT);
    /* LCW - emitting source information - 7/24/97 */
    L_read_parm_b(ppi, "emit_source_info", &EMIT_SOURCE_INFO);
    /* BCC - 2/26/97 */
    L_read_parm_i(ppi, "multi_alias_relation", &multi_alias_relation);
    L_read_parm_i(ppi, "generate_access_name", &generate_access_name);
    L_read_parm_i(ppi, "generate_access_name_by_type", 
                  &generate_access_name_by_type);
    /* BCC - 10/24/97 */
    L_read_parm_b(ppi, "remove_dead_function", &remove_dead_function);
    /* BCC/ITI - 1/29/99 */
    L_read_parm_b(ppi, "verify_brand_names", &verify_brand_names);
    /* BCC/ITI - 2/9/99 */
    L_read_parm_b(ppi, "resolve_machine_dependent_information", 
		  &resolve_machine_dependent_information);
}

void P_read_parm_arch(ppi)
    Parm_Parse_Info *ppi;
{
    /* BCC - machine arch and model - 6/12/95 */
    L_read_parm_s(ppi, "arch", &P_arch);
    L_read_parm_s(ppi, "model", &P_model);
    L_read_parm_s(ppi, "lmdes", &P_lmdes_file_name);
}

