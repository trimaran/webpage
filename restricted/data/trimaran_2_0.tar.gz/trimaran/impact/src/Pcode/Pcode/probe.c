/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.20  */
/* IMPACT Trimaran Release (www.trimaran.org)                  May 17, 1999  */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   probe.c
 *      Author: Le-Chun Wu and Wen-mei Hwu
\*****************************************************************************/
       

#include <stdlib.h>
#include <string.h>
#include <Pcode/gen_hcode.h>
#include <Pcode/probe.h>
#include <Pcode/parms.h>

#define PROBE_ARRAY_SIZE 100

FILE *Fprvprobe;
FILE *Fprvloopid;

char *probe_array_name = "_imp_probe_array";
int next_probe = 0;
int next_probe_BB;
int next_loop_id = 0; /* LCW - 3/24/99 */
int lp_id_counter_diff = 0;

/* LCW - some external functions for loop iter count profiling - 3/29/99 
 * JCG - updated after filled in routines functionality -4/99 */
extern int PP_get_loop_max_iter_id(int loop_id);
extern int PP_get_loop_max_input_id();
extern int PP_get_loop_iter_count(int loop_id, int iter_id);
extern double PP_get_loop_iter_avg_exec(int loop_id, int iter_id);
extern double PP_get_loop_iter_input_exec(int loop_id, int iter_id,
					  int input_id);


/*
void gen_probe_declare(F, func_name)
FILE *F;
char *func_name;
{
   next_probe = 0;
   probe_array_name = (char *)malloc(strlen(func_name)+15);
   sprintf(probe_array_name, "_%s_count_probe", func_name);
   fprintf(F, "(GVAR %s ((GLOBAL)(INT)((A (signed ", probe_array_name);
   fprintf(F, "%d))))\n", PROBE_ARRAY_SIZE);
   fprintf(F, " (AGGR (signed 0)))\n");
}
*/

void insert_middle_probe(F, probe_no)
FILE *F;
int probe_no;
{
   /* LCW - insert either a pseudo probe or a real one - 10/24/96 */
   if (DO_INSERT_PSEUDO_PROBE)
     fprintf(F, "(nulldefine (EXPR_PRAGMA \"PCODE_PROBE\\%%%d\"))", probe_no);
   else
     fprintf(F, "(postinc (index (var %s) (signed %d)))", probe_array_name,
		probe_no);
}

void insert_probe(F, probe_no)
FILE *F;
int probe_no;
{
   fprintf(F, "\t");
   insert_middle_probe(F, probe_no);
   fprintf(F, "\n");
}


void PP_gen_init_c_code(array_size, loop_no)
{
   fprintf(Fdump_probe_code, "#include <stdio.h>\n");
   fprintf(Fdump_probe_code, "#include <stdlib.h>\n");
   fprintf(Fdump_probe_code, "int _PP_is_initialized = 0;\n");
   fprintf(Fdump_probe_code, "long int %s[%d] = {0};\n", probe_array_name, 
	   array_size);
   fprintf(Fdump_probe_code, "extern struct _PP_iter_table;\n");
   fprintf(Fdump_probe_code, "extern void _PP_dump_probe_init();\n");
   fprintf(Fdump_probe_code, "extern void _PP_dump_probe_array();\n");
   fprintf(Fdump_probe_code, "extern void _PP_dump_loop_iter_init();\n");
   fprintf(Fdump_probe_code, "extern void _PP_dump_loop_iter_table();\n");
   fprintf(Fdump_probe_code, "void _PP_initialize()\n");
   fprintf(Fdump_probe_code, "{\n");
   fprintf(Fdump_probe_code, "   if (_PP_is_initialized)\n");
   fprintf(Fdump_probe_code, "      return;\n");
   fprintf(Fdump_probe_code, "   _PP_is_initialized = 1;\n");
   /* don't need to dump probe array when inserting pseudo probes */
   if (! DO_INSERT_PSEUDO_PROBE) {
      if (DO_INSERT_PROBE)
      {
	 fprintf(Fdump_probe_code, "   _PP_dump_probe_init(%s, %d);\n", 
		 probe_array_name, array_size);
	 fprintf(Fdump_probe_code, "   atexit(_PP_dump_probe_array);\n");
      }
      if (DO_INSERT_LOOP_TRIP_COUNT_PROBE) {
	 fprintf(Fdump_probe_code, "   _PP_dump_loop_iter_init(%d);\n", 
		 loop_no);
	 fprintf(Fdump_probe_code, "   atexit(_PP_dump_loop_iter_table);\n");
      }
   }
   fprintf(Fdump_probe_code, "}\n");
}


#if 0  /* LCW - this function is not needed anymore - 3/25/99 */
void gen_call_dump_probe_array(F)
FILE *F;
{
   fprintf(F, "\t(call (var atexit) (addr (var _dump_probe_array)))\n");
}
#endif

#if 0  /* LCW - we don't automatically generate function _dump_probe_array
	  anymore. Instead, this function will be put in the library and
	  we will generate _PP_initialize automatically - 3/25/99 */
void gen_dump_probe_code(array_size)
int array_size;
{
   fprintf(Fdump_probe_code, "#include <stdio.h>\n");
   fprintf(Fdump_probe_code, "int _PP_initialized = 0;\n"); /* LCW -3/25/99 */
   fprintf(Fdump_probe_code, "long int %s[%d] = {0};\n", probe_array_name, 
		array_size);
   fprintf(Fdump_probe_code, "void _dump_probe_array()\n");
   fprintf(Fdump_probe_code, "{\n");
   fprintf(Fdump_probe_code, "   FILE *Fprofile, *Fprobe;\n");
   fprintf(Fdump_probe_code, "   int i, start_index, end_index;\n");
   fprintf(Fdump_probe_code, "   char func_name[512];\n");
   fprintf(Fdump_probe_code, "   char file_name[256];\n");
   fprintf(Fdump_probe_code, "   Fprobe = fopen(\"impact_probe.status\", \"r\");\n");
   fprintf(Fdump_probe_code, "   if (Fprobe == NULL) {\n");
   fprintf(Fdump_probe_code, "      fprintf(stderr, \"Error, cannot open probe status file: impact_probe.status\\n\");\n");
   fprintf(Fdump_probe_code, "      exit(-1);\n");
   fprintf(Fdump_probe_code, "   }\n");
   /* LCW - make the profile data file different for each process by attaching
      the process id to the file name - 11/19/97 */
   fprintf(Fdump_probe_code, "   sprintf(file_name, \"profile_dat.%%d\", getpid());\n");
   fprintf(Fdump_probe_code, "   Fprofile = fopen(file_name, \"w\");\n");
   fprintf(Fdump_probe_code, "   while (fscanf(Fprobe, \"%%s%%d%%d\", &func_name, &start_index, &end_index) != EOF) {\n");
/*
   fprintf(Fdump_probe_code, "      fprintf(Fprofile, \"%%s\\n\", func_name);\n");
*/
   fprintf(Fdump_probe_code, "      for (i = start_index; i <= end_index; i++)\n");
   /* LCW - modified to generate floating point weights - 3/5/97 */
   /* fprintf(Fdump_probe_code, "          fprintf(Fprofile, \"\\t%%u\\n\", %s[i]);\n", probe_array_name); */
   fprintf(Fdump_probe_code, "          fprintf(Fprofile, \"\\t%%f\\n\", (double)%s[i]);\n", probe_array_name);
   fprintf(Fdump_probe_code, "   }\n");
   fprintf(Fdump_probe_code, "   fclose(Fprofile);\n");
   fprintf(Fdump_probe_code, "   fclose(Fprobe);\n");
   fprintf(Fdump_probe_code, "}\n");
}
#endif

/* LCW - a version which uses file lock (fcntl) to handle multiple processes
   writing to the same profile data file - 11/18/97 */
#if 0
void gen_dump_probe_code(array_size)
int array_size;
{
   fprintf(Fdump_probe_code, "#include <stdio.h>\n");
   fprintf(Fdump_probe_code, "#include <string.h>\n");
   fprintf(Fdump_probe_code, "#include <fcntl.h>\n");
   fprintf(Fdump_probe_code, "long int %s[%d] = {0};\n", probe_array_name, 
		array_size);
   fprintf(Fdump_probe_code, "static int write_lock_file_wait(int fd)\n");
   fprintf(Fdump_probe_code, "{\n");
   fprintf(Fdump_probe_code, "   struct flock lock;\n");
   fprintf(Fdump_probe_code, "   lock.l_type = F_WRLCK;\n");
   fprintf(Fdump_probe_code, "   lock.l_start = 0;\n");
   fprintf(Fdump_probe_code, "   lock.l_whence = SEEK_SET;\n");
   fprintf(Fdump_probe_code, "   lock.l_len = 0;\n");
   fprintf(Fdump_probe_code, "   return(fcntl(fd, F_SETLKW, &lock));\n");
   fprintf(Fdump_probe_code, "}\n\n");
   fprintf(Fdump_probe_code, "void _dump_probe_array()\n");
   fprintf(Fdump_probe_code, "{\n");
   fprintf(Fdump_probe_code, "   FILE *Fprobe;\n");
   fprintf(Fdump_probe_code, "   int prof_des;\n");
   fprintf(Fdump_probe_code, "   char strbuf[256];\n");
   fprintf(Fdump_probe_code, "   int i, n, start_index, end_index;\n");
   fprintf(Fdump_probe_code, "   char func_name[256];\n");
   fprintf(Fdump_probe_code, "   Fprobe = fopen(\"impact_probe.status\", \"r\");\n");
   fprintf(Fdump_probe_code, "   if (Fprobe == NULL) {\n");
   fprintf(Fdump_probe_code, "      fprintf(stderr, \"Error, cannot open probe status file: impact_probe.status\\n\");\n");
   fprintf(Fdump_probe_code, "      exit(-1);\n");
   fprintf(Fdump_probe_code, "   }\n");
   fprintf(Fdump_probe_code, "   if ((prof_des = creat(\"profile.dat\", S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH)) < 0) {\n");
   fprintf(Fdump_probe_code, "      fprintf(stderr, \"Error, cannot open profile.dat.\\n\");\n");
   fprintf(Fdump_probe_code, "      exit(-1);\n");
   fprintf(Fdump_probe_code, "   }\n");
   fprintf(Fdump_probe_code, "   write_lock_file_wait(prof_des);\n");
   fprintf(Fdump_probe_code, "   while (fscanf(Fprobe, \"%%s%%d%%d\", &func_name, &start_index, &end_index) != EOF) {\n");
/*
   fprintf(Fdump_probe_code, "      fprintf(Fprofile, \"%%s\\n\", func_name);\n");
*/
   fprintf(Fdump_probe_code, "      for (i = start_index; i <= end_index; i++) {\n");
   fprintf(Fdump_probe_code, "          sprintf(strbuf, \"\\t%%f\\n\", (double)%s[i]);\n", probe_array_name);
   fprintf(Fdump_probe_code, "          n = strlen(strbuf);\n");
   fprintf(Fdump_probe_code, "          if (write(prof_des, strbuf, n) != n) {\n");
   fprintf(Fdump_probe_code, "             fprintf(stderr, \"Error, cannot write profile.dat.\\n\");\n");
   fprintf(Fdump_probe_code, "             exit(-1);\n");
   fprintf(Fdump_probe_code, "          }\n");
   fprintf(Fdump_probe_code, "      }\n");
   fprintf(Fdump_probe_code, "   }\n");
   fprintf(Fdump_probe_code, "   close(prof_des);\n");
   fprintf(Fdump_probe_code, "   fclose(Fprobe);\n");
   fprintf(Fdump_probe_code, "}\n");
}
#endif


/* LCW - generate the code to initialize loop iter counters - 3/24/99 */
void PP_gen_loop_iter_counter_initial(FILE *F, int loops_no)
{
  int i;

  for (i = 0; i < loops_no; i++)
      fprintf(F, "\t(assign (var _PP_LP_COUNTER_%d) (unsigned 0))\n", i);
}


void PP_insert_loop_iter_counter(FILE *F, int lp_counter_no)
{
  fprintf(F, "\t(postinc (var _PP_LP_COUNTER_%d))\n", lp_counter_no);
}


/* generate the Hcode which calls the function _PP_loop_iter_update and 
   then clear the counter (to 0) */
void PP_gen_update_lp_iter_func(FILE *F, int loop_id)
{
  int lp_counter_no;

  lp_counter_no = loop_id - lp_id_counter_diff;
  fprintf(F, "\t(call (var _PP_loop_iter_update) (signed %d) (var _PP_LP_COUNTER_%d))\n", loop_id, lp_counter_no);
  fprintf(F, "\t(assign (var _PP_LP_COUNTER_%d) (unsigned 0))\n", 
	  lp_counter_no);
}

void PP_gen_update_lp_iter_func_in_middle(FILE *F, int loop_id)
{
  int lp_counter_no;

  lp_counter_no = loop_id - lp_id_counter_diff;
  fprintf(F, "(call (var _PP_loop_iter_update) (signed %d) (var _PP_LP_COUNTER_%d)) ", loop_id, lp_counter_no);
  fprintf(F, "(assign (var _PP_LP_COUNTER_%d) (unsigned 0))", 
	  lp_counter_no);
}


void PP_annotate_loop_iter_count(Stmt loop_stmt)
{
  int loop_id;
  int max_iter_id, max_input_id;
  int iter_id, input_id;
  char pragmastr[4096], spec_str[256], tmp_str[256];

  if (loop_stmt->type != ST_SERLOOP)
     Punt("PP_annotate_loop_iter_count: SerloopHeader flag error");

  if (loop_stmt->ext == 0)
     Punt("PP_annotate_loop_iter_count: lack of loop id info");

  loop_id = *(int *)loop_stmt->ext;

  max_iter_id = PP_get_loop_max_iter_id(loop_id);
  max_input_id = PP_get_loop_max_input_id();

  for (iter_id = 0; iter_id < max_iter_id; iter_id++) {
      int iter_count;
      double avg, freq;
      
      iter_count = PP_get_loop_iter_count(loop_id, iter_id);
      sprintf(spec_str, "\"iter_%d\"", iter_count);

      if (FindStmtPragma(loop_stmt, spec_str))
	 Punt("PP_annotate_loop_iter_count: duplicated iter count pragma");

      avg = PP_get_loop_iter_avg_exec(loop_id, iter_id);
      sprintf(pragmastr, "\"\\#%e", (double)avg);
      for (input_id = 0; input_id < max_input_id; input_id++) {
	  freq = PP_get_loop_iter_input_exec(loop_id, iter_id, input_id);
	  sprintf(tmp_str, "\\#%e", (double)freq);
	  strcat(pragmastr, tmp_str);
      }
      strcat(pragmastr, "\"");

      AddStatementPragma(loop_stmt, strdup(spec_str), 
			 NewStringExpr(strdup(pragmastr)));
  }
  
  if (FindStmtPragma(loop_stmt, "\"iteration_header\""))
     Punt("PP_annotate_loop_iter_count: duplicated iteration_header pragma");

  sprintf(pragmastr, "\"\\%%%d\\%%%d\"", max_iter_id, max_input_id);
  AddStatementPragma(loop_stmt, strdup("\"iteration_header\""), 
		     NewStringExpr(strdup(pragmastr)));
}
typedef struct PP_Iter
{
    int		iter;		/* Number of iterations weights are for */
    double 	*weight;	/* Array of weights, indexed by input id */
} PP_Iter;

typedef struct PP_Loop
{
    PP_Iter	*entry;		/* Array of iter entries for this loop */
    int 	entry_count;	/* Number of iter entries for this loop */
} PP_Loop;

static int PP_loop_iter_prof_init = 0;
static int PP_loop_count = 0;
static int PP_input_count = 0;
static PP_Loop *PP_loop = NULL;

/* Read in entry loop iteration profile file -JCG 4/99 */
void PP_read_loop_iter_profile ()
{
    FILE *in;
    int size, weight_array_size;
    int loop_id, entry_id, input_id;
    int file_loop_id, entry_count;
    PP_Iter *entry;
    int iter;
    int ch;
    double *weight_array;

    /* Sanity check, should not call twice */
    if (PP_loop_iter_prof_init)
    {
	Punt ("PP_read_loop_iter_profile: already read in!");
    }

    if ((in = fopen ("profile.iter", "r")) == NULL)
    {
	Punt("PP_read_loop_iter_profile: could not open 'profile.iter' "
	     "for reading!");
    }
    
    /* Get loop and input count */
    if (fscanf (in, "%d %d\n\n", &PP_loop_count, &PP_input_count) != 2)
    {
	Punt("PP_read_loop_iter_profile: error reading loop and input count!");
    }

    /* Sanity check, input count better be positive */
    if (PP_input_count < 1)
    {
	Punt("PP_read_loop_iter_profile: invalid input count (< 1)!");
    }

    /* Calculate the size of each weight array (out of loop) */
    weight_array_size = PP_input_count * sizeof (double);

    /* Malloc the array to hold all the loop iteration info */
    if ((PP_loop = (PP_Loop *)malloc(PP_loop_count * sizeof(PP_Loop))) == NULL)
	Punt ("PP_read_loop_iter_profile: Out of memory");

    /* Read in each loop's info */
    for (loop_id = 0; loop_id < PP_loop_count; loop_id++)
    {
	if (fscanf (in, "%d %d\n", &file_loop_id, &entry_count) != 2)
	{
	    Punt("PP_read_loop_iter_profile: error reading loop id and "
		 "entry count!");
	}
	
	/* Sanity check, loop id's better match! */
	if (loop_id != file_loop_id)
	{
	    fprintf (stderr, "Expected loop id %i not %i!\n", loop_id, 
		     file_loop_id);
	    Punt("PP_read_loop_iter_profile: loop id mismatch");
	}
	
	/* Sanity check, better be non-negative number */
	if (entry_count < 0)
	{
	    Punt("PP_read_loop_iter_profile: invalid negative entry count");
	}

	/* Set loop entry count */
	PP_loop[loop_id].entry_count = entry_count;

	/* Don't malloc zero entry case */
	if (entry_count == 0)
	{
	    entry = NULL;
	}
	else
	{
	    if ((entry = (PP_Iter *)malloc(entry_count*sizeof(PP_Iter)))==NULL)
		Punt ("PP_read_loop_iter_profile: Out of memory");
	}
	PP_loop[loop_id].entry = entry;

	/* Read in each loop entry */
	for (entry_id = 0; entry_id < entry_count; entry_id++)
	{
	    /* Read in the iter count */
	    if (fscanf (in, "%d", &iter) != 1)
		Punt ("PP_read_loop_iter_profile: Error reading iter count!");

	    /* Set up entry */
	    entry[entry_id].iter = iter;

	    /* Malloc weight array */
	    if ((weight_array = (double *) malloc (weight_array_size)) == NULL)
		Punt ("PP_read_loop_iter_profile: Out of memory");
	    entry[entry_id].weight = weight_array;
		
	    /* Read in each input weight */
	    for (input_id = 0; input_id < PP_input_count; input_id++)
	    {
		if (fscanf (in, "%lf", &weight_array[input_id]) != 1)
		    Punt ("PP_read_loop_iter_profile: Error reading weight!");
	    }
	}
    }

    /* Sanity check, better only have whitespace left in file */
    while ((ch = getc (in)) != EOF)
    {
	if (!isspace (ch))
	{
	    fprintf (stderr, "Unexpected char '%c' at expected EOF!\n", ch);
	    Punt ("PP_read_loop_iter_profile: EOF expected!");
	}
    }
    
    fclose (in);

    /* Flag that we have read the loop iter profile */
    PP_loop_iter_prof_init = 1;
}

/* Routines to pass back loop iteration profile back to the routine
 * LCW wrote. -JCG 4/99 
 */
/* Returns the number of iteration entries for this loop id */
int PP_get_loop_max_iter_id(int loop_id)
{
    /* Read in the loop iter profile info, if have not already */
    if (!PP_loop_iter_prof_init)
    {
	PP_read_loop_iter_profile();
    }

    /* Sanity check, make sure loop_id valid */
    if ((loop_id < 0) || (loop_id >= PP_loop_count))
    {
	Punt ("PP_get_loop_max_iter_id: invalid loop id");
    }

    return(PP_loop[loop_id].entry_count);
}

/* Returns the number of inputs contained in the loop iteration profile */
int PP_get_loop_max_input_id()
{
    /* Read in the loop iter profile info, if have not already */
    if (!PP_loop_iter_prof_init)
    {
	PP_read_loop_iter_profile();
    }

    return(PP_input_count);
}

/* Returns number of iterations for the specified entry (iter_id) */
int PP_get_loop_iter_count(int loop_id, int iter_id)
{
    /* Sanity check, make sure loop_id valid */
    if ((loop_id < 0) || (loop_id >= PP_loop_count))
    {
	Punt ("PP_get_loop_iter_count: invalid loop id");
    }

    /* Sanity check, make sure iter_id valid */
    if ((iter_id < 0) || (iter_id >= PP_loop[loop_id].entry_count))
    {
	Punt ("PP_get_loop_iter_count: invalid iter id");
    }

    return (PP_loop[loop_id].entry[iter_id].iter);
}

/* Returns the average weight for this iteration over all inputs */
double PP_get_loop_iter_avg_exec(int loop_id, int iter_id)
{
    int input_id;
    double sum, avg;

    /* Sanity check, make sure loop_id valid */
    if ((loop_id < 0) || (loop_id >= PP_loop_count))
    {
	Punt ("PP_get_loop_iter_avg_exec: invalid loop id");
    }

    /* Sanity check, make sure iter_id valid */
    if ((iter_id < 0) || (iter_id >= PP_loop[loop_id].entry_count))
    {
	Punt ("PP_get_loop_iter_avg_exec: invalid iter id");
    }
    
    /* Sum up the inputs */
    sum = 0.0;
    for (input_id = 0; input_id < PP_input_count; input_id++)
    {
	sum += PP_loop[loop_id].entry[iter_id].weight[input_id];
    }

    /* Make average */
    avg = sum / ((double)PP_input_count);
    
    return (avg);
}

/* Returns the weight for the specified input */
double PP_get_loop_iter_input_exec(int loop_id, int iter_id, int input_id)
{
    /* Sanity check, make sure loop_id valid */
    if ((loop_id < 0) || (loop_id >= PP_loop_count))
    {
	Punt ("PP_get_loop_iter_input_exec: invalid loop id");
    }

    /* Sanity check, make sure iter_id valid */
    if ((iter_id < 0) || (iter_id >= PP_loop[loop_id].entry_count))
    {
	Punt ("PP_get_loop_iter_input_exec: invalid iter id");
    }

    /* Sanity check, make sure input_id valid */
    if ((input_id < 0) || (input_id >= PP_input_count))
    {
	Punt ("PP_get_loop_iter_input_exec: invalid input id");
    }

    return (PP_loop[loop_id].entry[iter_id].weight[input_id]);
}
