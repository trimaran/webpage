/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   profile.c
 *      Author: Teresa Johnson and Wen-mei Hwu
\*****************************************************************************/


#include <Pcode/dd_acc-tbl.h>
#include <Pcode/pcode.h>
#include <Pcode/profile.h>
#include <Pcode/impact_global.h>
#include <Pcode/parms.h>
#include <Pcode/hash.h>
#include <Pcode/struct.h>

#define AM_VERSION 3

static Create_Dep_ExprPragmas_Expr(Expr expr)
{
  Expr sib;

  /*if (expr == 0) Punt("Create_Dep_ExprPragmas_Expr : nil input");*/
  if (expr == 0) return;

  while (expr)
  {
    if (expr->acc && expr->acc->dep_prag_num && 
	((!assume_C_semantics && expr->acc->var_expr == expr) ||
	(assume_C_semantics && expr->acc->acc_expr == expr)))
    {
      AddExprPragma(expr,"\"DEP\"",NewIntExpr(expr->acc->dep_prag_num));
    }
    if (expr->acc2 && expr->acc2->dep_prag_num &&
	((!assume_C_semantics && expr->acc2->var_expr == expr) ||
	(assume_C_semantics && expr->acc2->acc_expr == expr)))
    {
      AddExprPragma(expr,"\"DEP\"",NewIntExpr(expr->acc2->dep_prag_num));
    }
    for (sib=expr->operands;sib;sib=sib->sibling)
    {
	Create_Dep_ExprPragmas_Expr(sib);
    }
    expr = expr->next;
  }
}

static Create_Dep_ExprPragmas_Stmt(Stmt stmt)
{
  /*if (stmt == 0) Punt("Create_Dep_ExprPragmas_Stmt : nil input");*/
  if (stmt == 0) return;

  while (stmt)
  {
    switch (stmt->type)
    {
      case ST_RETURN:
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.ret);
	break;
      case ST_COMPOUND:
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.compound->stmt_list);
	break;
      case ST_IF:
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.ifstmt->cond_expr);
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.ifstmt->then_block);
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.ifstmt->else_block);
	break;
      case ST_SWITCH:
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.switchstmt->expression);
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.switchstmt->switchbody);
	break;
      case ST_PSTMT:
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.pstmt->stmt);
	break;
      case ST_MUTEX:
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.mutex->expression);
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.mutex->statement);
	break;
      case ST_COBEGIN:
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.cobegin->statements);
	break;
      case ST_PARLOOP:
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.parloop->iteration_var);
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.parloop->init_value);
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.parloop->final_value);
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.parloop->incr_value);
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.parloop->pstmt->stmt);
	break;
      case ST_SERLOOP:
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.serloop->loop_body);
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.serloop->cond_expr);
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.serloop->init_expr);
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.serloop->iter_expr);
	break;
      case ST_EXPR:
	Create_Dep_ExprPragmas_Expr(stmt->stmtstruct.expr);
	break;
      case ST_BODY:
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.bodystmt->statement);
	break;
      case ST_EPILOGUE:
	Create_Dep_ExprPragmas_Stmt(stmt->stmtstruct.epiloguestmt->statement);
	break;
      default: 
	break;
    }
    stmt = stmt->lex_next;
  }
}

Create_Dep_ExprPragmas(FuncDcl fn)
{
  if (fn == 0) Punt("Create_Dep_ExprPragmas : nil input");

  Create_Dep_ExprPragmas_Stmt(fn->stmt);
}

P_Attr *P_new_attr(int id,char *name,int max_field)
{
    P_Attr *attr;
    int i;

    attr = (P_Attr *) ALLOCATE(P_Attr);
    attr->op_id = id;
    attr->name = name;
    attr->max_field = max_field;
    attr->next_attr = NIL;
    attr->next_attr2 = NIL;
    attr->field = (P_Attr_Field **) malloc(sizeof(P_Attr_Field *)*max_field);
    for (i=0;i<max_field;i++)
	attr->field[i] = ALLOCATE(P_Attr_Field);
    attr->rank = 0;
    return attr;
}

void P_set_int_attr_field (P_Attr *attr, int field_num, int value)
{
    if (field_num > attr->max_field)
	Punt("Tried to set non-existent field in attribute");
    attr->field[field_num]->type = P_INT;
    attr->field[field_num]->value.i = value;
}

void P_set_float_attr_field (P_Attr *attr, int field_num, float value)
{
    if (field_num > attr->max_field)
	Punt("Tried to set non-existent field in attribute");
    attr->field[field_num]->type = P_FLOAT;
    attr->field[field_num]->value.f = value;
}

void P_set_string_attr_field (P_Attr *attr, int field_num, char *value)
{
    if (field_num > attr->max_field)
	Punt("Tried to set non-existent field in attribute");
    attr->field[field_num]->type = P_STRING;
    attr->field[field_num]->value.s = value;
}

void P_set_label_attr_field (P_Attr *attr, int field_num, char *value)
{
    if (field_num > attr->max_field)
	Punt("Tried to set non-existent field in attribute");
    attr->field[field_num]->type = P_LABEL;
    attr->field[field_num]->value.l = value;
}

P_Attr *P_find_attr(P_Attr *attr, char *name)
{
    char *attr_name;
    P_Attr *ptr;

    if (name==NULL)
        Punt("P_find_attr: name is NULL");

    for (ptr=attr; ptr!=NULL; ptr=ptr->next_attr) {
        attr_name = ptr->name;
        if (*attr_name!=*name)          /* quick check of first letter */
            continue;
        if (! strcmp(attr_name, name))
            return (ptr);
    }

    return (NULL);
}

Pannotate_Init()
{
    /* init the hash table to hold the index file info and read into it */
    P_init_string_hash();
    Pannotate_read_index();
}

Pannotate_Finish()
{
    P_delete_string_hash();
}

Pannotate_Func(FuncDcl fn)
{
    int n,N;

    N = P_get_num_positions(fn->name);

    for (n=0;n<N;n++)
    {
        /* init the hash tables to hold the attributes */
        P_init_hash();

        /* read the Attribute Manager file into the hash tables, etc. */
        Pannotate_read_annot(fn->name,n);

	/* Combine like attrs */
	P_combine_attrs();

	/* associate line numbers with attributes */
	Pannotate_line_numbers_Stmt(fn->stmt);

        /* Annotate all statements */
	Pannotate_Stmt(fn->stmt);

        /* delete all the hash tables and attribute structures that were used */
        P_delete_hash();

    }
}

Pannotate_line_numbers_Stmt(Stmt stmt)
{
/*  if (stmt == 0) Punt("Pannotate_Stmt : nil input");*/
  if (stmt == 0) return;

  while (stmt)
  {
    switch (stmt->type)
    {
      case ST_RETURN:
        Pannotate_line_numbers_Expr(stmt->stmtstruct.ret);
        break;
      case ST_COMPOUND:
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.compound->stmt_list);
        break;
      case ST_IF:
        Pannotate_line_numbers_Expr(stmt->stmtstruct.ifstmt->cond_expr);
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.ifstmt->then_block);
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.ifstmt->else_block);
        break;
      case ST_SWITCH:
        Pannotate_line_numbers_Expr(stmt->stmtstruct.switchstmt->expression);
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.switchstmt->switchbody);
        break;
      case ST_PSTMT:
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.pstmt->stmt);
        break;
      case ST_MUTEX:
        Pannotate_line_numbers_Expr(stmt->stmtstruct.mutex->expression);
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.mutex->statement);
        break;
      case ST_COBEGIN:
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.cobegin->statements);
        break;
      case ST_PARLOOP:
        Pannotate_line_numbers_Expr(stmt->stmtstruct.parloop->iteration_var);
        Pannotate_line_numbers_Expr(stmt->stmtstruct.parloop->init_value);
        Pannotate_line_numbers_Expr(stmt->stmtstruct.parloop->final_value);
        Pannotate_line_numbers_Expr(stmt->stmtstruct.parloop->incr_value);
	Pannotate_line_numbers_Stmt(stmt->stmtstruct.parloop->pstmt->stmt);
        break;
      case ST_SERLOOP:
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.serloop->loop_body);
        Pannotate_line_numbers_Expr(stmt->stmtstruct.serloop->cond_expr);
        Pannotate_line_numbers_Expr(stmt->stmtstruct.serloop->init_expr);
        Pannotate_line_numbers_Expr(stmt->stmtstruct.serloop->iter_expr);
        break;
      case ST_EXPR:
        Pannotate_line_numbers_Expr(stmt->stmtstruct.expr);
        break;
      case ST_BODY:
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.bodystmt->statement);
        break;
      case ST_EPILOGUE:
        Pannotate_line_numbers_Stmt(stmt->stmtstruct.epiloguestmt->statement);
        break;
      default:
	break;
    }
    stmt = stmt->lex_next;
  }
}

Pannotate_line_numbers_Expr(Expr expr)
{
  Pragma pragma,prag,last_prag;
  P_Attr *this,*attr,*attr_list;
  P_attr_hash_node *node;
  Expr sib;
  int i;

  if (expr == 0) return;

  while (expr)
  {
   /* get the list of attributes specified in the Attribute
  	Manager file for this Expression by looking at all of its Pragmas */
   for (pragma=expr->pragma;pragma;pragma=pragma->next)
   {
      if (strcmp("\"DEP\"",pragma->specifier)) continue;
      if (pragma->expr->opcode != OP_int) Punt("invalid DEP Pragma expr");
      attr_list = P_get_attr(pragma->expr->value.scalar);

      /* for each op attribute that was in the Attribute Manager
        file, set the line number of the corresponding op node */
      for (this=attr_list;this;this=this->next_attr)
      {
	node = P_get_hash_node_by_op(this->op_id);
	node->lineno = expr->parentstmt->lineno;
      }
   }
   for (sib=expr->operands;sib;sib=sib->sibling)
   {
      Pannotate_line_numbers_Expr(sib);
   }
   expr = expr->next;
  }
}

Pannotate_Stmt(Stmt stmt)
{
/*  if (stmt == 0) Punt("Pannotate_Stmt : nil input");*/
  if (stmt == 0) return;

  while (stmt)
  {
    switch (stmt->type)
    {
      case ST_RETURN:
        Pannotate_Expr(stmt->stmtstruct.ret);
        break;
      case ST_COMPOUND:
        Pannotate_Stmt(stmt->stmtstruct.compound->stmt_list);
        break;
      case ST_IF:
        Pannotate_Expr(stmt->stmtstruct.ifstmt->cond_expr);
        Pannotate_Stmt(stmt->stmtstruct.ifstmt->then_block);
        Pannotate_Stmt(stmt->stmtstruct.ifstmt->else_block);
        break;
      case ST_SWITCH:
        Pannotate_Expr(stmt->stmtstruct.switchstmt->expression);
        Pannotate_Stmt(stmt->stmtstruct.switchstmt->switchbody);
        break;
      case ST_PSTMT:
        Pannotate_Stmt(stmt->stmtstruct.pstmt->stmt);
        break;
      case ST_MUTEX:
        Pannotate_Expr(stmt->stmtstruct.mutex->expression);
        Pannotate_Stmt(stmt->stmtstruct.mutex->statement);
        break;
      case ST_COBEGIN:
        Pannotate_Stmt(stmt->stmtstruct.cobegin->statements);
        break;
      case ST_PARLOOP:
        Pannotate_Expr(stmt->stmtstruct.parloop->iteration_var);
        Pannotate_Expr(stmt->stmtstruct.parloop->init_value);
        Pannotate_Expr(stmt->stmtstruct.parloop->final_value);
        Pannotate_Expr(stmt->stmtstruct.parloop->incr_value);
	Pannotate_Stmt(stmt->stmtstruct.parloop->pstmt->stmt);
        break;
      case ST_SERLOOP:
        Pannotate_Stmt(stmt->stmtstruct.serloop->loop_body);
        Pannotate_Expr(stmt->stmtstruct.serloop->cond_expr);
        Pannotate_Expr(stmt->stmtstruct.serloop->init_expr);
        Pannotate_Expr(stmt->stmtstruct.serloop->iter_expr);
        break;
      case ST_EXPR:
        Pannotate_Expr(stmt->stmtstruct.expr);
        break;
      case ST_BODY:
        Pannotate_Stmt(stmt->stmtstruct.bodystmt->statement);
        break;
      case ST_EPILOGUE:
        Pannotate_Stmt(stmt->stmtstruct.epiloguestmt->statement);
        break;
      default:
	break;
    }
    stmt = stmt->lex_next;
  }
}

Pannotate_Expr(Expr expr)
{
  Pragma pragma,prag,last_prag;
  P_Attr *this,*attr,*attr_list;
  P_attr_hash_node *node;
  char name[20],*text;
  char null_string[10];
  Expr sib,new_expr,prag_expr;
  int i,op_id,num;

  if (expr == 0) return;

  sprintf(null_string,"\"NULL\"");

  while (expr)
  {
   /* get the list of attributes specified in the Attribute
  	Manager file for this Expression by looking at all of its Pragmas */
   for (pragma=expr->pragma;pragma;pragma=pragma->next)
   {
      if (strcmp("\"DEP\"",pragma->specifier)) continue;
      if (pragma->expr->opcode != OP_int) Punt("invalid DEP Pragma expr");
      attr_list = P_get_attr(pragma->expr->value.scalar);

      /* for each op attribute that was in the Attribute Manager
        file, insert it into this Pcode expr pragma list */
      for (this=attr_list;this;this=this->next_attr)
      {
	sprintf(name,"\"%s\"",this->name);
	prag = FindExprPragma(expr,name);
	/* Need to take out all old prags on a prepass */ /*
	if (prag)
	   RemoveExprPragma(expr,prag);
	*/
	fprintf(Fpcode_position,"%12d",expr->parentstmt->lineno);
	if (expr->acc)
		fprintf(Fpcode_position," %s", expr->acc->text);
	else if (expr->acc2)
		fprintf(Fpcode_position," %s", expr->acc2->text);
	else
		fprintf(Fpcode_position," ??");
	fprintf(Fpcode_position," %s %d",name,this->max_field);
	prag_expr = 0;
	for (i=0;i<this->max_field;i++)
	{
	  if (!this->field[i])
	  {
	    new_expr = NewStringExpr(strdup(null_string));
	    fprintf(Fpcode_position," NULL");
	  }
	  else
	  {
	   switch(this->field[i]->type)
	   {
	    case P_INT:
		if (!(strcmp(this->name,"mdp") ||
			strncmp(this->name,"dep_",4)) && !i)
		{
		    if (this->field[i]->value.i == -1 ||
		      !(node = P_get_hash_node_by_op(this->field[i]->value.i)))
		    {
			num = -1;
		    	new_expr = NewIntExpr(num);
		    	fprintf(Fpcode_position," %12d",num);
		    }
		    else
		    {
		    	new_expr = NewIntExpr(node->lineno);
		    	fprintf(Fpcode_position," %12d", node->lineno);
		    }
		}
		else
		{
		    new_expr = NewIntExpr(this->field[i]->value.i);
		    fprintf(Fpcode_position," %12d", this->field[i]->value.i);
		}
		break;
	    case P_FLOAT:
		new_expr = NewRealExpr(this->field[i]->value.f);
		fprintf(Fpcode_position," %12f", this->field[i]->value.f);
		break;
	    case P_STRING:
		new_expr = NewStringExpr(strdup(this->field[i]->value.s));
		fprintf(Fpcode_position," %12s", this->field[i]->value.s);
		break;
	    case P_LABEL:
		new_expr = NewStringExpr(strdup(this->field[i]->value.l));
		fprintf(Fpcode_position," %12s", this->field[i]->value.l);
		break;
	   }
	  }
	  if (!prag_expr) prag_expr = new_expr;
	  else AddNextOperand(prag_expr,new_expr);
	}

	AddExprPragma(expr,strdup(name),prag_expr);

	if (this->rank)
	    fprintf(Fpcode_position," %d",this->rank);
	fprintf(Fpcode_position,"\n");
      }
   }
   for (sib=expr->operands;sib;sib=sib->sibling)
   {
      Pannotate_Expr(sib);
   }
   expr = expr->next;
  }
}

Pannotate_read_annot(char *fn_name,int i)
{
        int version,err,num_fn_attr,num_cb_attr,num_op_attr,weight;
        char name[500];

	rewind(Fannot);
	fscanf(Fannot,"# Attribute Manager file --- Version %d",&version);
	if (version > AM_VERSION)
		Punt("Version %d of annot file not supported yet",version);
        fseek(Fannot,P_get_position(fn_name,i),0);
        fscanf(Fannot,"begin _%s %d %d %d %f\n",name,&num_fn_attr,
                &num_cb_attr,&num_op_attr,&weight);
        if (strcmp(fn_name,name))
           Punt("Function not found in Attribute Manager file");
        Pannotate_read_func(version,num_fn_attr,num_cb_attr,num_op_attr);
}

Pannotate_read_func(int version,int num_fn_attr,int num_cb_attr,int num_op_attr)
{
        int i,err,op_id,id,num_fields,field_num,rank;
        char c,type,name[500],fn_name[500],line[500];
	char *temp;
        long value_i;
	float value_f;
	char value_s[500];
        P_Attr *attr;

	/* Currently can't pass back function attrs */
        for (i=0;i<num_fn_attr;i++)
        {
           fgets(line,500,Fannot);
        }

	/* Currently can't pass back cb attrs */
        for (i=0;i<num_cb_attr;i++)
        {
           fgets(line,500,Fannot);
        }

        for (i=0;i<num_op_attr;i++)
        {
           err = fscanf(Fannot,"%d %s",&op_id,name);
           if (err < 2)
		Punt("Incorrect format of annot file (op_id name)");
           if (version == 1)
           {
	     attr = P_new_attr(op_id,strdup(name),1);
             err = fscanf(Fannot," %d",&value_i);
             if (err < 1) Punt("Incorrect format of annot file (value ver 1)");
             P_set_int_attr_field (attr, 0, value_i);
           }
           else         /* version == 2 or 3 */
           {
             if (version == 3)
             {
                err = fscanf(Fannot," %d",&num_fields);
                if (err != 1) Punt(
                  "Incorrect format of annot file: num fields not specified");
             }
             else num_fields = 1;
	     attr = P_new_attr(op_id,strdup(name),num_fields);
             for (field_num=0;field_num<num_fields;field_num++)
             {
              err = fscanf(Fannot," %c",&type);
              if (err != 1)
                Punt("Incorrect format of annot file (missing attr type)");
              switch (type)
              {
                case 'i':
                   err = fscanf(Fannot," %d",&value_i);
                   P_set_int_attr_field (attr, field_num, value_i);
                   break;
                case 'f':
                   err = fscanf(Fannot," %f",&value_f);
                   P_set_float_attr_field (attr, field_num, value_f);
                   break;
                case 's':
                   err = fscanf(Fannot," %s",&value_s);
                   P_set_string_attr_field (attr, field_num, value_s);
                   break;
                case 'l':
                   err = fscanf(Fannot," %s",&value_s);
                   P_set_label_attr_field (attr, field_num, value_s);
                   break;
                case 'N':
                   err = fscanf(Fannot,"ULL");
                   attr->field[field_num] = 0;
                   err = 1;
                   break;
                default:
                   Punt("Attribute type '%c' not known (id %d)\n",
                                                        type,op_id);
                   break;
              }
              if (err < 1) Punt("Incorrect format of annot file (missing val)");
             }
           }

           fgets(line,500,Fannot);

	   err = sscanf(line," %d Rank %d\n",&id,&rank);
	   if (err > 0)
	   {
		P_hash_insert_attr(attr,id);
		if (err > 1)
		{
		    attr->rank = rank;
		}
	   }
        }
        fscanf(Fannot,"end _%s\n\n",fn_name);
}

Pannotate_read_index()
{
    int err,version,n;
    long position;
    char name[500];

    err = 
	fscanf(Fannot_index,"# Attribute Manager index file --- Version %d\n",
        	&version);
    if (err < 1) Punt("Incorrect format of index file");
    while ((err = fscanf(Fannot_index,"_%s %d",name,&n)) != -1)
    {
       if (err < 2) Punt("Incorrect format of index file");
       for (;n;n--)
       {
          err = fscanf(Fannot_index," 0x%lx",&position);
          if (err < 1) Punt("Incorrect format of index file");
          P_insert_position(name,position);
       }
       fscanf(Fannot_index,"\n");
    }
}
