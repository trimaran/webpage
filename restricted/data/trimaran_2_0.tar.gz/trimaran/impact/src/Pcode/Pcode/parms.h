/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.20  */
/* IMPACT Trimaran Release (www.trimaran.org)                  May 17, 1999  */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	parms.h
 *	Author:	David August, Grant Haab, Nancy Warter and Wen-mei Hwu
\*****************************************************************************/


#ifndef PARMS_H
#define PARMS_H

#include <Pcode/impact_global.h>
#include <library/l_parms.h>


/*
 * The overall control is specified by the following options.
 */

/*----------------------------------------------------------------------*/
/* INPUT / OUTPUT */

extern char *F_input;
extern FILE *Fin;
extern char *F_hcode_output;        /* used internally, do not use */
extern char *F_pcode_output;        /* used internally, do not use */
extern char *F_nm_output;           /* BCC - 10/7/96 */
extern char *F_input_ip;
extern FILE *Finput_ip;
extern char *F_output;
extern FILE *Fout;
extern char *F_output2;
extern FILE *Fout2;
extern char *F_out_ip;
extern FILE *Fout_ip;
extern char *F_error;
extern FILE *Ferr;
extern char *F_log;
extern FILE *Flog;
extern char *F_stat_pcode;
extern FILE *Fstpcode;
extern char *F_annot;
extern FILE *Fannot;
extern char *F_annot_index;
extern FILE *Fannot_index;
extern char *F_pcode_position;
extern FILE *Fpcode_position;
extern char *F_out_gvar;	    /* BCC - 2/25/97 */
extern FILE *Fout_gvar;

/* LCW - file handlers for probe status file, dump prode code file and 
 * profiling data file - 10/12/95 
 */
extern FILE *Fallprobe; 
extern FILE *Fdump_probe_code;
extern FILE *Fprofile;
extern FILE *Fnull;  /* LCW - 2/19/96 */


/*----------------------------------------------------------------------*/
/* VERBOSE */

/* 1: if debug_yes, constantly dump out internal compiler state. */
extern int debug_yes;		/* debug */

/* 2: if verbose_yes, tell the user what's being done or will be done. */
extern int verbose_yes;		/* be verbose */

/* 3: if line_yes, include line numbers in output */
extern int line_yes;		/* include line numbers */

/*----------------------------------------------------------------------*/
/* if static_array - make all local arrays static */
extern int static_array;

/* if do_dependence - do dependence analysis even if no transformations
 * specified. This is to debug dependence analysis.
 */
extern int do_dependence;

/* if set report pstmt errors - may be expanded to parallelize */
extern int parallel_flag;

/* print out number of top-level pcode defs and dcls */
extern int print_pcode_stats;  

/* if set generate pragmas for loops which contain source file position
 * and name information.  Used for passing loop information from Lcode
 * back to Pcode, and associating loop information with source code.
 */
extern int hcode_loop_prags;

/* if set generate SWP_INFO pragmas for loops which contain information
 * about the hazards (or lack thereof) which could prevent software pipelining
 * of the loop.  Pragma are generated when generating Hcode.
 */
extern int hcode_swp_prags;

/* if set generate pragmas for loops which mark the entry and exit points
 * with pragmas specifying source code position and type.  Used for operation
 * count loop simulation in Lcode. 
 */
extern int hcode_loop_sim_prags;

/* if set generate pragmas for functions which contain source file position
 * and name information.  Used for passing function information from Lcode
 * back to Pcode, and associating function information with source code.
 */
extern int hcode_func_prags;

/* if set, generate dependence pragmas for expressions which are expected
 * to generate load and store opers in Lcode
 */
extern int hcode_dep_prags;

/* if set, generate static profiling information based on loop nesting depth
 * only in Hcode output.  
 */
extern int hcode_static_prof;

/* the number of estimated loop iterations for static profile information 
 * generated in Hcode output.
 */
extern double hcode_stat_loop_weight;

/* the number of estimated function invokations for static profile information 
 * generated in Hcode output.
 */
extern double hcode_stat_func_weight;

/* if set, we are going to merge Lcode profiling info back into
 * Pcode, so we need to generate numbers for all accesses and
 * also need to output a Pcode file as well as an Hcode file.
 */
extern int do_merge_profiling;

/* if set, change access table format to support C semantics */
extern int do_dep_anal_for_C;
extern int generate_jsr_dependences;
extern int generate_gvar_address_taken;	/* BCC - 2/25/97 */
extern int generate_intraprocedural_data;     /* BCC 6/18/97 */

/* if set, and merge_interprocedural_data is set, will use IP data to annotate
callsites with 3 flags: JSR_MODS_ARGS, JSR_MODS_GVARS, JSR_DOES_IO */

/* Convert for loops to doserial for original C code (not converted by f2c). */
extern int do_loop_conversion_on_C;

/* Convert Fortran loops even if address of iteration variable is taken */
extern int loop_conv_if_unpromoted_iter_var;

/* automatic renice value for Pcode executable */
extern int pcode_nice_value; 

/* show loop transformations in log file */
extern int DEMO_OUTPUT;
/* warn about possibly uninitialized automatic variables */
extern int warn_uninitialized_automatic_vars;

extern int DEBUG_GEN_PCODE;
extern int DEBUG_GEN_HCODE;
extern int DEBUG_GEN_CHARLIE;
extern int DEBUG_PRINT_PCODE;
extern int DEBUG_LINKS;
extern int DEBUG_INIT;
extern int DEBUG_FUNC;
extern int DEBUG_SYMTREE;
/* BCC - 1/7/97 */
extern int DEBUG_FLATTENING;

/*----------------------------------------------------------------------*/
/* output in one of the specified form. */
/* Parallel C code is an intermediate form that uses calls to represent the
 * parallel data construct.  It can be compiled by a sequential C compiler
 * but will not produce the correct results since loop stmts will be
 * missing.  The reason for not replacing the parallel loop constructs with
 * sequential loop constructs is to allow for more aggressive sequential
 * optimizations.  We assume that the sequential optimizer will not move
 * code beyond the parallel stmts. 
 */
#define OUTPUT_NONE	0	/* no output */
#define OUTPUT_HCODE	1	/* convert to HCODE */
#define OUTPUT_PCODE	2	/* print out PCODE */
#define OUTPUT_NM	3	/* print out "nm -g" information */
extern int output_form;


/*----------------------------------------------------------------------*/
/* amount of work done */
extern int num_struct;
extern int num_union;
extern int num_enum;
extern int num_gvar;
extern int num_func;
extern int num_expandable_func;    /* BCC - 8/30/96 */
extern int num_total_func_call;    /* BCC - 8/30/96 */


/* flags for whether or not to open statistics files */
extern bool OPEN_STAT_PCODE;

extern int trans_named_funcs_only; /* for debugging transformations */
extern char *named_funcs_to_trans; /* if above TRUE, list of function names*/

/* character strings for parsing parameters into configuration variables */
extern char *output_format_string;
extern char *transform_string;

/* BCC - move parms for Psplit and Pinline to Psplit and Pinline themselves - 10/22/96 */
#if 0
/* BCC - added output form selection for Psplit - 7/4/95 */
extern char *sp_output_format_string;
extern char *sp_output_dir_string;
extern char *sp_input_spec;
extern char *sp_output_spec;

/* BCC - added output directory for Pinline - 11/6/95 */
extern char *il_output_dir_string;
extern char *il_log_name;
extern double code_expand_ratio;	/* BCC - 2/16/96 */
extern int maximum_bodysize;		/* BCC - 3/15/96 */
extern int maximum_stacksize;		/* BCC - 3/15/96 */
#endif

/* ITI(JCG) - set in Psplit -2/99 */
extern int sp_create_layout_info_generator; 

/* BCC - added flag for flattening - 11/26/95 */
extern int do_flatten;

/* external functions */

extern void P_read_parm_Pcode(Parm_Parse_Info *ppi);

/* BCC - arch and model for casting - 6/12/95 */
extern void P_read_parm_arch(Parm_Parse_Info *ppi);
extern char *P_arch;
extern char *P_model;
extern char *P_lmdes_file_name;

/* BCC - just translate - 11/6/96 */
extern int fast_mode;

/* LCW - flag for probe insertion for Pcode profiler - 10/06/95 */
extern int DO_INSERT_PROBE;

/* LCW - flag for annotating Pcode - 10/21/95 */
extern int DO_ANNOTATE_PCODE;

/* LCW - flag for inserting pseudo probe which pass probe id numbers to Lcode.
 * When this flag is set, DO_INSERT_PROBE will also be set - 10/24/96
 */
extern int DO_INSERT_PSEUDO_PROBE;

/* LCW - flags for loop trip count profiling - 3/24/99 */
extern int DO_INSERT_LOOP_TRIP_COUNT_PROBE;
extern int DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT;

/* LCW - flag for emitting source information (file name, scope number,
   line number, etc) to Hcode - 7/24/97 */
extern int EMIT_SOURCE_INFO;

/* BCC - 11/10/97 */
extern int multi_alias_relation;
extern int generate_access_name;
extern int generate_access_name_by_type;
extern int remove_dead_function;
extern int build_acc_tbl;
extern int calculate_alias;
/* BCC/ITI - 1/29/99 */
extern int verify_brand_names;
/* BCC/ITI - 2/9/99 */
extern int resolve_machine_dependent_information;

#endif
