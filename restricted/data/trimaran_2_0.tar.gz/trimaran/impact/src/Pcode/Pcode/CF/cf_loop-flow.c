/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	cf_loop-flow.c
 *	Author: Grant Haab and Wen-mei Hwu
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <library/set.h>
#include <library/llist.h>
#include <Pcode/flow.h>
#include <Pcode/cf_loop-flow.h>
#include <Pcode/cf_basic-block.h>
#include <Pcode/dd_data-dep.h>	/* only for maxCommonNest */
#include <Pcode/pcode.h>
#include <Pcode/struct.h>
#include <Pcode/parms.h>

int num_loops;

Set CF_Find_BBs_For_Stmts();

static Punt(mesg, stmt)
char *mesg;
Stmt stmt;
{
    if (stmt != NIL) {
	fprintf(Ferr, "# cf_loop-flow: %s in file %s on line %u\n", mesg,
		stmt->filename, stmt->lineno);
    }
    else {
	fprintf(Ferr, "# cf_loop-flow: %s\n", mesg);
    }
    exit(-1);
}

/*
 * Return set of basic blocks corresponding to a statement.
 */

Set CF_Find_BBs_For_Stmt(stmt)
Stmt stmt;
{
    Set bbs = NIL, temp1, temp2;
    Lptr l;

    SerLoop serloop;
    ParLoop parloop;

    switch (stmt->type) {
	case ST_NOOP:
	case ST_CONT:
	case ST_BREAK:
	case ST_RETURN:
	case ST_GOTO:
	case ST_ADVANCE:
	case ST_AWAIT:
	    break;
	case ST_COMPOUND:
	    bbs = CF_Find_BBs_For_Stmts(stmt->stmtstruct.compound->stmt_list);
	    break;
	case ST_IF:
	    bbs = CF_Find_BBs_For_Stmts(stmt->stmtstruct.ifstmt->then_block);
	    if (stmt->stmtstruct.ifstmt->else_block != NIL) {
		bbs = Set_union(temp1 = bbs, temp2 =  
		    CF_Find_BBs_For_Stmts(stmt->stmtstruct.ifstmt->else_block));
		Set_dispose(temp1);
		Set_dispose(temp2);
	    }
	    break;
	case ST_SWITCH:
	    bbs = CF_Find_BBs_For_Stmts(stmt->stmtstruct.switchstmt->switchbody);
	    break;
	case ST_PSTMT:
	    bbs = CF_Find_BBs_For_Stmts(stmt->stmtstruct.pstmt->stmt);
	    break;
	case ST_MUTEX:
	    bbs = CF_Find_BBs_For_Stmts(stmt->stmtstruct.mutex->statement);
	    break;
	case ST_COBEGIN:
	    bbs = CF_Find_BBs_For_Stmts(stmt->stmtstruct.cobegin->statements);
	    break;
	case ST_SERLOOP:
	    serloop = stmt->stmtstruct.serloop;
	    bbs = CF_Find_BBs_For_Stmts(serloop->loop_body);
	    break;
	case ST_PARLOOP:
	    parloop = stmt->stmtstruct.parloop;
	    bbs = CF_Find_BBs_For_Stmts(Parloop_Stmts_Prologue_Stmt(stmt));
	    break;
	case ST_EXPR:
	    break;
	case ST_BODY:
	    bbs = CF_Find_BBs_For_Stmts(stmt->stmtstruct.bodystmt->statement);
	    break;
	case ST_EPILOGUE:
	    bbs = CF_Find_BBs_For_Stmts(stmt->stmtstruct.epiloguestmt->statement);
	    break;
	default:
	    Punt("CF_Find_BBs_For_Stmt: Invalid statement type", stmt);
    }

    for (l=stmt->flow->flow_node_list; l!=NIL; l=l->next) {
	bbs = Set_add(bbs, ((FlowNode)l->ptr)->bb->index);
    }
    return bbs;
}

/*
 * Return the set of basic blocks corresponding to a list of statements.
 */

Set CF_Find_BBs_For_Stmts(stmt)
Stmt stmt;
{
    Set bbs = NIL, temp1, temp2;

    while (stmt != NIL) {
	bbs = Set_union(temp1 = bbs, temp2 = CF_Find_BBs_For_Stmt(stmt));
	Set_dispose(temp1);
	Set_dispose(temp2);
	stmt = stmt->lex_next;
    }
    return bbs;
}

/*
 * Return the set of basic blocks for the body of a parloop statement.
 * Also, set body_bb to the BB node representing the entry to the body.
 */

static Set CF_Find_BBs_For_Parloop_Body(stmt, body_bbn)
Stmt stmt;
BBNode *body_bbn;
{
    Set bbs = NIL, temp1, temp2;
    BBNode bbn;
    Stmt body_stmt;

    assert(stmt->type == ST_PARLOOP);

    body_stmt = Parloop_Stmts_Body_Stmt(stmt);
    *body_bbn = body_stmt->flow->entry_flow_node->bb;
    bbs = Set_add(bbs, (*body_bbn)->index);

    bbn = FindFlowNodeInList(NT_ParloopIterCond,stmt->flow->flow_node_list)->bb;
    bbs = Set_add(bbs, bbn->index);

    bbs = Set_union(temp1 = bbs, 
	temp2 = CF_Find_BBs_For_Stmt(body_stmt->stmtstruct.bodystmt->statement));
    Set_dispose(temp1);
    Set_dispose(temp2);

    return bbs;
}

/*
 * Print the Reaching BB's for a given parloop stmt in given func
 */

void CF_Print_Reaching_BBs(file, parloop_stmt, func)
FILE *file;
Stmt parloop_stmt;
FuncDcl func;
{
    int ld, bbi, num_lbbs, bb_num;
    Set loop_bbs;
    int *lbb;
    BBNode body_bbn, bbn;
    FlowNode ffn;
    BBGraph bb_graph;
    FlowGraph flow_graph;
    char name[128];
  
    assert(func != NIL);
    assert((flow_graph = func->flow->flow_graph) != NIL);
    assert(flow_graph->has_bbs);
    assert((bb_graph = flow_graph->bb_graph) != NIL);
    assert(bb_graph->has_rbbs);

    assert(parloop_stmt == NIL || parloop_stmt->type == ST_PARLOOP);

    if (parloop_stmt == NIL) 
	fprintf(file, "....Printing Reaching BBs for top level of function\n");
    else
	fprintf(file, "....Printing Reaching BBs for parloop stmt on line %d\n",
		parloop_stmt->lineno);

    if (parloop_stmt != NIL) {
	loop_bbs = CF_Find_BBs_For_Parloop_Body(parloop_stmt, &body_bbn);

	lbb = (int *) malloc(Set_size(loop_bbs) * sizeof(int));
	if (lbb == NIL) Punt("Allocation of rbbs4loop array failed", NIL);

	num_lbbs = Set_2array(loop_bbs, lbb);

	ld = parloop_stmt->stmtstruct.parloop->depth;
    }
    else {
	num_lbbs = (int) bb_graph->num_nodes;
	ld = 0;
    }

    for (bbi = 0; bbi < num_lbbs; bbi++) {
	if (parloop_stmt != NIL) bb_num = lbb[bbi];
	else bb_num = bbi;

	bbn = bb_graph->bb_node[bb_num];
	ffn = (FlowNode) bbn->flows->ptr;

	if (ffn->type == NT_FuncExit || ffn->type == NT_FuncEntry) {
	    sprintf(name, "%d %s(%s)", bb_num, NodeTypeNames[ffn->type],
		    ffn->pcode_ptr.func->name);
	}
	else {
	    sprintf(name, "%d %s(#%d)", bb_num, NodeTypeNames[ffn->type],
		    ffn->pcode_ptr.stmt->lineno);
	}
	fprintf(file, "......");
	Set_print(file, name, bbn->rbbs4loop[ld]);
    }

    if (parloop_stmt != NIL) free(lbb);
}

/*
 * Calculate the reaching basic blocks for a parloop.
 */

static void CF_BB_Loop_Flow_Parloop(parloop_stmt, func)
Stmt parloop_stmt;
FuncDcl func;
{
    int ld, bbi, num_lbbs, change, num_iter;
    Set loop_bbs, new_rbbs, temp;
    int *lbb;
    BBNode body_bbn, bbn;
    Lptr pred;
  
    assert(parloop_stmt != NIL && parloop_stmt->type == ST_PARLOOP);

    loop_bbs = CF_Find_BBs_For_Parloop_Body(parloop_stmt, &body_bbn);

    lbb = (int *) malloc(Set_size(loop_bbs) * sizeof(int));
    if (lbb == NIL) Punt("Allocation of rbbs4loop array failed", NIL);

    num_lbbs = Set_2array(loop_bbs, lbb);

    ld = parloop_stmt->stmtstruct.parloop->depth;

    change = TRUE;
    num_iter = 1;
    while (change) {
	change = FALSE;

	for (bbi = 0; bbi < num_lbbs; bbi++) {
	    bbn = bb_graph->bb_node[lbb[bbi]];

	    if (bbn != body_bbn) { /* this effectively breaks loop back-edges */
		
		/* calculate union of all predecessor nodes in same loop */
		new_rbbs = NIL;
		for (pred = bbn->pred; pred != NIL; pred = pred->next) {

		    if (Set_in(loop_bbs, ((BBNode)pred->ptr)->index)){

			new_rbbs = Set_add(new_rbbs,((BBNode)pred->ptr)->index);
			new_rbbs = Set_union(temp = new_rbbs,
					 ((BBNode)pred->ptr)->rbbs4loop[ld]);
			Set_dispose(temp);
		    }
		}

		if (!Set_same(new_rbbs, bbn->rbbs4loop[ld])) {
		    Set_dispose(bbn->rbbs4loop[ld]);
		    bbn->rbbs4loop[ld] = new_rbbs;
		    change = TRUE;
		}
		else Set_dispose(new_rbbs);
	    }
	}
	if (change) {
	    num_iter++;
	}
    }
    if (debug_yes) {
	fprintf(Flog, 
		"....Number of Iterations to calculate Reaching BBs for loop on line %d: %d\n",
		parloop_stmt->lineno, num_iter);
    }

    free(lbb);
    Set_dispose(loop_bbs);    
    num_loops++;
} 

/*
 * Calculate the reaching basic blocks for top level of program 
 * (non-loop-carried).
 */

static void CF_BB_Loop_Flow_Top_Level(func)
FuncDcl func;
{
    int ld, bbi, change, num_iter;
    unsigned int num_bbs;
    Set new_rbbs;
    BBNode bbn, pbbn;
    Lptr pred;
  
    ld = 0;
    num_bbs = bb_graph->num_nodes;

    change = TRUE;
    num_iter = 1;
    while (change) {
	change = FALSE;

	for (bbi = 0; bbi < num_bbs; bbi++) {
	    bbn = bb_graph->bb_node[bbi];

	    /* calculate union of all predecessor nodes in same loop */
	    new_rbbs = NIL;
	    for (pred = bbn->pred; pred != NIL; pred = pred->next) {
		pbbn = (BBNode)pred->ptr;
		new_rbbs = Set_add(new_rbbs, pbbn->index);
		new_rbbs = Set_union_acc(new_rbbs, pbbn->rbbs4loop[ld]);
	    }

	    if (!Set_same(new_rbbs, bbn->rbbs4loop[ld])) {
		Set_dispose(bbn->rbbs4loop[ld]);
		bbn->rbbs4loop[ld] = new_rbbs;
		change = TRUE;
	    }
	    else Set_dispose(new_rbbs);
	}
	if (change) {
	    num_iter++;
	}
    }
    if (debug_yes) {
	fprintf(Flog, 
		"....Number of Iterations to calculate Reaching BBs for top level of function: %d\n",
		num_iter);
    }
} 

/*
 * Calculate the reaching basic blocks for parloops at this level.
 */

static void CF_BB_Loop_Flow_Parloops(parloop_stmt, func)
Stmt parloop_stmt;
FuncDcl func;
{
    ParLoop parloop;

    while (parloop_stmt != NIL) {
	/* BCC/INTEL - changed '=' into '==' - 6/6/97 */
	assert(parloop_stmt->type == ST_PARLOOP);
	CF_BB_Loop_Flow_Parloop(parloop_stmt, func);

	parloop = parloop_stmt->stmtstruct.parloop;
	CF_BB_Loop_Flow_Parloops(parloop->child, func);

	parloop_stmt = parloop->sibling;
    }
}

/*
 * Create and initialize the reaching basic block arrays for each basic block.
 */

static void CF_Init_BB_Loop_Flow()
{
    int bbi, li;
    BBNode bbn;

    for (bbi = 0; bbi < bb_graph->num_nodes; bbi++) {
	bbn = bb_graph->bb_node[bbi];
	bbn->rbbs4loop = (Set *) malloc((maxCommonNest+1) * sizeof(Set));
	if (bbn->rbbs4loop == NIL) 
	    Punt("Allocation of rbbs4loop array failed", NIL);

	for (li = 0; li <= maxCommonNest; li++) {
	    bbn->rbbs4loop[li] = NIL;
	}
    }

    bb_graph->has_rbbs = TRUE;
}

/*
 * Check to see if function has reaching basic block sets calculated.
 * Return TRUE if reaching BB sets present, FALSE otherwise.
 */

bool CF_Function_Has_BB_Loop_Flow(func)
FuncDcl func;
{
    if (func->flow == NIL || func->flow->flow_graph == NIL)
        Punt("control flow graph not available for function", NIL);
    flow_graph = func->flow->flow_graph;

    if (!flow_graph->has_bbs) return FALSE;
    bb_graph = flow_graph->bb_graph;

    return bb_graph->has_rbbs;
}

/*
 * Dispose of Reaching Basic Block sets for all Parloops in function.
 */
void CF_Dispose_BB_Loop_Flow(func)
FuncDcl func;
{
    int bbi, li;
    BBNode bbn;

    flow_graph = func->flow->flow_graph;
    assert(flow_graph != NIL && flow_graph->has_bbs);
    bb_graph = flow_graph->bb_graph;
    assert(bb_graph != NIL && bb_graph->has_rbbs);

    for (bbi = 0; bbi < bb_graph->num_nodes; bbi++) {
	bbn = bb_graph->bb_node[bbi];
	if (bbn->rbbs4loop != NIL) {
	    for (li = 0; li <= bbn->loop_depth; li++) {
		bbn->rbbs4loop[li] = Set_dispose(bbn->rbbs4loop[li]);
	    }
	    free(bbn->rbbs4loop);
	    bbn->rbbs4loop = NIL;
	}
    }
    
    bb_graph->has_rbbs = FALSE;
}

/* 
 * Calculate Reaching Basic Blocks for all Parloops in function.
 */

void CF_Build_BB_Loop_Flow_Function(func)
FuncDcl func;
{
    Lptr cur_return_list, succ, pred;

    if (debug_yes || verbose_yes) {
	fprintf(Flog, "..Loop Flow Analysis beginning on fn (%s)\n",
		func->name);
    }

    if (func->flow == NIL || func->flow->flow_graph == NIL) 
	Punt("control flow graph not available for function", NIL);
    flow_graph = func->flow->flow_graph;
    
    if (!func->flow->flow_graph->has_bbs) CF_Build_BBG_Function(func);
    bb_graph = flow_graph->bb_graph;

    if (bb_graph->has_rbbs) CF_Dispose_BB_Loop_Flow(func);

    CF_Init_BB_Loop_Flow();

    num_loops = 0;

    CF_BB_Loop_Flow_Parloops(func->par_loop, func);

    if (debug_yes || verbose_yes) {
	fprintf(Flog, "..Loop Flow Analysis complete for fn (%s)\n",
		func->name);
    }
    if (debug_yes) {
	fprintf(Flog, "....Number of Loops Analyzed: %d\n", num_loops);
    }
}
