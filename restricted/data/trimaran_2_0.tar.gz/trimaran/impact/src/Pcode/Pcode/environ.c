/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.20  */
/* IMPACT Trimaran Release (www.trimaran.org)                  May 17, 1999  */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	environ.c
 *	Author:	David August, Grant Haab, Nancy Warter and Wen-mei Hwu
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <Pcode/environ.h>
#include <Pcode/parms.h>
#include <Pcode/struct.h>
#include <Pcode/profile.h>
#include <Pcode/probe.h>

/*
 * 	This file is used to specify the execution environment for Pcode
 *	including processing the command line arguments, opening files
 *	and initializing certain global data structures.
 */

/* global variables for transformation list */
_Xform *xform_head = 0;
_Xform *xform_tail = 0;

/* List of functions to transform for debugging */
char *funcs_to_trans[MAX_SOURCE_FUNCS + 1] = {0};
int func_trans_count = 0; 	/* number of functions in above array */

Xform NewXform()
{
    Xform xform;
    xform = ALLOCATE(_Xform);
    xform->type = 0;
    xform->next = NIL;
    xform->flags = 0;
    return xform;
}

int SetUpEnvironment(char *prog_name)
{
    char *t, *trans;
    char *small_alpha = "abcdefghijklmnopqrstuvwxyz";
    int i, trans_len;
    _Xform *xform;
    double tmp_var; /* LCW */

    /* BCC - 2/25/97 */
    if (generate_gvar_address_taken) {
	Fout_gvar = fopen(F_out_gvar, "a");
	if (Fout_gvar==NULL) {
	    fprintf(Ferr, "Error, cannot open global variable reference file: %s\n",
			F_out_gvar);
	    exit(-1);
	}
    }

    /* LCW - set DO_INSERT_PROBE when DO_INSERT_PSEUDO_PROBE is set - 10/24/96*/
    if (DO_INSERT_PSEUDO_PROBE)
       DO_INSERT_PROBE = 1;

    /* LCW - open probe-status file and dump_probe c code file - 10/12/95 */
    if (DO_INSERT_PROBE) {
       Fallprobe = fopen("impact_probe.status", "a");
       if (Fallprobe==NULL) {
	  fprintf(Ferr, "Error, cannot open probe status file: %s\n", 
			"impact_probe.status");
	  exit(-1);
       }
       Fdump_probe_code = fopen("impact_dump_probe_rev.c", "w");
       if (Fdump_probe_code==NULL) {
          fprintf(Ferr, "Error, cannot open dump_probe_code file: %s\n",
                        "impact_dump_probe_rev.c");
          exit(-1);
       }
    }

    /* TLJ 2/27/96 - moved next 2 paragraphs here from P_gen_code() (was main2) */

    /* LCW - open the file which records the next probe number and give the
     * value to next_probe - 10/12/95
     */
    if (DO_INSERT_PROBE || DO_ANNOTATE_PCODE) {
       Fprvprobe = fopen("impact_probe.tmp", "r");
       if (Fprvprobe == NULL)
          next_probe = 0;
       else {
          fscanf(Fprvprobe, "%d", &next_probe);
			 fclose(Fprvprobe);
		 }
	 /* sias - moved fclose(Fprvprobe) inside else to
	  * prevent null dereference in WIN32
	  */
    }
    
    /* LCW - open the profile data file and move the file pointer to the
     * correct place - 10/22/95
     */
    if (DO_ANNOTATE_PCODE) {
	Fprofile = fopen("profile.dat", "r");
	for (i = 1; i <= next_probe; i++)
	    /* LCW - modified to read floating-point profile weight - 3/5/97 */
	    fscanf(Fprofile, "%lf", &tmp_var);
    }
    
    /* LCW - open the file recording the next loop id number - 3/24/99 */
    if (DO_INSERT_LOOP_TRIP_COUNT_PROBE ||
        DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) {
	Fprvloopid = fopen("impact_loop_id.tmp", "r");
	if (Fprvloopid == NULL)
	    next_loop_id = 0;
	else {
	    fscanf(Fprvloopid, "%d", &next_loop_id);
	    fclose(Fprvloopid);
	}
    }
    
    /* LCW - open null file for annotating Pcode - 2/19/96 */
    if (DO_ANNOTATE_PCODE || DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) {
#undef NULLFILE
#ifndef WIN32
#define NULLFILE "/dev/null"
#else
#define NULLFILE "NUL"
#endif
/*	Added by sias Jul 97 */
       Fnull = fopen(NULLFILE, "w");
       if (Fnull==NULL) {
          fprintf(Ferr, "Error, cannot open null file\n");
          exit(-1);
       }
    }

    if (do_merge_profiling)
    {
	F_output2 = F_pcode_output;
    }

    if (do_merge_profiling && strcmp(F_output2, "stdout") && 
		(output_form == OUTPUT_HCODE)) {
        Fout2 = fopen(F_output2, "w");
        if (Fout2==NULL) {
            fprintf(Ferr, "Error, cannot open output file: %s\n", F_output2);
            exit(-1);
        }
    }

    if (do_merge_profiling && (output_form == OUTPUT_PCODE)) {
      if (strcmp(F_annot, "stdin"))
      {
	Fannot = fopen(F_annot, "r");
	if (Fannot==NULL) {
	    fprintf(Ferr, "Error, cannot open annot file: %s\n", F_annot);
	    exit(-1);
	}
      }
      else
      {
	fprintf(Ferr, "Error, annot file cannot be stdin\n");
	exit(-1);
      }

      if (strcmp(F_annot_index, "stdin"))
      {
	Fannot_index = fopen(F_annot_index, "r");
	if (Fannot_index==NULL) {
	    fprintf(Ferr, "Error, cannot open annot file: %s\n", F_annot_index);
	    exit(-1);
	}
      }
      else
      {
	fprintf(Ferr, "Error, annot_index file cannot be stdin\n");
	exit(-1);
      }
      Pannotate_Init();

      if (strcmp(F_pcode_position, "stdout")) {
	Fpcode_position = fopen(F_pcode_position, "w");
	if (Fpcode_position==NULL) {
	    fprintf(Ferr, "Error, cannot open pcode position file: %s\n",
		    F_pcode_position);
	    exit(-1);
        }
      }
    }

    if (print_pcode_stats) OPEN_STAT_PCODE = TRUE;

    /* GEH - parse function names to transform and store in array of strings */
    if (trans_named_funcs_only) {
	func_trans_count = 0;
	funcs_to_trans[func_trans_count] = strtok(named_funcs_to_trans," \t\n");
	while (funcs_to_trans[func_trans_count] != NIL) {
	    func_trans_count += 1;
	    if (func_trans_count > MAX_SOURCE_FUNCS) {
		Punt("Error: ran out of space for func names, increase MAX_SOURCE_FUNCS"); 
            }
	    funcs_to_trans[func_trans_count] = strtok(NIL, " \t\n");
	}
    }

    /* Process transformations */
    if (strlen(transform_string) > 0) {

	t = (char *) malloc((strlen(transform_string)+1) * sizeof(char));
	strcpy(t, transform_string);

	trans = strtok(t, " \t\n");

	while (trans != NIL && isspace(trans[0])) trans = strtok(NIL, " \t\n");
	while (trans != NIL) {
	    
	    trans_len = strcspn(trans, small_alpha);  

	    if (trans_len == 0) {
		fprintf(Ferr, "Error, Invalid Transformation specified\n");
		exit(-1);
	    }

	    xform = NewXform();

	    if(xform_head == 0) {
	      xform_head = xform;
	      xform_tail = xform;
	    } else {
	      xform_tail->next = xform;
	      xform_tail = xform;
	    }

	    if (! strncmp(trans, "FWDSUB", trans_len)) {
		xform->type = TRANS_FWDSUB;
		xform->flags = TFLAG_FWDSUB_ARRAYS | TFLAG_FWDSUB_PARLOOPS;
		for (i=trans_len; trans[i] != '\0'; i++) {
		    switch (trans[i]) {
			case 'a':
			    xform->flags &= ~TFLAG_FWDSUB_ARRAYS;
			    break;
			case 'p':
			    xform->flags &= ~TFLAG_FWDSUB_PARLOOPS;
			    break;
			case 'r':
			    xform->flags |= TFLAG_FWDSUB_RECURSIVE;
			    break;
			default:
			    fprintf(Ferr, 
				"Error: unrecognized %s transformation flag: %c\n",
				"FWDSUB", trans[i]);
			    exit(-1);
		    }
		}
	    }
	    else if (! strncmp(trans, "DEADCD", trans_len)) {
		xform->type = TRANS_DEADCODE;
		for (i=trans_len; trans[i] != '\0'; i++) {
		    switch (trans[i]) {
			default:
			    fprintf(Ferr, 
				"Error: unrecognized %s transformation flag: %c\n",
				"DEADCD", trans[i]);
			    exit(-1);
		    }
		}
	    }
	    else if (! strncmp(trans, "IVS", trans_len)) {
		xform->type = TRANS_IVS;
		for (i=trans_len; trans[i] != '\0'; i++) {
		    switch (trans[i]) {
			default:
			    fprintf(Ferr,
				"Error: unrecognized %s transformation flag: %c\
    n",
				"IVS", trans[i]);
			    exit(-1);
		    }
		}
            }
	    else {
		fprintf(Ferr, 
			"Error, Invalid Transformation Specified: %s\n", trans);
		exit(-1);
	    }

	    trans = strtok(NIL, " \t\n");
	    while (trans != NIL && isspace(trans[0])) trans = strtok(NIL, " \t\n");
	}
	free(t);
    }

    /* open statistics files */

    if (OPEN_STAT_PCODE) {
        if (strcmp(F_stat_pcode, "stderr")) {
	    Fstpcode = fopen(F_stat_pcode, "w");
	    if (Fstpcode == NULL) {
		fprintf(Ferr, "Error: cannot open PCODE statistics file %s\n",
			F_stat_pcode);
		exit(-1);
	    }
	}
    }

    /* if verbose, print execution environment */
    if (verbose_yes) {

	fprintf(Flog, ".. [%s]\n", prog_name);
	fprintf(Flog, ".. verbose mode is ON\n");
	fprintf(Flog, ".. debug mode is %s\n", (debug_yes)?"ON":"OFF");
	fprintf(Flog, ".. input file is %s\n", F_input);
	fprintf(Flog, ".. output file is %s in %s format\n", F_output, 
		output_format_string);
	fprintf(Flog, ".. log file is %s\n", F_log);
	fprintf(Flog, ".. error file is %s\n", F_error);
	if (line_yes) fprintf(Flog, ".. include source position in output\n");
	if (parallel_flag) fprintf(Flog, ".. generate pstmt warnings\n");
	if (static_array) fprintf(Flog, ".. make local arrays static\n");
	else fprintf(Flog, ".. leave local arrays automatic\n");
	if (do_dependence) fprintf(Flog, ".. forcing dependence analysis\n");
	if (trans_named_funcs_only) {
	    fprintf(Flog, ".. Functions to transform: ");
	    for (i=0; i<func_trans_count; i++) 
		fprintf(Flog, "%s ", funcs_to_trans[i]);
	    fprintf(Flog, "\n");
	}
	fprintf(Flog, ".. transformations are %s\n", transform_string);
	if (OPEN_STAT_PCODE) 
	    fprintf(Flog, ".. Pcode statistics file is %s\n", F_stat_pcode);
    }
    return 0;
}
