/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/

/*****************************************************************************
 *	File:	struct.h
 *	Authors: David August, Nancy Warter, Grant Haab, Krishna Subramanian, 
 *               and Wen-mei Hwu
 *	Modified from code written by:	Po-hua Chang
 *      		Po-hua Chang, Wen-mei Hwu
 *      License Agreement specifies the terms and conditions for 
 *      redistribution.
 *****************************************************************************/

#ifndef STRUCT_H
#define STRUCT_H

#include <Pcode/impact_global.h>
#include <Pcode/pcode.h>

/*-------------------------------------------------------------*/
/* Define Constants                                            */
/*-------------------------------------------------------------*/
#define			DEFAULT_VALUE		0x7FFFFFFF

/*-------------------------------------------------------------*/
/* Functions in struct.c                                       */
/*-------------------------------------------------------------*/
/* There are 14 groups of functions:
 *   1. Memory Allocation Functions
 *   2. Functions for string manipulation (e.g., variable renaming, etc.)
 *   3. Functions for scope manipulation
 *   4. Functions to allocate new data structures
 *   5. Functions to remove data structures
 *   6. Copy functions
 *   7. Equivalence functions
 *   8. Symbol tree/table access functions
 *   9. Variable manipulation functions
 *  10. Declarator manipulation functions
 *  11. Expression manipulation functions
 *  12. Statement manipulating functions
 *  13. Parloop manipulation functions
 *  14. Pragma functions
 */

/*   1. Memory Allocation Functions */

/*-------------------------------------------------------------*/
/* Select method of memory allocation - IMPACT or malloc (GEH) */
/*-------------------------------------------------------------*/				
extern char		*imp_alloc();
#define ALLOCATE(x)	(x *) imp_alloc (sizeof(x))
#define DISPOSE(x)	imp_free(x, sizeof(*x))

/*   2. Functions for string manipulation (e.g., variable renaming, etc.) */
extern char             *NewName(char *name, int scopeid);
extern char             *NewName2(char *name);
extern char             *NewName3(VarDcl var);

/* BCC - NewNameIL and NewNameLabel added for Pinline - 11/12/95 */
extern char             *NewNameIL(char *name, int scopeid); 
extern char             *NewNameLabel(char *name, char *func_name, int scopeid);

extern bool		PrefixMatch(char *prefix, char *string);
extern char		*DQString2String(char *str);
extern int		RemoveDQ(char *str, char buf[], int N);
extern char 		*String2Ident(char *str);

/*   3. Functions for scope manipulation */
extern int 		NewScopeId();
extern Scope		NewScope(int id);
extern void		RemoveScope(Scope s);
extern ScopeList	NewScopeList();
extern void		RemoveScopeList(ScopeList s);
extern ScopeList	FindScopeList(ScopeList poss_list);
extern VarDcl		FindNearScopeVar(Scope poss_scopes, char *var);
extern StructDcl	FindNearScopeSt(Scope poss_scopes, char *st);
extern UnionDcl		FindNearScopeUn(Scope poss_scopes, char *un);
extern EnumDcl		FindNearScopeEn(Scope poss_scopes, char *en);
extern EnumDcl		FindNearScopeEnF(Scope poss_scopes, char *f);
extern int		ClosestScope(Scope poss_scopes, char *name);
extern void		AddScope(Scope poss_scopes, int id);
extern void		DeleteScope(Scope poss_scopes);
extern Scope		InitScopes();
extern void		AddScopeList(ScopeList poss_list);
extern void		DeleteScopeList(ScopeList poss_list);
extern ScopeList	InitScopeList();
extern void             Update_Expr_Scope(Expr expr, int orig_scope, 
					  int new_scope);
extern void             Update_ExprList_Scope(Expr exprlist, int orig_scope, 
					      int new_scope);
extern void             Update_Stmt_Scope(Stmt stmt, int orig_scope, 
					  int new_scope);

/*   4. Functions to allocate new data structures */
extern TypeDcl		NewTypeDcl();
extern FuncDcl		NewFuncDcl();
extern VarDcl		NewVarDcl();
extern VarList		NewVarList();
extern EnumDcl		NewEnumDcl();
extern EnumField	NewEnumField();
extern StructDcl	NewStructDcl();
extern UnionDcl		NewUnionDcl();
extern Dcl 		NewDcl();
extern DclList 		NewDclList();
extern Field		NewField();
extern Type		NewType();
extern Param		NewParam();	/* BCC - 1/22/96 */
extern Dcltr		NewDcltr();
extern Init		NewInit();
extern Stmt		NewStmt();
extern Compound		NewCompound();
extern IfStmt		NewIfStmt();
extern SwitchStmt	NewSwitchStmt();
extern Label            NewLabel();
extern Pstmt		NewPstmt();
extern Advance		NewAdvance();
extern Await		NewAwait();
extern Mutex		NewMutex();
extern Cobegin		NewCobegin();
extern ParLoop		NewParLoop();
extern SerLoop		NewSerLoop();
extern Pragma		NewPragma(char *str, Expr expr);
extern ProfFN 		NewProfFN(); /* LCW - 12/23/95 */
extern ProfBB 		NewProfBB(); /* LCW - 12/23/95 */
extern ProfCS 		NewProfCS(); /* LCW - 12/23/95 */
extern ProfArc 		NewProfArc(); /* LCW - 12/23/95 */
/* LCW - modify the parameter for the new profile structure - 10/25/95 */
extern ProfST		NewProfST(double profinfo);
/* LCW - Routine to create a new expression profile - 10/29/95 */
extern ProfEXPR 	NewProfEXPR(double profinfo);

extern BodyStmt         NewBodyStmt();
extern EpilogueStmt     NewEpilogueStmt();
extern Type		NewBasicType(int type);
/* BCC - Routines to allocate StructUnionPoolElem - 7/3/96 */
extern StructUnionPoolElem NewStructUnionPoolElem(_TypeClassQual type);

/*   5. Functions to remove data structures */
extern void		P_RemoveParam(Pragma);		/* BCC - 11/22/96 */
extern void		RemoveParam(Param param);	/* BCC - 1/22/96 */
extern void		RemoveType(Type type);
extern void		RemoveTypeDcl(TypeDcl typedcl);	/* BCC - 8/25/96 */
extern void		RemoveDcl(Dcl dcl);		/* BCC - 8/18/96 */
extern void		RemoveDcltr(Dcltr dcltr);	/* BCC - 8/18/96 */
extern void		RemoveVarDcl(VarDcl var);
extern void		RemoveVarList(VarList list);
extern void		RemoveVarList2(VarList list);
extern FuncDcl		RemoveFuncDcl(FuncDcl fn);
extern void	       	RemoveCompound(Compound stmt);
extern void		RemoveIfStmt(IfStmt stmt);
extern void		RemoveSwitchStmt(SwitchStmt stmt);
extern void		RemoveLabel(Label label);
extern void             RemoveLabels(Label list);
extern void     	RemovePstmt(Pstmt stmt);
extern void		RemoveAdvance(Advance stmt);
extern void		RemoveAwait(Await stmt);
extern void	       	RemoveMutex(Mutex stmt);
extern void		RemoveCobegin(Cobegin stmt);
extern void		RemoveParLoop(ParLoop stmt);
extern void		RemoveSerLoop(SerLoop stmt);
extern void		RemoveStmt(Stmt stmt);
extern void		RemoveStmts(Stmt list);
extern void             RemoveBodyStmt(BodyStmt stmt);
extern void             RemoveEpilogueStmt(EpilogueStmt stmt);
/* REMOVES EXPRESSION AND ALL SIBLING, NEXT AND OPERAND EXPRESSIONS */
extern void		RemoveExpr(Expr expr);
extern void		RemoveInit(Init init);
/* LCW - routine to remove profile info - 10/29/95 */
extern void 		RemoveProfST(ProfST prof);
extern void 		RemoveProfEXPR(ProfEXPR prof);
extern void 		RemoveProfFN(ProfFN prof); /* LCW - 12/23/95 */
extern void 		RemoveProfBB(ProfBB prof); /* LCW - 12/23/95 */
extern void 		RemoveProfCS(ProfCS prof); /* LCW - 12/23/95 */
extern void 		RemoveProfArc(ProfArc prof); /* LCW - 12/23/95 */

/*  6. Copy functions */
extern Pragma		CopyPragma(Pragma pragma, int next); /* BCC - 1/2/97 */
extern ProfFN 		CopyProfFN(ProfFN prof); /* LCW - 12/23/95 */
extern ProfBB 		CopyProfBB(ProfBB prof); /* LCW - 12/23/95 */
extern ProfCS 		CopyProfCS(ProfCS cs);   /* LCW - 12/23/95 */
extern ProfArc 		CopyProfArc(ProfArc arc); /* LCW - 12/23/95 */
extern ProfST		CopyProfST(ProfST profST);
/* LCW - copy the expression profile field - 10/29/95 */
extern ProfEXPR 	CopyProfEXPR(ProfEXPR prof);
extern Type		CopyType(Type type);
extern Expr		CopyExpr(Expr expr);
extern Expr             CopyExprList(Expr exprlist);
extern Expr		CopyExprWithAcc(Expr expr);
extern Expr             CopyExprListWithAcc(Expr exprlist);
extern Label		CopyLabels(Label label, Label prev, Stmt st);

/* warning:  CopyStmt may not be fully debugged!  - GEH */
extern Stmt             CopyStmt(Stmt stmt, Stmt prev, Stmt parent); 
extern VarList          CopyVarList(VarList list, int scope);
extern StructDcl	CopyStructDcl(StructDcl st);
extern UnionDcl		CopyUnionDcl(UnionDcl un);
extern EnumDcl		CopyEnumDcl(EnumDcl en);
extern VarDcl		CopyVarDcl(VarDcl var, int scope);
extern VarDcl           SP_CopyVarDcl(VarDcl var);
extern FuncDcl		CopyFuncDcl(FuncDcl fn);

/*   7. Equivalence functions */
/* BCC - added a new option for comparing Struct/Union/Enum - 7/3/96 */
extern bool		SameStructDcl(StructDcl d1, StructDcl d2, int name);
extern bool		SameUnionDcl(UnionDcl un1, UnionDcl un2, int name);
extern bool		SameEnumDcl(EnumDcl en1, EnumDcl en2, int name);
extern bool		SameType(Type t1, Type t2, int name);
extern bool		SameExpr(Expr e1, Expr e2);
extern bool		EqualType(Type t1, Type t2);	

/*   8. Symbol tree/table access functions */
extern void		AddStruct(char *name, char *rename, StructDcl st, 					  int scope_id);
extern StructDcl	FindStruct(char *name, int scope_id);
extern StructDcl	FindStructNoScopeId(char *name);
extern Field		FindStructField(StructDcl st, char *name);
extern void	       	AddUnion(char *name, char *rename, UnionDcl un, 
				 int scope_id);
extern UnionDcl		FindUnion(char *name, int scope_id);
extern UnionDcl		FindUnionNoScopeId(char *name);
extern Field		FindUnionField(UnionDcl un, char *name);
extern void		AddEnum(char *name, char *rename, EnumDcl en, 
				int scope_id);
extern EnumDcl		FindEnum(char *name, int scope_id);
extern EnumDcl		FindEnumNoScopeId(char *name);
extern EnumField	FindEnumFieldInEnum(EnumDcl en, char *name);
extern void		AddVar(char *name, char *rename, VarDcl var, 
			       int scope_id);
extern void		ReplaceVar(char *name, VarDcl var, int scope_id);
extern VarDcl		FindVar(char *name, int scope_id);
extern VarDcl		FindVarNoScopeId(char *name);
extern void		AddFunction(char *name, Type return_type);	
extern Symbol		FindFunction(char *name);
extern void		AddTypeDef(char *name, TypeDcl ty);
extern TypeDcl		FindTypeDef(char *name);
extern void     	AddEnumField(char *name, char *rename, EnumDcl en, 					     int scope_id);
extern EnumDcl		FindEnumField(char *name, int scope_id);
extern EnumDcl		FindEnumFieldNoScopeId(char *name);
extern VarDcl           var_name_to_var_dcl(char *var_name);
extern VarDcl           var_expr_to_var_dcl(Expr var_expr);
extern EnumField        enum_expr_to_enum_field(Expr enum_expr);

/* 9. Variable manipulation functions  */
extern VarDcl		FindVarList(VarList list, char *name);
extern VarList		AddVar2List(VarList list, VarDcl var);
extern void 		MoveVarList(VarList orig_varlist, VarList new_varlist, 
				    int orig_scope, int new_scope);
extern void 		InvalidateVarListSyms(VarList varlist, int scope);
extern VarList *	FindNearestEnclVarList(Stmt stmt, int *scope);
extern VarDcl           CreateFuncVar(char *fn_name, int return_type);
extern VarDcl		CreateGlobalVar(char *var_name, Type type);
extern VarDcl		CreateLocalVar(char *var_name, int scope, 
					VarList *varlist_ptr, Type type);
extern VarDcl 		CreateLocalVarBasicType(char *var_name, int scope, 
					VarList *varlist_ptr, int basic_type);

/*  10. Declarator manipulation functions */
extern Param		CopyParam(Param param);	/* BCC - 1/22/96 */
extern Dcltr		CopyDcltr(Dcltr dcltr);
extern Dcltr		ConcatDcltr(Dcltr A, Dcltr B);
extern Dcltr		ReverseDcltr(Dcltr A);

/*  11. Expression manipulation functions */
extern Expr             NewDualOpExpr(int op_type, Expr operand_1, 
				      Expr operand_2);
extern Expr             NewSingleOpExpr(int op_type, Expr operand);
extern Expr		GetLastOperand(Expr expr);
extern void		AddOperand(Expr expr1, Expr expr2);
extern void		AddNextOperand(Expr expr1, Expr expr2);
extern Expr 		ConcatNextExpr(Expr expr1, Expr expr2);
extern int		FindOperandNumber(Expr expr, Expr child_expr);
extern Expr		GetOperand(Expr expr, int N);
extern Expr             GetNextOperand(Expr expr, int N);  /* DIA */
extern void		ChangeOperand(Expr expr, int N, Expr operand);
extern bool		ReplaceExprWithExprList(Expr expr, Expr exprlist);
extern Expr		NewInstExpr(int opcode, Type type);
extern Expr		NewExpr();
extern Expr		NewVarExpr(char *var_name, Type type);
extern Expr		NewIntExpr(int value);
extern Expr		NewRealExpr(double value);
extern Expr		NewFloatExpr(double value);
extern Expr		NewDoubleExpr(double value);
extern Expr		NewCharExpr(char *ch);
extern Expr		NewStringExpr(char *str);
extern Expr		TrueExpr();
extern Expr		FalseExpr();
extern Expr		DefaultExpr();
extern bool		IsTrueExpr(Expr expr);
extern bool		IsFalseExpr(Expr expr);	
extern bool		IsDefaultExpr(Expr expr);
extern bool 		IsAncestorOfExpr(Expr e1, Expr e2);
extern bool 		IsRightDescendentOfExpr(Expr e1, Expr e2);
extern bool		DoesExprPrecedeExprInExprList(Expr e1, Expr e2);
extern Expr		FindNonCompExprAncestor(Expr expr);
extern Expr		FindChildOfAncestor(Expr expr, Expr ancestor);
extern bool		IsVarExpr(Expr expr);
extern bool		IsConstOne(Expr expr);
extern bool		IsConstZero(Expr expr);
extern bool		IsConstNonZero(Expr expr);
extern bool		IsConstNegative(Expr expr);
extern bool		IsIntegralExpr(Expr expr);
extern int		IntegralExprValue(Expr expr);
extern bool		IsRealExpr(Expr expr);
extern bool		IsFloatExpr(Expr expr);
extern bool		IsDoubleExpr(Expr expr);
extern double		FloatExprValue(Expr expr);
extern bool		IsConstNumber(Expr expr);
extern bool		IsSideEffectFree(Expr expr);
extern bool		IsBooleanExpr(Expr expr);
extern bool		is_func_call(Expr expr);
/* BCC - 1/23/97 */
extern bool		IsPcodeTemp(Expr expr);
extern bool 		IsUselessVar(Expr expr, char *str);


#define ExprOperand(x,y) GetOperand(y,x)
#define IntType()	NewBasicType(TY_INT)

/*  12. Statement manipulating functions */
/* warning, the following three functions have not been fully debugged! - GEH */
extern bool             Create_Encl_Compd_IfNeeded(Stmt stmt);
extern void             Insert_Stmt_Before(Stmt orig_stmt, Stmt new_stmt);
extern void		Insert_Stmt_After(Stmt orig_stmt, Stmt new_stmt);

extern bool 		NullStmts(Stmt list);
extern Stmt 		Stmt_Init(Stmt stmt);
extern Label		FindStmtLabel(Stmt stmt, char *name);
extern void 		AddStmtLabel(Stmt stmt, Label label);

/*  13. Parloop manipulation functions */
extern Stmt		Parloop_Stmts_Prologue_Stmt(Stmt parloop_stmt);
extern Stmt		Parloop_Stmts_Body_Stmt(Stmt parloop_stmt);
extern Stmt		Parloop_Stmts_First_Epilogue_Stmt(Stmt parloop_stmt);
extern Stmt             Parloop_Body_Stmt(ParLoop parloop);

/*  14. Pragma functions */
extern void		AddFunctionPragma(FuncDcl func, char *specifier, 
					  Expr expr);
extern Pragma		FindFunctionPragma(FuncDcl func, char *prefix);
extern bool	        RemoveFunctionPragma(FuncDcl func, Pragma pragma);
extern void     	AddExprPragma(Expr expr, char *specifier, Expr p_expr);
extern Pragma		FindExprPragma(Expr expr, char *prefix);
extern bool		RemoveStmtPragma(Stmt stmt, Pragma pragma);
extern bool		RemoveExprPragma(Expr expr, Pragma pragma);
extern void 		AddPragmaToStatement(Stmt stmt, Pragma pragma);
extern void     	AddStatementPragma(Stmt stmt, char *specifier, 
					   Expr p_expr);
extern Pragma 		FindStmtPragma(Stmt stmt, char *prefix);
extern Pragma 		ConcatPragma (Pragma pragma1, Pragma pragma2);

#endif
