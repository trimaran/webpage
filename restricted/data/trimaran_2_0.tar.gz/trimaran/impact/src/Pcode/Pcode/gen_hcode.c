/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.30  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 14, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/****************************************************************************\
 *	File:	gen_hcode.c
 *	Author: David August, Nancy Warter and Wen-mei Hwu
 *	Code Modified from code written by Po-hua Chang
 \*****************************************************************************/


#include <Pcode/cf_basic-block.h>
#include <Pcode/cf_dominator.h>
#include <Pcode/cf_post-dominator.h>
#include <Pcode/cf_loop-summ.h>
#include <Pcode/cf_loop-flow.h>
#include <Pcode/impact_global.h>
#include <Pcode/struct.h>
#include <Pcode/parms.h>
#include <Pcode/flow.h>
#include <Pcode/gen_hcode.h>
#include <Pcode/dd_sync-arc.h>
#include <Pcode/dd_acc-tbl.h>
#include <Hcode/h_prag.h>
#include <library/c_basic.h>
#include <Pcode/probe.h>
#include <string.h>
#include <Pcode/pcode.h>  /* LCW 5/10/96 */
#include <machine/m_spec.h>

static int do_output = 1;
#define OUTPUT		do_output
#define DO_OUTPUT(x)	(do_output = x)
/* TLJ 5/3/96 - Change this to check level of include file nesting */
#define BLOCK_OUTPUT    (include_nesting != 0)
#if 0
#define BLOCK_OUTPUT	(do_output == 0)
#endif

    /* Gen_Pcode and Gen_Hcode all have their own private
	FILE *F; it is really stupid, but needs to be left like it
	is; i.e. DON'T REMOVE THE static FROM THIS DECL */
static FILE *F = NULL;

/* DIA: 1/11/93 Create global variable for GenStmts. */

FNQueue FNListHead;
FNQueue FNListTail;

int Expr_Is_Explicit = TRUE;

/* LCW - flags for indicating if the current function is the main function
 * and if right after a functin call - 10/10/95 
 */
#if 0  /* LCW - don't need this flag anymore */
static int IS_MAIN = 0;
#endif
static int after_func_call = 0;

/* LCW - current profiling execution count */
static double current_prof_count;

/* LCW - the number of loops in a function - 3/24/99 */
static int loops_num;

/* BCC - flag about if the current token is inside a function - 4/1/96 */
static int INSIDE_FUNCTION;

/*****************************************************/

/* forward decls */

void GenParamDataDcl();
static GenLocalDataDcl();
static void GenExpr(Expr expr);
static int PP_get_loop_number(); /* LCW - 3/24/99 */

/* NJW - notes */
/* 9/10 - Don't have to worry about include files, run through cpp first 
 * 	- Do we want to pass line positions through hcode?? if line_yes x
 *	- Union, Struct, Enum, Var - all moved out - already renamed.
 *	- Gen_HCODE_Struct, Gen_HCODE_Enum, Gen_HCODE_Union x
 *	- Gen_HCODE_LinePos, Gen_HCODE_Var x
 *	- GenStructDcl, GenUnionDcl, GenEnumDcl, GenGlobalDataDcl x
 *	- GenStructField x
 *	- GenType, GenDcltr, GenInit x
 *	- Need to add Global and Parameter types - based on GenGlobalDataDcl
 *	  etc?? x
 * 9/11	- Need to convert the following:
 *	  GenOpcode [x], GenExprPragma [x], GenExpr [x], GenBasicBlock [ ], 
 *	  GenFunction [x], GenParamDataDcl [x], GenLocalDataDcl [x]
 *	- Add GenBBPragma[x], GenFnPragma[x]
 *	- Gen_HCODE_Func [x]
 *	- Gen_HCODE_Init (used for debugging purposes) [x]
 *	- Add sync opcode to hcode.  use expression pragmas to indicate 
 *	  sync type (e.g. advance, await, mutex_begin, mutex_end) and sync
 *	  operands (e.g. marker for advance, marker and distance for await,
 *	  sync_var for mutex_begin and end)
 *	- Need GenBasicBlockPragma's to pass doall, doacross, doserial,
 *	  dosuper.
 *	- Need to rename local variables with scoping (or something) because
 *	  Hcode only uses one symbol table for all variables. (done in pcode.c)
 * 9/12 - Don't think location allowed anywhere but before function in hcode?
 *	- GenStmts[ ]
 * 9/13 - Have to make sure that have a goto at the end of each basic block
 *	  except when it ends with: return, if, or switch.
 * 9/14 - finish case and default - check genstmts.
 *
 * 10/92 - add a clear string symbol table so that labels in different functions
 *         are unique (This is the only use of the string symbol table that I
 *         know of - if it is ever used for anything else, a new table should
 *         be defined - since this is cleared after every function is processed)
 */
/* have to handle special cases: comma, enum/var, sync 
 *   comma:  when process an expression list (expr->next), deternmine how many 
 *	     expressions are in the list and add that many "(comma ". after 
 *	     writing first two expressions from the list, print ")" and after 
 *	     that put ")" after each expression. 
 *	pp2p output looks like:
 *	  ((ASSIGN (VAR i) (INT 0)) (ASSIGN (VAR x) (INT 5)))
 *	Cugc output looks like:
 *	  (comma (assign (var i___1) (signed 0)) (assign (var x__1) (signed 5)))
 *	
 *   enum/var:  if expr->enum_flag then print "enum" else "var"
 *
 *   sync:  for advance, await, mutex (and the end of a mutex) need to
 *	    print out "sync" followed by an expression pragma.
 *	    The pragmas for sync:  (must be string)
 *		"ADVANCE___marker"
 *		"AWAIT___marker___distance"
 *		"MUTEXBEGIN___syncvar"
 *		"MUTEXEND___syncvar"
 * The bb pragmas for DOALL, DOACROSS, DOSERIAL, DOSUPER:   (must be a string)
 *    	"DOALL"
 *    	"DOACROSS"
 *    	"DOSERIAL"
 *    	"DOSUPER"
 */
/*========================================================================*/

/*========================================================================*/
static Punt(mesg)
     char *mesg;
{
  fprintf(Ferr, "# gen_hcode: %s\n", mesg);
  exit(-1);
}

static void encode_type_name(Type type, char *name)
{
    Dcltr dcltr;
    char dim[20];
    StructDcl st;
    UnionDcl un;
    int i;

    name[0] = 0;

    if (type->type & TY_UNSIGNED)
	strcat(name, "u");
    if (type->type & TY_VOID)
	strcat(name, "void");
    else if (type->type & TY_CHAR)
	strcat(name, "char");
    else if (type->type & TY_SHORT)
	strcat(name, "short");
    else if (type->type & TY_LONG)
	strcat(name, "long");
    else if (type->type & (TY_INT | TY_SIGNED | TY_ENUM))
	strcat(name, "int");
    else if (type->type & TY_FLOAT)
	strcat(name, "float");
    else if (type->type & TY_DOUBLE)
	strcat(name, "double");
    else if (type->type & TY_STRUCT)  {
        sprintf(name, "S_%s", type->struct_name);
    }
    else if (type->type & TY_UNION) {
        sprintf(name, "U_%s", type->struct_name);
    }
    else if (type->type & TY_VARARG)
	strcat(name, "vararg");
    else if (!name[0])
	    Punt("No type information");
    
    if (!strcmp(name, "u"))
	strcat(name, "int");

    if (type->dcltr)
	strcat(name, "+");

    for (i = 0, dcltr = type->dcltr; dcltr; i++, dcltr = dcltr->next) {
        switch (dcltr->method) {
            case D_ARRY :
		if (i == 0) {
		    sprintf(dim, "P");
		}
		else {
		    if (dcltr->index)
			sprintf(dim, "A%d", dcltr->index->value.scalar);
		    else
			sprintf(dim, "A");
		}
                strcat(name, dim);
                break;
            case D_PTR :
                strcat(name, "P");
                break;
            case D_FUNC :
		if (i == 0) {
		    strcat(name, "PF");
		}
		else 
		    strcat(name, "F");
                break;
        }
    }
}

static double ipow(double base, int power)
{
   int i;
   double result = 1.0;

   assert(power >= 0);
   for (i=1; i<=power; i++) {
       result *= base;
   }
   return result;
}


/*========================================================================*/
/* print type information. */
static GenType(type, option)
     Type type;
     int option;	/* 0 : print no class, 1 : print class, 
			 * 2: print class and global, 3: print class and parameter */
{
  int t;
  if (type==0) return;
  t = type->type;
  if (t==0) {
    fprintf(F, "TYPE_LESS ");
    return;
  }
  /* storage class */
  if (option!=0) {
    /* class */
    if (t & TY_REGISTER) fprintf(F, "(REGISTER)");
/* BCC - since all static variables have been renamed, don't print static
    if (t & TY_STATIC) fprintf(F, "(STATIC)");  - 6/13/95 */
/* BCC - instead, print "GLOBAL" */
    if (t & TY_STATIC) fprintf(F, "(GLOBAL)");
    if (t & TY_EXTERN) fprintf(F, "(EXTERN)");
    if (t & TY_AUTO) fprintf(F, "(AUTO)");
    /* DIA - 4/31/94: No GLOBAL and EXTERN or STATIC */
    if (!((t & TY_STATIC) || (t & TY_EXTERN)))
      if (option == 2) fprintf(F, "(GLOBAL)");
    if (option == 3) fprintf(F, "(PARAMETER)");
    /* qualifier */
    if (t & TY_CONST) fprintf(F, "(CONST)");
    if (t & TY_VOLATILE) fprintf(F, "(VOLATILE)");
    /* at present, won't gen noalias from pcode */
    /*
      if (t & TY_NOALIAS) fprintf(F, "(NOALIAS)"); 
      */
    /* pass sync as volatile through hcode ?? */
    if (t & TY_SYNC) fprintf(F, "(VOLATILE)");
  }
  /* type */ 
  if (t & TY_SIGNED) fprintf(F, "(SIGNED)");
  if (t & TY_UNSIGNED) fprintf(F, "(UNSIGNED)");
  if (t & TY_VOID) fprintf(F, "(VOID)");
  if (t & TY_SHORT) fprintf(F, "(SHORT)");
  if (t & TY_LONG) fprintf(F, "(LONG)");
  if (t & TY_CHAR) fprintf(F, "(CHAR)");
  if (t & TY_INT) fprintf(F, "(INT)");
  if (t & TY_FLOAT) fprintf(F, "(FLOAT)");
  if (t & TY_DOUBLE) fprintf(F, "(DOUBLE)");
  if (t & TY_VARARG) fprintf(F, "(VARARG)");	/* BCC - 1/24/96 */
  if (t & TY_STRUCT) fprintf(F, "(STRUCT %s)", type->struct_name);
  if (t & TY_UNION) fprintf(F, "(UNION %s)", type->struct_name);
  /* BCC - if doing spliting, enum are treated as int - 7/3/95 */
  if (t & TY_ENUM) {
    if (split == 0) fprintf(F, "(ENUM %s)", type->struct_name);
    else fprintf(F, "(INT)");
  }
}


/* BCC - 1/22/96 */
static GenDcltr(Dcltr, int);

/* BCC - 1/22/96 */
static GenParamTypeList(param)
     Param param;
{
  fprintf(F, " (");
  while (param) {
    fprintf(F, "(FPARAM (");
    GenType(param->type);
    GenDcltr(param->type->dcltr, 0);
    fprintf(F, "))");
    param = param->next;
  }
  fprintf(F, ")");
}

/* type:
 *  0:  no restrictions
 *  1:  don't print function declarator "F"
 */
static GenDcltr(dcltr, type)
     Dcltr dcltr;
     int type;
{
  fprintf(F, "(");
  /* GEH - added special code to strip off only FIRST function declarator */
  if (dcltr != 0 && dcltr->method == D_FUNC) {
    if(type != 1) {
/* 
 * BCC - 1/22/96
 * Changed the format of a function declarator from "F" to "(F (..) (..))" 
 * where "(..)" is the type of the parameters.
 */
      fprintf(F, "(F");
      if (dcltr->qualifier!=0) {
	/* GEH - print out function qualifiers */
        if (dcltr->qualifier & DQ_CDECL) fprintf(F, " CDECL");
        if (dcltr->qualifier & DQ_STDCALL) fprintf(F, " STDCALL");
        if (dcltr->qualifier & DQ_FASTCALL) fprintf(F, " FASTCALL");
      }
      if (dcltr->param!=0) 
	GenParamTypeList(dcltr->param);
      fprintf(F, ")");
      if (dcltr->next!=0) fprintf(F, " ");
    }
    dcltr = dcltr->next;
  }
  while (dcltr!=0) {
    switch (dcltr->method) {
    case D_ARRY:
      if (dcltr->index!=0) fprintf(F, "(");
      fprintf(F, "A");
      if (dcltr->index!=0) {
	fprintf(F, " ");
	GenExpr(dcltr->index);
      } 
      if (dcltr->index!=0) fprintf(F, ")");
      if (dcltr->next!=0) fprintf(F, " ");
      break;
    case D_PTR:
      if (dcltr->qualifier!=0) fprintf(F, "(");
      fprintf(F, "P");
      /* GEH - print out pointer qualifiers */
      if (dcltr->qualifier & DQ_CONST) fprintf(F, " CONST");
      if (dcltr->qualifier & DQ_VOLATILE) fprintf(F, " VOLATILE");
      if (dcltr->qualifier!=0) fprintf(F, ")");
      if (dcltr->next!=0) fprintf(F, " ");
      break;
    case D_FUNC:
/* 
 * BCC - 1/22/96
 * Changed the format of a function declarator from "F" to "(F (..) (..))" 
 * where "(..)" is the type of the parameters.
 */
      fprintf(F, "(F");
      if (dcltr->qualifier!=0) {
	/* GEH - print out function qualifiers */
        if (dcltr->qualifier & DQ_CDECL) fprintf(F, " CDECL");
        if (dcltr->qualifier & DQ_STDCALL) fprintf(F, " STDCALL");
        if (dcltr->qualifier & DQ_FASTCALL) fprintf(F, " FASTCALL");
      }
      if (dcltr->param!=0) 
        GenParamTypeList(dcltr->param);
      fprintf(F, ")");
      if (dcltr->next!=0) fprintf(F, " ");
      break;
    default:
      Punt("illegal dcltr");
    }
    dcltr = dcltr->next;
  }
  fprintf(F, ")");
}
/*========================================================================*/
static GenOpcode(opcode)
     int opcode;
{
  switch (opcode) {
  case OP_quest :		fprintf(F, "quest ");	break;
  case OP_disj :		fprintf(F, "disj ");	break;
  case OP_conj :		fprintf(F, "conj ");	break;
    /* where ever there is an expression list need to put comma's in betw? */
    /*
      case OP_comma :		fprintf(F, "comma ");	break;
      */
  case OP_assign :	fprintf(F, "assign ");	break;
  case OP_or :		fprintf(F, "or ");	break;
  case OP_xor :		fprintf(F, "xor ");	break;
  case OP_and :		fprintf(F, "and ");	break;
  case OP_eq :		fprintf(F, "eq ");	break;
  case OP_ne :		fprintf(F, "ne ");	break;
  case OP_lt :		fprintf(F, "lt ");	break;
  case OP_le :		fprintf(F, "le ");	break;
  case OP_ge :		fprintf(F, "ge ");	break;
  case OP_gt :		fprintf(F, "gt ");	break;
  case OP_rshft :		fprintf(F, "rshft ");	break;
  case OP_lshft :		fprintf(F, "lshft ");	break;
  case OP_add :		fprintf(F, "add ");	break;
  case OP_sub :		fprintf(F, "sub ");	break;
  case OP_mul :		fprintf(F, "mul ");	break;
  case OP_div :		fprintf(F, "div ");	break;
  case OP_mod :		fprintf(F, "mod ");	break;
  case OP_neg :		fprintf(F, "neg ");	break;
  case OP_not :		fprintf(F, "not ");	break;
  case OP_inv :		fprintf(F, "inv ");	break;
    /*
      case OP_abs :		fprintf(F, "abs ");	break;
      */
  case OP_preinc :	fprintf(F, "preinc ");	break;
  case OP_predec :	fprintf(F, "predec ");	break;
  case OP_postinc :	fprintf(F, "postinc ");	break;
  case OP_postdec :	fprintf(F, "postdec ");	break;
  case OP_Aadd :		fprintf(F, "Aadd ");	break;
  case OP_Asub :		fprintf(F, "Asub ");	break;
  case OP_Amul :		fprintf(F, "Amul ");	break;
  case OP_Adiv :		fprintf(F, "Adiv ");	break;
  case OP_Amod :		fprintf(F, "Amod ");	break;
  case OP_Arshft :	fprintf(F, "Arshft ");	break;
  case OP_Alshft :	fprintf(F, "Alshft ");	break;
  case OP_Aand :		fprintf(F, "Aand ");	break;
  case OP_Aor :		fprintf(F, "Aor ");	break;
  case OP_Axor :		fprintf(F, "Axor ");	break;
  case OP_indr :		fprintf(F, "indr ");	break;
  case OP_addr :		fprintf(F, "addr ");	break;
  case OP_index :		fprintf(F, "index ");	break;
  case OP_call :		fprintf(F, "call ");	break;
  case OP_dot :		fprintf(F, "dot ");	break;
  case OP_arrow :		fprintf(F, "arrow ");	break;
  case OP_compexpr:
  case OP_var :	
    /*
      case OP_enum :
      case OP_signed :
      case OP_unsigned :
      case OP_float :
      */
  case OP_int:
  case OP_real:
  /* BCC - added - 8/4/96 */
  case OP_float:
  case OP_double:
  case OP_char :
  case OP_string :
  case OP_cast :	
  case OP_expr_size :
  case OP_type_size :	
  case OP_error :
    /*
      case OP_return :
      case OP_goto :
      case OP_if :
      case OP_switch :
      */
    Punt("no opcode for this instruction");
    break;
    default :
      Punt("GenOpcode : illegal opcode");
  }
}

static void GenExprPragmaFromStr(char *pragmastr)
{
    fprintf(F, " (EXPR_PRAGMA \"%s\")", pragmastr);
}

static void GenConjDisjPragma(Pragma pragma)
{
    char *str;

    str = DQString2String(pragma->expr->value.string);
    fprintf(F, " (EXPR_PRAGMA \"CONJDISJ\\$%s\")", str);
    free(str);
}

static void GenCallNamePragma(Pragma pragma)
{
    char *str;

    str = DQString2String(pragma->expr->value.string);
    fprintf(F, " (EXPR_PRAGMA \"CALLNAME\\$%s\")", str);
    free(str);
}

static void GenIfElsePragma(Pragma pragma)
{
    char *str;

    str = DQString2String(pragma->expr->value.string);
    fprintf(F, " (EXPR_PRAGMA \"IFELSE\\$%s\")", str);
    free(str);
}

static void GenCallInfoPragma(Pragma pragma)
{
    char *str;

    str = DQString2String(pragma->expr->value.string);
    fprintf(F, " (EXPR_PRAGMA \"call_info\\$%s\")", str);
    free(str);
}

static void GenExprPragma(Pragma pragma)
{
    Pragma prag;
    char *str;

    for (prag = pragma; prag != NULL; prag = prag->next) {
	/* BCC - 9/12/96
	 * translate Pcode CALLNAME pragmas into Hcode format
	 */
	if (!strcmp(prag->specifier, "\"CALLNAME\""))
	    GenCallNamePragma(prag);
	else if (!strcmp(prag->specifier, "\"CONJDISJ\""))
	    GenConjDisjPragma(prag);
	else if (!strcmp(prag->specifier, "\"IFELSE\""))
	    GenIfElsePragma(prag);
	else if (!strcmp(prag->specifier, "\"call_info\""))
	    GenCallInfoPragma(prag);
	else {
	    /* BCC - bug fix - 10/15/96 */
	    if (prag->specifier[0] == '"') {
		str = DQString2String(prag->specifier);
		GenExprPragmaFromStr(str);
		free(str);
	    } else
		GenExprPragmaFromStr(prag->specifier);
	}
    }
}


static void GenBBPragmaFromStr(char *pragmastr)
{
  fprintf(F, "\t(BB_PRAGMA \"%s\")\n", pragmastr);
}

static void GenBBPragma(Pragma pragma)
{
    Pragma prag;

    for (prag = pragma; prag != NULL; prag = prag->next) {
	GenBBPragmaFromStr(prag->specifier);
    }
}

/* LCW - generate HCODE pragmas for loop iter profiling info - 3/27/99 */
static void GenLoopIterProfPragma(Pragma stmtpragma)
{
  Pragma pragma_ptr;
  char *str, *spec_str;

  if (stmtpragma == NULL)
     return;

  for (pragma_ptr = stmtpragma; pragma_ptr; pragma_ptr = pragma_ptr->next) {
      if (! strcmp(pragma_ptr->specifier, "\"iteration_header\"")) {
	 str = DQString2String(pragma_ptr->expr->value.string);
	 fprintf(F, "\t(BB_PRAGMA \"iteration_header%s\")\n", str);
	 free(str);
      }
      else if (! strncmp(pragma_ptr->specifier, "\"iter_", 6)) {
	 spec_str = DQString2String(pragma_ptr->specifier);
	 str = DQString2String(pragma_ptr->expr->value.string);
	 fprintf(F, "\t(BB_PRAGMA \"%s%s\")\n", spec_str, str);
	 free(spec_str);
	 free(str);
      }
  }
}


static void GenFnPragmaFromStr(char *pragmastr)
{
  fprintf(F, " (FN_PRAGMA \"%s\")\n", pragmastr);
}

static void GenFnPragma(Pragma pragma)
{
    Pragma prag;

    for (prag = pragma; prag != NULL; prag = prag->next) {
	GenFnPragmaFromStr(prag->specifier);
    }
}


/* LCW -- Find the scope id for the expression for debugging use - 7/25/95 */
static int FindExprScope(Expr expr)
{
   Stmt stmtptr;

   for (stmtptr=expr->parentstmt; stmtptr != 0; stmtptr=stmtptr->parent)
       if (stmtptr->type == ST_COMPOUND)
          return(stmtptr->stmtstruct.compound->scope);
   return(0);
}

/* LCW -- Find the scope id for the statement - 9/23/97 */
static int FindStmtScope(Stmt stmt)
{
   Stmt stmtptr;

   for (stmtptr=stmt; stmtptr != 0; stmtptr=stmtptr->parent)
       if (stmtptr->type == ST_COMPOUND)
          return(stmtptr->stmtstruct.compound->scope);
   return(0);
}


/* LCW -- strip the double quotes of file names so that the pragma-to-attribute
 * modules of Hcode don't get confused on those double quotes.   - 8/2/95
 */
static char * StripDoubleQuotes(char *dst_str, char *src_str)
{
   char *ptr1, *ptr2;

   *dst_str = '\0';
   /* LCW - check if the source string is null or not - 10/1/96 */
   if (src_str != NULL) {
      ptr1 = dst_str;
      ptr2 = src_str;
      while (*ptr2 != '\0')
         if (*ptr2 != '\"')
            *ptr1++ = *ptr2++;
         else
            ptr2++;
      *ptr1 = '\0';
   }
   return(dst_str);
}


/* generate expression. */
/* have to handle special cases: comma, enum/var, sync 
 * handle enum/var here.  handle comma and sync in GenBasicBlock
 */
/* OP_int -> signed, OP_real-> float */
static void GenExpr(Expr expr)
{
  VarDcl v;
  EnumDcl en;
  int s;
  int opcode, n;
  Expr arg;
  double prof_count, old_count; /* LCW */
  struct _ProfST *ProfStPtr; /* LCW */
  struct _ProfEXPR *ProfExprPtr; /* LCW */
  int rel_opcode; /* LCW */
  int IS_BUILTIN_FUNC = 0; /* LCW */
  char pragmastr[8192], temp_str[1024];
  char strip_fname[256];  /* LCW - hold a file name without double quotes.
                             - 8/2/95 */
  int comma_inserted = 0; /* LCW - 3/24/99 */

  if (expr==0) Punt("GenExpr : nil expr");

  /* LCW - put current profiling weight to the expression - 10/30/95 */
  if (DO_ANNOTATE_PCODE) 
     expr->profile = NewProfEXPR((double)current_prof_count);

  /*
   *	print expressions.
   */
  switch (opcode=expr->opcode) {
  case OP_var :
    /* BCC - if it's doing spliting, generate corresponding int value - 7/1/95*/
    if(expr->enum_flag) {
      if (split == 1) {
	EnumField enf;
	enf = enum_expr_to_enum_field(expr);
	assert(enf != NIL && enf->value != NIL);
	assert (enf->value->opcode == OP_int);
	fprintf(F, "(signed %d", enf->value->value.scalar);
      }
      else
	fprintf(F, "(enum \"%s\"", expr->value.var_name); 
    }
    else 
      fprintf(F, "(var %s", expr->value.var_name); 

    /* BCC - 10/6/97 */
    GenExprPragma(expr->pragma);

    fprintf(F, ")");
    break;
    /*
      case OP_enum :
      fprintf(F, "(enum %s)", expr->value.string); break;
      */
    /*
      case OP_signed :
      fprintf(F, "(signed %d)", expr->value.scalar);	break;
      case OP_unsigned :
      fprintf(F, "(unsigned %u)", expr->value.uscalar); break;
      case OP_float :
      fprintf(F, "(float %e)", expr->value.real);	break;
      */
  case OP_int :
    /* BCC - need to represent (unsigned int) -1 - 10/31/96 */
    if (expr->type && (expr->type->type & TY_UNSIGNED))
	fprintf(F, "(unsigned %d)", expr->value.scalar);
    else
	fprintf(F, "(signed %d)", expr->value.scalar);	
    break;
  /* BCC - added - 8/4/96 */
  case OP_float :
/***** DIA 1/30/94 - See codegen.c: "SAM 9-24-91"
    fprintf(F, "(float %.16e)", expr->value.real);	break;
*****/
/* GEH - added one more digit of precision to prevent rounding error - 4/27/95*/
    /* BCC - use 8 digits for float - 8/22/96 */
    fprintf(F, "(float %1.8e)", (float)expr->value.real);	break;
  /* BCC - added - 8/4/96 */
  case OP_double :
  case OP_real :
    fprintf(F, "(double %1.16e)", expr->value.real);	break;
  case OP_char :
    /* BCC - we need to represent (unsigned char) - 10/31/96 */
    if (expr->type && (expr->type->type & TY_UNSIGNED)) 
	fprintf(F, "(cast ((UNSIGNED)(CHAR)()) (char %s))", 
		expr->value.string);	
    else
	fprintf(F, "(char %s)", expr->value.string);	
    break;
  case OP_string :
    fprintf(F, "(string %s)", expr->value.string);	break;
  case OP_cast :
    fprintf(F, "(cast (");
    GenType(expr->type, 0);
    GenDcltr(expr->type->dcltr, 0);
    fprintf(F, ") ");
    GenExpr(ExprOperand(1, expr));
    fprintf(F, ")");
    break;
  case OP_type_size :
    fprintf(F, "(type_size (");
    GenType(expr->value.type, 0);
    GenDcltr(expr->value.type->dcltr, 0);
    fprintf(F, "))");
    break;
  case OP_expr_size :
    arg = ExprOperand(1, expr);
    if (arg==0) Punt("GenExpr : sizeof missing argument");
    fprintf(F, "(expr_size ");
    GenExpr(arg);
    fprintf(F, ")");
    break;
    /*
      case OP_return :
      case OP_goto :
      case OP_if :
      case OP_switch :
      Punt("GenExpr : premature return/jump/cond_br/switch");
      break;
      */
  case OP_quest :
    {
      /* LCW - check if the pcode file is flattened when doing inserting 
       * pseudo probes - 10/24/96 
       */
      if (INSIDE_FUNCTION && DO_INSERT_PSEUDO_PROBE)
	 Punt("Flattening pcode files before inserting pseudo probes");

      fprintf(F, "(quest ");
      /* can't be a comma expression */
      GenExpr(ExprOperand(1, expr));
      fprintf(F, " ");

      /* LCW - insert a probe in the then part of a quest-operator expression
       * - 10/30/95 
       */
      /* BCC - 4/1/96 
       * Don't probe codes in global data declarations since it is executed 
       * only once and the probe might screw up the syntax.
       */
      if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
	 fprintf(F, " (comma ");
         insert_middle_probe(F, next_probe++);
         fprintf(F, " ");
	 if (DO_ANNOTATE_PCODE) {
	    old_count = current_prof_count;
	    /* LCW - modified to read floating-point profile weights and to
	       handle the case when EOF is encountered - 3/5/97 */
            if (fscanf(Fprofile, "%lf", &current_prof_count) == EOF)
	       current_prof_count = 0.0;
	 }
	 GenCommaExpr(ExprOperand(2,expr));
	 fprintf(F, ")");
	 current_prof_count = old_count;
      }
      else {
         /* can be a comma expression */
         GenCommaExpr(ExprOperand(2,expr));
      }
      fprintf(F, " ");

      /* LCW - insert a probe in the else part of a quest-operator expression
       * - 10/18/95 
       */
      /* BCC - 4/1/96 
       * Don't probe codes in global data declarations since it is executed 
       * only once and the probe might screw up the syntax.
       */
      if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
         fprintf(F, " (comma ");
         insert_middle_probe(F, next_probe++);
	 fprintf(F, " ");
	 if (DO_ANNOTATE_PCODE) {
            old_count = current_prof_count;
	    /* LCW - modified to read floating-point profile weights and to
	       handle the case when EOF is encountered - 3/5/97 */
            if (fscanf(Fprofile, "%lf", &current_prof_count) == EOF)
	       current_prof_count = 0.0;
         }
         /* can't be a comma expression */
         GenExpr(ExprOperand(3, expr));
         fprintf(F, ")");
	 current_prof_count = old_count;
      }
      else
	 /* can't be a comma expression */
	 GenExpr(ExprOperand(3, expr));
      /*
	if (expr->pragma!=0) 
	GenExprPragma(expr->pragma);
	*/

      /* LCW - generate file name, line no and scope id pragmas. - 7/25/95 */
      if (EMIT_SOURCE_INFO) {   /* LCW 7/24/97 */
      	 if (expr->parentstmt != NULL) {
            HC_write_name_to_pragma_str(pragmastr, "POS");
            HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
            HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
            GenExprPragmaFromStr(pragmastr);
            HC_write_name_to_pragma_str(pragmastr, "SCOPE");
            HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
            GenExprPragmaFromStr(pragmastr);
      	 }
      }

      fprintf(F, ")");
      break;
    }
    /*
      case OP_comma :
      fprintf(F, "(comma ");
      GenExpr(ExprOperand(1, expr));
      fprintf(F, " ");
      GenExpr(ExprOperand(2, expr));
      if (expr->pragma!=0) 
      GenExprPragma(expr->pragma);
      fprintf(F, ")");
      break;
      */
  case OP_call :
    num_total_func_call++;

#if 0
    /* LCW - don't need to insert a probe before the function call -10/24/96 */
    /* LCW - insert a probe just before the function call - 10/29/95 */
    /* BCC - 4/1/96 
     * Don't probe codes in global data declarations since it is executed 
     * only once and the probe might screw up the syntax.
     */
    if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
       /* LCW - check if the function call is a built-in function. If it is,
	  don't put probe before it. - 2/17/96 */
       arg = ExprOperand(1, expr);
       IS_BUILTIN_FUNC = (arg->value.var_name != NULL) && 
			(! strncmp(arg->value.var_name, "__builtin", 9));
       if (! IS_BUILTIN_FUNC) {
          fprintf(F, " (comma ");
          insert_middle_probe(F, next_probe++);
          fprintf(F, " ");
       }

       /* LCW - append the profiling data - 10/30/95 */
       if (DO_ANNOTATE_PCODE) {
	  if (! IS_BUILTIN_FUNC) {
	     /* LCW - modified to read floating-point profile weights and to
	       handle the case when EOF is encountered - 3/5/97 */
	     if (fscanf(Fprofile, "%lf", &current_prof_count) == EOF)
	        current_prof_count = 0.0;
	     RemoveProfEXPR(expr->profile);
	     expr->profile = NewProfEXPR((double)current_prof_count);
	  }
	  else {
	     RemoveProfEXPR(expr->profile);
	     expr->profile = NewProfEXPR((double)current_prof_count);
	  }
       }
    }
#endif

    /* LCW - check if this is an exit call. If it is, check if it is in a 
       loop, if it is, insert a function call to update the loop iter 
       counter - 3/24/99 */
    if (DO_INSERT_LOOP_TRIP_COUNT_PROBE && INSIDE_FUNCTION) {
       comma_inserted = 0;
       arg = ExprOperand(1, expr);
       if ((arg->value.var_name != NULL) && 
	   (! strcmp(arg->value.var_name, "exit"))) {
	  Stmt loopstmt;
	  for (loopstmt = expr->parentstmt; loopstmt != NIL;
	       loopstmt = loopstmt->parent) {
	      if (loopstmt->type == ST_SERLOOP) {
		 int *loop_id_ptr; 
		 if ((loop_id_ptr = (int *)loopstmt->ext) == 0)
		    Punt("GenExpr: lack of loop id info");
		 if (! comma_inserted) {
		    fprintf(F, " (comma ");
		    comma_inserted = 1;
		 }
		 PP_gen_update_lp_iter_func_in_middle(F, *loop_id_ptr);
		 fprintf(F, " ");
	      }
	  }
       }
    }

    /* Don't add call_info pragma if annotating in profile info 
     * (otherwise, get two pragmas per call if doing profiling.)
     */
    if (!DO_ANNOTATE_PCODE)
    {
	/* BCC 5/16/98 */
	sprintf(pragmastr, "\""); 
	encode_type_name(expr->type, temp_str);
	strcat(pragmastr, temp_str);
	for (n = 1, arg = ExprOperand(2, expr); arg; arg = arg->next) {
	    strcat(pragmastr, "%");
	    encode_type_name(arg->type, temp_str);
	    strcat(pragmastr, temp_str);
	}
	strcat(pragmastr, "\"");
	AddExprPragma(expr, strdup("\"call_info\""), 
		      NewStringExpr(strdup(pragmastr)));
    }

    fprintf(F, "(call");
    arg = ExprOperand(1, expr);
    fprintf(F, " ");
    GenExpr(arg);
    arg = ExprOperand(2, expr);
    for(; arg != 0; arg = arg->next) {
      fprintf(F, " ");
      GenExpr(arg);
    }
    
    /* old code - 7/92 
       for (n=1; (arg=ExprOperand(n, expr)) != 0; n++) {
       fprintf(F, " ");
       GenExpr(arg);
       }
       */
  
    /* BCC - 12/8/97 
    if (expr->pragma!=0) 
        GenExprPragma(expr->pragma);
    */

    /* GEH - print expression pragma for calling convention qualifier */
    arg = ExprOperand(1, expr);
    if (arg->type->dcltr != 0 &&
	arg->type->dcltr->method == D_FUNC &&
        arg->type->dcltr->qualifier !=0) {

	HC_write_name_to_pragma_str(pragmastr, "CALL_CONV");
	if (arg->type->dcltr->qualifier & DQ_CDECL) 
	    HC_append_string_to_pragma_str(pragmastr, "CDECL");
	if (arg->type->dcltr->qualifier & DQ_STDCALL) 
	    HC_append_string_to_pragma_str(pragmastr, "STDCALL");
	if (arg->type->dcltr->qualifier & DQ_FASTCALL) 
	    HC_append_string_to_pragma_str(pragmastr, "FASTCALL");
	GenExprPragmaFromStr(pragmastr);
    }

    /* BCC - 10/6/97 */
    GenExprPragma(expr->pragma);

    /* LCW - generate file name, line no and scope id pragmas. - 7/25/95 */
    if (EMIT_SOURCE_INFO) {  /* LCW - 7/24/97 */
       if (expr->parentstmt != NULL) {
          HC_write_name_to_pragma_str(pragmastr, "POS");
          HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
          HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
          GenExprPragmaFromStr(pragmastr);
          HC_write_name_to_pragma_str(pragmastr, "SCOPE");
       	  HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
          GenExprPragmaFromStr(pragmastr);
       }
    }

    fprintf(F, ")");

#if 0
    /* LCW - don't need to insert a probe before function call - 10/24/96 */
    /* LCW - right parenthesis for the inserted comma expression - 10/29/95 */
    /* BCC - 4/1/96 
     * Don't probe codes in global data declarations since it is executed 
     * only once and the probe might screw up the syntax.
     */
    if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) 
       if (! IS_BUILTIN_FUNC)
          fprintf(F, ")");
#endif

    /* LCW - right parenthesis for the inserted comma expression - 3/24/99 */
    if (DO_INSERT_LOOP_TRIP_COUNT_PROBE && INSIDE_FUNCTION)
       if (comma_inserted)
	  fprintf(F, ")");

    /* LCW - set flag indicating after func call - 10/12/95 */
    after_func_call = 1;
    break;
  case OP_index :
    fprintf(F, "(index ");
    GenExpr(ExprOperand(1, expr));
    fprintf(F, " ");
    GenCommaExpr(ExprOperand(2, expr));
    /*
      if (expr->pragma!=0) 
      GenExprPragma(expr->pragma);
      */

    /* BCC - 12/8/97 */
    GenExprPragma(expr->pragma);

    /* LCW - generate file name, line no and scope id pragmas. - 7/25/95 */
    if (EMIT_SOURCE_INFO) {  /* LCW - 7/24/97 */
       if (expr->parentstmt != NULL) {
          HC_write_name_to_pragma_str(pragmastr, "POS");
          HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
          HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
          GenExprPragmaFromStr(pragmastr);
          HC_write_name_to_pragma_str(pragmastr, "SCOPE");
          HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
          GenExprPragmaFromStr(pragmastr);
       }
    }


    fprintf(F, ")");
    break;
    /* binary */
  case OP_disj :
  case OP_conj :
    /* LCW - check if the pcode file is flattened when doing inserting 
     * pseudo probes - 10/24/96 
     */
    if (DO_INSERT_PSEUDO_PROBE)
       Punt("Flattening pcode files before inserting pseudo probes");

    /* LCW - insert probe to each conditional expression of a conj or disj
     * expression - 10/08/95
     */
    /* BCC - 4/1/96 
     * Don't probe codes in global data declarations since it is executed 
     * only once and the probe might screw up the syntax.
     */
    if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
       fprintf(F, "(");
       GenOpcode(opcode);
       rel_opcode = (ExprOperand(1, expr))->opcode;
       if ((rel_opcode != OP_disj) && (rel_opcode != OP_conj)) {
          fprintf(F, " (comma ");
          insert_middle_probe(F, next_probe++);

          /* LCW - read the profiling data - 10/24/95 */
          if (DO_ANNOTATE_PCODE) {
	     old_count = current_prof_count;
	     /* LCW - modified to read floating-point profile weights and to
	       handle the case when EOF is encountered - 3/5/97 */
             if (fscanf(Fprofile, "%lf", &current_prof_count) == EOF)
	        current_prof_count = 0.0;
	  }
       }

       fprintf(F, " ");
       GenExpr(ExprOperand(1, expr));
       if ((rel_opcode != OP_disj) && (rel_opcode != OP_conj))
          fprintf(F, ")");

       /* LCW - reset the profiling data - 10/30/95 */
       if (DO_ANNOTATE_PCODE) {
          RemoveProfEXPR(expr->profile);
          expr->profile = NewProfEXPR((ExprOperand(1, expr))->profile->count);
	  current_prof_count = old_count;
       }

       rel_opcode = (ExprOperand(2, expr))->opcode;
       if ((rel_opcode != OP_disj) && (rel_opcode != OP_conj)) {
          fprintf(F, " (comma ");
          insert_middle_probe(F, next_probe++);

          /* LCW - read the profiling data - 10/24/95 */
          if (DO_ANNOTATE_PCODE) {
	     /* LCW - modified to read floating-point profile weights and to
	       handle the case when EOF is encountered - 3/5/97 */
             if (fscanf(Fprofile, "%lf", &current_prof_count) == EOF)
	        current_prof_count = 0.0;
	     old_count = current_prof_count;
	  }
       }

       fprintf(F, " ");
       GenExpr(ExprOperand(2, expr));
       if ((rel_opcode != OP_disj) && (rel_opcode != OP_conj))
          fprintf(F, ")");
       fprintf(F, ")");
       if (DO_ANNOTATE_PCODE)
	  current_prof_count = old_count;
       break;
    }
  case OP_or :
  case OP_xor :
  case OP_and :
  case OP_eq :
  case OP_ne :
  case OP_lt :
  case OP_le :
  case OP_ge :
  case OP_gt :
  case OP_rshft :
  case OP_lshft :
  case OP_add :
  case OP_sub :
  case OP_mul :
  case OP_div :
  case OP_mod :
    fprintf(F, "(");
    GenOpcode(opcode);
    GenExpr(ExprOperand(1, expr));
    fprintf(F, " ");
    GenExpr(ExprOperand(2, expr));
    /*
      if (expr->pragma!=0) 
      GenExprPragma(expr->pragma);
      */

    /* LCW - generate file name, line no and scope id pragmas. - 7/25/95 */
    if (EMIT_SOURCE_INFO) {  /* LCW - 7/24/97 */
       if (expr->parentstmt != NULL) {
          HC_write_name_to_pragma_str(pragmastr, "POS");
          HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
          HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
          GenExprPragmaFromStr(pragmastr);
          HC_write_name_to_pragma_str(pragmastr, "SCOPE");
          HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
          GenExprPragmaFromStr(pragmastr);
       }
    }
    fprintf(F, ")");
    break;
  /*
   * BCC - 11/13/97
   * If the assignment is of the form "@arg.... = i" or
   * "@return.... = j", just print the right-hand-side as i or j.
   * If the assignment is of the form "k = @param....", just ignore
   * the whole thing.
   */
  case OP_assign :
    if (IsUselessVar(expr->operands, NULL))
	GenExpr(ExprOperand(2, expr));
    else {
	Expr op1, op2, op2_1;
	
	op1 = ExprOperand(1, expr);
	op2 = ExprOperand(2, expr);
	op2_1 = ExprOperand(1, op2);
	
	if ((op1->opcode == OP_var) && 
	    (strstr(op1->value.string, "@arg") ||
	     strstr(op1->value.string, "@return"))) {
	    GenExpr(ExprOperand(2, expr));
	}
	else if ((op2->opcode == OP_var) && 
	         strstr(op2->value.string, "@param")) {
	    GenExpr(ExprOperand(1, expr));
	}
	else {
	    fprintf(F, "(");
	    GenOpcode(opcode);
	    GenExpr(ExprOperand(1, expr));
	    fprintf(F, " ");
	    if (op2->opcode == OP_cast &&
		op1->type->dcltr == 0 &&
		op2->type->dcltr == 0 &&
		op2_1->type->dcltr == 0 &&
		(((op1->type->type & TY_CHAR) && 
		  (op2_1->type->type & (TY_SHORT | TY_INT | TY_LONG))) ||
		 ((op1->type->type & TY_SHORT) && 
		  (op2_1->type->type & (TY_INT | TY_LONG)))))
		GenExpr(op2_1);
	    else
		GenExpr(ExprOperand(2, expr));
	    /* LCW - generate file name, line no and scope id pragmas. 
	       - 7/25/95 */
	    if (EMIT_SOURCE_INFO) {  /* LCW - 7/24/97 */
	       if (expr->parentstmt != NULL) {
		  HC_write_name_to_pragma_str(pragmastr, "POS");
		  HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
		  HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
		  GenExprPragmaFromStr(pragmastr);
		  HC_write_name_to_pragma_str(pragmastr, "SCOPE");
		  HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
		  GenExprPragmaFromStr(pragmastr);
	       }
	    }
	    fprintf(F, ")");
	}

    }
    break;
  case OP_Aadd :
  case OP_Asub :
  case OP_Amul :
  case OP_Adiv :
  case OP_Amod :
  case OP_Arshft :
  case OP_Alshft :
  case OP_Aand :
  case OP_Aor :
  case OP_Axor :
    fprintf(F, "(");
    GenOpcode(opcode);
    GenExpr(ExprOperand(1, expr));
    fprintf(F, " ");
    GenExpr(ExprOperand(2, expr));
    /* BCC - 10/6/97 */
    GenExprPragma(expr->pragma);
  
    /* LCW - generate file name, line no and scope id pragmas. - 7/25/95 */
    if (EMIT_SOURCE_INFO) {  /* LCW - 7/24/97 */
       if (expr->parentstmt != NULL) {
          HC_write_name_to_pragma_str(pragmastr, "POS");
          HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
          HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
          GenExprPragmaFromStr(pragmastr);
          HC_write_name_to_pragma_str(pragmastr, "SCOPE");
          HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
          GenExprPragmaFromStr(pragmastr);
       }
    }

    fprintf(F, ")");
    break;
    /* the second operand is in value.string */
  case OP_dot :
  case OP_arrow :
    fprintf(F, "(");
    GenOpcode(opcode);
    GenExpr(ExprOperand(1, expr));
    fprintf(F, " \"%s\"", expr->value.string);

    /* BCC - 10/6/97 */
    GenExprPragma(expr->pragma);

    /* LCW - generate file name, line no and scope id pragmas. - 7/25/95 */
    if (EMIT_SOURCE_INFO) {  /* LCW - 7/24/97 */
       if (expr->parentstmt != NULL) {
          HC_write_name_to_pragma_str(pragmastr, "POS");
          HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
          HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
          GenExprPragmaFromStr(pragmastr);
          HC_write_name_to_pragma_str(pragmastr, "SCOPE");
          HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
          GenExprPragmaFromStr(pragmastr);
       }
    }

    fprintf(F, ")");
    break;
    /* unary */
  case OP_neg :
  case OP_not :
  case OP_inv :
    /*
      case OP_abs :
      */
  case OP_preinc :
  case OP_predec :
  case OP_postinc :
  case OP_postdec :
    fprintf(F, "(");
    GenOpcode(opcode);
    GenExpr(ExprOperand(1, expr));

    /* BCC - 10/6/97 */
    GenExprPragma(expr->pragma);
  
    /* LCW - generate file name, line no and scope id pragmas. - 7/25/95 */
    if (EMIT_SOURCE_INFO) {  /* LCW - 7/24/97 */
       if (expr->parentstmt != NULL) {
          HC_write_name_to_pragma_str(pragmastr, "POS");
          HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
          HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
          GenExprPragmaFromStr(pragmastr);
          HC_write_name_to_pragma_str(pragmastr, "SCOPE");
          HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
          GenExprPragmaFromStr(pragmastr);
       }
    }

    fprintf(F, ")");
    break;
  case OP_addr :
    fprintf(F, "(");
    GenOpcode(opcode);
    GenExpr(ExprOperand(1, expr));

    /* LCW - generate file name, line no and scope id pragmas. - 7/25/95 */
    if (EMIT_SOURCE_INFO) {  /* LCW - 7/24/97 */
       if (expr->parentstmt != NULL) {
          HC_write_name_to_pragma_str(pragmastr, "POS");
          HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
          HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
          GenExprPragmaFromStr(pragmastr);
          HC_write_name_to_pragma_str(pragmastr, "SCOPE");
          HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
          GenExprPragmaFromStr(pragmastr);
       }
    }

    /* BCC - 2/25/97 */
    if (generate_gvar_address_taken) {
	if (expr->operands->opcode == OP_var && FindVar(expr->operands->value.string, 0)) {
	    fprintf(Fout_gvar, "%s\n", expr->operands->value.string);
	}
    };
    fprintf(F, ")");
    break;

  case OP_indr :
    fprintf(F, "(");
    GenOpcode(opcode);
    GenExpr(ExprOperand(1, expr));

    /* BCC - 10/6/97 */
    GenExprPragma(expr->pragma);

    /* LCW - generate file name, line no and scope id pragmas. - 7/25/95 */
    if (EMIT_SOURCE_INFO) {  /* LCW - 7/24/97 */
       if (expr->parentstmt != NULL) {
          HC_write_name_to_pragma_str(pragmastr, "POS");
          HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, expr->parentstmt->filename));
          HC_append_int_to_pragma_str(pragmastr, expr->parentstmt->lineno);
          GenExprPragmaFromStr(pragmastr);
          HC_write_name_to_pragma_str(pragmastr, "SCOPE");
          HC_append_int_to_pragma_str(pragmastr, FindExprScope(expr));
          GenExprPragmaFromStr(pragmastr);
       }
    }

    fprintf(F, ")");
    break;
  case OP_compexpr:
    {
      GenCommaExpr(ExprOperand(1, expr));
      /* LCW - reset the profiling data - 10/30/95 */
      if (DO_ANNOTATE_PCODE) {
         RemoveProfEXPR(expr->profile);
	 expr->profile = NewProfEXPR((ExprOperand(1, expr))->profile->count);
      }
      break;
    }
    /* don't do anything for the following */
  case OP_error :		
    break;
    default :
      Punt("GenExpr : illegal expression");
  }
}


/* check if the loop increment is one.  if not punt 
 * for now just implement a simple check that assumes the
 * expression must be in the form of (int 1)
 */
int IncrOne(expr)
     Expr expr;
{
  if((expr->opcode != OP_int) || (expr->value.scalar != 1))
    return 0;
  else 
    return 1;
}
/*
 *  FindVarName - get the variable name from a variable expresssion.
 *  if not a variable expression punt with message that can only
 *  handle simple mutex variable expression.
 */
char *FindVarName(expr)
     Expr expr;
{
  if(expr->opcode != OP_var)
    Punt("Can only handle simple mutex variable expression");
  else {
    if( (! (expr->type->type & TY_SYNC)) && 
       (! (expr->type->type & TY_VOLATILE)))
      Punt("Mutex variable must have either sync or volatile type");
    else
      return(expr->value.var_name);
  }
}

/* Generate comma expression.
 *  go through the list and count the expressions.  for n expressions, need 
 *  n-1 comma stmts. first, print the comma stmts. next, print the 
 *  expressions.  after the first two expressions, print a ')' then after 
 *  each expression print ')'.
 *  e.g., (comma (comma (expr1) (expr2)) (expr3))
 */
GenCommaExpr(expr)
     Expr expr;
{
  Expr p;
  int count = 1;
  int i;
  if(expr == 0) return;
  p = expr;
  while(p->next!=0) {
    p = p->next;
    count++;
  }
  if(count == 1)
    GenExpr(expr);
  else {
    fprintf(F, "\t(comma ");
    for(i=3; i<=count; i++) 
      fprintf(F, "(comma ");
    for(i=1, p=expr; p!=0; i++, p=p->next) {
      GenExpr(p);
      if(i>=2)
	fprintf(F, ")");
      if(i!=count)
	fprintf(F, " ");
    }
  }
}


/*********************************************
**  Generate Statement Code Begins          **
**  DIA: 1/6/93                             **
*********************************************/


InitFNQueue()
 {
  FNListHead = NULL;
  FNListTail = NULL;
 }

FNEnqueue(FlowNode fn)
 {
  FNQueue New;

  if (fn == NULL)
    return;
  New = ALLOCATE(_FNQueue);
  New->next = NULL;
  New->fn = fn;
  if (FNListHead == NULL)
    FNListHead = New;
  else
    FNListTail->next = New;
  FNListTail = New;
 }

FlowNode FNDequeue()
 {
  FlowNode RetVal;
  FNQueue Entry;

  if (FNListHead == NULL)
    return NULL;

  Entry = FNListHead;
  RetVal = Entry->fn;
  FNListHead = FNListHead->next;
  DISPOSE(Entry);
  return (RetVal);
 }

/*
** BuildFNQueue - Builds the Flow Node Queue representation.
*/

BuildFNQueue(Stmt st)
 {
  Stmt StmtIndx;

  /* Return if there are no statements */  
  if(st == NULL)
    return;
  
  /* handle each statement */
  switch(st->type)
   {
    case ST_CONT:
    case ST_BREAK:
    case ST_RETURN:
    case ST_GOTO:
    case ST_EXPR:
    case ST_ADVANCE:
    case ST_AWAIT:
    case ST_NOOP:
     {
      FNEnqueue(st->flow->entry_flow_node);
      break;
     }
    case ST_IF:
     {
      FNEnqueue(st->flow->entry_flow_node);
      BuildFNQueue(st->stmtstruct.ifstmt->then_block);
      BuildFNQueue(st->stmtstruct.ifstmt->else_block);
      FNEnqueue( FindFlowNodeInList(NT_IfExit, st->flow->flow_node_list) );
      break;
     }
    case ST_PSTMT:	
     {
      FNEnqueue(st->flow->entry_flow_node);
      BuildFNQueue(st->stmtstruct.pstmt->stmt);
      FNEnqueue( FindFlowNodeInList(NT_PStmtExit, st->flow->flow_node_list) );
      break;
     }
    case ST_MUTEX:
     {
      FNEnqueue(st->flow->entry_flow_node);
      BuildFNQueue(st->stmtstruct.mutex->statement);
      FNEnqueue( FindFlowNodeInList(NT_MutexExit, st->flow->flow_node_list) );
      break;
     }
    case ST_COBEGIN:
     { 
      Punt("GenStmts:  Can't handle cobegin yet");
      break;
     }
    case ST_SWITCH:
     {
      FNEnqueue(st->flow->entry_flow_node);
      BuildFNQueue(st->stmtstruct.switchstmt->switchbody);
      FNEnqueue( FindFlowNodeInList(NT_SwitchExit, st->flow->flow_node_list) );
      break;
     }
    case ST_COMPOUND:  
     {  
      FNEnqueue(st->flow->entry_flow_node);
      StmtIndx = st->stmtstruct.compound->stmt_list;
      while(StmtIndx != NULL)
       {
        BuildFNQueue(StmtIndx);
        StmtIndx = StmtIndx -> lex_next;
       }
      FNEnqueue( FindFlowNodeInList(NT_CompoundExit, st->flow->flow_node_list) );
      break;
     }
    case ST_PARLOOP:
     {
      StmtIndx = st->stmtstruct.parloop->pstmt->stmt;
      FNEnqueue( FindFlowNodeInList(NT_ParloopInitCond, st->flow->flow_node_list) );
      FNEnqueue( FindFlowNodeInList(NT_PStmtCompEntry, StmtIndx->flow->flow_node_list) );

      StmtIndx = StmtIndx->stmtstruct.compound->stmt_list;
      while(StmtIndx && StmtIndx->type != ST_BODY && StmtIndx->type != ST_EPILOGUE)
       { 
        BuildFNQueue(StmtIndx);
        StmtIndx = StmtIndx->lex_next;
       }

      BuildFNQueue(StmtIndx);

      FNEnqueue( FindFlowNodeInList(NT_ParloopIterCond, st->flow->flow_node_list) );
     
#if 0
      StmtIndx = StmtIndx->lex_next;
      BuildFNQueue(StmtIndx);
#endif
      if(StmtIndx)
       {
        StmtIndx = StmtIndx->lex_next;
        while(StmtIndx)
         { 
          BuildFNQueue(StmtIndx);
          StmtIndx = StmtIndx->lex_next;
         }
       }

      FNEnqueue( FindFlowNodeInList(NT_PStmtCompExit,
                 st->stmtstruct.parloop->pstmt->stmt->flow->flow_node_list) );
      /* GEH - should put Epilogue CF nodes on the queue also soon */
      FNEnqueue( FindFlowNodeInList(NT_ParloopExit, st->flow->flow_node_list) );

      break;
     }
    case ST_SERLOOP:
     {
      switch(st->stmtstruct.serloop->loop_type)
       {
        case LT_FOR:
        case LT_WHILE:
	/* GEH - modified for new for-while loops */
         {
          FNEnqueue( FindFlowNodeInList(NT_SerloopInitCond, st->flow->flow_node_list) );
          BuildFNQueue(st->stmtstruct.serloop->loop_body);
          FNEnqueue( FindFlowNodeInList(NT_SerloopIterCond, st->flow->flow_node_list) );
          FNEnqueue( FindFlowNodeInList(NT_SerloopExit, st->flow->flow_node_list) );
          break;
         }
        case LT_DO:
         {
          FNEnqueue( FindFlowNodeInList(NT_SerloopEntry, st->flow->flow_node_list) );
          BuildFNQueue(st->stmtstruct.serloop->loop_body);
          FNEnqueue( FindFlowNodeInList(NT_SerloopCond, st->flow->flow_node_list) );
          FNEnqueue( FindFlowNodeInList(NT_SerloopExit, st->flow->flow_node_list) );
          break;
         }
       }
      break;
     }
    case ST_BODY:
     {
      FNEnqueue(st->flow->entry_flow_node);
      BuildFNQueue(st->stmtstruct.bodystmt->statement);
      break;
     }
    case ST_EPILOGUE:
     {
      FNEnqueue(st->flow->entry_flow_node);
      BuildFNQueue(st->stmtstruct.epiloguestmt->statement);
      break;
     }
    default:
      Punt("GenStmts: Invalid instruction type");
   }
  
 }

Add_Stats_Directive(char *name, Stmt loop_stmt)
 {
  char pragmastr[256];

  /* GEH - add sync with attribute for marking loops */
  if (hcode_loop_sim_prags) 
   {
    fprintf(F, "\t(sync ");
    HC_write_name_to_pragma_str(pragmastr, name);
    HC_append_string_to_pragma_str(pragmastr, 
				   DQString2String(loop_stmt->filename));
    HC_append_int_to_pragma_str(pragmastr, loop_stmt->lineno);
    assert(loop_stmt->type == ST_PARLOOP || loop_stmt->type == ST_SERLOOP);
    if (loop_stmt->type == ST_PARLOOP) 
     {
      switch(loop_stmt->stmtstruct.parloop->loop_type) 
       {
	case LT_DOSUPER:
	  HC_append_string_to_pragma_str(pragmastr, "dosuper");
	  break;
	case LT_DOALL:
	  HC_append_string_to_pragma_str(pragmastr, "doall");
	  break;
	case LT_DOACROSS:
	  HC_append_string_to_pragma_str(pragmastr, "doacross");
	  break;
	case LT_DOSERIAL:
	  HC_append_string_to_pragma_str(pragmastr, "doserial");
	  break;
	default:
	  assert(0 && "unknown parloop type");
	  break;
       }
     }
    else
     {
      switch(loop_stmt->stmtstruct.serloop->loop_type) 
       {
	case LT_FOR:
	  HC_append_string_to_pragma_str(pragmastr, "for");
	  break;
	case LT_WHILE:
	  HC_append_string_to_pragma_str(pragmastr, "while");
	  break;
	case LT_DO:
	  HC_append_string_to_pragma_str(pragmastr, "do");
	  break;
	default:
	  assert(0 && "unknown serloop type");
	  break;
       }
     }
    GenExprPragmaFromStr(pragmastr);
    fprintf(F, ")\n");
   }
 }

static GenerateLoopPragmas(stmt)
Stmt stmt;
{
    char pragmastr[256];
    Pragma pragma;

    if (pragma = FindStmtPragma(stmt, "\"FOR\"")) {
	HC_write_name_to_pragma_str(pragmastr, "LOOP");
	HC_append_string_to_pragma_str(pragmastr, "for");
        HC_append_int_to_pragma_str(pragmastr, pragma->expr->value.scalar);
        GenBBPragmaFromStr(pragmastr);
	HC_write_name_to_pragma_str(pragmastr, "FUNC");
	HC_append_string_to_pragma_str(pragmastr, currentFuncDcl->name);
	HC_append_int_to_pragma_str(pragmastr, currentFuncDcl->lineno);
	GenBBPragmaFromStr(pragmastr);
	HC_write_name_to_pragma_str(pragmastr, "FILE");
	HC_append_string_to_pragma_str(pragmastr, 
				       DQString2String(stmt->filename));
	GenBBPragmaFromStr(pragmastr);
    }
    else if (pragma = FindStmtPragma(stmt, "\"WHILE\"")) {
	HC_write_name_to_pragma_str(pragmastr, "LOOP");
	HC_append_string_to_pragma_str(pragmastr, "while");
        HC_append_int_to_pragma_str(pragmastr, pragma->expr->value.scalar);
        GenBBPragmaFromStr(pragmastr);
	HC_write_name_to_pragma_str(pragmastr, "FUNC");
	HC_append_string_to_pragma_str(pragmastr, currentFuncDcl->name);
	HC_append_int_to_pragma_str(pragmastr, currentFuncDcl->lineno);
	GenBBPragmaFromStr(pragmastr);
	HC_write_name_to_pragma_str(pragmastr, "FILE");
	HC_append_string_to_pragma_str(pragmastr, 
				       DQString2String(stmt->filename));
	GenBBPragmaFromStr(pragmastr);
    }
    else if (pragma = FindStmtPragma(stmt, "\"DO\"")) {
	HC_write_name_to_pragma_str(pragmastr, "LOOP");
	HC_append_string_to_pragma_str(pragmastr, "do");
        HC_append_int_to_pragma_str(pragmastr, pragma->expr->value.scalar);
        GenBBPragmaFromStr(pragmastr);
	HC_write_name_to_pragma_str(pragmastr, "FUNC");
	HC_append_string_to_pragma_str(pragmastr, currentFuncDcl->name);
	HC_append_int_to_pragma_str(pragmastr, currentFuncDcl->lineno);
	GenBBPragmaFromStr(pragmastr);
	HC_write_name_to_pragma_str(pragmastr, "FILE");
	HC_append_string_to_pragma_str(pragmastr, 
				       DQString2String(stmt->filename));
	GenBBPragmaFromStr(pragmastr);
    }
}

ConvFNQueue()
 {
  FlowNode CurrFN, PrevFN, FNTemp1, FNTemp2;
  Stmt CurrStmt, StmtIndx;
  int InsideBB, Default;
  Lptr LptrIndx;
  Label LabelIndx;
  char pragmastr[256];
  Pragma swp_pragma;
  Expr expr;
  char *pragma_string;
  double prof_count; /* LCW */
  struct _ProfST *ProfStPtr; /* LCW */
  int SerloopHeader;    /* flag to indicate that the current basic block is 
                           the header of a Serloop */
  int next_lp_counter_no = 0; /* LCW-current no of loop iter counters-3/24/99*/

  PrevFN = NULL;
  InsideBB = TRUE;
  SerloopHeader = FALSE;
  while(CurrFN = FNDequeue())
   {
    if ((PrevFN == NULL) || (CurrFN->bb->index != PrevFN->bb->index && !InsideBB))
     {
      fprintf(F, " (BB %d", CurrFN->bb->index + 1);
      InsideBB = TRUE;
      /* LCW - print BB profile information extracted from Pcode - 5/15/96 */
      if (CurrFN->bb->profile != NULL)
	 GenBBProfile(CurrFN->bb->profile);
      fprintf(F, "\n");
      /* BCC - generate loop pragmas for restructured loops - 2/2/97 */
      if (hcode_loop_prags)
	  GenerateLoopPragmas(CurrFN->pcode_ptr.stmt);
      /* GEH - added static profile information pragmas */
      if (hcode_static_prof) 
       {
	HC_write_name_to_pragma_str(pragmastr, "STAT_PROF");
	HC_append_real_to_pragma_str(pragmastr, 
	    hcode_stat_func_weight *
		ipow(hcode_stat_loop_weight,
		     CF_Find_Loop_Nest_Depth_For_BB(currentFuncDcl,
						    CurrFN->bb)));
	GenBBPragmaFromStr(pragmastr);
       }

      /* LCW - generate HCODE Pragmas for loop iter profiling info - 3/27/99 */
      if (SerloopHeader) {
	 Stmt loopstmt;
	 loopstmt = PrevFN->pcode_ptr.stmt;
	 if (loopstmt->type != ST_SERLOOP)
	    Punt("GenStmts: SerloopHeader flag error");
	 GenLoopIterProfPragma(loopstmt->pragma);
      }

        /* DML - moved LOOP/FUNC/FILE pragma generation to here from 
           case NT_SerloopCond so that the pragmas get generated
           in the header block of the Serloop instead of before the 
           loop and at the end of the loop.  */
      /* LCW - moved the checking of flag "hcode_loop_prags" inside 
	 the if statement to make sure SerloopHeader would be reset 
	 correctly - 4/23/99 */
      if (SerloopHeader)
       {
	if (hcode_loop_prags) {
	   HC_write_name_to_pragma_str(pragmastr, "LOOP");
	   switch(CurrStmt->stmtstruct.serloop->loop_type)
	     {
	     case LT_WHILE:
	       HC_append_string_to_pragma_str(pragmastr, "while");
	       break;
	     case LT_FOR:
	       HC_append_string_to_pragma_str(pragmastr, "for");
	       break;
	     case LT_DO:
	       HC_append_string_to_pragma_str(pragmastr, "do");
	       break;
	     default:
	       Punt("GenStmts: invalid SerLoop type");
	     }
	   HC_append_int_to_pragma_str(pragmastr, CurrStmt->lineno);
	   GenBBPragmaFromStr(pragmastr);
	   /* Pragmas for function and file name */
	   if (currentFuncDcl->name == NIL || CurrStmt->filename == NIL) 
	     Punt("GenStmts: missing File or Function name info for pragmas");

	   HC_write_name_to_pragma_str(pragmastr, "FUNC");
	   HC_append_string_to_pragma_str(pragmastr, currentFuncDcl->name);
	   HC_append_int_to_pragma_str(pragmastr, currentFuncDcl->lineno);
	   GenBBPragmaFromStr(pragmastr);

	   HC_write_name_to_pragma_str(pragmastr, "FILE");
	   HC_append_string_to_pragma_str(pragmastr, 
					  DQString2String(CurrStmt->filename));
	   GenBBPragmaFromStr(pragmastr);
	}

	/* LCW - the flag will be needed in the following. It will be set 
	   to false later. - 3/24/99 */
	if (! ((DO_INSERT_LOOP_TRIP_COUNT_PROBE || 
		DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) && INSIDE_FUNCTION))
	/* Set flag to false.  Will be set to true after the NT_SerloopInitCond
	   block for the next Serloop is generated. */
	   SerloopHeader = FALSE;
       }

      /* LCW - insert fcuntion call to _PP_initialize at the beginning of each
	 function (the function will check if it has been invoked - 3/25/99 */
      if ((DO_INSERT_PROBE || DO_INSERT_LOOP_TRIP_COUNT_PROBE) && 
	  INSIDE_FUNCTION) {
	 if (CurrFN->bb->index == 0)
	    fprintf(F, "\t(call (var _PP_initialize))\n");
      }

      /* LCW - 3/24/99 */
      if ((DO_INSERT_LOOP_TRIP_COUNT_PROBE || 
	   DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) && INSIDE_FUNCTION) {
	 Stmt loop_stmt;
	 int *loop_id_ptr;

	 /* insert the initialization of loop iter counters in the first
	    basic block of each function */
	 if (CurrFN->bb->index == 0)
	    PP_gen_loop_iter_counter_initial(F, loops_num);

	 /* insert a loop iter counter in the first BB of the loop body and
	    assign a loop id to the loop */
	 if (SerloopHeader) {
	    PP_insert_loop_iter_counter(F, next_lp_counter_no);
	    if (++next_lp_counter_no > loops_num)
	       Punt("GenStmts: the number of loops is wrong");

	    loop_stmt = PrevFN->pcode_ptr.stmt;
	    if (loop_stmt->type != ST_SERLOOP)
	       Punt("GenStmts: SerloopHeader flag error");
	    loop_id_ptr = (int *)malloc(sizeof(int));
	    *loop_id_ptr = next_loop_id++;
	    loop_stmt->ext = (Extension)loop_id_ptr;

	    if (DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) {
	       PP_annotate_loop_iter_count(loop_stmt);
	    }

	    SerloopHeader = FALSE;
	 }

	 /* insert a function call at the exit of a loop to update 
	    the loop iter counter */
	 if (CurrFN->type == NT_SerloopExit) {
	    loop_stmt = CurrFN->pcode_ptr.stmt;
	    loop_id_ptr = (int *)loop_stmt->ext;
	    if ((loop_stmt->type != ST_SERLOOP) || (loop_id_ptr == 0))
	       Punt("GenStmts: SerLoop Stmt error");
	    PP_gen_update_lp_iter_func(F, *loop_id_ptr);
	 }
      }


      /* LCW - insert a probe at the begining of each BB and generate the 
       * function call atexit(&dump_probe_array) if this is the first BB
       * of the main function - 10/10/95 */
      /* BCC - 4/1/96 
       * Don't probe codes in global data declarations since it is executed 
       * only once and the probe might screw up the syntax.
       */
      if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
	 insert_probe(F, next_probe++);

#if 0    /* LCW - we don't put atexit in main function anymore. 
	    Instead, it is in _PP_initialize - 3/25/99 */
	 /* LCW - we don't need to dump probe array when inserting pseudo
	  * probes - 10/25/96
	  */
	 if ((IS_MAIN) && (CurrFN->bb->index == 0) && (!DO_INSERT_PSEUDO_PROBE))
	    gen_call_dump_probe_array(F);
#endif

	 /* LCW - get current profiling weight - 10/23/95 */
	 if (DO_ANNOTATE_PCODE)
	    /* LCW - modified to read floating-point profile weights and to
	       handle the case when EOF is encountered - 3/5/97 */
	     if (fscanf(Fprofile, "%lf", &current_prof_count) == EOF)
	        current_prof_count = 0.0;
      }
     }
    else
      if (CurrFN->bb->index != PrevFN->bb->index && InsideBB)
       {
        /* CLOSE ANY TYPE OF BASIC BLOCK HERE */ 
        if (((FlowNode) PrevFN->succ->ptr)->type != NT_FuncExit) {
	  /* LCW - append source info pragma if the previous node is 
	     NT_Continue or NT_Break - 9/23/97 */
          /* fprintf(F, "\t(GOTO %d) )\n", ((FlowNode) PrevFN->succ->ptr)->bb->index + 1); */
          fprintf(F, "\t(GOTO %d", 
		  ((FlowNode) PrevFN->succ->ptr)->bb->index + 1);
	  if ((EMIT_SOURCE_INFO) && (PrevFN->type == NT_Continue || 
				     PrevFN->type == NT_Break)) {
	     char pragmastr[256];
	     char strip_fname[256];
	     /* fprintf(F, " "); */
	     HC_write_name_to_pragma_str(pragmastr, "POS");
	     HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, CurrStmt->filename));
	     HC_append_int_to_pragma_str(pragmastr, CurrStmt->lineno);
	     GenExprPragmaFromStr(pragmastr);
	     HC_write_name_to_pragma_str(pragmastr, "SCOPE");
	     HC_append_int_to_pragma_str(pragmastr, FindStmtScope(CurrStmt));
	     GenExprPragmaFromStr(pragmastr);
	  }
	  fprintf(F, ") )\n");
	  /* LCW - end of change */
        }
        else {
	  /* LCW - if the Return is in a loop, insert a function 
	     call to update the loop iter counter - 3/24/99 */
	  if (DO_INSERT_LOOP_TRIP_COUNT_PROBE && INSIDE_FUNCTION) {
	     Stmt loopstmt;
	     for (loopstmt = CurrFN->pcode_ptr.stmt; loopstmt != NIL;
		  loopstmt = loopstmt->parent) {
	         if (loopstmt->type == ST_SERLOOP) {
		   int *loop_id_ptr;
		   if ((loop_id_ptr = (int *)loopstmt->ext) == 0)
		      Punt("GenStmts: lack of loop id info");
		   PP_gen_update_lp_iter_func(F, *loop_id_ptr);
		 }
	     }
	  }

          fprintf(F, "\t(RETURN) )\n"); 
	}
  
        fprintf(F, " (BB %d", CurrFN->bb->index + 1);
        /* LCW - print BB profile information extracted from Pcode - 5/15/96 */
        if (CurrFN->bb->profile != NULL)
	   GenBBProfile(CurrFN->bb->profile);
        fprintf(F, "\n");
        /* BCC - generate loop pragmas for restructured loops - 2/2/97 */
        if (hcode_loop_prags)
	    GenerateLoopPragmas(CurrFN->pcode_ptr.stmt);
	/* GEH - added static profile information pragmas */
	if (hcode_static_prof) 
	 {
	  HC_write_name_to_pragma_str(pragmastr, "STAT_PROF");
	  HC_append_real_to_pragma_str(pragmastr, 
	      hcode_stat_func_weight *
		  ipow(hcode_stat_loop_weight,
		       CF_Find_Loop_Nest_Depth_For_BB(currentFuncDcl,
						      CurrFN->bb)));
	  GenBBPragmaFromStr(pragmastr);
	 }

	/* LCW- generate HCODE Pragmas for loop iter profiling info -3/27/99 */
	if (SerloopHeader) {
	   Stmt loopstmt;
	   loopstmt = PrevFN->pcode_ptr.stmt;
	   if (loopstmt->type != ST_SERLOOP)
	      Punt("GenStmts: SerloopHeader flag error");
	   GenLoopIterProfPragma(loopstmt->pragma);
	}


          /* DML - moved LOOP/FUNC/FILE pragma generation to here from 
             case NT_SerloopCond so that the pragmas get generated
             in the header block of the Serloop instead of before the 
             loop and at the end of the loop.  */
	/* LCW - moved the checking of flag "hcode_loop_prags" inside 
	 the if statement to make sure SerloopHeader would be reset 
	 correctly - 4/23/99 */
        if (SerloopHeader)
         {
	  if (hcode_loop_prags) {
	     HC_write_name_to_pragma_str(pragmastr, "LOOP");
	     switch(CurrStmt->stmtstruct.serloop->loop_type)
	       {
	       case LT_WHILE:
		 HC_append_string_to_pragma_str(pragmastr, "while");
		 break;
	       case LT_FOR:
		 HC_append_string_to_pragma_str(pragmastr, "for");
		 break;
	       case LT_DO:
		 HC_append_string_to_pragma_str(pragmastr, "do");
		 break;
	       default:
		 Punt("GenStmts: invalid SerLoop type");
	       }
	     HC_append_int_to_pragma_str(pragmastr, CurrStmt->lineno);
	     GenBBPragmaFromStr(pragmastr);
	     /* Pragmas for function and file name */
	     if (currentFuncDcl->name == NIL || CurrStmt->filename == NIL) 
	       Punt("GenStmts: missing File or Function name info for pragmas");
  
	     HC_write_name_to_pragma_str(pragmastr, "FUNC");
	     HC_append_string_to_pragma_str(pragmastr, currentFuncDcl->name);
	     HC_append_int_to_pragma_str(pragmastr, currentFuncDcl->lineno);
	     GenBBPragmaFromStr(pragmastr);

	     HC_write_name_to_pragma_str(pragmastr, "FILE");
	     HC_append_string_to_pragma_str(pragmastr, 
					  DQString2String(CurrStmt->filename));
	     GenBBPragmaFromStr(pragmastr);
	  }

	  /* LCW - the flag will be needed in the following. It will be set 
	     to false later. - 3/24/99 */
	  if (! ((DO_INSERT_LOOP_TRIP_COUNT_PROBE || 
		  DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) && INSIDE_FUNCTION))
          /* Set flag to false.  Will be set to true after the 
             NT_SerloopInitCond block for the next Serloop is generated. */
	     SerloopHeader = FALSE;
         }

	/* LCW - insert fcuntion call to _PP_initialize at the beginning of 
	   each function. Note the function will check if itself has been 
	   invoked - 3/25/99 */
	if ((DO_INSERT_PROBE || DO_INSERT_LOOP_TRIP_COUNT_PROBE) && 
	    INSIDE_FUNCTION) {
	   if (CurrFN->bb->index == 0)
	      fprintf(F, "\t(call (var _PP_initialize))\n");
	}

	/* LCW - 3/24/99 */
	if ((DO_INSERT_LOOP_TRIP_COUNT_PROBE || 
	     DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) && INSIDE_FUNCTION) {
	   Stmt loop_stmt;
	   int *loop_id_ptr;

	   /* insert the initialization of loop iter counters in the first
	      basic block of each function */
	   if (CurrFN->bb->index == 0)
	      PP_gen_loop_iter_counter_initial(F, loops_num);

	   /* insert a loop iter counter in the first BB of the loop body and
	      assign a loop id to the loop */
	   if (SerloopHeader) {
	      PP_insert_loop_iter_counter(F, next_lp_counter_no);
	      if (++next_lp_counter_no > loops_num)
		 Punt("GenStmts: the number of loops is wrong");

	      loop_stmt = PrevFN->pcode_ptr.stmt;
	      if (loop_stmt->type != ST_SERLOOP)
		 Punt("GenStmts: SerloopHeader flag error");
	      loop_id_ptr = (int *)malloc(sizeof(int));
	      *loop_id_ptr = next_loop_id++;
	      loop_stmt->ext = (Extension)loop_id_ptr;

	      if (DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) {
		 PP_annotate_loop_iter_count(loop_stmt);
	      }

	      SerloopHeader = FALSE;
	   }
	   
	   /* insert a function call at the exit of a loop to update 
	    the loop iter counter */
	   if (CurrFN->type == NT_SerloopExit) {
	      loop_stmt = CurrFN->pcode_ptr.stmt;
	      loop_id_ptr = (int *)loop_stmt->ext;
	      if ((loop_stmt->type != ST_SERLOOP) || (loop_id_ptr == 0))
		 Punt("GenStmts: SerLoop Stmt error");
	      PP_gen_update_lp_iter_func(F, *loop_id_ptr);
	   }
	}

        /* LCW - insert probe here - 10/08/95 */
        /* BCC - 4/1/96 
         * Don't probe codes in global data declarations since it is executed 
         * only once and the probe might screw up the syntax.
         */
        if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
	   insert_probe(F, next_probe++);
	   /* LCW - get current profiling weight - 10/23/95 */
	   if (DO_ANNOTATE_PCODE)
	      /* LCW - modified to read floating-point profile weights and to
	       handle the case when EOF is encountered - 3/5/97 */
	      if (fscanf(Fprofile, "%lf", &current_prof_count) == EOF)
		 current_prof_count = 0.0;
	}
       }

    CurrStmt = CurrFN->pcode_ptr.stmt;

    switch(CurrFN->type)
     {
      /* case NT_CompoundEntry: */ /* LCW - moved to the below - 5/10/96 */
      /* case NT_Null: */
      /* case NT_PStmtCompEntry: */
      /* case NT_Continue: */
      /* case NT_Break: */
      /* case NT_ParloopMainEpilogue: */
      case NT_IfExit:
      case NT_CompoundExit: 
      case NT_SwitchExit:
      case NT_PStmtCompExit:
       {
        break;
       }
      case NT_CompoundEntry:
      case NT_Null:
      case NT_PStmtCompEntry:
      case NT_Continue:
      case NT_Break:
      case NT_ParloopMainEpilogue:
       {
	/* LCW - put current profiling weight to the statement - 5/17/96 */
	if (DO_ANNOTATE_PCODE)
           CurrStmt->profile = NewProfST((double)current_prof_count);
	break;
       }
      case NT_SerloopExit:
       {
	Add_Stats_Directive("stats_off", CurrStmt);
	break;
       }	
      case NT_ParloopAuxEpilogue:
       {
	Add_Stats_Directive("stats_off", CurrStmt->parent->parent);
	/* LCW - put current profiling weight to the statement - 5/18/96 */
	if (DO_ANNOTATE_PCODE)
           CurrStmt->profile = NewProfST((double)current_prof_count);
	break;
       }
      case NT_ParloopExit:
       {
	Add_Stats_Directive("stats_off", CurrStmt);
	break;
       }
      case NT_Goto:
       {
	FlowNode destfn = (FlowNode)CurrStmt->flow->entry_flow_node->succ->ptr;
        /* Use return if successor is NT_FuncExit */
        if (destfn->type != NT_FuncExit) 
	 {
	  Stmt loopstmt, stmt;

	  /* GEH - if early exit from an enclosing Serloop, attach stats_off 
	     pragma */
	  for (loopstmt=CurrStmt->parent; 
	       loopstmt!=NIL; 
	       loopstmt=loopstmt->parent) 
	   {
	    if (loopstmt->type == ST_SERLOOP) 
	     {
	      for (stmt=destfn->pcode_ptr.stmt->parent; 
		   stmt!=NIL && stmt!=loopstmt; 
		   stmt=stmt->parent);
	      if (stmt==NIL) {
		 Add_Stats_Directive("stats_off", loopstmt);

		 /* LCW - the Goto jumps out of this loop. Need to insert a 
		    function call to update the loop iter counter - 3/24/99 */
		 if (DO_INSERT_LOOP_TRIP_COUNT_PROBE && INSIDE_FUNCTION) {
		    int *loop_id_ptr;
		    if ((loop_id_ptr = (int *)loopstmt->ext) == 0)
		       Punt("GenStmts: lack of loop id info");
		    PP_gen_update_lp_iter_func(F, *loop_id_ptr);
		 }
	      }
	     }
	   }

	  /* GEH - if side entrance to a Serloop, attach stats_on pragma */
	  for (loopstmt=destfn->pcode_ptr.stmt->parent;
	       loopstmt!=NIL;
	       loopstmt=loopstmt->parent)
	   {
	    if (loopstmt->type == ST_SERLOOP)
	     {
	      for (stmt=CurrStmt->parent;
		   stmt!=NIL && stmt!=loopstmt;
		   stmt=stmt->parent);
	      if (stmt==NIL) Add_Stats_Directive("stats_on", loopstmt);
	     }
	   }
          fprintf(F, "\t(GOTO %d) )\n", destfn->bb->index + 1);
	 }
        else {
	  /* LCW - if the Goto jumps out of this loop, insert a function 
	     call to update the loop iter counter - 3/24/99 */
	  if (DO_INSERT_LOOP_TRIP_COUNT_PROBE && INSIDE_FUNCTION) {
	     Stmt loopstmt;
	     for (loopstmt = CurrStmt->parent; loopstmt != NIL;
		  loopstmt = loopstmt->parent) {
	         if (loopstmt->type == ST_SERLOOP) {
		   int *loop_id_ptr;
		   if ((loop_id_ptr = (int *)loopstmt->ext) == 0)
		      Punt("GenStmts: lack of loop id info");
		   PP_gen_update_lp_iter_func(F, *loop_id_ptr);
		 }
	     }
	  }
	   
          fprintf(F, "\t(RETURN) )\n");
	}
	/* LCW - put current profiling weight to the statement - 5/17/96 */
	if (DO_ANNOTATE_PCODE)
           CurrStmt->profile = NewProfST((double)current_prof_count);
        InsideBB = FALSE;
        break;
       }
      case NT_SerloopInitCond:
       {
        /* LCW - put current profiling weight to the statement - 10/24/95 */
        if (DO_ANNOTATE_PCODE) 
	   CurrStmt->profile = NewProfST((double)current_prof_count); 

        if(CurrStmt->stmtstruct.serloop->init_expr)
         {
          fprintf(F, "\t");
          GenCommaExpr(CurrStmt->stmtstruct.serloop->init_expr);
          fprintf(F, "\n");
         }

	Add_Stats_Directive("stats_on", CurrStmt);

        /* set flag to indicate that next basic block is the Serloop header 
           for "for" and "while" loops */
        SerloopHeader = TRUE;

       /* BCC - 4/17/97 
	* We need to set Expr_Is_Explicit to FALSE to generate
	* CurrStmt->stmtstruct.serloop->cond_expr
	* Expr_Is_Explicit will be reset to be TRUE at the end of 
	* SerloopCond_Label
	*/
        Expr_Is_Explicit = FALSE;

	/* GEH - modified to handle new for-while loops */
        goto SerloopCond_Label;
       }
      case NT_SerloopIterCond:
       {
       /* BCC - 4/17/97 
	* We need to set Expr_Is_Explicit to TRUE until 
	* CurrStmt->stmtstruct.serloop->cond_expr is generated
	*/
        Expr_Is_Explicit = TRUE;
#if 0
        /* DMG  - 7 Feb 95 - Set Expr_Is_Explicit to true for the iter cond;
           it is turned back off before the loopback condition is generated */
        Expr_Is_Explicit = TRUE;
#endif
        if(CurrStmt->stmtstruct.serloop->iter_expr)
         {
          fprintf(F, "\t");
          GenCommaExpr(CurrStmt->stmtstruct.serloop->iter_expr);
          fprintf(F, "\n");
         }
#if 0
	Expr_Is_Explicit = FALSE;
#endif

	/* GEH - modified to handle new for-while loops */
        goto SerloopCond_Label;
       }
      case NT_SerloopCond:
      /* GEH - modified to handle new for-while loops */
      SerloopCond_Label:
       {
        FNTemp1 = FindFlowNodeInList(NT_SerloopExit, CurrFN->succ);
        FNTemp2 = (FlowNode)(CurrFN->succ->ptr);
        if (FNTemp1 == FNTemp2)
          FNTemp2 = ((FlowNode)CurrFN->succ->next->ptr);

        /* Checking for conditional expression.  Is this necessary? */
        if(CurrStmt->stmtstruct.serloop->cond_expr)
         {
          fprintf(F, "\t(IF ");
          GenCommaExpr(CurrStmt->stmtstruct.serloop->cond_expr);

	  /* LCW - insert a new basic block for else-part and put a probe
	   * here - 10/08/95
	   */
          /* BCC - 4/1/96 
           * Don't probe codes in global data declarations since it is executed 
           * only once and the probe might screw up the syntax.
           */
          if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
	     fprintf(F, " (THEN %d) (ELSE %d)) )\n", FNTemp2->bb->index + 1,
		  next_probe_BB);
	     fprintf(F, " (BB %d\n", next_probe_BB++);
	     insert_probe(F, next_probe++);
	     fprintf(F, "\t(GOTO %d) )\n", FNTemp1->bb->index + 1);
	     /* LCW - append the profiling data - 10/24/95 */
	     if (DO_ANNOTATE_PCODE) {
	        /* LCW - modified to read floating-point profile weights and 
		   to handle the case when EOF is encountered - 3/5/97 */
		if (fscanf(Fprofile, "%lf", &prof_count) == EOF)
		   prof_count = 0.0;
		ProfStPtr = CurrStmt->profile;
		if (ProfStPtr) {
		   while (ProfStPtr->next)
		      ProfStPtr = ProfStPtr->next;
		   ProfStPtr->next = NewProfST((double)prof_count);
		}
		else
		   CurrStmt->profile = NewProfST((double)prof_count);
	     }
	  }
	  else {
	     /* BCC - 4/13/97
	      * generate empty loop pragmas for static branch prediction 
	      */

	     if (CurrStmt->stmtstruct.serloop->loop_body == NULL ||
		 CurrStmt->stmtstruct.serloop->loop_body->type == ST_NOOP)
	         /* LCW - changed to append source info pragmas - 9/30/97 */
	         /* fprintf(F, 
			" (THEN %d) (ELSE %d) (EXPR_PRAGMA \"EMPTYLOOP\")) )\n",
			FNTemp2->bb->index + 1, FNTemp1->bb->index + 1); */
		 fprintf(F, " (THEN %d) (ELSE %d) (EXPR_PRAGMA \"EMPTYLOOP\")",
			FNTemp2->bb->index + 1, FNTemp1->bb->index + 1);
	     else
	         /* fprintf(F, " (THEN %d) (ELSE %d)) )\n", FNTemp2->bb->index + 1,
		      FNTemp1->bb->index + 1); */
		 fprintf(F, " (THEN %d) (ELSE %d)", FNTemp2->bb->index + 1,
		      FNTemp1->bb->index + 1);
	     /* LCW - append source info pragma - 9/30/97 */
	     if (EMIT_SOURCE_INFO) {
	        char pragmastr[256];
		char strip_fname[256];
		HC_write_name_to_pragma_str(pragmastr, "POS");
		HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, CurrStmt->filename));
		HC_append_int_to_pragma_str(pragmastr, CurrStmt->lineno);
		GenExprPragmaFromStr(pragmastr);
		HC_write_name_to_pragma_str(pragmastr, "SCOPE");
		HC_append_int_to_pragma_str(pragmastr, FindStmtScope(CurrStmt));
		GenExprPragmaFromStr(pragmastr);
	     }
	     fprintf(F, ") )\n");
	     /* LCW - end of change */
	  }
         }
        else {
          fprintf(F, "\t(GOTO %d) )\n", FNTemp2->bb->index + 1);
	  /* LCW - the 2nd and 3rd profile counts of serloop statement are 0
	   * when there is no cond_expr - 5/17/96 */
	  if (DO_ANNOTATE_PCODE) {
	     ProfStPtr = CurrStmt->profile;
	     if (ProfStPtr) {
	        while (ProfStPtr->next)
		   ProfStPtr = ProfStPtr->next;
		ProfStPtr->next = NewProfST(0.0);
	     }
	     else
	        CurrStmt->profile = NewProfST(0.0);
	  }
	}
        InsideBB = FALSE;
	Expr_Is_Explicit = TRUE;
        break;
       }
      case NT_ParloopInitCond:
       {
	/* LCW - put current profiling weight to the statement - 10/24/95 */
        if (DO_ANNOTATE_PCODE)
	   CurrStmt->profile = NewProfST((double)current_prof_count);

	Add_Stats_Directive("stats_on", CurrStmt);

        fprintf(F, "\t(assign (var %s) ",
                CurrStmt->stmtstruct.parloop->iteration_var->value.var_name);
        GenCommaExpr(CurrStmt->stmtstruct.parloop->init_value);  
        fprintf(F, ")\n");
        FNTemp1 = FindFlowNodeInList(NT_ParloopExit, CurrFN->succ);
	if (FNTemp1 != NIL) /* loop has short-circuit CF path (GEH - 4/17/95) */
	 {
	  FNTemp2 = FindFlowNodeInList(NT_PStmtCompEntry, CurrFN->succ);
	  fprintf(F, "\t(IF (le (var %s) ", 
		  CurrStmt->stmtstruct.parloop->iteration_var->value.var_name);
	  GenCommaExpr(CurrStmt->stmtstruct.parloop->final_value);

	  /* LCW - insert a new basic block for else-part and put a probe
           * here - 10/08/95
           */
          /* BCC - 4/1/96 
           * Don't probe codes in global data declarations since it is executed 
           * only once and the probe might screw up the syntax.
           */
          if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
             fprintf(F, ") (THEN %d) (ELSE %d)) )\n", FNTemp2->bb->index + 1,
                  next_probe_BB);
             fprintf(F, " (BB %d\n", next_probe_BB++);
             insert_probe(F, next_probe++);
             fprintf(F, "\t(GOTO %d) )\n", FNTemp1->bb->index + 1);
	     /* LCW - append the profiling data - 10/24/95 */
             if (DO_ANNOTATE_PCODE) {
	        /* LCW - modified to read floating-point profile weights and 
		   to handle the case when EOF is encountered - 3/5/97 */
                if (fscanf(Fprofile, "%lf", &prof_count) == EOF)
		   prof_count = 0.0;
		ProfStPtr = CurrStmt->profile;
		while (ProfStPtr->next)
		   ProfStPtr = ProfStPtr->next;
		ProfStPtr->next = NewProfST((double)prof_count);
             }
          }
          else
	     fprintf(F, ") (THEN %d) (ELSE %d)) )\n", FNTemp2->bb->index + 1,
	          FNTemp1->bb->index + 1);
	  InsideBB = FALSE;
	 }
	else  /* LCW - the 2nd profile count is 0 if loop has short-circuit 
		 CF path - 5/19/96 */
	 {
	  if (DO_ANNOTATE_PCODE) {
	     ProfStPtr = CurrStmt->profile;
	     while (ProfStPtr->next)
		ProfStPtr = ProfStPtr->next;
	     ProfStPtr->next = NewProfST(0.0);  
	  }
	 }
	break;    
       }
      case NT_ParloopIterCond:
       {
        if(! IncrOne(CurrStmt->stmtstruct.parloop->incr_value))
         {
          if (CurrStmt->stmtstruct.parloop->loop_type == LT_DOACROSS ||
	      CurrStmt->stmtstruct.parloop->loop_type == LT_DOALL) 
	    Warning("ParLoop increment not equal to one");
          fprintf(F, "\t(Aadd (var %s) ", 
                  CurrStmt->stmtstruct.parloop->iteration_var->value.var_name);
          GenExpr(CurrStmt->stmtstruct.parloop->incr_value);
          fprintf(F, ")\n");
         }
        else
          fprintf(F, "\t(postinc (var %s))\n", 
                  CurrStmt->stmtstruct.parloop->iteration_var->value.var_name);
        fprintf(F, "\t(IF (le (var %s) ", 
                CurrStmt->stmtstruct.parloop->iteration_var->value.var_name);
        GenCommaExpr(CurrStmt->stmtstruct.parloop->final_value);
        FNTemp1 = FindFlowNodeInList(NT_ParloopBody, CurrFN->succ);
        FNTemp2 = (FlowNode)(CurrFN->succ->ptr);
        if (FNTemp1 == FNTemp2)
          FNTemp2 = ((FlowNode)CurrFN->succ->next->ptr);

	/* LCW - insert a new basic block for else-part and put a probe
         * here - 10/08/95
         */
        /* BCC - 4/1/96 
         * Don't probe codes in global data declarations since it is executed 
         * only once and the probe might screw up the syntax.
         */
        if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
           fprintf(F, ") (THEN %d) (ELSE %d)) )\n", FNTemp1->bb->index + 1,
                next_probe_BB);
           fprintf(F, " (BB %d\n", next_probe_BB++);
           insert_probe(F, next_probe++);
           fprintf(F, "\t(GOTO %d) )\n", FNTemp2->bb->index + 1);
	   /* LCW - append the profiling data - 10/24/95 */
	   if (DO_ANNOTATE_PCODE) {
	      /* LCW - modified to read floating-point profile weights and to
	       handle the case when EOF is encountered - 3/5/97 */
	      if (fscanf(Fprofile, "%lf", &prof_count) == EOF)
		 prof_count = 0.0;
	      ProfStPtr = CurrStmt->profile;
	      while (ProfStPtr->next)
		 ProfStPtr = ProfStPtr->next;
	      ProfStPtr->next = NewProfST((double)prof_count);
	   }
        }
        else
           fprintf(F, ") (THEN %d) (ELSE %d)) )\n", FNTemp1->bb->index + 1,
                FNTemp2->bb->index + 1);
        InsideBB = FALSE;
        break;    
       }
      case NT_ParloopBody:
       {
        if (hcode_loop_prags)
         {
          assert(CurrStmt->parent->parent->type == ST_PARLOOP);

	  HC_write_name_to_pragma_str(pragmastr, "LOOP");
          switch(CurrStmt->parent->parent->stmtstruct.parloop->loop_type)
           {
            case LT_DOALL:
	      HC_append_string_to_pragma_str(pragmastr, "doall");
	      break;
            case LT_DOACROSS:
	      HC_append_string_to_pragma_str(pragmastr, "doacross");
              break;
            case LT_DOSERIAL:
	      HC_append_string_to_pragma_str(pragmastr, "doserial");
              break;
            case LT_DOSUPER:
	      HC_append_string_to_pragma_str(pragmastr, "dosuper");
              break;
            default:
              Punt("GenStmts: invalid ParLoop type");
	  }
	  HC_append_int_to_pragma_str(pragmastr, 
				      CurrStmt->parent->parent->lineno);
	  GenBBPragmaFromStr(pragmastr);

	  /* Pragmas for function and file name */
          if (currentFuncDcl->name == NIL || CurrStmt->filename == NIL) 
            Punt("GenStmts: missing File or Function name info for pragmas");

	  HC_write_name_to_pragma_str(pragmastr, "FUNC");
	  HC_append_string_to_pragma_str(pragmastr, currentFuncDcl->name);
	  HC_append_int_to_pragma_str(pragmastr, currentFuncDcl->lineno);
	  GenBBPragmaFromStr(pragmastr);

	  HC_write_name_to_pragma_str(pragmastr, "FILE");
	  HC_append_string_to_pragma_str(pragmastr, 
				 DQString2String(CurrStmt->filename));
	  GenBBPragmaFromStr(pragmastr);
         }

         /* DML 1/27/96  - pass SWP_INFO pragma from Pcode to Hcode if
            hcode_swp_prags turned on */
         swp_pragma = FindStmtPragma(CurrStmt,"\"SWP_INFO\"");
         if (hcode_swp_prags && swp_pragma) {
              pragma_string = DQString2String(swp_pragma->specifier);
	      HC_write_name_to_pragma_str(pragmastr, pragma_string);
              imp_free(pragma_string, strlen(pragma_string)+1);
              for (expr = swp_pragma->expr; expr != NULL; expr = expr->next) {
                  pragma_string = DQString2String(expr->value.string);
	          HC_append_string_to_pragma_str(pragmastr, pragma_string);
                  imp_free(pragma_string, strlen(pragma_string)+1);
              }
	      GenBBPragmaFromStr(pragmastr);
         }
	 
	/* LCW - put current profiling weight to the statement - 5/17/96 */
	if (DO_ANNOTATE_PCODE)
           CurrStmt->profile = NewProfST((double)current_prof_count);

        break;
       }
      case NT_SerloopEntry:
	/* LCW - put current profiling weight to the statement - 10/25/95 */
        if (DO_ANNOTATE_PCODE) {
           CurrStmt->profile = NewProfST((double)current_prof_count);
	   if (CurrStmt->stmtstruct.serloop->loop_type == LT_DO)
	      CurrStmt->profile->next = NewProfST(0);
	}
	Add_Stats_Directive("stats_on", CurrStmt);

        /* next basic block will be the header for do-while loop */
        SerloopHeader = TRUE;
        break;
      case NT_SwitchCond:
       {
	int tmp_BB_no = next_probe_BB; /*LCW - temporary BB index - 10/08/95*/
        Default = FALSE;

        /* LCW - put current profiling weight to the statement - 10/24/95 */
        if (DO_ANNOTATE_PCODE)
           CurrStmt->profile = NewProfST((double)current_prof_count);
	
        fprintf(F, "\t(SWITCH ");
        GenCommaExpr(CurrStmt->stmtstruct.switchstmt->expression);
        for (LptrIndx = CurrFN->succ; LptrIndx != NULL; LptrIndx = LptrIndx->next)
         {
          StmtIndx = ((FlowNode)LptrIndx->ptr)->pcode_ptr.stmt;
          if (StmtIndx != CurrStmt)
           {
            for(LabelIndx = StmtIndx->labels; LabelIndx != NULL; LabelIndx = LabelIndx->next)
              if(LabelIndx->type == LB_CASE) 
               {
                fprintf(F, " (");
                GenExpr(LabelIndx->expression);

		/* LCW - create a basic block for each case branch - 10/08/95*/ 
                /* BCC - 4/1/96 
                 * Don't probe codes in global data declarations since it is 
                 * executed only once and the probe might screw up the syntax.
                 */
                if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) 
		   fprintf(F, " %d)", tmp_BB_no++);
		else
                   fprintf(F, " %d)", ((FlowNode)LptrIndx->ptr)->bb->index + 1);
               }
           }
         }
        for (LptrIndx = CurrFN->succ; LptrIndx != NULL; LptrIndx = LptrIndx->next)
         {
          StmtIndx = ((FlowNode)LptrIndx->ptr)->pcode_ptr.stmt;
          if (StmtIndx != CurrStmt)
           {
            for(LabelIndx = StmtIndx->labels; LabelIndx != NULL; LabelIndx = LabelIndx->next)
              if(LabelIndx->type == LB_DEFAULT) 
               {
                fprintf(F, " (DEFAULT");
                fprintf(F, " %d)", ((FlowNode)LptrIndx->ptr)->bb->index + 1);
                Default = TRUE;
               }
           }
         }
        if (!Default)
         {
          fprintf(F, " (DEFAULT");
          fprintf(F, " %d)", FindFlowNodeInList(NT_SwitchExit, CurrFN->succ)->bb->index + 1); 
         }

	/* LCW - append source info pragma - 9/30/97 */
	if (EMIT_SOURCE_INFO) {
	   char pragmastr[256];
	   char strip_fname[256];
	   HC_write_name_to_pragma_str(pragmastr, "POS");
	   HC_append_string_to_pragma_str(pragmastr, 
			 StripDoubleQuotes(strip_fname, CurrStmt->filename));
	   HC_append_int_to_pragma_str(pragmastr, CurrStmt->lineno);
	   GenExprPragmaFromStr(pragmastr);
	   HC_write_name_to_pragma_str(pragmastr, "SCOPE");
	   HC_append_int_to_pragma_str(pragmastr, FindStmtScope(CurrStmt));
	   GenExprPragmaFromStr(pragmastr);
	}
	/* LCW - end of change */
        fprintf(F, ") )\n");

	/* LCW - insert new basic blocks for case branches and put a probe
	 * in each of the basic block - 10/08/95
	 */
        /* BCC - 4/1/96 
         * Don't probe codes in global data declarations since it is executed 
         * only once and the probe might screw up the syntax.
         */
        if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
	   for (LptrIndx = CurrFN->succ; LptrIndx != NULL; 
						LptrIndx = LptrIndx->next) {
               StmtIndx = ((FlowNode)LptrIndx->ptr)->pcode_ptr.stmt;
               if (StmtIndx != CurrStmt) {
                  for (LabelIndx = StmtIndx->labels; LabelIndx != NULL;
						LabelIndx = LabelIndx->next)
              	      if (LabelIndx->type == LB_CASE) {
		         fprintf(F, " (BB %d\n", next_probe_BB++);
                         insert_probe(F, next_probe++);
                         fprintf(F, "\t(GOTO %d) )\n", 
				   ((FlowNode)LptrIndx->ptr)->bb->index + 1);

			 /* LCW - append the profiling data - 10/24/95 */
			 if (DO_ANNOTATE_PCODE) {
			    /* LCW - modified to read floating-point profile 
			       weights and to handle the case when EOF is 
			       encountered - 3/5/97 */
			    if (fscanf(Fprofile, "%lf", &prof_count) == EOF)
			       prof_count = 0.0;
			    ProfStPtr = CurrStmt->profile;
			    while (ProfStPtr->next)
			       ProfStPtr = ProfStPtr->next;
			    ProfStPtr->next = NewProfST((double)prof_count);
			 }
		      }
	       }
	   }
	}   
        InsideBB = FALSE;
        break;
       } 
      case NT_Return:
       {
	/* GEH - add stats_off pragma to each enclosing Serloop */
	Stmt loopstmt;

	for (loopstmt=CurrStmt->parent; loopstmt!=NIL;loopstmt=loopstmt->parent)
	 {
	   if (loopstmt->type == ST_SERLOOP) {
	     Add_Stats_Directive("stats_off", loopstmt);

	     /* LCW - the Return is within the loop. Need to insert a function
		call to update the loop iter counter - 3/24/99 */
	     if (DO_INSERT_LOOP_TRIP_COUNT_PROBE && INSIDE_FUNCTION) {
	        int *loop_id_ptr;
		if ((loop_id_ptr = (int *)loopstmt->ext) == 0)
		   Punt("GenStmts: lack of loop id info");
		PP_gen_update_lp_iter_func(F, *loop_id_ptr);
	     }
	   }
	 }
	/* LCW - put current profiling weight to the statement - 10/25/95 */
        if (DO_ANNOTATE_PCODE)
           CurrStmt->profile = NewProfST((double)current_prof_count);

        fprintf(F, "\t(RETURN");
        if(CurrStmt->stmtstruct.ret != NULL)
         {
          fprintf(F, " ");
	  /* BCC - handle return 1,2,3 - 7/18/96 
          GenExpr(CurrStmt->stmtstruct.ret);
	  */
          GenCommaExpr(CurrStmt->stmtstruct.ret);
         }
	/* LCW - append source info pragma - 9/29/97 */
	if (EMIT_SOURCE_INFO) {
	   char pragmastr[256];
	   char strip_fname[256];
	   HC_write_name_to_pragma_str(pragmastr, "POS");
	   HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, CurrStmt->filename));
	   HC_append_int_to_pragma_str(pragmastr, CurrStmt->lineno);
	   GenExprPragmaFromStr(pragmastr);
	   HC_write_name_to_pragma_str(pragmastr, "SCOPE");
	   HC_append_int_to_pragma_str(pragmastr, FindStmtScope(CurrStmt));
	   GenExprPragmaFromStr(pragmastr);
	}
	/* LCW - end of change */
        fprintf(F, ") )\n");
        InsideBB = FALSE;
        break;
       }
      case NT_MutexEntry:
       {

        fprintf(F, "\t(sync"); 
	HC_write_name_to_pragma_str(pragmastr, "MUTEXBEGIN");
	HC_append_label_to_pragma_str(pragmastr, 
			FindVarName(CurrStmt->stmtstruct.mutex->expression));
	GenExprPragmaFromStr(pragmastr);
	fprintf(F, ")");
        break;
       }
      case NT_MutexExit:
       {
        fprintf(F, "\t(sync"); 
	HC_write_name_to_pragma_str(pragmastr, "MUTEXEND");
	HC_append_label_to_pragma_str(pragmastr, 
			FindVarName(CurrStmt->stmtstruct.mutex->expression));
	GenExprPragmaFromStr(pragmastr);
	fprintf(F, ")");
        break;
       }
      case NT_Expr:
       {
        Expr ExIndx;
       
	/* LCW - put current profiling weight to the statement - 10/24/95 */
	if (DO_ANNOTATE_PCODE)
	   CurrStmt->profile = NewProfST((double)current_prof_count);

        for(ExIndx = CurrStmt->stmtstruct.expr; ExIndx != NULL; ExIndx = ExIndx->next)
         {
          fprintf(F, "\t");
          GenExpr(ExIndx);
          fprintf(F, "\n");
         }

	/* LCW - insert a probe right after a function call - 10/12/95 */
        /* BCC - 4/1/96 
         * Don't probe codes in global data declarations since it is executed 
         * only once and the probe might screw up the syntax.
         */
        if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
	   if (after_func_call) {
	      insert_probe(F, next_probe++);
	      after_func_call = 0;
	      /* LCW - get new current profiling weight - 10/23/95 */
	      if (DO_ANNOTATE_PCODE)
		 /* LCW - modified to read floating-point profile weights and 
		    to handle the case when EOF is encountered - 3/5/97 */
		 if (fscanf(Fprofile, "%lf", &current_prof_count) == EOF)
		    current_prof_count = 0.0;
	   }
	}

        break;
       }
      case NT_IfCond:
       {
	/* LCW - put current profiling weight to the statement - 10/24/95 */
	if (DO_ANNOTATE_PCODE)
	   CurrStmt->profile = NewProfST((double)current_prof_count);

        fprintf(F, "\t(IF ");
        GenCommaExpr(CurrStmt->stmtstruct.ifstmt->cond_expr);
        fprintf(F, " (THEN %d)", CurrStmt->stmtstruct.ifstmt->
                                 then_block->flow->entry_flow_node->bb->index + 1);
        if(CurrStmt->stmtstruct.ifstmt->else_block) {
	  /* LCW - insert a new basic block for else-part and put a probe
           * here - 10/08/95
           */
          /* BCC - 4/1/96 
           * Don't probe codes in global data declarations since it is executed 
           * only once and the probe might screw up the syntax.
           */
          if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
             fprintf(F, " (ELSE %d)", next_probe_BB);
	     /* LCW - should generate pragmas for flattened boolean 
		expressions here if there is any - 3/13/97 */
	     if (CurrStmt->pragma)
	        GenExprPragma(CurrStmt->pragma);
	     fprintf(F, ") )\n");
             fprintf(F, " (BB %d\n", next_probe_BB++);
             insert_probe(F, next_probe++);
             fprintf(F, "\t(GOTO %d) )\n", CurrStmt->stmtstruct.ifstmt->
			else_block->flow->entry_flow_node->bb->index + 1);
	     InsideBB = FALSE;
	     /* LCW - append the profiling data - 10/24/95 */
	     if (DO_ANNOTATE_PCODE) {
	        /* LCW - modified to read floating-point profile weights and 
		   to handle the case when EOF is encountered - 3/5/97 */
		if (fscanf(Fprofile, "%lf", &prof_count) == EOF)
		   prof_count = 0.0;
		ProfStPtr = CurrStmt->profile;
		while (ProfStPtr->next)
		   ProfStPtr = ProfStPtr->next;
		ProfStPtr->next = NewProfST((double)prof_count);
	     }
	     break;
          }
          else
             fprintf(F, " (ELSE %d)", CurrStmt->stmtstruct.ifstmt->
                        else_block->flow->entry_flow_node->bb->index + 1);
	}
        else
         {
	  /* LCW - insert a new basic block for else-part and put a probe
           * here - 10/08/95
           */
          /* BCC - 4/1/96 
           * Don't probe codes in global data declarations since it is executed 
           * only once and the probe might screw up the syntax.
           */
          if (INSIDE_FUNCTION && (DO_INSERT_PROBE || DO_ANNOTATE_PCODE)) {
             fprintf(F, " (ELSE %d)", next_probe_BB);
	     /* LCW - should generate pragmas for flattened boolean 
		expressions here if there is any - 3/13/97 */
	     if (CurrStmt->pragma)
	        GenExprPragma(CurrStmt->pragma);
	     fprintf(F, ") )\n");
             fprintf(F, " (BB %d\n", next_probe_BB++);
             insert_probe(F, next_probe++);
	     if (CurrStmt->stmtstruct.ifstmt->then_block->flow->entry_flow_node 
		 == ((FlowNode)CurrStmt->flow->entry_flow_node->succ->ptr))
		fprintf(F, "\t(GOTO %d) )\n", ((FlowNode)CurrStmt->flow->
			entry_flow_node->succ->next->ptr)->bb->index + 1);
	     else
		fprintf(F, "\t(GOTO %d) )\n", ((FlowNode)CurrStmt->flow->
			entry_flow_node->succ->ptr)->bb->index + 1);
	     InsideBB = FALSE;
	     /* LCW - append the profiling data - 10/24/95 */
             if (DO_ANNOTATE_PCODE) {
	        /* LCW - modified to read floating-point profile weights and 
		   to handle the case when EOF is encountered - 3/5/97 */
                if (fscanf(Fprofile, "%lf", &prof_count) == EOF)
		   prof_count = 0.0;
                ProfStPtr = CurrStmt->profile;
                while (ProfStPtr->next)
                   ProfStPtr = ProfStPtr->next;
                ProfStPtr->next = NewProfST((double)prof_count);
             }
	     break;
	  } 
          if(CurrStmt->stmtstruct.ifstmt->then_block->flow->entry_flow_node == 
              ((FlowNode)CurrStmt->flow->entry_flow_node->succ->ptr))
            fprintf(F, " (ELSE %d)", ((FlowNode)CurrStmt->flow->entry_flow_node->
                                      succ->next->ptr)->bb->index + 1);
          else
            fprintf(F, " (ELSE %d)", ((FlowNode)CurrStmt->flow->entry_flow_node->
                                      succ->ptr)->bb->index + 1);
         }

	/* BCC - generate pragmas for flattened boolean expressions - 9/13/96 */
	if (CurrStmt->pragma)
	  GenExprPragma(CurrStmt->pragma);

	/* LCW - append source info pragma - 9/30/97 */
	if (EMIT_SOURCE_INFO) {
	   char pragmastr[256];
	   char strip_fname[256];
	   HC_write_name_to_pragma_str(pragmastr, "POS");
	   HC_append_string_to_pragma_str(pragmastr, StripDoubleQuotes(strip_fname, CurrStmt->filename));
	   HC_append_int_to_pragma_str(pragmastr, CurrStmt->lineno);
	   GenExprPragmaFromStr(pragmastr);
	   HC_write_name_to_pragma_str(pragmastr, "SCOPE");
	   HC_append_int_to_pragma_str(pragmastr, FindStmtScope(CurrStmt));
	   GenExprPragmaFromStr(pragmastr);
	}
	/* LCW - end of change */
        fprintf(F, ") )\n");
        InsideBB = FALSE;
        break;
       }
      case NT_Advance:
       {
	fprintf(F, "\t(sync");
	HC_write_name_to_pragma_str(pragmastr, "ADVANCE");
	HC_append_int_to_pragma_str(pragmastr, CurrStmt->stmtstruct.advance->marker);
	GenExprPragmaFromStr(pragmastr);
	fprintf(F, ")");
        break;
       }
      case NT_Await:
       {
	fprintf(F, "\t(sync");
	HC_write_name_to_pragma_str(pragmastr, "AWAIT");
	HC_append_int_to_pragma_str(pragmastr, CurrStmt->stmtstruct.await->marker);
	HC_append_int_to_pragma_str(pragmastr, CurrStmt->stmtstruct.await->distance);
	GenExprPragmaFromStr(pragmastr);
	fprintf(F, ")");
        break;
       }
      default:
       {
        Punt("ConvFNQueue: Unimplemented Flow Node Type");
       }
     } 

    PrevFN = CurrFN;
   }
  if (InsideBB) 
    fprintf(F, "\t(RETURN) )\n");
 }

ConsolidateFNQueue()
 {
  FNQueue CurrFNQ, PrevFNQ;
  FNQueue TopFNQ, BottomFNQ;

  PrevFNQ = NULL;
  CurrFNQ = FNListHead;
  while(CurrFNQ)
   {
    if (PrevFNQ != NULL)
     {
      if (CurrFNQ->fn->bb->index != PrevFNQ->fn->bb->index)
       {
        if (((FlowNode) PrevFNQ->fn->succ->ptr)->type != NT_FuncExit)
         {
          if (((FlowNode) PrevFNQ->fn->succ->ptr)->bb->index == PrevFNQ->fn->bb->index)
           {
            TopFNQ = CurrFNQ;
            while(TopFNQ->next->fn != ((FlowNode) PrevFNQ->fn->succ->ptr))
              TopFNQ = TopFNQ->next;
            BottomFNQ = TopFNQ;
            while(BottomFNQ->next && BottomFNQ->next->fn->bb->index == PrevFNQ->fn->bb->index)
              BottomFNQ = BottomFNQ->next;
            PrevFNQ->next = TopFNQ->next;
            TopFNQ->next = BottomFNQ->next;
            BottomFNQ->next = CurrFNQ;     
            CurrFNQ = PrevFNQ->next;       
           }
         }
       }
     }
    PrevFNQ = CurrFNQ;
    CurrFNQ = CurrFNQ->next;
   }
 }


GenStmts(Stmt st)
 {
  InitFNQueue();
  BuildFNQueue(st);
  ConsolidateFNQueue();
  ConvFNQueue();
 }

/*********************************************
**  Generate Statement Code Ends            **
**  DIA: 1/6/93                             **
*********************************************/




/* NJW - 12/15  Generate the remaining local data declarations
 */

GenRemainingLocalDataDcl(st) 
     Stmt st;
{
  VarList ptr;
  if(st == 0) return;
  
  switch(st->type) {
  case ST_IF:
    GenRemainingLocalDataDcl(st->stmtstruct.ifstmt->then_block);
    if(st->stmtstruct.ifstmt->else_block)
      GenRemainingLocalDataDcl(st->stmtstruct.ifstmt->else_block);
    break;
  case ST_SWITCH:
    GenRemainingLocalDataDcl(st->stmtstruct.switchstmt->switchbody);
    break;
  case ST_PARLOOP:
    GenRemainingLocalDataDcl(st->stmtstruct.parloop->pstmt->stmt);
    break;
  case ST_SERLOOP:
    GenRemainingLocalDataDcl(st->stmtstruct.serloop->loop_body);
    break;
  case ST_PSTMT:
    GenRemainingLocalDataDcl(st->stmtstruct.pstmt->stmt);
    break;
  case ST_BODY:
    GenRemainingLocalDataDcl(st->stmtstruct.bodystmt->statement);
    break;
  case ST_EPILOGUE:
    GenRemainingLocalDataDcl(st->stmtstruct.epiloguestmt->statement);
    break;
  case ST_COMPOUND:
    for(ptr = st->stmtstruct.compound->var_list; ptr!=0; ptr=ptr->next) {
      fprintf(F, " ");
      GenLocalDataDcl(ptr->var);
    }
    GenRemainingLocalDataDcl(st->stmtstruct.compound->stmt_list);
    break;
  default:
    break;
  }
  if(st->lex_next != 0)
    GenRemainingLocalDataDcl(st->lex_next);
}

static void Split_Basic_Blocks(bbg)
    BBGraph bbg;
{
    BBNode bbn, new;
    FlowNode fn;
    Lptr flow, nflow;
    int nodes, bbnum, order, numnew;

    /* first, calculate number of new basic blocks needed */
    numnew = 0;
    nodes = bbg->num_nodes;

    for (bbnum = 0; bbnum < nodes; bbnum++) {
	bbn = bbg->bb_node[bbnum];

	for (flow = bbn->flows; flow->next != NIL; flow = flow->next) {
	    fn = (FlowNode) flow->ptr;
	    if (fn->type == NT_Goto || fn->type == NT_SwitchCond) numnew++;
	}
    }

    /* reallocate bb array to accommodate new basic blocks */
    bbg->bb_node = realloc(bbg->bb_node, (nodes + numnew) * sizeof(BBNode));

    /* Now split basic blocks anywhere there is an internal NT_Goto 
       or NT_SwitchCond flow node */
    for (bbnum = 0; bbnum < nodes; bbnum++) {
	bbn = bbg->bb_node[bbnum];
	order = 0;

	assert(bbn->flows != NIL);
	for (flow = bbn->flows, nflow = flow->next; 
	     nflow != NIL; 
	     flow = nflow, nflow = flow->next) {

	    fn = (FlowNode) flow->ptr;
	    fn->order = order++;
	    fn->bb = bbn;

	    if (fn->type == NT_Goto || fn->type == NT_SwitchCond) {
		new = NewBBNode(bbg);
		new->index = bbg->num_nodes - 1;
		bbg->bb_node[new->index] = new;

		new->succ = bbn->succ;
		bbn->succ = NIL;
		ConnectBBNodes(bbn, new);

		new->flows = nflow;
		flow->next = NIL;
		order = 0;

		bbn = new;
	    }
	}

	fn = (FlowNode) flow->ptr;
	fn->bb = bbn;
	fn->order = order;
    }

    assert(nodes + numnew == bbg->num_nodes);

    /* dispose of corrupted information - GEH 6/12/95 */
    if (CF_Function_Has_BB_Dominators(bbg->func)) 
	CF_Dispose_BB_Dominators(bbg->func);
    if (CF_Function_Has_BB_Post_Dominators(bbg->func)) 
	CF_Dispose_BB_Post_Dominators(bbg->func);
    if (CF_Function_Has_Loop_Summ(bbg->func)) 
	CF_Dispose_Loop_Summ(bbg->func);
    if (CF_Function_Has_BB_Loop_Flow(bbg->func)) 
	CF_Dispose_BB_Loop_Flow(bbg->func);
}


/* print function definition. */
static GenFunction(func)
     FuncDcl func;
{
  VarList ptr;
  Stmt st;
  char pragmastr[8192], pragmastr1[8192], *str;
  int start_probe, i; /* LCW */
  Pragma prag;
  Dcltr dcltr;
  
  if (func==0) Punt("GenFunction : nil input");
  if (func->type==0) Punt("GenFunction : no return type");
  if (func->name==0) Punt("GenFunction : no name");

  /* Generate CF information if not done already */
  if (!CF_Function_Has_BBG(func)) 
    CF_Build_BBG_Function(func);

  /* GEH - Split basic blocks at internal NT_Goto and NT_Switch flow nodes */
  Split_Basic_Blocks(func->flow->flow_graph->bb_graph);

  if (hcode_static_prof || dep_pragmas_generated) 
    CF_Build_Loop_Summ_Function(func);

  /* LCW - next basic block number for probe insertion - 10/08/95 */
  next_probe_BB = func->flow->flow_graph->bb_graph->num_nodes + 1;

  /* LCW - generate the declaration for initialization functions and 
     probe array - 3/25/99 */
  if (DO_INSERT_PROBE || DO_ANNOTATE_PCODE || DO_INSERT_LOOP_TRIP_COUNT_PROBE 
      || DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) {
     /* fprintf(F, "(GVAR _PP_is_initialized ((EXTERN)(INT)()))\n"); */
     fprintf(F, "(GVAR _PP_initialize ((EXTERN)(VOID)((F))))\n");
     if (DO_INSERT_PROBE || DO_ANNOTATE_PCODE) {
        fprintf(F, "(GVAR %s ((EXTERN)(LONG)((A))))\n", probe_array_name);
	start_probe = next_probe;
     }
     if (DO_INSERT_LOOP_TRIP_COUNT_PROBE || 
	 DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT)
        fprintf(F, "(GVAR _PP_loop_iter_update ((EXTERN)(VOID)((F))))\n");
  }

#if 0 /* LCW - we don't insert atexit in function main anymore - 3/25/99 */
  /* LCW - set IS_MAIN flag if the current function is the main function 
   * - 10/10/95 
   */
  if (DO_INSERT_PROBE || DO_ANNOTATE_PCODE || DO_INSERT_LOOP_TRIP_COUNT_PROBE 
      || DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) {
     if (!strcmp(func->name, "main") || !strcmp(func->name, "MAIN__")) {
        IS_MAIN = 1;
	/* LCW - we don't need to dump probe array when inserting pseudo
	 * probes - 10/25/96
	 */
	if (!DO_INSERT_PSEUDO_PROBE) {
	  fprintf(F, "(GVAR atexit ((EXTERN)(INT)(F)))\n");
	  fprintf(F, "(GVAR _dump_probe_array ((EXTERN)(VOID)(F)))\n");
	}
     }
     else
        IS_MAIN = 0;
  }
#endif

  /* BCC - signaling it's inside a function - 4/1/96 */
  INSIDE_FUNCTION = 1;
  fprintf(F, "(BEGIN_FN %s)\n", func->name);
  /* LCW - print function profile - 5/10/96 */
  /* LCW - check if function has profile information first - 1/28/97 */
  if (func->profile != NULL) {
     fprintf(F, " (PROFILE %d %f)\n", num_func, func->profile->count);
  }
  else if (func->stmt->stmtstruct.compound->stmt_list != NULL) {
     if (func->stmt->stmtstruct.compound->stmt_list->profile != NULL)
        fprintf(F, " (PROFILE %d %f)\n", num_func, 
	     func->stmt->stmtstruct.compound->stmt_list->profile->count);
  }
  fprintf(F, " (RETURN_TYPE (");
  GenType(func->type, 2);		/* return type */ /* always GLOBAL??*/
  GenDcltr(func->type->dcltr, 1);
  fprintf(F, "))\n");
  /* print parameter definition */
  HC_write_name_to_pragma_str(pragmastr, "call_info");

  /* BCC - advance dcltr to skip "F" */
  dcltr = func->type->dcltr;
  func->type->dcltr = dcltr->next;
  encode_type_name(func->type, pragmastr1);
  func->type->dcltr = dcltr;

  for (ptr=func->param; ptr!=0; ptr=ptr->next) {
    /* BCC - 5/17/98 */
    char temp_str[1024];

    strcat(pragmastr1, "%");
    encode_type_name(ptr->var->type, temp_str);
    strcat(pragmastr1, temp_str);

    fprintf(F, " ");
    GenParamDataDcl(ptr->var);
  }
  /* BCC - print out the func param_type_list pragma */
  HC_append_string_to_pragma_str(pragmastr, pragmastr1);
#if 0
  HC_write_name_to_pragma_str(pragmastr, pragmastr1);
#endif
  GenFnPragmaFromStr(pragmastr);

  /* print local variable definition from compound stmts. */
  GenRemainingLocalDataDcl(func->stmt);
  
  /* LCW - generate variable declaration for loop iter counters - 3/24/99 */
  if (DO_INSERT_LOOP_TRIP_COUNT_PROBE || 
      DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) {
     loops_num = PP_get_loop_number(func->stmt);
     for (i = 0; i < loops_num; i ++)
         fprintf(F, " (LVAR _PP_LP_COUNTER_%d ((UNSIGNED)(LONG)()))\n", i);
     /* save the diff between the next loop id and the loop iter counter id */
     lp_id_counter_diff = next_loop_id;
  }

  /* print pragma */
  /*
    for (pragma=func->pragma; pragma!=0; pragma=pragma->next) {
    fprintf(F, " (FN_PRAGMA %s)\n", pragma->specifier);
    }
    */

  /* GEH - add function pragma for call convention qualifier here */
  if (func->type->dcltr != 0 &&
      func->type->dcltr->method == D_FUNC &&
      func->type->dcltr->qualifier != 0) {

    HC_write_name_to_pragma_str(pragmastr, "CALL_CONV");
    if (func->type->dcltr->qualifier & DQ_CDECL) 
	HC_append_string_to_pragma_str(pragmastr, "CDECL");
    if (func->type->dcltr->qualifier & DQ_STDCALL) 
	HC_append_string_to_pragma_str(pragmastr, "STDCALL");
    if (func->type->dcltr->qualifier & DQ_FASTCALL) 
	HC_append_string_to_pragma_str(pragmastr, "FASTCALL");
    GenFnPragmaFromStr(pragmastr);
  }

  /* GEH - added pragmas for function and file name */
  /* BCC - temp fix - 4/11/96 
   * For a null function like foo1() {}, there is no way to insert
   * pos, therefore no place to insert filename. So just don't
   * check that.
   */
  if (hcode_func_prags && func->filename) {

      if (func->name == NIL)
	  Punt("GenFunction: missing File or Function name info for pragmas");

      HC_write_name_to_pragma_str(pragmastr, "FUNC");
      HC_append_string_to_pragma_str(pragmastr, func->name);
      HC_append_int_to_pragma_str(pragmastr, func->lineno);
      GenFnPragmaFromStr(pragmastr);

      HC_write_name_to_pragma_str(pragmastr, "FILE");
      HC_append_string_to_pragma_str(pragmastr, DQString2String(func->filename));
      GenFnPragmaFromStr(pragmastr);
  }

  if (dep_pragmas_generated) {
      HC_write_name_to_pragma_str(pragmastr, "DEP_PRAGMAS");
      GenFnPragmaFromStr(pragmastr);
  }

  /* GEH - added static profile information pragmas */
  if (hcode_static_prof) {
      HC_write_name_to_pragma_str(pragmastr, "STAT_PROF");
      HC_append_real_to_pragma_str(pragmastr, hcode_stat_func_weight);
      GenFnPragmaFromStr(pragmastr);
  }

  /* BCC - generate flatten pragma - 7/11/96 */
  if (FindFunctionPragma(func, "\"flatten\"")) {
      HC_write_name_to_pragma_str(pragmastr, "flatten");
      GenFnPragmaFromStr(pragmastr);
  }

  /* BCC - generate old_style_param pragma - 8/22/96 */
  if (FindFunctionPragma(func, "\"old_style_param\"")) {
      HC_write_name_to_pragma_str(pragmastr, "old_style_param");
      GenFnPragmaFromStr(pragmastr);
  }

  /* ITI/BCC - generate append_gcc_ellipsis pragma - 4/6/99 */
  if (FindFunctionPragma(func, "\"append_gcc_ellipsis\"")) {
      HC_write_name_to_pragma_str(pragmastr, "append_gcc_ellipsis");
      GenFnPragmaFromStr(pragmastr);
  }

  /* BCC - generate args_pcode_promoted pragma - 9/16/96 */
  if (!FindFunctionPragma(func, "\"args_pcode_promoted\"")) {
      HC_write_name_to_pragma_str(pragmastr, "args_pcode_promoted");
      GenFnPragmaFromStr(pragmastr);
  }

  /* BCC - generate brand names - 1/28/99 */
  /* JCG - modified to support new pragmas and pragma format - 6/99 */
  if ((prag = FindFunctionPragma(func, "\"IMPACT_INFO\""))) {
      HC_write_name_to_pragma_str(pragmastr, "impact_info");
      str = DQString2String(prag->expr->value.string);
      HC_append_string_to_pragma_str(pragmastr, str);
      free(str);
      GenFnPragmaFromStr(pragmastr);
  }

  if ((prag = FindFunctionPragma(func, "\"HOST_INFO\""))) {
      HC_write_name_to_pragma_str(pragmastr, "host_info");
      str = DQString2String(prag->expr->value.string);
      HC_append_string_to_pragma_str(pragmastr, str);
      free(str);
      GenFnPragmaFromStr(pragmastr);
  }

  if ((prag = FindFunctionPragma(func, "\"PREPROCESS_INFO\""))) {
      HC_write_name_to_pragma_str(pragmastr, "preprocess_info");
      str = DQString2String(prag->expr->value.string);
      HC_append_string_to_pragma_str(pragmastr, str);
      free(str);
      GenFnPragmaFromStr(pragmastr);
  }

  /* LCW - extract BB profile info if the input Pcode has been profiled 
     - 5/16/96 */
  /* LCW - check if the function has profile information first - 1/29/97 */
  if (func->profile != NULL)
     ExtractBBProfile(func->stmt);
  else if (func->stmt->stmtstruct.compound->stmt_list != NULL) {
     if (func->stmt->stmtstruct.compound->stmt_list->profile != NULL)
        ExtractBBProfile(func->stmt);
  }

  /* print function body */

  fprintf(F, " (ENTRY 1)\n");

  GenStmts(func->stmt);
  
  fprintf(F, "(END_FN %s)\n", func->name);

  /* LCW - put the function profile in the Pcode function pragma - 1/28/97 */
  if (DO_ANNOTATE_PCODE) {
     Expr weight_expr;
 
     if (func->stmt->profile != NULL)
        weight_expr = NewDoubleExpr(func->stmt->profile->count);
     else if (func->stmt->stmtstruct.compound->stmt_list != NULL) {
        if (func->stmt->stmtstruct.compound->stmt_list->profile != NULL)
	   weight_expr = NewDoubleExpr(func->stmt->stmtstruct.compound
				       ->stmt_list->profile->count);
     }
     if (weight_expr != NULL) {
        AddFunctionPragma(func, "\"profile\"", weight_expr);
	RemoveExpr(weight_expr);
     }
  }

  /* LCW - write probe status to file - 10/12/95 */
  if (DO_INSERT_PROBE)
     fprintf(Fallprobe, "%s %d %d\n", func->name, start_probe, next_probe - 1);

  /* BCC - signaling it's finished parsing a function - 4/1/96 */
  INSIDE_FUNCTION = 0;
  fflush(F);
}

/*========================================================================*/
/* print enum type definition. */
static GenEnumDcl(E)
     EnumDcl E;
{
  EnumField ptr;
  if (E==0) Punt("GenEnumDcl : nil E");
  /* BCC - if spliting, enum are replaced by int - 7/1/95 */
  if (split == 1) return;
  if(E->new_name != 0)
    fprintf(F, "(DEF_ENUM %s ", E->new_name);
  else
    fprintf(F, "(DEF_ENUM %s ", E->name);
  ptr=E->fields;
  while (ptr!=0) {	/* print fields. */
    if(ptr->new_name != 0)
      fprintf(F, " (\"%s\"", ptr->new_name);
    else
      fprintf(F, " (\"%s\"", ptr->name);
    if (ptr->value!=0) {	
      fprintf(F, " ");
      GenExpr(ptr->value);
    }
    fprintf(F, ")");
    ptr = ptr->next;
  }
  fprintf(F, ")\n");
  if(line_yes)	/* output position */
    if(E->filename != 0)
      Gen_HCODE_LinePos(F, E->lineno, E->filename);
}
/*========================================================================*/
/* print a struct/union field. */
static GenStructField(field)
     Field field;
{
  if (field==0) return;
  fprintf(F, "(");
  if (field->name!=0) {
    fprintf(F, "\"%s\"", field->name);
  } else {
    fprintf(F, "\"\"");
  }
  fprintf(F, " (");
  GenType(field->type, 1);
  GenDcltr(field->type->dcltr, 0);
  fprintf(F, ")");
  if (field->bit_field!=0) {
    fprintf(F, " ");
    GenExpr(field->bit_field);
  }
  fprintf(F, ")\n");
}
/* print struct structure definition. */
static GenStructDcl(S)
     StructDcl S;
{
  Field ptr;
  if (S==0) Punt("GenStructDcl : nil S");
  if(S->new_name != 0)
    fprintf(F, "(DEF_STRUCT %s\n", S->new_name);
  else
    fprintf(F, "(DEF_STRUCT %s\n", S->name);
  for (ptr=S->fields; ptr!=0; ptr=ptr->next) {
    fprintf(F, " ");
    GenStructField(ptr);
  }
  fprintf(F, ")\n");
  if(line_yes)	/* output position */
    if(S->filename != 0)
      Gen_HCODE_LinePos(F, S->lineno, S->filename);
}
/* print union structure definition. */
static GenUnionDcl(U)
     StructDcl U;
{
  Field ptr;
  if (U==0) Punt("GenUnionDcl : nil U");
  if(U->new_name != 0)
    fprintf(F, "(DEF_UNION %s\n", U->new_name);
  else
    fprintf(F, "(DEF_UNION %s\n", U->name);
  for (ptr=U->fields; ptr!=0; ptr=ptr->next) {
    fprintf(F, " ");
    GenStructField(ptr);
  }
  fprintf(F, ")\n");
  if(line_yes)	/* output position */
    if(U->filename != 0)
      Gen_HCODE_LinePos(F, U->lineno, U->filename);
}
/*========================================================================*/
static GenInit(init)
     Init init;
{
  int n;
  /*
   * initializer :
   *	expression?
   *	(AGGR initializer*)?
   */
  if (init==0) return;	/* init is only optional. */
  if (init->expr!=0) {
    fprintf(F, " ");
    GenExpr(init->expr);
  } else
    if (init->set!=0) {
      Init ptr;
      fprintf(F, " (AGGR");
      ptr=init->set;
      n = 0;
      while (ptr!=0) {
	GenInit(ptr);
	ptr = ptr->next;
	n++;
	if ((n%4)==0) fprintf(F, "\n");
      }
      fprintf(F, ")");
    } else
      Punt("GenInit : unknown data type");
}
/*========================================================================*/
/* print parameter definition. */
void GenParamDataDcl(V)
     VarDcl V;
{
  char *name;
  if (V==0) Punt("GenParamDataDcl : nil V");
  /* (PARAMETER name%s DeclSpec) */
  if(V->new_name != 0)			/* rename if needed */
    name = V->new_name;
  else
    name = V->name;
  fprintf(F, "(PARAMETER %s (", name);
  GenType(V->type, 3);			/* type */ /* PARAMETER */
  GenDcltr(V->type->dcltr, 0);
  fprintf(F, "))\n");
}
/* print local variable definition. make sure use new_name */
static GenLocalDataDcl(V)
     VarDcl V;
{
  char *name;
  if (V==0) Punt("GenLocalDataDcl : nil V");
  /* (LVAR name%s DeclSpec) */
  if(V->new_name != 0)			/* rename if needed */
    name = V->new_name;
  else
    name = V->name;
  /* BCC - don't print useless variables - 1/23/97 */
  if (IsUselessVar(NULL, name)) return;
  fprintf(F, "(LVAR %s (", name);
  GenType(V->type, 1);			/* type */
  GenDcltr(V->type->dcltr, 0);
  fprintf(F, "))\n");
}
/* print global variable definition. */
/* the type definition is what's recorded at that instance of the
 * global variable definition. If it is extern class, the initialization
 * section is not printed.
 */
static GenGlobalDataDcl(V, type, dcltr)
     VarDcl V;
     Type type;
     Dcltr dcltr;
{
  /*
   * (GVAR name%s DeclSpec Initializer)
   */
  if (V==0) Punt("GenGlobalDataDcl : nil V");
  if(V->new_name != 0)
    fprintf(F, "(GVAR %s (", V->new_name);
  else
    fprintf(F, "(GVAR %s (", V->name);
  GenType(type, 2);				/* type */ /*GLOBAL */
  GenDcltr(dcltr, 0);				/* dcltr */
  fprintf(F, ")");
  if (! (type->type & TY_EXTERN)) {
    if (V->init!=0) {
      fprintf(F, "\n");
      GenInit(V->init);
    }
  }
  fprintf(F, ")\n");
  if(line_yes)	/* output position */
    if(V->filename != 0)
      Gen_HCODE_LinePos(F, V->lineno, V->filename);
}
/*========================================================================*/
Gen_HCODE_LinePos(F, n, src_file)
     FILE *F;
     int n;
     char *src_file;
{
  if (BLOCK_OUTPUT) return;
  fprintf(F, "(POSITION %d %s)\n", n, src_file);
}
Gen_HCODE_Struct(FL, st)
     FILE *FL;
     StructDcl st;
{
  if (BLOCK_OUTPUT) return;
  F = FL;
  GenStructDcl(st);
}
Gen_HCODE_Union(FL, un) 
     FILE *FL;
     UnionDcl un;
{
  if (BLOCK_OUTPUT) return;
  F = FL;
  GenUnionDcl(un);
}
Gen_HCODE_Enum(FL, en) 
     FILE *FL;
     EnumDcl en;
{
  if (BLOCK_OUTPUT) return;
  F = FL;
  GenEnumDcl(en);
}
Gen_HCODE_Var(FL, var) 
     FILE *FL;
     VarDcl var;
{
  if (BLOCK_OUTPUT) return;
  F = FL;
  GenGlobalDataDcl(var, var->type, var->type->dcltr);
}
Gen_HCODE_Func(FL, fn) 
     FILE *FL;
     FuncDcl fn;
{
  if (BLOCK_OUTPUT) return;
  F = FL;
  GenFunction(fn);
}

Gen_HCODE_Expr(FILE *FL, Expr expr)
{
  if (BLOCK_OUTPUT) return;
  F = FL;
  GenExpr(expr);
}

/* BCC - added to generate (INCLUDE xxxx) - 7/3/95 */
Gen_HCODE_Include(FL, file)
     FILE *FL;
     char *file;
{
    int buf;
    char new_file[256];
    int length;
    /* BCC - only include the same file once in a compilation - 7/13/96 */
    int print;


    sprintf(new_file, file);
    length = strlen(file)-1;
    while (length > 0) {
	if (new_file[length] == '.') {
	    new_file[length] = 0;
	    break;
	}
	length--;
    }
    strcat(new_file, ".hch\"");

    print = 1;
    if (!strcmp(new_file, "\"struct.hch\"")) {
        struct_count++;
        if (struct_count > 1) print = 0;
    }
    if (!strcmp(new_file, "\"extern.hch\"")) {
        extern_count++;
        if (extern_count > 1) print = 0;
    }

    if (! BLOCK_OUTPUT && print) {
	fprintf(FL, "(INCLUDE %s)\n", new_file);
    }
/* Change BLOCK_OUTPUT to check if include_nesting != 0 */
#if 0
    buf = OUTPUT;
    DO_OUTPUT(0);
#endif
/* TLJ - change this to "SetupIncludeFile" and incr include flag */
  SetupIncludeFile(file);
#if 0
    ReadIncludeFile(file);
    DO_OUTPUT(buf);
#endif
}

/*========================================================================*/
/* 
 *	The following functions are provided for debugging purpose
 *	only and should not be used in normal operational mode.
 */
Gen_HCODE_Init(FL, init)
     FILE *FL;
     Init init;
{
  F = FL;
  GenInit(init);
}
/*========================================================================*/


/*
 * LCW - Check if the expression contains function call(s) - 1/30/97 
 */
static int contain_func_call(struct _Expr *expr)
{
  if (expr->opcode == OP_call)
     return(1);

  if (expr->operands != NULL)
     if (contain_func_call(expr->operands))
        return(1);

  if (expr->sibling != NULL)
     if (contain_func_call(expr->sibling))
        return(1);

  return(0);
}

/*
 * LCW - extract the basic block profiling information from the Pcode
 * statement profile information - 5/12/96
 */
ConvFNQueue_BBProfile() {
  FlowNode CurrFN, PrevFN, FNTemp1, FNTemp2;
  Stmt CurrStmt, StmtIndx;
  int InsideBB, Default;
  Lptr LptrIndx;
  Label LabelIndx;
  struct _ProfST *ProfStPtr;
  struct _ProfBB *CurrProfBB;
  struct _ProfArc *ProfArcPtr, *LastProfArc;
  int init_total, init_not_taken, init_taken;
  int iter_not_taken, iter_taken;
  /* int Prev_Is_StmtExit = FALSE; */
  int prev_is_func_call = FALSE;
  int is_bb_start = FALSE;
  int func_call_in_bb = FALSE;
  int bb_prof_is_adjusted = FALSE;
  double out_weight = 0.0;

  PrevFN = NULL;
  InsideBB = TRUE;
  while(CurrFN = FNDequeue())
   {
    CurrStmt = CurrFN->pcode_ptr.stmt;

    if ((PrevFN == NULL) || 
	(CurrFN->bb->index != PrevFN->bb->index && !InsideBB)) {
      /* fprintf(F, " (BB %d\n", CurrFN->bb->index + 1); */
       is_bb_start = TRUE;
       func_call_in_bb = FALSE;
       bb_prof_is_adjusted = FALSE;
       prev_is_func_call = FALSE;
       CurrProfBB = CurrFN->bb->profile = NewProfBB();
       if (CurrStmt->profile != NULL)
	  CurrProfBB->weight = CurrStmt->profile->count;
       else if (CurrStmt->type == ST_COMPOUND && 
		CurrStmt->stmtstruct.compound->stmt_list != NULL &&
		CurrStmt->stmtstruct.compound->stmt_list->profile != NULL)
	  CurrProfBB->weight = CurrStmt->stmtstruct.compound->stmt_list
	                       ->profile->count;
       else if ((PrevFN == NULL) && (currentFuncDcl->profile != NULL))
	  CurrProfBB->weight = currentFuncDcl->profile->count;
       else
	  Punt("ConvFNQueue_BBProfile: No profile info in the input Pcode");
       out_weight = CurrProfBB->weight;
       InsideBB = TRUE;

    }
    else if (CurrFN->bb->index != PrevFN->bb->index && InsideBB) {
      /* CLOSE ANY TYPE OF BASIC BLOCK HERE */ 
       if (((FlowNode) PrevFN->succ->ptr)->type != NT_FuncExit) {
	 /* fprintf(F, "\t(GOTO %d) )\n", 
		  ((FlowNode) PrevFN->succ->ptr)->bb->index + 1); */
	  if (out_weight > 0) {
	     CurrProfBB->destination = NewProfArc();
	     CurrProfBB->destination->bb_id = ((FlowNode)PrevFN->succ->ptr)->bb
	                                      ->index + 1;
	     CurrProfBB->destination->condition = 1;
	     CurrProfBB->destination->weight = out_weight;
	  }
       }
       /* else 
          fprintf(F, "\t(RETURN) )\n"); */
  
        /* fprintf(F, " (BB %d\n", CurrFN->bb->index + 1); */
       is_bb_start = TRUE;
       func_call_in_bb = FALSE;
       bb_prof_is_adjusted = FALSE;
       prev_is_func_call = FALSE;
       CurrProfBB = CurrFN->bb->profile = NewProfBB();
       if (CurrStmt->profile != NULL)
	  CurrProfBB->weight = CurrStmt->profile->count;
       else if (CurrStmt->type == ST_COMPOUND && 
		CurrStmt->stmtstruct.compound->stmt_list->profile != NULL)
	  CurrProfBB->weight = CurrStmt->stmtstruct.compound->stmt_list->profile->count;
       else
	  Punt("ConvFNQueue_BBProfile: No profile info in the input Pcode");
       out_weight = CurrProfBB->weight;
    }
    else {
       is_bb_start = FALSE;
    }

    /* Prev_Is_StmtExit = FALSE; */

    switch(CurrFN->type)
     {
      case NT_CompoundEntry:
      case NT_Null:
      case NT_Continue:
      case NT_Break:
	{
	  if (prev_is_func_call) {
	     if (CurrStmt->profile != NULL)
	        out_weight = CurrStmt->profile->count;
	     else if (CurrStmt->type == ST_COMPOUND && 
		      CurrStmt->stmtstruct.compound->stmt_list->profile != NULL)
	        out_weight = CurrStmt->stmtstruct.compound->stmt_list->
		             profile->count;
	     prev_is_func_call = FALSE;
	  }
	  break;
	}
      case NT_PStmtCompEntry:
      case NT_ParloopMainEpilogue:
      case NT_ParloopAuxEpilogue:
      case NT_CompoundExit: 
      case NT_PStmtCompExit:
      case NT_IfExit:
      case NT_SwitchExit:
      case NT_SerloopExit:
      case NT_ParloopExit:
      case NT_MutexExit:
	{
	  int bb_id;
	  _Lptr *pred_lptr;
	  struct _BBNode *pred_bb;
	  double in_weight = 0.0;
	  struct _ProfArc *arc;

	  if (is_bb_start) {
	     bb_id = CurrFN->bb->index + 1;
	     for (pred_lptr = CurrFN->pred; pred_lptr != NULL; 
		  pred_lptr = pred_lptr->next) {
	         pred_bb = ((_FlowNode *)pred_lptr->ptr)->bb;
		 if (pred_bb->profile != NULL) {
		    for (arc = pred_bb->profile->destination; arc != NULL;
			 arc = arc->next) {
		        if (arc->bb_id == bb_id) {
			   in_weight += arc->weight;
			   break;
			}
		    }
		 }
	     }
	     CurrProfBB->weight = in_weight;
	     out_weight = CurrProfBB->weight;
	     is_bb_start = FALSE;
	  }
	  /* Prev_Is_StmtExit = TRUE; */
	  break;
	}
      case NT_Goto:
       {
	FlowNode destfn = (FlowNode)CurrStmt->flow->entry_flow_node->succ->ptr;
        if (destfn->type != NT_FuncExit) {
	   /* fprintf(F, "\t(GOTO %d) )\n", destfn->bb->index + 1); */
	   if (CurrStmt->profile != NULL && CurrStmt->profile->count > 0) {
	      CurrProfBB->destination = NewProfArc();
	      CurrProfBB->destination->bb_id = destfn->bb->index + 1;
	      CurrProfBB->destination->condition = 1;
	      CurrProfBB->destination->weight = CurrStmt->profile->count;
	   }
	}
        InsideBB = FALSE;
        break;
       }
      case NT_SerloopInitCond:
       {
	 if (prev_is_func_call) {
	    if (CurrStmt->profile != NULL) {
	       out_weight = CurrStmt->profile->count;
	       prev_is_func_call = FALSE;
	    }
	 }
         goto SerloopCond_Label;
       }
      case NT_SerloopIterCond:
       {
	 if (is_bb_start) {
	    if (CurrStmt->stmtstruct.serloop->iter_expr != NULL)
	       CurrProfBB->weight = CurrStmt->stmtstruct.serloop->iter_expr->profile->count;
	    else if (CurrStmt->stmtstruct.serloop->cond_expr != NULL)
	       CurrProfBB->weight = CurrStmt->stmtstruct.serloop->cond_expr->profile->count;
	    is_bb_start = FALSE;
	    out_weight = CurrProfBB->weight;
	 }
	 if (prev_is_func_call) {
	    if (CurrStmt->stmtstruct.serloop->iter_expr != NULL) {
	       out_weight = CurrStmt->stmtstruct.serloop->iter_expr->profile->count;
	       prev_is_func_call = FALSE;
	    }
	    else if (CurrStmt->stmtstruct.serloop->cond_expr != NULL) {
	       out_weight = CurrStmt->stmtstruct.serloop->cond_expr->profile->count;
	       prev_is_func_call = FALSE;
	    }
	 }
	    
         goto SerloopCond_Label;
       }
      case NT_SerloopCond:
      /* GEH - modified to handle new for-while loops */
      SerloopCond_Label:
       {
        FNTemp1 = FindFlowNodeInList(NT_SerloopExit, CurrFN->succ);
        FNTemp2 = (FlowNode)(CurrFN->succ->ptr);
        if (FNTemp1 == FNTemp2)
          FNTemp2 = ((FlowNode)CurrFN->succ->next->ptr);

	if (CurrStmt->profile != NULL) {
	   init_total = CurrStmt->profile->count;
	   init_not_taken = CurrStmt->profile->next->count;
	   init_taken = init_total - init_not_taken;
	   iter_not_taken = CurrStmt->profile->next->next->count;
	   /* TLJ 7/10/96 - no iter_taken if was a FOR loop */
	   if (CurrFN->type != NT_SerloopInitCond) {
#if 0
	   if (PrevFN->pcode_ptr.stmt->profile != NULL)
	      iter_taken = PrevFN->pcode_ptr.stmt->profile->count - 
		            iter_not_taken;
	   else
	      iter_taken = PrevFN->pcode_ptr.stmt->stmtstruct.compound
		           ->stmt_list->profile->count - iter_not_taken;
#endif
	      if (CurrStmt->stmtstruct.serloop->iter_expr != NULL)
		 iter_taken = CurrStmt->stmtstruct.serloop->iter_expr->profile
		              ->count - iter_not_taken;
	      else if (CurrStmt->stmtstruct.serloop->cond_expr != NULL)
		 iter_taken = CurrStmt->stmtstruct.serloop->cond_expr->profile
		              ->count - iter_not_taken;
	      else {
		 if (PrevFN->pcode_ptr.stmt->profile != NULL)
		    iter_taken = PrevFN->pcode_ptr.stmt->profile->count - 
		                 iter_not_taken;
		 else
		    iter_taken = PrevFN->pcode_ptr.stmt->stmtstruct.compound
		                 ->stmt_list->profile->count - iter_not_taken;
	      }
	   }
	}
        /* Checking for conditional expression.  Is this necessary? */
        if (CurrStmt->stmtstruct.serloop->cond_expr) {
	  /* fprintf(F, " (THEN %d) (ELSE %d)) )\n", FNTemp2->bb->index + 1,
                  FNTemp1->bb->index + 1); */
	   if (CurrFN->type == NT_SerloopInitCond) {
	      if (init_taken > 0) {
		 ProfArcPtr = NewProfArc();
		 ProfArcPtr->bb_id = FNTemp2->bb->index + 1;
		 ProfArcPtr->condition = 1;
		 ProfArcPtr->weight = init_taken;
		 CurrProfBB->destination = LastProfArc = ProfArcPtr;
	      }	
	      else
		 LastProfArc = NULL;
	      if (init_not_taken >0) {
		 ProfArcPtr = NewProfArc();
		 ProfArcPtr->bb_id = FNTemp1->bb->index + 1;
		 ProfArcPtr->condition = 0;
		 ProfArcPtr->weight = init_not_taken;
		 if (LastProfArc != NULL)
		    LastProfArc->next = ProfArcPtr;
		 else
		    CurrProfBB->destination = ProfArcPtr;
	      }	
	   } 
	   else if (CurrFN->type == NT_SerloopIterCond) {
	      if (iter_taken > 0) {
	         ProfArcPtr = NewProfArc();
		 ProfArcPtr->bb_id = FNTemp2->bb->index + 1;
		 ProfArcPtr->condition = 1;
		 ProfArcPtr->weight = iter_taken;
		 CurrProfBB->destination = LastProfArc = ProfArcPtr;
	      } 
	      else
		 LastProfArc = NULL;
	      if (iter_not_taken > 0) {
		 ProfArcPtr = NewProfArc();
		 ProfArcPtr->bb_id = FNTemp1->bb->index + 1;
		 ProfArcPtr->condition = 0;
		 ProfArcPtr->weight = iter_not_taken;
		 if (LastProfArc != NULL)
		    LastProfArc->next = ProfArcPtr;
		 else
		    CurrProfBB->destination = ProfArcPtr;
	      }
	   }
	   else {  /* do-while loop */
	      if (iter_taken > 0) {
	         ProfArcPtr = NewProfArc();
		 ProfArcPtr->bb_id = FNTemp2->bb->index + 1;
		 ProfArcPtr->condition = 1;
		 ProfArcPtr->weight = iter_taken;
		 CurrProfBB->destination = LastProfArc = ProfArcPtr;
	      } 
	      else
		 LastProfArc = NULL;
	      if (iter_not_taken > 0) {
		 ProfArcPtr = NewProfArc();
		 ProfArcPtr->bb_id = FNTemp1->bb->index + 1;
		 ProfArcPtr->condition = 0;
		 ProfArcPtr->weight = iter_not_taken;
		 if (LastProfArc != NULL)
		    LastProfArc->next = ProfArcPtr;
		 else
		    CurrProfBB->destination = ProfArcPtr;
	      }
	   }
	} 
        else {
          /* fprintf(F, "\t(GOTO %d) )\n", FNTemp2->bb->index + 1); */
	  if (CurrFN->bb->profile != NULL) {
	     if (CurrFN->bb->profile->weight > 0) {
	        CurrProfBB->destination = NewProfArc();
		CurrProfBB->destination->bb_id = FNTemp2->bb->index + 1;
		CurrProfBB->destination->condition = 1;
		CurrProfBB->destination->weight = CurrFN->bb->profile->weight;
	     }
	  }
	}
        InsideBB = FALSE;
        break;
       }
      case NT_ParloopInitCond:
       {
	if (prev_is_func_call) {
	   if (CurrStmt->profile != NULL) {
	      out_weight = CurrStmt->profile->count;
	      prev_is_func_call = FALSE;
	   }
	}
        FNTemp1 = FindFlowNodeInList(NT_ParloopExit, CurrFN->succ);
	if (FNTemp1 != NIL) /* loop has short-circuit CF path */
	 {
	  FNTemp2 = FindFlowNodeInList(NT_PStmtCompEntry, CurrFN->succ);
	  /* fprintf(F, ") (THEN %d) (ELSE %d)) )\n", FNTemp2->bb->index + 1,
	          FNTemp1->bb->index + 1); */
	  if (CurrStmt->profile != NULL) {
	     init_total = CurrStmt->profile->count;
	     init_not_taken = CurrStmt->profile->next->count;
	     init_taken = init_total - init_not_taken;
	     if (init_taken > 0) {
		 ProfArcPtr = NewProfArc();
		 ProfArcPtr->bb_id = FNTemp2->bb->index + 1;
		 ProfArcPtr->condition = 1;
		 ProfArcPtr->weight = init_taken;
		 CurrProfBB->destination = LastProfArc = ProfArcPtr;
	      }	
	      else
		 LastProfArc = NULL;
	      if (init_not_taken >0) {
		 ProfArcPtr = NewProfArc();
		 ProfArcPtr->bb_id = FNTemp1->bb->index + 1;
		 ProfArcPtr->condition = 0;
		 ProfArcPtr->weight = init_not_taken;
		 if (LastProfArc != NULL)
		    LastProfArc->next = ProfArcPtr;
		 else
		    CurrProfBB->destination = ProfArcPtr;
	      }
	  } 
	  InsideBB = FALSE;
	 }
	break;    
       }
      case NT_ParloopIterCond:
       {
	  int bb_id;
	  _Lptr *pred_lptr;
	  struct _BBNode *pred_bb;
	  double in_weight = 0.0;
	  struct _ProfArc *arc;

	  if (is_bb_start) {
	     bb_id = CurrFN->bb->index + 1;
	     for (pred_lptr = CurrFN->pred; pred_lptr != NULL; 
		  pred_lptr = pred_lptr->next) {
	         pred_bb = ((_FlowNode *)pred_lptr->ptr)->bb;
		 if (pred_bb->profile != NULL) {
		    for (arc = pred_bb->profile->destination; arc != NULL;
			 arc = arc->next) {
		        if (arc->bb_id == bb_id) {
			   in_weight += arc->weight;
			   break;
			}
		    }
		 }
	     }
	     CurrProfBB->weight = in_weight;
	     out_weight = CurrProfBB->weight;
	     is_bb_start = FALSE;
	  }

        FNTemp1 = FindFlowNodeInList(NT_ParloopBody, CurrFN->succ);
        FNTemp2 = (FlowNode)(CurrFN->succ->ptr);
        if (FNTemp1 == FNTemp2)
          FNTemp2 = ((FlowNode)CurrFN->succ->next->ptr);
        /* fprintf(F, ") (THEN %d) (ELSE %d)) )\n", FNTemp1->bb->index + 1,
                FNTemp2->bb->index + 1); */
	if (CurrStmt->profile != NULL) {
	   iter_not_taken = CurrStmt->profile->next->next->count;
	   /* LCW - Use out_weight to determine iter_taken - 2/5/97 */
	   iter_taken = out_weight - iter_not_taken;
#if 0
	   if (PrevFN->pcode_ptr.stmt->profile != NULL)
	      iter_taken = PrevFN->pcode_ptr.stmt->profile->count - 
		            iter_not_taken;
	   else
	      iter_taken = PrevFN->pcode_ptr.stmt->stmtstruct.compound
		           ->stmt_list->profile->count - iter_not_taken;
#endif
	   if (iter_taken > 0) {
	      ProfArcPtr = NewProfArc();
	      ProfArcPtr->bb_id = FNTemp1->bb->index + 1;
	      ProfArcPtr->condition = 1;
	      ProfArcPtr->weight = iter_taken;
	      CurrProfBB->destination = LastProfArc = ProfArcPtr;
	   } 
	   else
	      LastProfArc = NULL;
	   if (iter_not_taken > 0) {
	      ProfArcPtr = NewProfArc();
	      ProfArcPtr->bb_id = FNTemp2->bb->index + 1;
	      ProfArcPtr->condition = 0;
	      ProfArcPtr->weight = iter_not_taken;
	      if (LastProfArc != NULL)
		 LastProfArc->next = ProfArcPtr;
	      else
		 CurrProfBB->destination = ProfArcPtr;
	   }
	}
        InsideBB = FALSE;
        break;    
       }
      case NT_ParloopBody:
        break;
      case NT_SerloopEntry:
       {
	if (prev_is_func_call) {
	   if (CurrStmt->profile != NULL) {
	      out_weight = CurrStmt->profile->count;
	      prev_is_func_call = FALSE;
	   }
	}
        break;
       }
      case NT_SwitchCond:
       {
	double prof_default;
	int case_number = 1; /* LCW - the order number of each case - 1/29/97 */
        Default = FALSE;

        /* fprintf(F, "\t(SWITCH ");
        GenCommaExpr(CurrStmt->stmtstruct.switchstmt->expression); */
	if (CurrStmt->profile == NULL)
	   Punt("ConvFNQueue_BBProfile: No profile info in the input Pcode");
	if (prev_is_func_call) {
	   out_weight = CurrStmt->profile->count;
	   prev_is_func_call = FALSE;
	}
	ProfStPtr = CurrStmt->profile->next;
	prof_default = CurrStmt->profile->count;
	LastProfArc = NULL;
        for (LptrIndx = CurrFN->succ; LptrIndx != NULL; LptrIndx = LptrIndx->next) {
          StmtIndx = ((FlowNode)LptrIndx->ptr)->pcode_ptr.stmt;
          if (StmtIndx != CurrStmt) {
             for(LabelIndx = StmtIndx->labels; LabelIndx != NULL; LabelIndx = LabelIndx->next)
               if(LabelIndx->type == LB_CASE) {
	    /* fprintf(F, " %d)", ((FlowNode)LptrIndx->ptr)->bb->index + 1); */
		 if (ProfStPtr->count > 0) {
		    ProfArcPtr = NewProfArc();
		    ProfArcPtr->bb_id =((FlowNode)LptrIndx->ptr)->bb->index+1;
		    /* LCW - condition should be the case number - 1/21/97 */
		    ProfArcPtr->condition = case_number;
		    ProfArcPtr->weight = ProfStPtr->count;
		    prof_default = prof_default - ProfStPtr->count;
		    if (LastProfArc != NULL) {
		       LastProfArc->next = ProfArcPtr;
		       LastProfArc = ProfArcPtr;
		    }
		    else
		       CurrProfBB->destination = LastProfArc = ProfArcPtr;
		 }	
		 ProfStPtr = ProfStPtr->next;
		 case_number++;
	       } 
	  } 
	} 
        for (LptrIndx = CurrFN->succ; LptrIndx != NULL; LptrIndx = LptrIndx->next) {
          StmtIndx = ((FlowNode)LptrIndx->ptr)->pcode_ptr.stmt;
          if (StmtIndx != CurrStmt) {
            for(LabelIndx = StmtIndx->labels; LabelIndx != NULL; LabelIndx = LabelIndx->next)
              if (LabelIndx->type == LB_DEFAULT) {
		 /* fprintf(F, " (DEFAULT");
                fprintf(F, " %d)", ((FlowNode)LptrIndx->ptr)->bb->index + 1);*/
		 if (prof_default > 0) {
		    ProfArcPtr = NewProfArc();
		    ProfArcPtr->bb_id = ((FlowNode)LptrIndx->ptr)->bb->index+1;
		    /* LCW - conditoin should be 0 for default case - 1/21/97 */
		    ProfArcPtr->condition = 0;
		    ProfArcPtr->weight = prof_default;
		    if (LastProfArc != NULL) 
		       LastProfArc->next = ProfArcPtr;
		    else
		       CurrProfBB->destination = ProfArcPtr;
		 }
		 Default = TRUE;
	      } 
          } 
	} 
        if (!Default) {
           /* fprintf(F, " (DEFAULT");
           fprintf(F, " %d)", FindFlowNodeInList(NT_SwitchExit, CurrFN->succ)->bb->index + 1); */
	   if (prof_default > 0) {
	      ProfArcPtr = NewProfArc();
	      ProfArcPtr->bb_id = FindFlowNodeInList(NT_SwitchExit, CurrFN->succ)->bb->index + 1;
	      /* LCW - conditoin should be 0 for default case - 1/21/97 */
	      ProfArcPtr->condition = 0;
	      ProfArcPtr->weight = prof_default;
	      if (LastProfArc != NULL) 
		 LastProfArc->next = ProfArcPtr;
	      else
		 CurrProfBB->destination = ProfArcPtr;
	   }	
        }
        InsideBB = FALSE;
        break;
       } 
      case NT_Return:
       {
	if (prev_is_func_call) {
	   if (CurrStmt->profile != NULL) {
	      out_weight = CurrStmt->profile->count;
	      prev_is_func_call = FALSE;
	   }
	}
        InsideBB = FALSE;
        break;
       }
      case NT_MutexEntry:
       {
	if (prev_is_func_call) {
	   if (CurrStmt->profile != NULL) {
	      out_weight = CurrStmt->profile->count;
	      prev_is_func_call = FALSE;
	   }
	}
	break;
       }
      case NT_Expr:
	{
	  if (prev_is_func_call) {
	    if (CurrStmt->profile != NULL) {
	       out_weight = CurrStmt->profile->count;
	       prev_is_func_call = FALSE;
	    }
	  }
	  /* 
	   * Adjust the BB profile weight because sometimes the weight
	   * initially assigned is wrong. Notice that only do this when
	   * there is no function call up to this point from the beginning 
	   * of the BB.
	   */
	  if ((!func_call_in_bb) && (!bb_prof_is_adjusted)) {
	     if (CurrStmt->profile->count != CurrProfBB->weight) {
	        CurrProfBB->weight = CurrStmt->profile->count;
		out_weight = CurrProfBB->weight;
	     }
	     bb_prof_is_adjusted = TRUE;
	  }

	  if (contain_func_call(CurrStmt->stmtstruct.expr)) {
	     prev_is_func_call = TRUE;
	     func_call_in_bb = TRUE;
	  }
	  break;
	}
      case NT_IfCond:
       {
	if (prev_is_func_call) {
	   if (CurrStmt->profile != NULL) {
	      out_weight = CurrStmt->profile->count;
	      prev_is_func_call = FALSE;
	   }
	}
	if ((CurrStmt->profile->count - CurrStmt->profile->next->count) > 0) {
	   ProfArcPtr = NewProfArc();
	   ProfArcPtr->bb_id = CurrStmt->stmtstruct.ifstmt->then_block->flow
	     ->entry_flow_node->bb->index + 1;
	   ProfArcPtr->condition = 1;
	   ProfArcPtr->weight = CurrStmt->profile->count - 
	                                  CurrStmt->profile->next->count;
	   CurrProfBB->destination = ProfArcPtr;
	}
	if (CurrStmt->profile->next->count > 0) {
	   ProfArcPtr = NewProfArc();
	   ProfArcPtr->condition = 0;
	   ProfArcPtr->weight = CurrStmt->profile->next->count;
	   if (CurrStmt->stmtstruct.ifstmt->else_block) {
	      ProfArcPtr->bb_id = CurrStmt->stmtstruct.ifstmt
		->else_block->flow->entry_flow_node->bb->index + 1;
	   }
	   else {
	     if (CurrStmt->stmtstruct.ifstmt->then_block->flow->entry_flow_node
		== ((FlowNode)CurrStmt->flow->entry_flow_node->succ->ptr))
	        ProfArcPtr->bb_id = ((FlowNode)CurrStmt->flow->entry_flow_node
				     ->succ->next->ptr)->bb->index + 1;
	     else
	        ProfArcPtr->bb_id = ((FlowNode)CurrStmt->flow->entry_flow_node
				     ->succ->ptr)->bb->index + 1;
	   }
	   if (CurrProfBB->destination == NULL)
	      CurrProfBB->destination = ProfArcPtr;
	   else
	      CurrProfBB->destination->next = ProfArcPtr;
	}
        InsideBB = FALSE;
        break;
       }
      case NT_Advance:
      case NT_Await:
       {
	if (prev_is_func_call) {
	   if (CurrStmt->profile != NULL) {
	      out_weight = CurrStmt->profile->count;
	      prev_is_func_call = FALSE;
	   }
	}
        break;
       }
      default:
       {
        Punt("ConvFNQueue_BBProfile: Unimplemented Flow Node Type");
       }
     } 

    PrevFN = CurrFN;
   }
  /* if (InsideBB) 
    fprintf(F, "\t(RETURN) )\n"); */
} 


ExtractBBProfile(Stmt st)
{
  InitFNQueue();
  BuildFNQueue(st);
  ConsolidateFNQueue();
  ConvFNQueue_BBProfile();
}

GenBBProfile(struct _ProfBB *bbprof)
{
  struct _ProfArc *ProfArcPtr;

  fprintf(F, " (PROFILE %f", bbprof->weight);
  ProfArcPtr = bbprof->destination;
  while (ProfArcPtr != NULL) {
    fprintf(F, " (%d %d %f)", ProfArcPtr->bb_id, ProfArcPtr->condition, ProfArcPtr->weight);
    ProfArcPtr = ProfArcPtr->next;
  }
  fprintf(F, ")");
}


/* LCW - scan the function and return the number of the loops in it -3/24/99 */
static int PP_get_loop_number(Stmt st)
{
  int loops_no = 0;
  Stmt StmtIndx;

  if (st == NULL)
     return(0);

  /* reset the ext field for later use */
  st->ext = 0;

  switch(st->type) {
    case ST_CONT:
    case ST_BREAK:
    case ST_RETURN:
    case ST_GOTO:
    case ST_EXPR:
    case ST_ADVANCE:
    case ST_AWAIT:
    case ST_NOOP:
      break;
    case ST_IF:
      loops_no += PP_get_loop_number(st->stmtstruct.ifstmt->then_block);
      loops_no += PP_get_loop_number(st->stmtstruct.ifstmt->else_block);
      break;
    case ST_PSTMT:	
      loops_no += PP_get_loop_number(st->stmtstruct.pstmt->stmt);
      break;
    case ST_MUTEX:
      loops_no += PP_get_loop_number(st->stmtstruct.mutex->statement);
      break;
    case ST_COBEGIN:
      Punt("PP_get_loop_number:  Can't handle cobegin yet");
      break;
    case ST_SWITCH:
      loops_no += PP_get_loop_number(st->stmtstruct.switchstmt->switchbody);
      break;
    case ST_COMPOUND:  
      StmtIndx = st->stmtstruct.compound->stmt_list;
      while(StmtIndx != NULL) {
        loops_no += PP_get_loop_number(StmtIndx);
        StmtIndx = StmtIndx -> lex_next;
      }
      break;
    case ST_PARLOOP:
      StmtIndx = st->stmtstruct.parloop->pstmt->stmt;

      StmtIndx = StmtIndx->stmtstruct.compound->stmt_list;
      while(StmtIndx && StmtIndx->type != ST_BODY && 
	    StmtIndx->type != ST_EPILOGUE) { 
        loops_no += PP_get_loop_number(StmtIndx);
        StmtIndx = StmtIndx->lex_next;
      }

      loops_no += PP_get_loop_number(StmtIndx);

      if (StmtIndx) {
         StmtIndx = StmtIndx->lex_next;
	 while(StmtIndx) { 
	   loops_no += PP_get_loop_number(StmtIndx);
	   StmtIndx = StmtIndx->lex_next;
	 }
      }

      break;
    case ST_SERLOOP:
      loops_no ++;
      switch(st->stmtstruct.serloop->loop_type) {
        case LT_FOR:
        case LT_WHILE:
          loops_no += PP_get_loop_number(st->stmtstruct.serloop->loop_body);
          break;
        case LT_DO:
          loops_no += PP_get_loop_number(st->stmtstruct.serloop->loop_body);
          break;
      }
      break;
    case ST_BODY:
      loops_no += PP_get_loop_number(st->stmtstruct.bodystmt->statement);
      break;
    case ST_EPILOGUE:
      loops_no += PP_get_loop_number(st->stmtstruct.epiloguestmt->statement);
      break;
    default:
      Punt("PP_get_loop_number: Invalid instruction type");
  }

  return(loops_no);
}
