/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	pcode.h
 *	Author:	Nancy Warter and Wen-mei Hwu
 *	Extends ccode.h written by:  Po-hua Chang
\*****************************************************************************/


#ifndef PCODE_H
#define PCODE_H

#include <library/types.h>
#include <library/symbol.h>
#include <library/list.h>


/*===========================================================================*/
/*
 *	Pcode is a statement level representation (whereas hcode is a basic
 *	block representation).  Pcode is organized as a parse tree structure
 *	with three levels of structures: function, statement, and expression.
 *	We assume that functions are processed independently to save memory
 *	space.  
 *
 *	ccode - The only exception is strings, which we never dispose.
 *		User of the internal structure is not allowed to alter
 *		the structure (READ ONLY). However, the extension (ext)
 *		fields are managed by the user, and is not destroyed by
 *		ccode.c
 */
/*===========================================================================*/
/*
 * It may be necessary to modify the following constants to
 * compile larger programs.
 */
#define MAX_STRING_TBL_SIZE	16383
#define MAX_FUNC_TBL_SIZE	4095	/* 7-bits is the most for UNIX-based */
#define MAX_OPCODE_TBL_SIZE	201
#define MAX_TYPEDEF_TBL_SIZE	4095
/* BCC - added for renaming struct names - 10/29/96 */
#define MAX_STRUCT_UNION_POOL_SIZE	1024

#define LOCAL 0
#define GLOBAL 1

extern char *P_parm_file;

/* global scope variable */
extern int max_scope;

/* BCC - flag which indicates if it's doing spliting or not - 7/1/95 */
extern int split;

/* BCC - flag which indicates if it's doing inlining or not - 11/15/95 */
extern int inlining;

/* BCC - flag which indicates if it will do inlining or not - 11/15/95 */
extern int do_inline;

/* TLJ - Current mode for reading include file */
extern int include_mode;

/* TLJ 2/25/96 - counter to indicate how many levels of nesting of include
 * 	files we are at in processing.
 */
extern int include_nesting;

/* TLJ 2/25/96 - array of include files with max include nesting entries */
extern char *include_files[3];

/* TLJ 2/25/96 - Global variables holding current Pcode structure input */
extern struct _StructDcl	*P_Struct;
extern struct _UnionDcl		*P_Union;
extern struct _EnumDcl		*P_Enum;
extern struct _VarDcl		*P_Gvar;	
extern struct _FuncDcl		*P_Func;	
extern char			*P_Include;
extern int P_Input_Type; /* which type is current */

extern int dcl_has_nested_dcls;	/* flag that the outer decl created some 
					other nested declarations */
extern struct _DclList 		*P_DclList;

/*===========================================================================*/
/*
 * Extension.
 * It is desirable to attach additional information to the
 * data structures, which we will define below. In different
 * phases of the compilation process, different sets of
 * extended definitions are necessary. Therefore, we should
 * keep the extension field general. We provide a general
 * purpose pointer to whatever data structures the programmer
 * will define in each phase of the compiler.
 */
typedef Void *Extension;

/*===========================================================================*/
/*
 * Profile records - to be defined at a later point.  Now they are null 
 * structures.  There are two structures required in pcode - one for function
 * and one for statements.
 */
/* LCW - define the following structures for Pcode profiling - 10/23/95 */

/* LCW - copy the following data structures from Hcode for passing the 
	 profiling information to Hcode - 12/23/95 */

typedef struct _ProfFN {
/*  int dummy; */
  int 	fn_id;          /* profile id */
  double count;
  struct _ProfCS  *calls;         /* call sites */
} _ProfFN, *ProfFN;

typedef struct _ProfCS {
        int             call_site_id;   /* call site id */
        int             callee_id;      /* callee id */
        double          weight;         /* invocation count */
        struct _ProfCS  *next;
} _ProfCS, *ProfCS;

typedef struct _ProfBB {
        double          weight;         /* profile weight */
        struct _ProfArc *destination;   /* control transitions */
} _ProfBB, *ProfBB;

typedef struct _ProfArc {
        int             bb_id;          /* destination bb */
        int             condition;      /* branch condition */
        double          weight;         /* profile weight */
        struct _ProfArc *next;
} _ProfArc, *ProfArc;


/* LCW - define the following structures for Pcode profiling - 10/23/95 */

typedef struct _ProfST {
/*  int dummy; */
  double count;
  struct _ProfST *next;
} _ProfST, *ProfST;

typedef struct _ProfEXPR {
  double count;
  struct _ProfEXPR *next;
} _ProfEXPR, *ProfEXPR;

/* TLJ 2/26/96 - created to hold a list of dcls nested within the
 * outer dcl returned by P_get_input(). Also a list of VarDcls created
 * by a FuncDcl.
 */
typedef struct _DclList {
  union _Dcl *dcl;
  int dcl_type;
  struct _DclList *next;
} _DclList, *DclList;

typedef union _Dcl {
	struct _VarDcl		*varDcl;	/* variable declarations */
	struct _StructDcl	*structDcl;	/* struct definitions */
	struct _UnionDcl	*unionDcl;	/* union definitions */
	struct _EnumDcl		*enumDcl;	/* enum definitions */
	struct _FuncDcl		*funcDcl;	/* func definitions */
} _Dcl,*Dcl;

/*===========================================================================*/
/* 
 * Symbol Table Structure.
 * This is based on the symbol table management functions
 * provided by the impact library. 
 * The "type" attribute of Symbol is used to designate
 * one of the below types.
 * For pcode, var, struct, union, and enum are stored in a symbol tree to
 * capture the scoping info.  String, func, and opcode are stored in the
 * regular symbol table structure of library0.
 */
/* Structure Types - these are probably duplicates and not needed (NJW) */
#define TT_VAR          0       /* global variable */
#define TT_STRUCT       1       /* struct tag */
#define TT_UNION        2       /* union tag */
#define TT_ENUM         4       /* enum tag */
#define TT_ENUMFIELD	5	/* enum field tag */
#define TT_FUNC		6	/* func tag (TLJ 2/27/96) */

/* Table type */
#define TBT_FUNC	0	/* function table */
#define TBT_STRING	1       /* string table (used in gen_hcode*/
#define TBT_OPCODE	2	/* opcode table */
#define TBT_TYPEDEF     3       /* typedef table */

typedef union _SymT {
	struct _VarDcl		*varDcl;	/* variable declarations */
	struct _StructDcl	*structDcl;	/* struct definitions */
	struct _UnionDcl	*unionDcl;	/* union definitions */
	struct _EnumDcl		*EnumDcl;	/* enum definitions */
} _SymT, *SymT;

/*
 * The "ptr" attribute of Symbol is used to point to 
 * the below data structure.
 */
typedef struct _Sym {
	struct _FuncDcl		*funcDcl;	/* function definitions */
} _Sym, *Sym;

typedef int SymTable[4];

extern SymTable SymbolTable;	
extern int scope;

/*===========================================================================*/
/* Scope field - doulbe linked list of scope id's
 */
typedef struct _Scope {
	int		id;			/* scope id */
	struct _Scope  *next;
	struct _Scope  *prev;	
} _Scope, *Scope;

/* Link list of _Scope 
 */
typedef struct _ScopeList {
	struct _Scope   *scope;
	struct _ScopeList *next;
	struct _ScopeList *prev;
} _ScopeList, *ScopeList;

/*===========================================================================*/
/* BBID - double linked list of bbid's
 */
typedef struct _BBID {
	int 	bbid;
	int     status;
	struct _BBID *next;
 	struct _BBID *prev;
} _BBID, *BBID;
/*===========================================================================*/
/* Type Specifier. (This is a subset of those used in Csemantic)
 * A type specifier consists of two pieces of information:
 * 1) type : data type and special type properties of the data holder, and
 * 2) dcltr : the access pattern of the data holder.
 * The type attribute can be further broken down to three
 * subfields: (qualifier, class, data_type). To efficiently
 * represent these fields, bit vectors can be used. The meaning
 * of each bit is defined as below:
 */
/* BCC - 7/10/96
 * enumerate these constants. xups can display them in symbolic names 
 */
typedef enum _TypeClassQual {
	/* (qualifier) */
	TY_CONST	=1		/* constant qualifier */,
	TY_VOLATILE	=2		/* volatile qualifier */,
	TY_SYNC		=4		/* sync */,
	/* (class) */
	TY_REGISTER	=8 		/* auto in register */,
	TY_AUTO		=16 		/* auto */,
	TY_STATIC	=32 		/* static */,
	TY_EXTERN	=64 		/* extern */,
	/* (type) */
	TY_VOID		=128 		/* void */,
	TY_CHAR		=256 		/* char */,
	TY_SHORT	=512 		/* short */,
	TY_INT		=1024 		/* int */,
	TY_LONG		=2048 		/* long */,
	TY_FLOAT	=4096 		/* float */,
	TY_DOUBLE	=8192 		/* double */,
	TY_SIGNED	=16384 		/* signed */,
	TY_UNSIGNED	=32768 		/* unsigned */,
	TY_STRUCT	=65536 		/* struct */,
	TY_UNION	=131072		/* union */,
	TY_ENUM		=262144		/* enum */,
	TY_TYPEDEF	=524288		/* typedef */,
	TY_VARARG	=1048576	/* vararg */
} _TypeClassQual;

/* 
 * useful macros 
 */
/* BCC - added TY_VARARG - 1/24/96 */
#define TY_TYPE  (TY_VOID|TY_CHAR|TY_SHORT|TY_INT|TY_LONG|TY_FLOAT|TY_DOUBLE| \
	TY_SIGNED|TY_UNSIGNED|TY_STRUCT|TY_UNION|TY_ENUM|TY_TYPEDEF|TY_VARARG)

/*
** DIA - Changed to handle LONG DOUBLE
*/

#define TY_INTEGRAL \
	(TY_CHAR|TY_SHORT|TY_INT|TY_LONG|TY_SIGNED|TY_UNSIGNED|TY_ENUM)

#define TYPE_INTEGRAL(x) \
        (((TY_CHAR|TY_SHORT|TY_INT|TY_SIGNED|TY_UNSIGNED|TY_ENUM) & (x)) || \
        ((TY_LONG & (x)) && !((TY_FLOAT|TY_DOUBLE) & (x))))

#define TY_REAL (TY_FLOAT|TY_DOUBLE|TY_LONG)

#define TYPE_REAL(x) \
        (((TY_FLOAT|TY_DOUBLE) & (x)) && !TYPE_INTEGRAL((x)))

#define TY_ARITHMETIC	(TY_INTEGRAL | TY_REAL)

#define TY_STRUCTURE (TY_UNION|TY_STRUCT)

/*
 * For TY_STRUCT, TY_UNION, and TY_ENUM, another field is
 * required to specify the structure. The simplest way
 * is to remember the name of the structure. When we
 * are required to know the structure information, we
 * can use the name to index into the symbol table.
 * This may be less time efficient than remembering
 * the location of the struture definition, and save
 * the symbol table lookup. However, I trust that the
 * symbol table hashing scheme is good, and it is better
 * to keep the data structures independent of each other
 * to simplify the debugging (shorter pointer chains).
 */
typedef struct _Type {
	_TypeClassQual	type;		/* type bit_vector */
	char		*struct_name;	/* structure name (struct/union/enum) */
	struct _Dcltr	*dcltr;		/* access pattern */
} _Type, *Type;

/*
 * The access pattern is a list of access declarators.
 * The actions are specified from the beginning of the
 * list to the end of the list. For example, (F, P) means
 * that it is a function which returns a pointer.
 * There are three types of access declarators:
 * 1: array index?
 * 2: pointer qualifier*
 * 3: function qualifier*
 * The index field of the array declarator is optional. When
 * defined, it specifies the dimension of the array. If not
 * defined, the array declarator acts very much like a pointer.
 * The index field is an expression, which may not be as simple as
 * a constant number. Therefore, we must use the Expr structure.
 * The qualifier bit field represents optional ANSI qualifiers for pointers 
 * and optional calling convention qualifiers for functions.
 */

/* accessing method */
/* BCC - 7/10/96
 * enumerate these constants. xups can display them in symbolic names
 */
typedef enum _AccessMethod {
	D_ARRY	=1	/* array access */,
	D_PTR	=2	/* pointer access */,
	D_FUNC	=3	/* function call */
} _AccessMethod;

/* declarator qualifier bits */
/* BCC - 7/10/96
 * enumerate these constants. xups can display them in symbolic names
 */
typedef enum _Qualifier {
	DQ_CONST	=1	/* constant qualifier (for D_PTR) */,
	DQ_VOLATILE	=2	/* volatile qualifier (for D_PTR) */,
	DQ_CDECL	=4	/* Visual C call convention (for D_FUNC) */,
	DQ_STDCALL	=8	/* Visual C call convention (for D_FUNC) */,
	DQ_FASTCALL	=16	/* Visual C call convention (for D_FUNC) */
} _Qualifier;

typedef struct _Dcltr {
	_AccessMethod		method;		/* accessing method */
	struct _Expr		*index;		/* array index */
	struct _Param		*param;	        /*BCC-parameters list 1/20/96*/
	struct _Dcltr		*next;		/* next accessing declarator */
	_Qualifier		qualifier;	/* declarator qualifiers */
} _Dcltr, *Dcltr;

/*
 * BCC - 1/20/96
 * To hole the formal parameters list to a function prototype, we added this
 * struct which is embedded within _Dcltr
 */

typedef struct _Param {
	struct _Type		*type;
	struct _Param 		*next;
} _Param, *Param;

/*===========================================================================*/
/*
 * Initializer.
 * Variables (not just global) can be initialized by aggregate initializer.
 * Multiple level of aggregate initialization can occur. The simplest
 * case is when it is just a simple expression.
 * When it is a simple expression, the set field is set to 0.
 * When it is an aggregate initializer, the expr field is set to 0.
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the _Init
 * data structure.
 */
typedef struct _Init {
	struct _Expr	*expr;		/* expression */
	struct _Init	*set;		/* { ... } */
	struct _Init	*next;		/* next token in the set */
	Extension	ext;		/* extension field */
} _Init, *Init;

/*===========================================================================*/
/* 
 * Variable Definition.
 * A variable definition consists of the following fields:
 * 1: variable name,
 * 2: variable type, and
 * 3: initializer (for global and local variables)
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the _VarDcl
 * data structure.
 */
typedef struct _VarDcl {
	char		*name;		/* variable name */
	char		*new_name;	/* name after renaming */
	struct _Type	*type;		/* variable type */
	struct _Init	*init;		/* data initialization */
	int		lineno;		/* line number */
	int 		colno;		/* column number */
 	char		*filename;	/* filename */
	struct __Pragma	*pragma;	/* pragma specifiers */
	Extension	ext;		/* extension field */
} _VarDcl, *VarDcl;


/*===========================================================================*/
/* 
 * Type Definition
 *
 */
typedef struct _TypeDcl {
	char		*name;		/* identification */
	struct _Type	*type;		/* type of definition */
	int		lineno;		/* line number */
	int		colno;		/* column number */
	char		*filename;	/* filename */
	Extension	ext;		/* extension field */
} _TypeDcl, *TypeDcl;

/*===========================================================================*/
/*
 * Struct/Union Definition.
 * Struct and union declarations are very much alike. 
 * Each has the following attributes:
 * 1: its name, and
 * 2: its fields.
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to these
 * data structures.
 */
typedef struct _StructDcl {
	char		*name;		/* identification */
	char		*new_name;	/* name after renaming */
	struct _Field	*fields;	/* field definition */
	int		lineno;		/* line number */
	int 		colno;		/* column number */
 	char		*filename;	/* filename */
	int 		size;		/* BCC - struct size - 2/17/97 */
	int		align;		/* BCC - first element alignment */
	Extension	ext;		/* extension field */
} _StructDcl, *StructDcl;

typedef struct _UnionDcl {
	char		*name;		/* identification */
	char		*new_name;	/* name after renaming */
	struct _Field	*fields;	/* field definition */
	int		lineno;		/* line number */
	int 		colno;		/* column number */
 	char		*filename;	/* filename */
	int 		size;		/* BCC - union size - 2/17/97 */
	int		align;		/* BCC - first element alignment */
	Extension	ext;		/* extension field */
} _UnionDcl, *UnionDcl;
/*
 * Each field of the above structures consists of several subattributes:
 * 1: name of the field,
 * 2: type declaration,
 * 3: bit_field, and
 * 4: a link to the next field.
 * The bit_field attribute specifies the number of bits of this field.
 * This allows the user to pack fields tightly together to reduce data
 * space requirement. The bit_field attribute is a constant expression,
 * which can be expressed by using the Expr data structure. It is not
 * sufficient to use an integer to represent bit_field because of 
 * sizeof() and enum constants in C.
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the
 * data structures.
 */
typedef struct _Field {
	char		*name;		/* name of the field */
	struct _Type	*type;		/* field type */
	struct _Expr	*bit_field;	/* number of bits */
	struct _Field	*next;		/* next field */
	int offset;			/* BCC - offset - 2/17/97 */
	int size;			/* BCC - size - 2/17/97 */
	Extension	ext;		/* extension field */
} _Field, *Field;

/*===========================================================================*/
/* 
 * Enumeration Type.
 * Enum structure is a fairly simple data structure which
 * has a name and a list of enum constants. Each enum
 * constant has a name and a value attribute. The value
 * attribute is assigned by the compiler. 
 */

    /* for enums, value of fields starts at 0, unless overriden */
#define BASE_ENUM_VALUE 0


typedef struct _EnumDcl {
	char			*name;		/* identification */
	char			*new_name;	/* name after renaming */
	struct _EnumField	*fields;	/* fields */
	int		        lineno;		/* line number */
	int 		        colno;		/* column number */
 	char		        *filename;	/* filename */
	Extension 		ext;		/* extension field */
} _EnumDcl, *EnumDcl;

typedef struct _EnumField {
	char			*name;		/* name of field */
	char			*new_name;	/* name after renaming */
	struct _Expr		*value;		/* constant value */
	struct _EnumField	*next;		/* next enum field */
} _EnumField, *EnumField;

/*===========================================================================*/
/*
 * Function Definition.
 * A function is a special construct which allows a
 * programmer to generalize a computation model and
 * to tailor a particular computation by passing
 * to a function appropriate parameters.
 * The following fields are defined for a function:
 * 1: name of the function,
 * 2: the return type,
 * 3: the parameter list,
 * 4: variable definitions within the function scope,
 * 5: pointer to the statement (compound)
 * 6: pragma
 * 7: profile
 * 8: pointer to first parallel loop
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the
 * data structures.
 */
typedef struct _FuncDcl {
	char		*name;		/* the name of function */
	struct _Type	*type;		/* return type */
	int		lineno;		/* line number */
	int 		colno;		/* column number */
 	char		*filename;	/* filename */
	struct _VarList	*param;		/* parameter definition */
	struct _Stmt 	*stmt;		/* ptr to function compound stmt */
	struct __Pragma	*pragma;	/* pragma specifiers */
	struct _ProfFN	*profile;	/* profile information */
 	struct _Stmt    *par_loop;	/* pointer to first parallel loop */
	struct _FuncFlow *flow;      	/* pointer to flow information */
	struct _FuncDepend *depend;	/* pointer to dependence information */
	Extension	ext;		/* extension field */
} _FuncDcl, *FuncDcl;

extern FuncDcl	currentFuncDcl;		/* pcode.c */
extern FuncDcl  calleeFuncDcl;          /* BCC - added for Pinline - 11/12/95 */

/*
 * A variable list is a list of variable names. The actual
 * definition of these variables can be obtained by accessing
 * the variable symbol table. To eliminate unncessary accessed,
 * a special pointer is provided to store the location of the
 * corresponding symbol table entry. However, this pointer must
 * be used with extreme care, because it is difficult to keep
 * track when it is valid. When it is not valid, it is set to 0.
 * Thereforem it is recommanded that it is checked against 0 before
 * it is used.
 */
typedef struct _VarList {
	char		*name;		/* name of the variable */
	struct _VarDcl	*var;		/* variable definition */
	struct _VarList	*next;		/* next variable */
} _VarList, *VarList;


/* 
 * Compound statement = locally defined (can be global) variables and the
 * 		       a list of stmts.
 */
typedef struct _Compound {
	struct _Stmt	*stmt_list;	/* ptr to stmt list */
	struct _VarList	*var_list;	/* variable list of compound */
	int             scope;          /* scope */
} _Compound, *Compound;

/*
 * If statement = if statment with conditional expression, then block and
 *		  and else block;
 */
typedef struct _IfStmt {
	struct _Expr	*cond_expr;	/* conditional expression */
	struct _Stmt	*then_block;	/* then block */
	struct _Stmt	*else_block;	/* else block */
} _IfStmt, *IfStmt;

/*
 * Switch statement = expression, switch body
 */
typedef struct _SwitchStmt {
	struct _Expr 	*expression;	/* expression of switch */
 	struct _Stmt	*switchbody;    /* ptr to switch body */
} _SwitchStmt, *SwitchStmt;

/*
 * P_Stmt statement = a stmt.  Extension field for any additional info
 * 		      that may want to keep for a p_stmt (such as list of
 *		      variables passed.
 */
typedef struct _Pstmt {
 	struct _Stmt	*stmt;		/* statement of pstmt */
	int lineno;                     /* moved these from dopstmt to here */
	int colno;
	char *filename;
	Extension	ext;		/* extension field */
} _Pstmt, *Pstmt;

/*
 * Advance = marker
 */
typedef struct _Advance {
	int	marker;			/* marker of advance/await pair */
} _Advance, *Advance;

/*
 * Await = marker, distance 
 */
typedef struct _Await {
	int 	marker;			/* marker of advance/await pair */
	int  	distance;		/* distance to wait for */
} _Await, *Await;	

/* 
 * Mutex = expression, statement  (expression should be simple)
 */
typedef struct _Mutex {
	struct _Expr	*expression;	/* expression of mutex */
	struct _Stmt	*statement;	/* statement of mutex */
} _Mutex, *Mutex;

/*
 * Cobegin = list of statements
 */
typedef struct _Cobegin {
	struct _Stmt	*statements;	/* list of statements */
} _Cobegin, *Cobegin;

/*
 * DoPstmt = local var decl, prologue stmt list, body stmt, epilogue stmt list,
 * 	     ext (can be used to point to variables that must be passed into
 *	     the pstmt).  The local variable declarations are actually in
 *	     the prologue when code is generated.  Local variables to the
 *	     loop body only can be placed in the compound stmt of body.
 *
 * Make prologue, body, and epilogue pstmts since when do check - each has
 * to be one.
 */

typedef struct _BodyStmt {
        struct _Stmt    *statement;      /* loop body stmt */
} _BodyStmt, *BodyStmt;

typedef struct _EpilogueStmt {
        struct _Stmt    *statement;      /* loop epilogue stmt */
} _EpilogueStmt, *EpilogueStmt;
		
/* 3/93 - remove dopstmt from internal representation but keep in grammar
   typedef struct _DoPstmt {
   struct _Pstmt  	*prologue;
   int lineno;
   int colno;
   char *filename;
   Extension	ext;
   } _DoPstmt, *DoPstmt;
   */

/* parallel loop types */
/* BCC - 7/10/96
 * enumerate these constants. xups can display them in symbolic names
 */
typedef enum _ParLoopType {
	LT_DOALL	=1,
	LT_DOACROSS	=2,
	LT_DOSERIAL	=3,
	LT_DOSUPER	=4
} _ParLoopType;

/*
 * ParLoop = loop type, loop body, iteration var, next par_loop stmt, loop 
 *	     prologue, loop epilogue, init value expression, final value 
 *	     expression, increment expression
 */
typedef struct _ParLoop {
	_ParLoopType	loop_type;		/* what type of parallel loop */
	struct _Pstmt   *pstmt;
	struct _Expr    *iteration_var; /* pointer to iteration variable */
	struct _Stmt	*sibling;	/* ptr to sibling at same level */
	struct _Expr	*init_value;	/* initial value expression */
	struct _Expr 	*final_value;	/* final value expression */
	struct _Expr	*incr_value;	/* increment expression */
	struct _Stmt    *child;         /* Linked list of all children */
	struct _Stmt    *parent;        /* Pointer to the parent, if any */
	unsigned int 	depth;		/* loop's nesting depth (Used in DD) */
} _ParLoop, *ParLoop;

/* serial loop types */
/* BCC - 7/10/96
 * enumerate these constants. xups can display them in symbolic names
 */
typedef enum _SerLoopType {
	LT_WHILE	=1,
	LT_FOR		=2,
	LT_DO		=3
} _SerLoopType;

/*
 * SerLoop = loop type, loop body, conditional expression of loop(while/for/do)
 * 	     initial expression (for), iterative expression(for)
 */
typedef struct _SerLoop {
	_SerLoopType	loop_type;	/* what type of serial loop */
	struct _Stmt	*loop_body;	/* pointer to loop body */
	struct _Expr	*cond_expr;	/* conditional expression */
	struct _Expr	*init_expr;	/* initial expression */
	struct _Expr 	*iter_expr;	/* iterative expression */
} _SerLoop, *SerLoop;

/* statement types */
/* BCC - 7/10/96
 * enumerate these constants. xups can display them in symbolic names
 */
typedef enum _StmtType {
	ST_NOOP		=1,
	ST_CONT		=2,
	ST_BREAK	=3,
	ST_RETURN	=4,
	ST_GOTO		=5,
	ST_COMPOUND	=6,
	ST_IF		=7,
	ST_SWITCH	=8,
	ST_PSTMT	=9,
	ST_ADVANCE	=10,
	ST_AWAIT	=11,
	ST_MUTEX	=12,
	ST_COBEGIN	=13,
	ST_PARLOOP	=14,
	ST_SERLOOP	=15,
	ST_EXPR		=16,
	ST_BODY         =17,   
	ST_EPILOGUE     =18
} _StmtType;

/* BCC - 7/10/96
 * enumerate these constants. xups can display them in symbolic names
 */
typedef enum _LabelType {
	LB_LABEL        =1,
	LB_CASE	        =2,
	LB_DEFAULT	=3
} _LabelType;

typedef struct _Label {
	char *val;
	_LabelType type;
	struct _Expr 	*expression;	/* expression of case */
 	struct _Label 	*next;
	struct _Label 	*prev;
}_Label, *Label;

/* 
 * The Stmt structure is generic for all statments.  The StmtStruct defines
 * the specific structure.
 * Statement structures:
 *	simple: noop, cont, break;
 *	pointer: return, goto, label
 *      structure: compound, if, switch, case, default, pstmt, advance, await,
 *		   mutex, cobegin, parloop, serloop.
 *
 */
typedef struct _Stmt {
	_StmtType	type;		/* type of statement */
	int		status;		/* flags for marking statements - GEH */
	int		lineno;		/* line number */
	int 		colno;		/* column number */
 	char		*filename;	/* filename */
	struct _ProfST	*profile;	/* profile information */
	struct __Pragma  *pragma;	/* pragma specifiers*/
	struct _Stmt	*lex_prev;	/* lexically previous stmt */
	struct _Stmt	*lex_next;	/* lexically next stmt */
	struct _Label 	*labels;	/* list of label of type */
					/* label, case, and default */ 
	union {
		struct _Expr *ret;	/* for return - ptr to expressions */
		char	*label;		/* goto label */
		struct _Compound *compound; /* pointer to compound struct */
		struct _IfStmt *ifstmt;	/* ptr to if struct */
		struct _SwitchStmt *switchstmt; /* ptr to switch struct */
		struct _Pstmt	*pstmt;	/* ptr to pstmt struct */
		struct _Advance *advance; /* ptr to advance struct */
		struct _Await *await;	/* ptr to await struct */
		struct _Mutex *mutex;	/* ptr to mutex struct */
		struct _Cobegin *cobegin; /* ptr to cobegin struct */
		struct _ParLoop *parloop; /* ptr to parallel loop struct */
		struct _SerLoop *serloop; /* ptr to serial loop struct */
		struct _Expr *expr; /* ptr to expression stmt */
		/* 1/2/92 */
		struct _BodyStmt *bodystmt; /* ptr to body of loop stmt */
		struct _EpilogueStmt *epiloguestmt; /* ptr to loop epilogue */
	} stmtstruct;
	struct _Stmt	*parent;	/* parent of statement */
	struct _StmtFlow *flow;         /* pointer to flow information */
	Extension	ext;		/* extension field */
} _Stmt, *Stmt;

extern Stmt currentStmt;		/* pcode.c */

/*
 * Predefined opcodes.
 */
/* BCC - 7/10/96
 * enumerate these constants. xups can display them in symbolic names
 */
typedef enum _Opcode {
	OP_var		=1,
	OP_enum		=2,
	OP_int		=3,
	OP_real		=4,
	OP_error	=5,	/* don't know what error used for */
	OP_char		=6,
	OP_string	=7,
	OP_dot		=8,
	OP_arrow	=9,
	OP_cast		=10,
	OP_expr_size	=11,
	OP_type_size	=12,
	OP_quest	=13,
	OP_disj		=14,
	OP_conj		=15,
	OP_compexpr	=16,
	OP_assign	=17,
	OP_or		=18,
	OP_xor		=19,
	OP_and		=20,
	OP_eq		=21,
	OP_ne		=22,
	OP_lt		=23,
	OP_le		=24,
	OP_ge		=25,
	OP_gt		=26,
	OP_rshft	=27,
	OP_lshft	=28,
	OP_add		=29,
	OP_sub		=30,
	OP_mul		=31,
	OP_div		=32,
	OP_mod		=33,
	OP_neg		=34,
	OP_not		=35,
	OP_inv		=36,
/*
       	--- no 37 
*/	
	OP_preinc	=38,
	OP_predec	=39,
	OP_postinc	=40,
	OP_postdec	=41,
	OP_Aadd		=42,
	OP_Asub		=43,
	OP_Amul		=44,
	OP_Adiv		=45,
	OP_Amod		=46,
	OP_Arshft	=47,
	OP_Alshft	=48,
	OP_Aand		=49,
	OP_Aor		=50,
	OP_Axor		=51,
	OP_indr		=52,
	OP_addr		=53,
	OP_index	=54,
	OP_call		=55,
	/* BCC - added to distinguish float and double constants */
	OP_float	=56,
	OP_double	=57,
} _Opcode;


/*===========================================================================*/
/* Expression.
 * A status field is provided for storing temporary information
 * in computations on expressions. The opcode field is an integer
 * because integer comparison is much faster than string comparison.
 * We need another table to map the name of opcode to a unique
 * integer value, including pre-defined operators.
 * The type field specifies the type of the result of the expression.
 * If the expression is a primary type, the value field specifies
 * its value. The sibling field is used to link all operands together.
 * The parent and the child pointers connect all expressions in a
 * basic block together. A parent expression is executed before a
 * child expression.
 * Finally, a special extension field is defined, so when computation is
 * necessary, additional information can be attached to the
 * data structures.
 *
 * Add field to indicate that a var is actually an enum (would use
 * and existing field s.a. status or ext but may be modified during
 * expression reduction or other expression calcs).
 */
typedef struct _Expr {
	int		status;			/* status */
	_Opcode		opcode;			/* opcode */
	int		enum_flag;		/* enum flag=1 if var is enum*/
	struct _Type	*type;			/* result type */
	union {
		long		scalar;		/* signed scalar value */
		unsigned long	uscalar;	/* unsigned scalar value */
		double		real;		/* floating point value */
		char		*string;	/* string/char/enum literal */
		char		*var_name;	/* name of variable */
		struct _Type	*type;		/* type_size/cast */
	} value;
	struct _Expr	*sibling, *operands;	/* operands */
	struct _Expr    *parentexpr;            /* parent expr, if any */
	struct _Stmt    *parentstmt;            /* parent stmt */
	struct _Expr	*next, *previous;	/* expression links */
	struct __Pragma	*pragma;		/* pragma */
	struct _ProfEXPR *profile;		/* LCW - profile info */
	Extension	ext;			/* extension field */
	Extension	ext2;			/* second extension field */
	struct _a_access *acc;			/* acc tbl entry */
	struct _a_access *acc2;			/* second acc tbl entry */
} _Expr, *Expr;

/*===========================================================================*/

/*
 * Predefined status bits
 */
#define STAT_VISITED    1<<0 /* status bit of expr marked when visiting expr */

/*===========================================================================*/
/*
 * Pragma specification 
 */
typedef struct __Pragma {
	char *specifier;	/* the specifier is is string */
	struct _Expr  *expr;	/* exressions of pragma */
	int lineno;		/* line number */
	int colno;		/* column number */
	char *filename;		/* filename */
	struct __Pragma *next;	/* a link to the next specifier */
} __Pragma, *Pragma;

/*===========================================================================*/
/* 
 * use extension field in stmts to hold bbid's when convert to hcode
 */
typedef struct _BBExt {
	int bbid;
} _BBExt, *BBExt;
/*===========================================================================*/

/* BCC - added StructDcl pool for renaming structs - 7/3/96 */
typedef struct _StructUnionPoolElem {
        enum _TypeClassQual	type;
	union {
	    struct _StructDcl	*st;
	    struct _UnionDcl	*un;
	} ptr;
	struct _StructUnionPoolElem	*next;
} _StructUnionPoolElem, *StructUnionPoolElem;

typedef struct _StructUnionPool {
	char 			*name;
	char 			*new_name;
	struct _StructUnionPoolElem	*elem;
} _StructUnionPool, *StructUnionPool; 

#endif

/* external functions */

extern void ClearSymbolTable(); 

/*
 * At top level, only struct defs, enum defs, union defs, global var defs,
 * functions.  Pragmas are already part of pcode.
 *
 * Since a function is a list (has a left and right paren) GetNode() will
 * get the entire function.  This may be changed later (by removing the
 * left and right paren's) if there is a memory problem with reading in the
 * entire function.  However, don't gain much because compoundstmt is also
 * a list.
 */

extern void ProcessList(LIST list);

extern Expr Expression (LIST list);

extern int label_mapping_table;	  /* BCC - a hash table for Pinline 12/11/95 */

extern long BodySize, StackSize;      /* BCC - funcinfo for Pinline 12/16/95 */

/* BCC - entry point from Pcode to Pinline to inline a function - 12/17/95 */
extern void (*ExpandCalleeFunction)(FuncDcl);	

/* BCC - entry point from Pcode to Pinline to annotate expressions - 12/17/95 */
extern void (*PreprocessFunction)(FuncDcl, int);

/* BCC - flag for annotate call through pointers - 12/17/95 */
extern int do_annotate_function;

/* BCC - take out discount from profile weight - 12/19/95 */
extern double in_fraction, out_fraction;

/* LCW - next available function id # - 5/10/96 */
extern int next_fn_id;

#define MAX_LABEL_LEVEL	1024
extern int label_scope_stack[MAX_LABEL_LEVEL];
extern int label_scope_index;

/* BCC - count the number of struct.pch and extern.pch encountered - 7/13/96 */
extern int struct_count, extern_count;

/* BCC - counter of elements in the renaming structure pool - 7/26/96 */
extern int max_struct_union_pool;
extern int new_struct_union_created;
extern int SUE_counter;
extern _StructUnionPool StructUnion_Pool[];

/* BCC - flag for using the newest struct/union name - 7/26/96 */
extern int update_st_un_name;

/* BCC - flag to enable structure renaming - 7/29/96 */
extern int rename_struct;
extern int struct_T_name_table;

/* BCC - flag to indicate if using the EDG frontend - 8/2/96 */
extern int edg_generated;

/* BCC - output format set by Psplit - 10/22/96 */
extern char *sp_output_format_string; 
