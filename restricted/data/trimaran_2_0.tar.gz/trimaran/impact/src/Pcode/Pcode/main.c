/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.30  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 14, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/

/*****************************************************************************\
 *	File:	main.c
 *	Author:	Pohua Chang and Wen-mei Hwu
\*****************************************************************************/


#include <sys/time.h>
#ifndef __WIN32__
#include <sys/resource.h>
#endif
#include <Pcode/impact_global.h>
#include <Pcode/main.h>
#include <library/l_parms.h>
#include <Pcode/parms.h>

extern char *P_parm_file;

/* Here is the dummy main program. */	
main(argc, argv, envp)
int argc;
char** argv;
char** envp;
{
	char *prog_name;		/* program name */
	int err, i;
	Parm_Macro_List *external_list;

	/* get program arguments */
	prog_name = *argv;

        /* Initialize global file pointers here instead of statically.  This is
         * to make Pcode compatible with gcc version egcs-2.91.66 - JCG 6/99 
         */
        Fin = stdin;
        Fout = stdout;
        Fout2 = stdout;
        Ferr = stderr;
        Flog = stderr;
        Fstpcode = stderr;
        Fannot = stdin;
        Fannot_index = stdin;
        Fpcode_position = stdout;
        
       

	/* GEH - added parameter stuff */

    	/*
    	 * Get macro definitions from command line and environment.
    	 * This is the updated version of command_line_macro_list,
    	 * any it may be used in the same way.
    	 */
    	external_list = L_create_external_macro_list (argv, envp);

	P_parm_file = L_get_std_parm_name(argv, envp, "STD_PARMS_FILE", 
					  "./STD_PARMS");

        L_load_parameters(P_parm_file, external_list,
			  "(Pcode", P_read_parm_Pcode);

	/* BCC/ITI - 2/10/99 */
	if (resolve_machine_dependent_information) {
	    /* BCC - in order to invode Mspec, so needs to 
	     * know $arch and $model - 6/12/95
	     */
	    /* Renamed 'architecture' to 'Larchitecture' -JCG 5/26/98 */
	    L_load_parameters_aliased (P_parm_file, external_list,
				       "(Larchitecture", "(architecture", 
				       P_read_parm_arch);
	    
	    /* BCC - now set the machine related information - 6/12/95 */
	    M_set_machine(P_arch, P_model);
	    
	    /* BCC - then get the size of each integer type - 6/12/95 */
	    P_GetIntegerSize();
	}

/********************************************************************/
/* TLJ 2/27/96 - moved this here from SetUpEnvironment since it is
 *	not module-specific.
 */

    if (!strcmp(output_format_string, "Hcode")) {
        output_form = OUTPUT_HCODE;
        F_output = F_hcode_output;
    }
    else if (!strcmp(output_format_string, "Pcode")) {
        output_form = OUTPUT_PCODE;
        F_output = F_pcode_output;
    }
    else if (!strcmp(output_format_string, "None")) {
        output_form = OUTPUT_NONE;
        F_output = "stdout";
    }
    /* BCC - 10/7/96 */
    else if (!strcmp(output_format_string, "nm")) {
        output_form = OUTPUT_NM;
        F_output = F_nm_output;
    }
    else {
        fprintf(Ferr, "Error, Illegal output file format: %s\n",
                 output_format_string);
        exit(-1);
    }

    /* Process arguments, ignore parameter stuff */

    for (i=1; i<argc; i++) {
        if (argv[i][0] != '-') {
            fprintf(Ferr, "Error, unknown Pcode option: %s\n", argv[i]);
            exit(-1);
        }
        switch (argv[i][1]) {
            case '\0':
                fprintf(Ferr,"Error, missing option specifier: %s\n",argv[i]);
                exit(-1);
                break;
            case 'i':
            case 'o':
            case 'e':
            case 'p':
                if (argv[i][2] != '\0') {
                    fprintf(Ferr,"Error, unknown Pcode option: %s\n",argv[i]);
                    exit(-1);
                }
                if (i+1 >= argc) {
                    fprintf(Ferr, "Error, filename for option: %s\n",argv[i]);
                    exit(-1);
                }
                if (argv[i][1] == 'i') F_input = argv[i+1];
                if (argv[i][1] == 'o') F_output = argv[i+1];
                if (argv[i][1] == 'e') F_error = argv[i+1];
                i+=1;   /* move forward to next option */
                break;
            case 'P':
            case 'F':
                break;
            default:
                fprintf(Ferr, "Error, unknown Pcode option: %s\n", argv[i]);
                exit(-1);
        }
    }
    /* Open error, input, output, and log files */
    if (strcmp(F_error, "stderr")) {
        Ferr = fopen(F_error, "w");
        if (Ferr==NULL) {
            fprintf(Ferr, "Error, cannot open error file: %s\n", F_error);
            exit(-1);
        }
    }

    if (strcmp(F_input, "stdin")) {
        Fin = fopen(F_input, "r");
        if (Fin==NULL) {
            fprintf(Ferr, "Error, cannot open input file: %s\n", F_input);
            exit(-1);
        }
    }

    if (strcmp(F_output, "stdout")) {
        Fout = fopen(F_output, "w");
        if (Fout==NULL) {
            fprintf(Ferr, "Error, cannot open output file: %s\n", F_output);
            exit(-1);
        }
    }

    if ((verbose_yes || debug_yes) && strcmp(F_log, "stderr")) {
        Flog = fopen(F_log, "w");
        if (Flog==NULL) {
            fprintf(Ferr, "Error, cannot open log file: %s\n", F_log);
            exit(-1);
        }
    }
/********************************************************************/
/* TLJ 2/27/96 - moved this here from P_gen_code (was main2) since it is
 *	not module-specific.
 */
    /* Open input file */
    err = (lexOpen(F_input, 0)==0);
    if (err) Punt("can not open input file");
/********************************************************************/

#ifndef __WIN32__
/* ADA 5/29/96: Win95/NT has diffenent way to change priority but IMPACT
   		module running on Win95/NT doesn't really care about it */
	setpriority(PRIO_PROCESS, 0, pcode_nice_value);
#endif
	/* call user program */
        P_gen_code(prog_name, external_list);

/********************************************************************/
/* TLJ 2/27/96 - moved this here from P_gen_code (was main2) since it is
 *	not module-specific.
 */
    /* Close input file */
    lexClose(F_input);
/********************************************************************/

        /*
	 * Print warning about unused command line parameter arguments 
	 */
        L_warn_about_unused_macros (stderr, external_list);

        /* DIA - For Makefile friendliness */
	exit (0);
}
