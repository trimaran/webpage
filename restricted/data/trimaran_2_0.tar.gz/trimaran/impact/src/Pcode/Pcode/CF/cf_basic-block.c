/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	cf_basic-block.c
 *	Author: Grant Haab and Wen-mei Hwu
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <library/llist.h>
#include <Pcode/flow.h>
#include <Pcode/cf_basic-block.h>
#include <Pcode/pcode.h>
#include <Pcode/parms.h>

/* forward declarations */


static Punt(mesg, stmt)
char *mesg;
Stmt stmt;
{
    if (stmt != 0) {
	fprintf(Ferr, "# cf_basic-block: %s in file %s on line %u\n", mesg,
		stmt->filename, stmt->lineno);
    }
    else {
	fprintf(Ferr, "# cf_basic-block: %s\n", mesg);
    }
    exit(-1);
}

void CF_Print_Basic_Blocks(FILE *file, FuncDcl func, bool flownodes)
{
    int bb_num;
    FlowNode ffn, fn;
    BBNode bbn;
    Lptr pred, succ, flows;
    BBGraph bb_graph;
    FlowGraph flow_graph;

    assert(func != NIL);
    assert((flow_graph = func->flow->flow_graph) != NIL);
    assert(flow_graph->has_bbs);
    assert((bb_graph = flow_graph->bb_graph) != NIL);

    fprintf(file, "....Printing Basic Blocks:\n");

    for (bb_num = 0; bb_num < bb_graph->num_nodes; bb_num++) {
	bbn = (BBNode) bb_graph->bb_node[bb_num];
        ffn = (FlowNode) bbn->flows->ptr;

	if (ffn->type == NT_FuncExit || ffn->type == NT_FuncEntry) {
	    fprintf(file, "      (bb %d %s(%s) ", bb_num, 
		    NodeTypeNames[ffn->type], ffn->pcode_ptr.func->name);
	}
	else{
	    fprintf(file, "      (bb %d %s(#%d) ", bb_num, 
		    NodeTypeNames[ffn->type], ffn->pcode_ptr.stmt->lineno);
	}

	fprintf(file, "(pred_bb");
	for (pred = bbn->pred; pred != NIL; pred = pred->next) {
	    fprintf(file, " %d", ((BBNode)pred->ptr)->index);
	}
	fprintf(file, ") (succ_bb");
	for (succ = bbn->succ; succ != NIL; succ = succ->next) {
	    fprintf(file, " %d", ((BBNode)succ->ptr)->index);
	}
	fprintf(file, "))\n");

	for (flows = bbn->flows; flownodes && (flows!=NIL); flows=flows->next){
	    fn = (FlowNode) flows->ptr;

	    if (fn->type == NT_FuncExit || fn->type == NT_FuncEntry) {
		fprintf(file, "        (fn %d %s(%s) ", fn->order, 
			NodeTypeNames[fn->type], fn->pcode_ptr.func->name);
	    }
	    else{
		fprintf(file, "        (fn %d %s(#%d) ", fn->order, 
			NodeTypeNames[fn->type], fn->pcode_ptr.stmt->lineno);
	    }

	    fprintf(file, "(pred_fn");
	    for (pred = fn->pred; pred != NIL; pred = pred->next) {
		fprintf(file, " %d.%d", ((FlowNode)pred->ptr)->bb->index,
			((FlowNode)pred->ptr)->order);
	    }
	    fprintf(file, ") (succ_fn");
	    for (succ = fn->succ; succ != NIL; succ = succ->next) {
		fprintf(file, " %d.%d", ((FlowNode)succ->ptr)->bb->index,
			((FlowNode)succ->ptr)->order);
	    }
	    fprintf(file, "))\n");

	}
    }
}
/* BCC - put BBs into the array in ascending order - 7/10/96 */

static void DFS_BB_Graph(bbn, num_bbs, num_lbbs)
BBNode bbn;
int *num_bbs, *num_lbbs;
{
    Lptr succ;
    BBNode succ_bb;

    SET_BB_NODE_FLAGS(bbn, BBNODE_VISITED);

    bb_graph->bb_node[(*num_bbs)] = bbn;
    if (FindFlowNodeDepth((FlowNode)bbn->flows->ptr) > 0)
	bb_graph->loop_bbs[(*num_lbbs)++] = bbn;
    bbn->index = (*num_bbs)++;

    for (succ = bbn->succ; succ != NIL; succ = succ->next) {
	succ_bb = (BBNode) succ->ptr;

	if (!IS_BB_NODE_FLAG_SET(succ_bb, BBNODE_VISITED)) 
	    DFS_BB_Graph(succ_bb, num_bbs, num_lbbs);
    }
}

#if 0	
static void DFS_BB_Graph(bbn, num_bbs, num_lbbs)
BBNode bbn;
int *num_bbs, *num_lbbs;
{
    Lptr succ;
    BBNode succ_bb;

    SET_BB_NODE_FLAGS(bbn, BBNODE_VISITED);

    for (succ = bbn->succ; succ != NIL; succ = succ->next) {
	succ_bb = (BBNode) succ->ptr;

	if (!IS_BB_NODE_FLAG_SET(succ_bb, BBNODE_VISITED)) 
	    DFS_BB_Graph(succ_bb, num_bbs, num_lbbs);

    }
    bb_graph->bb_node[--(*num_bbs)] = bbn;
    if (FindFlowNodeDepth((FlowNode)bbn->flows->ptr) > 0)
	bb_graph->loop_bbs[--(*num_lbbs)] = bbn;
    bbn->index = *num_bbs;
}
#endif

static void Build_BB_Node_Array()
{
    int num_bbs, num_lbbs;
    BBNode bbn;

    bb_graph->bb_node = (BBNode *) malloc(bb_graph->num_nodes * sizeof(BBNode));
    if (bb_graph->bb_node == NIL) Punt("Memory allocation failed.", NIL);
    bb_graph->loop_bbs = (bb_graph->num_lbbs > 0) ? 
			((BBNode *) malloc(bb_graph->num_lbbs*sizeof(BBNode))) :
			NIL;
    if (bb_graph->bb_node == NIL) Punt("Memory allocation failed.", NIL);
    /* BCC - now put BBs in ascending order - 7/10/96 
    num_bbs = bb_graph->num_nodes;
    num_lbbs = bb_graph->num_lbbs;
    */
    num_bbs = 0;
    num_lbbs = 0;

    ResetBBGraphFlags(bb_graph, BBNODE_VISITED);
    DFS_BB_Graph(bb_graph->entry_node, &num_bbs, &num_lbbs);

    /* GEH - added special case to find unreachable BBNodes - 6/6/95 */
    /* BCC - now put BBs in ascending order - 7/10/96 
    if (num_bbs != 0 || num_lbbs != 0) {
    */
    if (num_bbs != bb_graph->num_nodes || num_lbbs != bb_graph->num_lbbs) {
	for (bbn=bb_graph->first_node; bbn != NIL; bbn=bbn->next) {
	    if (!IS_BB_NODE_FLAG_SET(bbn, BBNODE_VISITED)) {
		bb_graph->bb_node[num_bbs] = bbn;
		if (FindFlowNodeDepth((FlowNode)bbn->flows->ptr) > 0)
		    bb_graph->loop_bbs[num_lbbs] = bbn;
		bbn->index = num_bbs++;
		SET_BB_NODE_FLAGS(bbn, BBNODE_VISITED);
	    }
	}
    }

    assert(num_bbs == bb_graph->num_nodes && num_lbbs == bb_graph->num_lbbs);
}

static void Build_BB_Graph(func)
FuncDcl func;
{
    BBNode bbn;
    FlowNode fn, ffn;
    Lptr succ, pred, flow;
    int num, fn_order;

    /* Build all the basic block nodes */
    for (ffn = flow_graph->first_node; ffn != NIL; ffn = ffn->next) {
	succ = ffn->succ;
	pred = ffn->pred;

	/* only flow node with no successors should be function exit node */
	assert(succ != NIL || ffn->type == NT_FuncExit);

	/* only flow node with no predecessors should be function entry node */
	/* GEH - removed since can't always remove unreachable code 6-6-95 */
	/* assert(pred != NIL || ffn->type == NT_FuncEntry); */

	if (pred == NIL || 
	    pred->next != NIL ||
	    ((FlowNode)pred->ptr)->succ->next != NIL) {

	    /*
	     * if either 1) node has no predecessors 
	     *		 2) node has more than one predecessor
	     *		 3) node's lone pred. has more than one succ.
	     *	then node is first flow node in BB 
	     */

	    bbn = NewBBNode(bb_graph);
	    if (FindFlowNodeDepth(ffn) > 0) bb_graph->num_lbbs += 1;
	    ffn->bb = bbn;
	    ffn->order = fn_order = 0;
	    bbn->flows = NewLptr((Void *) ffn);

	    while (succ != NIL && succ->next == NIL) {
		fn = (FlowNode) succ->ptr;
		assert(fn != NIL);
		pred = fn->pred;
		succ = fn->succ;
		assert(pred != NIL);
		if (pred->next != NIL) break;

		assert(fn->bb == NIL);
		fn->bb = bbn;
		fn->order = ++fn_order;
		bbn->flows = AppendLptr(bbn->flows, NewLptr((Void *) fn));
	    }
	}
    }

    /* Make sure all flow nodes included in a basic block */
    for (ffn = flow_graph->first_node; ffn != NIL; ffn = ffn->next) {
	assert(ffn->bb != NIL);	
	assert(ffn->order >= 0);
    }
	    
    /* Link all the basic block nodes */
    for (bbn = bb_graph->first_node; bbn != NIL; bbn = bbn->next) {

	fn = ((FlowNode)bbn->flows->ptr);  /* get first flow node of BB */

	/* Connect basic block to all predecessor basic blocks */
	pred = fn->pred;
        while (pred != NIL) {
	    ConnectBBNodes(((FlowNode)pred->ptr)->bb, bbn);
	    pred = pred->next;
	}
	
	/* get last flow node of BB */
	flow = bbn->flows;
	assert(flow != NIL);
	while (flow->next != NIL) flow = flow->next;

	/* Connect basic block to all successor basic blocks */
	succ = ((FlowNode)flow->ptr)->succ;
	while (succ != NIL) {
	    ConnectBBNodes(bbn, ((FlowNode)succ->ptr)->bb);
	    succ = succ->next;
	}
    }

    bb_graph->entry_node = func->flow->entry_flow_node->bb;
    bb_graph->exit_node = func->flow->exit_flow_node->bb;

    /* build array of BB nodes */
    Build_BB_Node_Array();
}

/*
 * Check to see if function has basic block graph.
 * Return TRUE if graph present, FALSE otherwise.
 */

bool CF_Function_Has_BBG(func)
FuncDcl func;
{
    if (func->flow == NIL || func->flow->flow_graph == NIL)
        Punt("control flow graph not available for function", NIL);
    flow_graph = func->flow->flow_graph;

    return flow_graph->has_bbs;
}

/* 
 * Build Basic Block graph for the given function.
 */

void CF_Build_BBG_Function(func)
FuncDcl func;
{
    if (debug_yes || verbose_yes) {
	fprintf(Flog, "..Basic Block Analysis beginning on fn (%s)\n",
		func->name);
    }

    if (func->flow == NIL || func->flow->flow_graph == NIL)
	Punt("control flow graph not available for function", NIL); 
    flow_graph = func->flow->flow_graph;

    if (flow_graph->has_bbs) RemoveBBGraph(flow_graph->bb_graph);
    bb_graph = flow_graph->bb_graph = NewBBGraph(func);
    flow_graph->has_bbs = TRUE;

    Build_BB_Graph(func);

    if (debug_yes || verbose_yes) {
	fprintf(Flog, "..Basic Block Analysis complete for fn (%s)\n",
		func->name);
    }
    if (debug_yes) {
	fprintf(Flog, "....Number of Basic Blocks in Graph: %d\n",
		bb_graph->num_nodes);
    }
}
