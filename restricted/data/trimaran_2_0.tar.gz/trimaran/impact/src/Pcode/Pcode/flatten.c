/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	flatten.c
 *	Author:	Ben-Chung Cheng and Wen-mei Hwu
\*****************************************************************************/
#include <Pcode/pcode.h>
#include <Pcode/struct.h>
#include <Pcode/reduce.h>
#include <Pcode/parms.h>
#include <Pcode/cast.h>
#include <library/list.h>
#include <library/c_symbol.h>

int next_var_id = 0;
static FuncDcl currentF = 0;

static void FlattenStmts(Stmt);
static void VisitStmts(Stmt);
static Expr GenerateExpr(Stmt, Expr, Expr);

#define F_SIDE_EFFECT   1
#define F_BREAK         2
#define F_CONTAIN_BREAK 4
#define F_ARGUMENT	8

typedef struct _ExprExt {
        int     node_type;
} _ExprExt, *ExprExt;

#define MAX_EXPR_SIZE   2000
static _ExprExt expr_list[MAX_EXPR_SIZE];
static int expr_list_len = -1;
static long num_must_break_node = 0;
static long num_induced_break_node = 0;
static long label_counter = 0;
static void RestructureStmts(Stmt);

static int conj_disj_counter;
static int conj_disj_sequence;
static int if_else_counter;
static int mapping_table_ID;
static int useless_var_table_ID;

static Expr SearchThroughParenthesis(expr, opcode)
Expr expr;
_Opcode opcode;
{
    while (expr->opcode == OP_compexpr) {
	if (expr->next) return 0;
	expr = expr->operands;
    }
    if (expr->opcode == opcode && expr->next == NULL)
	return expr;
    else return NULL;
}

static ExprExt NewExprExt() {
    expr_list_len++;
    if (expr_list_len>=MAX_EXPR_SIZE)
	Punt("NewExprExt : expression tree is too large");
    expr_list[expr_list_len].node_type = 0;
    return (expr_list + expr_list_len);
}

/*
 * (((a, b, c))) , propagate the flag from the enclosing parenthesis into a,b,c
 */
static MarkCompExpr(expr, flag)
Expr expr;
int flag;
{
    if (expr == 0) return;
    if (expr->opcode == OP_compexpr) {
	Expr op;

	op = expr->operands;
	if (op == NIL) return;
	op->status |= flag;
	if (op->opcode == OP_compexpr) MarkCompExpr(op, flag);

	op = op->next;
	while (op) {
	    op->status |= flag;
	    if (op->opcode == OP_compexpr) MarkCompExpr(op, flag);
	    op = op->next;
	}
    }
}
	

/*
 *      Visit an expression tree in the execution order.
 *      Use the status field of expressions to remember
 *      the returned location.
 */
static VisitExprNode(expr)
Expr expr;
{
    int opcode, i, j, flag;
    Expr op, op1, op2, op3, opnext;

    if (expr==0) return;
    opcode = expr->opcode;

    /* BCC - Don't break __builtin_XXX calls - 3/18/96 */
    if (opcode == OP_call && expr->operands->value.var_name && 
	!strncmp(expr->operands->value.var_name, "__builtin", 9))
	return;

    if (opcode == OP_call) {
	op2 = GetOperand(expr, 2);
	while (op2) {
	    op2->status |= F_ARGUMENT;
	    op2 = op2->next;
	}
    }

    /* 
     * step 1 : mark explicit attributes
     */

    /*
     *  step 1.1 : Assignments and function call (side-effect)
     */
    switch (opcode) {
	case OP_call :
	case OP_assign:    
	case OP_preinc:        
	case OP_predec:
	case OP_postinc:   
	case OP_postdec:       
	case OP_Aadd:
	case OP_Asub:      
	case OP_Amul:          
	case OP_Adiv:
	case OP_Amod:      
	case OP_Arshft:        
	case OP_Alshft:
	case OP_Aand:      
	case OP_Aor:           
	case OP_Axor: {
	    expr->status |= F_SIDE_EFFECT;
	    if (expr->opcode == OP_compexpr) 
		MarkCompExpr(expr->operands, F_SIDE_EFFECT);
	    break;
	}
	default :
	    /* do nothing */
	    break;
    }

    /*
     *  step 1.2 : expressions which needs to be restructured
     */
    if ((opcode==OP_quest) || (opcode==OP_conj) || (opcode==OP_disj)) {
        num_must_break_node++;
        expr->status |= (F_BREAK | F_CONTAIN_BREAK);
    }

    /*
     *  step 1.3 : functions with source code will be broken
     */
    if ( opcode==OP_call ) {
        char *funcname;
	int dummy;
	void *dummy_ptr;

        if (mapping_table_ID == 0) {
	    num_must_break_node++;
	    expr->status |= (F_BREAK | F_CONTAIN_BREAK);
	}
	else if (expr->operands->opcode == OP_var && 
		 IsFunctionType(expr->operands->type)) {
            funcname = expr->operands->value.var_name;
	    if (C_find(mapping_table_ID, funcname, 0, &dummy, 
		(Pointer *) &dummy_ptr)) { 
		num_must_break_node++;
		expr->status |= (F_BREAK | F_CONTAIN_BREAK);
	    }
	    else {
		if (DEBUG_FLATTENING) {
		    fprintf(Flog, "Function %s not broken because source code is not available\n", funcname);
		}
	    }
	} else {
	    num_must_break_node++;
	    expr->status |= (F_BREAK | F_CONTAIN_BREAK);
	}
    }

    /*
     *  step2 : make recursive calls.
     */
    for (i=1; (op=GetOperand(expr, i))!=0; i++) 
        VisitExprNode(op);
    if (expr->next != NIL) VisitExprNode(expr->next);

    /* 
     * step 3 : propogate attributes bottom up
     */
    /* 
     * step 3.1 : check operands
     */
    switch (expr->opcode) {
	/* op1 < op2 */
	case OP_disj:
	case OP_conj:
#if 0
	    op1 = GetOperand(expr, 1);
	    op2 = GetOperand(expr, 2);
	    if ((op2->status&F_SIDE_EFFECT) && (op2->status&F_CONTAIN_BREAK)){
		op1->status |= F_BREAK | F_CONTAIN_BREAK;
		if (op1->opcode == OP_compexpr) 
		    MarkCompExpr(op1, F_BREAK | F_CONTAIN_BREAK);
		opnext = op1->next;
		while (opnext) {
		    opnext->status |= F_BREAK | F_CONTAIN_BREAK;
		    if (opnext->opcode == OP_compexpr)
			MarkCompExpr(opnext, F_BREAK | F_CONTAIN_BREAK);
		    opnext = opnext->next;
		}
	    }
	    else if (op2->status & F_CONTAIN_BREAK) {
		if ((op1->status&F_SIDE_EFFECT) && (op1->status^F_BREAK)) {
		    op1->status |= F_BREAK | F_CONTAIN_BREAK;
		    if (op1->opcode == OP_compexpr) 
			MarkCompExpr(op1, F_BREAK | F_CONTAIN_BREAK);
		    opnext = op1->next;
		    while (opnext) {
			opnext->status |= F_BREAK | F_CONTAIN_BREAK;
			if (opnext->opcode == OP_compexpr)
			    MarkCompExpr(opnext, F_BREAK | F_CONTAIN_BREAK);
			opnext = opnext->next;
		    }
		}
	    }
	    expr->status |= (op1->status | op2->status) & 
			      (F_CONTAIN_BREAK | F_SIDE_EFFECT);
#endif
	    /* BCC - 1/29/97
	     * Although F_BREAK in op2 should not affect the attributes of
	     * op1, their attributes should always be propagated to expr
	     */
	    op1 = GetOperand(expr, 1);
	    op2 = GetOperand(expr, 2);
	    expr->status |= (op1->status | op2->status) & 
			      (F_CONTAIN_BREAK | F_SIDE_EFFECT);
	    break;
	/* op1 < op2, op1 < op3, op2 ? op3 */
	case OP_quest:
	    /* will be restructured */
	    /* BCC - 1/29/97
	     * Although F_BREAK in op2, op3 should not affect the attributes of
	     * op1, their attributes should always be propagated to expr
	     */
	    op1 = GetOperand(expr, 1);
	    op2 = GetOperand(expr, 2);
	    op3 = GetOperand(expr, 3);
	    expr->status |= (op1->status | op2->status | op3->status) & 
			      (F_CONTAIN_BREAK | F_SIDE_EFFECT);
	    break;
	/* op2 < op1 */
	case OP_assign:
	case OP_Aadd:
	case OP_Asub:
	case OP_Amul:
	case OP_Adiv:
	case OP_Amod:
	case OP_Arshft:
	case OP_Alshft:
	case OP_Aand:
	case OP_Aor:
	case OP_Axor:
	case OP_call:
	    op1 = GetOperand(expr, 1);
	    op2 = GetOperand(expr, 2);
	    if (opcode == OP_call && !op2) break;
	    if ((op1->status&F_SIDE_EFFECT) && (op1->status&F_CONTAIN_BREAK)) {
		op2->status |= F_BREAK | F_CONTAIN_BREAK;
		if (op2->opcode == OP_compexpr) 
		    MarkCompExpr(op2, F_BREAK | F_CONTAIN_BREAK);
		opnext = op2->next;
		while (opnext) {
		    opnext->status |= F_BREAK | F_CONTAIN_BREAK;
		    if (opnext->opcode == OP_compexpr)
			MarkCompExpr(opnext, F_BREAK | F_CONTAIN_BREAK);
		    opnext = opnext->next;
		}
	    }
	    else if (op1->status & F_CONTAIN_BREAK) {
		if ((op2->status&F_SIDE_EFFECT) && (op2->status^F_BREAK)) {
		    op2->status |= F_BREAK | F_CONTAIN_BREAK;
		    if (op2->opcode == OP_compexpr) 
			MarkCompExpr(op2, F_BREAK | F_CONTAIN_BREAK);
		    opnext = op2->next;
		    while (opnext) {
			opnext->status |= F_BREAK | F_CONTAIN_BREAK;
			if (opnext->opcode == OP_compexpr)
			    MarkCompExpr(opnext, F_BREAK | F_CONTAIN_BREAK);
			opnext = opnext->next;
		    }
		}
	    }
	    expr->status |= (op1->status | op2->status) & 
			    (F_CONTAIN_BREAK | F_SIDE_EFFECT);
	    break;
	/* opx ? opy */
	default:
	    for (i=1; (op=GetOperand(expr, i))!=0; i++) 
		expr->status |= op->status & (F_CONTAIN_BREAK | F_SIDE_EFFECT);
	    break;
    }
    /* 
     * step 3.2 : check the next expression
     */
    if ((op=GetNextOperand(expr, 1)) != 0) {
        if ((op->status & F_SIDE_EFFECT)  && (op->status & F_CONTAIN_BREAK)) {
	    if (!(expr->status & F_ARGUMENT)) {
		expr->status |= F_BREAK | F_CONTAIN_BREAK | F_SIDE_EFFECT;
		if (expr->opcode == OP_compexpr)
		    MarkCompExpr(expr, F_BREAK|F_CONTAIN_BREAK|F_SIDE_EFFECT);
	    }
	    else 
		expr->status |= F_CONTAIN_BREAK | F_SIDE_EFFECT;
	}
	else if (op->status & F_CONTAIN_BREAK) {
	    expr->status |= F_CONTAIN_BREAK;
	    if (!(expr->status & F_ARGUMENT) && (expr->status & F_SIDE_EFFECT)){
		expr->status |= F_BREAK | F_CONTAIN_BREAK;
		MarkCompExpr(expr, F_BREAK | F_CONTAIN_BREAK);
	    }
        }
	else if (op->status & F_SIDE_EFFECT) {
	    expr->status |= F_SIDE_EFFECT;
	}
    }

    /*
     * Example 1 : 
     *		a(b,c), d()
     *		The evaluation order is b->c->a()->d()
     *		Since d() should be evaluated later than a(), even though a()'s
     *		status is 1, it still needs to be broken
     * Example 2 :
     *		a(b(), c())
     *		The evaluation order is {b(),c()}->a()
     *		So even b() and c() are broken, there is no need to break a()
     * Real Example which causes failure if not handled carefully:
     *		008.espresso/cvrm.c:sort_reduce()
     *		( p[0] &= 0xffff, 
     *		  p[0] |= ((((n-cdist(largest,p))<<7) + ........)
     *		where p[0] are updated twice in the same expression list, so
     *		order of evaluation matters
     */
}

/* 
 * Move the information from ext node into the expr node
 */
static ResetExprStatus(expr)
Expr expr;
{
    Expr op;
    int i;

    if (expr==0) return;
    expr->status = 0;
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
        ResetExprStatus(op);
    }
    if (expr->next) ResetExprStatus(expr->next);
}

/*
 * Traverse the stmtements to annotate the expressions
 */
static void VisitStmts(stmts)
Stmt stmts;
{
    SerLoop serloop;
    ParLoop parloop;

    while (stmts != NIL) {
        switch (stmts->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
                break;
            case ST_RETURN:
		if (stmts->stmtstruct.ret) {
		    expr_list_len = -1;
		    if (stmts->stmtstruct.ret)
			stmts->stmtstruct.ret->status = 0;
		    VisitExprNode(stmts->stmtstruct.ret);
		}
		break;
            case ST_COMPOUND:
                VisitStmts(stmts->stmtstruct.compound->stmt_list);
                break;
            case ST_IF:
		expr_list_len = -1;
                if (stmts->stmtstruct.ifstmt->cond_expr)
		    stmts->stmtstruct.ifstmt->cond_expr->status = 0;
                VisitExprNode(stmts->stmtstruct.ifstmt->cond_expr);

                VisitStmts(stmts->stmtstruct.ifstmt->then_block);

                if (stmts->stmtstruct.ifstmt->else_block != NIL)
                    VisitStmts(stmts->stmtstruct.ifstmt->else_block);
                break;
            case ST_SWITCH:
		expr_list_len = -1;
                if (stmts->stmtstruct.switchstmt->expression)
		    stmts->stmtstruct.switchstmt->expression->status = 0;
                VisitExprNode(stmts->stmtstruct.switchstmt->expression);

                VisitStmts(stmts->stmtstruct.switchstmt->switchbody);
                break;
            case ST_EXPR:
		expr_list_len = -1;
                if (stmts->stmtstruct.expr)
		    stmts->stmtstruct.expr->status = 0;
                VisitExprNode(stmts->stmtstruct.expr);
                break;
            case ST_PSTMT:
                VisitStmts(stmts->stmtstruct.pstmt->stmt);
                break;
            case ST_MUTEX:
                VisitStmts(stmts->stmtstruct.mutex->statement);
                break;
            case ST_COBEGIN:
                VisitStmts(stmts->stmtstruct.cobegin->statements);
                break;
            case ST_SERLOOP:
                serloop = stmts->stmtstruct.serloop;

		expr_list_len = -1;
                if (serloop->init_expr) 
		    serloop->init_expr->status = 0;
                VisitExprNode(serloop->init_expr);

		expr_list_len = -1;
                if (serloop->cond_expr)
		    serloop->cond_expr->status = 0;
                VisitExprNode(serloop->cond_expr);

		expr_list_len = -1;
                if (serloop->iter_expr)
		    serloop->iter_expr->status = 0;
                VisitExprNode(serloop->iter_expr);

                VisitStmts(serloop->loop_body);
                break;
            case ST_PARLOOP:
                parloop = stmts->stmtstruct.parloop;
                VisitStmts(Parloop_Stmts_Prologue_Stmt(stmts));
                break;
            case ST_BODY:
                VisitStmts(stmts->stmtstruct.bodystmt->statement);
                break;
            case ST_EPILOGUE:
                VisitStmts(stmts->stmtstruct.epiloguestmt->statement);
                break;
            default:
                Punt("VisitStmts: Invalid statement type", stmts);
        }
        stmts = stmts->lex_next;
    }
}

/*
 *      if result_var is defined, use it as a new
 *      value holder. otherwise, we need to create
 *      a new local variable.
 */
Expr NewLocalVar(result_var, type)
Expr result_var;
Type type;
{
    Expr lvar;
    char var_name[200];
    lvar = result_var;

    /* BCC - Don't create a variable of type VOID - 5/19/95 */
    if ((type->type & TY_VOID) && (type->dcltr == 0))
        return NewIntExpr(0);  /* this will never be used */

    if (lvar==0) {
        VarList lv, ptr;
        VarDcl var;
        Dcltr dcltr;
        /* create a new temporary variable */
        for (;;) {      /* find a new name */
            sprintf(var_name, "P_%d___%d", next_var_id++, scope);
            for (lv = currentF->stmt->stmtstruct.compound->var_list; 
		 lv!=0; lv=lv->next)
                if (! strcmp(lv->name, var_name))
                    break;
            if (lv==0)
                break;
        }
        var = NewVarDcl();
        var->name = (char *) FindString(var_name);      /* list.c */
        var->type = CopyType(type);
        var->type->type &= TY_TYPE;
        var->type->type |= TY_AUTO;             /* local variable */

	/* 
	 * BCC - 8/19/96
	 * add the new var to the symbol table so that they can be freed later
	 */
	AddVar(var->name, var->new_name, var, scope);
        /*
         *      modify D_ARRY to D_PTR
         *      D_FUNC is not allowed.
         */
        dcltr = var->type->dcltr;
        if (dcltr!=0) {
            /* New code NJW 11/92 */
            if (dcltr->method==D_FUNC) {
                var->type->dcltr = NewDcltr();
                var->type->dcltr->method = D_PTR;
                var->type->dcltr->next = dcltr;
            }
            /* End New Code */
            if (dcltr->method==D_ARRY)
                dcltr->method = D_PTR;
        }
        /*
         *      use register when possible.
         */
        currentF->stmt->stmtstruct.compound->var_list = AddVar2List(
	    currentF->stmt->stmtstruct.compound->var_list, var);
        lvar = NewExpr(OP_var);
        lvar->value.var_name = var->name;
        lvar->type = CopyType(var->type);
    } else {
        lvar = CopyExpr(lvar);
        /* check type : we assume that the type is correct */
    }
    return lvar;
}

/* 
 * When we flatten an expression, we have to propagate the label associated 
 * with the old expression to the new one. For example:
 *
 * L1: a(b());		==> L1: t1 = b();
 *				a(t1);
 * But sometimes the label is hidden under the first level statement, 
 *
 * { L1: a(b()); }	==> L1: t1 = b();
 *				{ a(t1); }
 * Or even complicate:
 *
 * L1 : { L2: a(b()); }	==> L1: L2: t1 = b();
 *				{ a(t1); }
 */
Label ExtractLabels(stmt)
Stmt stmt;
{
    Label label1, label2, last;

    if (stmt == 0) return 0;
    switch (stmt->type) {
	case ST_COMPOUND :
	    label1 = stmt->labels;
	    stmt->labels = 0;
	    label2 = ExtractLabels(stmt->stmtstruct.compound->stmt_list);
	    if (label1 == 0) return label2;		/* l1 = 0, l2 = x */
	    else if (label2 == 0) return label1;	/* l1 = x, l2 = 0 */
	    else {
		last = label1;
		while (last->next) last = last->next;
		last->next = label2;
		label2->prev = last;
		return label1;
	    }
	    break;
	default :
	    label1 = stmt->labels;
	    stmt->labels = 0;
	    return label1;
    }
}

/* 
 * Add a statement of type ST_EXPR prior to the base statement
 */
static void AddStmt(base_stmt, expr)
Stmt base_stmt;
Expr expr;
{
    Stmt new_stmt;

    new_stmt = NewStmt();
    new_stmt->type = ST_EXPR;
    new_stmt->stmtstruct.expr = expr;
    /*
     * Propagate the label of the base statement to the new one
     */
    new_stmt->labels = ExtractLabels(base_stmt);
    Insert_Stmt_Before(base_stmt, new_stmt);
    LinkExpr(new_stmt->stmtstruct.expr, new_stmt, 0, 0);

    /*
     * LCW - propagate the line number, column number and file name of 
     *       the base statement to the new one. -- 10/8/96
     */
    new_stmt->lineno = base_stmt->lineno;
    new_stmt->colno = base_stmt->colno;
    if (base_stmt->filename != NULL) {
      new_stmt->filename = (char *)malloc(strlen(base_stmt->filename)+1);
      strcpy(new_stmt->filename, base_stmt->filename);
    }
    else
      new_stmt->filename = strdup("\"_no_file_name_\"");
}

static void UndeleteUselessVar(expr)
Expr expr;
{
    int dummy;
    int *dummy_ptr;

    if (useless_var_table_ID == 0) return;
    if (expr->opcode != OP_var) return;
    if (!IsPcodeTemp(expr)) return;
    C_update(useless_var_table_ID, expr->value.var_name, 0, 1, 0);
}

/*
 * Translate "x ? y : z" to 
 * if (x) result = y else result = z;
 * return result
 */
static Expr GenQuest(base_stmt, expr, result_var)
Stmt base_stmt;
Expr expr, result_var;
{
    Expr X, Y, Z;
    Expr result, assign, assign1, compexpr, temp;
    Stmt new_stmt, y_stmt, z_stmt;
    IfStmt new_if;

    /* 
     * Create a new stmt which is of type ST_IF
     */
    new_stmt = NewStmt();
    new_stmt->type = ST_IF;
    /* BCC - 1/15/97 */
    AddStatementPragma(new_stmt, strdup("\"QUEST\""), NewIntExpr(0));
    /*
     * Propagate the label of the base statement to the new one
     */
    new_stmt->labels = ExtractLabels(base_stmt);
    Insert_Stmt_Before(base_stmt, new_stmt);

    /*
     * LCW - propagate the line number, column number and file name of 
     *       the base statement to the new one. -- 10/8/96
     */
    new_stmt->lineno = base_stmt->lineno;
    new_stmt->colno = base_stmt->colno;
    if (base_stmt->filename != NULL) {
      new_stmt->filename = (char *)malloc(strlen(base_stmt->filename)+1);
      strcpy(new_stmt->filename, base_stmt->filename);
    }
    else
      new_stmt->filename = strdup("\"_no_file_name_\"");

    /*
     * Create the new IfStmt and connect it to new_stmt
     */
    new_if = NewIfStmt();
    new_stmt->stmtstruct.ifstmt = new_if;
    /*
     * Extract the three parts of the original "X ? Y : Z" expression
     */
    /* BCC - should use CopyExprList - 7/20/96 */
    X = CopyExprList(GetOperand(expr, 1));
    Y = CopyExprList(GetOperand(expr, 2));
    Z = CopyExprList(GetOperand(expr, 3));
    
    /* BCC - added needed compexpr for LinkExpr semantic check - 7/20/96 */
    if (X->next) {
	compexpr = NewExpr(OP_compexpr);
	AddOperand(compexpr, X);
	CastExpr(compexpr);
        X = compexpr;
    }
    
    /* BCC - added needed compexpr for LinkExpr semantic check - 7/20/96 */
    if (Y->next) {
	compexpr = NewExpr(OP_compexpr);
	AddOperand(compexpr, Y);
	CastExpr(compexpr);
        Y = compexpr;
    }
    
    /* BCC - added needed compexpr for LinkExpr semantic check - 7/20/96 */
    if (Z->next) {
	compexpr = NewExpr(OP_compexpr);
	AddOperand(compexpr, Z);
	CastExpr(compexpr);
        Z = compexpr;
    }

    /* BCC - the situation can be divided into the following:
     * 1) a = b ? c : d;
     *    if (b)
     *        a = c;
     *    else
     *        a = d;
     *    use a dirctly
     * 
     * 2) *p = b ? c : d;
     *    if (b)
     *        *p = temp = c;
     *    else
     *        *p = temp = d;
     *    use temp to save the evaluation time
     *
     * 3) *p++ = b ? c : d;
     *    if (b)
     *        *p++ = temp = c;
     *    else
     *        *p++ = temp = d;
     *    use temp because p++ has side-effect.
     */

    if (!result_var || !IsVarExpr(result_var))
	result = NewLocalVar(0, expr->type);
    else
	result = NewLocalVar(result_var, expr->type);
    new_if->cond_expr = X;
    /* BCC - a.b = P_0___1 = c, we can't delete P_0___1 */
#if 0
    UndeleteUselessVar(result);
#endif
    /*
     * True part
     */
    y_stmt = NewStmt();
    y_stmt->type = ST_EXPR;
    /* BCC - 11/12/96
     * when the code is like a ? (void) foo1() : 0, where the second operand
     * is non-void, we still can't assign it to the result var, because the
     * destinitaion local var is "0", resulted from the return type of foo1().
     */
    if (result->opcode == OP_int || IsVoidType(Y->type) || 
	IsVoidType(result->type)) {
	y_stmt->stmtstruct.expr = Y;
    }
    else {
	if (result_var) {
	    /* result_var == result*/
	    if (IsVarExpr(result_var)) {
		assign = NewExpr(OP_assign);
		AddOperand(assign, CopyExpr(result));
		AddOperand(assign, Y);
		CastExpr(assign);
		y_stmt->stmtstruct.expr = assign;
	    }
	    /* result_var is complex while result is simple */ 
	    else {
		assign = NewExpr(OP_assign);
		assign1 = NewExpr(OP_assign);
		AddOperand(assign1, CopyExpr(result_var));
		AddOperand(assign1, Y);
		CastExpr(assign1);
		AddOperand(assign, CopyExpr(result));
		AddOperand(assign, assign1);
		CastExpr(assign);
		y_stmt->stmtstruct.expr = assign;
	    }
	}
	/* no result_var, result is a var */
	else {
	    assign = NewExpr(OP_assign);
	    AddOperand(assign, CopyExpr(result));
	    AddOperand(assign, Y);
	    CastExpr(assign);
	    y_stmt->stmtstruct.expr = assign;
	}
    }

    /*
     * LCW - propagate the line number, column number and file name of 
     *       the base statement to the new one. -- 10/8/96
     */
    y_stmt->lineno = base_stmt->lineno;
    y_stmt->colno = base_stmt->colno;
    if (base_stmt->filename != NULL) {
      y_stmt->filename = (char *)malloc(strlen(base_stmt->filename)+1);
      strcpy(y_stmt->filename, base_stmt->filename);
    }
    else
      y_stmt->filename = strdup("\"_no_file_name_\"");

    /*
     * False part
     */
    z_stmt = NewStmt();
    z_stmt->type = ST_EXPR;
    /* BCC - explained as above - 11/12/96 */
    if (result->opcode == OP_int || IsVoidType(Z->type) || 
	IsVoidType(result->type)) {
	z_stmt->stmtstruct.expr = Z;
    }
    else {
	if (result_var) {
	    /* result_var == result*/
	    if (IsVarExpr(result_var)) {
		assign = NewExpr(OP_assign);
		AddOperand(assign, CopyExpr(result));
		AddOperand(assign, Z);
		CastExpr(assign);
		z_stmt->stmtstruct.expr = assign;
	    }
	    /* result_var is complex while result is simple */ 
	    else {
		assign = NewExpr(OP_assign);
		assign1 = NewExpr(OP_assign);
		AddOperand(assign1, CopyExpr(result_var));
		AddOperand(assign1, Z);
		CastExpr(assign1);
		AddOperand(assign, CopyExpr(result));
		AddOperand(assign, assign1);
		CastExpr(assign);
		z_stmt->stmtstruct.expr = assign;
	    }
	}
	/* no result_var, result is a var */
	else {
	    assign = NewExpr(OP_assign);
	    AddOperand(assign, CopyExpr(result));
	    AddOperand(assign, Z);
	    CastExpr(assign);
	    z_stmt->stmtstruct.expr = assign;
	}
    }

    /*
     * LCW - propagate the line number, column number and file name of 
     *       the base statement to the new one. -- 10/8/96
     */
    z_stmt->lineno = base_stmt->lineno;
    z_stmt->colno = base_stmt->colno;
    if (base_stmt->filename != NULL) {
      z_stmt->filename = (char *)malloc(strlen(base_stmt->filename)+1);
      strcpy(z_stmt->filename, base_stmt->filename);
    }
    else
      z_stmt->filename = strdup("\"_no_file_name_\"");

    /* 
     * Link the true and false part to the if stmt
     */
    new_if->then_block = y_stmt;
    new_if->else_block = z_stmt;
    LinkStmtsRt(new_stmt->stmtstruct.ifstmt->then_block, new_stmt, 0);
    LinkStmtsRt(new_stmt->stmtstruct.ifstmt->else_block, new_stmt, 0);
    LinkExpr(new_stmt->stmtstruct.ifstmt->cond_expr, new_stmt, 0, 0);
    /*
     * Flatten the cond expr of the if stmt
     */
    expr_list_len = -1;
    if (new_if->cond_expr)
	new_if->cond_expr->status = 0;
    ResetExprStatus(new_if->cond_expr);
    VisitExprNode(new_if->cond_expr);
    /* BCC - garbage collection - 8/19/96 */
    temp = GenerateExpr(new_stmt, new_if->cond_expr, 0);
    RemoveExpr(new_if->cond_expr);
    new_if->cond_expr = temp;
    /*
     * Flatten the newly constructed true stmts
     */
    VisitStmts(y_stmt);		
    FlattenStmts(y_stmt);
    /*
     * Flatten the newly constructed false stmts
     */
    VisitStmts(z_stmt);		
    FlattenStmts(z_stmt);
    return result;
}

/*
 * Translate "x && y" to
 * result = 0;
 * if (x) then result = (y<>0)
 * return result
 */

/* BCC - bug fix - 7/13/96
 * (d=d!=2 || d<4) is parsed as (d = ((d!=2) || (d<4))
 * we can't change the value of d until d is evaluated
 */
static Expr GenConj(base_stmt, expr, result_var)
Stmt base_stmt;
Expr expr, result_var;
{
    Expr X, Y;
    Expr result, assign, neq, compexpr, temp;
    Stmt new_stmt, new_stmt1, x_stmt, y_stmt;
    IfStmt new_if;
    char specifier[80];

    /*
     * Create the result=0 expression
     */
    /* BCC - 7/11/96
     * result_var shouldn't be set until the evaluation is finished 
    result = NewLocalVar(result_var, expr->type);
     */
    result = NewLocalVar(0, expr->type);
    assign = NewExpr(OP_assign);
    AddOperand(assign, CopyExpr(result));
    AddOperand(assign, NewIntExpr(0));
    AddStmt(base_stmt, assign);
    /* 
     * Create a new stmt which is of type ST_IF
     */
    new_stmt = NewStmt();
    new_stmt->type = ST_IF;
    /*
     * Propagate the label of the base statement to the new one
     */
    new_stmt->labels = ExtractLabels(base_stmt);
    Insert_Stmt_Before(base_stmt, new_stmt);

    /*
     * LCW - propagate the line number, column number and file name of 
     *       the base statement to the new one. -- 10/8/96
     */
    new_stmt->lineno = base_stmt->lineno;
    new_stmt->colno = base_stmt->colno;
    if (base_stmt->filename != NULL) {
      new_stmt->filename = (char *)malloc(strlen(base_stmt->filename)+1);
      strcpy(new_stmt->filename, base_stmt->filename);
    }
    else
      new_stmt->filename = strdup("\"_no_file_name_\"");

    /*
     * Create the new IfStmt and connect it to new_stmt
     */
    new_if = NewIfStmt();
    new_stmt->stmtstruct.ifstmt = new_if;
    /*
     * Extract the two parts of the original "X && Y" expression
     */
    /* BCC - should use CopyExprList - 7/20/96 */
    X = CopyExprList(GetOperand(expr, 1));
    Y = CopyExprList(GetOperand(expr, 2));

    /* BCC - added needed compexpr for LinkExpr semantic check - 7/20/96 */
    if (X->next) {
	compexpr = NewExpr(OP_compexpr);
	AddOperand(compexpr, X);
	CastExpr(compexpr);
        X = compexpr;
    }

    /* BCC - added needed compexpr for LinkExpr semantic check - 7/20/96 */
    if (Y->next) {
	compexpr = NewExpr(OP_compexpr);
	AddOperand(compexpr, Y);
	CastExpr(compexpr);
        Y = compexpr;
    }
    new_if->cond_expr = X;
    /*
     * True part
     */
    y_stmt = NewStmt();
    y_stmt->type = ST_EXPR;
    neq = NewExpr(OP_ne);
    AddOperand(neq, Y);
    AddOperand(neq, NewIntExpr(0));
    CastExpr(neq);
    assign = NewExpr(OP_assign);
    AddOperand(assign, CopyExpr(result));
    AddOperand(assign, neq);
    CastExpr(assign);
    y_stmt->stmtstruct.expr = assign;

    /*
     * LCW - propagate the line number, column number and file name of 
     *       the base statement to the new one. -- 10/8/96
     */
    y_stmt->lineno = base_stmt->lineno;
    y_stmt->colno = base_stmt->colno;
    if (base_stmt->filename != NULL) {
      y_stmt->filename = (char *)malloc(strlen(base_stmt->filename)+1);
      strcpy(y_stmt->filename, base_stmt->filename);
    }
    else
      y_stmt->filename = strdup("\"_no_file_name_\"");

    /* 
     * Link the true and false part to the if stmt
     */
    new_if->then_block = y_stmt;
    LinkStmtsRt(new_stmt->stmtstruct.ifstmt->then_block, new_stmt, 0);
    LinkExpr(new_stmt->stmtstruct.ifstmt->cond_expr, new_stmt, 0, 0);
    /*
     * Flatten the cond expr of the if stmt
     */
    expr_list_len = -1;
    if (new_if->cond_expr)
	new_if->cond_expr->status = 0;
    ResetExprStatus(new_if->cond_expr);
    VisitExprNode(new_if->cond_expr);

    /* BCC - garbage collection - 8/19/96 */
    temp = GenerateExpr(new_stmt, new_if->cond_expr, 0);
    RemoveExpr(new_if->cond_expr);
    new_if->cond_expr = temp;
    /*
     * Flatten the newly constructed true/false stmts
     */
    VisitStmts(y_stmt);		
    FlattenStmts(y_stmt);
    if (result_var) {
        assign = NewExpr(OP_assign);
        AddOperand(assign, CopyExpr(result_var));
        AddOperand(assign, CopyExpr(result));

        new_stmt1 = NewStmt();
        new_stmt1->type = ST_EXPR;
        new_stmt1->stmtstruct.expr = assign;
        Insert_Stmt_After(new_stmt, new_stmt1);
	LinkExpr(new_stmt1->stmtstruct.expr, new_stmt1, 0, 0);
	return CopyExpr(result_var);
    }
    else return result;
}

/*
 * Translate "x || y" to
 * result = 1;
 * if (x == 0) then result = (y<>0)
 * return result
 */

/* BCC - bug fix - 7/13/96
 * (d=d!=2 || d<4) is parsed as (d = ((d!=2) || (d<4))
 * we can't change the value of d until d is evaluated
 */
static Expr GenDisj(base_stmt, expr, result_var)
Stmt base_stmt;
Expr expr, result_var;
{
    Expr X, Y;
    Expr result, assign, neq, eq, compexpr, temp;
    Stmt new_stmt, new_stmt1, x_stmt, y_stmt;
    IfStmt new_if;
    char specifier[80];

    /*
     * Create result = 1 
     */
    /* BCC - 7/11/96
     * result_var shouldn't be set until the evaluation is finished
    result = NewLocalVar(result_var, expr->type);
     */
    result = NewLocalVar(0, expr->type);
    assign = NewExpr(OP_assign);
    AddOperand(assign, CopyExpr(result));
    AddOperand(assign, NewIntExpr(1));
    AddStmt(base_stmt, assign);
    /* 
     * Create a new stmt which is of type ST_IF
     */
    new_stmt = NewStmt();
    new_stmt->type = ST_IF;
    /*
     * Propagate the label of the base statement to the new one
     */
    new_stmt->labels = ExtractLabels(base_stmt);
    Insert_Stmt_Before(base_stmt, new_stmt);

    /*
     * LCW - propagate the line number, column number and file name of 
     *       the base statement to the new one. -- 10/8/96
     */
    new_stmt->lineno = base_stmt->lineno;
    new_stmt->colno = base_stmt->colno;
    if (base_stmt->filename != NULL) {
      new_stmt->filename = (char *)malloc(strlen(base_stmt->filename)+1);
      strcpy(new_stmt->filename, base_stmt->filename);
    }
    else
      new_stmt->filename = strdup("\"_no_file_name_\"");

    /*
     * Create the new IfStmt and connect it to new_stmt
     */
    new_if = NewIfStmt();
    new_stmt->stmtstruct.ifstmt = new_if;
    /*
     * Extract the two parts of the original "X || Y" expression
     */
    /* BCC - should use CopyExprList - 7/20/96 */
    X = CopyExprList(GetOperand(expr, 1));
    Y = CopyExprList(GetOperand(expr, 2));

    /* BCC - added needed compexpr for LinkExpr semantic check - 7/20/96 */
    if (X->next) {
	compexpr = NewExpr(OP_compexpr);
	AddOperand(compexpr, X);
	CastExpr(compexpr);
        X = compexpr;
    }

    /* BCC - added needed compexpr for LinkExpr semantic check - 7/20/96 */
    if (Y->next) {
	compexpr = NewExpr(OP_compexpr);
	AddOperand(compexpr, Y);
	CastExpr(compexpr);
        Y = compexpr;
    }

    new_if->cond_expr = X;
    /* 
     * Generate x == 0
     */
    eq = NewExpr(OP_eq);
    AddOperand(eq, X);
    AddOperand(eq, NewIntExpr(0));
    CastExpr(eq);
    new_if->cond_expr = eq;
    /*
     * True part
     */
    y_stmt = NewStmt();
    y_stmt->type = ST_EXPR;
    neq = NewExpr(OP_ne);
    AddOperand(neq, Y);
    AddOperand(neq, NewIntExpr(0));
    CastExpr(neq);
    assign = NewExpr(OP_assign);
    AddOperand(assign, CopyExpr(result));
    AddOperand(assign, neq);
    CastExpr(assign);
    y_stmt->stmtstruct.expr = assign;

    /*
     * LCW - propagate the line number, column number and file name of 
     *       the base statement to the new one. -- 10/8/96
     */
    y_stmt->lineno = base_stmt->lineno;
    y_stmt->colno = base_stmt->colno;
    if (base_stmt->filename != NULL) {
      y_stmt->filename = (char *)malloc(strlen(base_stmt->filename)+1);
      strcpy(y_stmt->filename, base_stmt->filename);
    }
    else
      y_stmt->filename = strdup("\"_no_file_name_\"");

    /* 
     * Link the true and false part to the if stmt
     */
    new_if->then_block = y_stmt;
    LinkStmtsRt(new_stmt->stmtstruct.ifstmt->then_block, new_stmt, 0);
    LinkExpr(new_stmt->stmtstruct.ifstmt->cond_expr, new_stmt, 0, 0);
    /*
     * Flatten the cond expr of the if stmt
     */
    expr_list_len = -1;
    if (new_if->cond_expr)
	new_if->cond_expr->status = 0;
    ResetExprStatus(new_if->cond_expr);
    VisitExprNode(new_if->cond_expr);
    temp = GenerateExpr(new_stmt, new_if->cond_expr, 0);
    RemoveExpr(new_if->cond_expr);
    new_if->cond_expr = temp;
    /*
     * Flatten the newly constructed true/false stmts
     */
    VisitStmts(y_stmt);		
    FlattenStmts(y_stmt);
    if (result_var) {
        assign = NewExpr(OP_assign);
        AddOperand(assign, CopyExpr(result_var));
        AddOperand(assign, CopyExpr(result));

        new_stmt1 = NewStmt();
        new_stmt1->type = ST_EXPR;
        new_stmt1->stmtstruct.expr = assign;
        Insert_Stmt_After(new_stmt, new_stmt1);
	LinkExpr(new_stmt1->stmtstruct.expr, new_stmt1, 0, 0);
	return CopyExpr(result_var);
    }
    else return result;
}

static void ResetBreakNode(expr)
Expr expr;
{
    int i;
    Expr op;

    if (expr == NULL) return;
    switch (expr->opcode) {
	case OP_quest :
	case OP_conj  :
	case OP_disj  :
	case OP_call  :
	    break;
	case OP_index :
	    expr->status &= ~F_BREAK;
	    ResetBreakNode(expr->operands);
	    break;
	default :
	    expr->status &= ~F_BREAK;
	    for (i=1; (op=GetOperand(expr, i)) != 0; i++) 
		ResetBreakNode(op);
	    break;
    }
    ResetBreakNode(expr->next);
}

/*
 * The ugliest function in this file. For an expression node which needs BREAK,
 * it move the expression out and use a new variable to represent it. If the
 * node doesn't need BREAK, it just duplicate the node and return it.
 */
static Expr GenerateExpr(base_stmt, expr, result_var)
Stmt base_stmt;
Expr expr, result_var;
{
    int status, opcode;
    Expr new, op, newop, op1, newop1, op2, newop2;
    Expr location, assign, temp, indr;
    Expr next_expr;
    Type type;
    int i, t;

    if (expr == 0)
	Punt("GenerateExpr: nil expr");
    status = expr->status;
    opcode = expr->opcode;

    if (!(status & F_BREAK)) {	/* no need to break; */
	if (result_var != 0) Punt("GenerateExpr: internal error 1");
	switch (opcode) {
	    case OP_assign:
		op1 = GetOperand(expr, 1);
		op2 = GetOperand(expr, 2);
		assert((op1->status & F_BREAK) == 0);
		if (!(op1->status & F_SIDE_EFFECT) && op2->status & F_BREAK) {
		    new = GenerateExpr(base_stmt, op2, op1);
		    if (expr->next) {
			new->next = GenerateExpr(base_stmt, expr->next, 0);
		    }
		    return new;
		}
		else {
		    new = CopyNode(expr); 
		    newop2 = GenerateExpr(base_stmt, op2, 0);
/*
		    UndeleteUselessVar(newop2);
*/
		    newop1 = GenerateExpr(base_stmt, op1, 0);
		    AddOperand(new, newop1);
		    AddOperand(new, newop2);
		    if (expr->next) {
			new->next = GenerateExpr(base_stmt, expr->next, 0);
		    }
		    return new;
		}
	    case OP_Aadd:
	    case OP_Asub:
	    case OP_Amul:
	    case OP_Adiv:
	    case OP_Amod:
	    case OP_Arshft:
	    case OP_Alshft:
	    case OP_Aand:
	    case OP_Aor:
	    case OP_Axor:
		op1 = GetOperand(expr, 1);
		op2 = GetOperand(expr, 2);
		assert((op1->status & F_BREAK) == 0);
		new = CopyNode(expr); 
		newop2 = GenerateExpr(base_stmt, op2, 0);
/*
		UndeleteUselessVar(newop2);
*/
		newop1 = GenerateExpr(base_stmt, op1, 0);
		AddOperand(new, newop1);
		AddOperand(new, newop2);
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		return new;
	    case OP_call:
		op1 = GetOperand(expr, 1);
		op2 = GetOperand(expr, 2);
		new = CopyNode(expr); 
		newop2 = op2 ? GenerateExpr(base_stmt, op2, 0) : NULL;
		newop1 = GenerateExpr(base_stmt, op1, 0);
/*
		UndeleteUselessVar(newop1);
*/
		AddOperand(new, newop1);
		if (newop2) {
		    AddOperand(new, newop2);
/*
		    UndeleteUselessVar(newop2);
*/
		}
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		return new;
	    /* BCC - reduce (a) to a - 12/17/95 */
	    case OP_compexpr:
		if (GetOperand(expr,1)->next == NIL) {
		    new = GenerateExpr(base_stmt, GetOperand(expr,1), 0);
/*
		    UndeleteUselessVar(new);
*/
		    if (expr->next) {
			new->next = GenerateExpr(base_stmt, expr->next, 0);
		    }
		    return new;
		}
		else {
		    new = CopyNode(expr); 
		    for (i=1; (op=GetOperand(expr, i)) != 0; i++) {
			newop = GenerateExpr(base_stmt, op, 0);
/*
			UndeleteUselessVar(newop);
*/
			AddOperand(new, newop);
		    }
		    if (expr->next) {
			new->next = GenerateExpr(base_stmt, expr->next, 0);
		    }
		    return new;
		}
	    default:
		new = CopyNode(expr); 
		for (i=1; (op=GetOperand(expr, i)) != 0; i++) {
		    newop = GenerateExpr(base_stmt, op, 0);
		    AddOperand(new, newop);
/*
		    UndeleteUselessVar(newop);
*/
		}
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		return new;
	}
    } else {			      /* need to break; */
	/*
	 * add "t = expr" to expr tree
	 * and use t instead 
	 */
	switch (opcode) {
	    /* 
	     * BCC - bug fix - 4/6/96
	     * Suppose the code looks like:
	     * foo1(&p1, *p2, foo2());
	     *
	     * It was transformed into after flattening:
	     *          temp1 = p1;
	     *          temp2 = &temp1;
	     *          temp3 = p2;
	     *          temp4 = *p2;
	     *          temp5 = foo2();
	     *          foo1(temp2, temp4, temp5);
	     *
	     *  where we can't use temp1 to hold p1 because we then take the
	     *  address of temp1, not p1. So flatten.c is modified to handle
	     *  OP_addr as a special case.
	     *
	     *  The following is the correct transformation:
	     *          temp1 = &p1;
	     *          temp2 = p2;
	     *          temp3 = *temp2;
	     *          temp4 = foo2();
	     *          foo1(temp1, temp2, temp4);
	     */
	    /* BCC - 7/31/96
	     * The bug fix is not complete yet. We can have code which 
	     * looks like &(aaa.bbb[foo() + ccc?ddd:eee]). In this case
	     * we still need to break foo() and ccc?ddd:eee but not
	     * the rest. So ResetBreakNode() reset the break flags all
	     * the way from the first operand of "&" till the end for all
	     * the "LVAR" expressions.
	     */
	    /* 
	     * Special case
	     */
	    case OP_quest: 
		new = GenQuest(base_stmt, expr, result_var);
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		break;
	    case OP_conj: 
		new = GenConj(base_stmt, expr, result_var);
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		break;
	    case OP_disj:
		new = GenDisj(base_stmt, expr, result_var);
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		break;
	    case OP_addr: 
		op = expr->operands;
		if ( op->opcode == OP_quest ) {
		    /* flatten &(i ? j : k) into (i ? &j : &k) */
		    newop = NewExpr(OP_quest);
		    AddOperand(newop, CopyExpr(op));

		    op1 = NewExpr(OP_addr);
		    AddOperand(op1, CopyExprList(GetOperand(op, 2)));
		    CastExpr(op1);
		    AddOperand(newop, op1);

		    op2 = NewExpr(OP_addr);
		    AddOperand(op2, CopyExprList(GetOperand(op, 3)));
		    CastExpr(op2);
		    AddOperand(newop, op2);

		    CastExpr(newop);
		    new = GenQuest(base_stmt, newop, 0);

		    if (expr->next) {
			new->next = GenerateExpr(base_stmt, expr->next, 0);
		    }
		}
		else {
		    assert((op->status & F_BREAK) == 0);
		    assign = NewExpr(OP_assign);
		    new = NewLocalVar(result_var, expr->type);
		    AddOperand(assign, new);
		    expr->status &= ~F_BREAK;
		    next_expr = expr->next;
		    expr->next = 0;
		    op = GenerateExpr(base_stmt, expr, 0);
/*
		    UndeleteUselessVar(op);
*/
		    expr->status |= F_BREAK;
		    expr->next = next_expr;
		    AddOperand(assign, op);
		    CastExpr(assign);
		    AddStmt(base_stmt, assign);
		    new = CopyExpr(new);
		    if (expr->next) {
			new->next = GenerateExpr(base_stmt, expr->next, 0);
		    }
		}
		break;
	    /*
	     * Compile-time expressions
	     */
	    case OP_enum:
	    case OP_int:
	    case OP_real:
	    case OP_float:
	    case OP_double:
	    case OP_char:
	    case OP_string:
	    case OP_expr_size:
	    case OP_type_size: 
		if (result_var != 0) {
		    assign = NewExpr(OP_assign);
		    new = CopyExpr(result_var);
		    AddOperand(assign, new);
		    AddOperand(assign, CopyExpr(expr));
		    CastExpr(assign);
		    AddStmt(base_stmt, assign);
		    new = CopyExpr(new);
		}
		else {
		    new = CopyExpr(expr);
		}
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		break;
	    /* 
	     * call/cast/complex expression
	     */
	    case OP_call: 
	    case OP_cast:
		/*
		 * If the returned type is VOID, there is no need to 
		 * generate t = call() or t = (....)
		 */
		type = expr->type;
		t = type->type & TY_TYPE;
		expr->status &= ~F_BREAK;
		next_expr = expr->next;
		expr->next = 0;
		op = GenerateExpr(base_stmt, expr, 0);
/*
		UndeleteUselessVar(op);
*/
		expr->status |= F_BREAK;
		expr->next = next_expr;
		if ((type->dcltr == 0) && (t == TY_VOID)) {
		    AddStmt(base_stmt, op);
		    new = NewIntExpr(0);
		}
		else {
		    assign = NewExpr(OP_assign);
		    new = NewLocalVar(result_var, expr->type);
		    AddOperand(assign, new);
		    AddOperand(assign, op);
		    CastExpr(assign);
		    AddStmt(base_stmt, assign);
		    new = CopyExpr(new);
		}
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		break;
	    case OP_compexpr: 
		/*
		 * If the returned type is VOID, there is no need to 
		 * generate t = call() or t = (....)
		 */
		type = expr->type;
		t = type->type & TY_TYPE;
		expr->status &= ~F_BREAK;
		next_expr = expr->next;
		expr->next = 0;
		op = GenerateExpr(base_stmt, expr, 0);
/*
		UndeleteUselessVar(op);
*/
		expr->status |= F_BREAK;
		expr->next = next_expr;
		if ((type->dcltr == 0) && (t == TY_VOID)) {
		    AddStmt(base_stmt, op);
		    new = NewIntExpr(0);
		}
		else {
		    new = op;
		}
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		break;
	    default:
		assign = NewExpr(OP_assign);
		new = NewLocalVar(result_var, expr->type);
		AddOperand(assign, new);
		expr->status &= ~F_BREAK;
		next_expr = expr->next;
		expr->next = 0;
		op = GenerateExpr(base_stmt, expr, 0);
/*
		UndeleteUselessVar(op);
*/
		expr->status |= F_BREAK;
		expr->next = next_expr;
		AddOperand(assign, op);
		CastExpr(assign);
		AddStmt(base_stmt, assign);
		new = CopyExpr(new);
		if (expr->next) {
		    new->next = GenerateExpr(base_stmt, expr->next, 0);
		}
		break;
	}
    }
    return new;
}

static UselessExpr(expr)
Expr expr;
{
    int result = 1;
    int i;
    Expr op;

    if (expr == 0) return 1;
    switch (expr->opcode) {
	case OP_postinc :
	case OP_postdec :
	case OP_preinc :
	case OP_predec :
	case OP_assign :
	case OP_Aadd :
	case OP_Asub :
	case OP_Amul :
	case OP_Adiv :
	case OP_Amod :
	case OP_Arshft :
	case OP_Alshft :
	case OP_Aand :
	case OP_Aor :
	case OP_Axor :
	case OP_call :
	    return 0;
	case OP_var :
	case OP_enum :
	case OP_int :
	case OP_real :
	/* BCC - 8/3/96 */
	case OP_float:
	/* BCC - 8/3/96 */
	case OP_double:
	case OP_char : 
	case OP_string :
	case OP_expr_size :
	case OP_type_size :
	    return UselessExpr(expr->next);
	default :
	    for (i=1; (op=GetOperand(expr, i)) != 0; i++)
		result &= UselessExpr(op);
	    return result & UselessExpr(expr->next);
    }
}

static UselessExprNode(expr)
Expr expr;
{
    int result = 1;
    int i;
    Expr op;

    if (expr == 0) return 1;
    switch (expr->opcode) {
	case OP_postinc :
	case OP_postdec :
	case OP_preinc :
	case OP_predec :
	case OP_assign :
	case OP_Aadd :
	case OP_Asub :
	case OP_Amul :
	case OP_Adiv :
	case OP_Amod :
	case OP_Arshft :
	case OP_Alshft :
	case OP_Aand :
	case OP_Aor :
	case OP_Axor :
	case OP_call :
	    return 0;
	case OP_var :
	case OP_enum :
	case OP_int :
	case OP_real :
	case OP_float:
	case OP_double:
	case OP_char : 
	case OP_string :
	case OP_expr_size :
	case OP_type_size :
	    return 1;
	default :
	    for (i=1; (op=GetOperand(expr, i)) != 0; i++)
		result &= UselessExpr(op);
	    return result;
    }
}

static void UpdateUselessVarTable(expr)
Expr expr;
{
    int i;
    int dummy, dummy_ptr;
    Expr op;

    if (expr == NULL) return;
    for (i=1; (op=GetOperand(expr, i)) != 0; i++)
	UpdateUselessVarTable(op);
    UpdateUselessVarTable(expr->next);
    /* BCC - if the var type is a structure, don't delete it - 6/3/97 */
    if (expr->opcode == OP_var && IsPcodeTemp(expr) && !IsStructureType(expr->type)) {
	if (!C_find(useless_var_table_ID, expr->value.var_name, 0, 
	    &dummy, (Pointer *) &dummy_ptr)) { 
	    C_update(useless_var_table_ID, 
		C_findstr(expr->value.var_name), 0, 0, 0);
	}
    }
}

bool IsUselessVar(expr, str) 
Expr expr;
char *str;
{
    int dummy;
    int *dummy_ptr;

    if (useless_var_table_ID == 0) return FALSE;
    if (expr && str == NULL) {
	if (expr->opcode != OP_var) return FALSE;
	if (C_find(useless_var_table_ID, expr->value.var_name, 0, &dummy,
	    (Pointer *) &dummy_ptr))  
	    return (dummy == 0) ? TRUE : FALSE;
	else 
	    return FALSE;
    }
    else if (expr == NULL && str) {
	if (C_find(useless_var_table_ID, str, 0, &dummy,
	    (Pointer *) &dummy_ptr))  
	    return (dummy == 0) ? TRUE : FALSE;
	else 
	    return FALSE;
    }
    else return FALSE;
}

static Expr CompressExprList(expr, last, keep)
Expr expr;
int last; /* always keep the last expr */
int keep; /* compress it, but still keep the declaration */
{
    Expr pointer, header, tail, temp; 
    int dummy, dummy_ptr;

    header = tail = NULL;
    if (expr->opcode == OP_compexpr && expr->next == NULL) {
	expr->operands = CompressExprList(expr->operands, last);
	if (expr->operands == NULL) {
	    RemoveExpr(expr);
	    return NULL;
	}
	else return expr;
    }
    pointer = expr;
    while (pointer) {
	if ((last == 1 && pointer->next == NULL) || !UselessExprNode(pointer)) {
	    if (header == NULL) {
		header = tail = pointer;
	    }
	    else {
		tail->next = pointer;
		tail = tail->next;
	    }
	    pointer = pointer->next;
	}
	else {
	    temp = pointer->next;
	    pointer->next = 0;
	    if (keep == 0) 
		UpdateUselessVarTable(pointer); 
#if 0
	    if (pointer->opcode == OP_var && IsPcodeTemp(pointer) && keep==0) {
		if (!C_find(useless_var_table_ID, pointer->value.var_name, 0, 
		    &dummy, (Pointer *) &dummy_ptr)) { 
		    C_update(useless_var_table_ID, 
			C_findstr(pointer->value.var_name), 0, 0, 0);
		}
	    }
#endif
	    RemoveExpr(pointer);
	    pointer = temp;
	}
    }
    if (tail) tail->next = 0;
    return header;
}

static void Break2Goto(stmts, label_name, changed)
Stmt stmts;
char *label_name;
int *changed;
{
    SerLoop serloop;
    ParLoop parloop;
    Stmt assign, goto_stmt;

    while (stmts != NIL) {
        switch (stmts->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
            case ST_EXPR:
            case ST_RETURN:
            case ST_SERLOOP:
            case ST_PARLOOP:
	    /* 
	     * BCC - 2/3/97
	     * Since the break in switch statements is not related to the 
	     * enclosing loops, it should not be changed into goto.
	     */
            case ST_SWITCH:
                break;
            case ST_BREAK:
		/* replaced by a goto */
		stmts->type = ST_GOTO;
		/* BCC - memory reuse bug fix - 11/11/96 */
		stmts->stmtstruct.label = strdup(label_name);
		*changed = 1;
                break;
            case ST_COMPOUND:
                Break2Goto(stmts->stmtstruct.compound->stmt_list, label_name,
			   changed);
                break;
            case ST_IF:
                Break2Goto(stmts->stmtstruct.ifstmt->then_block, label_name,
			   changed);
                if (stmts->stmtstruct.ifstmt->else_block != NIL)
                    Break2Goto(stmts->stmtstruct.ifstmt->else_block, label_name,
			       changed);
                break;
            case ST_PSTMT:
                Break2Goto(stmts->stmtstruct.pstmt->stmt, label_name, changed);
                break;
            case ST_MUTEX:
                Break2Goto(stmts->stmtstruct.mutex->statement, label_name,
			   changed);
                break;
            case ST_COBEGIN:
                Break2Goto(stmts->stmtstruct.cobegin->statements, label_name,
			   changed);
                break;
            case ST_BODY:
                Break2Goto(stmts->stmtstruct.bodystmt->statement, label_name,
			   changed);
                break;
            case ST_EPILOGUE:
                Break2Goto(stmts->stmtstruct.epiloguestmt->statement, 
                              label_name, changed);
                break;
            default:
                Punt("Break2Goto: Invalid statement type", stmts);
        }
        stmts = stmts->lex_next;
    }
}

static void Continue2Goto(stmts, label_name, changed)
Stmt stmts;
char *label_name;
int *changed;
{
    SerLoop serloop;
    ParLoop parloop;
    Stmt assign, goto_stmt;

    while (stmts != NIL) {
        switch (stmts->type) {
            case ST_NOOP:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
            case ST_EXPR:
            case ST_RETURN:
            case ST_SERLOOP:
            case ST_PARLOOP:
                break;
            case ST_CONT:
		/* replaced by a goto */
		stmts->type = ST_GOTO;
		/* BCC - memory reuse bug fix - 11/11/96 */
		stmts->stmtstruct.label = strdup(label_name);
		*changed = 1;
                break;
            case ST_COMPOUND:
                Continue2Goto(stmts->stmtstruct.compound->stmt_list, label_name,
			      changed);
                break;
            case ST_IF:
                Continue2Goto(stmts->stmtstruct.ifstmt->then_block, label_name,
			      changed);
                if (stmts->stmtstruct.ifstmt->else_block != NIL)
                    Continue2Goto(stmts->stmtstruct.ifstmt->else_block, 
				  label_name, changed);
                break;
            case ST_SWITCH:
                Continue2Goto(stmts->stmtstruct.switchstmt->switchbody, 
			      label_name, changed) ;
                break;
            case ST_PSTMT:
                Continue2Goto(stmts->stmtstruct.pstmt->stmt, label_name, 
			      changed);
                break;
            case ST_MUTEX:
                Continue2Goto(stmts->stmtstruct.mutex->statement, label_name,
			      changed);
                break;
            case ST_COBEGIN:
                Continue2Goto(stmts->stmtstruct.cobegin->statements, label_name,
			      changed);
                break;
            case ST_BODY:
                Continue2Goto(stmts->stmtstruct.bodystmt->statement, label_name,
			      changed);
                break;
            case ST_EPILOGUE:
                Continue2Goto(stmts->stmtstruct.epiloguestmt->statement, 
                              label_name, changed);
                break;
            default:
                Punt("Continue2Goto: Invalid statement type", stmts);
        }
        stmts = stmts->lex_next;
    }
}

static int ReachThrough(stmt)
Stmt stmt;
{
    Stmt stmt1, stmt2;

    if (stmt == 0) return 1;
    switch (stmt->type) {
	case ST_CONT:
	case ST_BREAK:
	case ST_GOTO:
	case ST_RETURN:
	    return 0;
	case ST_COMPOUND: 
	    stmt1 = stmt->stmtstruct.compound->stmt_list;
	    if (stmt1 == NULL) return 1;
	    while (stmt1->lex_next)
		stmt1 = stmt1->lex_next;
	    return ReachThrough(stmt1);
	case ST_IF:
	    stmt1 = stmt->stmtstruct.ifstmt->then_block;
	    stmt2 = stmt->stmtstruct.ifstmt->else_block;
	    return (ReachThrough(stmt1) || ReachThrough(stmt2));
	default:
	    return 1;
    }
}

static void RestructureIfStmt(stmts, group)
Stmt stmts;
int group;
{
    Expr cond_expr, not_expr, op1, op2;
    Stmt newstmt;
    Stmt first_true, last_true, first_false, last_false;
    Stmt true_part, false_part;
    Stmt go_out, lex_next;
    Stmt if1, if2;
    Label label;
    Pragma pragma, pragma1, pragma2;
    char pragma_string[512];
    char *func_name;
    char true_label[256], false_label[256], out_label[256];
    int i;

    cond_expr = SearchThroughParenthesis(stmts->stmtstruct.ifstmt->cond_expr, 
					 OP_conj);
    if (cond_expr == NULL)
	cond_expr=SearchThroughParenthesis(stmts->stmtstruct.ifstmt->cond_expr,
					   OP_disj);
    if (cond_expr) {
	if (stmts->stmtstruct.ifstmt->then_block->type != ST_COMPOUND) {
	    Create_Encl_Compd_IfNeeded(stmts->stmtstruct.ifstmt->then_block);
	}
	if (stmts->stmtstruct.ifstmt->else_block != NIL) {
	    if (stmts->stmtstruct.ifstmt->else_block->type != ST_COMPOUND) {
	       Create_Encl_Compd_IfNeeded(stmts->stmtstruct.ifstmt->else_block);
	    }
	} else {
	    newstmt = NewStmt();
	    newstmt->type = ST_NOOP;
	    stmts->stmtstruct.ifstmt->else_block = newstmt;
	    LinkStmtsRt(stmts->stmtstruct.ifstmt->else_block, stmts, 0);
	    Create_Encl_Compd_IfNeeded(newstmt);
	}

	true_part = stmts->stmtstruct.ifstmt->then_block;
	if (true_part->stmtstruct.compound->stmt_list == NULL) {
	    newstmt = NewStmt();
	    newstmt->type = ST_NOOP;
	    true_part->stmtstruct.compound->stmt_list = newstmt;
	    LinkStmtsRt(true_part->stmtstruct.compound->stmt_list,true_part,0);
	}
	first_true = true_part->stmtstruct.compound->stmt_list;
	last_true = first_true;
	while (last_true->lex_next)
	    last_true = last_true->lex_next;
	false_part = stmts->stmtstruct.ifstmt->else_block;
	if (false_part->stmtstruct.compound->stmt_list == NULL) {
	    newstmt = NewStmt();
	    newstmt->type = ST_NOOP;
	    false_part->stmtstruct.compound->stmt_list = newstmt;
	    LinkStmtsRt(false_part->stmtstruct.compound->stmt_list,
			false_part, 0);
	}
	first_false = false_part->stmtstruct.compound->stmt_list;
	last_false = first_false;
	while (last_false->lex_next)
	    last_false = last_false->lex_next;

	stmts->type = ST_NOOP;
	Insert_Stmt_After(stmts, true_part);
	Insert_Stmt_After(true_part, false_part);
	lex_next = false_part->lex_next;

	func_name = currentF->name;

	sprintf(true_label, "P_true_%d_%s___%d", 
		label_counter,func_name,true_part->stmtstruct.compound->scope);
	sprintf(false_label, "P_false_%d_%s___%d", 
		label_counter,func_name,false_part->stmtstruct.compound->scope);
	sprintf(out_label, "P_out_%d_%s___%d",
		label_counter++, func_name, 
		label_scope_stack[label_scope_index+1]);
	label = NewLabel();
	label->type = LB_LABEL;
	label->val = strdup(true_label);
	AddStmtLabel(first_true, label);
	label = NewLabel();
	label->type = LB_LABEL;
	label->val = strdup(false_label);
	AddStmtLabel(first_false, label);
	/* BCC - 12/01/96
	 * if the last statement in the true part is an unconditional jump,
	 * there is no need to insert the goto statement thereafter.
	 */
	if (ReachThrough(last_true)) {
	    if (lex_next == NULL) {
		lex_next = NewStmt();
		lex_next->type = ST_NOOP;
		Insert_Stmt_After(false_part, lex_next);
	    }
	    label = NewLabel();
	    label->type = LB_LABEL;
	    label->val = strdup(out_label);
	    /* lex_next now is the next non-compound statement */
	    while (lex_next->type == ST_COMPOUND && 
		   lex_next->stmtstruct.compound->stmt_list)
		lex_next = lex_next->stmtstruct.compound->stmt_list;
	    /* empty compound statement found */
	    if (lex_next->type == ST_COMPOUND)
		lex_next->type = ST_NOOP;
	    AddStmtLabel(lex_next, label);

	    go_out = NewStmt();
	    go_out->type = ST_GOTO;
	    go_out->stmtstruct.label = strdup(out_label);
	    Insert_Stmt_After(last_true, go_out);
	}

	if (cond_expr->opcode == OP_conj) {
	    op1 = CopyExpr(cond_expr->operands);
	    op2 = CopyExpr(cond_expr->operands->sibling);
	    RemoveExpr(stmts->stmtstruct.ifstmt->cond_expr);
	    stmts->stmtstruct.ifstmt->cond_expr = 0;
	    stmts->stmtstruct.ifstmt->then_block = 0;
	    stmts->stmtstruct.ifstmt->else_block = 0;
	    RemoveIfStmt(stmts->stmtstruct.ifstmt);

	    if1 = NewStmt();
	    if2 = NewStmt();

	    /* BCC - 4/13/97 */
	    pragma = FindStmtPragma(stmts, "\"EMPTYLOOP\"");
	    if (pragma) {
		AddPragmaToStatement(if1, CopyPragma(pragma, 0));
		AddPragmaToStatement(if2, CopyPragma(pragma, 0));
            }

	    pragma = FindStmtPragma(stmts, "\"CONJDISJ\"");
	    if (pragma) {
		sprintf(pragma_string, "\"c%d%s", 
		    conj_disj_sequence++, pragma->expr->value.string+1);
		AddStatementPragma(if1, 
		    strdup("\"CONJDISJ\""), 
		    NewStringExpr(strdup(pragma_string)));
		sprintf(pragma_string, "\"c%d%s", 
		    conj_disj_sequence++, pragma->expr->value.string+1);
		AddStatementPragma(if2, 
		    strdup("\"CONJDISJ\""), 
		    NewStringExpr(strdup(pragma_string)));
		RemoveStmtPragma(stmts, pragma);
	    }
	    else {
		sprintf(pragma_string, "\"c%d_%d\"", 
		    conj_disj_sequence++, group);
		AddStatementPragma(if1, 
		    strdup("\"CONJDISJ\""), 
		    NewStringExpr(strdup(pragma_string)));
		sprintf(pragma_string, "\"c%d_%d\"", 
		    conj_disj_sequence++, group);
		AddStatementPragma(if2, 
		    strdup("\"CONJDISJ\""), 
		    NewStringExpr(strdup(pragma_string)));
	    }
	    /* BCC - added ifelse pragmas - 1/2/97 */
	    pragma = FindStmtPragma(stmts, "\"IFELSE\"");
	    if (pragma) {
		AddPragmaToStatement(if1, CopyPragma(pragma, 0));
		AddPragmaToStatement(if2, CopyPragma(pragma, 0));
            }
	    if1->type = ST_IF;
	    if2->type = ST_IF;
	    if1->stmtstruct.ifstmt = NewIfStmt();
	    if2->stmtstruct.ifstmt = NewIfStmt();
	    if1->stmtstruct.ifstmt->cond_expr = op1;
	    if2->stmtstruct.ifstmt->cond_expr = op2;
	    if1->stmtstruct.ifstmt->then_block = if2;
	    /* LCW - propagate the line number, column number and file name
	       of the base statement to the new ones - 7/31/97 */
	    if1->lineno = if2->lineno = stmts->lineno;
	    if1->colno = if2->colno = stmts->colno;
	    /* LCW - propagate file name only when it is not NULL - 8/19/97 */
	    if (stmts->filename != NULL) {
	       if1->filename = strdup(stmts->filename);
	       if2->filename = strdup(stmts->filename);
	    }
	    else {
	       if1->filename = strdup("\"_no_file_name_\"");
	       if2->filename = strdup("\"_no_file_name_\"");
	    }
	    newstmt = NewStmt();
	    newstmt->type = ST_GOTO;
	    newstmt->stmtstruct.label = strdup(true_label);
	    if2->stmtstruct.ifstmt->then_block = newstmt;
	    newstmt = NewStmt();
	    newstmt->type = ST_GOTO;
	    newstmt->stmtstruct.label = strdup(false_label);
	    if1->stmtstruct.ifstmt->else_block = newstmt;
	    newstmt = NewStmt();
	    newstmt->type = ST_GOTO;
	    newstmt->stmtstruct.label = strdup(false_label);
	    if2->stmtstruct.ifstmt->else_block = newstmt;
	    LinkStmtsRt(if1, stmts->parent, stmts);
	    Insert_Stmt_After(stmts, if1);
	    RestructureIfStmt(if2, group);
	    RestructureIfStmt(if1, group);
	    return;
	}
	else if (cond_expr->opcode == OP_disj) {
	    op1 = CopyExpr(cond_expr->operands);
	    op2 = CopyExpr(cond_expr->operands->sibling);
	    RemoveExpr(stmts->stmtstruct.ifstmt->cond_expr);
	    stmts->stmtstruct.ifstmt->cond_expr = 0;
	    stmts->stmtstruct.ifstmt->then_block = 0;
	    stmts->stmtstruct.ifstmt->else_block = 0;
	    RemoveIfStmt(stmts->stmtstruct.ifstmt);
	    if1 = NewStmt();
	    if2 = NewStmt();

	    /* BCC - 4/13/97 */
	    pragma = FindStmtPragma(stmts, "\"EMPTYLOOP\"");
	    if (pragma) {
		AddPragmaToStatement(if1, CopyPragma(pragma, 0));
		AddPragmaToStatement(if2, CopyPragma(pragma, 0));
            }

	    pragma = FindStmtPragma(stmts, "\"CONJDISJ\"");
	    if (pragma) {
		sprintf(pragma_string, "\"d%d%s", 
		    conj_disj_sequence++, pragma->expr->value.string+1);
		AddStatementPragma(if1, 
		    strdup("\"CONJDISJ\""), 
		    NewStringExpr(strdup(pragma_string)));
		sprintf(pragma_string, "\"d%d%s", 
		    conj_disj_sequence++, pragma->expr->value.string+1);
		AddStatementPragma(if2, 
		    strdup("\"CONJDISJ\""), 
		    NewStringExpr(strdup(pragma_string)));
		RemoveStmtPragma(stmts, pragma);
	    }
	    else {
		sprintf(pragma_string, "\"d%d_%d\"", 
		    conj_disj_sequence++, group);
		AddStatementPragma(if1, 
		    strdup("\"CONJDISJ\""), 
		    NewStringExpr(strdup(pragma_string)));
		sprintf(pragma_string, "\"d%d_%d\"", 
		    conj_disj_sequence++, group);
		AddStatementPragma(if2, 
		    strdup("\"CONJDISJ\""), 
		    NewStringExpr(strdup(pragma_string)));
	    }
	    /* BCC - added ifelse pragmas - 1/2/97 */
	    pragma = FindStmtPragma(stmts, "\"IFELSE\"");
	    if (pragma) {
		AddPragmaToStatement(if1, CopyPragma(pragma, 0));
		AddPragmaToStatement(if2, CopyPragma(pragma, 0));
            }
	    if1->type = ST_IF;
	    if2->type = ST_IF;
	    if1->stmtstruct.ifstmt = NewIfStmt();
	    if2->stmtstruct.ifstmt = NewIfStmt();
	    if1->stmtstruct.ifstmt->cond_expr = op1;
	    if2->stmtstruct.ifstmt->cond_expr = op2;
	    /* LCW - propagate the line number, column number and file name
               of the base statement to the new ones - 7/31/97 */
            if1->lineno = if2->lineno = stmts->lineno;
            if1->colno = if2->colno = stmts->colno;
	    /* LCW - propagate file name only when it is not NULL - 8/19/97 */
	    if (stmts->filename != NULL) {
               if1->filename = strdup(stmts->filename);
               if2->filename = strdup(stmts->filename);
	    }
	    else {
	       if1->filename = strdup("\"_no_file_name_\"");
	       if2->filename = strdup("\"_no_file_name_\"");
	    }
	    newstmt = NewStmt();
	    newstmt->type = ST_GOTO;
	    newstmt->stmtstruct.label = strdup(true_label);
	    if1->stmtstruct.ifstmt->then_block = newstmt;
	    newstmt = NewStmt();
	    newstmt->type = ST_GOTO;
	    newstmt->stmtstruct.label = strdup(true_label);
	    if2->stmtstruct.ifstmt->then_block = newstmt;
	    if1->stmtstruct.ifstmt->else_block = if2;
	    newstmt = NewStmt();
	    newstmt->type = ST_GOTO;
	    newstmt->stmtstruct.label = strdup(false_label);
	    if2->stmtstruct.ifstmt->else_block = newstmt;
	    LinkStmtsRt(if1, stmts->parent, stmts);
	    Insert_Stmt_After(stmts, if1);
	    RestructureIfStmt(if2, group);
	    RestructureIfStmt(if1, group);
	    return;
	}
    }
    else {
	not_expr=SearchThroughParenthesis(stmts->stmtstruct.ifstmt->cond_expr,
					   OP_not);
	if (not_expr) {
	    cond_expr = SearchThroughParenthesis(not_expr->operands, OP_not);
	    if (cond_expr) {
		op1 = CopyExpr(GetOperand(cond_expr, 1));
		RemoveExpr(stmts->stmtstruct.ifstmt->cond_expr);
		stmts->stmtstruct.ifstmt->cond_expr = op1;
		LinkExpr(stmts->stmtstruct.ifstmt->cond_expr, stmts, 0, 0);
		RestructureIfStmt(stmts, group);
		return;
	    }
	    cond_expr = SearchThroughParenthesis(not_expr->operands, OP_conj);
	    if (cond_expr) {
		op1 = NewExpr(OP_not);
		AddOperand(op1, CopyExpr(GetOperand(cond_expr, 1)));
		CastExpr(op1);
		op2 = NewExpr(OP_not);
		AddOperand(op2, CopyExpr(GetOperand(cond_expr, 2)));
		CastExpr(op2);
		cond_expr = NewExpr(OP_disj);
		AddOperand(cond_expr, op1);
		AddOperand(cond_expr, op2);
		CastExpr(cond_expr);
		RemoveExpr(stmts->stmtstruct.ifstmt->cond_expr);
		stmts->stmtstruct.ifstmt->cond_expr = cond_expr;
		LinkExpr(stmts->stmtstruct.ifstmt->cond_expr, stmts, 0, 0);
		RestructureIfStmt(stmts, group);
		return;
	    }
	    cond_expr = SearchThroughParenthesis(not_expr->operands, OP_disj);
	    if (cond_expr) {
		op1 = NewExpr(OP_not);
		AddOperand(op1, CopyExpr(GetOperand(cond_expr, 1)));
		CastExpr(op1);
		op2 = NewExpr(OP_not);
		AddOperand(op2, CopyExpr(GetOperand(cond_expr, 2)));
		CastExpr(op2);
		cond_expr = NewExpr(OP_conj);
		AddOperand(cond_expr, op1);
		AddOperand(cond_expr, op2);
		CastExpr(cond_expr);
		RemoveExpr(stmts->stmtstruct.ifstmt->cond_expr);
		stmts->stmtstruct.ifstmt->cond_expr = cond_expr;
		LinkExpr(stmts->stmtstruct.ifstmt->cond_expr, stmts, 0, 0);
		RestructureIfStmt(stmts, group);
		return;
	    }
	}
    }
    RestructureStmts(stmts->stmtstruct.ifstmt->then_block);
    if (stmts->stmtstruct.ifstmt->else_block)
	RestructureStmts(stmts->stmtstruct.ifstmt->else_block);
}

static void FlattenStmts(stmts)
Stmt stmts;
{
    SerLoop serloop;
    ParLoop parloop;
    int old_scope;

    while (stmts != NIL) {
        switch (stmts->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
		break;
            case ST_RETURN: 
		if (stmts->stmtstruct.ret) {
		    Expr result;

		    result = GenerateExpr(stmts, stmts->stmtstruct.ret, 0);
/*
		    UndeleteUselessVar(result, NULL);
*/
		    RemoveExpr(stmts->stmtstruct.ret);
		    /* BCC - compress expr list - 1/23/97 */
		    stmts->stmtstruct.ret = CompressExprList(result, 1, 0);
                    /* BCC - relinke parent exprs 10/22/97 */
                    LinkExpr(stmts->stmtstruct.ret, stmts, 0, 0);
		    break;
		}
                break;
            case ST_COMPOUND:
		old_scope = scope;
		scope = stmts->stmtstruct.compound->scope;
                FlattenStmts(stmts->stmtstruct.compound->stmt_list);
		scope = old_scope;
                break;
            case ST_IF: {
		Expr result, temp;
		Expr cond_expr;

		result = GenerateExpr(stmts, 
				      stmts->stmtstruct.ifstmt->cond_expr, 0);
/*
		UndeleteUselessVar(result, NULL);
*/
		RemoveExpr(stmts->stmtstruct.ifstmt->cond_expr);
		/* BCC - compress expr list - 1/23/97 */
		stmts->stmtstruct.ifstmt->cond_expr = 
		    CompressExprList(result, 1, 0);
                /* BCC - relinke parent exprs 10/22/97 */
                LinkExpr(stmts->stmtstruct.ifstmt->cond_expr, stmts, 0, 0);
		FlattenStmts(stmts->stmtstruct.ifstmt->then_block);
		if (stmts->stmtstruct.ifstmt->else_block != NIL)
		    FlattenStmts(stmts->stmtstruct.ifstmt->else_block);
		break;
	    }
            case ST_SWITCH: {
		Expr result;

		result = GenerateExpr(stmts, 
				stmts->stmtstruct.switchstmt->expression, 0);
/*
		UndeleteUselessVar(result, NULL);
*/
		RemoveExpr(stmts->stmtstruct.switchstmt->expression);
		/* BCC - compress expr list - 1/23/97 */
		stmts->stmtstruct.switchstmt->expression = 
		    CompressExprList(result, 1, 0);
                /* BCC - relinke parent exprs 10/22/97 */
                LinkExpr(stmts->stmtstruct.switchstmt->expression, stmts, 0, 0);
                FlattenStmts(stmts->stmtstruct.switchstmt->switchbody);
                break;
	    }
            case ST_EXPR: 
		{
		    Expr result,expr;
		    int keep = 0;

		    expr = stmts->stmtstruct.expr;
		    if (expr->opcode == OP_assign)
			keep = IsPcodeTemp(expr->operands);
		    if (expr->opcode == OP_call && expr->next == NIL) {
		    /* 
		     * BCC - HtoL can not handle a function which returns a 
		     * structure without a lvar. That is, foo1() can not be 
		     * handled unless it becomes temp = foo1() if foo1 returns 
		     * a structure - 7/9/96 
		     */
			if (!IsStructureType(expr->type))
			    expr->status &= ~F_BREAK;
		    }
		    result = GenerateExpr(stmts, stmts->stmtstruct.expr, 0);
		    RemoveExpr(stmts->stmtstruct.expr);
		    /* BCC - compress expr list first - 1/23/97 */
		    result = CompressExprList(result, 0, keep);
		    /* 
		     * Don't link useless expresstions to stmt
		     */
		    if (UselessExpr(result)) {
			stmts->type = ST_NOOP;
			stmts->stmtstruct.expr = 0;
			/* BCC - garbage collection - 8/19/96 */
			RemoveExpr(result);
		    }
		    else {
			stmts->stmtstruct.expr = result;
                        /* BCC - relinke parent exprs 10/22/97 */
                        LinkExpr(stmts->stmtstruct.expr, stmts, 0, 0);
		    }
		}
		break;
            case ST_PSTMT:
                FlattenStmts(stmts->stmtstruct.pstmt->stmt);
                break;
            case ST_MUTEX:
                FlattenStmts(stmts->stmtstruct.mutex->statement);
                break;
            case ST_COBEGIN:
                FlattenStmts(stmts->stmtstruct.cobegin->statements);
                break;
            case ST_SERLOOP: 
                serloop = stmts->stmtstruct.serloop;
		FlattenStmts(serloop->loop_body);
                break;
            case ST_PARLOOP:
                parloop = stmts->stmtstruct.parloop;
                FlattenStmts(Parloop_Stmts_Prologue_Stmt(stmts));
                break;
            case ST_BODY:
                FlattenStmts(stmts->stmtstruct.bodystmt->statement);
                break;
            case ST_EPILOGUE:
                FlattenStmts(stmts->stmtstruct.epiloguestmt->statement);
                break;
            default:
                Punt("FlattenStmts: Invalid statement type", stmts);
        }
        stmts = stmts->lex_next;
    }
}

static void RestructureStmts(stmts)
Stmt stmts;
{
    SerLoop serloop;
    ParLoop parloop;
    int old_scope;

    while (stmts != NIL) {
        switch (stmts->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
            case ST_RETURN: 
            case ST_EXPR: 
		break;
            case ST_COMPOUND:
		old_scope = scope;
		scope = stmts->stmtstruct.compound->scope;
                RestructureStmts(stmts->stmtstruct.compound->stmt_list);
		scope = old_scope;
                break;
            case ST_IF: 
		RestructureIfStmt(stmts, conj_disj_counter++);
		break;
            case ST_SWITCH: 
                RestructureStmts(stmts->stmtstruct.switchstmt->switchbody);
                break;
            case ST_PSTMT:
                RestructureStmts(stmts->stmtstruct.pstmt->stmt);
                break;
            case ST_MUTEX:
                RestructureStmts(stmts->stmtstruct.mutex->statement);
                break;
            case ST_COBEGIN:
                RestructureStmts(stmts->stmtstruct.cobegin->statements);
                break;

/*******************************************************************************
 * RestructureStmts a FOR loop:
 * Old loop : 
 * 	for ( i = foo1(); i < foo2(); i+= foo3()) {
 *		foo4();
 *		if (i == 5) continue;
 *              if (i == 6) break;
 *	}
 *
 * New loop : 
 *	t1 = foo1();
 * 	{
 *		if (i < foo2()) {
 *      FOR1:       	foo4();
 *			if (i == 5) goto CONTINUE_1;
 *			if (i == 6) goto EXIT_1;
 *	CONTINUE_1 : 
 *			i += foo3();
 *			if (i < foo2()) goto FOR1;
 *              }
 *	}
 *      EXIT_1:
 * 
 * RestructureStmts a WHILE loop:
 * Old loop : 
 * 	while (i < foo2()) {
 *		foo4();
 *		if (i == 5) continue;
 *              if (i == 6) break;
 *	}
 *
 * New loop : 
 * 	{
 *		if (i < foo2()) {
 *	WHILE1:		foo4();
 *			if (i == 5) goto CONTINUE_1;
 *			if (i == 6) goto EXIT_1;
 *			if (i < foo2()) goto WHILE1;
 *		}
 *	}
 *      EXIT_1:
 * 
 * RestructureStmts a DO loop:
 * Old loop : 
 * 	do {
 *		foo4();
 *		if (i == 5) continue;
 *		if (i == 6) break;;
 *	} while ( i < foo2() );
 *
 * New loop : 
 * 	{
 *	DO1:	foo4();
 *		if (i == 5) goto CONTINUE_1;
 *		if (i == 6) goto EXIT_1;
 *	CONTINUE_1 :
 *		if (i < foo2()) goto DO1;
 *	} 
 *      EXIT_1:
 * 
 ******************************************************************************/

            case ST_SERLOOP: {
		Expr result, not, compexpr, cond_expr, iter_expr, init_expr;
		char cont_label[256], head_label[256], exit_label[256];
		Stmt new_stmt, gt, loop_body;
		IfStmt new_if;
		Label label;
		int cont_changed, break_changed;
		int empty_loop = 0;

                serloop = stmts->stmtstruct.serloop;
		if (serloop->loop_type == LT_FOR) {
		    if ( (serloop->init_expr && 
			  (serloop->init_expr->status & F_CONTAIN_BREAK)) ||
		         (serloop->cond_expr && 
			  (serloop->cond_expr->status & F_CONTAIN_BREAK)) ||
		         (serloop->iter_expr && 
			  (serloop->iter_expr->status & F_CONTAIN_BREAK)) ) {
			if (DEBUG_FLATTENING) {
			    fprintf(Flog, 
				    "Restructuring a FOR loop near line %d\n", 
				    stmts->lineno);
			}
			init_expr = serloop->init_expr;
			cond_expr = serloop->cond_expr;
			iter_expr = serloop->iter_expr;
			if (init_expr) 
			    AddStmt(stmts, init_expr);
                        loop_body = serloop->loop_body;
                        if (loop_body == NULL) {
                            loop_body = NewStmt();
                            loop_body->type = ST_NOOP;
                        }
			if (loop_body->type == ST_NOOP)
			    empty_loop = 1;
                        stmts->type = ST_COMPOUND;
			new_stmt = NewStmt();
			new_stmt->type = ST_IF;

			/* BCC - add pragmas for empty loop - 4/14/97 */
			if (empty_loop)
			    AddStatementPragma(new_stmt, 
					       strdup("\"EMPTYLOOP\""), 
					       NewIntExpr(0));

			AddStatementPragma(loop_body, strdup("\"FOR\""), 
					   NewIntExpr(stmts->lineno));

                        new_if = NewIfStmt();
                        new_stmt->stmtstruct.ifstmt = new_if;
			if (cond_expr)
			    new_if->cond_expr = CopyExprList(cond_expr);
			else
			    new_if->cond_expr = NewIntExpr(1);
                        new_if->then_block = loop_body;
                        LinkStmtsRt(new_stmt->stmtstruct.ifstmt->then_block, 
				    new_stmt, 0);
                        LinkExpr(new_stmt->stmtstruct.ifstmt->cond_expr, 
				 new_stmt, 0, 0);
			stmts->stmtstruct.compound = NewCompound();
			stmts->stmtstruct.compound->stmt_list = new_stmt;
			stmts->stmtstruct.compound->var_list = 0;
			stmts->stmtstruct.compound->scope = NewScopeId();
			LinkStmtsRt(stmts->stmtstruct.compound->stmt_list,
				    stmts, 0);
                        /* replace every continue in the for loop with goto */
                        sprintf(cont_label, "P_CONTINUE%d___%d",
                                label_counter, scope);
                        sprintf(head_label, "P_FOR%d___%d",
                                label_counter,scope);
                        sprintf(exit_label, "P_EXIT%d___%d",
                                label_counter++,scope);
                        cont_changed = 0;
                        Continue2Goto(loop_body, cont_label, &cont_changed);
                        break_changed = 0;
                        Break2Goto(loop_body, exit_label, &break_changed);
                        /*
                         * Attatch the exit_label to the next statement
                         */
                        if (break_changed) {
                            label = NewLabel();
                            label->type = LB_LABEL;
                            label->val = strdup(exit_label);
                            if (stmts->lex_next) {
                                AddStmtLabel(stmts->lex_next, label);
                            }
                            else {
                                new_stmt = NewStmt();
                                new_stmt->type = ST_NOOP;
                                AddStmtLabel(new_stmt, label);
                                Insert_Stmt_After(stmts, new_stmt);
                            }
                        }
			if (cond_expr) {
			    /*
			     * Create a new stmt which is of type ST_IF
			     */
			    new_stmt = NewStmt();
			    /* BCC - add pragmas for empty loop - 4/14/97 */
			    if (empty_loop)
				AddStatementPragma(new_stmt, 
						   strdup("\"EMPTYLOOP\""), 
						   NewIntExpr(0));
			    new_stmt->type = ST_IF;
			    if (cont_changed) {
				label = NewLabel();
				label->type = LB_LABEL;
				label->val = strdup(cont_label);
				AddStmtLabel(new_stmt, label);
			    }
			    Insert_Stmt_After(loop_body, new_stmt);

			    /*
     			     * LCW - propagate the line number, column number 
			     *       and file name of the base statement to 
			     *       the new one. -- 10/8/96
     			     */
     			    new_stmt->lineno = stmts->lineno;
     			    new_stmt->colno = stmts->colno;
			    if (stmts->filename != NULL) {
			      new_stmt->filename = (char *)malloc(strlen(stmts->filename)+1);
			      strcpy(new_stmt->filename, stmts->filename);
			    }
			    else
			      new_stmt->filename = strdup("\"_no_file_name_\"");

			    /*
			     * Create the new IfStmt and connect it to new_stmt
			     */
			    new_if = NewIfStmt();
			    new_stmt->stmtstruct.ifstmt = new_if;
			    new_if->cond_expr = cond_expr;
			    gt = NewStmt();
			    gt->type = ST_GOTO;
			    new_if->then_block = gt;
			    gt->stmtstruct.label = strdup(head_label);
			    LinkStmtsRt(new_stmt->stmtstruct.ifstmt->then_block,
					new_stmt, 0);
			    LinkExpr(new_stmt->stmtstruct.ifstmt->cond_expr,
				     new_stmt, 0, 0);
			}
			else {
			    /* 
			     * Create a goto statement 
			     */
			    new_stmt = NewStmt();
			    new_stmt->type = ST_GOTO;
			    new_stmt->stmtstruct.label = strdup(head_label);
			    if (cont_changed) {
				label = NewLabel();
				label->type = LB_LABEL;
				label->val = strdup(cont_label);
				AddStmtLabel(new_stmt, label);
			    }
			    Insert_Stmt_After(loop_body, new_stmt);
			}
			label = NewLabel();
			label->type = LB_LABEL;
			label->val = strdup(head_label);
			AddStmtLabel(loop_body, label);
			if (iter_expr)
			    AddStmt(new_stmt, iter_expr);
			RestructureStmts(stmts->stmtstruct.compound->stmt_list);
			serloop->loop_body = NULL;
			serloop->cond_expr = NULL;
			serloop->init_expr = NULL;
			serloop->iter_expr = NULL;
			RemoveSerLoop(serloop);
		    }
		    else
			RestructureStmts(serloop->loop_body);
		}
		else if (serloop->loop_type == LT_WHILE) {
                    if ( (serloop->cond_expr) && 
			 (serloop->cond_expr->status & F_CONTAIN_BREAK) ) {
			if (DEBUG_FLATTENING) {
			    fprintf(Flog, 
				    "Restructuring a WHILE loop near line %d\n",
				    stmts->lineno);
			}
                        cond_expr = serloop->cond_expr;
                        loop_body = serloop->loop_body;
                        if (loop_body == NULL) {
                            loop_body = NewStmt();
                            loop_body->type = ST_NOOP;
                        }
			if (loop_body->type == ST_NOOP)
			    empty_loop = 1;
                        stmts->type = ST_COMPOUND;
			new_stmt = NewStmt();
			new_stmt->type = ST_IF;
			/* BCC - add pragmas for empty loop - 4/14/97 */
			if (empty_loop)
			    AddStatementPragma(new_stmt, 
					       strdup("\"EMPTYLOOP\""), 
					       NewIntExpr(0));
			AddStatementPragma(loop_body, strdup("\"WHILE\""), 
					   NewIntExpr(stmts->lineno));

		        /*
                         * LCW - propagate the line number, column number
                         *       and file name of the base statement to
                         *       the new one. -- 10/8/96
                         */
                        new_stmt->lineno = stmts->lineno;
                        new_stmt->colno = stmts->colno;
			if (stmts->filename != NULL) {
			  new_stmt->filename = (char *)malloc(strlen(stmts->filename)+1);
			  strcpy(new_stmt->filename, stmts->filename);
			}
			else
			  new_stmt->filename = strdup("\"_no_file_name_\"");

			new_if = NewIfStmt();
			new_stmt->stmtstruct.ifstmt = new_if;
			new_if->cond_expr = CopyExprList(cond_expr);;
			new_if->then_block = loop_body;
			LinkStmtsRt(new_stmt->stmtstruct.ifstmt->then_block, 
				    new_stmt, 0);
			LinkExpr(new_stmt->stmtstruct.ifstmt->cond_expr, 
				 new_stmt, 0, 0);
			stmts->stmtstruct.compound = NewCompound();
			stmts->stmtstruct.compound->stmt_list = new_stmt;
			stmts->stmtstruct.compound->var_list = 0;
			stmts->stmtstruct.compound->scope = NewScopeId();
			LinkStmtsRt(stmts->stmtstruct.compound->stmt_list,
				    stmts, 0);
                        /* replace every continue in the for loop with goto */
                        sprintf(cont_label, "P_CONTINUE%d___%d",
                                label_counter, scope);
                        sprintf(head_label, "P_WHILE%d___%d",
                                label_counter,scope);
                        sprintf(exit_label, "P_EXIT%d___%d",
                                label_counter++,scope);
                        cont_changed = 0;
                        Continue2Goto(loop_body, cont_label, &cont_changed);
                        break_changed = 0;
                        Break2Goto(loop_body, exit_label, &break_changed);
                        /*
                         * Attatch the exit_label to the next statement
                         */
                        if (break_changed) {
                            label = NewLabel();
                            label->type = LB_LABEL;
                            label->val = strdup(exit_label);
                            if (stmts->lex_next) {
                                AddStmtLabel(stmts->lex_next, label);
                            }
                            else {
                                new_stmt = NewStmt();
                                new_stmt->type = ST_NOOP;
                                AddStmtLabel(new_stmt, label);
                                Insert_Stmt_After(stmts, new_stmt);
                            }
                        }
                        /*
                         * Create a new stmt which is of type ST_IF
                         */
                        new_stmt = NewStmt();
                        new_stmt->type = ST_IF;
			/* BCC - add pragmas for empty loop - 4/14/97 */
			if (empty_loop)
			    AddStatementPragma(new_stmt, 
					       strdup("\"EMPTYLOOP\""), 
					       NewIntExpr(0));
                        if (cont_changed) {
                            label = NewLabel();
                            label->type = LB_LABEL;
                            label->val = strdup(cont_label);
                            AddStmtLabel(new_stmt, label);
                        }
                        Insert_Stmt_After(loop_body, new_stmt);
                        /*
                         * Create the new IfStmt and connect it to new_stmt
                         */
                        new_if = NewIfStmt();
                        new_stmt->stmtstruct.ifstmt = new_if;
                        /*
                         * Create the cond_expr
                         */
                        new_if->cond_expr = cond_expr;
                        gt = NewStmt();
                        gt->type = ST_GOTO;
                        new_if->then_block = gt;
                        gt->stmtstruct.label = strdup(head_label);
                        label = NewLabel();
                        label->type = LB_LABEL;
                        label->val = strdup(head_label);
                        AddStmtLabel(loop_body, label);
                        LinkStmtsRt(new_stmt->stmtstruct.ifstmt->then_block,
                                    new_stmt, 0);
                        LinkExpr(new_stmt->stmtstruct.ifstmt->cond_expr,
                                 new_stmt, 0, 0);
			RestructureStmts(stmts->stmtstruct.compound->stmt_list);
			serloop->loop_body = NULL;
			serloop->cond_expr = NULL;
			serloop->init_expr = NULL;
			serloop->iter_expr = NULL;
			RemoveSerLoop(serloop);
		    }
		    else
			RestructureStmts(serloop->loop_body);
                }
		else if (serloop->loop_type == LT_DO) {
                    if ( (serloop->cond_expr) && 
			 (serloop->cond_expr->status & F_CONTAIN_BREAK) ) {
			if (DEBUG_FLATTENING) {
			    fprintf(Flog, 
				    "Restructuring a DO loop near line %d\n",
				    stmts->lineno);
			}
			cond_expr = serloop->cond_expr;
			loop_body = serloop->loop_body;
			if (loop_body == NULL) {
			    loop_body = NewStmt();
			    loop_body->type = ST_NOOP;
			}
			if (loop_body->type == ST_NOOP)
			    empty_loop = 1;
			stmts->type = ST_COMPOUND;
			AddStatementPragma(loop_body, strdup("\"DO\""), 
					   NewIntExpr(stmts->lineno));
			stmts->stmtstruct.compound = NewCompound();
			stmts->stmtstruct.compound->stmt_list = loop_body;
			stmts->stmtstruct.compound->var_list = 0;
			stmts->stmtstruct.compound->scope = NewScopeId();
			LinkStmtsRt(loop_body, stmts, 0);
                        /* replace every continue in the for loop with goto */
                        sprintf(cont_label, "P_CONTINUE%d___%d", 
				label_counter, scope);
			sprintf(head_label, "P_DO%d___%d", 
				label_counter,scope);
			sprintf(exit_label, "P_EXIT%d___%d", 
				label_counter++,scope);
			cont_changed = 0;
			Continue2Goto(loop_body, cont_label, &cont_changed);
			break_changed = 0;
			Break2Goto(loop_body, exit_label, &break_changed);
			/* 
			 * Attatch the exit_label to the next statement 
			 */
			if (break_changed) {
			    label = NewLabel();
			    label->type = LB_LABEL;
			    label->val = strdup(exit_label);
			    if (stmts->lex_next) {
				AddStmtLabel(stmts->lex_next, label);
			    }
			    else {
				new_stmt = NewStmt();
				new_stmt->type = ST_NOOP;
				AddStmtLabel(new_stmt, label);
				Insert_Stmt_After(stmts, new_stmt);
			    }
			}
                        /*
                         * Create a new stmt which is of type ST_IF
                         */
                        new_stmt = NewStmt();
                        new_stmt->type = ST_IF;
			/* BCC - add pragmas for empty loop - 4/14/97 */
			if (empty_loop)
			    AddStatementPragma(new_stmt, 
					       strdup("\"EMPTYLOOP\""), 
					       NewIntExpr(0));
			if (cont_changed) {
			    label = NewLabel();
			    label->type = LB_LABEL;
			    label->val = strdup(cont_label);
			    AddStmtLabel(new_stmt, label);
			}
			Insert_Stmt_After(loop_body, new_stmt);
                        /*
                         * Create the new IfStmt and connect it to new_stmt
                         */
                        new_if = NewIfStmt();
                        new_stmt->stmtstruct.ifstmt = new_if;
                        /*
                         * Create the cond_expr
                         */
                        new_if->cond_expr = cond_expr;
                        gt = NewStmt();
                        gt->type = ST_GOTO;
                        new_if->then_block = gt;
			gt->stmtstruct.label = strdup(head_label);
                        label = NewLabel();
                        label->type = LB_LABEL;
                        label->val = strdup(head_label);
                        AddStmtLabel(loop_body, label);
                        LinkStmtsRt(new_stmt->stmtstruct.ifstmt->then_block,
                                    new_stmt, 0);
                        LinkExpr(new_stmt->stmtstruct.ifstmt->cond_expr,
                                 new_stmt, 0, 0);
			RestructureStmts(stmts->stmtstruct.compound->stmt_list);
			serloop->loop_body = NULL;
			serloop->cond_expr = NULL;
			serloop->init_expr = NULL;
			serloop->iter_expr = NULL;
			RemoveSerLoop(serloop);
                    }
		    else
			RestructureStmts(serloop->loop_body);
                }
                break;
	    }
            case ST_PARLOOP:
                parloop = stmts->stmtstruct.parloop;
                RestructureStmts(Parloop_Stmts_Prologue_Stmt(stmts));
                break;
            case ST_BODY:
                RestructureStmts(stmts->stmtstruct.bodystmt->statement);
                break;
            case ST_EPILOGUE:
                RestructureStmts(stmts->stmtstruct.epiloguestmt->statement);
                break;
            default:
                Punt("RestructureStmts: Invalid statement type", stmts);
        }
        stmts = stmts->lex_next;
    }
}

/*
 *      Read in the mapping file
 */
static ReadFunctionMap()
{
    LIST list, opcode;
    LIST ptr1, ptr2;
    char *op;
    char *funcname, *filename;
    FILE *fptr;

    fptr = fopen("impact_mapping", "rt");
    if (fptr != 0) {
	fclose(fptr);
	filename = "impact_mapping";
    }
    else {
	fptr = fopen("../impact_mapping", "rt");
	if (fptr != 0) {
	    fclose(fptr);
	    filename = "../impact_mapping";
	}
	else return 0;
    }
    if (lexOpen(filename, 0)==0)
	Punt("cannot open impact_mapping");
    /*
     *  Allocate a name mapping table
     */
    mapping_table_ID = C_open_name_table(2500);

/* mapping file format : (map (pcode/file.c foo) to (impact_dir1/f_0.pc foo)) */
    for (; (list=GetNode())!=0; DisposeNode(list)) {
        if (NodeType(list)==T_EOF) {
            DisposeNode(list);
            break;
        }
        if (NodeType(list)!=T_LIST)
            Punt("illegal mapping file : Parenthesis needed");
        opcode = ChildOf(list);
        op = StringOf(opcode);
        if (! strcmp(op, "map")) {
            ptr2 = SiblingOf(SiblingOf(SiblingOf(SiblingOf(opcode))));
            funcname = C_findstr(StringOf(SiblingOf(ChildOf(ptr2))));
            C_update(mapping_table_ID, funcname, 0, 0, 0);
        }
    }
    lexClose(filename);
}


/*
 *	reconstruct the function definition, so all
 *	&& || ?: are removed, and calls are moved to the
 *	top level.
 */
P_Flatten(func)
FuncDcl func;
{
    Expr expr;
    static int read_mapping_info;

    currentF = func;
    /* BCC - 7/11/96
     * add a pragma to show that this function has been flattened 
     */
    if (FindFunctionPragma(func, "\"flatten\"")) return; 
    if (read_mapping_info == 0) {
	read_mapping_info = 1;

    /* BCC - this turns out to be unsafe because HtoL needs every call
     * flattened even if source code is not available. John Sias found this
     * bug in 134.perl of the call to index()
     */
#if 0
	ReadFunctionMap();
#endif
	useless_var_table_ID = C_open_name_table(500);
    }
    /* BCC - garbage collection - 8/17/96 */
    expr = NewIntExpr(1);
    AddFunctionPragma(func, "\"flatten\"", expr);
    RemoveExpr(expr);
    VisitStmts(func->stmt);		
    RestructureStmts(func->stmt);
    VisitStmts(func->stmt);		
    FlattenStmts(func->stmt);		/* change "a, b, c" to "a; b; c;" */
    if (DEBUG_FLATTENING) {
	fprintf(Flog, "Max var id = %d\n", next_var_id);
    }
}

Clear_Useless_Var_Table()
{
    if (useless_var_table_ID)
	C_clear_free_all(useless_var_table_ID);
}

void Scale_Expr_Weight(expr, ratio)
Expr expr;
double ratio;
{
    ProfEXPR ptr;

    if (expr == NIL) return;
    ptr = expr->profile;
    while (ptr) {
	ptr->count *= ratio;
	ptr = ptr->next;
    }
    Scale_Expr_Weight(expr->operands, ratio);
    Scale_Expr_Weight(expr->sibling, ratio);
    Scale_Expr_Weight(expr->next, ratio);
}

void Scale_Stmt_Weight(stmt, ratio)
Stmt stmt;
double ratio;
{
    SerLoop serloop;
    ParLoop parloop;
    ProfST ptr;

    while (stmt != NIL) {
	ptr = stmt->profile;
	while (ptr != NIL) {
	    ptr->count *= ratio;
	    ptr = ptr->next;
	}
        switch (stmt->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
                break;
            case ST_RETURN:
		Scale_Expr_Weight(stmt->stmtstruct.ret, ratio);
		break;
            case ST_COMPOUND:
                Scale_Stmt_Weight(stmt->stmtstruct.compound->stmt_list, ratio);
                break;
            case ST_IF:
		Scale_Expr_Weight(stmt->stmtstruct.ifstmt->cond_expr, ratio);
                Scale_Stmt_Weight(stmt->stmtstruct.ifstmt->then_block, ratio);
                if (stmt->stmtstruct.ifstmt->else_block != NIL)
		    Scale_Stmt_Weight(stmt->stmtstruct.ifstmt->else_block,
				      ratio);
                break;
            case ST_SWITCH:
		Scale_Expr_Weight(stmt->stmtstruct.switchstmt->expression, 
				  ratio);
                Scale_Stmt_Weight(stmt->stmtstruct.switchstmt->switchbody, 
				  ratio);
                break;
            case ST_EXPR:
		Scale_Expr_Weight(stmt->stmtstruct.expr, ratio);
                break;
            case ST_PSTMT:
                Scale_Stmt_Weight(stmt->stmtstruct.pstmt->stmt, ratio);
		break;
            case ST_MUTEX:
                Scale_Expr_Weight(stmt->stmtstruct.mutex->expression, ratio);
                Scale_Stmt_Weight(stmt->stmtstruct.mutex->statement, ratio);
                break;
            case ST_COBEGIN:
                Scale_Stmt_Weight(stmt->stmtstruct.cobegin->statements, ratio);
                break;
            case ST_SERLOOP:
                serloop = stmt->stmtstruct.serloop;
                Scale_Stmt_Weight(serloop->loop_body, ratio);
		Scale_Expr_Weight(serloop->cond_expr, ratio);
		Scale_Expr_Weight(serloop->init_expr, ratio);
		Scale_Expr_Weight(serloop->iter_expr, ratio);
                break;
            case ST_PARLOOP:
                parloop = stmt->stmtstruct.parloop;
		Scale_Expr_Weight(parloop->iteration_var, ratio);
		Scale_Expr_Weight(parloop->init_value, ratio);
		Scale_Expr_Weight(parloop->final_value, ratio);
		Scale_Expr_Weight(parloop->incr_value, ratio);
                Scale_Stmt_Weight(Parloop_Stmts_Prologue_Stmt(stmt), ratio);
                break;
            case ST_BODY:
                Scale_Stmt_Weight(stmt->stmtstruct.bodystmt->statement, ratio);
                break;
            case ST_EPILOGUE:
                Scale_Stmt_Weight(stmt->stmtstruct.epiloguestmt->statement, 
				  ratio);
                break;
            default:
                Punt("Scale_Stmt_Weight: Invalid statement type", stmt);
        }
        stmt = stmt->lex_next;
    }
}

void Scale_Func_Weight(func, ratio)
FuncDcl func;
double ratio;
{
    Pragma prof_fn;

    /* BCC - scale down the func profile weight - 9/21/97 */
    if (func->profile)
      func->profile->count *= ratio;
    prof_fn = FindFunctionPragma(func, "\"profile\"");
    if (prof_fn)
        prof_fn->expr->value.real *= ratio;

    Scale_Stmt_Weight(func->stmt, ratio);
}

static Find_Expandable_Call_Exprs(stmt)
Stmt stmt;
{
    char *func_name;
    Expr expr = stmt->stmtstruct.expr;
    Expr op1, op2;

    if (expr->next != NIL) return 0;  /* expr list "a(),b()" won't be inlined */
    switch (expr->opcode) {
	case OP_call:	/* inlining a() */
	    num_expandable_func++;
	    break;
	case OP_assign:	/* inlining b = a(); */

	    op1 = GetOperand(expr, 1);
	    op2 = GetOperand(expr, 2);
	    if (op2->opcode != OP_call) return 0;
	    num_expandable_func++;
	    break;
	default : 
	    return 0;
    }
    return 1;
}

Find_Expandable_Call_Stmts(stmts)
Stmt stmts;
{
    SerLoop serloop;
    ParLoop parloop;

    while (stmts != NIL) {
        switch (stmts->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
            case ST_RETURN:
                break;
            case ST_COMPOUND:
                Find_Expandable_Call_Stmts(
			stmts->stmtstruct.compound->stmt_list); 
                break;
            case ST_IF:
                Find_Expandable_Call_Stmts(
			stmts->stmtstruct.ifstmt->then_block);
                if (stmts->stmtstruct.ifstmt->else_block != NIL)
                    Find_Expandable_Call_Stmts(
			stmts->stmtstruct.ifstmt->else_block);
                break;
            case ST_SWITCH:
                Find_Expandable_Call_Stmts(
			stmts->stmtstruct.switchstmt->switchbody);
                break;
            case ST_EXPR:
                Find_Expandable_Call_Exprs(stmts);
                break;
            case ST_PSTMT:
                Find_Expandable_Call_Stmts(stmts->stmtstruct.pstmt->stmt);
		break;
            case ST_MUTEX:
                Find_Expandable_Call_Stmts(stmts->stmtstruct.mutex->statement);
                break;
            case ST_COBEGIN:
                Find_Expandable_Call_Stmts(
			stmts->stmtstruct.cobegin->statements);
                break;
            case ST_SERLOOP:
                serloop = stmts->stmtstruct.serloop;
                Find_Expandable_Call_Stmts(serloop->loop_body);
                break;
            case ST_PARLOOP:
                parloop = stmts->stmtstruct.parloop;
                Find_Expandable_Call_Stmts(Parloop_Stmts_Prologue_Stmt(stmts));
                break;
            case ST_BODY:
                Find_Expandable_Call_Stmts(
			stmts->stmtstruct.bodystmt->statement);
                break;
            case ST_EPILOGUE:
                Find_Expandable_Call_Stmts(
			stmts->stmtstruct.epiloguestmt->statement);
                break;
            default:
                Punt("Find_Expandable_Call_Stmts: Invalid statement type", stmts);
        }
        stmts = stmts->lex_next;
    }
    return 0;
}

P_FindNestedIf(stmts)
Stmt stmts;
{
    SerLoop serloop;
    ParLoop parloop;
    int old_scope;

    while (stmts != NIL) {
        switch (stmts->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
            case ST_RETURN: 
            case ST_EXPR: 
                break;
            case ST_COMPOUND:
                P_FindNestedIf(stmts->stmtstruct.compound->stmt_list);
                break;
            case ST_IF: {
		Stmt current;
		int nest;
		char else_string[2];
		char if_string[256];
		char pragma_string[256];
		
#if 0
		if (FindStmtPragma(stmts, "\"IFELSE\"") ||
		    stmts->stmtstruct.ifstmt->else_block == 0 ||
		    stmts->stmtstruct.ifstmt->else_block->type != ST_IF) {
#endif
		if (FindStmtPragma(stmts, "\"IFELSE\"")) { 
		    if (stmts->stmtstruct.ifstmt->then_block)
		        P_FindNestedIf(stmts->stmtstruct.ifstmt->then_block);
		    if (stmts->stmtstruct.ifstmt->else_block)
		        P_FindNestedIf(stmts->stmtstruct.ifstmt->else_block);
		    break;
		}
		current = stmts;
		nest = 0;
		while (current) {
		    if (current->type == ST_IF) {
			nest++;
			current = current->stmtstruct.ifstmt->else_block;
		    }
		    else break;
		}
		if (nest && current) {
		    else_string[0] = 'e';
		    else_string[1] = 0;
		}
		else
		    else_string[0] = 0;
		if_string[0] = 0;
                if (nest) {
                    if_else_counter++;
		    current = stmts;
		    while (nest) {
			strcat(if_string, "i");
			sprintf(pragma_string, "\"%s%s_%d\"", 
				else_string, if_string, if_else_counter);
			AddStatementPragma(current, 
				strdup("\"IFELSE\""), 
				NewStringExpr(strdup(pragma_string)));
			nest--;
			current = current->stmtstruct.ifstmt->else_block;
		    }
		}
		if (stmts->stmtstruct.ifstmt->then_block)
		    P_FindNestedIf(stmts->stmtstruct.ifstmt->then_block);
		if (stmts->stmtstruct.ifstmt->else_block)
		    P_FindNestedIf(stmts->stmtstruct.ifstmt->else_block);
		break;
	    }
            case ST_SWITCH: 
                P_FindNestedIf(stmts->stmtstruct.switchstmt->switchbody);
                break;
            case ST_PSTMT:
                P_FindNestedIf(stmts->stmtstruct.pstmt->stmt);
                break;
            case ST_MUTEX:
                P_FindNestedIf(stmts->stmtstruct.mutex->statement);
                break;
            case ST_COBEGIN:
                P_FindNestedIf(stmts->stmtstruct.cobegin->statements);
                break;
            case ST_SERLOOP: 
                serloop = stmts->stmtstruct.serloop;
		P_FindNestedIf(serloop->loop_body);
                break;
            case ST_PARLOOP:
                parloop = stmts->stmtstruct.parloop;
                P_FindNestedIf(Parloop_Stmts_Prologue_Stmt(stmts));
                break;
            case ST_BODY:
                P_FindNestedIf(stmts->stmtstruct.bodystmt->statement);
                break;
            case ST_EPILOGUE:
                P_FindNestedIf(stmts->stmtstruct.epiloguestmt->statement);
                break;
            default:
                Punt("P_FindNestedIf: Invalid statement type", stmts);
        }
        stmts = stmts->lex_next;
    }
}
