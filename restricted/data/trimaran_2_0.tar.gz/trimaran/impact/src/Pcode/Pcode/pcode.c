/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/******************************************************************************\
 *	File:	pcode.c
 *	Author: David August, Nancy Warter and Wen-mei Hwu
 *	Modified from code written by:	Po-hua Chang
\******************************************************************************/


/*===========================================================================
 *	Export Functions : 
 *		ProcessList()
 *		ClearSymbolTable()
 *===========================================================================*/

#include <Pcode/impact_global.h>
#include <library/list.h>
#include <library/c_symbol.h>	/* BCC - added for Pinline - 12/11/95 */
#include <Pcode/pcode.h>
#include <Pcode/read_pcode.h>
#include <Pcode/struct.h>
#include <Pcode/cast.h>
#include <Pcode/reduce.h>
#include <Pcode/init.h>
#include <Pcode/symtree.h>
#include <Pcode/parms.h>
#include <Pcode/func.h>
#include <Pcode/ip_merge.h>

#undef ABORT

char *P_parm_file;

static int pcode_init = 0;	/* initialize symbol tables */
static char *file=0;		/* current file position. */
static int line=0;		/* current line position. */
int assume_C_semantics;

/* scoping information is used to avoid renaming variables - the top level
 * has scope 0 and it gets incremented after function declarations and
 * compound stmts.  (anywhere that you can define new variables)
 */

static Scope possible_scopes;
static int init_scopes;         /* if set to 1 then should not encounter scope
                                   in input pcode */
int max_scope = 0;              /* maximum scope id */
int scope=0;		        /* current scope */
static int dummy=0;		/* dummy name for structs, enums, and unions */
int scope_assigned=0;           /* flag that indicates if we scope assigned in
				 * pcode input file. if scoped_assigned == 1,
				 * don't rename variables - new_name field == 0
				 */
int split=0;			/* BCC - flag that indicates if it's doing
                                   spliting - 7/1/95 */
char *sp_output_format_string;	/* BCC - set in Psplit - 10/22/96 */
int sp_create_layout_info_generator=0; /* ITI(JCG) -set in Psplit -2/99 */

int do_inline=0;		/* BCC - flag that indicates if it will do
                                   inlining - 11/15/95 */
int inlining=0;			/* BCC - flag that indicates if it's doing
                                   inlining - 11/10/95 */
int rename_struct=0;		/* BCC - flag that indicates if structure-
				   renaming is on - 7/29/96 */
int edg_generated=0;		/* BCC - flag that indicates if using the EDG
				   frontend - 8/2/96 */
int SUE_counter=0;		/* BCC - new struct/union/enum counter 
				   - 7/3/96 */
int update_st_un_name=0;	/* BCC - flag for using renamed struct/union
				   name (used in Psplit) - 7/26/96 */
void (*ExpandCalleeFunction)(FuncDcl);	/* BCC - entry to Pinline modules to 
					   inline function - 11/15/95 */
void (*PreprocessFunction)(FuncDcl, int); /* BCC - entry to Pinline modules 
					     to annotate functions - 11/15/95 */
int label_scope_stack[MAX_LABEL_LEVEL];	/* BCC - 4/19/96 */
int label_scope_index;			/* stack to hold the scopes for labels*/

/* TLJ - Current mode for reading include file */
int include_mode = 1;

/* TLJ 2/25/96 Handle include file nesting */
int include_nesting=0;	/* counter indicating level nesting we are at */
char *include_files[3] = {0,0,0};	/* array of include files
					with max include nesting entries */
Scope scope_buffer[3]; 		/* array of scopes for nested entries */

/* TLJ 2/25/96 - Global variables holding current Pcode structure input */
StructDcl        P_Struct;
UnionDcl         P_Union;
EnumDcl          P_Enum;
VarDcl           P_Gvar;       
FuncDcl          P_Func;    
char             *P_Include;
int P_Input_Type; /* which type is current */

int dcl_has_nested_dcls; /* flag that the outer decl created some
                                        other nested declarations */
int nested_dcls;	/* number of dcls nested within each other */
DclList          P_DclList;

static ScopeList pstmt_scopes = 0;
static int in_pstmt = 0;

int Colno;			/* current column number */
int Lineno;			/* current line number */
char *Filename;			/* current filename */

SymTable SymbolTable;

/* forward decls */
static ReadStmt();
static ReadStmts();
static SetUpSymbolTables();
static DefineStruct();
static DefineStructWithRenaming(); /* BCC - 7/26/96 */
static DefineUnionWithRenaming();  /* BCC - 10/30/96 */
static DefineUnion();
static DefineEnum();

static struct _ProfEXPR *ReadExprProfile(); /* LCW */

/*
 * The current function definition being constructed.
 */ 
 FuncDcl currentFuncDcl = 0;
 FuncDcl calleeFuncDcl = 0;	/* BCC - added for Pinline - 11/12/95 */

/*===================================================================*/
/*
 * Maintain a LIST stack, to make error reporting much more
 * user friendly.
 */
#define MAX_LEVEL 2000		/* max nest degree of expressions */
static int s_top = -1;
static LIST s_stack[MAX_LEVEL];

/* BCC - 12/11/95
 * When inline function, we have to rename the labels in the callee. So we need
 * a hash table to do the mapping.
 */
#define	MAX_LABELS	2000	/* BCC - added for Pinline - 12/11/95 */
int label_mapping_table;
char *func_name;

/* BCC - 10/30/96 */
#define	MAX_T_STRUCTS	1000
int struct_T_name_table;

/* BCC - Measure the body size and stack size of a function - 12/16/95 */
long BodySize;
long StackSize;

/* BCC - Annotate calls through pointers - 12/17/95 */
int do_annotate_function;

/* BCC - take out discount from profile weight - 12/19/95 */
double in_fraction = 1.0, out_fraction = 1.0;

/* BCC - declare a struct pool for renaming structs - 7/3/96 */
int max_struct_union_pool = 0;
int new_struct_union_created = 0;
_StructUnionPool StructUnion_Pool[MAX_STRUCT_UNION_POOL_SIZE];

/* BCC - count the number of struct.pch and extern.pch encountered - 7/13/96 */
int struct_count, extern_count;

static Clear() {
  s_top = -1;
}

static Push(list)
     LIST list;
{
  s_top++;
  if (s_top>=MAX_LEVEL) {
    Clear(); Punt("internal LIST stack overflows");
  }
  s_stack[s_top] = list;
}
static Pop() {
  if (s_top>=0)
    s_top--;
}
static LIST Top() {
  if ((s_top>=0)&&(s_top<MAX_LEVEL))
    return (s_stack[s_top]);
  else
    return 0;
}
/*===================================================================*/
/* Print error message and then punt the program. */
Punt(mesg)
     char *mesg;
{
  LIST err;
  fprintf(Ferr, "Pcode: %s\n", mesg);
  if (file!=0)
    fprintf(Ferr, "At file [%s] line [%d],\n", file, line);
  err = Top();
#ifdef ABORT
  abort();
#endif
  exit(-1);
}
/* Print a warning message to the log file and then return. */
Warning(mesg)
     char *mesg;
{
  /* External users really don't need to see all these warnings -JCG 5/6/98*/
#if 0
  fprintf(Flog, "Pcode warning: %s\n", mesg);
  if (file!=0)
    fprintf(Flog, "At file [%s] line [%d],\n", file, line);
#endif
}
/*===================================================================*/
static Pragma expr_pragma = 0;
/*
 * Process a pragma for the next expression.
 * These may be used internally since have fine grain control of expressions.
 */
static ReadExprPragma(id, exprs)
     char *id;
     Expr exprs;
{
  Pragma new, ptr;
  new = NewPragma(id, exprs);
  if (expr_pragma==0) 
    expr_pragma = new;
  else {
    ptr = expr_pragma;
    while (ptr->next!=0) ptr = ptr->next;
    ptr->next = new;
  }
}

/*
 * BCC - added 1/29/96
 *       Transfer char * to char [dim] for string constang
 */
Type AdjustType(expr)
Expr expr;
{
  Type type;

  if (expr == NULL) return NULL;
  while (expr && (expr->opcode == OP_compexpr))
    expr = expr->operands;
  if (expr == NULL) return NULL;
  if (expr->opcode == OP_string) {
    type = NewType();
    type->type = TY_CHAR;
    type->dcltr = NewDcltr();
    type->dcltr->method = D_ARRY;
    /* length - '"' - '"' + '\0' = length -1 */
    type->dcltr->index = NewIntExpr(strlen(expr->value.string)-1);
  }
  else
    type = CopyType(expr->type);
  return type;
}
/*
 * Process a non-nil expression.
 *
 * list = $Expr = (opcode operands $ExprPragma* $ExprProfile?)
 *
 * $ExprPragma = (PRAGMA $String $Expr*)   <--- NO POS!
 *		
 */
Expr Expression(LIST list)
{
  int no_cast = 0;
  extern Type DeclSpec();	/* forward */
  LIST opcode, operands, ptr;
  char *keyword;
  Symbol sym;
  VarDcl v;
  EnumDcl en;
  EnumField enf;
  int s;
/* BCC - operand_expr added to hold the result of operand expressions 4/27/95 */
  Expr expr,operand_expr;

  if ((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect expression format (1)");
  opcode = ChildOf(list);
  if ((opcode==0)||(NodeType(opcode)!=T_ID))
    Punt("incorrect expression format (2)");
  keyword = StringOf(opcode);
  operands = SiblingOf(opcode);
  /* index into the opcode symbol table to find the opcode */
  sym = FindSym(SymbolTable[TBT_OPCODE], keyword, 0);
  if (sym==0) {
    fprintf(Ferr, "> %s\n", keyword);
    Punt("incorrect expression format (3)");
  }
  expr = NewExpr(sym->value);

  /* LCW - handle pragmas and profile info first - 10/30/95 */
  expr_pragma = 0;
  for(ptr=operands; ptr!=0; ptr=SiblingOf(ptr)) {
    LIST temp;
    char *pragma_id;
    Expr pragma_expr;
    if(NodeType(ptr)!=T_LIST)
      continue;
    temp = ChildOf(ptr);
    if((temp!=0)&&(NodeType(temp)==T_ID)) {
      if (!strcmp(StringOf(temp), "PRAGMA")) {
         temp = SiblingOf(temp);
         if((temp==0)||(NodeType(temp)!=T_STRING))
           Punt("incorrect expression pragma specifier (1)");
         pragma_id = StringOf(temp);
         /* GEH - removed pragma type specifier - 1/12/95
         if((pragma_id[1]!='E')||(pragma_id[2]!='X'))
           Punt("incorrect expression pragma specifier (2)");
         */
         temp = SiblingOf(temp);
         if((temp==0)&&(NodeType(temp)!=T_LIST))
           Punt("incorrect expression pragma specifier (3)");
         pragma_expr = Expression(temp);
         ReadExprPragma(pragma_id, pragma_expr);
	 /* BCC - garbage collection - 8/25/96 */
	 RemoveExpr(pragma_expr);
	 /* BCC - since expr_pragma is reset to 0 in Expressoin, and Expression
		  can recursively call itself, we have to connect expr_pragma 
		  to Expr here 12/17/95 */
	  expr_pragma->next = expr->pragma;;
	  expr->pragma = expr_pragma;
      }
      else if (!strcmp(StringOf(temp), "PROFILE")) {
	 expr->profile = ReadExprProfile(temp);
      }
    }
  }
/* BCC - moved into the above for-loop - 12/17/95 */
#if 0
  expr->pragma = expr_pragma;
#endif
  expr_pragma = 0;

/* LCW - old code which can only handle pragmas - 10/30/95 */
#if 0
  /* handle pragmas first */
  expr_pragma = 0;
  for(ptr=operands; ptr!=0; ptr=SiblingOf(ptr)) {
    LIST temp;
    char *pragma_id;
    Expr pragma_expr;
    if(NodeType(ptr)!=T_LIST)
      continue;
    temp = ChildOf(ptr);
    if((temp!=0)&&(NodeType(temp)==T_ID)&&
       !strcmp(StringOf(temp), "PRAGMA")) {
      temp = SiblingOf(temp);
      if((temp==0)||(NodeType(temp)!=T_STRING))
	Punt("incorrect expression pragma specifier (1)");
      pragma_id = StringOf(temp);
      /* GEH - removed pragma type specifier - 1/12/95
      if((pragma_id[1]!='E')||(pragma_id[2]!='X'))
	Punt("incorrect expression pragma specifier (2)");
      */
      temp = SiblingOf(temp);
      if((temp==0)&&(NodeType(temp)!=T_LIST))
	Punt("incorrect expression pragma specifier (3)");
      pragma_expr = Expression(temp);
      ReadExprPragma(pragma_id, pragma_expr);
    }  
  }
  expr->pragma = expr_pragma;
  expr_pragma = 0;
#endif
  
  /* handle special expressions */
  Push(list);	/* level 1 */
  switch (expr->opcode) {
  case OP_var:  
    /* either a VarDcl or EnumField */
    /* operands = $VarID */
    if ((operands==0)||(NodeType(operands)!=T_ID))
      Punt("incorrect primary expression (1)");
    expr->value.var_name = StringOf(operands);
    
    /* check if variable declared or enum field */
    v=FindNearScopeVar(possible_scopes,expr->value.var_name);
    en=FindNearScopeEnF(possible_scopes,expr->value.var_name);
    
    /* to handle pragmas which will use variables before they
     * are defined add the following kludge (I should devise
     * a better way to handle pragma expression overall).
     */
    if((v==0)&&(en==0)) {
      if (verbose_yes) {
        fprintf(Flog, "=> variable %s\n", expr->value.var_name);
        Warning("variable used before declared");
      }
      if (DEBUG_SYMTREE) PrintSymT(TT_VAR);
      /* add default cast and set no_cast so CastExpr not called */
      expr->type = NewType();
      expr->type->type = (TY_INT | TY_EXTERN);
      no_cast = 1;
	/* DMG - we go ahead and put the undeclared variable in the symbol
		table; unless func is messed up, this should be a function
		call variable to a function which hasn't been defined or 
		forward declared */
      v = NewVarDcl();
      v->name = expr->value.var_name;
      v->type = CopyType(expr->type);
      v->type->dcltr = NewDcltr();
      v->type->dcltr->method = D_FUNC;
      AddVar (expr->value.var_name, 0, v, 0);
    }
    else if((v!=0)&&(en==0))  {    /* variable closest scope */
      if(v->new_name != 0) {
	/* rename */
	expr->value.var_name = v->new_name;
      }
      expr->type = CopyType(v->type);
    }
    else if((v==0)&&(en!=0)) { /* enum closes scope */
      expr->enum_flag = 1;
      enf = FindEnumFieldInEnum(en, expr->value.var_name);
      if(enf->new_name != 0) {
	/* rename */
	expr->value.var_name = enf->new_name;
      }
      expr->type = NewType();
      /* set type to default of cast.c */
      expr->type->type = (TY_INT | TY_EXTERN);  
    } else { 		/* find closest scope */
      s=ClosestScope(possible_scopes,expr->value.var_name);
      if(FindVar(expr->value.var_name, s)) {
	if(v->new_name != 0) {
	  /* rename */
	  expr->value.var_name = v->new_name;
	}
	expr->type = CopyType(v->type);
      }
      else {		/* enum field is closest scope */
	expr->enum_flag = 1;
	enf = FindEnumFieldInEnum(en, expr->value.var_name);
	if(enf->new_name != 0) {
	  /* rename */
	  expr->value.var_name = enf->new_name;
	}
	/* set type to default of cast.c */
	expr->type->type = (TY_INT | TY_EXTERN);
      }
    }
    break;
    /*
      case OP_enum:
      if ((operands==0)||(NodeType(operands)!=T_STRING))
      Punt("incorrect primary expression (2)");
      expr->value.string = StringOf(operands);
      break;
      */
    /*
      case OP_signed:
      */
  case OP_int:
    /* operands = $IntVal */
    if ((operands==0)||(NodeType(operands)!=T_INT))
      Punt("incorrect primary expression (3)");
    expr->value.scalar = IntegerOf(operands);
    break;
    /*
      case OP_unsigned:
      if ((operands==0)||(NodeType(operands)!=T_INT))
      Punt("incorrect primary expression (4)");
      expr->value.uscalar = IntegerOf(operands);
      break;
      */
    /*
      case OP_float:
      */
  /* BCC - added - 8/4/96 */
  case OP_float:
  case OP_double:
  case OP_real:
    /* operands = $RealVal */
    if ((operands==0)||(NodeType(operands)!=T_REAL))
      Punt("incorrect primary expression (5)");
    expr->value.real = RealOf(operands);
    break;
  case OP_char:
    /* operands = $CharVal */
    if ((operands==0)||(NodeType(operands)!=T_CHAR))
      Punt("incorrect primary expression (6)");
    expr->value.string = StringOf(operands);
    break;
  case OP_string:
    /* operands = $String */
    if ((operands==0)||(NodeType(operands)!=T_STRING))
      Punt("incorrect primary expression (7)");
    expr->value.string = StringOf(operands);
    break;
  case OP_dot:
  case OP_arrow:
    /* we will keep the field name in value.string */
    /* operands = $Expr $FieldID */
    if (operands==0)
      Punt("incorrect primary expression (8)");
    AddOperand(expr, Expression(operands));
    operands = SiblingOf(operands);
    if ((operands==0)||(NodeType(operands)!=T_ID)) 
      Punt("incorrect primary expression (8)");
    expr->value.string = StringOf(operands);
    break;
  case OP_cast:
    /* operands = $DeclSpec $Expr */
    if (operands==0)
      Punt("incorrect expression format (4) : cast");
    /*
     *	Here, we violate the NO_SHARING rule.
     *	But since the (value) field of Expr
     *	structure is never deleted, this is safe.
     */
    expr->value.type = expr->type = DeclSpec(operands, FALSE);
    operands = SiblingOf(operands);
    if (operands==0)
      Punt("incorrect expression format (5) : cast");
    AddOperand(expr, Expression(operands));
    break;
  case OP_expr_size:
    /* operands = $Expr */

/******************************************************************************\
 * BCC - after knowing the result type of an expression, use the type to      *
 * 	 calculate the size instead of the expression                 4/27/95 *
\******************************************************************************/

    operand_expr = Expression(operands);
    /*
     * BCC - 1/29/96
     *          Consider sizeof("__gnu_compiled");
     *          The type of "__gnu_compiled" is char *, not char [15]
     *          So we have to fake the type go get the right value
     */
    expr->value.type = AdjustType(operand_expr);
    RemoveExpr(operand_expr);
    /* BCC - end of change */

    if (expr->value.type == NULL) 
	Punt("no type returned from the expression");
    expr->opcode = OP_type_size;
    break;
  case OP_type_size:
    /* operands = $DeclSpec */
    if (operands==0)
      Punt("incorrect expression format (6) : type_size");
    expr->value.type = DeclSpec(operands);
    break;
  case OP_compexpr:
    {
      Expr expr_head;
      /* operands = ($ExprList) */
      ptr = ChildOf(operands);
      if(ptr!=0) {
	expr_head = Expression(ptr);
	AddOperand(expr, expr_head);
	ptr = SiblingOf(ptr);
      }
      for(; ptr!=0; ptr=SiblingOf(ptr)) {
	AddNextOperand(expr_head, Expression(ptr));
      }
      break;
    }
  case OP_index:
    {
      Expr expr_head;
      /* operands = $Expr ($ExprList) */
      AddOperand(expr, Expression(operands));
      ptr = ChildOf(SiblingOf(operands));
      if(ptr!=0) {
	expr_head = Expression(ptr);
	AddOperand(expr, expr_head);
	ptr = SiblingOf(ptr);
      }
      for(; ptr!=0; ptr=SiblingOf(ptr)) {
	AddNextOperand(expr_head, Expression(ptr));
      }
      break;
    }
  case OP_call:
    {
      Expr expr2;
      /* operands = $Expr ($ExprList?) */
      AddOperand(expr, Expression(operands));
      ptr = ChildOf(SiblingOf(operands));
      /* NJW - 8/92 - exprlist can be null */
      if(ptr) {
	expr2 = Expression(ptr);
	AddOperand(expr, expr2);
	ptr = SiblingOf(ptr);
	for(; ptr!=0; ptr=SiblingOf(ptr)) {
	  AddNextOperand(expr2, Expression(ptr));
	}
      }
      break;
    }
  case OP_quest:
    { 
      Expr expr2;
      /* operands = $Expr ($ExprList) $Expr */
      AddOperand(expr, Expression(operands));
      ptr = ChildOf(SiblingOf(operands));
      expr2 = Expression(ptr);
      AddOperand(expr, expr2);
      /* handle ExprList by adding additional operands to
       * sibling of the second operand
       */
      ptr = SiblingOf(ptr);
      for(; ptr!=0; ptr=SiblingOf(ptr)) {
	AddNextOperand(expr2, Expression(ptr));
      }
      AddOperand(expr,  Expression(SiblingOf(SiblingOf(operands))));
      break;
    }
  case OP_error:
    Punt("Expression: OP_error unknown");
    break;
  default:
    /* operands = $Expr $Expr |
       $Expr */
    for (ptr=operands; ptr!=0; ptr=SiblingOf(ptr)) {
      LIST temp;
      if (NodeType(ptr)==T_LIST) {
	temp = ChildOf(ptr);
	if ((temp!=0) && (NodeType(temp)==T_ID)
	    && (!strcmp(StringOf(temp), "PRAGMA") /* skip over pragma */
		|| !strcmp(StringOf(temp), "PROFILE"))) {
	  continue;	/* LCW - skip over profile - 10/31/95 */
	} 
      }
      AddOperand(expr, Expression(ptr));
    }
  }
  Pop();	/* level 1 */
  /* pragma handling kludge */
  if(!no_cast)
    /* 10/92 - change CastExpr so doesn't depend on scope */
    CastExpr(expr);
  return expr;
}

/*===================================================================*/
/* StructName - give a dummy name to a struct, enum, or union
 */
char * StructName()
{
  char *new_name = (char *)malloc(20); 	/* new_name should never have > 20 char */
  sprintf(new_name, "P_PC___Struct%d", dummy++);
  return(new_name);
}

/*===================================================================*/
/*
 * Reduce the type given type = typeid.
 *
 *   Given a typeid, look it up in the table and get the actual type.
 *   Dcltr's are combined within DeclSpec.
 */

Type ReduceType(typeid)
     char *typeid;
{
  TypeDcl ty;
  ty = FindTypeDef(typeid);
  if(ty==0)
    Punt("ReduceType: invalid type (1)");
  else 
    return(ty->type);
}

/* BCC - 1/21/96
 * Read the parameter type declarations
 *
 */

Param ReadParamTypeList(list)
     LIST list;
{
  LIST opcode;
  char *keyword;
  Param first, new, last;
  extern Type DeclSpec();

  first = last = NIL;
  for(; list!=0; list=SiblingOf(list)) {
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("incorrect parameter type specifier (1)");
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect parameter type specifier (2)");
    keyword = StringOf(opcode);
    if(strcmp(keyword, "FPARAM"))
      Punt("incorrect parameter type specifier (3)");
    opcode = SiblingOf(opcode);
    /* Specifier string */
    if((opcode==0)||(NodeType(opcode)!=T_LIST))
      Punt("incorrect parameter type specifier (4)");
    new = NewParam();
    new->type = DeclSpec(opcode);
    if (last == NIL)
      first = last = new;
    else {
      last->next = new;
      last = new;
    }
  }
  return first;
}

/*===================================================================*/
/* BCC 7/5/96 - check is a Dcl is buffered on the Dcl List
 */
bool IsDclOnList(list, dcl)
      DclList list;
      void *dcl;
{
  /* catch the first */
  switch (P_Input_Type) {
    case P_INPUT_STRUCT :
      if (dcl == (void *)P_Struct) return TRUE;
      break;
    case P_INPUT_UNION :
      if (dcl == (void *)P_Union) return TRUE;
      break;
    case P_INPUT_ENUM :
      if (dcl == (void *)P_Enum) return TRUE;
      break;
    case P_INPUT_GVAR :
      if (dcl == (void *)P_Gvar) return TRUE;
      break;
    case P_INPUT_FUNC :
      if (dcl == (void *)P_Func) return TRUE;
      break;
  }
  /* catch things on the list */
  while (list) {
    if ((void *)list->dcl->varDcl == dcl) return TRUE;
    list = list->next;
  }
  return FALSE;
}

/*===================================================================*/
/* TLJ 2/27/96 - Add a Dcl of given type to DclList.
 */
DclList AddDcl2List(list, dcl, type)
     DclList list;
     void *dcl;
     int type;
{
  register DclList new, l;

  new = NewDclList();
  switch (type)
  {
    case TT_VAR:
	new->dcl->varDcl = (VarDcl) dcl;
	break;
    case TT_ENUM:
	new->dcl->enumDcl = (EnumDcl) dcl;
	break;
    case TT_STRUCT:
	new->dcl->structDcl = (StructDcl) dcl;
	break;
    case TT_UNION:
	new->dcl->unionDcl = (UnionDcl) dcl;
	break;
    case TT_FUNC:
	new->dcl->funcDcl = (FuncDcl) dcl;
	break;
    default:
	Punt("AddDcl2List: Unrecognized dcl type");
  } 
  new->dcl_type = type;
  new->next = 0;
  if (list==0) {
    list = new;
  } else {
    l = list;
    while (l->next!=0)
      l = l->next;
    l->next = new;
  }
  return list;
}


char *RemoveTPrefix(str)
char *str;
{
    char *head, *tail, *name;
    char buffer[512];
    int number, i;

    head = tail = str;
    if (rename_struct && *tail == '_' && *(tail+1) == '_' && *(tail+2) == 'T') {
#if 0
	tail += 2;
	while (*++tail != '_');
#endif
        /* only using line # and column # for tagless structs */
        tail = str + strlen(str);
	for (i=0; i < 4; i++) {
	    while (*tail != '_')
		tail--;
	    tail--;
	}
	tail++;

	if (!C_find(struct_T_name_table, tail, 0, &number, 0)) {
	    number = 0;
	    C_update(struct_T_name_table, tail, 0, number, 0);
	};
	if (!C_find(struct_T_name_table, head, 0, &i, (Pointer *) &name)) {
	    if (number == 0) {
		C_update(struct_T_name_table, head, 0, 0, 
			 (Pointer *) strdup(tail));
		C_update(struct_T_name_table, tail, 0, 1, 0);
		return strdup(tail);
	    }
	    else {
		sprintf(buffer, "%s_impact%d", tail, number);
		C_update(struct_T_name_table, head, 0, 0,
			 (Pointer *)strdup(buffer));
		C_update(struct_T_name_table, tail, 0, number+1, 0);
		return strdup(buffer);
	    }
	}
	else return name;
    }
    else return str;
}

/*===================================================================*/
/*
 * Read a declaration_specifier, and return it.
 *
 * list = $DeclSpec = ($TcSpec+ $Dcltr*)
 *
 * If there is a named Struct, Enum, or Union that is used as a type
 * but not in symbol table then it must be defined by calling DefineStruct,
 * DefineEnum, or DefineUnion respectively. If it is in symbol table but has 
 * fields then must check to see if has same position - if not then it is a 
 * redefinition and it is an error.
 * If there is an unnamed Struct, Enum, or Union - can assume that it is
 * is not defined elsewhere - will give it a dummy name.
 *
 * NJW - 9/92 - type_id followed by a pointer is a pointer to type_id -
 */
Type DeclSpec(list)
     LIST list;
{
  int level;
  LIST item;
  char *spec;
  int type_type, type_id_flag;
  Type type;
  StructDcl tbl_st;
  UnionDcl tbl_un;
  EnumDcl tbl_en;
  Dcltr ptr2;
  bool Typedef = FALSE;

  type = NewType();
  type_id_flag = 0;
  ptr2 = 0;
  if ((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect declarator_specifier");
  Push(list);   /* level 1 */
  list = ChildOf(list);
  for (; list!=0; list=SiblingOf(list)) {
    if(
       (
        (NodeType(list)==T_ID) &&
        (
         (!strcmp(StringOf(list), "P")) ||
         (!strcmp(StringOf(list), "A")) ||
         (!strcmp(StringOf(list), "F"))
         )
       ) ||
       (
        (NodeType(list)==T_LIST)&&
        (
         (NodeType(ChildOf(list))==T_ID) &&
         (
          (!strcmp(StringOf(ChildOf(list)), "P")) ||    /* GEH - 2/9/96 */
          (!strcmp(StringOf(ChildOf(list)), "A")) ||
          (!strcmp(StringOf(ChildOf(list)), "F")) /* BCC - added F for params */
         )
         )
        )
       )

      {
        /* Dcltr */
        level = 0;
        for(; list!=0; list=SiblingOf(list)) {
          Dcltr ptr, new = NewDcltr();
          level++;
          if(NodeType(list)==T_ID) {    /* P or A or F */
            if(! strcmp(StringOf(list), "P")) {
              new->method = D_PTR;
            } else if(! strcmp(StringOf(list), "F")) {
              /* 4/92 - default to extern */
              new->method = D_FUNC;
              /* DIA - 4/7/94 No extern unless F at highest level, Don't extern
*/
              /* fields in a struct. */
        /* - BCC - Functionality moved to end of this function
              if (level == 1 && !(type->type & TY_STATIC))
                type->type |= TY_EXTERN;
        */
            } else if(! strcmp(StringOf(list), "A")) {
              new->method = D_ARRY;
              new->index = 0;
            } else
              Punt("incorrect Dcltr (1)");

          } else
            if(NodeType(list)==T_LIST) {        /* (P..) or (A..) or (F..) */
              item = ChildOf(list);
              if(! strcmp(StringOf(item), "A")) {
                new->method = D_ARRY;
                item = SiblingOf(item);
                if (item!=0) {
                  Expr exp = Expression(item);
                  new->index = ReduceExpr(exp);
                  RemoveExpr(exp);
                }
              } else if(! strcmp(StringOf(item), "P")) {
                new->method = D_PTR;
                new->qualifier = 0;
                item = SiblingOf(item);
                while (item!=0) {
                  if (! strcmp(StringOf(item), "CONST"))
                    new->qualifier |= DQ_CONST;
                  else if (! strcmp(StringOf(item), "VOLATILE"))
                    new->qualifier |= DQ_VOLATILE;
                  else Punt("incorrect Dcltr_Qualifier (1)");
                  item = SiblingOf(item);
                }
          /* BCC - a function declarator can have a list of params - 2/9/96 */
              } else if(! strcmp(StringOf(item), "F")) {
                new->method = D_FUNC;
                new->qualifier = 0;
                item = SiblingOf(item);
                while (item!=0 && NodeType(item)==T_ID) {
                  if (! strcmp(StringOf(item), "CDECL"))
                    new->qualifier |= DQ_CDECL;
                  else if (! strcmp(StringOf(item), "STDCALL"))
                    new->qualifier |= DQ_STDCALL;
                  else if (! strcmp(StringOf(item), "FASTCALL"))
                    new->qualifier |= DQ_FASTCALL;
                  else Punt("incorrect Dcltr_Qualifier (2)");
                  item = SiblingOf(item);
                }
                if (item!=0) {
                  item = ChildOf(item);
                  if (item != 0)
                    new->param = ReadParamTypeList(item);
                  else
                    Punt("incorrect Dcltr (4)");
                }
              } else
                Punt("incorrect Dcltr (2)");
            } else
              Punt("incorrect Dcltr (3)");

          /* link the new dcltr to the chain */
          /* NJW - 9/92 - handle type_id's differently */
          if(type_id_flag) {
            if(type->dcltr==0) {
              type->dcltr = new;
              type_id_flag = 0;    /* type_id doesn't have dcltr */
            } else {
              if(ptr2 == 0) {
                ptr2 = type->dcltr;  /* first dcltr of type_id */
                new->next = type->dcltr;
                type->dcltr = new;
              } else {
                ptr = type->dcltr;
                if(ptr == ptr2)
                  Punt("internal Dcltr error");
                while(ptr->next != ptr2) ptr = ptr->next;
                new->next = ptr->next;
                ptr->next = new;
              }
            }
          } else {
            ptr = type->dcltr;
            if (ptr==0) {
              type->dcltr = new;
            } else {
              while (ptr->next!=0) ptr = ptr->next;
              ptr->next = new;
            }
          }
        }
        break;  /* must be at the end of DeclSpec */
      }
    else {
      /* TcSpec */
      /* all but typedef, typeid, $EnumSpec, and $StructSpec are ids */
      if(NodeType(list)==T_ID) {
        spec = StringOf(list);
        if (! strcmp(spec, "CONST"))
          type->type |= TY_CONST;
        else if (! strcmp(spec, "VOLATILE"))
          type->type |= TY_VOLATILE;
        else if (! strcmp(spec, "AUTO"))
          type->type |= TY_AUTO;
        else if (! strcmp(spec, "STATIC"))
          type->type |= TY_STATIC;
        else if (! strcmp(spec, "EXTERN"))
          type->type |= TY_EXTERN;
        else if (! strcmp(spec, "REGISTER"))
          type->type |= TY_REGISTER;
        else if (! strcmp(spec, "CHAR"))
          type->type |= TY_CHAR;
        else if (! strcmp(spec, "FLOAT"))
          type->type |= TY_FLOAT;
        else if (! strcmp(spec, "DOUBLE"))
          type->type |= TY_DOUBLE;
        else if (! strcmp(spec, "INT"))
          type->type |= TY_INT;
        else if (! strcmp(spec, "SHORT"))
          type->type |= TY_SHORT;
        else if (! strcmp(spec, "LONG"))
          type->type |= TY_LONG;
        else if (! strcmp(spec, "SIGNED"))
          type->type |= TY_SIGNED;
        else if (! strcmp(spec, "UNSIGNED"))
          type->type |= TY_UNSIGNED;
        else if (! strcmp(spec, "VOID"))
          type->type |= TY_VOID;
        else if (! strcmp(spec, "SYNC"))
          type->type |= TY_SYNC;
        else if (! strcmp(spec, "VARARG"))      /* BCC - added - 1/24/96 */
          type->type |= TY_VARARG;
        else Punt("incorrect declarator_specifier (1)");
        /*
          else if (! strcmp(spec, "NOALIAS"))
          type->type |= TY_NOALIAS;
          else if (! strcmp(spec, "GLOBAL"))
          type->type |= TY_GLOBAL;
          else if (! strcmp(spec, "PARAMETER"))
          type->type |= TY_PARAMETER;
          */
      } else {  /* list = typedef, typeid, $EnumSpec, $StructSpec */
        item = ChildOf(list);
        if (NodeType(item)!=T_ID) {
          Punt("incorrect declarator_specifier (2)");
        } else {
          spec = StringOf(item);
        }
        if (! strcmp(spec, "TYPEDEF")) {
          /* assume that TYPEDEF can only occur after DEF */
          /* don't do anything - next type defines the type of typedef */
          /* Punt("incorrect declarator specifier (3)"); */
            Typedef = TRUE;
        } else
          if (! strcmp(spec, "TYPEID")) {
            /* NJW - 9/92 - need to insert ptr before type_id's */
            type_id_flag = 1;
            item = SiblingOf(item);
            if((item==0)||(NodeType(item)!=T_ID))
              Punt("incorrect declarator_specifier (4)");
            else {
              type_type = type->type;   /* 4/92 */
	      /* BCC - garbage collection - 8/17/96 */
	      RemoveType(type);
              type = CopyType(ReduceType(StringOf(item)));
              type->type |= type_type;

              /* BCC - necessary for local variables here - 7/26/96 */
              if ((type->type & TY_STRUCTURE) && rename_struct) {
                  /* BCC - get the newest name - 7/3/96 */
                  int i;

                  for (i=0; i<max_struct_union_pool; i++) {
                    if (!strcmp(type->struct_name, StructUnion_Pool[i].name)) 
		      break;
                  }
                  if ( i != max_struct_union_pool )
                    type->struct_name = StructUnion_Pool[i].new_name;
              }
            }
          } else
            if (! strcmp(spec, "STRUCT")) {
              if (type->type & (TY_STRUCT|TY_UNION|TY_ENUM))
                Punt("incorrect declarator_specifier (5)");
              type->type |= TY_STRUCT;
              item = SiblingOf(item);
              if (item!=0) {
                if(NodeType(item)!=T_ID) {  /* give dummy name */
                  if(NodeType(item)==T_LIST) {
                    type->struct_name = StructName();
		    /* BCC - 7/26/96 */
		    rename_struct ? 
			DefineStructWithRenaming(item, type->struct_name) : 
			DefineStruct(item, type->struct_name) ; 
                    /* 5/92 - fix up so struct_name points to new_name */
                    tbl_st = FindNearScopeSt(possible_scopes,
                                             type->struct_name);
                    if(tbl_st == 0)
                      Punt("Structure define internal error");
                    if(tbl_st->new_name != 0)
                      type->struct_name = tbl_st->new_name;
                  }
                  else
                    Punt("incorrect declarator_specifier (6)");
                }
          /*
          ** DIA - 4/12/94: Changed struct to handle same position def.
          **    Such as:  typedef struct {..} x, y;
          */
                else {
		  /* BCC - get the newest name - 7/3/96 */
		  char *name;
		  int i;

		  /* BCC - 10/29/96
		   * Since Psplit is able to rename struct automatically, the
		   * leading __Tdddddddd is omitted
		   */
		  name = RemoveTPrefix(StringOf(item));

		  for (i=0; i<max_struct_union_pool; i++) {
		    if (!strcmp(name, StructUnion_Pool[i].name)) break;
		  }
		  if ( i == max_struct_union_pool )
		    type->struct_name = name;
		  else
		    type->struct_name = StructUnion_Pool[i].new_name;

                  if((SiblingOf(item)!=0)&&
                     (NodeType(SiblingOf(item))!=T_LIST))
                    Punt("incorrect declarator_specifier (6.1)");

                  tbl_st = FindNearScopeSt(possible_scopes, type->struct_name);
                  if (tbl_st != 0)
                   {
                    /* redefinition? */
                    if(SiblingOf(item) != 0)
                     { /* has fields - is def */
           /*
           ** DIA - 4/23/93: This is a real mess.  Lineno and Colno trail
           **  behind actual values.  I will allow, now, redefinitions in
           **  order to handle a struct used before defined.
           */
           /*           if(! ((tbl_st->lineno == Lineno) &&  ** same pos **
           **               (tbl_st->colno == Colno) &&
           **               !strcmp(tbl_st->filename, Filename)))
           **           Punt("Structure Redefined (1)");
           */
		      rename_struct ? 
                        DefineStructWithRenaming(item, type->struct_name) :
                        DefineStruct(item, type->struct_name);
                      tbl_st = FindNearScopeSt(possible_scopes,
                                             type->struct_name);
                      if(tbl_st == 0)
                        Punt("Internal Error in Struct Def (1)");
                      else
                        if(tbl_st->new_name != 0)
                          type->struct_name = tbl_st->new_name;
                     }
                    else
                      if(tbl_st->new_name != 0) /*rename */
                        type->struct_name = tbl_st->new_name;
                   }
                  else /* define structure */
                   {
		    /* BCC - 7/26/96 */
		    rename_struct ? 
                      DefineStructWithRenaming(item, type->struct_name) :
                      DefineStruct(item, type->struct_name);
                    tbl_st = FindNearScopeSt(possible_scopes,
                                             type->struct_name);
                /* TLJ - 1/15/96: Modified so that something cast as
                 *      a pointer to a struct that is not yet defined
                 *      will not cause a punt (since this is just an address).
                 */
                /*  if(tbl_st == 0)
                 *    Punt("Internal Error in Struct Def (1)");
                 *  else
                 *    if(tbl_st->new_name != 0)
                 *      type->struct_name = tbl_st->new_name;
                 */
                    if(tbl_st == 0)
                        if ((SiblingOf(list) &&
                                NodeType(SiblingOf(list)) == T_ID &&
                                !strcmp(StringOf(SiblingOf(list)),"P")))
		            /* BCC - 7/26/96 */
			    rename_struct ? 
                              DefineStructWithRenaming(item, type->struct_name):
                              DefineStruct(item, type->struct_name);
                        else
                            Punt("Internal Error in Struct Def (1)");
                    else
                      if(tbl_st->new_name != 0)
                        type->struct_name = tbl_st->new_name;
                   }
                 }
              }
              else
                Punt("incorrect declarator_specifier(6.2)");

            } else
              if (! strcmp(spec, "UNION")) {
                if (type->type & (TY_STRUCT|TY_UNION|TY_ENUM))
                  Punt("incorrect declarator_specifier (7)");
                type->type |= TY_UNION;
                item = SiblingOf(item);
                if (item!=0) {
                  if(NodeType(item)!=T_ID) {    /* give dummy name */
                    if(NodeType(item)==T_LIST) {
                      type->struct_name = StructName();
                    /* BCC - 7/26/96 */
                    rename_struct ?
                        DefineUnionWithRenaming(item, type->struct_name) :
                        DefineUnion(item, type->struct_name) ;
                      /* 5/92 - fix up so struct_name points to new_name */
                      tbl_un = FindNearScopeUn(possible_scopes,
                                               type->struct_name);
                      if(tbl_un == 0)
                        Punt("Union define internal error");
                      if(tbl_un->new_name != 0)
                        type->struct_name = tbl_un->new_name;
                    }
                    else
                      Punt("incorrect declarator_specifier (8)");
                  }
          /*
          ** DIA - 4/12/94: Changed union to handle same position def.
          **    Such as:  typedef struct {..} x, y;
          */
                  else {
                  /* BCC - get the newest name - 7/3/96 */
                  char *name;
                  int i;

                  /* BCC - 10/29/96
                   * Since Psplit is able to rename struct automatically, the
                   * leading __Tdddddddd is omitted
                   */
                  name = RemoveTPrefix(StringOf(item));

                  for (i=0; i<max_struct_union_pool; i++) {
                    if (!strcmp(name, StructUnion_Pool[i].name)) break;
                  }
                  if ( i == max_struct_union_pool )
                    type->struct_name = name;
                  else
                    type->struct_name = StructUnion_Pool[i].new_name;

                    if((SiblingOf(item)!=0)&&
                       (NodeType(SiblingOf(item))!=T_LIST))
                      Punt("incorrect declarator_specifier (8.1)");

                    tbl_un=FindNearScopeUn(possible_scopes, type->struct_name);

                    if(tbl_un != 0)             /* in table */
                      {
                      /* redefinition? */
                      if(SiblingOf(item) != 0)
                       {   /* has fields - is a def */
           /*
           ** DIA - 4/23/93: This is a real mess.  Lineno and Colno trail
           **  behind actual values.  I will allow, now, redefinitions in
           **  order to handle a union used before defined.
           */
           /*        if(! ((tbl_un->lineno == Lineno) &&
           **                 (tbl_un->colno == Colno) &&
           **                 !strcmp(tbl_un->filename, Filename)))
           **             Punt("Union Redefined (1)");
           */
                      rename_struct ?
                        DefineUnionWithRenaming(item, type->struct_name) :
                        DefineUnion(item, type->struct_name);
                        tbl_un = FindNearScopeUn(possible_scopes, 
						 type->struct_name);
                        if(tbl_un == 0)
                          Punt("Union define internal error");
                        else
                          if(tbl_un->new_name != 0)
                            type->struct_name = tbl_un->new_name;
                       }
                      else
                        if(tbl_un->new_name != 0)       /*rename */
                          type->struct_name = tbl_un->new_name;
                    }
                   else /* Define Union */
                    {
                    /* BCC - 10/30/96 */
                    rename_struct ?
                      DefineUnionWithRenaming(item, type->struct_name) :
                      DefineUnion(item, type->struct_name);
                      tbl_un = FindNearScopeUn(possible_scopes,
                                             type->struct_name);
                /* TLJ - 1/15/96: Modified so that something cast as
                 *      a pointer to a struct that is not yet defined
                 *      will not cause a punt (since this is just an address).
                 */
                /*    if(tbl_un == 0)
                 *      Punt("Internal Error in Union Def (1)");
                 *    else
                 *      if(tbl_un->new_name != 0)
                 *        type->struct_name = tbl_un->new_name;
                 */
                    if(tbl_un == 0)
                        if ((SiblingOf(list) &&
                                NodeType(SiblingOf(list)) == T_ID &&
                                !strcmp(StringOf(SiblingOf(list)),"P")))
                            /* BCC - 10/31/96 */
                            rename_struct ?
                              DefineUnionWithRenaming(item, type->struct_name):
                              DefineUnion(item, type->struct_name);
                        else
                            Punt("Internal Error in Struct Def (1)");
                    else
                      if(tbl_un->new_name != 0)
                        type->struct_name = tbl_un->new_name;
                    }
                   }
                 }
                else
                  Punt("incorrect declarator specifier (8.2)");
              } else
                if (! strcmp(spec, "ENUM")) {
                  if (type->type & (TY_STRUCT|TY_UNION|TY_ENUM))
                    Punt("incorrect declarator_specifier (9)");
                  type->type |= TY_ENUM;
                  item = SiblingOf(item);
                  if(item!=0) {
                    if(NodeType(item)!=T_ID) { /* give dummy name */
                      if(NodeType(item)==T_LIST) {
                        type->struct_name = StructName();
                        DefineEnum(item, type->struct_name);
                        /* 5/92 - fix up so enum_name points to new_name */
                        tbl_en = FindNearScopeEn(possible_scopes,
                                                 type->struct_name);
                        if(tbl_en == 0)
                          Punt("Enum define internal error");
                        if(tbl_en->new_name != 0)
                          type->struct_name = tbl_en->new_name;
                      }
                      else
                        Punt("incorrect declarator_specifier (10)");
                    }
                    else {
                      type->struct_name = StringOf(item);
                      if((SiblingOf(item)!=0)&&
                         (NodeType(SiblingOf(item))!=T_LIST))
                        Punt("incorrect declarator specifier (10.1)");
                      tbl_en = FindNearScopeEn(possible_scopes,
                                               type->struct_name);
                      if(tbl_en != 0) { /* in table */
                        if(SiblingOf(item) != 0) { /* has fields - is def */
                          if(! ((tbl_en->lineno == Lineno) &&  /* same pos */
                                (tbl_en->colno == Colno) &&
                                !strcmp(tbl_en->filename, Filename)))
/* BCC - if it's doing split now, skip the checking for duplicated enum 7/1/95*/
                            if (split == 0)
                              Punt("Enum Redefined (1)");
                            else {
                              DefineEnum(item, type->struct_name);
                              tbl_en = FindNearScopeEn(possible_scopes,
                                                       type->struct_name);
                              if (tbl_en != 0 && tbl_en->new_name != 0)
                                  type->struct_name = tbl_en->new_name;
                            }
                        } else if(tbl_en->new_name != 0)  /* rename */
                          type->struct_name = tbl_en->new_name;
                      } else {
                        DefineEnum(item, type->struct_name);
                        /* GEH - added below code to use new name of enum */
                        tbl_en = FindNearScopeEn(possible_scopes,
                                                 type->struct_name);
                        if (tbl_en != 0 && tbl_en->new_name != 0)
                            type->struct_name = tbl_en->new_name;
                      }
                    }
                  }
                  else
                    Punt("incorrect declarator specifier (10.2)");
                } else
                  Punt("incorrect declarator_specifier field (11)");
      }
    }
  }

  /* BCC - 3/95 - declare a function as extern; moved from Dcltr section
        above */
  if (Typedef != TRUE && type->dcltr != NIL && type->dcltr->method == D_FUNC &&
                     (! (type->type & TY_STATIC)))
        type->type |= TY_EXTERN;

  /* GEH - specifier should default to int if no type specifier present */
  if (!(TY_TYPE & type->type)) type->type |= TY_INT;
  Pop();        /* level 1 */
  UnifyArithmeticType(type);    /* cast.c */
  return type;
}
/*===================================================================*/
/* Read function pragma(s) : apply to the current function */
/*
 * list = $Pragma* = (PRAGMA $String $ExprList $Pos?)* 
 */
static ReadFnPragmas(list)
     LIST list;
{
  LIST opcode, position, p;
  Expr expr = 0;
  Expr ex_ptr, temp_expr;
  char *keyword;
  Pragma new, ptr;
  for(; list!=0; list=SiblingOf(list)) {
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("incorrect function pragma specifier (1)");
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect function pragma specifier (2)");
    keyword = StringOf(opcode);
    if(strcmp(keyword, "PRAGMA"))
      Punt("incorrect function pragma specifier (3)");
    opcode = SiblingOf(opcode);
    /* Specifier string */
    if((opcode==0)||(NodeType(opcode)!=T_STRING))
      Punt("incorrect function pragma specifier (4)");
    keyword = StringOf(opcode);
    /* GEH - removed since specifier does not contain pragma type (5/16/93)
    if((keyword[1]!='F')||(keyword[2]!='N'))
      Punt("incorrect function pragma specifier (5)");
    */
    p = SiblingOf(opcode);
    if(p!=0) {
      if(strcmp(StringOf(ChildOf(p)), "POS")) {
	temp_expr = Expression(p);
	expr = ReduceExpr(temp_expr);
	RemoveExpr(temp_expr);
	p = SiblingOf(p);
	/* Expr */
	for(; p != 0; p = SiblingOf(p)) {
	  if(NodeType(p) != T_LIST)
	    Punt("incorrect function pragma specifier (6)");
	  if(!strcmp(StringOf(ChildOf(p)), "POS"))
	    break;
	  if(expr->next == 0) {
	    temp_expr = Expression(p);
	    expr->next = ReduceExpr(temp_expr);
	    RemoveExpr(temp_expr);
	  }
	  else {
	    ex_ptr = expr->next;
	    while(ex_ptr->next != 0) ex_ptr = ex_ptr->next;
	    temp_expr = Expression(p);
	    ex_ptr->next = ReduceExpr(temp_expr);
	    RemoveExpr(temp_expr);
	  }
	}
      }
    }
    new = NewPragma(keyword, expr);
    /* BCC - garbage collection - 8/25/96 */
    RemoveExpr(expr);
    /* position */
    position = p;
    if(position!=0) {
      if(NodeType(position) != T_LIST)
	Punt("incorrect position information (1)");
      else {
	position = ChildOf(position);
	if((position==0)||(NodeType(position)!=T_ID))
	  Punt("incorrect position information (2)");
	else
	  if(!strcmp(StringOf(position),"POS")) {
	    Filename = StringOf(SiblingOf(position));
	    Lineno = IntegerOf(SiblingOf(SiblingOf(position)));
	    Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(position))));
	  }
	  else
	    Punt("incorrect position information (3)");
      }
    }
    if(Filename != 0) {
      new->lineno = Lineno;
      new->colno = Colno;
      new->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(new->filename, "%s", Filename);
    }
    /* attach to function */
    ptr = currentFuncDcl->pragma;
    if (ptr==0)
      currentFuncDcl->pragma = new;
    else {
      while (ptr->next!=0) ptr = ptr->next;
      ptr->next = new;
    }
  }
}

/*
 *  Type definition
 *  list =  $DeclSpec 
 *
 *  I assume that TYPEDEF only occurs after DEF and is followed by a TcSpec.
 *  Thus, I am handling the following format:
 *	(DEF $DeclSpec $Pos?)
 *	$DeclSpec = ($TcSpec+ $Dcltr*)
 *	where, $TcSpec = (TYPEDEF $TypdID?)  
 * 
 */
static DefineType(list)
     LIST list;
{
  LIST item;
  TypeDcl ty;
  item = SiblingOf(ChildOf(ChildOf(list)));
  ty = NewTypeDcl();
  if(NodeType(item)==T_ID)
    ty->name = StringOf(item);
  if(Filename != 0) {
    ty->lineno = Lineno;
    ty->colno = Colno;
    ty->filename = (char *)malloc(strlen(Filename)+1);
    sprintf(ty->filename, "%s", Filename);
  }
  /* list is a DeclSpec */
  ty->type = DeclSpec(list);
  /* insert into symbol table */
  if (FindTypeDef(ty->name)!=0) {
    fprintf(Ferr, "=> typedef %s\n", ty->name);
    Punt("multiple type definition");
  }
  AddTypeDef(ty->name, ty);
}

/*===================================================================*/
/* Read in a struct definition. */
/*
 *  list = $StructID? $FieldDecl*
 *  name is given when it is a dummy name - otherwise take name from list.
 *  
 *  Since we are going to send through Hcode, we will not allow multiple
 *  structure definitions (regardless of scope) and we will move all structure
 *  definitions out to the global level (still use symbol tree in case correct
 *  this in the future - scope = 0).
 * 
 *  Called by:
 *	
 *	DeclSpec - if type is a struct but struct not defined yet - if doesn't
 *		   have fields then error because used before defined.
 *	TypeDefinition - in a regular DEF - again should have fields (this case,
 *		   the empty struct, will also be caught by C1).
 *
 *  Cases to handle:
 *	No fields - punt.
 *
 *  Output:
 *	Define Structure and add to symbol table.
 *	output (DEF (STRUCT ...)) in pcode or struct ... in C.
 *	
 */
static DefineStructWithRenaming(list,name)
     LIST list;
     char *name;
{
  LIST item;
  StructDcl en, en2;
  Field field, ptr;
  int i;
  char buffer[256];
  StructUnionPoolElem elem, new_elem;

  /* TLJ 2/27/96 - Increment nested defines counter */
  nested_dcls++;

  en = NewStructDcl();
  if (list==0)
    Punt("incorrect struct definition (1)");
  if(NodeType(list)!=T_ID)
    en->name = name;
  else {
    /* BCC - skip the __Tdddddddd prefix - 10/29/96 */
    char *name;

    name = RemoveTPrefix(StringOf(list));
    en->name = name;	/* var name */
    list = SiblingOf(list);       /* field */
  }
  if (Filename!=0) {
    en->lineno = Lineno;		/* position */
    en->colno = Colno;
    en->filename = (char *)malloc(strlen(Filename)+1);
    sprintf(en->filename, "%s", Filename);
  }
/* DIA - 4/23/94 Allow redefining structs.
**  if((list==0)||(NodeType(list)!=T_LIST))
**    ** struct empty - or used before defined **
**    Punt("incorrect struct definition (2)");  
** 
**  (* 4/92 - Add to symbol tree first.  When rename, fields which ref
**   * this struct will also be renamed **
**  if(FindStruct(en->name, scope) != 0) {
**    fprintf(Ferr, "=> struct %s\n", en->name);
**    Punt("multiple definition of a struct");
**  }
*/
  if(scope!=0) {		/* rename if not global def */
    if(! scope_assigned) 
      en->new_name = NewName(en->name, scope);
  }

  /* BCC - 7/12/96 
   * register first. In a recursive definition, the nested declaration won't
   * be inserted in DeclSpec()
   */

  if (!FindStruct(en->name, scope)) 
    AddStruct(en->name, en->new_name, en, scope);

  /* BCC - always parse the fields - 7/3/96 */
  for (; list!=0; list=SiblingOf(list)) {
    Push(list);	/* level 2 */
    field = NewField();
    /* ($VarID $DeclSpec $Expr?) | ($DeclSpec $Expr) */
    /*				   ^ - to handle bit fields */
    if (NodeType(list)!=T_LIST)
      Punt("incorrect struct field definition (1)");
    item = ChildOf(list);
    if (item==0)
      Punt("incorrect struct field definition (2)");
    if(NodeType(item)==T_ID) {	/* ($VarID $DeclSpec $Expr?) */
      field->name = StringOf(item);
      item = SiblingOf(item);
      if ((item==0)||(NodeType(item)!=T_LIST))
        Punt("incorrect struct field definition (3)");
      field->type = DeclSpec(item);
      item = SiblingOf(item);
      if (item!=0) {
        Expr exp;
        exp = Expression(item);
        field->bit_field = ReduceExpr(exp);
        RemoveExpr(exp);
      }
    } else {			/* ($DeclSpec $Expr) */
      if ((item==0)||(NodeType(item)!=T_LIST))
        Punt("incorrect struct field definition (4)");
      field->type = DeclSpec(item);	
      item = SiblingOf(item);
      if(item == 0)
        Punt("incorrect struct field definition (5)");
      else {
        Expr exp;
        exp = Expression(item);
        field->bit_field = ReduceExpr(exp);
        RemoveExpr(exp);
      }
    }
    /* BCC - if field->name == "__IMPACT_NULL__", skip it - 6/4/95 */
    /* BCC - if the bit-field length is 0, skip it - 7/9/96 */
    if ((field->name == NULL || strcmp(field->name, "__IMPACT_NULL__")) &&
	(field->bit_field == NULL || field->bit_field->value.scalar)) {
      ptr = en->fields;
      if (ptr==0) {
        en->fields = field;
      } else {
        while (ptr->next!=0) ptr = ptr->next;
        ptr->next = field;
      }
    }
    /* BCC - added to clean the memory garbage - 7/9/96 */
    else {
      RemoveField(field);
    }
    Pop();	/* level 2 */
  }

  for (i=0; i < max_struct_union_pool; i++) {
    if (!strcmp(StructUnion_Pool[i].name, en->name)) break;
  }

  /* BCC - this struct has aliases - 7/3/96 */
  if ( i != max_struct_union_pool) {
    elem = StructUnion_Pool[i].elem;
    if (en->fields) {
      while (elem) {
        if (elem->type == TY_STRUCT && SameStructDcl(en, elem->ptr.st, 0)) 
	  break;
        elem = elem->next;
      }
    }
    /* Yet another alias */
    if (elem == NULL) {
      sprintf(buffer, "%s_impact%d", en->name, SUE_counter++);
      en->name = strdup(buffer);
      printf("new name = %s\n", buffer);
      AddStruct(en->name, en->new_name, en, scope);

      new_elem = NewStructUnionPoolElem(TY_STRUCT);
      new_elem->ptr.st = en;
      new_elem->next = StructUnion_Pool[i].elem;
      StructUnion_Pool[i].elem = new_elem;
      StructUnion_Pool[i].new_name = en->name;
      new_struct_union_created = 1;

      if (nested_dcls == 1) {
        /* TLJ 2/25/96 - Set input type to tell how to process */
        P_Input_Type = P_INPUT_STRUCT;
        P_Struct = en;
      }
      else {
        /* TLJ 2/25/96 - note that there are nested dcls */
        dcl_has_nested_dcls = TRUE;
        P_DclList = AddDcl2List(P_DclList,en,TT_STRUCT);
      }
    }
    else {
      if (en->fields)
        /* Found a same struct among the aliases */
        StructUnion_Pool[i].new_name = elem->ptr.st->name;
    }
  }
  else if (FindUnion(en->name, scope)) {
    if (max_struct_union_pool == MAX_STRUCT_UNION_POOL_SIZE) 
      Punt("StructUnion_Pool overflow");
    if (en->fields) {
      sprintf(buffer, "%s_impact%d", en->name, SUE_counter++);
      printf("new name = %s\n", buffer);
      new_elem = NewStructUnionPoolElem(TY_STRUCT);
      new_elem->ptr.st = en;
      new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
      StructUnion_Pool[max_struct_union_pool].elem = new_elem;
      StructUnion_Pool[max_struct_union_pool].name = strdup(en->name);
      StructUnion_Pool[max_struct_union_pool].new_name = strdup(buffer);
	  
      new_elem = NewStructUnionPoolElem(TY_UNION);
      new_elem->ptr.un = FindUnion(en->name, scope);
      new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
      StructUnion_Pool[max_struct_union_pool].elem = new_elem;

      max_struct_union_pool++;
      new_struct_union_created = 1;
      en->name = strdup(buffer);
      /* rename the new one and add to the symbol table */
      AddStruct(en->name, en->new_name, en, scope);

      if (nested_dcls == 1) {
        /* TLJ 2/25/96 - Set input type to tell how to process */
        P_Input_Type = P_INPUT_STRUCT;
        P_Struct = en;
      }
      else {
        /* TLJ 2/25/96 - note that there are nested dcls */
        dcl_has_nested_dcls = TRUE;
        P_DclList = AddDcl2List(P_DclList,en,TT_STRUCT);
      }
    }
  }
  else {
    en2 = FindStruct(en->name, scope);
    if (en2 == en) {
      if (nested_dcls == 1) {
        /* TLJ 2/25/96 - Set input type to tell how to process */
        P_Input_Type = P_INPUT_STRUCT;
        P_Struct = en;
      }
      else {
        /* TLJ 2/25/96 - note that there are nested dcls */
        dcl_has_nested_dcls = TRUE;
        P_DclList = AddDcl2List(P_DclList,en,TT_STRUCT);
      }
    }
    else if (en->fields != 0) {
      if (en2->fields == 0) {

/* 
 * BCC - handles two different cases - 7/5/96 
 * 1) 	struct s;
 *	struct s { int i; };
 *	when the second struct s is paresd, the first one has already been 
 *	processed. so we would like to dump the second definition and update
 *	the symbol table to replace the fields pointer of the first one to
 *	the second.
 * 2)	struct s {
 *	    int i;
 *	    struct s *next;
 *	}
 *	in this case, the nest s has been put to the symbol table with no
 *	fields. but it's definition has not been dumped yet. in this case
 *	we will skip dumping the definition of the outer one.
 */
        /* real definition */
	en2->fields = en->fields;
	en->fields = 0;
	if (!IsDclOnList(P_DclList, en2)) {
	  if (nested_dcls == 1) {
	    /* TLJ 2/25/96 - Set input type to tell how to process */
	    P_Input_Type = P_INPUT_STRUCT;
	    P_Struct = en2;
	  }
	  else {
	    /* TLJ 2/25/96 - note that there are nested dcls */
	    dcl_has_nested_dcls = TRUE;
	    P_DclList = AddDcl2List(P_DclList,en2,TT_STRUCT);
	  }
	}
      }
      else {
        if (! SameStructDcl(en, en2, 1)) {
	  if (max_struct_union_pool == MAX_STRUCT_UNION_POOL_SIZE) 
	    Punt("StructUnion_Pool overflow");
	  sprintf(buffer, "%s_impact%d", en->name, SUE_counter++);
	  printf("new name = %s\n", buffer);
          new_elem = NewStructUnionPoolElem(TY_STRUCT);
	  new_elem->ptr.st = en;
	  new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
	  StructUnion_Pool[max_struct_union_pool].elem = new_elem;
	  StructUnion_Pool[max_struct_union_pool].name = strdup(en->name);
	  StructUnion_Pool[max_struct_union_pool].new_name = strdup(buffer);

          new_elem = NewStructUnionPoolElem(TY_STRUCT);
	  new_elem->ptr.st = en2;
	  new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
	  StructUnion_Pool[max_struct_union_pool].elem = new_elem;

	  max_struct_union_pool++;
	  new_struct_union_created = 1;
	  en->name = strdup(buffer);
	  /* rename the new one and add to the symbol table */
          AddStruct(en->name, en->new_name, en, scope);

	  if (nested_dcls == 1) {
	    /* TLJ 2/25/96 - Set input type to tell how to process */
	    P_Input_Type = P_INPUT_STRUCT;
	    P_Struct = en;
	  }
	  else {
	    /* TLJ 2/25/96 - note that there are nested dcls */
	    dcl_has_nested_dcls = TRUE;
	    P_DclList = AddDcl2List(P_DclList,en,TT_STRUCT);
	  }
        }
	else {
	  if (nested_dcls == 1) {
	    /* TLJ 2/25/96 - Set input type to tell how to process */
	    P_Input_Type = P_INPUT_STRUCT;
	    P_Struct = en;
	  }
	  else {
	    /* TLJ 2/25/96 - note that there are nested dcls */
	    dcl_has_nested_dcls = TRUE;
	    P_DclList = AddDcl2List(P_DclList,en,TT_STRUCT);
	  }
	}
      }
    }
  }
}

/*===================================================================*/
/* Read in a struct definition. */
static DefineStruct(list,name)
     LIST list;
     char *name;
{
  LIST item;
  StructDcl en, en2;
  Field field, ptr;
  int bit_offset=0;

  /* TLJ 2/27/96 - Increment nested defines counter */
  nested_dcls++;

  en = NewStructDcl();
  if (list==0)
    Punt("incorrect struct definition (1)");
  if(NodeType(list)!=T_ID)
    en->name = name;
  else {
    en->name = StringOf(list);	/* var name */
    list = SiblingOf(list);       /* field */
  }
  if (Filename!=0) {
    en->lineno = Lineno;		/* position */
    en->colno = Colno;
    en->filename = (char *)malloc(strlen(Filename)+1);
    sprintf(en->filename, "%s", Filename);
  }
/* DIA - 4/23/94 Allow redefining structs.
**  if((list==0)||(NodeType(list)!=T_LIST))
**    ** struct empty - or used before defined **
**    Punt("incorrect struct definition (2)");  
** 
**  (* 4/92 - Add to symbol tree first.  When rename, fields which ref
**   * this struct will also be renamed **
**  if(FindStruct(en->name, scope) != 0) {
**    fprintf(Ferr, "=> struct %s\n", en->name);
**    Punt("multiple definition of a struct");
**  }
*/
  if(scope!=0) {		/* rename if not global def */
    if(! scope_assigned) 
      en->new_name = NewName(en->name, scope);
  }

  /* DIA - 4/23/94: More recursive struct stuff */
  en2 = 0;
  if (!(en2 = FindStruct(en->name, scope)) || (en2->fields == 0) )
   {
    if (en2) {
      RemoveStructDcl(en);
      en = en2;
    }
    else
      AddStruct(en->name, en->new_name, en, scope);
      /* process struct_fields */
    for (; list!=0; list=SiblingOf(list)) {
        Push(list);	/* level 2 */
        field = NewField();
      /* ($VarID $DeclSpec $Expr?) | ($DeclSpec $Expr) */
      /*				   ^ - to handle bit fields */
      if (NodeType(list)!=T_LIST)
        Punt("incorrect struct field definition (1)");
      item = ChildOf(list);
      if (item==0)
        Punt("incorrect struct field definition (2)");
      if(NodeType(item)==T_ID) {	/* ($VarID $DeclSpec $Expr?) */
        field->name = StringOf(item);
        item = SiblingOf(item);
        if ((item==0)||(NodeType(item)!=T_LIST))
          Punt("incorrect struct field definition (3)");
        field->type = DeclSpec(item);
        item = SiblingOf(item);
        if (item!=0) {
	  Expr exp;
	  exp = Expression(item);
	  field->bit_field = ReduceExpr(exp);
	  RemoveExpr(exp);
        }
      } else {			/* ($DeclSpec $Expr) */
        if ((item==0)||(NodeType(item)!=T_LIST))
 	  Punt("incorrect struct field definition (4)");
        field->type = DeclSpec(item);	
        item = SiblingOf(item);
        if(item == 0)
	  Punt("incorrect struct field definition (5)");
        else {
	  Expr exp;
	  exp = Expression(item);
	  field->bit_field = ReduceExpr(exp);
	  RemoveExpr(exp);
        }
      }
      /* BCC - measure the type fields - 2/18/97 */
      /* consecutive bit fields */
      if (field->bit_field) {
	  int num_bit;

	  num_bit = IntegralExprValue(field->bit_field);
	  if (num_bit) {
	      field->offset = en->size;
	      field->size = 1;
	      bit_offset += num_bit;
	      /*
	      field->offset = en->size + (bit_offset + 1 + 7) / 8 - 1;
	      field->size = ((bit_offset + num_bit + 7) / 8) - ((bit_offset + 1 + 7) / 8) + 1; 
	      bit_offset += num_bit;
	      */
	  }
	  else {
	      field->offset = en->size;
	      field->size = 1;
	      bit_offset += num_bit;
	  }
      }
      else {
	  if (bit_offset) {
	      en->size += 1;
	      /*
	      en->size += (bit_offset + 7) / 8;
	      */
	      bit_offset = 0;
	  }
	  field->offset = en->size;
	  field->size = SizeOf(field->type);
	  en->size += field->size;
#if 0
	  fprintf(stderr, "%s.%s : %d_%d\n", en->name, field->name, 
		  field->offset, field->offset + field->size - 1);
#endif
      }

      /* BCC - if field->name == "__IMPACT_NULL__", skip it - 6/4/95 */
      /* BCC - if the bit-field length is 0, skip it - 7/9/96 */
      /* BCC - don't call strcmp is field->name is NULL - 10/27/97 */
      if ((field->name == NULL || strcmp(field->name, "__IMPACT_NULL__")) &&
          (field->bit_field == NULL || field->bit_field->value.scalar)) {
	ptr = en->fields;
	if (ptr==0) {
	  en->fields = field;
	} else {
	  while (ptr->next!=0) ptr = ptr->next;
	  ptr->next = field;
	}
      }
      Pop();	/* level 2 */
    
    }
    if (bit_offset) {
	en->size += 1;
	bit_offset = 0;
    }
    /* BCC - always bluff the size of unions to prevent the single-field
     * struct problem
     */
    /* BCC - don't bluff when handling forward declaration because this
     * will push the first field to start at offset 4 instead of 0
     */
    if (en->size)
	en->size += 4;

    if (nested_dcls == 1)
    {
      /* TLJ 2/25/96 - Set input type to tell how to process */
      P_Input_Type = P_INPUT_STRUCT;
      P_Struct = en;
    }
    else
    {
      /* TLJ 2/25/96 - note that there are nested dcls */
      dcl_has_nested_dcls = TRUE;
      P_DclList = AddDcl2List(P_DclList,en,TT_STRUCT);
    }
  }
  /* BCC - garbage collection - 8/26/96 */
  else {
    RemoveStructDcl(en);
  }
}

/*===================================================================*/
/* BCC - 10/30/96
/* Read in an union definition and rename it if necessary. */
static DefineUnionWithRenaming(list,name)
     LIST list;
     char *name;
{
  LIST item;
  UnionDcl en, en2;
  Field field, ptr;
  int i;
  char buffer[256];
  StructUnionPoolElem elem, new_elem;

  /* TLJ 2/27/96 - Increment nested defines counter */
  nested_dcls++;

  en = NewUnionDcl();
  if (list==0)
    Punt("incorrect union definition (1)");
  if(NodeType(list)!=T_ID)
    en->name = name;
  else {
    /* BCC - skip the __Tdddddddd prefix - 10/29/96 */
    char *name;

    name = RemoveTPrefix(StringOf(list));
    en->name = name;	/* var name */
    list = SiblingOf(list);       /* field */
  }
  if (Filename!=0) {
    en->lineno = Lineno;		/* position */
    en->colno = Colno;
    en->filename = (char *)malloc(strlen(Filename)+1);
    sprintf(en->filename, "%s", Filename);
  }
/* DIA - 4/23/94 Allow redefining structs.
**  if((list==0)||(NodeType(list)!=T_LIST))
**    ** struct empty - or used before defined **
**    Punt("incorrect struct definition (2)");  
** 
**  (* 4/92 - Add to symbol tree first.  When rename, fields which ref
**   * this struct will also be renamed **
**  if(FindStruct(en->name, scope) != 0) {
**    fprintf(Ferr, "=> struct %s\n", en->name);
**    Punt("multiple definition of a struct");
**  }
*/
  if(scope!=0) {		/* rename if not global def */
    if(! scope_assigned) 
      en->new_name = NewName(en->name, scope);
  }

  /* BCC - 7/12/96 
   * register first. In a recursive definition, the nested declaration won't
   * be inserted in DeclSpec()
   */

  if (!FindUnion(en->name, scope)) 
    AddUnion(en->name, en->new_name, en, scope);

  /* BCC - always parse the fields - 7/3/96 */
  for (; list!=0; list=SiblingOf(list)) {
    Push(list);	/* level 2 */
    field = NewField();
    /* ($VarID $DeclSpec $Expr?) | ($DeclSpec $Expr) */
    /*				   ^ - to handle bit fields */
    if (NodeType(list)!=T_LIST)
      Punt("incorrect struct field definition (1)");
    item = ChildOf(list);
    if (item==0)
      Punt("incorrect struct field definition (2)");
    if(NodeType(item)==T_ID) {	/* ($VarID $DeclSpec $Expr?) */
      field->name = StringOf(item);
      item = SiblingOf(item);
      if ((item==0)||(NodeType(item)!=T_LIST))
        Punt("incorrect union field definition (3)");
      field->type = DeclSpec(item);
      item = SiblingOf(item);
      if (item!=0) {
        Expr exp;
        exp = Expression(item);
        field->bit_field = ReduceExpr(exp);
        RemoveExpr(exp);
      }
    } else {			/* ($DeclSpec $Expr) */
      if ((item==0)||(NodeType(item)!=T_LIST))
        Punt("incorrect union field definition (4)");
      field->type = DeclSpec(item);	
      item = SiblingOf(item);
      if(item == 0)
        Punt("incorrect union field definition (5)");
      else {
        Expr exp;
        exp = Expression(item);
        field->bit_field = ReduceExpr(exp);
        RemoveExpr(exp);
      }
    }
    /* BCC - if field->name == "__IMPACT_NULL__", skip it - 6/4/95 */
    /* BCC - if the bit-field length is 0, skip it - 7/9/96 */
    if ((field->name == NULL || strcmp(field->name, "__IMPACT_NULL__")) &&
	(field->bit_field == NULL || field->bit_field->value.scalar)) {
      ptr = en->fields;
      if (ptr==0) {
        en->fields = field;
      } else {
        while (ptr->next!=0) ptr = ptr->next;
        ptr->next = field;
      }
    }
    /* BCC - added to clean the memory garbage - 7/9/96 */
    else {
      RemoveField(field);
    }
    Pop();	/* level 2 */
  }

  for (i=0; i < max_struct_union_pool; i++) {
    if (!strcmp(StructUnion_Pool[i].name, en->name)) break;
  }

  /* BCC - this struct has aliases - 7/3/96 */
  if ( i != max_struct_union_pool) {
    elem = StructUnion_Pool[i].elem;
    if (en->fields) {
      while (elem) {
        if (elem->type == TY_UNION && SameUnionDcl(en, elem->ptr.un, 0))
	  break;
        elem = elem->next;
      }
    }
    /* Yet another alias */
    if (elem == NULL) {
      sprintf(buffer, "%s_impact%d", en->name, SUE_counter++);
      en->name = strdup(buffer);
      printf("new name = %s\n", buffer);
      AddUnion(en->name, en->new_name, en, scope);

      new_elem = NewStructUnionPoolElem(TY_UNION);
      new_elem->ptr.un = en;
      new_elem->next = StructUnion_Pool[i].elem;
      StructUnion_Pool[i].elem = new_elem;
      StructUnion_Pool[i].new_name = en->name;
      new_struct_union_created = 1;

      if (nested_dcls == 1) {
        /* TLJ 2/25/96 - Set input type to tell how to process */
        P_Input_Type = P_INPUT_UNION;
        P_Union = en;
      }
      else {
        /* TLJ 2/25/96 - note that there are nested dcls */
        dcl_has_nested_dcls = TRUE;
        P_DclList = AddDcl2List(P_DclList,en,TT_UNION);
      }
    }
    else {
      if (en->fields)
        /* Found a same struct among the aliases */
        StructUnion_Pool[i].new_name = elem->ptr.un->name;
    }
  }
  else if (FindStruct(en->name, scope)) {
    if (max_struct_union_pool == MAX_STRUCT_UNION_POOL_SIZE) 
      Punt("StructUnion_Pool overflow");
    if (en->fields) {
      sprintf(buffer, "%s_impact%d", en->name, SUE_counter++);
      printf("new name = %s\n", buffer);
      new_elem = NewStructUnionPoolElem(TY_UNION);
      new_elem->ptr.un = en;
      new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
      StructUnion_Pool[max_struct_union_pool].elem = new_elem;
      StructUnion_Pool[max_struct_union_pool].name = strdup(en->name);
      StructUnion_Pool[max_struct_union_pool].new_name = strdup(buffer);

      new_elem = NewStructUnionPoolElem(TY_STRUCT);
      new_elem->ptr.st = FindStruct(en->name, scope);
      new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
      StructUnion_Pool[max_struct_union_pool].elem = new_elem;

      max_struct_union_pool++;
      new_struct_union_created = 1;
      en->name = strdup(buffer);
      /* rename the new one and add to the symbol table */
      AddUnion(en->name, en->new_name, en, scope);

      if (nested_dcls == 1) {
        /* TLJ 2/25/96 - Set input type to tell how to process */
        P_Input_Type = P_INPUT_UNION;
        P_Union = en;
      }
      else {
        /* TLJ 2/25/96 - note that there are nested dcls */
        dcl_has_nested_dcls = TRUE;
        P_DclList = AddDcl2List(P_DclList,en,TT_UNION);
      }
    }
  }
  else {
    en2 = FindUnion(en->name, scope);
    if (en2 == en) {
      if (nested_dcls == 1) {
        /* TLJ 2/25/96 - Set input type to tell how to process */
        P_Input_Type = P_INPUT_UNION;
        P_Union = en;
      }
      else {
        /* TLJ 2/25/96 - note that there are nested dcls */
        dcl_has_nested_dcls = TRUE;
        P_DclList = AddDcl2List(P_DclList,en,TT_UNION);
      }
    }
    else if (en->fields != 0) {
      if (en2->fields == 0) {

/* 
 * BCC - handles two different cases - 7/5/96 
 * 1) 	union s;
 *	union s { int i; };
 *	when the second union s is paresd, the first one has already been 
 *	processed. so we would like to dump the second definition and update
 *	the symbol table to replace the fields pointer of the first one to
 *	the second.
 * 2)	union s {
 *	    int i;
 *	    union s *next;
 *	}
 *	in this case, the nest s has been put to the symbol table with no
 *	fields. but it's definition has not been dumped yet. in this case
 *	we will skip dumping the definition of the outer one.
 */
        /* real definition */
	en2->fields = en->fields;
	en->fields = 0;
	if (!IsDclOnList(P_DclList, en2)) {
	  if (nested_dcls == 1) {
	    /* TLJ 2/25/96 - Set input type to tell how to process */
	    P_Input_Type = P_INPUT_UNION;
	    P_Union = en2;
	  }
	  else {
	    /* TLJ 2/25/96 - note that there are nested dcls */
	    dcl_has_nested_dcls = TRUE;
	    P_DclList = AddDcl2List(P_DclList,en2,TT_UNION);
	  }
	}
      }
      else {
        if (! SameUnionDcl(en, en2, 1)) {
	  if (max_struct_union_pool == MAX_STRUCT_UNION_POOL_SIZE) 
	    Punt("StructUnion_Pool overflow");
	  sprintf(buffer, "%s_impact%d", en->name, SUE_counter++);
	  printf("new name = %s\n", buffer);
          new_elem = NewStructUnionPoolElem(TY_UNION);
	  new_elem->ptr.un = en;
	  new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
	  StructUnion_Pool[max_struct_union_pool].elem = new_elem;
	  StructUnion_Pool[max_struct_union_pool].name = strdup(en->name);
	  StructUnion_Pool[max_struct_union_pool].new_name = strdup(buffer);

          new_elem = NewStructUnionPoolElem(TY_UNION);
	  new_elem->ptr.un = en2;
	  new_elem->next = StructUnion_Pool[max_struct_union_pool].elem;
	  StructUnion_Pool[max_struct_union_pool].elem = new_elem;

	  max_struct_union_pool++;
	  new_struct_union_created = 1;
	  en->name = strdup(buffer);
	  /* rename the new one and add to the symbol table */
          AddUnion(en->name, en->new_name, en, scope);

	  if (nested_dcls == 1) {
	    /* TLJ 2/25/96 - Set input type to tell how to process */
	    P_Input_Type = P_INPUT_UNION;
	    P_Union = en;
	  }
	  else {
	    /* TLJ 2/25/96 - note that there are nested dcls */
	    dcl_has_nested_dcls = TRUE;
	    P_DclList = AddDcl2List(P_DclList,en,TT_UNION);
	  }
        }
	else {
	  if (nested_dcls == 1) {
	    /* TLJ 2/25/96 - Set input type to tell how to process */
	    P_Input_Type = P_INPUT_UNION;
	    P_Union = en;
	  }
	  else {
	    /* TLJ 2/25/96 - note that there are nested dcls */
	    dcl_has_nested_dcls = TRUE;
	    P_DclList = AddDcl2List(P_DclList,en,TT_UNION);
	  }
	}
      }
    }
  }
}

/*===================================================================*/
/* Read in an union definition. */
static DefineUnion(list, name)
     LIST list;
     char *name;
{
  LIST item;
  UnionDcl en, en2;
  Field field, ptr;

  /* TLJ 2/27/96 - Increment nested defines counter */
  nested_dcls++;

  en = NewUnionDcl();
  /* union_name%s union_fields*) */
  if (list==0)
    Punt("incorrect union definition (1)");
  if(NodeType(list)!=T_ID)
    en->name = name;
  else {
    en->name = StringOf(list);	/* var name */
    list = SiblingOf(list);       /* 4/92 - take SiblingOf(list) here */
  }
  if(Filename != 0) {
    en->lineno = Lineno;
    en->colno = Colno;
    en->filename = (char *)malloc(strlen(Filename)+1);
    sprintf(en->filename, "%s", Filename);
  }

  /* DIA - 5/6/94 Allow redefining unions.
  **  if((list==0)||(NodeType(list)!=T_LIST))
  **  ** union empty - or used before defined **
  **  Punt("incorrect union definition (2)");
  **  ** insert into symbol table **
  ** if (FindUnion(en->name, scope)!=0) {	
  **  fprintf(Ferr, "=> union %s\n", en->name);
  **  Punt("multiple definition of a union");
  ** }
  */

  if(scope!=0) {		/* rename if not global def */
    if(! scope_assigned)
      en->new_name = NewName(en->name,scope);
  }

  /* DIA - 4/23/94: More recursive union stuff */
  en2 = 0;
  if (!(en2 = FindUnion(en->name, scope)) || (en2->fields == 0) )
   {
    if (en2) { 
      /* BCC - garbage collection - 8/26/96 */
      RemoveUnionDcl(en);
      en = en2;
    }
    else
      AddUnion(en->name, en->new_name,  en, scope);

    /* process union_fields */
    for (; list!=0; list=SiblingOf(list)) {
      Push(list);	/* level 2 */
      field = NewField();
      /* ($VarID $DeclSpec $Expr?) [($DeclSpec $Expr)-only for struct] */
      if (NodeType(list)!=T_LIST)
        Punt("incorrect union field definition (1)");
      item = ChildOf(list);
      if ((item==0)||(NodeType(item)!=T_ID))  
        /* NJW - converted T_STRING to T_ID, we don't have "" */
        Punt("incorrect union field definition (2)");
      field->name = StringOf(item);
      item = SiblingOf(item);
      if ((item==0)||(NodeType(item)!=T_LIST))
        Punt("incorrect union field definition (3)");
      field->type = DeclSpec(item);
      item = SiblingOf(item);
      if (item!=0) {
        Expr exp;
        exp = Expression(item);
        field->bit_field = ReduceExpr(exp);
        RemoveExpr(exp);
      }

      /* BCC - measure the type fields - 2/18/97 */
      field->offset = 0;
      /* consecutive bit fields */
      if (field->bit_field) {
	  int num_bit;

	  num_bit = IntegralExprValue(field->bit_field);
	  field->size = (num_bit + 7) / 8;
      }
      else 
	  field->size = SizeOf(field->type);
      en->size = field->size > en->size ? field->size : en->size;

      ptr = en->fields;
      if (ptr==0) {
        en->fields = field;
      } else {
        while (ptr->next!=0) ptr = ptr->next;
        ptr->next = field;
      }
      Pop();	/* level 2 */
    }
    /* BCC - always bluff the size of structs to prevent the single-field
     * struct problem
     */
    en->size += 4;

    if (nested_dcls == 1)
    {
      /* TLJ 2/25/96 - Set input type to tell how to process */
      P_Input_Type = P_INPUT_UNION;
      P_Union = en;
    }
    else
    {
      /* TLJ 2/25/96 - note that there are nested dcls */
      dcl_has_nested_dcls = TRUE;
      P_DclList = AddDcl2List(P_DclList,en,TT_UNION);
    }
  }
  /* BCC - garbage collection - 8/26/96 */
  else {
    RemoveUnionDcl(en);
  }
}
/*===================================================================*/
/* Read in an Enum definition. */
/* The (ptr) fields of Enum symbol table are connected to
 * EnumDcls. All enum fields must have unique names (even
 * across different enums)
 */
static DefineEnum(list, name)
     LIST list;
     char *name;
{
  LIST item;
  EnumDcl en;
  EnumField field, ptr;
  int enum_val;

  /* TLJ 2/27/96 - Increment nested defines counter */
  nested_dcls++;

  en = NewEnumDcl();
  /* (ENUM $EnumID? $EnumItem*) */
  if (list==0)
    Punt("incorrect enum definition (1)");
  if (NodeType(list)!=T_ID)
    en->name = name;
  else {
    en->name = StringOf(list);	/* var name */
    list = SiblingOf(list);       /* 4/92 */
  }
  if(Filename != 0) {
    en->lineno = Lineno;
    en->colno = Colno;
    en->filename = (char *)malloc(strlen(Filename)+1);
    sprintf(en->filename, "%s", Filename);
  }
  /* 4/92
     list = SiblingOf(list);
     */
/* BCC - commented out for null enum decl, also modified h_gen_c.c - 6/4/95
  if((list==0)||(NodeType(list)!=T_LIST)) 
    Punt("incorrect enum definition (2)");
*/

  /* process enum_fields */

  enum_val = BASE_ENUM_VALUE;

  /* ($EnumId $Expr?) */
  for (; list!=0; list=SiblingOf(list)) {
    Push(list);	/* level 2 */
    field = NewEnumField();
    if (NodeType(list)!=T_LIST)
      Punt("incorrect enum field definition (1)");
    item = ChildOf(list);
    if ((item==0)||(NodeType(item)!=T_ID))
      /* NJW - converted T_STRING to T_ID, we don't have "" */
      Punt("incorrect enum field definition (2)");
    field->name = StringOf(item);
    item = SiblingOf(item);
    if (item!=0) {
      Expr exp;	/* 9-12-89 */
      exp = Expression(item);
      field->value = ReduceExpr(exp);
	/* DMG - added punt and enum_val */
      if (field->value->opcode != OP_int)
          Punt("incorrect enum field definition: must reduce to int");
      enum_val = field->value->value.scalar + 1;
      RemoveExpr(exp);
    }
    else {
      field->value = NewIntExpr(enum_val++);
    }

    ptr = en->fields;
    if (ptr==0) {
      en->fields = field;
    } else {
      while (ptr->next!=0) ptr = ptr->next;
      ptr->next = field;
    }
    /* insert enum field into enum field symbol table used for
     * semantic checking
     */
    if((FindEnumField(field->name, scope)!=0) ||
       (FindVar(field->name, scope)!=0)) {	
/* BCC - if it's doing split now, skip the checking for duplicated enum 7/1/95*/
      if (split == 0) {
	fprintf(Ferr, "=> enum field %s\n", field->name);
	Punt("multiple definition of a enum field");
      }
    }
    if(scope!=0) {		/* rename if not global def */
      if(! scope_assigned)
	field->new_name = NewName(field->name, scope);
    }
    /* if scope = 0, field->new_name = 0 */
    AddEnumField(field->name, field->new_name, en, scope);
    Pop();	/* level 2 */
  }
  /* insert into symbol table */
  if (FindEnum(en->name, scope)!=0) {
/* BCC - if it's doing split now, skip the checking for duplicated enum 7/1/95*/
    if (split == 0) {
      fprintf(Ferr, "=> enum %s\n", en->name);
      Punt("multiple definition of a enum");
    }
  }
  if(scope!=0) {
    if(! scope_assigned)
      en->new_name = NewName(en->name, scope);
  }
  /* if scope = 0, en->new_name = 0 */
  AddEnum(en->name, en->new_name, en, 0);		/* scope = 0 */

  if (nested_dcls == 1)
  {
    /* TLJ 2/25/96 - Set input type to tell how to process */
    P_Input_Type = P_INPUT_ENUM;
    P_Enum = en;
  }
  else
  {
    /* TLJ 2/25/96 - note that there are nested dcls */
    dcl_has_nested_dcls = TRUE;
    P_DclList = AddDcl2List(P_DclList,en,TT_ENUM);
  }
}

/*===================================================================*/
/* Read in a type definition */
/* (DEF $DeclSpec $Pos?)
   $DeclSpec = ($TcSpec+  $Dcltr*)
   $Dcltr = P		|
   F		|
   (A $ExprList?)
   
   We will assume that there can only be 4 types of DEF's:  TYPEDEF,
   STRUCT, ENUM, and UNION.  (HOWEVER, the grammar allows more than these
   possibilities -- discuss w/ Grant).  Therefore, for DEF, 
   
   $TcSpec = (TYPEDEF  $typeID?) $TcSpec 	| <--- not way grammar written
   $EnumSpec			|
   $StructSpec
   
   There is no $Dcltr for StructSpec and EnumSpec $TcSpec's.
   
   $StructSpec = 
   (STRUCT	$StructID? $FieldDecl*)	|
   (UNION $StructID? $FieldDecl*)
   $EnumSpec =
   (ENUM $EnumID? $EnumItem*)	
   $EnumItem =
   ($EnumID $Expr?)
   $FieldDecl =
   ($VarId $DeclSpec $Expr?) |
   ($DeclSpec $Expr)
   */

/*
 *  list = $DeclSpec 
 *  SiblingOf(list) = $Pos?
 *  
 * Assign Pos to global value if exists - since used to disambiguate multiple
 * struct defs, should be passed from C1 and pp2p - but isn't needed after
 * gone through ptrans once.
 
 */
static TypeDefinition(list) 
     LIST list;
{
  LIST opcode, argument, position;
  char *keyword;
  char *dummyname="Dummy";
  if(list==0)
    Punt("incorrect DEF (1)");
  position = SiblingOf(list);
  if(position!=0) {
    if(NodeType(position) != T_LIST)
      Punt("incorrect position information (16)");
    else {
      position = ChildOf(position);
      if((position==0)||(NodeType(position)!=T_ID))
	Punt("incorrect position information (17)");
      else
	if(!strcmp(StringOf(position),"POS")) {
	  Filename = StringOf(SiblingOf(position));
	  Lineno = IntegerOf(SiblingOf(SiblingOf(position)));
	  Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(position))));
	}
	else
	  Punt("incorrect position information (18)");
    }
  }
  if(NodeType(ChildOf(list))==T_LIST) {		/* $TcSpec */
    opcode = ChildOf(ChildOf(list));
    if(NodeType(opcode)==T_ID) {
      keyword = StringOf(opcode);
      argument = SiblingOf(opcode);	/* ex: argument = $StructID */
      if(! strcmp(keyword, "TYPEDEF")) {
	DefineType(list);
      } else
	if(! strcmp(keyword, "STRUCT")) {
	    /* BCC - 7/26/96 */
	    rename_struct ?
	      DefineStructWithRenaming(argument, dummyname):
	      DefineStruct(argument, dummyname);
	} else
	  if(! strcmp(keyword, "UNION")) {
	    /* BCC - 7/26/96 */
	    rename_struct ?
	      DefineUnionWithRenaming(argument, dummyname):
	      DefineUnion(argument, dummyname);
	  } else
	    if(! strcmp(keyword, "ENUM")) {
	      DefineEnum(argument, dummyname);
	    } else  
	      Punt("incorrect DEF (2)");
    }
    else
      Punt("incorrect DEF (3)");
  }
  /* BCC - handling weird case like "extern struct s1" - 1/20/97 */
  else if (NodeType(ChildOf(list))==T_ID) {
    opcode = ChildOf(SiblingOf(ChildOf(list)));
    if(NodeType(opcode)==T_ID) {
      keyword = StringOf(opcode);
      argument = SiblingOf(opcode);	/* ex: argument = $StructID */
      if(! strcmp(keyword, "TYPEDEF")) {
	DefineType(list);
      } else
	if(! strcmp(keyword, "STRUCT")) {
	    /* BCC - 7/26/96 */
	    rename_struct ?
	      DefineStructWithRenaming(argument, dummyname):
	      DefineStruct(argument, dummyname);
	} else
	  if(! strcmp(keyword, "UNION")) {
	    /* BCC - 7/26/96 */
	    rename_struct ?
	      DefineUnionWithRenaming(argument, dummyname):
	      DefineUnion(argument, dummyname);
	  } else
	    if(! strcmp(keyword, "ENUM")) {
	      DefineEnum(argument, dummyname);
	    } else  
	      Punt("incorrect DEF (2)");
    }
    else
      Punt("incorrect DEF (3)");
  }
  else  Punt("incorrect DEF (4)");
}

/*===================================================================*/
/* Read the initialization form. */
/*
 * list $InitExpr
 *  InitExpr = ($InitExpr*) | $Expr
 */	  
static Init Initializer(list)
     LIST list;
{
  LIST ptr;
  Init last = 0;	/* BCC - short cut the the last one - 2/23/96 */
  Init new, next, pn;
  if ((list==0)||(ChildOf(list)==0)) return 0;  /* no initializer */
  new = NewInit();
  if (NodeType(list)!=T_LIST)
    Punt("incorrect initializer (1)");
  ptr = ChildOf(list);
  /* if node type != T_ID then it is an aggregate initializer */
  if (NodeType(ptr)==T_LIST) {
    /* aggregate initializer */
    for (; ptr!=0; ptr=SiblingOf(ptr)) {
      next = Initializer(ptr);
      /** add to the set **/
      pn = new->set;
      /* BCC - changed the following code to use the short cut - 2/23/96 */
      if (pn==0) {
	new->set = next;
	last = next;
      } else {
	if (last) {
	    last->next = next;
	    last = next;
	}
	else {
	    while (pn->next!=0) pn = pn->next;
	    pn->next = next;
	}
      }
    }
  } else  {
    if(NodeType(ptr)!=T_ID)
      Punt("incorrect initializer (1.1)"); 
    else {
      Expr exp = Expression(list);	/* 9-12 */
      new->expr = ReduceExpr(exp);
      RemoveExpr(exp);
    }
  }
  return new;
}

/*===================================================================
 * BCC - added 2/2/96
 * Process local aggregate initializers
 */

static Stmt InitLocalAggr(expr, init, type)
     Expr expr;
     Init init;
     Type type;
{
  Init in;
  Expr op1, op2, exp;
  Stmt new, existing, last;
  Type ty;
  Dcltr dcltr;

  existing = 0;
  /*
   * (1) Initialize a structure
   */
  if (IsStructureType(type)) {
    StructDcl st;
    Field field, f;

    st = FindNearScopeSt(possible_scopes, type->struct_name);
    if (st == 0) {
      fprintf(Ferr, "> struct %s\n", type->struct_name);
      Punt("cannot initialize a struct before its body is defined");
    }
    field = st->fields;
    while (field) {
      in = init;
      if (in) {
        /*
         * leaf
         */
        if (in->set == 0) {
          /*
           * not a char array
           */
          if (IsCharArrayType(field->type) == 0) {
            /*
             * Generate a.b where a is a structure and comes from expr and b is
             * one of a's fields
             */
            ty = CopyType(field->type);
            op1 = CopyExpr(expr);
            op2 = NewVarExpr(field->name, ty);
            exp = NewInstExpr(OP_dot, 0);
            exp->value.string = FindString(field->name);
            AddOperand(exp, op1);
            AddOperand(exp, op2);
            CastExpr(exp);
            op1 = exp;
            /*
             * Generate a.b = c, where a.b is generated above
             */
            op2 = CopyExpr(in->expr);
            exp = NewInstExpr(OP_assign, 0);
            AddOperand(exp, op1);
            AddOperand(exp, op2);
            CastExpr(exp);
            op1 = exp;

            new = NewStmt();
            new->type = ST_EXPR;
	    /* BCC - reduce first - 8/22/96 */
            new->stmtstruct.expr = ReduceExpr(exp);
	    RemoveExpr(exp);
            new->lineno = 0;
            new->colno = 0;
            if (existing == NIL) existing = new;
            else {
              last = existing;
              while (last->lex_next) last = last->lex_next;
              last->lex_next = new;
              new->lex_prev = last;
            }
          }
          /*
           * a char array
           */
          else {
            int i, s, length;
            char str[2048], ch[5];

            if (in->expr->opcode != OP_string)
              Punt("Illegal initializer for a char array");
            s = IntegralExprValue(field->type->dcltr->index);
            RemoveDQ(in->expr->value.string, str, 2048);
            length = strlen(str)+1;
            if (length > s)
              Punt("String initializer is longer than the allocated space");
            for (i = 0; i < s; i++) {
              /*
               * Generate a.b where a is a structure and comes from expr and b
               * is one of a's fields
               */
              op1 = CopyExpr(expr);
              op2 = NewVarExpr(field->name, CopyType(field->type));
              exp = NewInstExpr(OP_dot, 0);
              exp->value.string = FindString(field->name);
              AddOperand(exp, op1);
              AddOperand(exp, op2);
              CastExpr(exp);
              op1 = exp;
              /*
               * Generate a.b[i]
               */
              op2 = NewIntExpr(i);
              exp = NewInstExpr(OP_index, 0);
              AddOperand(exp, op1);
              AddOperand(exp, op2);
              CastExpr(exp);
              op1 = exp;
              if (i < length-1) {
                ch[0] = ch[2] = '\'';
                ch[1] = str[i];
                ch[3] = 0;
              }
              else {
                ch[0] = ch[3] = '\'';
                ch[1] = '\\';
                ch[2] = '0';
                ch[4] = 0;
              }
              /*
               * Generate a.b[i] = 'c'
               */
              op2 = NewCharExpr(FindString(ch));
              exp = NewInstExpr(OP_assign, 0);
              AddOperand(exp, op1);
              AddOperand(exp, op2);
              CastExpr(exp);

              new = NewStmt();
              new->type = ST_EXPR;
	      /* BCC - reduce first - 8/22/96 */
              new->stmtstruct.expr = ReduceExpr(exp);
	      RemoveExpr(exp);
              new->lineno = 0;
              new->colno = 0;
              if (existing == NIL) existing = new;
              else {
                last = existing;
                while (last->lex_next) last = last->lex_next;
                last->lex_next = new;
                new->lex_prev = last;
              }
            }
          }
        }
        /*
         * init is a node, not a leaf
         */
        else {
          if (IsStructureType(field->type)==0 && IsArrayType(field->type) == 0)
            Punt("Illegal local initializer type (1)");
          else {
            /*
             * Generate a.b where a is a structure and comes from expr and b is
             * one of a's fields
             */
            ty = CopyType(field->type);
            op1 = CopyExpr(expr);
            op2 = NewVarExpr(field->name, ty);
            exp = NewInstExpr(OP_dot, 0);
            exp->value.string = FindString(field->name);
            AddOperand(exp, op1);
            AddOperand(exp, op2);
            CastExpr(exp);
            op1 = exp;
            /*
             * recursively process the nested structure
             */
            new = InitLocalAggr(op1, in->set, ty);
            if (existing == NIL) existing = new;
            else {
              last = existing;
              while (last->lex_next) last = last->lex_next;
              last->lex_next = new;
              new->lex_prev = last;
            }
          }
        }
      }
      /* Early end */
      else {
      }
      init = init->next;
      field = field->next;
    }
    return existing;
  }

  /*
   * (2) Initialize a char array
   */
  if (IsCharArrayType(type)) {
    int i, s, length;
    char str[2048], ch[5];

    in = init;
    /*
     * char a[10] = "test";
     * or char a[10] = {"test"};
     */
    if (in->expr->opcode == OP_string) {
      s = IntegralExprValue(type->dcltr->index);
      RemoveDQ(in->expr->value.string, str, 2048);
      length = strlen(str)+1;
      if (length > s)
        Punt("String initializer is longer than the allocated space");
      for (i = 0; i < s; i++) {
        /*
         * Generate a[i]
         */
        op1 = CopyExpr(expr);
        op2 = NewIntExpr(i);
        exp = NewInstExpr(OP_index, 0);
        AddOperand(exp, op1);
        AddOperand(exp, op2);
        CastExpr(exp);
        op1 = exp;
        if (i < length-1) {
          ch[0] = ch[2] = '\'';
          ch[1] = str[i];
          ch[3] = 0;
        }
        else {
          ch[0] = ch[3] = '\'';
          ch[1] = '\\';
          ch[2] = '0';
          ch[4] = 0;
        }
        /*
         * Generate a[i] = 'c'
         */
        op2 = NewCharExpr(FindString(ch));
        exp = NewInstExpr(OP_assign, 0);
        AddOperand(exp, op1);
        AddOperand(exp, op2);
        CastExpr(exp);

        new = NewStmt();
        new->type = ST_EXPR;
	/* BCC - reduce first - 8/22/96 */
        new->stmtstruct.expr = ReduceExpr(exp);
	RemoveExpr(exp);
        new->lineno = 0;
        new->colno = 0;
        if (existing == NIL) existing = new;
        else {
          last = existing;
          while (last->lex_next) last = last->lex_next;
          last->lex_next = new;
          new->lex_prev = last;
        }
      }
    }
    /*
     * char a[10] = { 't', 'e', 's', 't', '\0' };
     * where init->expr->opcode == OP_char
     */
    else {
      s = IntegralExprValue(type->dcltr->index);
      for (i = 0; i < s; i++) {
        /*
         * Generate a[i]
         */
        op1 = CopyExpr(expr);
        op2 = NewIntExpr(i);
        exp = NewInstExpr(OP_index, 0);
        AddOperand(exp, op1);
        AddOperand(exp, op2);
        CastExpr(exp);
        op1 = exp;
        if (in != 0) {
          op2 = CopyExpr(in->expr);
          in = in->next;
        }
        else {
          ch[0] = ch[3] = '\'';
          ch[1] = '\\';
          ch[2] = '0';
          ch[4] = 0;
          op2 = NewCharExpr(FindString(ch));
        }
        /*
         * Generate a[i] = 'c'
         */
        exp = NewInstExpr(OP_assign, 0);
        AddOperand(exp, op1);
        AddOperand(exp, op2);
        CastExpr(exp);

        new = NewStmt();
        new->type = ST_EXPR;
	/* BCC - reduce first - 8/22/96 */
        new->stmtstruct.expr = ReduceExpr(exp);
	RemoveExpr(exp);
        new->lineno = 0;
        new->colno = 0;
        if (existing == NIL) existing = new;
        else {
          last = existing;
          while (last->lex_next) last = last->lex_next;
          last->lex_next = new;
          new->lex_prev = last;
        }
      }
    }
    return existing;
  }

  /*
   * (3) Initialize a regular array
   */
  if (IsArrayType(type)) {
    int index, size;

    in = init;
    dcltr = type->dcltr;
    size = IntegralExprValue(dcltr->index);
    for (index = 0; index < size; index++) {
      /*
       * no initializers
       */
      if (in == 0) break;
      /*
       * init is a leaf, assignment expressions are enough
       */
      if (in->set == 0) {
        /*
         * Generate expr[i]
         */
        op1 = CopyExpr(expr);
        op2 = NewIntExpr(index);
        exp = NewInstExpr(OP_index, 0);
        AddOperand(exp, op1);
        AddOperand(exp, op2);
        CastExpr(exp);
        op1 = exp;
        /*
         * Generate expr[i] = init->expr
         * or expr[i] = 0
         */
        if (in)
          op2 = CopyExpr(in->expr);
        else
          op2 = NewIntExpr(0);
        exp = NewInstExpr(OP_assign, 0);
        AddOperand(exp, op1);
        AddOperand(exp, op2);
        CastExpr(exp);
        op1 = exp;

        new = NewStmt();
        new->type = ST_EXPR;
	/* BCC - reduce first - 8/22/96 */
        new->stmtstruct.expr = ReduceExpr(exp);
	RemoveExpr(exp);
        new->lineno = 0;
        new->colno = 0;
        if (existing == NIL) existing = new;
        else {
          last = existing;
          while (last->lex_next) last = last->lex_next;
          last->lex_next = new;
          new->lex_prev = last;
        }
      }
      /*
       * init is a node, recursively initialize data
       */
      else {
        ty = CopyType(type);
        ty->dcltr = ty->dcltr->next;
        /*
         * Generate expr[i]
         */
        op1 = CopyExpr(expr);
        op2 = NewIntExpr(index);
        exp = NewInstExpr(OP_index, 0);
        AddOperand(exp, op1);
        AddOperand(exp, op2);
        CastExpr(exp);
        op1 = exp;
        new = InitLocalAggr(op1, in->set, ty);
        RemoveType(ty);
        RemoveExpr(op1);
        if (existing == NIL) existing = new;
        else {
          last = existing;
          while (last->lex_next) last = last->lex_next;
          last->lex_next = new;
          new->lex_prev = last;
        }
      }
      in = in->next;
    }
    return existing;
  }
}

/*===================================================================*/
/* Convert the Initializer to statements
 *
 * list $InitExpr
 *
 * There are no aggregate initialization for local var.
 */
static Stmt Init2Stmt(list, var)
     LIST list;
     VarDcl var;
{
  LIST ptr;
  Expr exp;
  Type ty;
  Expr op1, op2, new_op2;
  Stmt new, next, temp;
  if((list==0)||(ChildOf(list)==0)) return 0;	/* no initializer */
  new = NewStmt();
  if(NodeType(list)!=T_LIST)
    Punt("incorrect initializer (2)");
  ptr = ChildOf(list);
  /* if opcode != EXPR then it is an aggregate initializer */
  /* BCC - supporting aggregate initializers for local variables now - 2/2/96 */
  if(NodeType(ptr)==T_LIST) {
#if 0
    Punt("no aggregate initializers for local variables");
#endif
    var->init = Initializer(list);
    if (var->init) {
      ProcessInit(var, possible_scopes);
      /*
       * (1) Initialize a structure
       */
      if (IsStructureType(var->type)) {
        ty = CopyType(var->type);
        if (var->new_name != 0)
          op1 = NewVarExpr(var->new_name, ty);
        else
          op1 = NewVarExpr(var->name, ty);
        new = InitLocalAggr(op1, var->init->set, ty);
        RemoveExpr(op1);
        return new;
      }
      /*
       * (2) Initialize a char array
       */
      if (IsCharArrayType(var->type)) {
        ty = CopyType(var->type);
        if (var->new_name != 0)
          op1 = NewVarExpr(var->new_name, ty);
        else
          op1 = NewVarExpr(var->name, ty);

        if (var->init->set)
          new = InitLocalAggr(op1, var->init->set, ty);
        else
          new = InitLocalAggr(op1, var->init, ty);
        RemoveExpr(op1);
        return new;
      }
      /*
       * (3) Initialize a regular array
       */
      if (IsArrayType(var->type)) {
        ty = CopyType(var->type);
        if(var->new_name != 0)
          op1 = NewVarExpr(var->new_name, ty);
        else
          op1 = NewVarExpr(var->name, ty);
        new = InitLocalAggr(op1, var->init->set, ty);
        RemoveExpr(op1);
        return new;
      }
      /*
       * Sorry, don't know how to initialize
       */
      else
        Punt("Illegal local aggregate type");
    }
    else
      return 0;
  }
  /* BCC - end of change 2/2/96 */

  if(NodeType(ptr) != T_ID)
    Punt("incorrect initializer (3)");
  new->type = ST_EXPR;
/* BCC - don't assign type now, cast it later - 8/22/96 */
#if 0
  ty = CopyType(var->type);    /* copy type for assign expr */	 
  exp = NewInstExpr(OP_assign, ty);
#endif
  exp = NewInstExpr(OP_assign, 0);
  ty = CopyType(var->type);   /* copy type for var in expr */
  if(var->new_name != 0) 
    op1 = NewVarExpr(var->new_name, ty);
  else 
    op1 = NewVarExpr(var->name, ty);
  op2 = Expression(list);
  new_op2 = ReduceExpr(op2);
  RemoveExpr(op2);
  AddOperand(exp, op1);
  AddOperand(exp, new_op2);
  /* BCC - 8/22/96 */
  CastExpr(exp);
  new->stmtstruct.expr = ReduceExpr(exp);
  RemoveExpr(exp);
  
/*
  new->lineno = 0;
  new->colno = 0;
  new->filename = (char *)malloc(6);
  sprintf(new->filename, "dummy");
*/

  /* LCW -- Assign the correct file name and line/column numbers to the
   * corresponding fields of new statement structure for variable 
   * initialization. - 7/24/95
   */
  new->lineno = Lineno;
  new->colno = Colno;
  /* LCW - assign file name only when it's not null - 8/22/97 */
  if (Filename != 0) {
      new->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(new->filename, "%s", Filename);
  }

  return new;
}

/*===================================================================*/
/* 
 * Read in a global variable pragma
 * list = $Pragma* = (PRAGMA $String $ExprList $Pos?)*
 *	  --------
 */

static Pragma ReadGvarPragmas(list)
     LIST list;
{
  LIST opcode, position, p;
  Expr expr = 0;
  Expr ex_ptr, temp_expr;
  char *keyword;
  Pragma new, head_ptr, tail_ptr;
  head_ptr=tail_ptr=0;
  for(; list!=0; list = SiblingOf(list)) {
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("incorrect global variable pragma specifier (1)");
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect global variable pragma specifier (2)");
    keyword = StringOf(opcode);
    if(strcmp(keyword, "PRAGMA"))
      Punt("incorrect global variable pragma specifier (3)");
    opcode = SiblingOf(opcode);
    /* Specifier string */
    if((opcode==0)||(NodeType(opcode)!=T_STRING))
      Punt("incorrect global variable pragma specifier (4)");
    keyword = StringOf(opcode);
    /* GEH - removed since specifier does not contain pragma type (5/16/93)
    if((keyword[1]!='G')||(keyword[2]!='V'))
      Punt("incorrect global variable pragma specifier (5)");
    */
    p = SiblingOf(opcode);
    if(p!=0) {
      if(strcmp(StringOf(ChildOf(p)), "POS")) {
	temp_expr = Expression(p);
	expr = ReduceExpr(temp_expr);
	RemoveExpr(temp_expr);
	p = SiblingOf(p);
	/* Expr */
	for(; p != 0; p = SiblingOf(p)) {
	  if(NodeType(p)!=T_LIST)
	    Punt("incorrect global variable pragma specifier (6)");
	  if(!strcmp(StringOf(ChildOf(p)), "POS"))
	    break;
	  if(expr->next == 0) {
	    temp_expr = Expression(p);
	    expr->next = ReduceExpr(temp_expr);
	    RemoveExpr(temp_expr);
	  }
	  else {
	    ex_ptr = expr->next;
	    while(ex_ptr->next != 0) ex_ptr = ex_ptr->next;
	    temp_expr = Expression(p);
	    ex_ptr->next = ReduceExpr(temp_expr);
	    RemoveExpr(temp_expr);
	  }
	}
      }
    }
    new = NewPragma(keyword, expr);
    /* BCC - garbage collection - 8/25/96 */
    RemoveExpr(expr);
    /* position */
    position = p;
    if(position!=0) {
      if(NodeType(position) != T_LIST)
	Punt("incorrect position information (19)");
      else {
	position = ChildOf(position);
	if((position==0)||(NodeType(position)!=T_ID))
	  Punt("incorrect position information (20)");
	else
	  if(!strcmp(StringOf(position),"POS")) {
	    Filename = StringOf(SiblingOf(position));
	    Lineno = IntegerOf(SiblingOf(SiblingOf(position)));
	    Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(position))));
	  }
	  else
	    Punt("incorrect position information (21)");
      }
    }
    if(Filename != 0) {
      new->lineno = Lineno;
      new->colno = Colno;
      new->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(new->filename, "%s", Filename);
    }
    /* Attach to global variable */
    if(head_ptr==0) {
      head_ptr = new;
      tail_ptr = new;
    } else {
      tail_ptr->next = new;
      tail_ptr = new;
    }
  }
  return(head_ptr);
}

/*===================================================================*/
/* Read in a global variable definition. */
/* The (ptr) fields of the global variable symbol table
 * points to the symbol definitions (VarDcl).
 * 
 * Called by:
 *	ProcessList - if extern, static, or default global
 *	ReadLocalVar - if extern or static
 *	
 * list = $VarID $DeclSpec $InitExpr ($Pragma*) $Pos? |
 *	  $VarID $DeclSpec () ($Pragma*) $Pos?
 * scope = 0 (even if a static or extern def from a different scoping - place
 * at level 0 in table.
 */

static DefineGvar(list)
     LIST list;
{
  VarDcl var, v;
  LIST position;  /* LCW -- 7/17/95 */

  /* TLJ 2/27/96 - Increment nested defines counter */
  nested_dcls++;

  var = NewVarDcl();
  if ((list==0)||(NodeType(list)!=T_ID))
    Punt("incorrect global variable declaration (1)");
  var->name = StringOf(list);	/* var name */

  /* BCC - set edg_generated flag - 8/2/96 */
  if (edg_generated == 0 && !strcmp(var->name, "IMPACT_EDG_GENERATED"))
    edg_generated = 1;
  /* BCC - 7/29/96  
   * the rename scheme for Psplit only works for EDG-generated Pcode 
   */
  /* BCC - 8/2/96
   * only rename when doing real spliting, or generating layout 
   * info (-ITI/JCG 2/99), not extracting function types
   */
  if (edg_generated && split && 
      ((strcmp(sp_output_format_string, "Pcode") == 0) ||
       sp_create_layout_info_generator))
  {
    rename_struct = 1;
    if (!struct_T_name_table)
      struct_T_name_table = C_open_name_table(MAX_T_STRUCTS);
  }
  /* BCC - 11/12/96
   * If Chsemansi is used, we still need to call ReduceExpr() to get constants
   * for array declarations
   */
  if (edg_generated == 0 && do_annotate_function == 0 && inlining == 0)
    fast_mode = 0;
  list = SiblingOf(list);
  if ((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect global variable declaration (2)");

  /* LCW -- Grap position informatin here so that DefineStruct will get the
   * correct Line number. 7/17/95
   */
  position = SiblingOf(SiblingOf(SiblingOf(list)));
  if(position != 0) {
    if(NodeType(position) != T_LIST)
      Punt("incorrect position information (16)");
    else {
      position = ChildOf(position);
      if((position==0)||(NodeType(position)!=T_ID))
        Punt("incorrect position information (17)");
      else
        if(!strcmp(StringOf(position),"POS")) {
          Filename = StringOf(SiblingOf(position));
          Lineno = IntegerOf(SiblingOf(SiblingOf(position)));
          Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(position))));
        }
        else
          Punt("incorrect position information (18)");
    }
  }

  var->type = DeclSpec(list);	/* var type */
  /* make sure it is not defined several times (scope = 0)*/
  if ((v=FindVar(var->name,0))!=0) {
    int type1, type2, class1, class2, class;
    /* It is possible to have multiple definitions of
     * the same variable. For example, several can be extern
     * definitions, and one be a global definition.
     * global + extern -> global
     * extern + extern -> extern
     * extern + static -> static
     * global + static -> static 
     */
    if(FindEnumField(var->name,0)!=0) 	/* scope=0 */
      Warning("multiple definitions of a global variable (2.1)");
    type1 = v->type->type;
    type2 = var->type->type;
#define U_CLASS (TY_STATIC|TY_EXTERN)
    class1 = type1 & U_CLASS;		/* class = 0 => global */
    class2 = type2 & U_CLASS;
    type1 &= ~U_CLASS;
    type2 &= ~U_CLASS;
    if (type1!=type2) {         /* BCC - print out the var name - 7/1/95 */
      Warning("multiple definitions of a global variable (1)");
      Warning(var->name);
    }
    if (((class1 & TY_STATIC) && (class2 == 0)) ||
	((class1 == 0) && (class2 & TY_STATIC))) {
      Warning("multiple definitions of a global variable (2)");
    } else if ((class1 == 0) || (class2 == 0)) {
      class = 0;
    } else if ((class1 & TY_STATIC) || (class2 & TY_STATIC)) {
      class = TY_STATIC;
    } else if ((class1 & TY_EXTERN) || (class2 & TY_EXTERN)) {
      class = TY_EXTERN;
    } else 
      Warning("multiple definitions of a global variable (3)");
    /*
     * we modify the OLD version of the variable declaration.
     * the new copy must not be altered because it will appear
     * in the output.
     */
    /* BCC - 11/3/96
     * In 126.gcc, sparc_frw_output_function_prologue() is defined as a void
     * function in aux-output.c, but declared as a int function in final.c.
     * The correct type of void has been found by one pass through all the
     * files via Psplit with functype.pch generated. So whenever we see a 
     * function/var with type void, it means that it must be defined as void
     * explicitly somewhere so it won't be overwritten.
     */
    if (v->type->type) {
/*
	if (v->type->type & TY_VOID && IsFunctionType(v->type))
*/
        /* BCC - always replace int functions - 5/21/98 */
        if (IsFunctionType(v->type) &&
            !((v->type->type & TY_INT) && (v->type->dcltr->next == 0))) {
            RemoveType(var->type);
            var->type = CopyType(v->type);
        }
	else
	    v->type->type = (type1 | class);
    };
  } else {
    /* add it to the symbol table */
    AddVar(var->name, 0, var, 0);	/* scope = 0 */
  }
  /*
   * must handle the initializer after the variable entry has
   * been defined in the symbol table, because there are cases
   * where the variable itself is used in its own initializer (cccp)
   */
  list = SiblingOf(list);
  var->init = Initializer(list);	/* var initializer */
  /*
   * convert the initializer list to our more strict format.
   * also make necessary type conversion to the initializer.
   */
/******************************************************************************\
 * BCC - update the newest declarator for just initialized data - 5/29/95     *
 *       For example, extern int i[]; will be inserted into symbol table with *
 *       the index field in dcltr empty. Then, another declaration with a     *
 *       a initialization appears in the code which will fill the index field,*
 *       but not the one in the symbol table. So we have to update the symbol *
 *       table here.                                                          *
\******************************************************************************/
  if (var->init!=0) {
    ProcessInit(var, possible_scopes);
#if 0
    /* BCC - moved later - 8/25/96 */
    /* BCC - var is created by NewVarDcl, the old one could be freed 11/20/95 */
    if (v != 0) ReplaceVar(var->name, var, 0);
#endif
  }
  
  /* process any pragmas associated with the global variable */
  list = SiblingOf(list);
  if(ChildOf(list)!=0)
    var->pragma = ReadGvarPragmas(ChildOf(list));
  
  /* process position if exists */
  list = SiblingOf(list);
  if(list!=0) {
    if(NodeType(list) != T_LIST)
      Punt("incorrect position information (4)");
    else {
      list = ChildOf(list);
      if((list==0)||(NodeType(list)!=T_ID))
	Punt("incorrect position information (5)");
      else
	if(!strcmp(StringOf(list), "POS")) {
	  Filename = StringOf(SiblingOf(list));
	  var->filename = (char *)malloc(strlen(Filename)+1);
	  sprintf(var->filename, "%s", Filename);
	  var->lineno = Lineno = IntegerOf(SiblingOf(SiblingOf(list)));
	  var->colno = Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(list))));
	}
	else
	  Punt("incorrect position information (6)");
    }
  }
  
  /* BCC - the new one always replace the old one - 8/25/96 */
  /* BCC - if v is a function, the old type must come form functype.pch, which
   *       we don't want to be overwritten.
   */
  if (v && !IsFunctionType(v->type)) 
      ReplaceVar(var->name, var, 0);

  if (nested_dcls == 1)
  {
    /* TLJ 2/25/96 - Set input type to tell how to process */
    P_Input_Type = P_INPUT_GVAR;
    P_Gvar = var;
  }
  else
  {
    /* TLJ 2/25/96 - note that there are nested dcls */
    dcl_has_nested_dcls = TRUE;
    P_DclList = AddDcl2List(P_DclList,var,TT_VAR);
  }
}
/*===================================================================*/
/* Read local variable pragma */
/*
 * list = $Pragma* = (PRAGMA $String $ExprList $Pos?)*
 */
static Pragma ReadLvarPragmas(list)
     LIST list;
{
  LIST opcode, position, p;
  Expr expr = 0;
  Expr ex_ptr, temp_expr;
  char *keyword;
  Pragma new, head_ptr, tail_ptr;
  head_ptr=tail_ptr=0;
  for(; list!=0; list = SiblingOf(list)) {
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("incorrect local variable pragma specifier (1)");
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect local variable pragma specifier (2)");
    keyword = StringOf(opcode);
    if(strcmp(keyword, "PRAGMA"))
      Punt("incorrect local variable pragma specifier (3)");
    opcode = SiblingOf(opcode);
    /* Specifier string */
    if((opcode==0)||(NodeType(opcode)!=T_STRING))
      Punt("incorrect local variable pragma specifier (4)");
    keyword = StringOf(opcode); 
    /* GEH - removed since specifier does not contain pragma type (5/16/93)
    if((keyword[1]!='L')||(keyword[2]!='V'))
      Punt("incorrect local variable pragma specifier (5)");
    */
    p = SiblingOf(opcode);
    if(p!=0) {
      if(strcmp(StringOf(ChildOf(p)), "POS")) {
	temp_expr = Expression(p);
	expr = ReduceExpr(temp_expr);
	RemoveExpr(temp_expr);
	p = SiblingOf(p);
	/* Expr */
	for(; p != 0; p = SiblingOf(p)) {
	  if(NodeType(p)!=T_LIST)
	    Punt("incorrect local variable pragma specifier (6)");
	  if(!strcmp(StringOf(ChildOf(p)), "POS"))
	    break;
	  if(expr->next == 0) {
	    temp_expr = Expression(p);
	    expr->next = ReduceExpr(temp_expr);
	    RemoveExpr(temp_expr);
	  }
	  else {
	    ex_ptr = expr->next;
	    while(ex_ptr->next != 0) ex_ptr = ex_ptr->next;
	    temp_expr = Expression(p);
	    ex_ptr->next = ReduceExpr(temp_expr);
	    RemoveExpr(temp_expr);
	  }
	}
      }
    }
    new = NewPragma(keyword, expr);
    /* BCC - garbage collection - 8/25/96 */
    RemoveExpr(expr);
    /* position */
    position = p;
    if(position!=0) {
      if(NodeType(position) != T_LIST)
	Punt("incorrect position information (22)");
      else {
	position = ChildOf(position);
	if((position==0)||(NodeType(position)!=T_ID))
	  Punt("incorrect position information (23)");
	else
	  if(!strcmp(StringOf(position),"POS")) {
	    Filename = StringOf(SiblingOf(position));
	    Lineno = IntegerOf(SiblingOf(SiblingOf(position)));
	    Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(position))));
	  }
	  else
	    Punt("incorrect position information (24)");
      }
    }
    if(Filename != 0) {
      new->lineno = Lineno;
      new->colno = Colno;
      new->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(new->filename, "%s", Filename);
    }
    /* Attach to global variable */
    if(head_ptr==0) {
      head_ptr = new;
      tail_ptr = new;
    } else {
      tail_ptr->next = new;
      tail_ptr = new;
    }
  }
  return(head_ptr);
}
/*===================================================================*/
/* Read in a local variable definition. */
/*
 * list = $LocalDecl* 
 *        ---------- 
 * $LocalDecl = $TypeDef | $LocalDataDecl
 *
 * $TypeDef = (DEF $DeclSpec $Pos?)
 * $LocalDataDecl = (LVAR $VarID $DeclSpec $InitExpr ($Pragma*) $Pos?) |
 *		    (LVAR $VarID $DeclSpec () ($Pragma*) $Pos?)
 *
 * lv_list = currentFuncDcl->local if associated with a function
 *	   = compoundstmt->var_list if associated with a compound 
 *           statement (!= function body)
 *
 * if read in a static or extern:
 *	extern - can't initialize an extern - put in table at 
 *		 global scoping (0) - leave extern declaration where it is.
 *	static - can initialize a static.  don't want to move the initialization
 *		 into stmts because this is actually a global var and init
 *		 is for free.  move static declaration out after renaming.
 *	
 * Rename local variables b.c. need to for hcode.
 * return initializer stmts. 
 */
static Stmt ReadLocalVar(list, lv_list)
     LIST list;
     VarList *lv_list;
{
  
  LIST opcode, position;
  char *keyword;
  VarDcl var, v;
  Stmt init_stmts = 0;  /* for initialization stmts */
  Stmt stmt;
  for(; list!=0; list=SiblingOf(list)) {
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("incorrect local variable declaration (1)");
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect local variable declaration (2)");
    keyword = StringOf(opcode);
    if((strcmp(keyword, "LVAR"))&&(strcmp(keyword,"DEF")))
      Punt("incorrect local variable declaration (3)");
    if(!strcmp(keyword, "LVAR")) {
      var = NewVarDcl();
      opcode = SiblingOf(opcode);
      if((opcode==0)||(NodeType(opcode)!=T_ID))
	Punt("incorrect local variable declaration (4)");
      var->name = StringOf(opcode);

      /* LCW -- moved from below to here so that DeclSpec can get the correct
       * position information.  7/17/95
       */
      /* process position if exists */
      position = SiblingOf(SiblingOf(SiblingOf(SiblingOf(opcode))));
      if(position!=0) {
        if(NodeType(position) != T_LIST)
          Punt("incorrect position information (13)");
        else {
          position = ChildOf(position);
          if((position==0)||(NodeType(position)!=T_ID))
            Punt("incorrect position information (14)");
          else
            if(!strcmp(StringOf(position), "POS")) {
              Filename = StringOf(SiblingOf(position));
              Lineno = IntegerOf(SiblingOf(SiblingOf(position)));
              Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(position))));
            }
            else
              Punt("incorrect position information (15)");
        }
      }

      if(Filename != 0) {
        var->lineno = Lineno;
        var->colno = Colno;
        var->filename = (char *)malloc(strlen(Filename)+1);
        sprintf(var->filename, "%s", Filename);
      }


      opcode = SiblingOf(opcode);
      if((opcode==0)||(NodeType(opcode)!=T_LIST))
	Punt("incorrect local variable declaration (5)");
      var->type = DeclSpec(opcode);
      
      /* GEH - moved from below so position info exists for renaming */
      /* process any pragmas associated with the local variable */
      position = SiblingOf(SiblingOf(opcode));
      if(ChildOf(position)!=0)
	var->pragma = ReadLvarPragmas(ChildOf(position));

/* LCW -- The following code has been moved up */
      /* process position if exists */
/*    position = SiblingOf(position);
      if(position!=0) {
	if(NodeType(position) != T_LIST)
	  Punt("incorrect position information (13)");
	else {
	  position = ChildOf(position);
	  if((position==0)||(NodeType(position)!=T_ID))
	    Punt("incorrect position information (14)");
	  else
	    if(!strcmp(StringOf(position), "POS")) {
	      Filename = StringOf(SiblingOf(position));
	      Lineno = IntegerOf(SiblingOf(SiblingOf(position)));
	      Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(position))));
	    }
	    else
	      Punt("incorrect position information (15)");
	}
      }

      if(Filename != 0) {
	var->lineno = Lineno;
	var->colno = Colno;
	var->filename = (char *)malloc(strlen(Filename)+1);
	sprintf(var->filename, "%s", Filename);
      }
*/

      /* if not global then shouldn't be volatile or sync */
      if((!((var->type->type & TY_EXTERN) ||
	    (var->type->type & TY_STATIC))) &&
	 (/* (var->type->type & TY_VOLATILE) || */ /* GEH - locals can be 
							 volatile!  5-29-95 */
	  (var->type->type & TY_SYNC)))
	/* Punt("sync or volatile local declaration"); */
	Punt("local variable declaration cannot be of type sync");
      
      /* if static, rename using scopeid, move out when print */
      /* GEH - renaming happens in Chsemantic now.  5-30-95 */
      if(var->type->type & TY_STATIC) {
	if((FindVar(var->name,scope)!=0) || 
	   (FindEnumField(var->name, scope)!= 0)) 
	  Warning("multiple definitions of a local variable (1)");
	else {
	  /* GEH
	  if(! scope_assigned) 
	    var->new_name = NewName(var->name, scope);
	  AddVar(var->name, var->new_name, var, scope);
	  */
	  var->new_name = NewName2(var->name);
	  AddVar(var->name, var->new_name, var, scope);
	  opcode = SiblingOf(opcode);
	  var->init = Initializer(opcode);
	  if(var->init!=0)
	    ProcessInit(var, possible_scopes);
	  /* TLJ 2/25/96 - note that there are also global vars to process */
	  dcl_has_nested_dcls = TRUE;
	  P_DclList = AddDcl2List(P_DclList,var,TT_VAR);
  	  /* TLJ 2/27/96 - Increment nested defines counter */
  	  nested_dcls++;
	}
      } else if(var->type->type & TY_EXTERN) {
	if(FindEnumField(var->name,0)!=0)	
	  Warning("multiple definitions of a global variable (4)");
	/* if in table, leave w/o changing type.  if not add */
	if(FindVar(var->name, 0)==0) {
	  AddVar(var->name, 0, var, 0);
	}

        /* DIA - Took this out in order to allow: int x() = 5; */
	/* 4/92 - do regardless of whether in table or not */
	/* opcode = SiblingOf(opcode);
	** if(ChildOf(opcode)!=0)
	**   Punt("cannot initialize an external variable (1)");
	*/
        /* DIA - Added the following */
	  /*
	   * move the initializer to an expr stmt after.
	   */
	  opcode = SiblingOf(opcode);
	  stmt = Init2Stmt(opcode, var);  /* initializer to stmt*/
	  /* 
	   * BCC - bug fix for aggregate local vars - 3/31/96 
	   * Since the initializers have been transformed into statements, they
	   * don't have to be attached to the var or redundent statements will 
	   * be generated when it goes through Pcode more than once
	   */
	  if (var->init) {
	    RemoveInit(var->init);
	    var->init = 0;
	  }
	  /* BCC - end of change */

	  if (stmt!=0) {       
	    /* add statment to init_stmts */
	    if(init_stmts==0)
	      init_stmts = stmt;
	    else {
	      Stmt temp;
	      temp = init_stmts;
	      while(temp->lex_next!=0) temp = temp->lex_next;
	      temp->lex_next = stmt;
	      stmt->lex_prev = temp;
	    }
	  }
        /* DIA - Bottom of added code */

      } else 

	/* NJW - 3/93 - if static_array - then make local arrays static */
        /* BCC - if it's doing spliting, don't make local arrays global */
        if(split == 0 && static_array && IsArrayType(var->type) &&
	   !(var->type->type & TY_STATIC)) {
	  var->type->type = (var->type->type | TY_STATIC);
	  if((FindVar(var->name,scope)!=0) || 
	     (FindEnumField(var->name, scope)!= 0)) 
	    Warning("multiple definitions of a local variable (1.1)");
	  else {
	    /* GEH, BCC - changed to file position renaming for file splitting*/
	    /*
	    if(! scope_assigned) 
	      var->new_name = NewName(var->name, scope);
	    */
	    var->new_name = NewName3(var);
	    AddVar(var->name, var->new_name, var, scope);
	    opcode = SiblingOf(opcode);
	    var->init = Initializer(opcode);
	    if(var->init!=0)
	      ProcessInit(var, possible_scopes);
	    /* TLJ 2/25/96 - note that there are also global vars to process */
	    dcl_has_nested_dcls = TRUE;
	    P_DclList = AddDcl2List(P_DclList,var,TT_VAR);
  	    /* TLJ 2/27/96 - Increment nested defines counter */
  	    nested_dcls++;
	  }
	} else {
	  /* make sure it is not defined several times at scope 
	   * check to see if enumfield has same name - in hcode this
	   * isn't allowed (regardless of scoping).  in c it isn't
	   * allowed at the same scoping level.
	   */
	  if((FindVar(var->name,scope)!= 0) ||
	     (FindEnumField(var->name, scope)!= 0)) 
	    Warning("multiple definitions of a local variable (2)");
	  else {
	    /* Rename and Add it to the symbol table */
/* BCC - if it's doing inlining, then use NewNameIL to update the scope number
	 otherwise use the old rename function (NewName)           - 11/10/95 */
	    if(! scope_assigned) {
	      if (!inlining)
	        var->new_name = NewName(var->name, scope);
	      else
	        var->new_name = NewNameIL(var->name, scope);
	    }
	    AddVar(var->name, var->new_name, var, scope);
	  }

	  /*
	   * move the initializer to an expr stmt after.
	   */
	  opcode = SiblingOf(opcode);
	  stmt = Init2Stmt(opcode, var);  /* initializer to stmt*/
	  /* 
	   * BCC - bug fix for aggregate local vars - 3/31/96 
	   * Since the initializers have been transformed into statements, they
	   * don't have to be attached to the var or redundent statements will 
	   * be generated when it goes through Pcode more than once
	   */
	  if (var->init) {
	    RemoveInit(var->init);
	    var->init = 0;
	  }
	  /* BCC - end of change */

	  if (stmt!=0) {       
	    /* add statment to init_stmts */
	    if(init_stmts==0)
	      init_stmts = stmt;
	    else {
	      Stmt temp;
	      temp = init_stmts;
	      while(temp->lex_next!=0) temp = temp->lex_next;
	      temp->lex_next = stmt;
	      stmt->lex_prev = temp;
	    }
	  }
	}
      
#if 0 
/* GEH - moved above */
      /* process any pragmas associated with the local variable */
      opcode = SiblingOf(opcode);
      if(ChildOf(opcode)!=0)
	var->pragma = ReadLvarPragmas(ChildOf(opcode));
      
      /* process position if exists */
      opcode = SiblingOf(opcode);
      if(opcode!=0) {
	if(NodeType(opcode) != T_LIST)
	  Punt("incorrect position information (13)");
	else {
	  opcode = ChildOf(opcode);
	  if((opcode==0)||(NodeType(opcode)!=T_ID))
	    Punt("incorrect position information (14)");
	  else
	    if(!strcmp(StringOf(opcode), "POS")) {
	      Filename = StringOf(SiblingOf(opcode));
	      Lineno = IntegerOf(SiblingOf(SiblingOf(opcode)));
	      Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(opcode))));
	    }
	    else
	      Punt("incorrect position information (15)");
	}
      }
      if(Filename != 0) {
        var->lineno = Lineno;
        var->colno = Colno;
        var->filename = (char *)malloc(strlen(Filename)+1);
        sprintf(var->filename, "%s", Filename);
      }
#endif
      /** if not static, link it to the function or compound 
	statement **/
      if(!(var->type->type & TY_STATIC))
	*lv_list = AddVar2List(*lv_list, var);
      /* GEH - remove static declaration since moved out - 5-30-95 */
      else
	var->type->type &= ~TY_STATIC;
    } else {	/* $TypeDef */
      opcode = SiblingOf(opcode);
      TypeDefinition(opcode, scope);
    }
  }

  return(init_stmts);
}


/*-------------------------------------------------------------------*/
/* Read in parameter definitions. */
/*
 * list = $FunctPrmDecl* = (PARAM $VarId $DeclSpec $Pos?)*
 *			   ------------------------------
 * need to add parameters to scope level as local variables
 */
static ReadParameters(list)
     LIST list;
{
  LIST opcode, position;
  char *keyword;
  VarDcl var;
  VarList new, ptr;
  for(;list!=0;list=SiblingOf(list)) {
    /** create new variable declaration **/
    var = NewVarDcl();
    if ((list==0)||(NodeType(list)!= T_LIST))
      Punt("incorrect parameter declaration (1)");
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect parameter declaration (2)");
    keyword = StringOf(opcode);
    if(strcmp(keyword, "PARAM"))
      Punt("incorrect parameter declaration (3)");
    opcode = SiblingOf(opcode);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect parameter declaration (4)");
    var->name = StringOf(opcode);
    opcode = SiblingOf(opcode);
    if((opcode==0)||(NodeType(opcode)!=T_LIST))
      Punt("incorrect parameter declaration (5)");
    var->type = DeclSpec(opcode);
    /* add to proper scope in symbol table */
    if((FindVar(var->name, scope)!=0) ||
       (FindEnumField(var->name, scope)!=0))
      Punt("parameter is a redeclaration of a variable");
/* BCC - if it's doing inlining, then use NewNameIL to update the scope number
	 otherwise use the old rename function (NewName)           - 11/10/95 */
    /* BCC - don't rename "..." - 1/24/96 */
    if(!scope_assigned && strcmp(var->name, "...")) { 
      if (!inlining)
        var->new_name = NewName(var->name, scope);
      else
        var->new_name = NewNameIL(var->name, scope);
    }
    AddVar(var->name, var->new_name, var, scope);
    
    /* WE DON'T HAVE PARAMETER TYPE - IF NEEDED, ADD AS FOLLOWS:
       if (var->type->type & (TY_AUTO|TY_STATIC|TY_EXTERN|TY_GLOBAL)) {
       ^^^^^^^^^ - also don't have
       fprintf(Ferr, "> %s\n", var->name);
       Punt("incorrect parameter declaration (6)");
       }
       var->type->type |= TY_PARAMETER;
       */
    position = SiblingOf(opcode);
    if(position!=0) {
      if(NodeType(position) != T_LIST)
	Punt("incorrect position information (10)");
      else {
	position = ChildOf(position);
	if((position==0)||(NodeType(position)!=T_ID))
	  Punt("incorrect position information (11)");
	else
	  if(!strcmp(StringOf(position),"POS")) {
	    Filename = StringOf(SiblingOf(position));
	    Lineno = IntegerOf(SiblingOf(SiblingOf(position)));
	    Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(position))));
	  }
	  else
	    Punt("incorrect position information (12)");
      }
    }
    if(Filename != 0) {
      var->lineno = Lineno;
      var->colno = Colno;
      var->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(var->filename, "%s", Filename);
    }
    /* link it to the function. preserve the incoming order.
     */
    currentFuncDcl->param = AddVar2List(currentFuncDcl->param, var);
  }
}
/*-------------------------------------------------------------------*/
/* Read a statement pragma 
 * 
 * list = $Pragma* = (PRAGMA $String $ExprList $Pos?)
 *        --------
 */
static Pragma ReadStmtPragmas(list)
     LIST list;
{
  LIST opcode, position, p;
  Expr expr = 0;
  Expr temp_expr, ex_ptr;
  char *keyword;
  Pragma new, head_ptr, tail_ptr;
  head_ptr=tail_ptr=0;
  for(; list!=0; list = SiblingOf(list)) {
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("incorrect statement pragma specifier (1)");
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect statement pragma specifier (2)");
    keyword = StringOf(opcode);
    if(strcmp(keyword, "PRAGMA"))
      Punt("incorrect statement pragma specifier (3)");
    opcode = SiblingOf(opcode);
    /* Specifier string */
    if((opcode==0)||(NodeType(opcode)!=T_STRING))
      Punt("incorrect statement pragma specifier (4)");
    keyword = StringOf(opcode);
    /* Strings have "'s around them so, "ST ... " */
    /* GEH - removed since specifier does not contain pragma type (5/16/93)
    if((keyword[1]!='S')||(keyword[2]!='T'))
      Punt("incorrect statement pragma specifier (5)");
    */
    p = SiblingOf(opcode);
    if(p!=0) {
      if(strcmp(StringOf(ChildOf(p)), "POS")) {
	temp_expr = Expression(p);
	expr = ReduceExpr(temp_expr);
	RemoveExpr(temp_expr);
	p = SiblingOf(p);
	/* Expr */
	for(; p != 0; p = SiblingOf(p)) {
	  if(NodeType(p)!=T_LIST)
	    Punt("incorrect statement pragma specifier (6)");
	  if(!strcmp(StringOf(ChildOf(p)), "POS"))
	    break;
	  if(expr->next == 0) {
	    temp_expr = Expression(p);
	    expr->next = ReduceExpr(temp_expr);
	    RemoveExpr(temp_expr);
	  }
	  else {
	    ex_ptr = expr->next;
	    while(ex_ptr->next != 0) ex_ptr = ex_ptr->next;
	    temp_expr = Expression(p);
	    ex_ptr->next = ReduceExpr(temp_expr);
	    RemoveExpr(temp_expr);
	  }
	}
      }
    }
    new = NewPragma(keyword, expr);
    /* BCC - garbage collection - 8/25/96 */
    RemoveExpr(expr);
    /* position */
    position = p;
    if(position!=0) {
      if(NodeType(position) != T_LIST)
	Punt("incorrect position information (25)");
      else {
	position = ChildOf(position);
	if((position==0)||(NodeType(position)!=T_ID))
	  Punt("incorrect position information (26)");
	else
	  if(!strcmp(StringOf(position),"POS")) {
	    Filename = StringOf(SiblingOf(position));
	    Lineno = IntegerOf(SiblingOf(SiblingOf(position)));
	    Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(position))));
	  }
	  else
	    Punt("incorrect position information (27)");
      }
    }
    if(Filename != 0) {
      new->lineno = Lineno;
      new->colno = Colno;
      new->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(new->filename, "%s", Filename);
    }
    /* Attach to global variable */
    if(head_ptr==0) {
      head_ptr = new;
      tail_ptr = new;
    } else {
      tail_ptr->next = new;
      tail_ptr = new;
    }
  }
  return(head_ptr);
}


/* LCW - routine which reads the profile information and puts it in the 
 * profile field of the statement structure - 10/26/95
 */

static struct _ProfST *ReadStmtProfile(list)
    LIST list;
{
  struct _ProfST *profhead = NULL, *proftail = NULL, *profptr;

  if (strcmp(StringOf(list), "PROFILE"))
     Punt("incorrect profile information");
  list = SiblingOf(list);
  for (; list != 0; list = SiblingOf(list)) {
  /* 
   * BCC - if the function is inlined, the profile weight should be reduced 
   *	   12/19/95 
   */
      profptr = NewProfST(RealOf(list) * in_fraction);
      if (profhead == NULL) profhead = profptr;
      if (proftail == NULL)
	 proftail = profptr;
      else {
	 proftail->next = profptr;
	 proftail = profptr;
      }
  }
  return(profhead);
}

/* LCW - routine to read the profile information and put it in the
 * profile field of the expression structure - 10/26/95
 */

static struct _ProfEXPR *ReadExprProfile(list)
    LIST list;
{
  struct _ProfEXPR *profhead = NULL, *proftail = NULL, *profptr;

  if (strcmp(StringOf(list), "PROFILE"))
     Punt("incorrect profile information");
  list = SiblingOf(list);
  for (; list != 0; list = SiblingOf(list)) {
  /* 
   * BCC - if the function is inlined, the profile weight should be reduced 
   *	   12/19/95 
   */
      profptr = NewProfEXPR(RealOf(list) * in_fraction);
      if (profhead == NULL) profhead = profptr;
      if (proftail == NULL)
         proftail = profptr;
      else {
         proftail->next = profptr;
         proftail = profptr;
      }
  }
  return(profhead);
}


/*-------------------------------------------------------------------*/
/* Read an expression list;
 *
 * list = ($ExprList)
 *
 * Link expressions within the list through the next ptr.
 */

static Expr ReadExprList(list)
     LIST list;
{
  LIST ptr;
  Expr new, ex_ptr, temp;

  /* BCC - reduce exprs before attach them - 8/5/96 */
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect expression list form (1)");
  ptr = ChildOf(list);
  if((ptr==0)||(NodeType(ptr)!=T_LIST))
    Punt("incorrect expression list form (2)");
  temp = Expression(ptr);
  new = ReduceExpr(temp);
  RemoveExpr(temp);
  ptr = SiblingOf(ptr);
  for(; ptr!=0; ptr=SiblingOf(ptr)) {
    if(new->next == 0) {
      temp = Expression(ptr);
      new->next = ReduceExpr(temp);
      RemoveExpr(temp);
    }
    else {
      ex_ptr = new->next;
      while(ex_ptr->next!=0) ex_ptr=ex_ptr->next;
      temp = Expression(ptr);
      ex_ptr->next = ReduceExpr(temp);
      RemoveExpr(temp);
    }
  }
  return(new); 
}

/*-------------------------------------------------------------------*/
/* Read a compound statement.
 *
 * list = ScopeID? ($LocalDecl*) ($Stmt*)
 *                 -------------
 * the scope is incremented during the compound stmt.
 */
static Compound ReadCompoundStmt(list)
     LIST list;
{
  LIST ptr;
  Compound new;
  new = NewCompound();
  if(list==0)
    Punt("incorrect compound statement form (1)");
/* BCC - if inlining is not set, then check for correctness - 11/10/95 */
  if(!inlining && (NodeType(list)==T_INT) && (scope_assigned == 0))
    Punt("incorrect compound statement form (2)");
  if(NodeType(list) == T_INT) {
/* BCC - if inlining is not set, then use existing scope - 11/10/95 */
    if (!inlining) {
      scope = IntegerOf(list);
      if(scope > max_scope)
        max_scope = scope;
    }
    else scope = NewScopeId();
    list = SiblingOf(list);
  } else {
    scope = NewScopeId();
  }
  /* BCC - update the label_scope_stack - 4/19/96 */
  label_scope_stack[++label_scope_index] = scope;
  if (label_scope_index == MAX_LABEL_LEVEL)
      Punt("label stack full - extend MAX_LABEL_LEVEL in pcode.h\n");

  if(NodeType(list) != T_LIST)
    Punt("incorrect compound statement form (3)");
  ptr = ChildOf(list);
  new->scope = scope;
  AddScope(possible_scopes,scope);
  if(ptr != 0) 
    new->stmt_list = ReadLocalVar(ptr, &(new->var_list));	
  if((SiblingOf(list)==0)||(NodeType(SiblingOf(list))!=T_LIST))
    Punt("incorrect compound statement form (4)");
  ptr = ChildOf(SiblingOf(list));
  if(ptr!=0)
    ReadStmts(ptr, &(new->stmt_list));
  if (!scope_assigned) InvalidateVarListSyms (new->var_list,new->scope);
  DeleteScope(possible_scopes);
  label_scope_index--;
  return(new);
}

/*-------------------------------------------------------------------*/
/* Read a serial loop
 *
 * loop_type = LT_DO | LT_WHILE | LT_FOR
 * if loop_type = LT_DO
 *   list = $Stmt WHILE ($ExprList)
 *          -----
 * if loop_type = LT_WHILE
 *   list = ($ExprList) DO $Stmt
 *          -----------
 * if loop_type = LT_FOR
 *   list = ($ExprList?) ($ExprList?) ($ExprList?) DO $Stmt
 *          ------------
 *
 */
static SerLoop ReadSerLoop(list, loop_type)
     LIST list;
     int loop_type;
{
  LIST ptr;
  SerLoop new;
  new = NewSerLoop();
  new->loop_type = loop_type;
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect serial loop statement form (1)");
  if(loop_type == LT_DO) {
    /* if > one stmt caught below */
    ReadStmt(list, &(new->loop_body), ST_SERLOOP);	
    ptr = SiblingOf(list);
    if((ptr==0)||(NodeType(ptr)!= T_ID)||(strcmp(StringOf(ptr),"WHILE")))
      Punt("incorrect serial loop statement form (2)");
    ptr = SiblingOf(ptr);
    if((ptr==0)||(NodeType(ptr)!=T_LIST))
      Punt("incorrect serial loop statement form (3)");
    new->cond_expr = ReadExprList(ptr);
    if(SiblingOf(ptr)!=0)
      Punt("incorrect serial loop statement form (4)");
  }
  else if(loop_type == LT_WHILE) {
    new->cond_expr = ReadExprList(list);
    ptr = SiblingOf(list);
    if((ptr==0)||(NodeType(ptr)!=T_ID)||(strcmp(StringOf(ptr),"DO")))
      Punt("incorrect serial loop statement form (5)");
    ptr = SiblingOf(ptr);
    if((ptr==0)||(NodeType(ptr)!=T_LIST))
      Punt("incorrect serial loop statement form (6)");
    ReadStmt(ptr,&(new->loop_body), ST_SERLOOP);
    if(SiblingOf(ptr)!=0)
      Punt("incorrect serial loop statement form (7)");
  }
  else if(loop_type == LT_FOR) {
    if(ChildOf(list)!=0)
      new->init_expr = ReadExprList(list);
    ptr = SiblingOf(list);
    if((ptr==0)||(NodeType(ptr)!=T_LIST))
      Punt("incorrect serial loop statement form (8)");
    if(ChildOf(ptr)!=0)
      new->cond_expr = ReadExprList(ptr);
    ptr = SiblingOf(ptr);
    if((ptr==0)||(NodeType(ptr)!=T_LIST))
      Punt("incorrect serial loop statement form (9)");
    if(ChildOf(ptr)!=0)
      new->iter_expr = ReadExprList(ptr);
    ptr = SiblingOf(ptr);
    if((ptr==0)||(NodeType(ptr)!=T_ID)||(strcmp(StringOf(ptr),"DO")))
      Punt("incorrect serial loop statement form (10)");
    ptr = SiblingOf(ptr);
    if((ptr==0)||(NodeType(ptr)!=T_LIST))
      Punt("incorrect serial loop statement form (11)");
    ReadStmt(ptr,&(new->loop_body), ST_SERLOOP);
    if(SiblingOf(ptr)!=0)
      Punt("incorrect serial loop statement form (12)");
  }
  else 
    Punt("internal error: incorrect serial loop type");
  return(new);
}

/*-------------------------------------------------------------------*/
/* Read an if statement.
 *
 * list = ($ExprList) THEN $Stmt ELSE $Stmt |($ExprList) THEN $Stmt
 *        -----------                        -----------
 */
static IfStmt ReadIfStmt(list)
     LIST list;
{
  LIST ptr;
  IfStmt new;
  new = NewIfStmt();
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect if statement form (1)");
  new->cond_expr = ReadExprList(list);
  ptr = SiblingOf(list);
  if((ptr==0)||(NodeType(ptr)!=T_ID)||(strcmp(StringOf(ptr),"THEN")))
    Punt("incorrect if statement form (2)");
  ptr = SiblingOf(ptr);
  if((ptr==0)||(NodeType(ptr)!=T_LIST))
    Punt("incorrect if statement form (3)");
  ReadStmt(ptr, &(new->then_block), ST_IF);
  ptr = SiblingOf(ptr);
  if(ptr!=0) {
    if((NodeType(ptr)!=T_ID)||(strcmp(StringOf(ptr),"ELSE")))
      Punt("incorrect if statement form (4)");
    ptr = SiblingOf(ptr);
    if((ptr==0)||(NodeType(ptr)!=T_LIST))
      Punt("inocrrect if statement form (5)");
    ReadStmt(ptr, &(new->else_block), ST_IF);
    if(SiblingOf(ptr)!=0)
      Punt("incorrect if statement form (6)");
  }
  return(new);
}

/*-------------------------------------------------------------------*/
/* Read a switch statement.
 * 
 * list = ($ExprList) $Stmt
 *	  -----------
 */
static SwitchStmt ReadSwitchStmt(list)
     LIST list;
{
  LIST ptr;
  SwitchStmt new;
  new = NewSwitchStmt();
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect switch statement form (1)");
  new->expression = ReadExprList(list);
  ptr = SiblingOf(list);
  if((ptr==0)||(NodeType(ptr)!=T_LIST))
    Punt("incorrect switch statement form (2)");
  ReadStmt(ptr, &(new->switchbody), ST_SWITCH);
  if(SiblingOf(ptr)!=0)
    Punt("incorrect if statement form (3)");
  return(new);
}

/*-------------------------------------------------------------------*/
/* Read return statement.
 * 
 * list = ($ExprList)
 * 	  -----------
 */
static Expr ReadReturnStmt(list)
     LIST list;
{
  Expr new;
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect return statement form (1)");
  new = ReadExprList(list);
  return(new);
}

/*-------------------------------------------------------------------*/
/* Read a goto statement.
 *
 * list = $LabelID
 */
static char *ReadGotoStmt(list)
     LIST list;
{
  char *new;

  if((list==0)||(NodeType(list)!=T_ID))
    Punt("incorrect goto statement form (1)");

/* 
 * BCC - Because labels can be forward referenced, they are renamed either here
 * 	 here or in the label definition depending on whichever happens first
 */
  if(! scope_assigned) {
    char *oldname, *newname;
    int dummy;

    oldname = StringOf(list);
    if ( !C_find(label_mapping_table, oldname, 0, &dummy, (Pointer *) &new )) {
      /* BCC - use the scope numbers stored in the stack - 4/19/96 */
      if (!inlining)
        newname = NewNameLabel(oldname, func_name, 
			       label_scope_stack[label_scope_index]);
      else
        newname = NewNameIL(oldname, label_scope_stack[label_scope_index]);
#if 0
      oldname = C_findstr(oldname);
      newname = C_findstr(newname);
      C_update(label_mapping_table, oldname, 0, 0, newname);
      new = newname;
#endif
      /* BCC - garbage collection - 8/19/96 */
      C_update(label_mapping_table, oldname, 0, 0, newname);
      new = newname;
    }
  }
  else new = StringOf(list);

#if 0
  /* BCC - rename the label for Pinlie - 11/13/95 */
  if (inlining)
    new = NewName(StringOf(list), label_counter);
  else 
    new = StringOf(list);
#endif

  if(SiblingOf(list)!=0)
    Punt("incorrect goto form (2)");
  return(strdup(new));
}

/*-------------------------------------------------------------------*/
/* Read a Pstmt.
 *
 * list = $Stmt
 */
static Pstmt ReadPstmt(list)
     LIST list;
{
  Pstmt new;
  new = NewPstmt();
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect pstmt statement form (1)");
  ReadStmt(list, &(new->stmt), ST_PSTMT);
  if(SiblingOf(list)!=0)
    Punt("incorrect pstmt form (2)");
  return(new);
}

/*-------------------------------------------------------------------*/
/* Read a loop body
 *
 * list = $Stmt
 */
static BodyStmt ReadBodyStmt(list)
     LIST list;
{
  BodyStmt new;
  new = NewBodyStmt();
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect body statement form (1)");
  ReadStmt(list, &(new->statement), ST_BODY);
  if(SiblingOf(list)!=0)
    Punt("incorrect body stmt form (2)");
  return(new);
}
/*-------------------------------------------------------------------*/
/* Read a loop epilogue
 * list = $Stmt
 */
static EpilogueStmt ReadEpilogueStmt(list)
     LIST list;
{
  EpilogueStmt new;
  new = NewEpilogueStmt();
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect epilogue statement form (1)");
  ReadStmt(list, &(new->statement), ST_EPILOGUE);
  if(SiblingOf(list)!=0)
    Punt("incorrect epilogue stmt form (2)");
  return(new);
}
/*-------------------------------------------------------------------*/
/* Read an advance statement.
 *
 * list = $IntVal
 */
static Advance ReadAdvanceStmt(list)
     LIST list;
{
  Advance new;
  new = NewAdvance();
  if((list==0)||(NodeType(list)!=T_INT))
    Punt("incorrect advance statement form (1)");
  new->marker = IntegerOf(list);
  if(SiblingOf(list)!=0)
    Punt("incorrect advance statement form (2)");
  return(new);
}

/*-------------------------------------------------------------------*/
/* Read an await statement.
 *
 * list = $IntVal $IntVal
 *        -------
 */
static Await ReadAwaitStmt(list)
     LIST list;
{
  LIST ptr;
  Await new;
  new = NewAwait();
  if((list==0)||(NodeType(list)!=T_INT))
    Punt("incorrect await statement form (1)");
  new->marker = IntegerOf(list);
  ptr = SiblingOf(list);	
  if((ptr==0)||(NodeType(ptr)!=T_INT))
    Punt("incorrect await statement form (2)");
  new->distance = IntegerOf(ptr);
  if(SiblingOf(ptr)!=0)
    Punt("incorrect await statement form (3)");
  return(new);
}


/*-------------------------------------------------------------------*/
/* Read DoPstmt
 *
 * list = $DoPstmt
 *	= (PSTMT (PROLOGUE $Stmt (BODY $Stmt EPILOGUE $Stmt)) $Pos?)
 *
 * 3/93:  still read in dopstmt - but internally, just create pstmt
 */
static Pstmt ReadDoPstmt(list)
     LIST list;
{
  LIST ptr, arg1, arg2;
  Pstmt new;
  new = NewPstmt();
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect do_pstmt form (1)");
  ptr = ChildOf(list);
  if((ptr==0)||(NodeType(ptr)!=T_ID)||(strcmp(StringOf(ptr),"PSTMT")))
    Punt("incorrect do_pstmt form (2)");
  ptr = SiblingOf(ptr);
  if((ptr==0)||(NodeType(ptr)!=T_LIST))
    Punt("incorrect do_pstmt form (3)");
  arg1 = ChildOf(ptr);
  if((arg1==0)||(NodeType(arg1)!=T_ID)||
     (strcmp(StringOf(arg1),"PROLOGUE")))
    Punt("incorrect do_pstmt form (4)");
  arg1= SiblingOf(arg1);
  if((arg1==0)||(NodeType(arg1)!=T_LIST))
    Punt("incorrect do_pstmt form (5)");
  ReadStmt(arg1, &(new->stmt), ST_PARLOOP);
  
  /* handle $Pos? */
  ptr=SiblingOf(ptr);           /* $Pos? */
  if(ptr!=0) {
    if(NodeType(ptr) != T_LIST)
      Punt("incorrect position information (31)");
    else {
      ptr=ChildOf(ptr);
      if((ptr==0)||(NodeType(ptr)!=T_ID))
	Punt("incorrect position information (32)");
      else
	if(!strcmp(StringOf(ptr),"POS")) {
	  Filename = StringOf(SiblingOf(ptr));
	  Lineno = IntegerOf(SiblingOf(SiblingOf(ptr)));
	  Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(ptr))));
	}
	else
	  Punt("incorrect position information (33)");
    }
  }
  if(Filename != 0) {
    new->lineno = Lineno;
    new->colno = Colno;
    new->filename = (char *)malloc(strlen(Filename)+1);
    sprintf(new->filename, "%s", Filename);
  }
  
  return(new);
}

/*-------------------------------------------------------------------*/
/* Read a parallel loop.
 *
 * list = $DoStmtHead $DoPStmt
 *        -----------
 * loop_type = LT_DOSERIAL | LT_DOALL | LT_DOACROSS | LT_DOSUPER
 */
static ParLoop ReadParLoop(list, loop_type)
     LIST list;
     int loop_type;
{
  LIST ptr, argument;
  ParLoop new;
  char *name;
  VarDcl v;
  Type t;
  new = NewParLoop();
  new->loop_type = loop_type;
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect parallel loop statement form (1)");
  ptr = ChildOf(list);
  if((ptr==0)||(NodeType(ptr)!=T_LIST))
    Punt("incorrect parallel loop statement form (2)");
  argument = ChildOf(ptr);
  if((argument==0)||(NodeType(argument)!=T_ID)||
     (strcmp(StringOf(argument), "INDEX")))
    Punt("incorrect parallel loop statement form (3)");
  argument = SiblingOf(argument);
  if((argument==0)||(NodeType(argument)!=T_ID))
    Punt("incorrect parallel loop statement form (4)");
  name = StringOf(argument);
  v=FindNearScopeVar(possible_scopes, name);
  if(v != 0) {
    t = NewType();
    t->type = TY_INT;
    if(v->new_name != 0) 
      /* 1/93 - update iteration_var to expression */
      new->iteration_var = NewVarExpr(v->new_name, t);
    else 
      new->iteration_var = NewVarExpr(name, t);
  } 
  ptr = SiblingOf(ptr);
  if((ptr==0)||(NodeType(ptr)!=T_LIST))
    Punt("incorrect parallel loop statement form (5)");
  argument = ChildOf(ptr);
  if((argument==0)||(NodeType(argument)!=T_ID)||
     (strcmp(StringOf(argument), "INIT")))
    Punt("incorrect parallel loop statement form (6)");
  argument = SiblingOf(argument);
  if((argument==0)||(NodeType(argument)!=T_LIST))
    Punt("incorrect parallel loop statement form (7)");
  new->init_value = Expression(argument);
  ptr = SiblingOf(ptr);
  if((ptr==0)||(NodeType(ptr)!=T_LIST))
    Punt("incorrect parallel loop statement form (8)");
  argument = ChildOf(ptr);
  if((argument==0)||(NodeType(argument)!=T_ID)||
     (strcmp(StringOf(argument), "FINAL")))
    Punt("incorrect parallel loop statement form (9)");
  argument = SiblingOf(argument);
  if((argument==0)||(NodeType(argument)!=T_LIST))
    Punt("incorrect parallel loop statement form (10)");
  new->final_value = Expression(argument);
  ptr = SiblingOf(ptr);
  if((ptr==0)||(NodeType(ptr)!=T_LIST))
    Punt("incorrect parallel loop statement form (11)");
  argument = ChildOf(ptr);
  if((argument==0)||(NodeType(argument)!=T_ID)||
     (strcmp(StringOf(argument), "INC")))
    Punt("incorrect parallel loop statement form (12)");
  argument = SiblingOf(argument);
  if((argument==0)||(NodeType(argument)!=T_LIST))
    Punt("incorrect parallel loop statement form (13)");
  new->incr_value = Expression(argument);
  if(SiblingOf(ptr)!=0)
    Punt("incorrect parallel loop statement form (14)");
  list = SiblingOf(list);
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect parallel loop statement form (15)");
  new->pstmt = ReadDoPstmt(list);
  if(SiblingOf(list)!=0)
    Punt("incorrect parallel loop statement form (16)");
  
  return(new);
}

/*-------------------------------------------------------------------*/
/* Read a mutex statement.
 *
 * list = $Expr $Stmt
 *        ----
 */
static Mutex ReadMutexStmt(list)
     LIST list;
{
  LIST ptr;
  Mutex new;
  new = NewMutex();
  if((list==0)||(NodeType(list)!=T_LIST))
    Punt("incorrect mutex statement form (1)");
  new->expression = Expression(list);
  ptr = SiblingOf(list);
  if((ptr==0)||(NodeType(ptr)!=T_LIST))
    Punt("incorrect mutex statement form (2)");
  ReadStmt(ptr, &(new->statement), ST_MUTEX);
  if(SiblingOf(ptr)!=0)
    Punt("incorrect mutex statement form (3)");
  return(new);
}


/*-------------------------------------------------------------------*/
/* Read a cobegin statement.
 *
 * list = $Stmt+
 */
static Cobegin ReadCobeginStmt(list)
     LIST list;
{
  Cobegin new;
  new = NewCobegin();
  if((list==0)||(NodeType(list)!=T_LIST)) /* one or more */
    Punt("incorrect cobegin statement form (1)");
  ReadStmt(list, &(new->statements), ST_COBEGIN);
  return(new);
}

/* Read label list (added 2/92)
 *
 * list = $Label* 
 * $label = = (CASE $Expr) | (DEFAULT) |  (LABEL $LabelID)
 * $LabelID = a standard C identifier
 *
 * Don't rename labels using scopeid as before (labels should be 
 * unique)
 */
static Label ReadStmtLabels(list) 
     LIST list;
{
  LIST opcode, ptr;
  Label new, head_ptr, tail_ptr;
  char *keyword;
  head_ptr = tail_ptr = 0;
  if(list == 0)
    return;
  for(; list!=0; list = SiblingOf(list)) {
    new = NewLabel();
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("incorrect statement label specifier (1)");
    opcode = ChildOf(list);
    if((opcode == 0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect statement label specifier (2)");
    keyword = StringOf(opcode);
    if(!strcmp(keyword, "CASE")) {
      new->type = LB_CASE;
      ptr = SiblingOf(opcode);
      new->expression = Expression(ptr);  /* $Expr */
    } else if(!strcmp(keyword, "DEFAULT")) {
      new->type = LB_DEFAULT;
    } else if(!strcmp(keyword, "LABEL")) {
      new->type = LB_LABEL;
      ptr = SiblingOf(opcode);

/*
 * BCC - Because labels can be forward referenced, they are renamed either here
 *       here or in the label definition depending on whichever happens first
 */
      if(! scope_assigned) {
        char *oldname, *newname;
        int dummy;

        oldname = StringOf(ptr);
        if (!C_find(label_mapping_table,oldname,0,&dummy,(Pointer *)&new->val)){
	  /* BCC - use the scope stored in the stack - 4/19/96 */
          if (!inlining)
            newname = NewNameLabel(oldname, func_name, 
				   label_scope_stack[label_scope_index]); 
          else
            newname = NewNameIL(oldname, label_scope_stack[label_scope_index]);
          C_update(label_mapping_table, oldname, 0, 0, newname);
          new->val = strdup(newname);
        }
	/* BCC - duplicate the name for garbage collection - 8/21/96 */
	else 
	  new->val = strdup(new->val);
      }
      else new->val = strdup(StringOf(ptr));

#if 0
      /* BCC - rename the label for Pinlie - 11/13/95 */
      if (inlining)
	new->val = NewName(StringOf(ptr), label_counter);
      else 
        new->val = StringOf(ptr);
#endif
    } else
      Punt("incorrect statement label specifier (3)");
    if(head_ptr == 0) {
      head_ptr = new;
      tail_ptr = new;
    } else {
      tail_ptr->next = new;
      new->prev = tail_ptr;
      tail_ptr = new;
    }
  }
  return(head_ptr);
}


/*-------------------------------------------------------------------*/
/* Read in a single statement 
 *
 * list = $Stmt = (($Label*) $Stmt2 ($Pragma*) $Pos?)
 *        -----
 * stmt_list = ptr to stmt_list
 */
static ReadStmt(list, stmt_list, parent_type)
     LIST list;
     Stmt *stmt_list;
     int parent_type;
{
  LIST ptr, opcode, argument;
  char *keyword;
  Stmt stmt;
  int loop_type;
  LIST ptr2;  /* LCW */
  stmt = NewStmt();
  if(list==0)
    return;
  if(NodeType(list)!=T_LIST)
    Punt("incorrect statement list (1)");
  ptr = ChildOf(list);          /* ($Label*) */
  if(ChildOf(ptr)!=0) 
    stmt->labels = ReadStmtLabels(ChildOf(ptr));
  ptr = SiblingOf(ptr);         /* $Stmt2 */
  /* handle $Stmt2 */
  opcode = ChildOf(ptr);
  if((opcode==0)||(NodeType(opcode)!=T_ID))
    Punt("incorrect statement specifier (1)");
  keyword = StringOf(opcode);
  argument = SiblingOf(opcode);
  if(! strcmp(keyword, "EXPR")) {
    /* argument = ($ExprList) */
    stmt->type = ST_EXPR;
    stmt->stmtstruct.expr = ReadExprList(argument);
  } else if(! strcmp(keyword,"COMPSTMT")) {
    /* argument = ($LocalDecl*) ($stmt*) */
    stmt->type = ST_COMPOUND;
    stmt->stmtstruct.compound = ReadCompoundStmt(argument);
  } else if(! strcmp(keyword,"DO")) {
    /* argument = $Stmt WHILE ($ExprList) */
    stmt->type = ST_SERLOOP;
    loop_type = LT_DO;
    stmt->stmtstruct.serloop = ReadSerLoop(argument, loop_type);
  } else if(! strcmp(keyword,"WHILE")) {
    /* argument = ($ExprList) DO $Stmt */
    stmt->type = ST_SERLOOP;
    loop_type = LT_WHILE;
    stmt->stmtstruct.serloop = ReadSerLoop(argument, loop_type);
  } else if(! strcmp(keyword,"FOR")) {
    /* argument = ($ExprList?) ($ExprList?) ($ExprList?) DO $Stmt */
    stmt->type = ST_SERLOOP;
    loop_type = LT_FOR;
    stmt->stmtstruct.serloop = ReadSerLoop(argument, loop_type);
  } else if(! strcmp(keyword,"IF")) {
    /* argument = ($ExprList) THEN $Stmt Else $Stmt |
     *            ($ExprList) THEN $Stmt
     */
    stmt->type = ST_IF;
    stmt->stmtstruct.ifstmt = ReadIfStmt(argument);
  } else if(! strcmp(keyword,"SWITCH")) {
    /* argument = ($ExprList) $Stmt */
    stmt->type = ST_SWITCH;
    stmt->stmtstruct.switchstmt = ReadSwitchStmt(argument);
  } else if(! strcmp(keyword,"BREAK")) {
    stmt->type = ST_BREAK;
  } else if(! strcmp(keyword,"CONTINUE")) {
    stmt->type = ST_CONT;
  } else if(! strcmp(keyword,"RETURN")) {
    stmt->type = ST_RETURN;
    if(argument!=0)
      /* argument = ($ExprList) */
      stmt->stmtstruct.ret = ReadReturnStmt(argument);
  } else if(! strcmp(keyword,"GOTO"))  {
    /* argument = $LabelID */
    stmt->type = ST_GOTO;
    stmt->stmtstruct.label = ReadGotoStmt(argument);
  } else if(! strcmp(keyword,"NULL")) {
    stmt->type = ST_NOOP;
  } else if(! strcmp(keyword, "PSTMT")) {
    /* argument = $Stmt */
    stmt->type = ST_PSTMT;
    stmt->stmtstruct.pstmt = ReadPstmt(argument);
  } else if(! strcmp(keyword, "ADVANCE")) {
    /* argument = $IntVal */
    stmt->type = ST_ADVANCE;
    stmt->stmtstruct.advance = ReadAdvanceStmt(argument);
  } else if(! strcmp(keyword, "AWAIT")) {
    /* argument = $IntVal $IntVal */
    stmt->type = ST_AWAIT;
    stmt->stmtstruct.await = ReadAwaitStmt(argument);
  } else if(! strcmp(keyword, "DOSERIAL")) {
    /* argument = $DoStmtHead $DoPStmt */
    stmt->type = ST_PARLOOP;
    loop_type = LT_DOSERIAL;
    stmt->stmtstruct.parloop = ReadParLoop(argument, loop_type);
  } else if(! strcmp(keyword, "DOALL")) {
    /* argument = $DoStmtHead $DoPstmt */
    stmt->type = ST_PARLOOP;
    loop_type = LT_DOALL;
    stmt->stmtstruct.parloop = ReadParLoop(argument, loop_type);
  } else if(! strcmp(keyword, "DOACROSS")) {
    /* argument = $DoStmtHead $DoPstmt */
    stmt->type = ST_PARLOOP;
    loop_type = LT_DOACROSS;
    stmt->stmtstruct.parloop = ReadParLoop(argument, loop_type);
  } else if(! strcmp(keyword, "DOSUPER")) {
    /* argument = $DoStmtHead $DoPstmt */
    stmt->type = ST_PARLOOP;
    loop_type = LT_DOSUPER;
    stmt->stmtstruct.parloop = ReadParLoop(argument, loop_type);
  } else if(! strcmp(keyword, "MUTEX")) {
    /* argument = $Expr $Stmt */
    stmt->type = ST_MUTEX;
    stmt->stmtstruct.mutex = ReadMutexStmt(argument);
  } else if(! strcmp(keyword, "COBEGIN")) {
    /* argument = $Stmt+ */
    stmt->type = ST_COBEGIN;
    stmt->stmtstruct.cobegin = ReadCobeginStmt(argument);
  } else
    Punt("incorrect statement specifier (2)");
  
  /* handle ($Pragma*) */
  ptr=SiblingOf(ptr);           /* ($Pragma*) */
  if(ChildOf(ptr)!=0)
    stmt->pragma = ReadStmtPragmas(ChildOf(ptr));
  

    /* LCW - the following code is modified to handle both $Pos and $Profile
     * constructs - 5/17/96 
     */
    /* handle $Pos? and $Profile? */
    ptr=SiblingOf(ptr);		/* $Pos? or $Profile? */
    if(ptr!=0) {
      if(NodeType(ptr) != T_LIST)
	Punt("incorrect position or profile information (28)");
      else {
	ptr2 = SiblingOf(ptr); /* LCW - in case both $Pos and $Profile exist */
	ptr=ChildOf(ptr);
	if (ptr2 != 0) { /* LCW - both $Pos and $Profile exist */
	   if((ptr==0)||(NodeType(ptr)!=T_ID))
	     Punt("incorrect position information (29)");
	   else
	     if(!strcmp(StringOf(ptr),"POS")) {
	       Filename = StringOf(SiblingOf(ptr));
	       Lineno = IntegerOf(SiblingOf(SiblingOf(ptr)));
	       Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(ptr))));
	     }
	     else
	       Punt("incorrect position information (30)");
	   if(NodeType(ptr2) != T_LIST)
	     Punt("incorrect profile information");
	   else {
	     ptr = ChildOf(ptr2);
	     if ((ptr==0)||(NodeType(ptr)!=T_ID))
		Punt("incorrect profile information");
	     else
		if(!strcmp(StringOf(ptr), "PROFILE"))
		  stmt->profile = ReadStmtProfile(ptr);
		else
		  Punt("incorrect profile information");
	   }
	}
	else {  /* LCW - either $Pos or $Profile exists */
	   if((ptr==0)||(NodeType(ptr)!=T_ID))
	     Punt("incorrect position or profile information");
	   else
	     if(!strcmp(StringOf(ptr),"POS")) {
	       Filename = StringOf(SiblingOf(ptr));
	       Lineno = IntegerOf(SiblingOf(SiblingOf(ptr)));
	       Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(ptr))));
	     }
	     else if(!strcmp(StringOf(ptr), "PROFILE")) 
	       stmt->profile = ReadStmtProfile(ptr);
	     else
	       Punt("incorrect position or profile information");
	}
      }
    }

/* LCW - old code which can not handle $Profile? - 5/17/96 */
#if 0
  /* handle $Pos? */
  ptr=SiblingOf(ptr);           /* $Pos? */
  if(ptr!=0) {
    if(NodeType(ptr) != T_LIST)
      Punt("incorrect position information (28)");
    else {
      ptr=ChildOf(ptr);
      if((ptr==0)||(NodeType(ptr)!=T_ID))
	Punt("incorrect position information (29)");
      else
	if(!strcmp(StringOf(ptr),"POS")) {
	  Filename = StringOf(SiblingOf(ptr));
	  Lineno = IntegerOf(SiblingOf(SiblingOf(ptr)));
	  Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(ptr))));
	}
	else
	  Punt("incorrect position information (30)");
    }
  }
#endif

  if(Filename != 0) {
    stmt->lineno = Lineno;
    stmt->colno = Colno;
    stmt->filename = (char *)malloc(strlen(Filename)+1);
    sprintf(stmt->filename, "%s", Filename);
  }
  /* attach to list */
  if(*stmt_list == 0)
    *stmt_list = stmt;
  else {
    Stmt temp;
    temp = *stmt_list;
    while(temp->lex_next != 0) temp = temp->lex_next;
    temp->lex_next = stmt;
    stmt->lex_prev = temp;
  }
}

/*-------------------------------------------------------------------*/
/* Read in statement list 
 *
 * list = $Stmt* = (($Label*) $Stmt2 ($Pragma*) $Pos?)
 *        -----
 * stmt_list = ptr to stmt_list
 * single_stmt == flag that indicates that we should only parse one stmt
 *                this is needed to handle adding compound stmts to
 *                if stmts when there is an else branch (and also for
 *                do while).  (2/92)
 */
static ReadStmts(list, stmt_list)
     LIST list;
     Stmt *stmt_list;
{
  LIST ptr, opcode, argument;
  char *keyword;
  Stmt stmt;
  int loop_type;
  LIST ptr2;  /* LCW */
  if(list==0)
    return;
  if(NodeType(list)!=T_LIST)
    Punt("incorrect statement list (1)");
  for(; list!=0; list=SiblingOf(list)) {
    stmt = NewStmt();
    ptr=ChildOf(list);	          /* ($Label*) */
    if(ChildOf(ptr)!=0) 
      stmt->labels = ReadStmtLabels(ChildOf(ptr));
    ptr = SiblingOf(ptr);           /* $Stmt2 */
    /* handle $Stmt2 */
    opcode = ChildOf(ptr);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("incorrect statement specifier (1)");
    keyword = StringOf(opcode);
    argument = SiblingOf(opcode);
    if(! strcmp(keyword, "EXPR")) {
      /* argument = ($ExprList) */
      stmt->type = ST_EXPR;
      stmt->stmtstruct.expr = ReadExprList(argument);	
    } else if(! strcmp(keyword,"COMPSTMT")) {
      /* argument = ($LocalDecl*) ($stmt*) */
      stmt->type = ST_COMPOUND;
      stmt->stmtstruct.compound = ReadCompoundStmt(argument);
    } else if(! strcmp(keyword,"DO")) {
      /* argument = $Stmt WHILE ($ExprList) */
      stmt->type = ST_SERLOOP;
      loop_type = LT_DO;
      stmt->stmtstruct.serloop = ReadSerLoop(argument, loop_type);
    } else if(! strcmp(keyword,"WHILE")) {
      /* argument = ($ExprList) DO $Stmt */
      stmt->type = ST_SERLOOP;
      loop_type = LT_WHILE;
      stmt->stmtstruct.serloop = ReadSerLoop(argument, loop_type);
    } else if(! strcmp(keyword,"FOR")) {
      /* argument = ($ExprList?) ($ExprList?) ($ExprList?) DO $Stmt */
      stmt->type = ST_SERLOOP;
      loop_type = LT_FOR;
      stmt->stmtstruct.serloop = ReadSerLoop(argument, loop_type);
    } else if(! strcmp(keyword,"IF")) {
      /* argument = ($ExprList) THEN $Stmt Else $Stmt |
       * 		  ($ExprList) THEN $Stmt
       */
      stmt->type = ST_IF;
      stmt->stmtstruct.ifstmt = ReadIfStmt(argument);
    } else if(! strcmp(keyword,"SWITCH")) {
      /* argument = ($ExprList) $Stmt */
      stmt->type = ST_SWITCH;
      stmt->stmtstruct.switchstmt = ReadSwitchStmt(argument);
    } else if(! strcmp(keyword,"BREAK")) {
      stmt->type = ST_BREAK;
    } else if(! strcmp(keyword,"CONTINUE")) {
      stmt->type = ST_CONT;
    } else if(! strcmp(keyword,"RETURN")) {
      stmt->type = ST_RETURN;
      if(argument!=0)
	/* argument = ($ExprList) */
	stmt->stmtstruct.ret = ReadReturnStmt(argument);
    } else if(! strcmp(keyword,"GOTO"))  {
      /* argument = $LabelID */
      stmt->type = ST_GOTO;
      stmt->stmtstruct.label = ReadGotoStmt(argument);
    } else if(! strcmp(keyword,"NULL")) {
      stmt->type = ST_NOOP;
    } else if(! strcmp(keyword, "PSTMT")) {
      /* argument = $Stmt */
      stmt->type = ST_PSTMT;
      stmt->stmtstruct.pstmt = ReadPstmt(argument);
    } else if(! strcmp(keyword, "ADVANCE")) {
      /* argument = $IntVal */
      stmt->type = ST_ADVANCE;
      stmt->stmtstruct.advance = ReadAdvanceStmt(argument);
    } else if(! strcmp(keyword, "AWAIT")) {
      /* argument = $IntVal $IntVal */
      stmt->type = ST_AWAIT;
      stmt->stmtstruct.await = ReadAwaitStmt(argument);
    } else if(! strcmp(keyword, "DOSERIAL")) {
      /* argument = $DoStmtHead $DoPStmt */
      stmt->type = ST_PARLOOP;
      loop_type = LT_DOSERIAL;
      stmt->stmtstruct.parloop = ReadParLoop(argument, loop_type);
    } else if(! strcmp(keyword, "DOALL")) {
      /* argument = $DoStmtHead $DoPstmt */
      stmt->type = ST_PARLOOP;
      loop_type = LT_DOALL;
      stmt->stmtstruct.parloop = ReadParLoop(argument, loop_type);
    } else if(! strcmp(keyword, "DOACROSS")) {
      /* argument = $DoStmtHead $DoPstmt */
      stmt->type = ST_PARLOOP;
      loop_type = LT_DOACROSS;
      stmt->stmtstruct.parloop = ReadParLoop(argument, loop_type);
    } else if(! strcmp(keyword, "DOSUPER")) {
      /* argument = $DoStmtHead $DoPstmt */
      stmt->type = ST_PARLOOP;
      loop_type = LT_DOSUPER;
      stmt->stmtstruct.parloop = ReadParLoop(argument, loop_type);
    } else if(! strcmp(keyword, "MUTEX")) {
      /* argument = $Expr $Stmt */
      stmt->type = ST_MUTEX;
      stmt->stmtstruct.mutex = ReadMutexStmt(argument);
    } else if(! strcmp(keyword, "COBEGIN")) {
      /* argument = $Stmt+ */
      stmt->type = ST_COBEGIN;
      stmt->stmtstruct.cobegin = ReadCobeginStmt(argument);
    } else if(! strcmp(keyword, "BODY")) {       /* 1/2/91 */
      /* argument = $Stmt */
      stmt->type = ST_BODY;
      stmt->stmtstruct.bodystmt = ReadBodyStmt(argument);
    } else if(! strcmp(keyword, "EPILOGUE")) {
      /* argument = $Stmt */
      stmt->type = ST_EPILOGUE;
      stmt->stmtstruct.epiloguestmt = ReadEpilogueStmt(argument);
    } else
      Punt("incorrect statement specifier (2)");
    
    /* handle ($Pragma*) */
    ptr=SiblingOf(ptr);		/* ($Pragma*) */
    if(ChildOf(ptr)!=0)
      stmt->pragma = ReadStmtPragmas(ChildOf(ptr));


    /* LCW - the following code is modified to handle both $Pos and $Profile
     * constructs - 10/26/95 
     */
    /* handle $Pos? and $Profile? */
    ptr=SiblingOf(ptr);		/* $Pos? or $Profile? */
    if(ptr!=0) {
      if(NodeType(ptr) != T_LIST)
	Punt("incorrect position or profile information (28)");
      else {
	ptr2 = SiblingOf(ptr); /* LCW - in case both $Pos and $Profile exist */
	ptr=ChildOf(ptr);
	if (ptr2 != 0) { /* LCW - both $Pos and $Profile exist */
	   if((ptr==0)||(NodeType(ptr)!=T_ID))
	     Punt("incorrect position information (29)");
	   else
	     if(!strcmp(StringOf(ptr),"POS")) {
	       Filename = StringOf(SiblingOf(ptr));
	       Lineno = IntegerOf(SiblingOf(SiblingOf(ptr)));
	       Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(ptr))));
	     }
	     else
	       Punt("incorrect position information (30)");
	   if(NodeType(ptr2) != T_LIST)
	     Punt("incorrect profile information");
	   else {
	     ptr = ChildOf(ptr2);
	     if ((ptr==0)||(NodeType(ptr)!=T_ID))
		Punt("incorrect profile information");
	     else
		if(!strcmp(StringOf(ptr), "PROFILE"))
		  stmt->profile = ReadStmtProfile(ptr);
		else
		  Punt("incorrect profile information");
	   }
	}
	else {  /* LCW - either $Pos or $Profile exists */
	   if((ptr==0)||(NodeType(ptr)!=T_ID))
	     Punt("incorrect position or profile information");
	   else
	     if(!strcmp(StringOf(ptr),"POS")) {
	       Filename = StringOf(SiblingOf(ptr));
	       Lineno = IntegerOf(SiblingOf(SiblingOf(ptr)));
	       Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(ptr))));
	     }
	     else if(!strcmp(StringOf(ptr), "PROFILE")) 
	       stmt->profile = ReadStmtProfile(ptr);
	     else
	       Punt("incorrect position or profile information");
	}
      }
    }

/* LCW - old code which can not handle $Profile? - 10/26/95 */
#if 0
    /* handle $Pos? */
    ptr=SiblingOf(ptr);         /* $Pos? */
    if(ptr!=0) {
      if(NodeType(ptr) != T_LIST)
        Punt("incorrect position information (28)");
      else {
        ptr=ChildOf(ptr);
        if((ptr==0)||(NodeType(ptr)!=T_ID))
          Punt("incorrect position information (29)");
        else
          if(!strcmp(StringOf(ptr),"POS")) {
            Filename = StringOf(SiblingOf(ptr));
            Lineno = IntegerOf(SiblingOf(SiblingOf(ptr)));
            Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(ptr))));
          }
          else
            Punt("incorrect position information (30)");
      }
    }
#endif

    if(Filename != 0) {
      stmt->lineno = Lineno;
      stmt->colno = Colno;
      stmt->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(stmt->filename, "%s", Filename);
    }
    /* attach to list */
    if(*stmt_list == 0)
      *stmt_list = stmt;
    else {
      Stmt temp;
      temp = *stmt_list;
      while(temp->lex_next != 0) temp = temp->lex_next;
      temp->lex_next = stmt;
      stmt->lex_prev = temp;
    } 
    
  }
}

/*-------------------------------------------------------------------*/
/* Find OP_Var of expression that is modified */
char *FindOPVar(exp)
     Expr exp;
{
  switch(exp->opcode) {
  case OP_var:
    return(exp->value.var_name);
    break;
    /* 1/93 - add case for cast and addr */
  case OP_cast:
  case OP_addr:
  case OP_compexpr:
  case OP_dot:
  case OP_arrow:
  case OP_index:
  case OP_indr:
    
    /* assume first operand is the variable to check, 
     * e.g. A in (A), A.x, A->x, A[i], *A 
     */
    FindOPVar(GetOperand(exp,1));
    break;
    
  default:
    Warning("FindOPVar: Unexpected opcode");
  }
}

/*  Check if an expression modifies a local variable defined outside the
 *  scope of the pstmt.
 *
 *  Have pstmt_scopes and poss_scopes.  If there is a modified expr then
 *  check to see what scope the var is at from poss_scopes and then check
 *  if it is 1) static, otherwise 2) pstmt_scopes.  If it is static then it
 *  is global (but not at scope 0).  pstmt_scopes consists of the global scope 
 *  and scopes within the pstmt.
 *
 *  lval of the following instructions must be checked: 
 *	OP_assign, OP_postinc, OP_preinc, OP_predec, OP_postdec,
 *	OP_Aadd, OP_Asub, OP_Amul, OP_Adiv, OP_Amod, OP_Arshft,
 *	OP_Alshft, OP_Aand, OP_Aor, OP_Axor
 *  have to check the rval of these expressions for possible modifing stmts
 *
 *  An lval can be one of the following: (from C A Reference Manual)
 *	- name
 *	- subscript expression e[k] - regardless of whether e or k are lval
 *	- parenthesized value if contained expr is lval
 *	- direct component selection expression e.name if e is an lval
 *	- an indirect component selection e->name regardless if e is lval
 *	- an indirection expression *e regardless if e is lval
 */
Modified(exp)
     Expr exp;
{
  Expr e;
  VarDcl v;
  char *name;
  switch(exp->opcode) {
  case OP_assign:
  case OP_postinc:
  case OP_postdec:
  case OP_preinc:
  case OP_predec:
  case OP_Aadd:
  case OP_Asub:
  case OP_Amul:
  case OP_Adiv:
  case OP_Amod:
  case OP_Arshft:
  case OP_Alshft:
  case OP_Aand:
  case OP_Aor:
  case OP_Axor:
    /* get lval name */
    name = FindOPVar(GetOperand(exp,1));
    /* check if variable in poss_scopes and static */
    if(! (((v = FindNearScopeVar(possible_scopes,name)) != 0) &&
	  (v->type->type & TY_STATIC))) {
      /* if not, check if variable in pstmt_scopes */
      if(FindNearScopeVar(FindScopeList(pstmt_scopes)->scope, name) == 0) {
	/* if not */
	fprintf(Flog, "=> variable %s\n", name);
	Warning("Incorrect Pstmt (write)");
      }
    }
    break;
  default:
    break;
  }
  /* search through operands for assignment expression */
  /* handle special case comma expression and then remainder */
  switch(exp->opcode) {
  case OP_index:
    {
      Expr op2, op2_temp;
      VarDcl v;
      char *name;
      /* op1 handled by FindOPVar - can't modify directly */
      /* op1 - array shouldn't be read if not local to loop */
      name = FindOPVar(GetOperand(exp,1));
      if(! (((v = FindNearScopeVar(possible_scopes,name)) != 0) &&
	    (v->type->type & TY_STATIC))) {
	if(FindNearScopeVar(FindScopeList(pstmt_scopes)->scope, name) == 0) {
	  /* if not */
	  fprintf(Flog, "=> variable %s\n", name);
	  Warning("Incorrect pstmt (array)");
	}
      }
      /* op2 = index which can have an assignment within */
      op2 = GetOperand(exp, 2);
      Modified(op2);
      op2_temp = op2->next;
      for(; op2_temp!=0; op2_temp = op2_temp->next)
	Modified(op2_temp);
      break;
    }
  case OP_quest:
    {
      Expr op1, op2, op3, op2_temp;
      op1 = GetOperand(exp, 1);
      Modified(op1);
      op2 = GetOperand(exp,2);
      Modified(op2);
      op2_temp = op2->next;
      for(; op2_temp!=0; op2_temp = op2_temp->next)
	Modified(op2_temp);
      op3 = GetOperand(exp, 3);
      Modified(op3);
      break;
    }
  case OP_compexpr:
    {
      Expr op1, op_temp;
      op1 = GetOperand(exp, 1);
      Modified(op1);
      op_temp = op1->next;
      for(; op_temp != 0; op_temp = op_temp->next)
	Modified(op_temp);
      break;
    }
  default:	
    e=exp->operands;
    for(;e!=0; e=e->sibling) 
      Modified(e);
    break;
  }
}

/*-------------------------------------------------------------------*/
/* check pstmts to see that local variables not defined within
 * the pstmts (with same scope or lower scope) are read only scalars.
 * global variables (static, global, extern) can be written.
 *
 * there are 2 types of pstmts, normal and implied in parloop 
 */
CheckPstmts(st)
     Stmt st;
{
  Expr e;
  VarDcl v;
  char *name;
  if(st == 0) return;		/* no stmts to processes */
  if(! parallel_flag) return;   /* only check pstmt if 'p' option specified */

  switch(st->type) {
  case ST_NOOP:
  case ST_CONT:
  case ST_BREAK:
  case ST_GOTO:
  case ST_ADVANCE:
  case ST_AWAIT:
    break;
    
  case ST_RETURN:
    if(in_pstmt)
      for(e=st->stmtstruct.ret; e!=0; e=e->next)
	Modified(e);
    break;
  case ST_EXPR:
    if(in_pstmt)
      for(e=st->stmtstruct.expr; e!=0; e=e->next)
	Modified(e);
    break;
  case ST_IF:
    if(in_pstmt)
      for(e=st->stmtstruct.ifstmt->cond_expr; e!=0; e=e->next)
	Modified(e);
    CheckPstmts(st->stmtstruct.ifstmt->then_block);
    CheckPstmts(st->stmtstruct.ifstmt->else_block);
    break;
  case ST_SWITCH:
    if(in_pstmt)
      for(e=st->stmtstruct.switchstmt->expression; e!=0; e=e->next)
	Modified(e);
    CheckPstmts(st->stmtstruct.switchstmt->switchbody);
    break;
  case ST_PSTMT:
    in_pstmt++;
    AddScopeList(pstmt_scopes);
    CheckPstmts(st->stmtstruct.pstmt->stmt);
    DeleteScopeList(pstmt_scopes);
    in_pstmt--;
    break;
  case ST_MUTEX:
    /* constant expression */
    CheckPstmts(st->stmtstruct.mutex->statement);
    break;
  case ST_COBEGIN:
    CheckPstmts(st->stmtstruct.cobegin->statements);
    break;
  case ST_COMPOUND:
    AddScope(possible_scopes,st->stmtstruct.compound->scope);
    AddScope(FindScopeList(pstmt_scopes)->scope,st->stmtstruct.compound->scope);
    CheckPstmts(st->stmtstruct.compound->stmt_list);
    DeleteScope(possible_scopes);
    DeleteScope(FindScopeList(pstmt_scopes)->scope);
    break;
  case ST_PARLOOP:
    if(in_pstmt) {
      /* check if loop var in poss_scopes and static */
      /* new change for iteration_var reference */
      name = st->stmtstruct.parloop->iteration_var->value.var_name;
      if(!(((v = FindNearScopeVar(possible_scopes, name)) != 0) &&
	   (v->type->type & TY_STATIC))) {
	/* if not check if variable in pstmt_scopes */
	if(FindNearScopeVar(FindScopeList(pstmt_scopes)->scope, 
			    name) == 0) {
	  /* if not */
	  fprintf(Flog, "=> variable %s\n", name);
	  Warning("Incorrect Pstmt (index variable)");
	}
      }
      for(e=st->stmtstruct.parloop->init_value; e!=0; e=e->next)
	Modified(e);
      for(e=st->stmtstruct.parloop->final_value; e!=0; e=e->next)
	Modified(e);
      for(e=st->stmtstruct.parloop->incr_value; e!=0; e=e->next)
	Modified(e);
    }  
    /* implied pstmt */
    in_pstmt++;
    AddScopeList(pstmt_scopes);
    CheckPstmts(st->stmtstruct.parloop->pstmt->stmt);
    DeleteScopeList(pstmt_scopes);
    in_pstmt--;
    break;
  case ST_SERLOOP:
    if(in_pstmt) {
      for(e=st->stmtstruct.serloop->cond_expr; e!=0; e=e->next)
	Modified(e);
      for(e=st->stmtstruct.serloop->init_expr; e!=0; e=e->next)
	Modified(e);
      for(e=st->stmtstruct.serloop->iter_expr; e!=0; e=e->next)
	Modified(e);
    }
    CheckPstmts(st->stmtstruct.serloop->loop_body);
    break;
  case ST_BODY:
    CheckPstmts(st->stmtstruct.bodystmt->statement);
    break;
  case ST_EPILOGUE:
    CheckPstmts(st->stmtstruct.epiloguestmt->statement);
    break;
  default:
    Punt("CheckPstmts: Invalid instruction type");
  }
  if(st->lex_next != 0)
    CheckPstmts(st->lex_next);
}

/*
 * LCW - Search function pragma for profile pragma. Put the profile information
 *       in the function profile structure if found - 1/28/97
 */
static void ExtractFuncProfile()
{
  struct __Pragma *pragma_ptr;
  struct _ProfFN *func_prof;

  for (pragma_ptr = currentFuncDcl->pragma; pragma_ptr != NULL; 
       pragma_ptr = pragma_ptr->next) {
      if (! strcmp(pragma_ptr->specifier, "\"profile\"")) {
	 func_prof = NewProfFN();
	 func_prof->fn_id = num_func;
	 /* BCC - adjust with in_fraction 9/22/97 */
	 pragma_ptr->expr->value.real *= in_fraction;
	 func_prof->count = pragma_ptr->expr->value.real;
	 currentFuncDcl->profile = func_prof;
	 break;
      }
  }
}

/*-------------------------------------------------------------------*/
/* Read in a function definition. */
/* The (ptr) fields of the function symbol table point 
 * to the return DeclSpec of the functions.
 *
 * list = (BEGIN_FN $VarID $Pos?) $DeclSpec ($FunctPrmDecl*) ($Pragma*)
 *        -----------------------
 *	  $CompoundStmt (END_FN $VarID)
 *
 * Note that when print out function there is a compound statement that
 * is ommited in the data structure.
 */
static BeginFunc(list)
     LIST list;
{
  LIST ptr, opcode, argument, parameter;
  char *fn_name, *keyword;
  Symbol sym;
  Stmt st;
  VarDcl v, fwdDcl;       	/* function name is also a global variable */
  int old_scope = scope;	/* BCC - used as a buffer for Pinline */
  FuncDcl callerFuncDcl = currentFuncDcl; /* BCC - another buffer for Pinline */
  /* BCC - added 8/3/96 */
  Dcltr dcltr;
  Type type;
  VarList params;
  Param last, new;

  /* TLJ 2/27/96 - Increment nested defines counter */
  nested_dcls++;

  if (inlining == 0) {
    v = NewVarDcl();
    /* begin function */
    argument = SiblingOf(ChildOf(list));
    if ((argument==0)||(NodeType(argument)!=T_ID)) 
      Punt("BeginFunc: missing fn_name");
/* BCC - use func_name as a global variable for NewNameLabel to rename 12/95 */
    func_name = fn_name = StringOf(argument);		/* function name */
    v->name = fn_name;
    currentFuncDcl = NewFuncDcl();		/* OPEN a new Func scope */
    currentFuncDcl->name = fn_name;
    /* 3/93 - don't assign scopes here - assign them with compound stmt */

    argument = SiblingOf(argument);
    if(argument!=0) {
      if(NodeType(argument) != T_LIST)
        Punt("incorrect position information (7)");
      else {
        argument = ChildOf(argument);
        if((argument==0)||(NodeType(argument)!=T_ID))
          Punt("incorrect position information (8)");
        else if(!strcmp(StringOf(argument),"POS")) {
          Filename = StringOf(SiblingOf(argument));
          Lineno = IntegerOf(SiblingOf(SiblingOf(argument)));
          Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(argument))));
        }
        else Punt("incorrect position information (9)");
      }
    }

    /** add a symbol table entry **/
    if (FindFunction(fn_name)!=0) {
      fprintf(Ferr, "=> function %s\n", fn_name);
      Punt("multiple definition of a function");
    }
    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (1)");
    /* return type */
    /* To be compatible with hcode, we use the symbol table ptr to 
     * refer to the return type.
     */
    AddFunction(fn_name, 0);	/* return type is not yet known */
    sym = FindFunction(fn_name);

#if 0
    sym->ptr = currentFuncDcl->type = DeclSpec(list);
    v->type = currentFuncDcl->type; /* variable type is return type */
#endif

    /* BCC - 8/25/96
     * for garbage colection reasons, make separate copies - 8/25/96 
     */
    currentFuncDcl->type = DeclSpec(list);

    /* add variable to global var scope */
    if(FindEnumField(v->name, 0) != 0)
      Punt("redeclaration of function name");
    /* don't check if function name is redeclaration of variable - because
     * that is how you define a fucntion ahead of time.
     */

    /* LCW - if EDG front-end is used, all the functions will be
     * forward-declared and they will have correct file name and
     * line number information. - 10/18/96
     */
    if (edg_generated && ((fwdDcl=FindVar(v->name, 0)) != NULL)) {
      v->lineno = fwdDcl->lineno;
      v->colno = fwdDcl->colno;
      /* LCW - propagate file name only when it is not NULL - 8/21/97 */
      if (fwdDcl->filename != NULL) {
         v->filename = (char *)malloc(strlen(fwdDcl->filename)+1);
         strcpy(v->filename, fwdDcl->filename);
      }
      else
         v->filename = strdup("\"_no_file_name_\"");
    }
    /* BCC - When inlining, since some header files are skipped and the body
     * of the callee has contained the correct information, we can just go
     * ahead and use it.
     */
    else if(Filename!=0) {
      v->lineno = Lineno;
      v->colno = Colno;
      v->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(v->filename, "%s", Filename);
    }

	/* DMG - changed to ReplaceVar, to avoid duplicate entries in
	   the var symbol table when functions are forward declared */
    ReplaceVar(v->name, v, 0);       /* no new name */
    
    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (2)");
    /* parameter */
    argument = ChildOf(list);
    parameter = argument;
    /* 3/93 - postpone reading paramters until know scope.
      if(argument!=0)			
        ReadParameters(argument);
     */
    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (3)");
    /* function pragma */
    argument = ChildOf(list);	/* argument = $Pragma* */
    if(argument!=0)
      ReadFnPragmas(argument);
  
    /*
     * LCW - Search function pragma for profile pragma. Put the profile 
     * information in the function profile structure if found - 1/28/97
     */
    ExtractFuncProfile();

    /* function body */
    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (4)");
    /* function body = compound statement */
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("illegal 1st level function descriptor (5)");
    keyword = StringOf(opcode);
    argument = SiblingOf(opcode);
    if(strcmp(keyword, "COMPSTMT")) 
      Punt("illegal 1st level function descriptor (6)");
  
    /* create a compound stmt (3/93) */
    if(NodeType(argument) == T_INT) {
      scope = IntegerOf(argument);  /* will also be set by readcompoundstmt - 
				       but need for parameters */
      scope_assigned = 1;
    } else {
      scope = max_scope + 1;        /* will be set by readcompoundstmt - but 
				       need for parameters */
      scope_assigned = 0;
    }
    /* 3/93 - delay reading parameters til know scope */
    if(parameter!=0)			/* argument = $FunctPrmDecl* */
      ReadParameters(parameter);

    /* BCC - add param types to var - 8/3/96 */
    type = currentFuncDcl->type;
    dcltr = type->dcltr;
    assert(dcltr->method == D_FUNC);
    if (dcltr->param == 0) {
      params = currentFuncDcl->param;
      last = NULL;
      while (params) {
          new = NewParam();
          new->type = CopyType(params->var->type);
          if (last) {
              last->next = new;
              last = new;
          }
          else {
              dcltr->param = new;
              last = new;
          }
          params = params->next;
      }
    }

    /* BCC - use the updated types - 8/25/96 */ 
    sym->ptr = CopyType(currentFuncDcl->type);
    v->type = CopyType(currentFuncDcl->type);

    /* LCW -- moved from below to make sure the positin information for
     * functions won't get changed during ReadCompoundStmt(). 7/17/95
     */

    /* LCW - if EDG front-end is used, all the functions will be
     * forward-declared and they will have correct file name and
     * line number information. - 10/18/96
     */
    if (edg_generated && ((fwdDcl=FindVar(currentFuncDcl->name, 0)) != NULL)) {
      currentFuncDcl->lineno = fwdDcl->lineno;
      currentFuncDcl->colno = fwdDcl->colno;
      currentFuncDcl->filename = (char *)malloc(strlen(fwdDcl->filename)+1);
      sprintf(currentFuncDcl->filename, "%s", fwdDcl->filename);
    }
    else if(Filename!=0) {
      currentFuncDcl->lineno = Lineno;
      currentFuncDcl->colno = Colno;
      currentFuncDcl->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(currentFuncDcl->filename, "%s", Filename);
    }

    currentFuncDcl->stmt = NewStmt();
    currentFuncDcl->stmt->type = ST_COMPOUND;
    currentFuncDcl->stmt->stmtstruct.compound = ReadCompoundStmt(argument);
    /* end change (3/93) */

/* LCW -- The following code has been moved up. */
/*
    if(Filename!=0) {
      currentFuncDcl->lineno = Lineno;
      currentFuncDcl->colno = Colno;
      currentFuncDcl->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(currentFuncDcl->filename, "%s", Filename);
    }
*/

    /* function end */
    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (9)");
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("illegal 1st level function descriptor (10)");
    keyword = StringOf(opcode);
    if(strcmp(keyword, "END_FN"))
      Punt("illegal 1st level function descriptor (11)");
    argument = SiblingOf(opcode);
    if((argument==0)||(NodeType(argument)!=T_ID))
      Punt("illegal 1st level function descriptor (12)");
    if(strcmp(fn_name, StringOf(argument)))
      Punt("END_FN: function name doesn't match current function");
    
    /* link together basic blocks  and check pstmts */
    LinkStmts(currentFuncDcl);
    LinkLoops(currentFuncDcl);
#if 0
    possible_scopes = InitScopes();
    /* 4/92  - replace scope2 with 1 */
    AddScope(possible_scopes, 1);
#endif

/*=============================================================================\
 *  BCC - there two flags related to Pinline : 			- 11/15/95 
 *	  1) do_inline : scan the current function to find possibly inlinable
 *			 callees.
 *	  2) inlining :  doing inlining right now. Skip some error checking 
 *			 functionality for regular functions.
 *	  Don't do nested inlining in one step	
\*============================================================================*/
    if (do_inline == 0) {	/* BCC - make Pinline as simple as possible */
      pstmt_scopes = InitScopeList(); /* always have a dummy list */
      if(parallel_flag)
        CheckPstmts(currentFuncDcl->stmt);

      if (nested_dcls == 1)
      {
        /* TLJ 2/25/96 - Set input type to tell how to process */
        P_Input_Type = P_INPUT_FUNC;
        P_Func = currentFuncDcl;
      }
      else
      {
        /* TLJ 2/25/96 - note that there are nested dcls */
        dcl_has_nested_dcls = TRUE;
        P_DclList = AddDcl2List(P_DclList,currentFuncDcl,TT_FUNC);
      }

      /* BCC - execute the following code when do_inline == 0 - 3/13/96 */ 
      /* TLJ 4/28/96 - Process later */
#if 0
      /* process the currentFuncDcl (see process.c) */
      ProcessFuncDcl(currentFuncDcl);	
#endif
  
      /* dispose the memory space taken by it.
       * It is IMPORTANT that currentFuncDcl is set to 0.
       * So the local definitions will no longer be visible
       * to future expressions (see cast.c: E_var part).
       */
      /* TLJ 2/25/96 - Remove later since we process the decl later */
#if 0
      RemoveFuncDcl(currentFuncDcl);
      RemoveScopeListChain(pstmt_scopes);
      currentFuncDcl = 0;
      scope = 0;
#endif
      /* BCC - End of Change - 3/13/96 */
    }
    else {
      /* 
       * BCC - 3/13/96 
       * For Pinline, we want to reduce the number of disk accesses. So
       * we postpone the write back of the processed file until necessary 
       */

      (*ExpandCalleeFunction)(currentFuncDcl);
      Scale_Func_Weight(currentFuncDcl, out_fraction);
    }
  }
  else { 	/* doing inlining */
    /* begin function */
    argument = SiblingOf(ChildOf(list));
    if ((argument==0)||(NodeType(argument)!=T_ID)) 
      Punt("BeginFunc: missing fn_name");
/* BCC - use func_name as a global variable for NewNameLabel to rename 12/95 */
    func_name = fn_name = StringOf(argument);		/* function name */
    currentFuncDcl = NewFuncDcl();		/* OPEN a new Func scope */
    currentFuncDcl->name = fn_name;
    /* 3/93 - don't assign scopes here - assign them with compound stmt */

    argument = SiblingOf(argument);
    if(argument!=0) {
      if(NodeType(argument) != T_LIST)
        Punt("incorrect position information (7)");
      else {
        argument = ChildOf(argument);
        if((argument==0)||(NodeType(argument)!=T_ID))
          Punt("incorrect position information (8)");
        else if(!strcmp(StringOf(argument),"POS")) {
          Filename = StringOf(SiblingOf(argument));
          Lineno = IntegerOf(SiblingOf(SiblingOf(argument)));
          Colno = IntegerOf(SiblingOf(SiblingOf(SiblingOf(argument))));
        }
        else Punt("incorrect position information (9)");
      }
    }

    /* BCC - since a function could be inlined many times, skip the duplication
       test for a inlined function - 11/12/95 */

    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (1)");

    /* BCC - since it's doing inlining, don't insert the currently being 
	     processed function to the symbol table */
    currentFuncDcl->type = DeclSpec(list);

    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (2)");

    /* parameter */
    argument = ChildOf(list);
    parameter = argument;

    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (3)");

    /* function pragma */
    argument = ChildOf(list);	/* argument = $Pragma* */
    if(argument!=0)
      ReadFnPragmas(argument);
  
    /*
     * LCW - Search function pragma for profile pragma. Put the profile 
     * information in the function profile structure if found - 1/28/97
     */
    ExtractFuncProfile();

    /* function body */
    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (4)");

    /* function body = compound statement */
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("illegal 1st level function descriptor (5)");

    keyword = StringOf(opcode);
    argument = SiblingOf(opcode);
    if(strcmp(keyword, "COMPSTMT")) 
      Punt("illegal 1st level function descriptor (6)");
  
    /* create a compound stmt (3/93) */
    /* BCC - always use a new scope for inlined function */
    scope = max_scope + 1;	/* will be set by readcompoundstmt - but 
				   need for parameters */
    scope_assigned = 0;
    /* 3/93 - delay reading parameters til know scope */
    if(parameter!=0)			/* argument = $FunctPrmDecl* */
      ReadParameters(parameter);

    /* BCC - add param types to durrentFuncType->type - 8/3/96 */
    type = currentFuncDcl->type;
    dcltr = type->dcltr;
    assert(dcltr->method == D_FUNC);
    if (dcltr->param == 0) {
      params = currentFuncDcl->param;
      last = NULL;
      while (params) {
          new = NewParam();
          new->type = CopyType(params->var->type);
          if (last) {
              last->next = new;
              last = new;
          }
          else {
              dcltr->param = new;
              last = new;
          }
          params = params->next;
      }
    }

    currentFuncDcl->stmt = NewStmt();
    currentFuncDcl->stmt->type = ST_COMPOUND;
    currentFuncDcl->stmt->stmtstruct.compound = ReadCompoundStmt(argument);
    /* end change (3/93) */

    if(Filename!=0) {
      currentFuncDcl->lineno = Lineno;
      currentFuncDcl->colno = Colno;
      currentFuncDcl->filename = (char *)malloc(strlen(Filename)+1);
      sprintf(currentFuncDcl->filename, "%s", Filename);
    }

    /* function end */
    list = SiblingOf(list);
    if((list==0)||(NodeType(list)!=T_LIST))
      Punt("illegal 1st level function descriptor (9)");
    opcode = ChildOf(list);
    if((opcode==0)||(NodeType(opcode)!=T_ID))
      Punt("illegal 1st level function descriptor (10)");
    keyword = StringOf(opcode);
    if(strcmp(keyword, "END_FN"))
      Punt("illegal 1st level function descriptor (11)");
    argument = SiblingOf(opcode);
    if((argument==0)||(NodeType(argument)!=T_ID))
      Punt("illegal 1st level function descriptor (12)");
    if(strcmp(fn_name, StringOf(argument)))
      Punt("END_FN: function name doesn't match current function");
    
    /* link together basic blocks  and check pstmts */
    LinkStmts(currentFuncDcl);
    LinkLoops(currentFuncDcl);

    /* suppost now BeginFunc is called via Pinline to process the callee, it 
       will first save currentFuncDcl to callerFuncDcl, then borrow current...
       to process the callee, then move it to calleeFuncDcl and restore 
       currentFuncDcl from callerFuncDcl */
    scope = old_scope;
    calleeFuncDcl = currentFuncDcl;
    currentFuncDcl = callerFuncDcl;
  }
  /* BCC - clear the label rename table 12/11/95 */
  /* BCC - clear the label rename table and free name fields 8/20/96 */
  C_clear_free_all(label_mapping_table);
}
/*-------------------------------------------------------------------*/
/*
 * Process a list. If it is a header for several subsequent
 * lists, read and process those lists.
 */

/*
 * At top level, only struct defs, enum defs, union defs, global var defs,
 * functions.  Pragmas are already part of pcode.
 *
 * Since a function is a list (has a left and right paren) GetNode() will
 * get the entire function.  This may be changed later (by removing the
 * left and right paren's) if there is a memory problem with reading in the
 * entire function.  However, don't gain much because compoundstmt is also
 * a list.
 */

void ProcessList(list)
     LIST list;
{
  LIST opcode, argument;
  char *keyword;
  /* BCC - ProcessList could be reentered, so we need a buffer - 11/21/95 */
  /* TLJ 2/26/96 - now take care of this in the Setup and PostProcess
   * IncludeFile routines since no recursive calls to ProcessList.
   */
  /*Scope scope_buffer = possible_scopes;*/

  /* TLJ 2/25/96 - Set input type to NULL in case it doesn't get set later */
  P_Input_Type = P_INPUT_NULL;
  dcl_has_nested_dcls = FALSE;
  P_DclList = NULL;
  nested_dcls = 0;

  /* initialize symbol tables */
  if (! pcode_init) {
    SetUpSymbolTables();

  }
  /* BCC - 8/16/96 
   * Now the previous ProcessList() has really finished, we can free the
   * previous possible_scopes list
   */
  if (possible_scopes)
    RemoveScopeChain(possible_scopes);
  /* initialize possible scopes */
  possible_scopes = InitScopes();
  if (list==0) Punt("unexpected )");
  if (NodeType(list)==T_LIST) {
    opcode = ChildOf(list);
    if (NodeType(opcode)==T_ID) {
      keyword = StringOf(opcode);
      argument = SiblingOf(opcode);
      if (! strcmp(keyword, "DEF")) {
	TypeDefinition(argument, 0);
      } else
	if (! strcmp(keyword, "GVAR")) {
	  DefineGvar(argument);		/* scope == 0 */
	} else
	  /* BCC - added here to handle INCLUDE directive - 5/26/95 */
	  if (! strcmp(keyword, "INCLUDE")) {
	    if ( (argument == 0) || (NodeType(argument) != T_STRING) )
	      Punt("incorrect include format (1)");
	    /* BCC - 8/25/96
	     * there is no need to include the header files again for the
	     * callee function since they are the same as those of the caller
	     * and all the decalrations are still in the symbol table
	     */
	    if (inlining == 0) {
	      /* TLJ 2/25/96 - Set input type to tell how to process */
	      P_Input_Type = P_INPUT_INCLUDE;
              if (NodeType(argument) != T_STRING)
                Punt("illegal (INCLUDE) statement");
	      P_Include = StringOf(argument);
	    }
	    else 
	      P_Input_Type = P_INPUT_NULL;
	  } else {
	    Punt("illegal first level opcode");
	  }
    } else {
      list = ChildOf(list);		/* (BEGIN_FN $VarID $Pos?) */
      if(NodeType(list)==T_LIST) {
	opcode = ChildOf(list);
	if(NodeType(opcode) == T_ID) {
	  keyword = StringOf(opcode);
	  argument = SiblingOf(opcode);
	  if (! strcmp(keyword, "BEGIN_FN")) {
	    BeginFunc(list);
	  } else {
	    Punt("illegal first level opcode");
	  } 
	} else {
	  Punt("illegal first level");
	}
      } else {
	Punt("illegal first level list");
      }
    }
  } else {
    Punt("illegal first level list");
  }

  /* BCC - free current scopes and restore old - 11/21/95 */
  /* TLJ 2/25/96 - Remove later since we process the decl later */
  /*RemoveScopeChain(possible_scopes);
  possible_scopes = scope_buffer;*/
  /* BCC - end of modification - 11/21/95 */

  Clear();	/* prevent use after delete */
}
/*===================================================================*/
/*
 * Set up all symbol tables. Insert default names into the
 * symbol tables.
 */
static SetUpSymbolTables() {
  int tid;
  Symbol sym;
  if (pcode_init) return;
  pcode_init = 1;

  /*
   *  use symbol trees for var, struct, union which have scope 
   *  information.  modified from impcc/Csemantic/symbol.c
   *  the root of the trees need to be initialized to zero.
   */
  InitSymbolTree();	
  
  /** create symbol tables **/
  /*
   *  create hash symbol tables for string, func, and opcode since these
   *  don't depend on the scope and are more efficient. - straight from
   *  library.
   */
  SymbolTable[TBT_FUNC] = NewSymTbl(MAX_FUNC_TBL_SIZE);
  SymbolTable[TBT_OPCODE] = NewSymTbl(MAX_OPCODE_TBL_SIZE);
  SymbolTable[TBT_TYPEDEF] = NewSymTbl(MAX_TYPEDEF_TBL_SIZE);
  
  /** insert default values **/
  tid = SymbolTable[TBT_OPCODE];
  sym = AddSym(tid, "VAR", 0); sym->value = OP_var;
  sym = AddSym(tid, "INT", 0); sym->value = OP_int;
  /* BCC - treat REAL as of type double - 8/3/96 
  sym = AddSym(tid, "REAL", 0); sym->value = OP_real;
  */
  sym = AddSym(tid, "REAL", 0); sym->value = OP_double;	  /* BCC - 8/6/96 */
  sym = AddSym(tid, "FLOAT", 0); sym->value = OP_float;	  /* BCC - 8/3/96 */
  sym = AddSym(tid, "DOUBLE", 0); sym->value = OP_double; /* BCC - 8/3/96 */
  sym = AddSym(tid, "CHAR", 0); sym->value = OP_char;
  sym = AddSym(tid, "STRING", 0); sym->value = OP_string;
  sym = AddSym(tid, "DOT", 0); sym->value = OP_dot;
  sym = AddSym(tid, "ARROW", 0); sym->value = OP_arrow;
  sym = AddSym(tid, "CAST", 0); sym->value = OP_cast;
  sym = AddSym(tid, "EXPRSIZE", 0); sym->value = OP_expr_size;
  sym = AddSym(tid, "TYPESIZE", 0); sym->value = OP_type_size;
  sym = AddSym(tid, "QUEST", 0); sym->value = OP_quest;
  sym = AddSym(tid, "DISJ", 0); sym->value = OP_disj;
  sym = AddSym(tid, "CONJ", 0); sym->value = OP_conj;
  sym = AddSym(tid, "COMPEXPR", 0); sym->value = OP_compexpr; 
  sym = AddSym(tid, "ASSIGN", 0); sym->value = OP_assign;
  sym = AddSym(tid, "OR", 0); sym->value = OP_or;
  sym = AddSym(tid, "XOR", 0); sym->value = OP_xor;
  sym = AddSym(tid, "AND", 0); sym->value = OP_and;
  sym = AddSym(tid, "EQ", 0); sym->value = OP_eq;
  sym = AddSym(tid, "NE", 0); sym->value = OP_ne;
  sym = AddSym(tid, "LT", 0); sym->value = OP_lt;
  sym = AddSym(tid, "LE", 0); sym->value = OP_le;
  sym = AddSym(tid, "GE", 0); sym->value = OP_ge;
  sym = AddSym(tid, "GT", 0); sym->value = OP_gt;
  sym = AddSym(tid, "RSHFT", 0); sym->value = OP_rshft;
  sym = AddSym(tid, "LSHFT", 0); sym->value = OP_lshft;
  sym = AddSym(tid, "ADD", 0); sym->value = OP_add;
  sym = AddSym(tid, "SUB", 0); sym->value = OP_sub;
  sym = AddSym(tid, "MUL", 0); sym->value = OP_mul;
  sym = AddSym(tid, "DIV", 0); sym->value = OP_div;
  sym = AddSym(tid, "MOD", 0); sym->value = OP_mod;
  sym = AddSym(tid, "NEG", 0); sym->value = OP_neg;
  sym = AddSym(tid, "NOT", 0); sym->value = OP_not;
  sym = AddSym(tid, "INV", 0); sym->value = OP_inv;
  sym = AddSym(tid, "PREINC", 0); sym->value = OP_preinc;
  sym = AddSym(tid, "PREDEC", 0); sym->value = OP_predec;
  sym = AddSym(tid, "POSTINC", 0); sym->value = OP_postinc;
  sym = AddSym(tid, "POSTDEC", 0); sym->value = OP_postdec;
  sym = AddSym(tid, "A_ADD", 0); sym->value = OP_Aadd;
  sym = AddSym(tid, "A_SUB", 0); sym->value = OP_Asub;
  sym = AddSym(tid, "A_MUL", 0); sym->value = OP_Amul;
  sym = AddSym(tid, "A_DIV", 0); sym->value = OP_Adiv;
  sym = AddSym(tid, "A_MOD", 0); sym->value = OP_Amod;
  sym = AddSym(tid, "A_RSHFT", 0); sym->value = OP_Arshft;
  sym = AddSym(tid, "A_LSHFT", 0); sym->value = OP_Alshft;
  sym = AddSym(tid, "A_AND", 0); sym->value = OP_Aand;
  sym = AddSym(tid, "A_OR", 0); sym->value = OP_Aor;
  sym = AddSym(tid, "A_XOR", 0); sym->value = OP_Axor;
  sym = AddSym(tid, "INDR", 0); sym->value = OP_indr;
  sym = AddSym(tid, "ADDR", 0); sym->value = OP_addr;
  sym = AddSym(tid, "INDEX", 0); sym->value = OP_index;
  sym = AddSym(tid, "CALL", 0); sym->value = OP_call;
  /* Don't know what error is used for */
  sym = AddSym(tid, "ERROR", 0); sym->value = OP_error;

  /* BCC - setup a label mapping table for Pinline - 12/11/95 */
  label_mapping_table = C_open_name_table(MAX_LABELS);
}
/*===================================================================*/
/*
 *	This function is not used by CCODE.
 *	Some external modules may require reading multiple
 *	ccode files in one pass. This function allows
 *	the user to completely destroy the image created
 *	by reading the previous ccode file.
 */
void ClearSymbolTable() {
  if (! pcode_init) return;
  /* 	++++
   *	The space allocated for VarDcl, StructDcl, and UnionDcl 
   *	definitions are not recycled in this version. 
   *	If this turns out to cause problem, some garbage
   *	collection should be done before calling CleanSymTbl()
   */
  /* 
   *	Clear symbol tables. (may need function to clear symbol trees)
   *	Except opcode and string table.
   */
  ClearSymTbl(SymbolTable[TBT_FUNC]);
}

/* BCC - added to handle included files */
/*===================================================================*/
/*
 *      1) remove " " from the file name.
 *      2) try to open the file.
 */
void ReadIncludeFile(char *file)
{
	char name[512];
	int flag;
	int mode;	/* BCC - insert path or not - 6/10/96 */

	flag = RemoveDQ(file, name, 512);
	if (flag<=0) Punt("illegal (INCLUDE) file name");
	/* 
	 * BCC - functypy.pch is always put in the directory where Pcode is
	 *	 invoked - 6/10/96
	 */
	mode = (strcmp(name, "functype.pch") && strcmp(name, "../functype.pch")
		&& strcmp(name, "../../functype.pch")) ? 1 : 0;
	flag = (lexOpen(name, mode) == 0);
	if (flag) Punt("cannot open include file");
#if 0
	for (;;) {
	    LIST node;
	    node = GetNode();
	    if (node == 0) break;
	    if (NodeType(node) == T_EOF) break;
	    ProcessList(node);
	    node = DisposeNode(node);
	}
#endif
	while (P_get_input() != P_INPUT_EOF) {
	    process_input();
	}
	lexClose(file);
}

/* TLJ 2/25/96 */
void SetupIncludeFile(char *file)
{
	char name[512];
	int flag;
	static int extern_count=0, struct_count=0;

	if (strstr(file, "struct")) {
	    struct_count++;
	    if (struct_count > 1)
		return;
	}
	if (strstr(file, "extern")) {
	    extern_count++;
	    if (edg_generated == 1 && extern_count > 1)
		return;
	}

	flag = RemoveDQ(file, name, 512);
	if (flag<=0) Punt("illegal (INCLUDE) file name");
	flag = (lexOpen(name, include_mode) == 0);
	if (flag) Punt("cannot open include file");
  	scope_buffer[include_nesting] = possible_scopes;
	/* BCC - set it to zero or it will be free in ProcessList() - 8/23/96 */
	possible_scopes = 0;
	include_files[include_nesting++] = strdup(file);
}

/* TLJ 2/25/96 */
void PostProcessIncludeFile()
{
	/* LCW - check if there is any include file - 5/17/96 */
	/* BCC - should check include_nesting-1 - 6/10/96 */
	if (include_files[include_nesting-1] == NULL) return;
	file = include_files[--include_nesting];
	/* BCC - garbage collection - 8/24/96 */
	RemoveScopeChain(possible_scopes);
  	possible_scopes = scope_buffer[include_nesting];
	lexClose(file);
	free(file);
}

/* TLJ 2/26/96 - This function will remove the FuncDcl as well as
 * other associated cleanup after processing a FuncDcl.
 */
void P_delete_func()
{
    RemoveFuncDcl(currentFuncDcl);
    if (do_inline == 0) RemoveScopeListChain(pstmt_scopes);
    currentFuncDcl = 0;
    scope = 0;
    RemoveScopeChain(possible_scopes);
    /* BCC - 8/16/96 */
    possible_scopes = 0;
}

/* BCC - garbage collection - 8/17/96 */
GarbageCollection()
{
    if (pcode_init == 0) return;
    ResetSymbolTables();
    ClearFreeSymTbl(TBT_TYPEDEF, (void (*)())RemoveTypeDcl);
    ClearFreeSymTbl(TBT_FUNC, (void (*)())RemoveType);
    RemoveAllString();		/* in library/list */
    Filename = 0;
#if 0
    /* BCC - this is doing too much - 8/30/96 */
    C_RemoveAllString();	/* in library/libc */
#endif
}

