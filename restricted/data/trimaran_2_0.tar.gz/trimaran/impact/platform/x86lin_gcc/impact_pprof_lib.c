/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.01  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Mar. 15, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * Copyright 1999 IMPACT Technologies, Inc; Champaign, Illinois
 * For commercial license rights, contact: Marketing Office via
 * electronic mail: marketing@impactinc.com
 *
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*==================================================================
 *  File          : impact_pprof_lib.c
 *  Description   : Support for Pcode profiling
 * 
 *  Created by John C. Gyllenhaal, Le-chun Wu, Wen-mei Hwu 4/99
 * 
 * The following command was used to generate impact_pprof_lib.o: 
 *   gcc -c -O -I${IMPACT_REL_PATH}/include impact_pprof_lib.c
*==================================================================*/
#include <stdio.h>

/* 
 * Specialized, trimmed down, and renamed version of 
 * impact/src/library/dynamic_symbol/int_symbol.[ch] for use by
 * the Pcode loop iteration profiler. -JCG 4/99
 *
 * Note: Converted all L_alloc calls back to mallocs.  Changed
 *       all punts into fprintf()s and exit()s.  Did not convert
 *       delete routines since data needed until program finishes
 *       (so no need to free).
 */

/*
 * ITER symbol table structures and prototypes
 */
typedef struct ITER_Symbol
{
    int                         iter;           /* Loop iterations */
    int                         weight;         /* Profile weight */
    struct ITER_Symbol_Table    *table;         /* For deletion of symbol */
    struct ITER_Symbol          *next_hash;     /* For table's hash table */
    struct ITER_Symbol          *prev_hash;
    struct ITER_Symbol          *next_symbol;   /* For table's contents list */
    struct ITER_Symbol          *prev_symbol;

} ITER_Symbol;

typedef struct ITER_Symbol_Table
{
    ITER_Symbol         **hash;         /* Array of size hash_size */
    int                 hash_size;      /* Must be power of 2 */
    int                 hash_mask;      /* AND mask, (hash_size - 1) */
    int                 resize_size;    /* When reached, resize hash table */
    ITER_Symbol         *head_symbol;   /* Contents list */
    ITER_Symbol         *tail_symbol;
    int                 symbol_count;
} ITER_Symbol_Table;

/* Create and initialize ITER_Symbol_Table.
 * Creates a hash table of initial size 2 * expected_size rounded up
 * to the closest power of two.  (Min hash size 32)
 */
static ITER_Symbol_Table *ITER_new_symbol_table ()
{
    ITER_Symbol_Table *table;
    ITER_Symbol **hash;
    unsigned int min_size, hash_size;
    int i;

    /* Start with the minumum hash size of 32.  
     * (Smaller sizes don't work as well with the hashing algorithm)
     */
    hash_size = 32;

    /* Allocate symbol table */
    table = (ITER_Symbol_Table *) malloc (sizeof(ITER_Symbol_Table));
    if (table == NULL)
    {
	fprintf (stderr, "ITER_new_symbol_table: Out of memory");
	exit (1);
    }

    /* Allocate array for hash */
    hash = (ITER_Symbol **) malloc (hash_size * sizeof(ITER_Symbol *));
    if (hash == NULL)
    {
	fprintf (stderr, "ITER_new_symbol_table: Out of memory");
	exit (1);
    }

    /* Initialize hash table */
    for (i=0; i < hash_size; i++)
        hash[i] = NULL;

    /* Initialize fields */
    table->hash = hash;
    table->hash_size = hash_size;
    table->hash_mask = hash_size -1; /* AND mask, works only for power of 2 */
    /* Resize when count at 75% of hash_size */
    table->resize_size = hash_size - (hash_size >> 2);
    table->head_symbol = NULL;
    table->tail_symbol = NULL;
    table->symbol_count = 0;

    return (table);
}

/* Doubles the symbol table hash array size */
static void ITER_resize_symbol_table (ITER_Symbol_Table *table)
{
    ITER_Symbol **new_hash, *symbol, *hash_head;
    int new_hash_size;
    unsigned int new_hash_mask, new_hash_index;
    int i;

    /* Double the size of the hash array */
    new_hash_size = table->hash_size * 2;

    /* Allocate new hash array */
    new_hash = (ITER_Symbol **) malloc (new_hash_size * 
					sizeof (ITER_Symbol *));
    if (new_hash == NULL)
    {
	fprintf (stderr, "ITER_resize_symbol_table: Out of memory");
	exit (1);
    }

    /* Initialize new hash table */
    for (i=0; i < new_hash_size; i++)
	new_hash[i] = NULL;

    /* Get the hash mask for the new hash table */
    new_hash_mask = new_hash_size -1; /* AND mask, works only for power of 2 */
    
    /* Go though all the symbol and add to new hash table.
     * Can totally disreguard old hash links.
     */
    for (symbol = table->head_symbol; symbol != NULL; 
	 symbol = symbol->next_symbol)
    {
	/* Get index into hash table to use for this name */
	new_hash_index = symbol->iter & new_hash_mask;
	
	/* Add symbol to head of linked list */
	hash_head = new_hash[new_hash_index];
	symbol->next_hash = hash_head;
	symbol->prev_hash = NULL;
	if (hash_head != NULL)
	    hash_head->prev_hash = symbol;
	new_hash[new_hash_index] = symbol;
    }

    /* Free old hash table */
    free (table->hash);
   
    /* Initialize table fields for new hash table */
    table->hash = new_hash;
    table->hash_size = new_hash_size;
    table->hash_mask = new_hash_mask;
    /* Resize when count at 75% of new_hash_size */
    table->resize_size = new_hash_size - (new_hash_size >> 2); 
}

/* Adds structure to symbol table, data is not copied!!! 
 * Dynamically increases symbol table's hash array.
 * Returns pointer to added symbol.
 */
static ITER_Symbol *ITER_add_symbol (ITER_Symbol_Table *table, int iter, 
				     int weight)
{
    ITER_Symbol *symbol, *hash_head, *check_symbol, *tail_symbol;
    unsigned int hash_index;
    int symbol_count;

    /* Increase symbol table size if necessary before adding new symbol.  
     * This will change the hash_mask if the table is resized!
     */
    symbol_count = table->symbol_count;
    if (symbol_count >= table->resize_size)
    {
	ITER_resize_symbol_table (table);
    }

    /* Allocate a symbol (pool initialized in create table routine)*/
    symbol = (ITER_Symbol *) malloc (sizeof(ITER_Symbol));
    if (symbol == NULL)
    {
	fprintf (stderr, "ITER_add_symbol: Out of memory");
	exit (1);
    }
    
    /* Initialize fields */
    symbol->iter = iter;
    symbol->weight = weight;
    symbol->table = table;

    /* Get tail symbol for ease of use */
    tail_symbol = table->tail_symbol;

    /* Add to linked list of symbols */
    symbol->next_symbol = NULL;
    symbol->prev_symbol = tail_symbol;

    if (tail_symbol == NULL)
	table->head_symbol = symbol;
    else
	tail_symbol->next_symbol = symbol;
    table->tail_symbol = symbol;

    /* Get index into hash table to use for this iter */
    hash_index = iter & table->hash_mask;
    
    /* Get head symbol in current linked list for ease of use */
    hash_head = table->hash[hash_index];

    
    /* Sanity check (may want to ifdef out later).
     *
     * Check that this symbol's name is not already in the symbol table.
     * Punt if it is, since can cause a major debugging nightmare.
     */
    for (check_symbol = hash_head; check_symbol != NULL;
	 check_symbol = check_symbol->next_hash)
    {
	/* If iter the same, punt */
	if (check_symbol->iter == iter)
	{
	    fprintf (stderr, 
		     "ITER_add_symbol: cannot add '%i', already in table!",
		     iter);
	    exit (1);
	}
    }
    
    /* Add symbol to head of linked list */
    symbol->next_hash = hash_head;
    symbol->prev_hash = NULL;
    if (hash_head != NULL)
	hash_head->prev_hash = symbol;
    table->hash[hash_index] = symbol;

    /* Update table's symbol count */
    table->symbol_count = symbol_count + 1;

    /* Return symbol added */
    return (symbol);
}

/* Returns a ITER_Symbol structure with the desired value, or NULL
 * if the iter is not in the symbol table.
 */
static ITER_Symbol *ITER_find_symbol (ITER_Symbol_Table *table, int iter)
{
    ITER_Symbol *symbol;
    unsigned int hash_index;

    /* Get the index into the hash table */
    hash_index = iter & table->hash_mask;

    /* Search the linked list for matching name */
    for (symbol = table->hash[hash_index]; symbol != NULL; 
	 symbol = symbol->next_hash)
    {
	/* Compare iters to find match */
	if (symbol->iter == iter)
	{
	    return (symbol);
	}
    }
    return (NULL);
}

static int _PP_probe_count = 0;
static long int *_PP_probe_array = NULL;

/* Called at beging of program execution to specify the location and
 * size of the probe array.
 */
void _PP_dump_probe_init (long int *probe_array, int probe_count)
{
    _PP_probe_array = probe_array;
    _PP_probe_count = probe_count;
}

/* Called at end of program execution to write control flow profile infomation
 * to a file. 
 */
void _PP_dump_probe_array()
{
   FILE *Fprofile;
   int i;
   char file_name[256];

   /* Use PID to create profile dat file name */
   sprintf(file_name, "profile_dat.%d", getpid());
   if ((Fprofile = fopen(file_name, "w")) == NULL)
   {
       fprintf(stderr, "Error, cannot open profile output file: %s\n",
	       file_name);
       exit(-1);
   }

   /* Dump out entire probe array */
   for (i = 0; i < _PP_probe_count; i++)
   {
       fprintf(Fprofile, "\t%f\n", (double)_PP_probe_array[i]);
   }

   /* Close file */
   fclose(Fprofile);
}

/* Loop iteration profiling support for Pcode profiling -JCG 4/99 */
static int _PP_loop_count = 0;  
static ITER_Symbol_Table **_PP_loop_iter_table = NULL;

/* Called at beginning of program to indicate number of loops in program.
 * Creates appropritate data structures for tracking loop iteration
 * profiling data 
 */
void _PP_dump_loop_iter_init(int loop_no)
{
    int table_size;
    int i;

    /* Record the number of loops in the program */
    _PP_loop_count = loop_no;

    /* Allocate loop iteration table */
    table_size = loop_no * sizeof (ITER_Symbol_Table *);
    _PP_loop_iter_table = (ITER_Symbol_Table **) malloc (table_size);
    if (_PP_loop_iter_table == NULL)
    {
	fprintf (stderr, "_PP_dump_loop_iter_init: Out of memory (size %i)\n",
		 table_size);
	exit (1);
    }

    /* Initialize all the pointers to NULL */
    for (i=0; i < loop_no; i++)
	_PP_loop_iter_table[i] = NULL;
}

/* Called at all potential loop exit points.  If 'iter' is 0, the loop
 * didn't actually iterate and the call should be ignored.
 */
void _PP_loop_iter_update(int loop_id, int iter)
{
    ITER_Symbol_Table *table;
    ITER_Symbol *iter_symbol;

    /* If iter == 0, ignore this call (loop didn't iterate) */
    if (iter == 0)
	return;

    /* Sanity check */
    if (loop_id >= _PP_loop_count)
    {
	fprintf (stderr, "_PP_loop_iter_update: loop %i out of bounds (%i)!\n",
		 loop_id, _PP_loop_count);
	abort();
    }

    /* Get loop iteration table */
    table = _PP_loop_iter_table[loop_id];

    /* If doesn't exist, create */
    if (table == NULL)
    {
	table = ITER_new_symbol_table();
	_PP_loop_iter_table[loop_id] = table;
    }

    /* Find symbol for this iteration count */
    iter_symbol = ITER_find_symbol (table, iter);

    /* If doesn't exist, create with weight 0 */
    if (iter_symbol == NULL)
    {
	iter_symbol = ITER_add_symbol (table, iter, 0);
    }

    /* Update weight */
    iter_symbol->weight++; 
}

/* Called at end of program execution.  Write out loop iteration profile
 * information in single profile run form.  Uses process id to create
 * output file name.
 */
void _PP_dump_loop_iter_table()
{
    FILE *Fiter;
    char file_name[256];
    ITER_Symbol_Table *table;
    ITER_Symbol *iter_symbol;
    int loop_id, num_iters;
    
    /* Use PID to create profile iter file name */
    sprintf(file_name, "profile_iter.%d", getpid());
    if ((Fiter = fopen(file_name, "w")) == NULL)
    {
	fprintf(stderr, "Error, cannot open profile output file: %s\n",
		file_name);
	exit(-1);
    }

    /* Print out the number of loops and number of inputs profiled (always 1)
     */
    fprintf (Fiter, "%i %i\n", _PP_loop_count, 1);

    /* Go through each loop and print out iterations for each */
    for (loop_id=0; loop_id < _PP_loop_count; loop_id++)
    {
	/* Get iter table for this loop id */
	table = _PP_loop_iter_table[loop_id];

	/* Print out if exists */
	if (table != NULL)
	{
	    /* Print out loop id and number of entries for this loop */
	    fprintf (Fiter, "\n%i %i\n", loop_id, table->symbol_count);

	    for (iter_symbol = table->head_symbol; iter_symbol != NULL;
		 iter_symbol = iter_symbol->next_symbol)
	    {
		fprintf (Fiter, "  %i %i\n", iter_symbol->iter,
			 iter_symbol->weight);
	    }
	}

	/* Otherwise, print out loop id and no entries for this loop */
	else
	{
	    fprintf (Fiter, "\n%i %i\n", loop_id, 0);
	}
    }

    /* Close the iter profile file */
    fclose (Fiter);
}







