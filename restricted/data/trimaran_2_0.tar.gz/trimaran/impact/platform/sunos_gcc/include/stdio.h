#ifndef _PARAMS
#if defined(__STDC__) || defined(__cplusplus)
#define _PARAMS(ARGS) ARGS
#else
#define _PARAMS(ARGS) ()
#endif
#endif /* _PARAMS */
#define __need___va_list
#include <stdarg.h>
/*	@(#)stdio.h 1.16 89/12/29 SMI; from UCB 1.4 06/30/83	*/

# ifndef FILE
#define	BUFSIZ	1024
#define _SBFSIZ	8
extern	struct	_iobuf {
	int	_cnt;
	unsigned char *_ptr;
	unsigned char *_base;
	int	_bufsiz;
	short	_flag;
	char	_file;		/* should be short */
} _iob[];

#define _IOFBF	0
#define	_IOREAD	01
#define	_IOWRT	02
#define	_IONBF	04
#define	_IOMYBUF	010
#define	_IOEOF	020
#define	_IOERR	040
#define	_IOSTRG	0100
#define	_IOLBF	0200
#define	_IORW	0400
#undef NULL
#define	NULL	0
#define	FILE	struct _iobuf
#define	EOF	(-1)

#define	stdin	(&_iob[0])
#define	stdout	(&_iob[1])
#define	stderr	(&_iob[2])

#ifdef lint	/* so that lint likes (void)putc(a,b) */
extern int putc();
extern int getc();
#else
#define	getc(p)		(--(p)->_cnt>=0? ((int)*(p)->_ptr++):_filbuf(p))
#define putc(x, p)	(--(p)->_cnt >= 0 ?\
	(int)(*(p)->_ptr++ = (unsigned char)(x)) :\
	(((p)->_flag & _IOLBF) && -(p)->_cnt < (p)->_bufsiz ?\
		((*(p)->_ptr = (unsigned char)(x)) != '\n' ?\
			(int)(*(p)->_ptr++) :\
			_flsbuf(*(unsigned char *)(p)->_ptr, p)) :\
		_flsbuf((unsigned char)(x), p)))
#endif
#define	getchar()	getc(stdin)
#define	putchar(x)	putc((x),stdout)
#define	feof(p)		(((p)->_flag&_IOEOF)!=0)
#define	ferror(p)	(((p)->_flag&_IOERR)!=0)
#define	fileno(p)	((p)->_file)
#define	clearerr(p)	(void) ((p)->_flag &= ~(_IOERR|_IOEOF))

extern FILE	*fopen _PARAMS((const char *, const char *));
extern FILE	*fdopen _PARAMS((int, const char *));
extern FILE	*freopen _PARAMS((const char *, const char *, FILE *));
extern FILE	*popen _PARAMS((const char *, const char *));
extern FILE	*tmpfile();
extern long	ftell _PARAMS((FILE *));
extern char	*fgets _PARAMS((char *, int, FILE *));
extern char	*gets _PARAMS((char *));
extern char	*sprintf _PARAMS((char *, const char *, ...));
extern char	*ctermid _PARAMS((char *));
extern char	*cuserid _PARAMS((char *));
extern char	*tempnam _PARAMS((const char *, const char *));
extern char	*tmpnam _PARAMS((char *));

#define L_ctermid	9
#define L_cuserid	9
#define P_tmpdir	"/usr/tmp/"
#define L_tmpnam	25		/* (sizeof(P_tmpdir) + 15) */
# endif
#if defined(__cplusplus) || defined(__USE_FIXED_PROTOTYPES__)
extern int fclose (FILE *);
extern int fflush (FILE *);
extern int fgetc (FILE *);
extern int fgetpos (FILE *, long *);
extern int fprintf (FILE *, const char *, ...);
extern int fputc (int, FILE *);
extern int fputs (const char *, FILE *);
extern __SIZE_TYPE__ fread (void *, __SIZE_TYPE__ , __SIZE_TYPE__ , FILE *);
extern int fscanf (FILE *, const char *, ...);
extern int fseek (FILE *, long int, int);
extern int fsetpos (FILE *, const long *);
extern __SIZE_TYPE__ fwrite (const void *, __SIZE_TYPE__ , __SIZE_TYPE__ , FILE *);
extern int pclose (FILE *);
extern void perror (const char *);
extern int printf (const char *, ...);
extern int puts (const char *);
extern int remove (const char *);
extern int rename (const char *, const char *);
extern void rewind (FILE *);
extern int scanf (const char *, ...);
extern void setbuf (FILE *, char *);
extern int setvbuf (FILE *, char *, int, __SIZE_TYPE__ );
extern int sscanf (const char *, const char *, ...);
#ifndef vprintf
extern int vprintf (const char *, __gnuc_va_list);
#endif
#ifndef vsprintf
extern int vsprintf (char *, const char *, __gnuc_va_list);
#endif
#ifndef vfprintf
extern int vfprintf (FILE *, const char *, __gnuc_va_list);
#endif
extern int ungetc (int, FILE *);
extern int _filbuf (FILE *);
extern int _flsbuf (unsigned int, FILE *);
#endif /* defined(__cplusplus) || defined(__USE_FIXED_PROTOTYPES__*/
