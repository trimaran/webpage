/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/* Author: Matt Merten, Mike Thiems, Wen-mei Hwu                             */
#ifndef LBX86_BYTEGEN_MD_H
#define LBX86_BYTEGEN_MD_H


#define DEST0            0
#define DEST1            1
#define DEST2            2
#define DEST3            3
#define SRC0            10
#define SRC1            11
#define SRC2            12
#define SRC3            13
#define SRC4            14
#define SRC5            15
#define SRC6            16
#define SRC0_AND_DEST0  20
#define SRC1_AND_DEST1  21
#define SRC2_AND_DEST2  22
#define SRC3_AND_DEST3  23
#define SRC2_AND_DEST3  32

#define ILLEGAL       -1
#define OPCODE_CBR    -2
#define OPCODE_RELJMP -3

#define TYPE_INT             1
#define TYPE_LABEL           2
#define TYPE_CB              3
#define TYPE_LABEL_OR_CB     4
#define TYPE_GENREG          5
#define TYPE_ADDR            6
#define TYPE_MAC_VOID        7
#define TYPE_GENREG_8        8
#define TYPE_GENREG_16       9
#define TYPE_GENREG_32      10
#define TYPE_AL             11
#define TYPE_AH             12
#define TYPE_AX             13
#define TYPE_EAX            14
#define TYPE_ACCUM          15 // AL or AX or EAX
#define TYPE_AX_OR_AL       16
#define TYPE_EAX_OR_AX      17
#define TYPE_CL             18
#define TYPE_CX             19
#define TYPE_ECX            20
#define TYPE_ECX_OR_CX      21
#define TYPE_EBX            22
#define TYPE_EDI            23
#define TYPE_ESI            24
#define TYPE_DX             25
#define TYPE_EDX            26
#define TYPE_EDX_OR_DX      27
#define TYPE_ESP            28
#define TYPE_ESP_OR_SP      29
#define TYPE_EBP            30
#define TYPE_GP_16_32       31
#define TYPE_SEGREG         32
#define TYPE_DS             33
#define TYPE_FST            34
#define TYPE_FST0           35
#define TYPE_FST1           36
#define TYPE_FPSW           37
#define TYPE_FPCW           38
#define TYPE_INT_OR_LABEL   39

#define SIZE_BYTE                  1
#define SIZE_WORD                  2
#define SIZE_DWORD                 4
#define SIZE_FWORD                 6
#define SIZE_TWORD                10
#define SIZE_MAX                 108
#define SIZE_FOLLOW_MEM         1008
#define SIZE_FOLLOW_OP1         1011
#define SIZE_FOLLOW_OP2         1012
#define SIZE_FOLLOW_OP3         1013
#define SIZE_SPECIAL_MOVSZX_REG 1020
#define SIZE_SPECIAL_MOVSZX_MEM 1021
#define OPSIZE_IFDEFAULT32      1022
#define OPSIZE_IFDEFAULT16      1023

#define MOD_00       0
#define MOD_01       1
#define MOD_10       2
#define MOD_11       3
#define MOD_NOT11    4

#define X_REG_OP1   11
#define X_REG_OP2   12
#define X_SREG3_OP1 21
#define X_SREG3_OP2 22
#define X_00R       30
#define X_01R       32
#define X_10R       34
#define X_11R       36

#define RM_MEM       8
#define RM_REG_OP1  11
#define RM_REG_OP2  12
#define RM_REG_OP3  13
#define RM_FSTi     20
#define RM_FSTi_OP1 21
#define RM_FSTi_OP2 22

#define MF_REAL      0
#define MF_INT       1

#define D_NOTREV     0
#define D_REV        1


#endif
