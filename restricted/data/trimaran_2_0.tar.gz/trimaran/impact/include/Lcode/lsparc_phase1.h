/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/*************************************************************************\
 *
 *  File:  lsparc_phase1.h
 *
 *  Description:
 *	    Predefined SPARC opcodes
 *
 *  Creation Date :  August, 1992
 *
 *  Author:  Sabrina Y. Hwu, Wen-mei Hwu
 *
 *  Revisions:
 *
 *
\************************************************************************/

#define L_PRELOAD	0

#ifndef L_SPARC_H
#define L_SPARC_H

/* define extensions to instructions */
enum {

  MOV_SETHI = 1, 
  MOV_SETHI_FPLABEL,
  MOV_SET,
  MOV_MOV_DOUBLE,
  SUB_SUBcc,

  EQ_BEQ,
  NE_BNE,
  GE_BGE,
  GEU_BGEU,
  GT_BG, 		/* = 10 */

  GTU_BGU,
  LE_BLE,
  LEU_BLEU,
  LT_BL,
  LTU_BLU,

  OR_NOT_ZERO_2_NOT,
  EQ_BEQ_F,
  EQ_BEQ_F2,
  NE_BNE_F,
  NE_BNE_F2, 		/* = 20 */

  GE_BGE_F,
  GE_BGE_F2,
  GT_BG_F,
  GT_BG_F2,
  LE_BLE_F,

  LE_BLE_F2,
  LT_BL_F,
  LT_BL_F2,
  ADD_SAVE,
  ADD_SETHI_ADD_SAVE,	 /* = 30 */

  ADD_RESTORE,
  ADD_SRC2_LABEL_LO,
  ADD_MOV_INCR_SRC_DEST_REG_NUM,
  FADD_MOV_INCR_SRC_DEST_REG_NUM,
  STORE_REG,

  LOAD_REG,
  MOV_REG,
  SUBF_FCMPS,
  SUB_F2_FCMPD,
  LOAD_SRC2_LABEL_LO,	 /* = 40 */

  STORE_SRC2_LABEL_LO,
  LOAD_SRC2_FPLABEL_LO,
  OR_SRC2_LO,
  INCR_SRC3_REG_NUM,
  INCR_DEST_REG_NUM,

  JSR_REM,
  JSR_JMPL_TR_TEMP,
  JSR_BLE_COND,
  DEBUG_TAG,
  PRED_EMUL,		/* = 50 */

  MOV_LOAD_PREDICATE,	/* = 51 */
  ADD_SRC2_HI,
  JSR_INTERNAL,
  EMUL_VIKING,
  MOV_F_MOV_I
};


/* maximum values for immediate operands */
#define INT_2EXP13              0x2000
#define INT_2EXP12              0x1000
#define INT_2EXP11              0x800
#define INT_2EXP10              0x400
#define INT_2EXP4               0x10

#define SIGNED_FIELD_13(a)	(((a >= -INT_2EXP12)&&(a < INT_2EXP12))?1:0)

extern	int	L_non_leaf_func;
extern	int	L_function_return_type;

union CONVERT {
  struct {
    int  hi;
    int  lo;
  } integer;
  float  sgl;
  double dbl;
};
union CONVERT convert;

int	dataAligned;
int	data1Defined;
int	leaf;
int	callee_regs;
Set	callee_registers;
int	caller_regs;
int	alloc_size;
int	func_return_type;
int	swap_size;
int     prev_regalloc_swap_size;   /* This is the size of swap space from */
                                       /* Limpact Regalloc when RegAlloc 2x.  */
int     incoming_regs;
int     outgoing_regs;
L_Cb	*mcb;

/* Define a few used functions that the system doesn't define */

extern void L_scan_for_regs();
extern void L_scan_for_local_regs();
extern int  L_scan_for_alloc();
extern int L_update_alloc(L_Func *fn, int change);
extern int  L_update_local();
extern int  L_leaf_func();
extern void L_update_callee_caller();
extern void L_scan_prologue_defines();
extern L_Oper* L_register_or_const();
extern L_Oper* L_register_only();
extern L_Oper* L_float_macro_load(L_Operand *operand, L_Oper *oper, int ctype,
                                  L_Cb *cb);
extern void L_annotate_int_rem(L_Oper *oper, int op, L_Cb *cb);
extern void L_annotate_float_compare(L_Oper *oper, int op, int pred);

#endif
