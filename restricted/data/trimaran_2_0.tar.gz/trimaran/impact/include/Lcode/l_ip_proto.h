/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/* Author: Wen-mei Hwu                                                       */
/*
 *   This file was automatically generated by cextract version 1.2.
 *   Manual editing not recommended.
 *
 *   Created: Thu Sep 15 23:53:40 1994
 */
#ifndef __CEXTRACT__
#ifdef __STDC__

extern CallGraph *L_callgraph_build ( FILE * );
extern void L_callgraph_delete ( CallGraph * );
extern int L_callgraph_get_func_id ( CallGraph *, char * );
extern void L_callgraph_print ( FILE *, CallGraph * );
extern Set L_callgraph_query ( CallGraph *, int, int );
extern void L_cg_add_arc ( CG_Node *, L_Oper *, L_Operand * );
extern void L_cg_add_node ( CG_Node * );
extern void L_cg_add_non_dup_arc ( CG_Node *, L_Oper *, L_Operand * );
extern void L_cg_add_unknown_arcs ( CG_Node * );
extern void L_cg_delete_all_dst_arcs ( CG_Arc * );
extern void L_cg_delete_all_src_arcs ( CG_Arc * );
extern void L_cg_delete_arc ( CG_Arc * );
extern void L_cg_delete_node ( CG_Node * );
extern CG_Node *L_cg_find_node ( char * );
extern void L_cg_free_functions ( CallGraph * );
extern CG_Node *L_cg_get_node_from_id ( int );
extern void L_cg_load_func ( CG_Node * );
extern CallGraph *L_cg_new_callgraph ( void );
extern CG_Node *L_cg_new_node ( char * );
extern void L_cg_resolve_unknown_jsr ( CG_Node * );
extern void L_cg_resolve_unknown_nodes ( void );
extern void L_database_add_entry ( int, char * );
extern void L_database_init ( void );
extern void L_db_add_callsite ( int, int, char *, int );
extern void L_db_add_global_memory_cell ( int, int, int, L_Operand *, L_Operand * );
extern void L_db_add_global_memory_value ( int, int, int, L_Operand *, L_Operand *, int, L_Operand *, L_Operand *, L_Operand * );
extern void L_db_add_param_reg ( int, int, int, L_Operand * );
extern void L_db_add_param_value ( int, int, int, L_Operand *, int, L_Operand *, L_Operand *, L_Operand * );
extern void L_db_add_return_value ( int, L_Operand *, int, L_Operand *, L_Operand *, L_Operand * );
extern Database_Callsite *L_db_find_callsite ( Database_Entry *, int, int, Database_Callsite * );
extern Database_Entry *L_db_find_entry ( int );
extern Memory_Cell *L_db_find_global_memory_cell ( Database_Callsite *, L_Operand *, L_Operand * );
extern Reg *L_db_find_param_reg ( Database_Callsite *, L_Operand * );
extern int L_db_global_memory_cell_defined ( Database_Callsite *, L_Operand *, L_Operand * );
extern Database_Callsite *L_db_new_callsite ( int, char *, int );
extern Database_Entry *L_db_new_entry ( int, char * );
extern int L_db_param_reg_defined ( Database_Callsite *, L_Operand * );
extern Memory_Cell *L_db_query_global_memory ( CG_Node *, int, int, L_Oper * );
extern Reg *L_db_query_param_reg ( CG_Node *, int, int, L_Operand * );
extern Reg *L_db_query_return_reg ( CG_Node *, CG_Node *, L_Operand * );
extern void L_db_update_global_memory ( Database_Entry *, CG_Node *, L_Oper * );
extern void L_db_update_param_reg ( Database_Entry *, CG_Node *, L_Operand * );
extern void L_db_update_return_reg ( CG_Node *, L_Operand * );
extern L_Oper *L_find_rts ( L_Func * );
extern void L_gen_code ( Parm_Macro_List * );
extern void L_interproc_init ( Parm_Macro_List * );
extern void L_read_parm_safe ( Parm_Parse_Info * );
extern Memory_Cell *L_mem_add_cell ( Memory *, L_Operand *, L_Operand *, int );
extern Memory_Cell *L_mem_add_hash ( L_Operand * );
extern int L_mem_compute_hash ( Memory *, L_Operand *, L_Operand * );
extern void L_mem_define_cell ( CG_Node *, L_Operand *, L_Operand *, int, L_Operand *, L_Operand *, L_Operand *, int );
extern void L_mem_delete ( Memory * );
extern void L_mem_delete_cell ( Memory_Cell * );
extern void L_mem_delete_hash ( void );
extern void L_mem_delete_value_gt_level ( Memory *, int );
extern Memory_Cell *L_mem_find_cell ( Memory *, L_Operand *, L_Operand * );
extern Memory_Cell *L_mem_find_hash ( L_Operand *, L_Operand * );
extern Memory_Cell *L_mem_get_cell ( CG_Node *, L_Oper * );
extern int L_mem_global_load ( L_Oper * );
extern int L_mem_global_ref ( L_Operand *, L_Operand * );
extern int L_mem_global_store ( L_Oper * );
extern void L_mem_load_data ( L_Data * );
extern int L_mem_local_load ( L_Oper * );
extern int L_mem_local_ref ( L_Operand *, L_Operand * );
extern int L_mem_local_store ( L_Oper * );
extern Memory_Cell *L_mem_new_cell ( L_Operand *, L_Operand *, int );
extern Memory *L_mem_new_memory ( int );
extern int L_mem_ptr_load ( L_Oper * );
extern int L_mem_ptr_ref ( L_Operand *, L_Operand * );
extern int L_mem_ptr_store ( L_Oper * );
extern void L_mem_reset ( CG_Node * );
extern int L_mem_same_address ( L_Operand *, L_Operand *, L_Operand *, L_Operand * );
extern int L_mem_same_global_address ( L_Operand *, L_Operand *, L_Operand *, L_Operand * );
extern void L_rf_define_register ( RegFile *, L_Operand *, int, L_Operand *, L_Operand *, L_Operand *, int );
extern void L_rf_delete_reg ( Reg * );
extern void L_rf_delete_register_gt_level ( RegFile *, int );
extern void L_rf_delete_reg_file ( RegFile * );
extern Reg *L_rf_delete_reg_gt_level ( Reg *, int );
extern RegBank *L_rf_enlargen_bank ( RegBank *, int );
extern Reg *L_rf_get_register ( CG_Node *, RegFile *, L_Operand * );
extern Reg *L_rf_get_return_reg ( CG_Node *, RegFile *, L_Oper *, L_Operand *, L_Operand * );
extern Reg *L_rf_new_reg ( L_Operand * );
extern RegFile *L_rf_new_reg_file ( void );
extern void L_rf_reset_reg_file ( RegFile * );
extern int L_can_swap_int_operands ( int );
extern L_Operand *L_get_return_param ( L_Oper * );
extern Resolved *L_resolve_unknown ( CG_Node *, L_Cb *, L_Oper *, int, L_Operand **, L_Oper * );
extern Resolved *L_rs_add_cell ( Resolved *, Memory_Cell *, int );
extern Resolved *L_rs_add_reg ( Resolved *, Reg *, int );
extern void L_rs_delete_resolved ( Resolved * );
extern void L_rs_evaluate_double_arith ( CG_Node *, RegFile *, L_Oper *, int );
extern void L_rs_evaluate_float_arith ( CG_Node *, RegFile *, L_Oper *, int );
extern void L_rs_evaluate_int_arith ( CG_Node *, RegFile *, L_Oper *, int );
extern void L_rs_evaluate_jsr ( CG_Node *, RegFile *, L_Oper *, int );
extern void L_rs_evaluate_load ( CG_Node *, RegFile *, L_Oper *, int );
extern void L_rs_evaluate_mov ( CG_Node *, RegFile *, L_Oper *, int );
extern void L_rs_evaluate_store ( CG_Node *, RegFile *, L_Oper *, int );
extern Resolved *L_rs_new_resolved ( void );
extern double L_rs_perform_dbl_arith ( int, L_Operand *, L_Operand *, L_Operand * );
extern double L_rs_perform_flt_arith ( int, L_Operand *, L_Operand *, L_Operand * );
extern int L_rs_perform_int_arith ( int, L_Operand *, L_Operand *, L_Operand * );
extern void L_rs_perform_store ( CG_Node *, RegFile *, L_Operand *, L_Operand *, L_Operand *, int );
extern Resolved *L_rs_resolve_unknown ( Resolved *, CG_Node *, RegFile *, UD_Node *, UD_Node *, int, int, L_Operand **, L_Oper * );
extern Value *L_rs_solve_2op_int_arith ( RegFile *, L_Operand *, int, Value *, Value *, int, int );
extern void L_find_side_effect_free ( CallGraph *, FILE * );
extern int L_is_safe_subroutine_call ( CG_Node *, L_Oper *, int );
extern int L_is_stack_store ( L_Oper * );
extern void L_add_arc ( UD_Node *, UD_Node * );
extern int L_add_non_duplicate_arc ( UD_Node *, UD_Node * );
extern void L_delete_arc ( UD_Arc * );
extern void L_free_all_dst_arcs ( UD_Arc * );
extern void L_free_all_src_arcs ( UD_Arc * );
extern void L_ud_add_retrace ( UD_Graph *, UD_Node *, L_Cb *, L_Oper *, Set, Def_List * );
extern Set L_ud_add_src ( Set, L_Operand * );
extern Set L_ud_add_src_reg ( Set, int );
extern void L_ud_add_start_node ( UD_Graph *, UD_Node * );
extern void L_ud_build_graph_recurse ( UD_Graph *, UD_Node *, Set, Def_List * );
extern int L_ud_convert_operand ( L_Operand * );
extern Def_List *L_ud_copy_def_list ( Def_List * );
extern void L_ud_delete_node ( UD_Graph *, UD_Node * );
extern int L_ud_find_matching_address ( Def_List *, L_Oper * );
extern int L_ud_find_matching_hash ( Def_List *, L_Oper * );
extern UD_Node *L_ud_find_retrace ( UD_Graph *, L_Cb *, L_Oper *, Set, Def_List * );
extern L_Oper *L_ud_find_start_pt ( L_Cb *, L_Cb * );
extern void L_ud_free_all_def_oper ( Def_Oper * );
extern void L_ud_free_all_retrace ( UD_Graph * );
extern void L_ud_free_def_list ( Def_List * );
extern int L_ud_ignore_oper ( L_Oper * );
extern void L_ud_insert_def_oper_first ( UD_Node *, Def_Oper * );
extern Def_List *L_ud_new_def_list ( void );
extern Def_Oper *L_ud_new_def_oper ( L_Oper * );
extern UD_Graph *L_ud_new_graph ( L_Func *, L_Cb *, L_Oper *, L_Oper * );
extern UD_Node *L_ud_new_node ( UD_Graph *, L_Cb *, L_Oper * );
extern Retrace *L_ud_new_retrace ( UD_Node *, L_Cb *, L_Oper *, Set, Def_List * );
extern void L_ud_print_def_oper ( Def_Oper * );
extern void L_ud_print_graph_recurse ( UD_Node * );
extern void L_ud_print_node ( UD_Node * );
extern void L_ud_reduce_graph ( UD_Graph * );
extern void L_ud_reduce_graph_recurse ( UD_Graph *, UD_Node * );
extern Set L_ud_remove_dest ( Set, int );
extern void L_ud_remove_matching_address ( Def_List *, L_Oper * );
extern void L_ud_update_def_list ( Def_List *, L_Oper * );
extern UD_Graph *L_usedef_build_graph ( CG_Node *, L_Cb *, L_Oper *, int, L_Operand **, L_Oper * );
extern void L_usedef_delete_graph ( UD_Graph * );
extern void L_usedef_print_graph ( UD_Graph * );
extern Value *L_v_add_value ( Value *, int, L_Operand *, L_Operand *, L_Operand *, int );
extern Value *L_v_copy_value ( Value * );
extern void L_v_delete_all_value ( Value * );
extern Value *L_v_delete_value_gt_level ( Value *, int );
extern Value *L_v_find_matching_value ( Value *, int, L_Operand *, L_Operand *, L_Operand *, int );
extern Value *L_v_get_value_same_level ( Value *, Value * );
extern Value *L_v_new_value ( int, L_Operand *, L_Operand *, L_Operand *, int );

#else /* __STDC__ */

extern CallGraph *L_callgraph_build (/* FILE * */);
extern void L_callgraph_delete (/* CallGraph * */);
extern int L_callgraph_get_func_id (/* CallGraph *, char * */);
extern void L_callgraph_print (/* FILE *, CallGraph * */);
extern Set L_callgraph_query (/* CallGraph *, int, int */);
extern void L_cg_add_arc (/* CG_Node *, L_Oper *, L_Operand * */);
extern void L_cg_add_node (/* CG_Node * */);
extern void L_cg_add_non_dup_arc (/* CG_Node *, L_Oper *, L_Operand * */);
extern void L_cg_add_unknown_arcs (/* CG_Node * */);
extern void L_cg_delete_all_dst_arcs (/* CG_Arc * */);
extern void L_cg_delete_all_src_arcs (/* CG_Arc * */);
extern void L_cg_delete_arc (/* CG_Arc * */);
extern void L_cg_delete_node (/* CG_Node * */);
extern CG_Node *L_cg_find_node (/* char * */);
extern void L_cg_free_functions (/* CallGraph * */);
extern CG_Node *L_cg_get_node_from_id (/* int */);
extern void L_cg_load_func (/* CG_Node * */);
extern CallGraph *L_cg_new_callgraph (/* void */);
extern CG_Node *L_cg_new_node (/* char * */);
extern void L_cg_resolve_unknown_jsr (/* CG_Node * */);
extern void L_cg_resolve_unknown_nodes (/* void */);
extern void L_database_add_entry (/* int, char * */);
extern void L_database_init (/* void */);
extern void L_db_add_callsite (/* int, int, char *, int */);
extern void L_db_add_global_memory_cell (/* int, int, int, L_Operand *, L_Operand * */);
extern void L_db_add_global_memory_value (/* int, int, int, L_Operand *, L_Operand *, int, L_Operand *, L_Operand *, L_Operand * */);
extern void L_db_add_param_reg (/* int, int, int, L_Operand * */);
extern void L_db_add_param_value (/* int, int, int, L_Operand *, int, L_Operand *, L_Operand *, L_Operand * */);
extern void L_db_add_return_value (/* int, L_Operand *, int, L_Operand *, L_Operand *, L_Operand * */);
extern Database_Callsite *L_db_find_callsite (/* Database_Entry *, int, int, Database_Callsite * */);
extern Database_Entry *L_db_find_entry (/* int */);
extern Memory_Cell *L_db_find_global_memory_cell (/* Database_Callsite *, L_Operand *, L_Operand * */);
extern Reg *L_db_find_param_reg (/* Database_Callsite *, L_Operand * */);
extern int L_db_global_memory_cell_defined (/* Database_Callsite *, L_Operand *, L_Operand * */);
extern Database_Callsite *L_db_new_callsite (/* int, char *, int */);
extern Database_Entry *L_db_new_entry (/* int, char * */);
extern int L_db_param_reg_defined (/* Database_Callsite *, L_Operand * */);
extern Memory_Cell *L_db_query_global_memory (/* CG_Node *, int, int, L_Oper * */);
extern Reg *L_db_query_param_reg (/* CG_Node *, int, int, L_Operand * */);
extern Reg *L_db_query_return_reg (/* CG_Node *, CG_Node *, L_Operand * */);
extern void L_db_update_global_memory (/* Database_Entry *, CG_Node *, L_Oper * */);
extern void L_db_update_param_reg (/* Database_Entry *, CG_Node *, L_Operand * */);
extern void L_db_update_return_reg (/* CG_Node *, L_Operand * */);
extern L_Oper *L_find_rts (/* L_Func * */);
extern void L_gen_code (/* Parm_Macro_List * */);
extern void L_interproc_init (/* Parm_Macro_List * */);
extern void L_read_parm_safe (/* Parm_Parse_Info * */);
extern Memory_Cell *L_mem_add_cell (/* Memory *, L_Operand *, L_Operand *, int */);
extern Memory_Cell *L_mem_add_hash (/* L_Operand * */);
extern int L_mem_compute_hash (/* Memory *, L_Operand *, L_Operand * */);
extern void L_mem_define_cell (/* CG_Node *, L_Operand *, L_Operand *, int, L_Operand *, L_Operand *, L_Operand *, int */);
extern void L_mem_delete (/* Memory * */);
extern void L_mem_delete_cell (/* Memory_Cell * */);
extern void L_mem_delete_hash (/* void */);
extern void L_mem_delete_value_gt_level (/* Memory *, int */);
extern Memory_Cell *L_mem_find_cell (/* Memory *, L_Operand *, L_Operand * */);
extern Memory_Cell *L_mem_find_hash (/* L_Operand *, L_Operand * */);
extern Memory_Cell *L_mem_get_cell (/* CG_Node *, L_Oper * */);
extern int L_mem_global_load (/* L_Oper * */);
extern int L_mem_global_ref (/* L_Operand *, L_Operand * */);
extern int L_mem_global_store (/* L_Oper * */);
extern void L_mem_load_data (/* L_Data * */);
extern int L_mem_local_load (/* L_Oper * */);
extern int L_mem_local_ref (/* L_Operand *, L_Operand * */);
extern int L_mem_local_store (/* L_Oper * */);
extern Memory_Cell *L_mem_new_cell (/* L_Operand *, L_Operand *, int */);
extern Memory *L_mem_new_memory (/* int */);
extern int L_mem_ptr_load (/* L_Oper * */);
extern int L_mem_ptr_ref (/* L_Operand *, L_Operand * */);
extern int L_mem_ptr_store (/* L_Oper * */);
extern void L_mem_reset (/* CG_Node * */);
extern int L_mem_same_address (/* L_Operand *, L_Operand *, L_Operand *, L_Operand * */);
extern int L_mem_same_global_address (/* L_Operand *, L_Operand *, L_Operand *, L_Operand * */);
extern void L_rf_define_register (/* RegFile *, L_Operand *, int, L_Operand *, L_Operand *, L_Operand *, int */);
extern void L_rf_delete_reg (/* Reg * */);
extern void L_rf_delete_register_gt_level (/* RegFile *, int */);
extern void L_rf_delete_reg_file (/* RegFile * */);
extern Reg *L_rf_delete_reg_gt_level (/* Reg *, int */);
extern RegBank *L_rf_enlargen_bank (/* RegBank *, int */);
extern Reg *L_rf_get_register (/* CG_Node *, RegFile *, L_Operand * */);
extern Reg *L_rf_get_return_reg (/* CG_Node *, RegFile *, L_Oper *, L_Operand *, L_Operand * */);
extern Reg *L_rf_new_reg (/* L_Operand * */);
extern RegFile *L_rf_new_reg_file (/* void */);
extern void L_rf_reset_reg_file (/* RegFile * */);
extern int L_can_swap_int_operands (/* int */);
extern L_Operand *L_get_return_param (/* L_Oper * */);
extern Resolved *L_resolve_unknown (/* CG_Node *, L_Cb *, L_Oper *, int, L_Operand **, L_Oper * */);
extern Resolved *L_rs_add_cell (/* Resolved *, Memory_Cell *, int */);
extern Resolved *L_rs_add_reg (/* Resolved *, Reg *, int */);
extern void L_rs_delete_resolved (/* Resolved * */);
extern void L_rs_evaluate_double_arith (/* CG_Node *, RegFile *, L_Oper *, int */);
extern void L_rs_evaluate_float_arith (/* CG_Node *, RegFile *, L_Oper *, int */);
extern void L_rs_evaluate_int_arith (/* CG_Node *, RegFile *, L_Oper *, int */);
extern void L_rs_evaluate_jsr (/* CG_Node *, RegFile *, L_Oper *, int */);
extern void L_rs_evaluate_load (/* CG_Node *, RegFile *, L_Oper *, int */);
extern void L_rs_evaluate_mov (/* CG_Node *, RegFile *, L_Oper *, int */);
extern void L_rs_evaluate_store (/* CG_Node *, RegFile *, L_Oper *, int */);
extern Resolved *L_rs_new_resolved (/* void */);
extern double L_rs_perform_dbl_arith (/* int, L_Operand *, L_Operand *, L_Operand * */);
extern double L_rs_perform_flt_arith (/* int, L_Operand *, L_Operand *, L_Operand * */);
extern int L_rs_perform_int_arith (/* int, L_Operand *, L_Operand *, L_Operand * */);
extern void L_rs_perform_store (/* CG_Node *, RegFile *, L_Operand *, L_Operand *, L_Operand *, int */);
extern Resolved *L_rs_resolve_unknown (/* Resolved *, CG_Node *, RegFile *, UD_Node *, UD_Node *, int, int, L_Operand **, L_Oper * */);
extern Value *L_rs_solve_2op_int_arith (/* RegFile *, L_Operand *, int, Value *, Value *, int, int */);
extern void L_find_side_effect_free (/* CallGraph *, FILE * */);
extern int L_is_safe_subroutine_call (/* CG_Node *, L_Oper *, int */);
extern int L_is_stack_store (/* L_Oper * */);
extern void L_add_arc (/* UD_Node *, UD_Node * */);
extern int L_add_non_duplicate_arc (/* UD_Node *, UD_Node * */);
extern void L_delete_arc (/* UD_Arc * */);
extern void L_free_all_dst_arcs (/* UD_Arc * */);
extern void L_free_all_src_arcs (/* UD_Arc * */);
extern void L_ud_add_retrace (/* UD_Graph *, UD_Node *, L_Cb *, L_Oper *, Set, Def_List * */);
extern Set L_ud_add_src (/* Set, L_Operand * */);
extern Set L_ud_add_src_reg (/* Set, int */);
extern void L_ud_add_start_node (/* UD_Graph *, UD_Node * */);
extern void L_ud_build_graph_recurse (/* UD_Graph *, UD_Node *, Set, Def_List * */);
extern int L_ud_convert_operand (/* L_Operand * */);
extern Def_List *L_ud_copy_def_list (/* Def_List * */);
extern void L_ud_delete_node (/* UD_Graph *, UD_Node * */);
extern int L_ud_find_matching_address (/* Def_List *, L_Oper * */);
extern int L_ud_find_matching_hash (/* Def_List *, L_Oper * */);
extern UD_Node *L_ud_find_retrace (/* UD_Graph *, L_Cb *, L_Oper *, Set, Def_List * */);
extern L_Oper *L_ud_find_start_pt (/* L_Cb *, L_Cb * */);
extern void L_ud_free_all_def_oper (/* Def_Oper * */);
extern void L_ud_free_all_retrace (/* UD_Graph * */);
extern void L_ud_free_def_list (/* Def_List * */);
extern int L_ud_ignore_oper (/* L_Oper * */);
extern void L_ud_insert_def_oper_first (/* UD_Node *, Def_Oper * */);
extern Def_List *L_ud_new_def_list (/* void */);
extern Def_Oper *L_ud_new_def_oper (/* L_Oper * */);
extern UD_Graph *L_ud_new_graph (/* L_Func *, L_Cb *, L_Oper *, L_Oper * */);
extern UD_Node *L_ud_new_node (/* UD_Graph *, L_Cb *, L_Oper * */);
extern Retrace *L_ud_new_retrace (/* UD_Node *, L_Cb *, L_Oper *, Set, Def_List * */);
extern void L_ud_print_def_oper (/* Def_Oper * */);
extern void L_ud_print_graph_recurse (/* UD_Node * */);
extern void L_ud_print_node (/* UD_Node * */);
extern void L_ud_reduce_graph (/* UD_Graph * */);
extern void L_ud_reduce_graph_recurse (/* UD_Graph *, UD_Node * */);
extern Set L_ud_remove_dest (/* Set, int */);
extern void L_ud_remove_matching_address (/* Def_List *, L_Oper * */);
extern void L_ud_update_def_list (/* Def_List *, L_Oper * */);
extern UD_Graph *L_usedef_build_graph (/* CG_Node *, L_Cb *, L_Oper *, int, L_Operand **, L_Oper * */);
extern void L_usedef_delete_graph (/* UD_Graph * */);
extern void L_usedef_print_graph (/* UD_Graph * */);
extern Value *L_v_add_value (/* Value *, int, L_Operand *, L_Operand *, L_Operand *, int */);
extern Value *L_v_copy_value (/* Value * */);
extern void L_v_delete_all_value (/* Value * */);
extern Value *L_v_delete_value_gt_level (/* Value *, int */);
extern Value *L_v_find_matching_value (/* Value *, int, L_Operand *, L_Operand *, L_Operand *, int */);
extern Value *L_v_get_value_same_level (/* Value *, Value * */);
extern Value *L_v_new_value (/* int, L_Operand *, L_Operand *, L_Operand *, int */);

#endif /* __STDC__ */
#endif /* __CEXTRACT__ */
