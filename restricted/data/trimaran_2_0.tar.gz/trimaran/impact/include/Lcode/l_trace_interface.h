/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.20  */
/* IMPACT Trimaran Release (www.trimaran.org)                  May 17, 1999  */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 *
 * Copyright 1999 IMPACT Technologies, Inc; Champaign, Illinois
 * For commercial license rights, contact: Marketing Office via
 * electronic mail: marketing@impactinc.com
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/

/*****************************************************************************\
 *      File:   l_trace_interface.h
 *      Author: John Gyllenhaal, Wen-mei Hwu
 *      Creation Date:  April 1994
\*****************************************************************************/

#ifndef L_TRACE_INTERFACE_H
#define L_TRACE_INTERFACE_H

/* The original trace headers were designed assuming the 'assembly' being
 * traced was available and minimal trace overhead (with some error
 * checking) was desired.  There are several old headers that will not occur
 * in IMPACT 2.1 (but are left in for backward compatibility). -JCG 4/99 
 */
#define L_TRACE_PRED_CLR        0       
#define L_TRACE_PRED_SET        1
#define L_TRACE_PRED_UNDEF      2       /* Not in IMPACT 2.1 -JCG 4/99*/
#define L_TRACE_FN              3
#define L_TRACE_STUB            4       /* Not in IMPACT 2.1 -JCG 4/99*/
#define L_TRACE_BRTHRU          5
#define L_TRACE_START		6       /* Not in IMPACT 2.1 -JCG 4/99*/
#define L_TRACE_START_FORMAT1   6       /* Format before 10/14/96 */
#define L_TRACE_END             7
#define L_TRACE_WRITE           8       /* Store address next trace word */
#define L_TRACE_RTS             9       /* Not currently used -JCG 4/99*/
#define L_TRACE_SAMPLE_START    10
#define L_TRACE_SAMPLE_END      11
#define L_TRACE_PREFETCH        12      /* Not in IMPACT 2.1 -JCG 4/99*/
#define L_TRACE_MEM_COPY        13      /* Not in IMPACT 2.1 -JCG 4/99*/
#define L_TRACE_MEM_COPY_BACK   14      /* Not in IMPACT 2.1 -JCG 4/99*/
#define L_TRACE_MEM_COPY_CHECK  15      /* Not in IMPACT 2.1 -JCG 4/99*/
#define L_TRACE_MASKED_SEG_FAULT 16     /* Load would have thrown exception */
#define L_TRACE_NO_SEG_FAULT	17	/* Must be MASKED_SEG_FAULT + 1 */
#define L_TRACE_START_FORMAT2	18	/* New trace format 10/14/96 */
					/* Pred defs now also traced */
#define L_TRACE_START_FORMAT3	19	/* New trace format -ITI/JCG 1/99*/

/*
 * Additional trace headers to support alternate tracing modes in 
 * Lemulate version 2.2. -ITI/JCG 4/99 
 *
 * Based on ideas and suggestions from Dan Connors, Scott Mahlke, 
 * Jason Fritts, Jean-Michel Puiatti, and many others. 
 */

/* Headers to support parsing trace without benchmark assembly -ITI/JCG 4/99 */
#define L_TRACE_READ     	20      /* Load address next trace word */
#define L_TRACE_PRED_DEF     	21      /* Pred value after def (next word) */
#define L_TRACE_PROMOTED_PRED  	22      /* Pred value after def (next word) */
#define L_TRACE_SWITCH_CASE	23      /* src[1] on jump_rg's */
#define L_TRACE_RET_FROM_JSR	24      /* JSR location in next two words */

/* Two different headers for tracing every operation executed -ITI/JCG 4/99*/
#define L_TRACE_OP_ID         	27      /* Lcode op id in next word */
#define L_TRACE_FN_OP_ID       	28      /* Lcode fn & op id in next two words*/

/* Headers to support various levels of value tracing -ITI/JCG 4/99*/
#define L_TRACE_DEST_REG_I	30      /* Integer dest register value */
#define L_TRACE_DEST_REG_F	31      /* Float dest register value */
#define L_TRACE_DEST_REG_F2	32      /* Double dest register value */
#define L_TRACE_SRC_REG_I	33      /* Integer src register value */
#define L_TRACE_SRC_REG_F	34      /* Float src register value */
#define L_TRACE_SRC_REG_F2	35      /* Double src register value */
#define L_TRACE_SRC_LIT_I	36      /* Integer src literal value */
#define L_TRACE_SRC_LIT_F	37      /* Float src literal value */
#define L_TRACE_SRC_LIT_F2	38      /* Double src literal value */


/* JSR id (from top of function) is encoded as (L_TRACE_JSR_OFFSET - id)
 * when put into the trace. 
 */
#define L_TRACE_JSR_OFFSET	-2048


/* To support Lemulates tracing options and future trace formats 
 * seamlessly, allow a set of trace flags (TF) to be placed after
 * L_TRACE_START_FORMAT3. -ITI/JCG 1/99
 *
 * Note: These are bit flags, assume 32 bit words.
 */

/* Lemulate's function id method is being used (verses function address).
 * The ids start at 1000 and are numbered in the order found in
 * the encoded file. -ITI/JCG 1/99
 */
#define TF_FUNC_IDS			0x0000001

/* These TRACE_FLAGs correspond directly to the Lemulate trace parameters.  
 * See impact/parms/LEMULATE_DEFAULTS for description of each parameter.  
 * These flags allow tools to adapt to different trace settings or punt 
 * if something unexpected is thrown at them. -ITI/JCG 4/99
 */
#define TF_PROBE_FOR_PROFILING		0x0000002 
#define TF_PROBE_FOR_SIMULATION		0x0000004 
#define TF_PROBE_FOR_CUSTOM		0x0000008  
#define TF_PREDICATE_PROBE_CODE		0x0000010
#define TF_TRACE_CONTROL_FLOW		0x0000020
#define TF_TRACE_EMPTY_CBS		0x0000040
#define TF_TRACE_MEM_ADDRS		0x0000080
#define TF_TRACE_MASKED_LOAD_FAULTS	0x0000100
#define TF_TRACE_JUMP_RG_SRC1		0x0000200
#define TF_TRACE_PRED_USES		0x0000400
#define TF_TRACE_PRED_DEFS		0x0000800
#define TF_TRACE_PROMOTED_PREDS		0x0001000
#define TF_TRACE_PRED_JUMP_FALL_THRU	0x0002000
#define TF_TRACE_EXTRA_HEADERS		0x0004000
#define TF_TRACE_OP_IDS			0x0008000
#define TF_TRACE_ENHANCED_OP_IDS	0x0010000
#define TF_TRACE_DEST_REG_VALUES	0x0020000
#define TF_TRACE_SRC_REG_VALUES		0x0040000
#define TF_TRACE_SRC_LIT_VALUES		0x0080000

/* If need more than 32 flags, use last bit to flag that there is a 
 * second 32-bit word of flags.  Not needed yet, so delaying implementation
 * until required.  -ITI/JCG 4/99
 */


/* The following union is used to split a double value 'f2' into two 
 * 32-bit words for transmision thru the trace pipe. This structure may 
 * be to reconstruct the double on the receiving end and to store value 
 * tracing values in general.  -ITI/JCG 4/99
 *
 * Note: Value tracing of doubles in this manner should be verified to
 *       work with the host compiler before trusting this hack!  The trace
 *       with value profiles is unlikely to be readable on another
 *       platform.
 */
typedef union Trace_Value 
{
    int		i;
    float	f;
    double	f2;
    struct 
    {
    	int	w1;	/* Assumed to be the first word of double f2 */
	int	w2;	/* Assumed to be the second word of double f2 */
    } word;
} Trace_Value;

#endif


