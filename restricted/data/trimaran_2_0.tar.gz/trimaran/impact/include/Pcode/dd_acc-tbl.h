/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/*****************************************************************************\
 *      File:   dd_acc-tbl.h
 *      Author: Grant Haab and Wen-mei Hwu
\*****************************************************************************/


#ifndef DD_ACC_TBL_H
#define DD_ACC_TBL_H

#include <Pcode/impact_global.h>
#include <Pcode/pcode.h>
#include <Pcode/dd_portable.h>
#include <Pcode/dd_affine.h>
#include <Pcode/dd_dir.h>
#include <Pcode/dd_extra.h>
#include <Pcode/flow.h>
#include <library/graph.h>
#include <library/c_symbol.h>
#include <library/set.h>

/* Text for pragma string when want to skip data dependence for function */
#define DD_FN_SKIP_PRAGMA	"\"not f2c\""

/* define the maximum number of subscripts for an array access */
#define DD_MAX_ARRAY_SUBSCR	9	/* this cannot be greater than 9! */

/* define the maximum number of dimension paths for delinearization */
#define DD_MAX_DIM_PATHS	32

/* define the maximum size of string used in dependence analysis structures */
#define DD_MAX_STRING		512

/* define the maximum number of acc expr which can be related to a single
	variable reference */
#define DD_MAX_ACC_PER_VAR_REF		32

#define ARC_DIR_EITHER 0
#define ARC_DIR_FWD 1
#define ARC_DIR_REV 2

/******************************************************************************
 Data Structures and Function Declarations used internally for Access Table.
 ******************************************************************************/

typedef Stmt context_iterator;

/* 
 * a structure containing information for a subscript expression of an 
 * array access used by the omega dependence analyzer.
 */
typedef struct _sub_iterator {
	Expr sub_expr;			/* Pcode subscript expression */
	affine_expr *affexpr;		/* affine expression for subscript */
	unsigned char mod_sub_var;	/* subscript symbolic vars modified */ 
	struct _sub_iterator *next;	/* structure for next subscript */
} _sub_iterator, *sub_iterator;

/* values for mod_sub_var in above sub_iterator structure */
#define NO_SUB_VAR_MOD		0
#define SUB_VAR_MOD_IN_PARLOOP	(1<<0)
#define SUB_VAR_MOD_AT_TOP_LEV	(1<<1)
#define SUB_VAR_MOD_IN_FUNC	(SUB_VAR_MOD_IN_PARLOOP|SUB_VAR_MOD_AT_TOP_LEV)

#define IND_VAR_TBL_MAX_SIZE    64

/******************************************************************************
 Data Structures used to access the dependence graph using the variable access
 table. (Some fields used internally by Dep. Analysis.)
 ******************************************************************************/

/* BCC - 4/22/96 
 * After flattening, a whole bunch of local vars are created. So the size of 
 * the table has to be increased from 1024 to 2048. 
 */
/* BCC - 10/19/96 
 * After inlining 300%, the table size is not enough for 099.go. So extend 
 * again from 2048 to 3072.
 */
#define ACC_TBL_MAX_SIZE	3072

#define ACC_TBL_INCREMENT	512

/* BCC - new arcs definition - 3/22/97 */
typedef enum Arc_Types {
    RED_DD_ARC = 1,
    RED_DI_ARC = 2,
    RED_ID_ARC = 4,
    RED_II_ARC = 8,
    GREEN_ARC = 16,
    BLUE_DD_ARC = 32,
    BLUE_DI_ARC = 64,
    BLUE_ID_ARC = 128,
    BLUE_II_ARC = 256,
    BLACK_ARC = 512,
    BRUTE_AND_FORCE_ARC = 1024,
} Arc_Types;

#define ALL_ARCS 0xFFFFFFFF

#define RED_ARCS (RED_DD_ARC | RED_ID_ARC | RED_DI_ARC | RED_II_ARC)
#define BLUE_ARCS (BLUE_DD_ARC | BLUE_ID_ARC | BLUE_DI_ARC | BLUE_II_ARC)
#define ROOT_ARCS (RED_ARCS | BLUE_ARCS)

/* BCC - changed into enums for debugging purposes - 2/6/97 */
/* Variable types used for var_class field in DDSymEntry structure */
typedef enum Var_Class {
    DD_LOCAL_VAR = 1,
    DD_GLOBAL_VAR = 2,
    DD_FUNCTION_NAME_VAR = 3,
    DD_FUNCTION_CALL = 4 
} Var_Class;

/* 
 * BCC - exposed levels 
 * 1) DD_A_DEREF: p in foo(p). p is a local variable and p* is exposed to foo().
 *    p can change the content of other pointer variables but p cannot be 
 *    changed.
 * 2) DD_A_DEREF_DEREF: if p is a local variable, access names which contain 
 *    at least two '*'s and end with '*' are qualfied. In cases like p**, p* 
 *    can change other pointers and be changed.
 * 3) DD_A_DEREF_F: if p is a local variable, p*.field is exposed to 
 *    foo(). It can only change other pointers, but cannot be changed.
 * 4) DD_G_G_F: If g is a global variable, g.field and g are exposed. They can 
 *    only change other pointers, but cannot be changed.
 * 5) DD_G_DEREF: If g is a global variable, any access names derived from g 
 *    which end with one '*' are qualified. g can change other pointers and 
 *    can be changed.
 * 6) DD_F_DEREF: If p is a formal parameter, p* can be aliased to anyting
 *    exposed to the caller. If q is another parameter, p and q can hold the
 *    same value, but cannot change each other. Since the p is local to the
 *    callee, prior to enter the function 
 * 7) DD_F_DEREF_DEREF: If p is a formal parameter, p* can not only be changed,
 *    but also can change other things.
 * 8) DD_F_DEREF_F: If p is a formal parameter, p*.field can modify other 
 *    parameter dereferences, and other global dereferences, but cannot be
 *    modified.
 * 9) DD_R_DEREF: If p holds the return value of a function call, p* can be 
 *    aliased to anything exposed to the callee, which are outgoing arguments
 *    and global variables. As DD_F_DEREF, p cannot change q, if q also holds
 *    another return value.
 * 10)DD_R_DEREF_DEREF: Reference DD_F_DEREF_DEREF.
 * 11)DD_R_DEREF_F: Reference DD_F_DEREF_F.
 * 
 * Operations:
 * DD_A_DEREF <-> DD_A_DEREF : Nothing
 * DD_A_DEREF <-> DD_A_DEREF_DEREF : DD_A_DEREF R> DD_A_DEREF_DEREF
 * DD_A_DEREF <-> DD_A_DEREF_F : Nothing
 * DD_A_DEREF <-> DD_G_G_F : Nothing
 * DD_A_DEREF <-> DD_G_DEREF : DD_A_DEREF R> DD_G_DEREF
 * DD_A_DEREF <-> DD_F_X : Nothing
 * DD_A_DEREF <-> DD_R_DEREF : DD_A_DEREF R> DD_R_DEREF
 * DD_A_DEREF <-> DD_R_DEREF_DEREF : Nothing
 * DD_A_DEREF <-> DD_R_DEREF_F : Nothing
 * 
 * DD_A_DEREF_DEREF <-> DD_A_DEREF_DEREF : DD_A_DEREF_DEREF <R> DD_A_DEREF_DEREF
 * DD_A_DEREF_DEREF <-> DD_A_DEREF_F : DD_A_DEREF_F R> DD_A_DEREF_DEREF
 * DD_A_DEREF_DEREF <-> DD_G_G_F : DD_G_G_F R> DD_A_DEREF_DEREF
 * DD_A_DEREF_DEREF <-> DD_G_DEREF : DD_A_DEREF_DEREF <R> DD_G_DEREF
 * DD_A_DEREF_DEREF <-> DD_F_X : Nothing
 * DD_A_DEREF_DEREF <-> DD_R_DEREF : DD_A_DEREF_DEREF R> DD_R_DEREF
 * DD_A_DEREF_DEREF <-> DD_R_DEREF_DEREF : Nothing
 * DD_A_DEREF_DEREF <-> DD_R_DEREF_F : Nothing
 *
 * DD_A_DEREF_F <-> DD_A_DEREF_F : Nothing
 * DD_A_DEREF_F <-> DD_G_G_F : Nothing
 * DD_A_DEREF_F <-> DD_G_DEREF : DD_A_DEREF_F R> DD_G_DEREF
 * DD_A_DEREF_F <-> DD_F_X : Nothing
 * DD_A_DEREF_F <-> DD_R_DEREF : DD_A_DEREF_F R> DD_R_DEREF
 * DD_A_DEREF_F <-> DD_R_DEREF_DEREF : Nothing
 * DD_A_DEREF_F <-> DD_R_DEREF_F : Nothing
 * 
 * DD_G_G_F <-> DD_G_G_F : Nothing
 * DD_G_G_F <-> DD_G_DEREF : DD_G_G_F R> DD_G_DEREF
 * DD_G_G_F <-> DD_F_DEREF : DD_G_G_F R> DD_F_DEREF
 * DD_G_G_F <-> DD_F_DEREF_DEREF : DD_G_G_F R> DD_F_DEREF_DEREF
 * DD_G_G_F <-> DD_F_DEREF_F : Nothing
 * DD_G_G_F <-> DD_R_DEREF : DD_G_G_F R> DD_R_DEREF
 * DD_G_G_F <-> DD_R_DEREF_DEREF : Nothing
 * DD_G_G_F <-> DD_R_DEREF_F : Nothing
 *
 * DD_G_DEREF <-> DD_G_DEREF : DD_G_DEREF <R> DD_G_DEREF
 * DD_G_DEREF <-> DD_F_DEREF : DD_G_DEREF R> DD_F_DEREF
 * DD_G_DEREF <-> DD_F_DEREF_DEREF : DD_G_DEREF <R> DD_F_DEREF_DEREF
 * DD_G_DEREF <-> DD_F_DEREF_F : DD_F_DEREF_F R> DD_G_DEREF
 * DD_G_DEREF <-> DD_R_DEREF : DD_G_DEREF R> DD_R_DEREF
 * DD_G_DEREF <-> DD_R_DEREF_DEREF : Nothing
 * DD_G_DEREF <-> DD_R_DEREF_F : Nothing
 *
 * DD_F_DEREF <-> DD_F_DEREF : DD_F_DEREF <B> DD_F_DEREF
 * DD_F_DEREF <-> DD_F_DEREF_DEREF : DD_F_DEREF_DEREF R> DD_F_DEREF
 * DD_F_DEREF <-> DD_F_DEREF_F : DD_F_DEREF_F R> DD_F_DEREF
 * DD_F_DEREF <-> DD_R_DEREF : Nothing
 * DD_F_DEREF <-> DD_R_DEREF_DEREF : Nothing
 * DD_F_DEREF <-> DD_R_DEREF_F : Nothing
 *
 * DD_F_DEREF_DEREF <-> DD_F_DEREF_DEREF : DD_F_DEREF_DEREF <R> DD_F_DEREF_DEREF
 * DD_F_DEREF_DEREF <-> DD_F_DEREF_F : DD_F_DEREF_F R> DD_F_DEREF_DEREF
 * DD_F_DEREF_DEREF <-> DD_R_DEREF : Nothing
 * DD_F_DEREF_DEREF <-> DD_R_DEREF_DEREF : Nothing
 * DD_F_DEREF_DEREF <-> DD_R_DEREF_F : Nothing
 *
 * DD_F_DEREF_F <-> DD_F_DEREF_F : Nothing
 * DD_F_DEREF_F <-> DD_R_DEREF : Nothing
 * DD_F_DEREF_F <-> DD_R_DEREF_DEREF : Nothing
 * DD_F_DEREF_F <-> DD_R_DEREF_F : Nothing
 *
 * DD_R_DEREF <-> DD_R_DEREF : DD_R_DEREF <B> DD_R_DEREF
 * DD_R_DEREF <-> DD_R_DEREF_DEREF : DD_R_DEREF_DEREF R> DD_R_DEREF
 * DD_R_DEREF <-> DD_R_DEREF_F : DD_R_DEREF_F R> DD_R_DEREF
 *
 * DD_R_DEREF_DEREF <-> DD_R_DEREF_DEREF : DD_R_DEREF_DEREF <R> DD_R_DEREF_DEREF
 * DD_R_DEREF_DEREF <-> DD_R_DEREF_F : DD_R_DEREF_F R> DD_R_DEREF_DEREF
 * 
 * DD_R_DEREF_F <-> DD_R_DEREF_F : Nothing
 */

typedef enum Exposed_Level {
    DD_A_DEREF = 1,		
    DD_A_DEREF_DEREF = 2,
    DD_A_DEREF_F = 4,
    DD_G_G_F = 8,
    DD_G_DEREF = 16,
    DD_F_DEREF = 32,
    DD_F_DEREF_DEREF = 64,
    DD_F_DEREF_F = 128,
    DD_R_DEREF = 256,
    DD_R_DEREF_DEREF = 512,
    DD_R_DEREF_F = 1024
} Exposed_Level;

#define DD_ARGUMENT_LEVELS	(DD_A_DEREF | DD_A_DEREF_DEREF | DD_A_DEREF_F)
#define DD_GLOBAL_LEVELS	(DD_G_G_F | DD_G_DEREF)
#define DD_FORMAL_LEVELS	(DD_F_DEREF | DD_F_DEREF_DEREF | DD_F_DEREF_F)
#define DD_FUNC_RETURN_LEVELS	(DD_R_DEREF | DD_R_DEREF_DEREF | DD_R_DEREF_F)

typedef enum Exposed_Class {
    DD_FORMAL = 1,
    DD_GLOBAL = 2,
    DD_ARGUMENT = 3,
    DD_FUNCTION_RETURN = 4
} Exposed_Class;

/* Used by Omega test to initialize tag field */
#define UNTAGGED -1

typedef enum Node_Type {
    DUMMY_NODE = 0,
    SRC_NODE = 1,
    DEST_NODE = 2,
    BOTH = 3,
} Node_Type;

typedef enum Phase {
    real_phase,
    pseudo_phase,
} Phase;

typedef struct _AliasGroup {
    char *delta;
    int sign;
    int group;
} _AliasGroup, *AliasGroup;

/*
 * Contains info for an entry in the Data Dependence symbol table
 * There is one of these structures for each unique variable name accessed
 * in the function.  (Variable names include function call names.)
 */ 
typedef struct _DDSymEntry {
	char *var_name;		/* coded name of variable accessed */
	char *old_var_name;	/* full name of variable accessed w/o scope */
	char *symbolic_name;	/* full name of variable accessed w scope */
	bool is_fetched;	/* true if variable read in function */
	bool is_stored;		/* true if variable written in function */
	bool is_array;		/* true if variable accessed as array in func*/
	bool is_funcparam;	/* true if variable is formal param to func */
	bool is_arg_ret;	/* true if variable is argument or ret value */
	bool is_recursive;	/* true if variable access is recursive */
	Exposed_Level exposed_levels;	/* bit values */
	struct _DDSymType *first_type;	/* list of types for the variable */
	int tag;		/* Used for identifying var in omega test */
				/* Must by UNTAGGED initially */
	Var_Class var_class;	/* Must be local, global, or function name */
	int var_offset;		/* Offset into structure var for equiv. vars */
	Node alias_node;	/* Alias graph node for var. access */
	Set loop_nests_mod;	/* Set of loop nest indicies which modify 
				   this variable or aliases (depend. analysis)*/
	int df_index;		/* index into variable array of FlowNode,
				   Only used for data flow analysis */
	bool is_in_sub;		/* true if variable used in subscipt expr in 
				   current BB.  Only used for array load elim.*/
	VarDcl base_vardcl;     /* VarDcl of base variable of access (i.e. 
				   A.b.c would have A as base variable) */
	bool ptr_modified;	/* true if the ptr which is the base for this
				   access is updated (e.g. incremented) in
				   the function */
	Lptr src_list;		/* pointer to the list of src nodes */
	Lptr dest_list;		/* pointer to the list of dest nodes */
	Lptr suffix_list;	/* pointer to other nodes which contain this */
	Lptr prefix_list;	/* pointer to other nodes which are contained */
	AliasGroup alias_group;
} _DDSymEntry, *DDSymEntry;

/* for Alias Graph -- arc type definitions */
typedef enum Arc_Type {
    FWD_ALIAS_ARC = 1,
    REVERSE_ALIAS_ARC = 2,
} Arc_Type;

typedef struct A_Arc {
    void *src;
    void *dest;
    Arc_Types type;
    int group;
} _A_Arc, *A_Arc;

/* 
 * Contains info for the type a variable is cast to.
 * Used to alias accesses of a single variable which may be of different
 * types.  In this case, subscript analysis is not accurate and conservative
 * assumptions are used.  The DDSymType's for a DDSymEntry are kept in a 
 * linked-list data structure.
 */
typedef struct _DDSymType {
	bool has_type;			/* True if variable is cast to a type */
	int typeid;			/* type ID for variable cast */
	char *struct_name;		/* name of structure for variable cast*/
	struct _DDSymType *next_type;	/* variable with same name, diff type */
	struct _a_access *first_access; /* first access to variable with type */
	struct _DDSymEntry *sym_entry;	/* pointer to the symbol table entry */
	struct _ArrSub *arr_sub;	/* pointer to array subscript list
					   used by array load elimination */
	struct _ArrElem *arr_elem;	/* pointer to array element list
					   used by scalar replacement */
	Type type;			/* type of access */
	int num_inherited_subi;		/* number of sub_iters in a_access
					   not directly associated with this
					   access, i.e. for access **a, # of
					   sub_iters of *a */
} _DDSymType, *DDSymType;


/* 
 * Contains information for an instance of a variable access used by the omega 
 * dependence analyzer.
 * It is attached to a variable expression extension field during access table
 * construction.
 * The a_access' for a DDSymType are kept in a linked-list data structure.
 */
typedef struct _a_access {	
	Expr acc_expr;		/* Pcode variable access expression */
	Expr var_expr;		/* Pcode variable expression */
	FlowNode flow_node;	/* pointer to flow node where access occurs */
	char *text; 		/* Charlie variable access string */
	struct _DDSymType *sym_type; 	/* type for this variable access */
	uint access_depth;	/* loop nesting depth of dependence 
				   may not be accurate after transformations! */
	bool is_index;		/* Is the variable an index variable */
	uint index_depth;	/* If index var, depth of nesting for loop */
	bool is_fetch;		/* is access a memory fetch? */
	bool is_store;		/* is access a memory store? */
	bool ptr_func_arg;	/* is access an argument to a func call */
	bool entire_extent;	/* is access to entire variable? */
	bool is_explicit;	/* is access explicit in Pcode or not */
			    /* Only false for final and cond expr before */
			    /* short-circuit path of Parloop & Serloop stmts */
	struct _sub_iterator *first_subi;  /* the first subscript iterator */
	context_iterator first_context;	   /* the first context iterator */
	struct _a_access *next_access; 	   /* the next access to the variable */
	struct ddnode *nodeddin;  /* dependences for which access is dest. */
	struct ddnode *nodeddout; /* dependences for which access is source */
	Stmt temp_stmt;		/* temporary pointer to a statement */
	int df_index;		/* index into access array of FlowNode,
				   Only used for data flow analysis */
        int dep_prag_num;       /* unique dep arc number for this access */
	struct _ArrRef *arr_ref;/* pointer to array reference instance,
				   Only used for scalar replacement */ 
	Lptr hidden_access;	/* BCC - point to accesses in the callee */
	struct _a_access *jsr_access;	/* BCC - an access may come implicitly
					   from a jsr */
} _a_access, *a_access;

typedef a_access var_id;
typedef _a_access _var_id;

typedef struct AccNameHistory {
    Type type;
    char name[DD_MAX_STRING+1];
} _AccNameHistory, *AccNameHistory;

typedef struct SymEntriesPair {
    Arc_Types type;
    DDSymEntry src;
    DDSymEntry dest;
} _SymEntriesPair, *SymEntriesPair;

typedef struct StringPair {
    Arc_Types type;
    char src_str[DD_MAX_STRING+1];
    char dest_str[DD_MAX_STRING+1];
} _StringPair, *StringPair;

typedef struct Callee {
    char *name;
    int indirect;
    Lptr callee_list;		/* list of indirect callee names */ 
    Lint scope_list;		/* list of callsite lists */
    Lint return_scope_list;	/* light-weight scope list */
    Expr expr;			/* any expr node of this callname */
} _Callee, *Callee;

/******************************************************************************
  Stucture for maintaining ExprList
*******************************************************************************/

	/* used by C analysis to make a list of exprs which may form the
	   RHS of an assignment.  A list is required to handle nested ?: 
	   structures */
typedef struct _ExprList {	
    Expr		expr;
    int			is_addr_expr;
    struct _ExprList	*next;
} _ExprList, *ExprList;


/******************************************************************************
  Stucture for maintaining vararg functions
*******************************************************************************/

typedef struct VarargFuncInfo {
    char *name;
    int	 init_vararg_loc;
} _VarargFuncInfo, *VarargFuncInfo;

#define MAX_SEGMENTS	128

/******************************************************************************
  Stucture for maintaining derived references
*******************************************************************************/

typedef struct DerivedRadius {
    void *sym_entry;
    char *extended_radius;
} _DerivedRadius, *DerivedRadius;

/******************************************************************************
  Utility Functions (for debugging and other modules) 
*******************************************************************************/

#include <Pcode/dd_data-dep.h>
#include <Pcode/depend.h>

/* Create a new subscript iterator structure */
extern sub_iterator NewSubscriptIterator();

/* Remove a subscript iterator structure chain */
extern void RemoveSubscriptIterator(sub_iterator si);

/* Create a new string pair structure */
extern StringPair NewStringPair();

/* Remove a string pair */
extern void RemoveStringPair(StringPair);

/* Create a new callee structure */
extern Callee NewCallee();

/* Remove a callee */
extern void RemoveCallee(Callee);

/* Create a new alias arc */
extern A_Arc NewA_Arc();

/* Create a new alias arc with data */
extern A_Arc NewA_ArcWithData(void *, void *, Arc_Types);

/* Remove a new alias arc */
extern void RemoveA_Arc(A_Arc);

/* Create a new derived radius */
extern DerivedRadius NewDerivedRadius(void *, char *);

/* Remove a derived radius */
extern void RemoveDerivedRadius(DerivedRadius);

/* Remove the access table for the given func->depend (internal) */
extern void RemoveAccessTable(FuncDepend fd);

/* Print Access Table Information for Single Access */
extern void DD_Print_Single_Access(FILE *file, a_access acc);

/* Print Access Table Information for Single Variable */
extern void DD_Print_Access_Table_Var(FILE *file, DDSymEntry sym_entry);

/* Print all Access Table Information for given function */
extern void DD_Print_Entire_Access_Table(FILE *file, FuncDcl func);

/* Check whether expr is an iteration_var expr in a _ParLoop structure. */
extern bool Is_Iteration_Var_Expr(Expr expr);

/* Check whether expr is a dimension variable created by f2c. */
extern bool Is_Dimension_Var_Expr(Expr var_expr);

/* Get access expression from variable expression, also get offset into
   structure IF equivalenced access.  If not equiv. access, offset is set
   to zero. */
extern Expr DD_VarRec_Get_AccExpr(Expr var_expr, int *offset, 
				  bool *entire_extent, Expr *index_expr);

/* Find out the common prefix */
extern int DD_Length_Common_Prefix(char *s1, char *s2);

/* Find out if the sym_entry is used as a return value */
extern int DD_SymEntry_Is_Return(DDSymEntry sym_entry);

/******************************************************************************
  External Functions (for transformations and optimizations) 
*******************************************************************************/

/* 
 * Build Variable Access Table for a function:
 *
 * This function builds a variable access symbol table for all the variables
 * in the function.  Variables which can be accessed as different types
 * are separated according to type into the DDSymType structures for each
 * access table entry.  Different accesses to the same variable are each given
 * a unique access structure (a_access) within a DDSymType structure.
 *
 * An alias graph is constructed between access table entry (DDSymEntry) 
 * to show which variables can possibly be aliased to others.
 *
 * In addition, array accesses are delinearized in the current implementation
 * and the appropriate scalar forward substitutions will be done for the
 * subscript expressions in a later version.
 *
 * CURRENTLY, ONLY FUNCTIONS THAT ARE GENERATED USING F2C ARE SUPPORTED! <----
 * Two checks are made before calculating data dependence.  First, a check
 * is made to see if the current file had a source comment indicating f2c 
 * translation.  If not, this function returns the value FALSE.  The access 
 * table is unusable in this case.  Similarly, if a pragma with specifier "not 
 * f2c" is present for the function, then FALSE is returned.  This allows one 
 * to skip dependence analysis of C functions added to the end of a file 
 * generated by f2c.  
 *
 * IF YOU RUN DATA DEPENDENCE ON A C FUNCTION, THE COMPILER WILL MOST LIKELY
 * PUNT.  IF IT DOES NOT, THE RESULTS WILL ALMOST CERTAINLY BE INVALID.
 *
 * Returns whether or not the access table could be generated.
 * If access table could not be calculated due to unsupported input,
 * returns value of FALSE, which indicates no access table was created.
 *
 * This function Creates an access table and stores index of the table in
 * the depend field of a FuncDcl structure.
 * The access table contains entries of type DDSymEntry, one for each
 * distinct variable in the program.   
 *
 * An example calling code for dependence analysis for a transformation that
 * is to be applied to a function is as follows:
 *
 *   if (!DD_Function_Has_Access_Table(func) &&
 *      (!DD_Build_Access_Table_Func(func))) {
 *
 *        if (debug_yes || verbose_yes) {
 *            fprintf(Flog,
 *                    "___ NOT performed on fn (%s) due to lack of access table.
\n",
 *                    func->name);
 *        }
 *        return;  / * exit transformation * /
 *    }
 *
 * Note that the transformation writer needs to check whether the access table
 * analysis failed (because of Non-F2c code) and print the appropriate error
 * message (substitute transformation name for "___").
 *
 * Use C_forall() in library/libc/c_symbol.h along with the access
 * table index in func->depend->acc_tbl to iterate through all the variables
 * in the access table. 
 *
 * There are pointers both from accesses in the access table to pcode var
 * expressions (var_expr field in a_access structure) and from the var
 * expressions back to the accesses (acc field of Expr structure).
 *
 * Also, there are pointers from the accesses to the corresponding flow node 
 * in the flow_node field of the a_access structure. 
 *
 * See Build_Statement_Dependence_Graph and Copy_Dependences_To_Stmt_Graph in
 * lt_distribution.c for an example of use of the access table.
 */

extern bool DD_Build_Access_Table_Func(FuncDcl func);

/*
 * Returns whether or not variable access information is present for function. 
 * Use this before calling DD_Build_Access_Table_Func() to make sure 
 * redundant computation is avoided.
 */
extern bool DD_Function_Has_Access_Table(FuncDcl func);

/*
 * Free the access table and all associated dependence and data-flow 
 * information.  
 *
 * IMPORTANT!:
 *
 * This routine must be called whenever there is a modification made to
 * Pcode which changes an access to a variable, creates a new variable access
 * or destroys a variable access.  Otherwise the information in the table
 * will be incosistent and memory allocation could be corrupted.
 */

extern void DD_Free_Access_Table(FuncDcl func);

/* 
 * Check whether a variable access is within the body of the given loop stmt 
 *
 * The loop_stmt must be of type ST_PARLOOP. 
 */
extern bool Access_Within_Loop(a_access acc, Stmt loop_stmt);

/*
 * Connect all accesses to corresponding flow nodes in the control flow
 * graph for the given function.
 *
 * I don't know if this is actually useful to call from outside
 * DD_Build_Access_Table_Func().
 */
extern void DD_Connect_Accesses_To_Flow(FuncDcl func);

extern int DD_Sym_Entries_Aliased (DDSymEntry src_sym_entry, 
				   DDSymEntry dest_sym_entry, int dir);
/*
extern void DD_find_all_prefix_aliases (char *name, int type, Integer value,
					Pointer ptr);
*/
extern void DD_find_all_prefix_aliases (int cur_acc_tbl, char *lhs_name,
					char *rhs_name);


extern int DD_length_of_common_prefix (char *str1, char *str2);
extern void DD_Add_Pseudo_Parameter_Return_Assignment(FuncDcl);


extern int assume_C_semantics;

extern char *lhs_name;
extern char *rhs_name;
extern char search_name[DD_MAX_STRING];
extern DDSymEntry lhs_sym_entry;
extern int ACC_TBL_SIZE;
extern unsigned char *adj_matrix;
extern int cur_acc_tbl, temp_acc_tbl;
extern FILE *pip_file;
extern Lptr callee_info_ptr;
extern Lptr callee_ptr;
extern Lptr callname_ptr;
extern Lptr visited_struct_union_ptr;
extern void Add_Red_Direct_Arc(DDSymEntry, DDSymEntry);
extern void Add_Red_Indirect_Arc(DDSymEntry, DDSymEntry);
extern void Add_Green_Arc(DDSymEntry, DDSymEntry);
extern void Add_Blue_Arc(DDSymEntry, DDSymEntry);
extern void Add_Black_Arc(DDSymEntry, DDSymEntry);
extern void DD_add_red_dd_arc(DDSymEntry, DDSymEntry, int, int);
extern void DD_add_red_di_arc(DDSymEntry, DDSymEntry, int, int);
extern void DD_add_red_id_arc(DDSymEntry, DDSymEntry, int, int);
extern void DD_add_red_ii_arc(DDSymEntry, DDSymEntry, int, int);
extern void DD_add_green_arc(DDSymEntry, DDSymEntry, int, int);
extern void DD_add_blue_dd_arc(DDSymEntry, DDSymEntry, int, int);
extern void DD_add_blue_di_arc(DDSymEntry, DDSymEntry, int, int);
extern void DD_add_blue_id_arc(DDSymEntry, DDSymEntry, int, int);
extern void DD_add_blue_ii_arc(DDSymEntry, DDSymEntry, int, int);
extern void DD_add_black_arc(DDSymEntry, DDSymEntry, int, int);
extern a_access NewAccess();
extern DDSymType NewSymType();
extern char *DD_bcc_VarRec_Get_AccName_CSem(Expr, Expr, bool, bool, bool *);
extern bool DD_type_contains_function_pointers(Type type);
extern bool DD_impossible_name(char *);
extern bool DD_non_full_access_name(char *);
extern void DD_generate_access_pattern(FuncDcl);
extern void DD_read_max_indir_level();
extern int DD_break_name_into_segments(char *, char *[]);
extern bool DD_sym_entries_proper_prefix(char *, char *, char *, char *);
extern int node_format;
extern A_Arc DD_EntryInList(void *, Lptr, Node_Type);
extern void DD_RemoveA_ArcList(Lptr);
extern void DD_compact_name(char *name, char *dest);
bool DD_name1_is_prefix_of_name2_compacted(char *, char *, char *);
DerivedRadius InLptr_DerivedRadius(Lptr, Void *);
extern void DD_generate_access_name(FuncDcl);
extern int DD_AnalyzeEntryClass(char *);
extern char *DD_get_access_name(Expr expr);
extern DDSymEntry DD_find_and_add_empty_sym_entry(char *, Expr, int);

#endif
