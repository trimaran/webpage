/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File: PM_txtLexan.cpp
// Author: Rodric M. Rabbah
//
// The ReaCT-ILP Research Group may be contacted at react-ilp@cs.nyu.edu
///////////////////////////////////////////////////////////////////////////////

#include "PM_txtLexan.h"
#include "PM_assert.h"

#include "PM_event.h"

#include <ctype.h>

/////////////////////////////////////////////////////////////////////
// NULL constructor, bindStream must be used to initialize input 
// stream
/////////////////////////////////////////////////////////////////////
PM_txtLexan::PM_txtLexan(void):_isBound(true), _lineNum(1), _stackFull(false)
{
    // assign the input stream to standard input
    _file = new ifstream(0);
}

/////////////////////////////////////////////////////////////////////
// if successful, binds file to input stream
/////////////////////////////////////////////////////////////////////
PM_txtLexan::PM_txtLexan(char* fileName): _isBound(false)
{
    bindStream(fileName);
}

/////////////////////////////////////////////////////////////////////
// close file handle
/////////////////////////////////////////////////////////////////////
PM_txtLexan::~PM_txtLexan(void)
{
    if ( _isBound ) {
	(*_file).close(); 
	_isBound = false;
    }

    delete _file;
}

/////////////////////////////////////////////////////////////////////
// attempts to bind file to input stream, exits on failure
/////////////////////////////////////////////////////////////////////
int PM_txtLexan::bindStream(char* fileName)
{ 
    if ( _isBound ) {
	cerr << "Warning: PM_txtLexan already bound... redirecting!"
	     << endl;
	    
	(*_file).close();
	delete _file;
    }
    
    // assign the input stream to standard input when a null file
    // name is speficied
    if ( fileName == NULL ) _file = new ifstream(0);
    else _file = new ifstream(fileName, ios::in);
    
    if ( (*_file).bad() ) {
	cerr << "Error:  could not open file <" << fileName << ">!" << endl;
	exit (1);
    }
    
    (*_file).unsetf(ios::skipws);
    _isBound = true;
    _lineNum = 1;
    _stackFull = 0;
    
    return true;
} 

/////////////////////////////////////////////////////////////////////
// reads a token from lexan
// if token type is a string, then extend its value, otherwise
// returns current token type
/////////////////////////////////////////////////////////////////////
int PM_txtLexan::getToken(void)
{
    return (PM_txtLexan::getToken(_token));
}

int PM_txtLexan::getToken(PM_token& token)
{
    readToken();
    
    token = _token;
    _stackFull = 0; 
    
    switch ( token.tokenType() ) {
    case _pmSTR:
	return traceKeyWord((char*) token);
	
    case _pmPUNC:
	switch ( char(token) ) {
	case RT_id : return _RT;
	case ON_id : return _ON;
	case ES_id : return _ES;
	default    : return char(token);
	}
	
    default:
	return token.tokenType();
    }
} 

/////////////////////////////////////////////////////////////////////
// Scan a puntuation character, and compare it to parameter.
// Syntax error on failed comaprison
/////////////////////////////////////////////////////////////////////
PM_txtLexan& PM_txtLexan::operator >> (const char& ch)
{
    readToken();
    if ( _token.tokenType() != _pmPUNC )
	syntaxError(_token);
    
    else if ( char(_token) != ch )
	syntaxError(_token);
    
    _stackFull = 0; 
    return *this; 
}

/////////////////////////////////////////////////////////////////////
// Scan a string, and compare it to parameter.
// Syntax error on failed comaprison
/////////////////////////////////////////////////////////////////////
PM_txtLexan& PM_txtLexan::operator >> (const char*& string)
{
    readToken();
    if ( _token.tokenType() != _pmSTR )
	syntaxError(_token);
    else if ( strcmp((char*)_token, string) != 0 )
	syntaxError(_token);
    
    _stackFull = 0; 
    return *this;
}

/////////////////////////////////////////////////////////////////////
// Scan a puntuation character
/////////////////////////////////////////////////////////////////////
PM_txtLexan& PM_txtLexan::operator >> (char& ch)
{
    readToken();
    if ( _token.tokenType() != _pmPUNC )
	syntaxError(_token);
    
    ch = char(_token);
    _stackFull = 0; 
    return *this;
}

/////////////////////////////////////////////////////////////////////
// Scan a string
/////////////////////////////////////////////////////////////////////
PM_txtLexan& PM_txtLexan::operator >> (char*& buffer)
{
    readToken();
    if ( _token.tokenType() != _pmSTR )
	syntaxError(_token);
    
    buffer = (char*)(_token);
    _stackFull = 0; 
    return *this;
}

/////////////////////////////////////////////////////////////////////
// Scan a string
/////////////////////////////////////////////////////////////////////
PM_txtLexan& PM_txtLexan::operator >> (eString& buffer)
{
    readToken();
    if ( _token.tokenType() != _pmSTR )
	syntaxError(_token);
    
    buffer = (char*)(_token);
    _stackFull = 0; 
    return *this;
}

/////////////////////////////////////////////////////////////////////
// Scan an integer
/////////////////////////////////////////////////////////////////////
PM_txtLexan& PM_txtLexan::operator >> (int& i)
{
    readToken();
    if ( _token.tokenType() != _pmINT )
	syntaxError(_token);
    
    i = int(_token);
    _stackFull = 0; 
    return *this;
}

/////////////////////////////////////////////////////////////////////
// Scan a hex number
/////////////////////////////////////////////////////////////////////
PM_txtLexan& PM_txtLexan::operator >> (PM_hex& h)
{
    PM_assert(_stackFull == 0);

    (*_file) >> h;
    
    if ( (*_file).fail() ) {
	static char* errMessage = (char*)"hex-format number expected";
	_token = errMessage;
	syntaxError(_token);
    }
    
    return *this;
}

/////////////////////////////////////////////////////////////////////
// Scan a double
/////////////////////////////////////////////////////////////////////
PM_txtLexan& PM_txtLexan::operator >> (double& d)
{
    PM_assert(_stackFull == 0);

    (*_file) >> d;
    
    if ( (*_file).fail() ) {
	static char* errMessage = (char*)"double expected";
	_token = errMessage;
	syntaxError(_token);
    }
    
    return *this;
}

/////////////////////////////////////////////////////////////////////
// Scan a float
/////////////////////////////////////////////////////////////////////
PM_txtLexan& PM_txtLexan::operator >> (float& f)
{
    PM_assert(_stackFull == 0);

    (*_file) >> f;
    
    if ( (*_file).fail() ) {
	static char* errMessage = (char*)"float number expected";
	_token = errMessage;
	syntaxError(_token);
    }
    
    return *this;
}

/////////////////////////////////////////////////////////////////////
// determines if the current char-string is an event
// case RT_id is handled by getToken
// case ON_id is handled by getToken
// case ES_id is handled by getToken
/////////////////////////////////////////////////////////////////////
int PM_txtLexan::traceKeyWord(const char* buffer)
{
    switch ( toupper(buffer[0]) ) {	  
    case LOAD_id:
	switch ( toupper(buffer[1]) ) {
	case BYTE_id  : return _LB;
	case HWORD_id : return _LH;
	case WORD_id  : return _LW;
	case FLOAT_id : return _LS;
	case DOUBL_id : return _LD;
	default       :	break;
	}
	
    case STORE_id:
	switch ( toupper(buffer[1]) ) {
	case BYTE_id  : return _SB;
	case HWORD_id : return _SH;
	case WORD_id  : return _SW;
	case FLOAT_id : return _SS;
	case DOUBL_id : return _SD;
	default       :	break;
	}
	
    case PE_id : return _PE;
    case BE_id : return _BE;
    case OE_id : return _OE;
    case RW_id : return _RW;
    default    : return _pmSTR;
    }
}

/////////////////////////////////////////////////////////////////////
// The lexical analyzer, fetches the next token in the istream
// non-punctuation characters are treated a strings, 
// numbers treated as doubles
/////////////////////////////////////////////////////////////////////
void PM_txtLexan::readToken(void)
{
    // if token already exists, then done
    if ( _stackFull )
	return;
    
    static char next_char;
    static char curr_char;
    
    skipSpace();
    next_char = (*_file).peek();
    
    if ( (*_file).eof() )
	_token.setEOF();
    
    // read number
    else if ( isdigit(next_char) ) {
	static int num;
	(*_file) >> num;
	
	if ( (*_file).fail() )
	    syntaxError(_token);
	
	_token = num;
    } // end number scan
    
    // read a string
    else if ( isalpha(next_char) || (next_char == UNDRSCR) ) {
	int i = 0;
	while ( (*_file).get(curr_char) ) {
	    if( isalnum(curr_char) || (curr_char == UNDRSCR) || (curr_char == PERIOD) )
		_buffer[i++] = curr_char;
	    else {
		(*_file).putback(curr_char);
		break;
	    }
	}
	_buffer[i] = '\0';
	_token = _buffer;
    } // end string scan
    
    // read a punctuation character
    else if ( ispunct(next_char) ) {
	(*_file) >> curr_char;
	if ( (*_file).fail() )
	    syntaxError(_token);
	
	_token = curr_char;
    } // end punctuation character scan
    
    else // unknow event
	PM_assert(0);
} // end lexical analyzer


/////////////////////////////////////////////////////////////////////
// if _stackFull flag is not asserted, assert it, otherwise
// abort, can not push token
/////////////////////////////////////////////////////////////////////
void PM_txtLexan::putBackToken(void)
{
    if ( _stackFull ) {
	cerr << "Can't put back token. Stack already full" << endl;
	exit(0);
    }
    
    _stackFull = 1;
} // end putBackToken

/////////////////////////////////////////////////////////////////////
// reads characters to the end of a line
/////////////////////////////////////////////////////////////////////
void PM_txtLexan::skipLine(void)
{
    static char c;
    while ( 1 )	{
	(*_file) >> c;
	if ( ((*_file).eof()) || (c == NEW_LINE) ) {
	    _lineNum++;
	    return;
	}
    }
} // end skipLine

/////////////////////////////////////////////////////////////////////
// skips all white space, and comments
/////////////////////////////////////////////////////////////////////
void PM_txtLexan::skipSpace(void)
{
    static char c;
    
    while ((*_file).get(c)) {
	if ( c == NEW_LINE )     _lineNum++;
	else if ( isspace(c) )   continue;
	else if ( c == COMMENT ) skipLine();
	
	else break;
    }
    
    (*_file).putback(c);
} // end skipSpace

/////////////////////////////////////////////////////////////////////
// outputs syntax error, and exits
/////////////////////////////////////////////////////////////////////
void PM_txtLexan::syntaxError(PM_token& token)
{
    cerr << "Syntax error, line " << _lineNum 
	 << " at token <" << token << ">"
	 << endl;
    exit(1);
} // end syntaxError
