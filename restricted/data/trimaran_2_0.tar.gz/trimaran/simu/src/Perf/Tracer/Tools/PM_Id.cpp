/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File: PM_Id.cpp
// Author: Rodric M. Rabbah
//
// The ReaCT-ILP Research Group may be contacted at react-ilp@cs.nyu.edu
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
// Description: I/O support for PM_Id class
///////////////////////////////////////////////////////////////////////////////

#include "PM_Id.h"
#include "PM_hash_utilities.h"

// constructors and destructors
PM_Id::PM_Id():_index(1){}

PM_Id::PM_Id(const PM_Id& current):
    _index(current._index), _string(current._string){}

PM_Id::PM_Id(int value):
    _index(value){}
  
PM_Id::~PM_Id(){}


/////////////////////////////////////////////////////////
// assignment
/////////////////////////////////////////////////////////
PM_Id& PM_Id::operator = (const PM_Id& current)
{
    _index  = current._index; 
    _string = current._string;
    return *this;
}

PM_Id& PM_Id::operator = (int index)
{
    _index = index;
    _string = NULLstr;
    return *this;
}

/////////////////////////////////////////////////////////
// increment current index prefix/postfix
/////////////////////////////////////////////////////////
PM_Id& PM_Id::operator ++ () // prefix
{
    _index++;
    _string = NULLstr;
    return *this;
}

PM_Id& PM_Id::operator ++ (int) // postfix
{
    static PM_Id retVal;
  
    retVal._index  = _index;
    retVal._string = _string;
  
    _index++;
    _string = NULLstr;
    return retVal;
}


/////////////////////////////////////////////////////////
// set the _string member to requested value
/////////////////////////////////////////////////////////
PM_Id& PM_Id::setString(const eString& string)
{
    _string = string;
    return *this;
}


////////////////////////////////////////////////////////////
// binds file and procedure names to individual maps, to
// avoid name collision.  PM_Id is used as the hashing key
// for the window_tree
////////////////////////////////////////////////////////////
PM_Id& PM_Id::bindId(bindingMap whichMap, const eString& string)
{
    static Hash_map<eString, PM_Id> _fileMap(hash_eString, MAX);
    static Hash_map<eString, PM_Id> _procMap(hash_eString, MAX);
  
    static Hash_map<eString, PM_Id>* map;
    static PM_Id currentId;
  
    switch ( whichMap ) {
    case _FILEMAP : map = &_procMap; break;
    case _PROCMAP : map = &_fileMap; break;
    }

    if ( map->is_bound(string) )
	return map->value(string);

    currentId.setString(string);  
    map->bind(string,currentId);
    return currentId++;
}


////////////////////////////////////////////////////////////
// the rebel data region is assigned a special
// hashingkey
////////////////////////////////////////////////////////////
PM_Id& PM_Id::assignDataRegionName(void)
{
    static eString prefix;
    static char    suffix = 'a';
    if ( suffix > 'z' )
	suffix = 'a';

    prefix = "~__data_";
    prefix.cat((char) suffix++);

    return bindId(_PROCMAP, prefix);
}

////////////////////////////////////////////////////////////
// I/O
////////////////////////////////////////////////////////////
ostream& operator << (ostream& os, const PM_Id& x)
{ 
    if ( x._string == "" ) os << x._index; 
    else os << x._string;
    return os; 
}

