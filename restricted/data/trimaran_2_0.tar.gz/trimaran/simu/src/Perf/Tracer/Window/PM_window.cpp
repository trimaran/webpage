/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File: PM_window.cpp
// Author: Rodric M. Rabbah
//
// The ReaCT-ILP Research Group may be contacted at react-ilp@cs.nyu.edu
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Description: The interface to the tracer, builds the
//              configuration_file_specified region map
///////////////////////////////////////////////////////////////////////////////

#include "PM_window.h"
#include "PM_assert.h"
#include "PM_hash_utilities.h"

// rebel reader and support
#include "ir_reader.h"
#include "iterators.h"

// the profile is printed to rebel_file_name.profile
const eString PROFILE_EXTENSION_STRING = ".profile";

// header_printed is found in ir_writer.cpp, must be reset
// to ensure that header is printed for every elcor file
extern int header_printed; 

template<class T>
PM_window<T>::PM_window(void): 
    _root(NULL), _isBound(false), _isInit(false), _in(NULL), _verbose(false){};

template<class T>
PM_window<T>::PM_window(char* fileName, const bool verbose): 
    _root(NULL), _isBound(false), _isInit(false), _in(NULL), _verbose(verbose)
{ 
    if ( bindFile(fileName) ) { 
	loadWindow(); 
	flattenMap();
    }
}

template<class T>
PM_window<T>::~PM_window(void) 
{ 
    // delete the nodes of the tree first
    if (_root != NULL)
      _root->deleteTree();

    // now the _root can be deleted
    delete _root; 

    delete _in; 
}

/////////////////////////////////////////////////////////////////////
//  Binds configuration file to window object
//  return true upon success, otherwise false
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::bindFile(char* fileName)
{
    if ( fileName == NULL ) {	
	// cerr << "Warning: no file name specified to PM_Window constructor!" 
	//      << endl;
	return false;
    }

    if ( _isBound ) {
	cerr << "Error: window object already bound to file <"
	     << _fileName << ">, reassigning to <" 
	     << fileName  << ">"
	     << endl;
    }

    _isBound  = true;
    _isInit   = false;
    _fileName = fileName;
    _root     = new T;
    
    return true;
} // end bindFile

/////////////////////////////////////////////////////////////////////
//  Parses configuration file, and loads requested monitoring regions
//  to data structures from specified elcor files
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::loadWindow(void)
{
    if ( ! _isBound ) {
	cerr << "Error: Window object not bound to file!"
	     << endl;
	exit(1);
    }
    
    // binds configuration file to parser
    if ( (char*) _fileName == NULL ) {
	cerr << "Invalid file name parameter to PM_window!" << endl;
	exit(0);
    }
    _in = new PM_windowLexan(_fileName);

    if (_verbose)
	cout << "Loading Window..." << endl;

    _isInit = buildTree(*_root);

    if (_verbose)
	cout << "Finished Loading Window..." << endl;

} // end loadWindow

/////////////////////////////////////////////////////////////////////
//  interface method, if key is found in root's hashmap, return
//  a pointer to the node, otherwise return NULL
/////////////////////////////////////////////////////////////////////
template<class T>
T* PM_window<T>::validProcedure(eString& procName)
{
    if ( ! _isBound ) return NULL;

    PM_Id key = PM_Id::bindId(_PROCMAP, procName);
    return ( (T*) _root->valid(key) );
} // end validProcedure

template<class T>
T* PM_window<T>::validProcedure(PM_Id& key)
{
    if ( ! _isBound ) return NULL;

    return ( (T*) _root->valid(key) );
} // end validProcedure

template<class T>
T* PM_window<T>::get_PM_PROC(const eString& procName) const
{
    if ( ! _isBound ) return NULL;
    
    PM_Id key = PM_Id::bindId(_PROCMAP, procName);
    return ( (T*) _root->valid(key) );
}

template<class T>
T* PM_window<T>::get_PM_CB(const eString& procName, const int blockId) const
{
    T* proc = get_PM_PROC(procName);

    if ( proc != NULL )	{
	PM_Id key = blockId;
	return ( (T*) proc->valid(key) );
    }
    
    return NULL;
}

template<class T>
Region* PM_window<T>::get_Rebel_PROC(const eString& procName) const
{
    T* proc = get_PM_PROC(procName);

    if ( proc != NULL ) return ( proc->getRebelRegion() );
    else return NULL;
} // end getCompoundRebelRegion for procedure

template<class T> 
Region* PM_window<T>::get_Rebel_CB(const eString& procName, const int blockId) const
{
    T* cb = get_PM_CB(procName, blockId);

    if ( cb != NULL ) return ( cb->getRebelRegion() );
    else return NULL;
} // end getCompoundRebelRegion for bb, hb

template<class T>
Region* PM_window<T>::get_Rebel_OP(const eString& procName, 
				   const int blockId, const int opId) const
{
    Region* region = get_Rebel_CB(procName, blockId);

    if ( region != NULL ) {
	Region_subregions region_ptr(region); 
	for ( ; region_ptr != 0; region_ptr++) { 
	    if ( (*region_ptr)->is_op() && ((*region_ptr)->id() == opId) )
		return (*region_ptr);
	}
	    
	cerr << "Warning: Profiler backend error, OP " << opId 
	     << " not found in CB " << blockId << " procedure " 
	     << procName << endl;
    }

    return NULL;
} // end getOpRebelRegion

/////////////////////////////////////////////////////////////////////
// prints usefull information when true or 
// operates silently when false
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::setVerboseMode(const bool option)
{
    _verbose = option;
}

/////////////////////////////////////////////////////////////////////
//  for each subFile in the root's hashmap, create a new file
//  with the same name as the elcor file, with the 
//  PROFILE_EXTENSION_STRING appended to it, and write the rebel
//  regions
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::writeProfiledFiles(void)
{
    if ( ! _isInit ) {
	cerr << "Error: Window object not initialized!\n"
	     << "Loading Window... please wait!"
	     << endl;

	loadWindow();
	flattenMap();
    }

    if (_verbose)
	cout << "Writing Profiled Files..." << endl;

    static eString outFileName;
    PM_region* currentFile;

    PM_subRegion_iterator iter(*_root);
    for( ; iter != 0; iter++ ) {
	header_printed = 0;

	currentFile = (*iter);
	
	outFileName = currentFile->getKey().stringVal();
	outFileName.cat(PROFILE_EXTENSION_STRING);

	IR_outstream* profile_El_OUT_STREAM = new IR_outstream(outFileName);

	PM_subRegion_iterator procIter(*currentFile);
	for ( ; procIter != 0; procIter++ ) {
	    (*procIter)->print(cout, profile_El_OUT_STREAM);
	}
      
	delete profile_El_OUT_STREAM;
    }

    if (_verbose)
	cout << "Done Writing Profiled Files!" << endl;
    
} // end writeProfiledFiles

/////////////////////////////////////////////////////////////////////
//  DFS driver:
//  for all subfiles in root flatten(root, subfile)
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::flattenMap(void)
{
    if ( ! _isInit ) {
	cerr << "Error: Window object not initialized!\n"
	     << "initialization in progress... please wait!"
	     << endl;
      
	loadWindow();
    }

    if (_verbose)
	cout << "Flattening Map..." << endl;

    PM_region* currentFile;
    PM_subRegion_iterator iter(*_root);

    for( ; iter != 0; iter++ ) {
	currentFile = *iter;
	flattenMap(*_root, *currentFile);
    }

    if (_verbose)
	cout << "Map flattened successfuly." << endl;

} // end flattenMap driver

/////////////////////////////////////////////////////////////////////
//  add all valid procedures to the root's flatmap, and
//  add all valid bb, hb, lb to their parent procedure's
//  flatmap
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::flattenMap(PM_region& root, PM_region& parent)
{
    PM_region* child;
    PM_subRegion_iterator iter(parent);

    for( ; iter != 0; iter++ ) {
	child = (*iter);
      
	switch ( child->getType() ) {
	case _PROC:
	    if ( child->getValidBit() ) {
		root.addToValidMap(child);
		flattenMap(*child, *child); 
	    }
	    break;
	    
	case _LOOP:
	    if ( child->getValidBit() ) {
		root.addToValidMap(child);
		flattenMap(root, *child); 
	    }
	    break;
	
	case _BB: case _HB:
	    if ( child->getValidBit() ) {
		root.addToValidMap(child);
		flattenMap(*child, *child); 
	    }
	    break;
	
	case _OP: 
	    if ( child->getValidBit() )
		root.addToValidMap(child);
	    break;

	case _DATA: break;
	
	default: PM_assert(0);
	}
    }
} // end flattenMap


/////////////////////////////////////////////////////////////////////
//  FILE -> subFile; | subFile; File
//  implemented as:
//     FILE -> subFile more_subFile
//     more_subFile -> ; subFile more_subFile | ; epsilon (e*)
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::buildTree(PM_region& _fileMap)
{
    _fileMap.setType(_FILE);
    _fileMap.setKey(PM_Id::bindId(_FILEMAP, (eString) "cfgfile"));
  
    do {	
	PM_region* subFileReg = new T;
	
	subFileReg->setType(_SUBFILE);
	
	if ( subFile(*subFileReg) )
	    _fileMap.bind(subFileReg);
	
	match(SEMICOLON);
	
    } while (_lookAhead != _pmEOF);
  
    return true;
} // end buildTree


/////////////////////////////////////////////////////////////////////
// subFile -> fileName{procReg} | fileName{} | e*
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::subFile(PM_region& currentFile)
{
    static eString rebel_input_file_name;
    int    subExamine = false;
  
    getRebel_InputFile(rebel_input_file_name);
    PM_window::loadRebel(rebel_input_file_name, currentFile);

    match(LEFT_BRACE);
    subExamine = procReg(currentFile);
  
    if ( subExamine ) currentFile.setAllRegion(false);     
    else currentFile.propagate(true);
    match(RIGT_BRACE);

    return true;
} // end subFile parser


/////////////////////////////////////////////////////////////////////
// procRegion -> subProc; | subProc; procRegion
//  implemented as:
//     procRegion   -> subProc more_subProc
//     more_subProc -> ; subProc more_subProc | e* 
//
// return Value of subregion parsing is propagate to calling
// function
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::procReg(PM_region& currentFile)
{
    int retVal = subProc(currentFile);
    int tmpVal;
    while ( 1 )	{
	switch ( _lookAhead ) {
	case SEMICOLON:
	    match(SEMICOLON); 
	    tmpVal = subProc(currentFile);
	    retVal = retVal || tmpVal;
	    break;
	
	default:
	    return retVal;
	}
    }  
} // end procRegion parser


/////////////////////////////////////////////////////////////////////
// subProc -> procName(compReg) | procName() | e*
//
// returns true if subregions are examined, otherwise false
// a return value of true results in the parent's valid bit
// propagation to all its chidlren
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::subProc(PM_region& currentFile)
{
    int examine = false;
  
    switch ( _lookAhead ) {
    case (LEFT_PAREN):
	match(LEFT_PAREN); examine = subProc(currentFile); match(RIGT_PAREN); 
	break;

    case _pmSTR: {
	examine = true;
    
	PM_Id key = PM_Id::bindId(_PROCMAP, (char*)_token);
	PM_region*  currentProc = (PM_region*) currentFile.value(key);
    
	if ( currentProc == NULL ) {	
	    cerr << "PM error: function <" << (char*)_token << "> "
		 << "not found in requested file: " 
		 << currentFile.getKey().stringVal()
		 << endl;
	    exit(1);
	}
	currentProc->setValidBit(true);

	match(_pmSTR);
	match(LEFT_PAREN);
	// if subregions are not examined, then propagate the 
	// parent's valid bit to all its childrenn
	if ( compReg(*currentProc) ) 
	    currentProc->setAllRegion(false); 
	else 
	    currentProc->propagate(true);

	// currentFile.bind(currentProc);
	match(RIGT_PAREN); 
    } break;
    
    default: break;
    }  
  
    return examine;
} // end subProcedure parser


/////////////////////////////////////////////////////////////////////
// compReg -> subCompRegion | subCompRegion, compReg
// implemented as:
//     compReg -> subCompRegion more_subCompRegion
//     more_subCompRegion -> , subCompRegion more_subCompRegion | e*
//
// return Value of subregion parsing is propagate to calling
// function
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::compReg ( PM_region& currentProc )
{
    int retVal = subComp(currentProc);
    int tmpVal;
    while ( 1 )	{
	switch ( _lookAhead ) {
	case (COMMA):
	    match(COMMA); 
	    tmpVal = subComp(currentProc);
	    retVal = retVal || tmpVal;
	    break;
										
	default: return retVal;
	}
    }
} // end compRegion parser


/////////////////////////////////////////////////////////////////////
// subCompRegion -> loop(sCRn) | stat(op) | stat() | stat | e*
//
// loop -> LOOP ID                          sCRn => subCompRegion
// stat -> LOOP ID | subStat
// stat -> BB ID | HB ID
// op   -> OP ID
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::subComp ( PM_region& currentProc )
{
    int examine = false;

    switch ( _lookAhead ) {
    case (LEFT_PAREN):
	match(LEFT_PAREN); examine = subComp(currentProc); match(RIGT_PAREN); 
	break;

    case _wBB: case _wHB:
	examine = parseBlock(currentProc);
	break;

    case _wLOOP:
	examine = parseLoop(currentProc);
	break;

    default: break;
    } 
    
    return examine;
} // end subCompRegion parser

/////////////////////////////////////////////////////////////////////
// LOOP ID | LOOP ID() | LOOP ID(stat) grammar implemented
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::parseLoop( PM_region& currentProc )
{
    int loopNum;
    (*_in) >> loopNum;

    PM_Id key(loopNum);  
    PM_region* currentLoop = (PM_region*) currentProc.value(key);
    if ( currentLoop == NULL ) {
	cerr << "PM error: could not retrieve loop_body "
	     << loopNum << " requested from " 
	     << currentProc.getKey()
	     << endl;
	exit(1);
    }
    currentLoop->setValidBit(true);

    match(_wLOOP);
    switch ( _lookAhead ) {
    case LEFT_PAREN:
	match(LEFT_PAREN);
	if ( parseBlock(*currentLoop) ) currentLoop->setAllRegion(false);
	match(RIGT_PAREN);
	break;
	
    default: break;
    }

    if ( currentLoop->getAllBit() ) currentLoop->propagate(true);
    // currentProc.bind(currentLoop);
    
    return true;
} // end parseLoop


/////////////////////////////////////////////////////////////////////
// BB ID | HB ID | BB ID() | HB ID() | BB ID(op) | HB ID(op) | e*
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::parseBlock( PM_region& currentProc )
{
    if ( ! ((_lookAhead == _wBB) || (_lookAhead == _wHB)) )
	return false;

    int blockNum;
    (*_in) >> blockNum;

    PM_Id key(blockNum);
    PM_region* currentBlock = (PM_region*) currentProc.value(key);
    if ( currentBlock == NULL )	{
	cerr << "PM error: could not retrieve block "
	     << blockNum << " requested from " 
	     << currentProc.getKey()
	     << endl;
	exit(1);
    }
    currentBlock->setValidBit(true);

    match(_lookAhead);  
    if ( checkOp(*currentBlock) )
	currentBlock->setAllRegion(false);
    //  since current implementation
    //  does not create nodes for operations
    //  unless requested in checkOp, then the
    //  following is not necessary:
    //
    //  else currentBlock->propagate(true);
    //  NOTE: recover of operation for viewing a BB/HB is 
    //  done in the filteratore (see process_event_ON)

    //  currentProc.bind(currentBlock);
    return true;
} // end parseBlock


/////////////////////////////////////////////////////////////////////
// parses for an OPeration, and it's id number if any
/////////////////////////////////////////////////////////////////////
template<class T>
int PM_window<T>::checkOp(PM_region& currentBlock)
{
    int examine = false;
    int opNum;

    if ( _lookAhead == LEFT_PAREN ) {
	match(LEFT_PAREN);
      
	switch ( _lookAhead ) {
	case _wOP: {
	    (*_in) >> opNum;

	    PM_region* currentOp = new T;
	    currentOp->setType(_OP);
	    currentOp->setValidBit(true);
	    currentOp->setKey(opNum);
	    
	    // bind to tree
	    currentBlock.bind(currentOp);
								
	    examine = true;
	    (*_in) >> RIGT_PAREN; 
	    match(_wOP);
	} break;
      
	case RIGT_PAREN:
	    match(RIGT_PAREN); 
	    break;
	
	default: (*_in).syntaxError(_token);
	} // end switch
    } // end if
  
    return examine;
} // end checkOp

/////////////////////////////////////////////////////////////////////
// reads the full path and file name of the rebel file in the 
// configuration file.  Target is used by loadRebel() to construct
// tree
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::getRebel_InputFile(eString& file)
{
    static char c;

    // reset file name
    file = NULLstr;

    do {
	// ignore all leading white space, characters, and semicolons
	(*_in).skipSpace();
    } while ( (c = (*_in).getNextChar()) == SEMICOLON );
    
    while ( 1 ) {
	if ((c == UNDRSCR) || (c == BACK_SLASH) || (c == PERIOD) || 
	    isalnum(c) || (c == DASH))
	    file |= c;
	    
	else break;
	
	c = (*_in).getNextChar();
    }
    
    if ( file == NULLstr ) 
	(*_in).syntaxError(_token);
    
    // return the last character read to stream
    (*_in).putBackChar(c);
    
    // then advance the lookAhead token
    match(_lookAhead);
    
} // end getRebel_InputFile


/////////////////////////////////////////////////////////////////////
// advances the _lookAhead token or detects syntax errors
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::match(int token)
{
    if ( _lookAhead == token )
	_lookAhead = _in->getToken(_token);
  
    else (*_in).syntaxError(_token);
} // end _lookAhead match


/////////////////////////////////////////////////////////////////////
// Reads rebel, and create region tree
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::loadRebel(eString& inputFile, PM_region& file)
{
    if (_verbose)
	cout << "Processing Rebel file <" << inputFile << ">" 
	     << endl;

    file.setKey(PM_Id::bindId(_FILEMAP, inputFile));
    file.setValidBit(true);

    El_input_file_name = inputFile;
    EL_IN_STREAM = new IR_instream(El_input_file_name);

    while (ir_read(*EL_IN_STREAM) != EL_INPUT_EOF) {
	switch (El_input_type) {
	case EL_INPUT_EOF:
	    break;

	case EL_INPUT_DATA: {
	    PM_region* data = new PM_DataRegion;
	    El_datalist *rebelData;
	
	    rebelData = (El_datalist *) El_input;
	    data->setType(_DATA);
	    data->setKey(PM_Id::assignDataRegionName());
	    ((PM_DataRegion*) data)->setRebelPtr(rebelData);

	    file.bind(data);
	} break;

	case EL_INPUT_CODE: {
	    PM_region* procedure = new T;
	    read((PM_CodeRegion*) procedure);
	    
	    file.bind(procedure);
	} break;
       
	default: break;
	}
    }

    delete EL_IN_STREAM;

    if (_verbose)
	cout << "Finished processing Rebel file <" << inputFile << ">" 
	     << endl;
} // end loadRebel


/////////////////////////////////////////////////////////////////////
// initialize the procedure's fields, and set the rebel code pointer
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::read(PM_CodeRegion* proc)
{
    Procedure* rebelProcedure;	  
    rebelProcedure = (Procedure *) El_input;

    const eString& proc_name = rebelProcedure->get_name();

    proc->setType(_PROC);
    proc->setKey(PM_Id::bindId(_PROCMAP, proc_name));
    proc->setRebelPtr(rebelProcedure);

    if (_verbose)
	cout << "Creating node for procedure <" << proc_name << ">" 
	     << endl;

    // initialize _region map
    Region_subregions region_ptr( (Region*) rebelProcedure );
    for ( ; region_ptr != 0; region_ptr++) {	  
	PM_region* block = new T;
	read((PM_CodeRegion*) block, *region_ptr);

	proc->bind(block);
    }

    if (_verbose)
	cout << "Procedure <" << proc_name << "> fully allocated." 
	     << endl;

} // end read procedure


/////////////////////////////////////////////////////////////////////
// initialize the block's fields, and set the rebel code pointer
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_window<T>::read(PM_CodeRegion* block, Region* rebelSubRegion)
{
    // initialize block, and add to proc_map
    if (rebelSubRegion->is_bb())
	block->setType(_BB);
    else if (rebelSubRegion->is_hb())
	block->setType(_HB);

    // recursively intialize the loop_body's subregions
    else if (rebelSubRegion->is_loopbody()) {
	block->setType(_LOOP);

	if (_verbose)
	    cout << "  Unrolling Loop Body: " << rebelSubRegion->id()
		 << endl;

	Region_subregions region_ptr(rebelSubRegion);
	for ( ; region_ptr != 0; region_ptr++) {
	    PM_region* subBlock = new T;
	    read((PM_CodeRegion*) subBlock, *region_ptr);
      
	    block->bind(subBlock);
	}

	if (_verbose)
	    cout << "  Loop Body fully unrolled" << endl;

    }
    block->setKey(rebelSubRegion->id());
    block->setRebelPtr(rebelSubRegion);

    if (_verbose)
	cout << "\t" << block->getType() << ": " << rebelSubRegion->id() 
	     << "\tnode fully created."
	     << endl;

} // end read block
