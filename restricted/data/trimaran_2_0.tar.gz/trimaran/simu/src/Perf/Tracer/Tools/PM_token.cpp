/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File: PM_token.cpp
// Author: Rodric M. Rabbah
//
// The ReaCT-ILP Research Group may be contacted at react-ilp@cs.nyu.edu
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Description: The token used by the lexical analyzers
///////////////////////////////////////////////////////////////////////////////

#include "PM_token.h"
#include "PM_assert.h"
#include <string.h>

////////////////////////////////////////////////////////////
// assignment operators
////////////////////////////////////////////////////////////

// copy one token to another
PM_token& PM_token::operator = (PM_token& token)
{
    _type = token._type;
    _tokenVal = token._tokenVal;
    return *this;
}

// set token to EOF
PM_token& PM_token::setEOF(void)
{
    _type = _pmEOF;
    return *this;
}

// assign a punctuation character to the token
PM_token& PM_token::operator=(char punctuation) 
{
    _type = _pmPUNC;
    _tokenVal.charVal = punctuation;
    return *this;
}

// assign a string to the token
PM_token& PM_token::operator=(char* string)
{
    _type = _pmSTR;
    _tokenVal.strVal = string;
    return *this;
}

// assign a integer number value to the token
PM_token& PM_token::operator=(int number)
{
    _type = _pmINT;
    _tokenVal.intVal = number;
    return *this;
}

// assign a double number value to the token
PM_token& PM_token::operator=(double number)
{
    _type = _pmDBL;
    _tokenVal.dblVal = number;
    return *this;
}

// assign a float number value to the token
PM_token& PM_token::operator=(float number)
{
    _type = _pmFLT;
    _tokenVal.fltVal = number;
    return *this;
}

////////////////////////////////////////////////////////////
// casting operators
////////////////////////////////////////////////////////////
// cast a token to a punctuation character
PM_token::operator char(void) const 
{
    PM_assert(_type == _pmPUNC);
    return _tokenVal.charVal;
}

// cast a token to a string value
PM_token::operator char*(void) const
{
    PM_assert(_type == _pmSTR);
    return _tokenVal.strVal;
}

// cast a token to an integer value
PM_token::operator int(void) const
{
    PM_assert(_type == _pmINT);
    return _tokenVal.intVal;
}

// cast a token to a double value
PM_token::operator double(void) const
{
    PM_assert(_type == _pmDBL);
    return _tokenVal.dblVal;
}

// cast a token to a float value
PM_token::operator float(void) const
{
    PM_assert(_type == _pmFLT);
    return _tokenVal.fltVal;
}


////////////////////////////////////////////////////////////
// equality operators
////////////////////////////////////////////////////////////

// comapre token to punctuation character
bool PM_token::operator == (const char ch) const
{
    if ( _type == _pmPUNC )
	return ( char(*this) == ch );
    return false;
}
 
// comapre token to a string
bool PM_token::operator == (const char* str) const
{
    if ( _type == _pmSTR )
	return ( strcmp( str, ((char*)(*this)) ) == 0 );
    return false;
}

// comapre token to integer value
bool PM_token::operator == (const int num) const
{
    if ( _type == _pmINT )
	return ( int(*this) == num );
    return false;
}

// comapre token to double value
bool PM_token::operator == (const double num) const
{
    if ( _type == _pmDBL )
	return ( double(*this) == num );
    return false;
}

// comapre token to float value
bool PM_token::operator == (const float num) const
{
    if ( _type == _pmFLT )
	return ( float(*this) == num );
    return false;
}


// comapre token to punctuation character
bool PM_token::operator != (const char ch) const
{
    if ( _type == _pmPUNC )
	return ( char(*this) != ch );
    return false;
}
 
// comapre token to a string
bool PM_token::operator != (const char* str) const
{
    if ( _type == _pmSTR )
	return ( strcmp( str, ((char*)(*this)) ) != 0 );
    return false;
}

// comapre token to integer value
bool PM_token::operator != (const int num) const
{
    if ( _type == _pmINT )
	return ( int(*this) != num );
    return false;
}

// comapre token to double value
bool PM_token::operator != (const double num) const
{
    if ( _type == _pmDBL )
	return ( double(*this) != num );
    return false;
}

// comapre token to float value
bool PM_token::operator != (const float num) const
{
    if ( _type == _pmFLT )
	return ( float(*this) != num );
    return false;
}


////////////////////////////////////////////////////////////
// I/O
////////////////////////////////////////////////////////////

// output current token value
ostream& operator << (ostream& os, PM_token& token)
{
    switch ( token.tokenType() ) {
    case _pmPUNC :  os << char(token);     break;
    case _pmSTR  :  os << (char *) token;  break;
    case _pmINT  :  os << int(token);      break;
    case _pmDBL  :  os << double(token);   break;
    case _pmFLT  :  os << float(token);    break;
    case _pmEOF  :  os << "eof";           break;
    default : break;
    }
  
    return os;
}










