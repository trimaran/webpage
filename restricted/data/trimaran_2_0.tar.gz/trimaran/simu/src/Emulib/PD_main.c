/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/******************************************************************************
 * File:    PD_main.c
 * Authors: Rodric M. Rabbah, Amit Nene, Igor Pechtchanski
 *****************************************************************************/

/*************************************************************************/
/*      Description:    Simulator main loop                              */
/*************************************************************************/

/* Names of the Trace and Statistics file */
#define TRACE_FILE "DYN_TRACE"
#define STATS_FILE "DYN_STATS"

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <assert.h>
#include "PD.h"
#include "PD_queue.h"

#define push(v)               *__PD_hack_stack++ = v
#define pop()                 *(--__PD_hack_stack)

static struct __PD_regfile dummy_regfile;
struct __PD_regfile *__PD_cur_reginfo = &dummy_regfile;

static struct __PD_stats dummy_stats;
struct __PD_stats*  __PD_cur_stats = &dummy_stats;

static struct __PD_params dummy_params;
struct __PD_params* __PD_params_vals = &dummy_params;

/* Some bit buckets - are initialized in PD_init*/
__PD_REG __PD_black_hole;
__PD_REG __PD_int_zero;
__PD_REG __PD_flt_zero;
__PD_REG __PD_dbl_zero;
__PD_REG __PD_flt_one;
__PD_REG __PD_dbl_one;
__PD_REG __PD_pred_f;
__PD_REG __PD_pred_t;

/* GPR macro registers */
__PD_REG __PD_int_p1;
__PD_REG __PD_int_p2;
__PD_REG __PD_int_p3;
__PD_REG __PD_int_p4;
__PD_REG __PD_int_ret;
__PD_REG __PD_sp;
__PD_REG __PD_fp;
__PD_REG __PD_ap;
__PD_REG __PD_gp;
__PD_REG __PD_temp_reg;

/* FPR macro registers */
__PD_REG __PD_flt_p1;
__PD_REG __PD_flt_p2;
__PD_REG __PD_flt_p3;
__PD_REG __PD_flt_p4;
__PD_REG __PD_flt_ret;

/* FPR macro registers */
__PD_REG __PD_dbl_p1;
__PD_REG __PD_dbl_p2;
__PD_REG __PD_dbl_ret;

/* BTR macro */
__PD_REG __PD_ret_addr;

/* CR macro registers */
__PD_REG __PD_pc;
__PD_REG __PD_psw;

/* used by modulo scheduling. will have to be saved on procedure entry
 * for virtual register emulation ?
 */
__PD_REG __PD_rrb;
__PD_REG __PD_lc;
__PD_REG __PD_esc;
__PD_REG __PD_lv;

/* stack frame related */
__PD_REG __PD_op;
__PD_REG __PD_ip;
__PD_REG __PD_rs;

/* vararg hack register */
__PD_REG __PD_VAR_ap_list_start;

/* Should be removed, when PV_i implementation functionality
 * is fully merged
 */
__PD_REG __PD_all_pred;
__PD_REG __PD_all_rot_pred;
__PD_REG __PD_all_static_pred;

/* 
 * Special alias registers
 * PV_0..7 implemented for now
 * Each PV_n is an aggregate of 32 predicate registers(32 bits -> 1 word)
 */
__PD_REG __PD_PV[__PD_PV_NUM];

/* Queues to implement EQUALS model */
__PD_QP __PD_QROW [__PD_QSIZE];
__PD_QR __PD_QUEUE[__PD_QSIZE];

unsigned char __PD_queueptr;
unsigned long __PD_timer;

/* Holds the operation of the last outgoing edge in Rebel */
/* 0 indicates a fall-through edge */
int __PD_edge = 0;

/* Hold the address of the last called function */
int __PD_simulator_call = 0;
__PD_call_info __PD_last_call = {0, 0};

void *__PD_trace_file = NULL;
void *__PD_stats_file = NULL;

static double __PD_stack[__PD_MAX_STACK];
static unsigned long __PD_hack_stack_data[__PD_MAX_STACK];
unsigned long *__PD_hack_stack      = __PD_hack_stack_data;
unsigned long *__PD_hack_stack_base = __PD_hack_stack_data;

unsigned long __PD_STACK_LIMIT = (unsigned long) &(__PD_stack[__PD_MAX_STACK]);

/* table to all registers */
__PD_REG*  __PD_REGISTERS[__PD_TOTAL_REG_NUM];

/* physical registers vector */
__PD_REG*  __PD_regs = NULL;

/* for efficiency */
__PD_REG*  __PD_gpr_file;
__PD_REG*  __PD_fpr_file;
__PD_REG*  __PD_btr_file;

__PD_REG*  __PD_pr_file;
__PD_REG*  __PD_cr_file;

/* respective size of static (S) and rotating (R) registers */
unsigned long __PD_GPR_FILE_S_SIZE;
unsigned long __PD_GPR_FILE_R_SIZE;
unsigned long __PD_GPR_NUM = 0;

unsigned long __PD_FPR_FILE_S_SIZE;
unsigned long __PD_FPR_FILE_R_SIZE;
unsigned long __PD_FPR_NUM = 0;

unsigned long __PD_BTR_FILE_S_SIZE;
unsigned long __PD_BTR_NUM = 0;

unsigned long __PD_PR_FILE_R_SIZE;
unsigned long __PD_PR_FILE_S_SIZE;
unsigned long __PD_PR_NUM = 0;

unsigned long __PD_CR_FILE_R_SIZE;
unsigned long __PD_CR_FILE_S_SIZE;
unsigned long __PD_CR_NUM = 0;

/* Is set when RTS is hit - controls the interpreter loop in PD_simulate */
bool __PD_done = 0;

#ifdef _SETJMP_LONGJMP_SUPPORT_
/* Is set when a longjmp is executed */
bool __PD_SL_longjmp_executed = 0;
int* __PD_SL_longjmp_depth    = 0;
#endif /* _SETJMP_LONGJMP_SUPPORT_ */

/* global clock, ticks continuously */
double __PD_GLOBAL_CLOCK = 0;
char*  __PD_current_function;

#ifdef _FULL_SPECULATION_SUPPORT_
# define _SPECULATION_SUPPORT_
#endif /* _FULL_SPECULATION_SUPPORT_ */

#ifdef _SPECULATION_SUPPORT_
/* handle operation speculation */
int  __PD_exception_raised = 0;
void __PD_set_op_speculative_tag(__PD_OP *op, bool* bit);

/* check to see if any of the speculative tags of the source registers
 * are true, and if so, returns true, otherwise returns false
 */
#define __PD_has_speculated_sources(op) \
   ( ((op->src[0].is_reg) && (REG(op->src[0])->speculative_tag)) | \
     ((op->src[1].is_reg) && (REG(op->src[1])->speculative_tag)) | \
     ((op->src[2].is_reg) && (REG(op->src[2])->speculative_tag)) | \
     ((op->src[3].is_reg) && (REG(op->src[3])->speculative_tag)) )

unsigned int __PD_DO_NOT_TRAP_RAISED_EXCEPTION = 0;

#include <setjmp.h>

/* setjmp/longjmp buffer */
jmp_buf __PD_jump_buffer; 

#endif /* _SPECULATION_SUPPORT_ */

/* signal handler function */
void __PD_initialize_signal_handler();
void __PD_raise_exception(int id, int sig);
void __PD_delay_exception(int sig);


/*** Simulator Signal Handler ***/

/* catches exception signals 
 */
void __PD_initialize_signal_handler()
{
  /* call delay exceptions in case of speculation */
  signal(SIGINT,   __PD_delay_exception);
  signal(SIGILL,   __PD_delay_exception);
  signal(SIGTERM,  __PD_delay_exception);
  signal(SIGSEGV,  __PD_delay_exception);
  signal(SIGFPE,   __PD_delay_exception);
#ifdef HPUX
  signal(_SIGQUIT, __PD_delay_exception);
  signal(_SIGHUP,  __PD_delay_exception);
  signal(_SIGBUS,  __PD_delay_exception);
#else /* LINUX OR SUNOS */
  signal(SIGQUIT, __PD_delay_exception);
  signal(SIGHUP,  __PD_delay_exception);
  signal(SIGBUS,  __PD_delay_exception);
#endif
}


/* raise the exception and quit 
 */
void __PD_raise_exception(int id, int sig)
{
  __PD_stats_dump();
  if (id == -1) {
    __PD_error("Exception Raised while simulating %s!", 
	       __PD_current_function);
  }
  else {
    __PD_error("Exception Raised at operation %d of %s!", 
	       id, __PD_current_function);
  }
}


/* delay the raised exception 
 */
void __PD_delay_exception(int sig)
{
#ifdef _SPECULATION_SUPPORT_
  /* if an exception was raised by a non-speculated operation,
   * raise it immediately 
   */
  if (__PD_DO_NOT_TRAP_RAISED_EXCEPTION) {
    __PD_raise_exception(__PD_DO_NOT_TRAP_RAISED_EXCEPTION-1, sig);
  }

  /* expection raised by speculated operation, and should be masked */
  __PD_exception_raised = 1;
  
  /* Reinstall trap signal handler (uninstalls itself when signal called) */
  if (signal(sig, __PD_delay_exception));

  longjmp(__PD_jump_buffer, -1);

#else  /* NO _SPECULATION_SUPPORT_ */
  __PD_raise_exception(-1, sig);
#endif /* _SPECULATION_SUPPORT_ */
}


/* end simulation 
 */
void __PD_endsim(unsigned int lat)
{
  static int done = 1;
  if (__PD_params_vals->control_flow_trace)
    __PD_trace_ret(0);

  /* set __PD_done = 1; at RTS latency */
  __PD_delay(&done, &__PD_done, lat);
}


/* clean up simulator buffers - print statistics and trace if necessary 
 */
void __PD_cleanup(int sig) 
{
  if (__PD_trace_file != NULL) {
    fflush((FILE *) __PD_trace_file);
    
    __PD_trace_endsim(0);
  }
}

/*** Register Handling Functions ***/

/* implements an infinite register view
 * (used for virtual register emulation)
 * 
 * phy = 1 => physical regs
 *     = 0 => virtual regs
 *
 * restore = 1 => called after a simulating a proc
 *         = 0 => called before simualting a proc
 */
void __PD_set_regfile(struct __PD_regfile* reginfo, __PD_REG* __PD_saved_regs,
		      int phy, int restore)
{
  static int init = 0;

  int gpr_offset, gpr_r_offset;
  int fpr_offset, fpr_r_offset;
  int btr_offset;
  int pr_offset, pr_r_offset;
  int cr_offset, cr_r_offset;
  int total;
  
  /* when emulating virtual register resources, init should never be true 
   */
  if (init) {
    /* just a sanity check */
    if (!phy) __PD_error("attempt to emulate virtual register model, "
			 "when physical register model has been instantiated");
    return;
  }
  
  /* update new register file information */
  __PD_GPR_FILE_S_SIZE = reginfo->gpr_stat_size;
  __PD_GPR_FILE_R_SIZE = reginfo->gpr_rot_size;
  __PD_GPR_NUM      = __PD_GPR_FILE_S_SIZE + __PD_GPR_FILE_R_SIZE ;

  __PD_FPR_FILE_S_SIZE = reginfo->fpr_stat_size;
  __PD_FPR_FILE_R_SIZE = reginfo->fpr_rot_size;
  __PD_FPR_NUM      = __PD_FPR_FILE_S_SIZE + __PD_FPR_FILE_R_SIZE ;

  __PD_BTR_FILE_S_SIZE = reginfo->btr_stat_size;
  __PD_BTR_NUM      = __PD_BTR_FILE_S_SIZE;

  __PD_PR_FILE_S_SIZE  = reginfo->pr_stat_size;
  __PD_PR_FILE_R_SIZE  = reginfo->pr_rot_size;
  __PD_PR_NUM       = __PD_PR_FILE_R_SIZE  + __PD_PR_FILE_S_SIZE;

  __PD_CR_FILE_S_SIZE  = reginfo->cr_stat_size;
  __PD_CR_FILE_R_SIZE  = reginfo->cr_rot_size;
  __PD_CR_NUM       = __PD_CR_FILE_R_SIZE  + __PD_CR_FILE_S_SIZE;

  total = __PD_GPR_NUM + __PD_FPR_NUM + __PD_BTR_NUM + 
          __PD_PR_NUM  + __PD_CR_NUM;


  /* for virtual registers, allocate new register files on every entry */
  if (!phy) {
    /* function entry */
    if (!restore) {
      /* allocate a register set of size = total for new function call */
      __PD_regs = (struct __PD_REG *) malloc(total * sizeof(struct __PD_REG));
    
      if (__PD_regs == NULL) {
	__PD_error("Could not allocate Machine's Virtual Register Space!");
      }
    }
    /* function return */
    else {
      free (__PD_regs);
      __PD_regs = __PD_saved_regs;
    }
  }
   
  /* for physical regs just allocate a file once */
  else {
    __PD_regs = (struct __PD_REG *) malloc(total * sizeof(struct __PD_REG));
    
    if (__PD_regs == NULL) {
      __PD_error("Could not allocate Machine's Physical Register Space!");
    }
  }

  /* synchronize register file pointers */
  gpr_offset   = 0;
  gpr_r_offset = gpr_offset   + __PD_GPR_FILE_S_SIZE;
  fpr_offset   = gpr_r_offset + __PD_GPR_FILE_R_SIZE;
  fpr_r_offset = fpr_offset   + __PD_FPR_FILE_S_SIZE;
  btr_offset   = fpr_r_offset + __PD_FPR_FILE_R_SIZE;
  pr_offset    = btr_offset   + __PD_BTR_FILE_S_SIZE;
  pr_r_offset  = pr_offset    + __PD_PR_FILE_S_SIZE;
  cr_offset    = pr_r_offset  + __PD_PR_FILE_R_SIZE;
  cr_r_offset  = cr_offset    + __PD_CR_FILE_S_SIZE;
  
  __PD_REGISTERS[__PD_GPR_FILE] = &__PD_regs[gpr_offset];
  __PD_REGISTERS[__PD_FPR_FILE] = &__PD_regs[fpr_offset];
  __PD_REGISTERS[__PD_BTR_FILE] = &__PD_regs[btr_offset];
  
  __PD_REGISTERS[__PD_PR_FILE] = &__PD_regs[pr_offset];;
  __PD_REGISTERS[__PD_CR_FILE] = &__PD_regs[cr_offset];
  
  __PD_REGISTERS[__PD_GPR_FILE_ROT] = &__PD_regs[gpr_r_offset];
  __PD_REGISTERS[__PD_FPR_FILE_ROT] = &__PD_regs[fpr_r_offset];
  
  __PD_REGISTERS[__PD_PR_FILE_ROT] = &__PD_regs[pr_r_offset];
  __PD_REGISTERS[__PD_CR_FILE_ROT] = &__PD_regs[cr_r_offset];
  
  __PD_cur_reginfo = reginfo;

  /* why is the last call structure reinitialized? 
     __PD_last_call.address  = 0;
     __PD_last_call.is_valid = 0;
  */

  /* if physical registers selected then do not need to 
   * do reinitialization 
   */
  init = phy;
}


/*** Speculation Support Functions ***/

#ifdef _SPECULATION_SUPPORT_

/* propagate the exception raised to destination registers */
void __PD_set_op_speculative_tag(__PD_OP *op, bool* bit)
{
  /* unroll the loop since the number of destinations is fixed */
  /*
    int i;
    for (i = 0; i < __PD_MAX_DEST; i++) {
      __PD_delay(bit, &REG(op->dest[i])->speculative_tag, op->lat[0]);
    }
  */

  __PD_delay(bit, &REG(op->dest[0])->speculative_tag, op->lat[0]);
  __PD_delay(bit, &REG(op->dest[1])->speculative_tag, op->lat[1]);
  __PD_delay(bit, &REG(op->dest[2])->speculative_tag, op->lat[2]);
  __PD_delay(bit, &REG(op->dest[3])->speculative_tag, op->lat[3]);
}

#endif /* _SPECULATION_SUPPORT_ */


/*** Simulator Utility Functions ***/

/* determine if the last function call is a native or simulator call
 */
int __PD_lookup(void (*_this)()) 
{
  if ((__PD_last_call.address  == (long) _this) &&
      (__PD_last_call.is_valid == 1)) {

    __PD_last_call.is_valid = 0;
    __PD_simulator_call = 1;
    return 1; /* simulator call */
  }

  __PD_simulator_call = 0;
  return 0; /* native call */
}


/* aclock instruction : advance clock 
 */
void __PD_aclock(__PD_OP *op) 
{
  int i;
  int clocks = (int) LIT(op->src[0]);

  if (__PD_params_vals->dynamic_stats)
    __PD_cur_stats->dyn_cyc += clocks;
   
  for (i = 0; i < clocks; i++) {
    __PD_GLOBAL_CLOCK++;
    __PD_execute_instruction();
  }
}


/* initialize the simulator's internal state
 */
void __PD_init() 
{
  static int called = 0;
  
  /* create DYN_TRACE if required */
  if (__PD_params_vals->control_flow_trace ||
      __PD_params_vals->address_trace) {
    if (__PD_trace_file == NULL) {
      __PD_trace_file = (void *) fopen(TRACE_FILE, "w+");
    }
  }
  
  /* create DYN_STATS if required */
  if (__PD_params_vals->dynamic_stats) {
    if (__PD_stats_file == NULL) {
      __PD_stats_file = (void *) fopen(STATS_FILE, "w+");
      /* register statistics dumping function on exit */
      atexit(__PD_stats_dump);
    }
  }
  
  if (called) return;

  /* initialize speculation signals */
  __PD_initialize_signal_handler();

  /* initiliaze pointers */
  __PD_REGISTERS[__PD_RRB] = &__PD_rrb;
  __PD_REGISTERS[__PD_LC ] = &__PD_lc;
  __PD_REGISTERS[__PD_ESC] = &__PD_esc;
  
  __PD_REGISTERS[__PD_SP] = &__PD_sp;
  __PD_REGISTERS[__PD_PC] = &__PD_pc;
  __PD_REGISTERS[__PD_FP] = &__PD_fp;

  __PD_REGISTERS[__PD_LV ] = &__PD_lv;
  __PD_REGISTERS[__PD_OPS] = &__PD_op;
  __PD_REGISTERS[__PD_RS ] = &__PD_rs;
  __PD_REGISTERS[__PD_IP ] = &__PD_ip;

  __PD_REGISTERS[__PD_INT_P1] = &__PD_int_p1;
  __PD_REGISTERS[__PD_INT_P2] = &__PD_int_p2;
  __PD_REGISTERS[__PD_INT_P3] = &__PD_int_p3;
  __PD_REGISTERS[__PD_INT_P4] = &__PD_int_p4;

  __PD_REGISTERS[__PD_FLT_P1] = &__PD_flt_p1;
  __PD_REGISTERS[__PD_FLT_P2] = &__PD_flt_p2;
  __PD_REGISTERS[__PD_FLT_P3] = &__PD_flt_p3;
  __PD_REGISTERS[__PD_FLT_P4] = &__PD_flt_p4;

  __PD_REGISTERS[__PD_DBL_P1] = &__PD_dbl_p1;
  __PD_REGISTERS[__PD_DBL_P2] = &__PD_dbl_p2;

  __PD_REGISTERS[__PD_INT_ZERO] = &__PD_int_zero;
  __PD_REGISTERS[__PD_FLT_ZERO] = &__PD_flt_zero;
  __PD_REGISTERS[__PD_DBL_ZERO] = &__PD_dbl_zero;

  __PD_REGISTERS[__PD_FLT_ONE] = &__PD_flt_one;
  __PD_REGISTERS[__PD_DBL_ONE] = &__PD_dbl_one;

  __PD_REGISTERS[__PD_UNDEF] = NULL;
  __PD_REGISTERS[__PD_LOCAL] = NULL;
  __PD_REGISTERS[__PD_PARAM] = NULL;
  __PD_REGISTERS[__PD_SWAP ] = NULL;

  __PD_REGISTERS[__PD_INT_RET_TYPE] = NULL;
  __PD_REGISTERS[__PD_FLT_RET_TYPE] = NULL;
  __PD_REGISTERS[__PD_DBL_RET_TYPE] = NULL;

  __PD_REGISTERS[__PD_INT_RET] = &__PD_int_ret;
  __PD_REGISTERS[__PD_FLT_RET] = &__PD_flt_ret;
  __PD_REGISTERS[__PD_DBL_RET] = &__PD_dbl_ret;

  __PD_REGISTERS[__PD_INT_TM] = NULL;
  __PD_REGISTERS[__PD_FLT_TM] = NULL;
  __PD_REGISTERS[__PD_DBL_TM] = NULL;

  __PD_REGISTERS[__PD_RET_ADDR] = &__PD_ret_addr;

  __PD_REGISTERS[__PD_ALL_PRED       ] = &__PD_all_pred;
  __PD_REGISTERS[__PD_ALL_ROT_PRED   ] = &__PD_all_rot_pred;
  __PD_REGISTERS[__PD_ALL_STATIC_PRED] = &__PD_all_static_pred;

  __PD_REGISTERS[__PD_PRED_F] = &__PD_pred_f;
  __PD_REGISTERS[__PD_PRED_T] = &__PD_pred_t;

  __PD_REGISTERS[__PD_BLACK_HOLE] = &__PD_black_hole;
  __PD_REGISTERS[__PD_TEMP_REG  ] = &__PD_temp_reg;
   
  __PD_REGISTERS[__PD_PV_0] = &__PD_PV[0];
  __PD_REGISTERS[__PD_PV_1] = &__PD_PV[1];
  __PD_REGISTERS[__PD_PV_2] = &__PD_PV[2];
  __PD_REGISTERS[__PD_PV_3] = &__PD_PV[3];
  __PD_REGISTERS[__PD_PV_4] = &__PD_PV[4];
  __PD_REGISTERS[__PD_PV_5] = &__PD_PV[5];
  __PD_REGISTERS[__PD_PV_6] = &__PD_PV[6];
  __PD_REGISTERS[__PD_PV_7] = &__PD_PV[7];

  /* initialize RRB */
  __PD_rrb.reg.cr = 0;

  /* initilaize bit bucket values */
  __PD_int_zero.reg.gpr   = 0;
  __PD_flt_zero.reg.fpr_S = 0;
  __PD_dbl_zero.reg.fpr_D = 0;
  __PD_flt_one.reg.fpr_S  = 1.0;
  __PD_dbl_one.reg.fpr_D  = 1.0;
  __PD_pred_f.reg.pr      = 0;
  __PD_pred_t.reg.pr      = 1;

  /* initialize EQUALS related queue */
  __PD_initqueue();
  __PD_inittimer();
  __PD_initLDS();
  __PD_sp.reg.cr = (unsigned long) &__PD_stack;
  __PD_done = 0;
   
  /* must initialize the dummy_params to the initial
   * params values */
  dummy_params.nual_equals         = __PD_params_vals->nual_equals;  
  dummy_params.binary_trace_format = __PD_params_vals->binary_trace_format;
  dummy_params.address_trace       = __PD_params_vals->address_trace;   
  dummy_params.control_flow_trace  = __PD_params_vals->control_flow_trace;
  dummy_params.dynamic_stats       = __PD_params_vals->dynamic_stats;     
  
  called = 1;
}


/* initialize timer 
 */
void __PD_inittimer(void) 
{
  __PD_timer = 0;
}


/* initialize queue 
 */
void __PD_initqueue(void) 
{
  register int i;

  for (i = 0; i < __PD_QSIZE; i++) {
    __PD_QROW[i].nmoves = 0;
    __PD_QROW[i].nactions = 0;
    __PD_QROW[i].call = 0;
  }

  __PD_queueptr = 0;
}


/* delay copy until current time + specified latency 
 */
void __PD_delay(void *val, void *reg, unsigned long lat) 
{
  register int attime = (__PD_queueptr + lat) & __PD_QMASK;
  register int n = __PD_QROW[attime].nmoves;

#ifdef _DEBUG_
  fprintf(stderr, "\tdelay(%p, *(%p)=%x) until %d\n",
	  (unsigned long *)reg, (unsigned long *)val,
	  *(unsigned long *)val, attime);
#endif /* _DEBUG_ */

  __PD_QUEUE[attime].moves[n].reg =  (unsigned long *)reg;
  __PD_QUEUE[attime].moves[n].val = *(unsigned long *)val;
  __PD_QROW [attime].nmoves++;
}


/* delay double copy until current time + specified latency 
 */
void __PD_delay2x(void *val, void *reg, unsigned long lat) 
{
  register int attime = (__PD_queueptr + lat) & __PD_QMASK;
  register int n = __PD_QROW[attime].nmoves;

#ifdef _DEBUG_
  fprintf(stderr, "\tdelay2(%p, *(%p)=%x *(%p)=%x) until %d\n",
	  (unsigned long *)reg, (unsigned long *)val, *(unsigned long *)val,
	  (unsigned long *)val + 1, *((unsigned long *)val + 1), attime);
#endif /* _DEBUG_ */

  __PD_QUEUE[attime].moves[n].reg =  (unsigned long *)reg;
  __PD_QUEUE[attime].moves[n].val = *(unsigned long *)val;

  __PD_QUEUE[attime].moves[n+1].reg =   (unsigned long *)reg + 1;
  __PD_QUEUE[attime].moves[n+1].val = *((unsigned long *)val + 1);
  __PD_QROW [attime].nmoves += 2;
}


/* delay a function (vector) call until current time + specified latency 
 */
void __PD_delay_call(__PD_VECTOR addr, __PD_VECTOR anno, 
		     __PD_REG *ret, unsigned long lat) 
{
  register int attime = (__PD_queueptr + lat) & __PD_QMASK;
  
  if (__PD_QROW[attime].call) {
    fprintf(stderr, "Simulator error: more than 1 branch per instruction\n");
    exit(1);
  }
  
#ifdef _DEBUG_
  fprintf(stderr, "\tdelay_call: %p(%p) until %d\n", anno, addr, attime);
#endif /* _DEBUG_ */
  
  __PD_QUEUE[attime].call.vec  = anno;
  __PD_QUEUE[attime].call.targ = addr;
  __PD_QUEUE[attime].call.ret  = ret;
  __PD_QROW [attime].call = 1;
}


/* dequeue and commit all values; execute all function calls
 */
void __PD_execute_instruction(void) 
{
  register unsigned long p;
  register bool call;
  register __PD_VECTOR vec;
  register __PD_VECTOR targ;
  register __PD_REG *ret;

#ifdef _DEBUG_
  fprintf(stderr, "\tProcessing queue at %d\n", __PD_queueptr);
#endif /* _DEBUG_ */

  /* execute the moves */
  for (p = 0; p < __PD_QROW[__PD_queueptr].nmoves; p++) {
    register __PD_QM *t = &__PD_QUEUE[__PD_queueptr].moves[p];

#ifdef _DEBUG_
    fprintf(stderr, "\tcopying %x to %p\n", t->val, t->reg);
#endif /* _DEBUG_ */

    *t->reg = t->val;
  }

  /* save call, vector and return address */
  call = __PD_QROW [__PD_queueptr].call;
  vec  = __PD_QUEUE[__PD_queueptr].call.vec;
  targ = __PD_QUEUE[__PD_queueptr].call.targ;
  ret  = __PD_QUEUE[__PD_queueptr].call.ret;

#ifdef _DEBUG_
  fprintf(stderr, "\tQueue at %d empty\n", __PD_queueptr);
#endif /* _DEBUG_ */

  __PD_QROW[__PD_queueptr].nmoves = 0;
  __PD_QROW[__PD_queueptr].call = 0;

  __PD_queueptr++;
  __PD_timer--;

  /* now execute any function calls */
  if (call) {
    unsigned long pc = __PD_pc.reg.cr;    /* save PC */
    
    /* used to track where last call originated from */
    __PD_last_call.address  = (long) targ;
    __PD_last_call.is_valid = 1;
      
    /* call the function */
    if (vec) (*vec)(targ);
    else     (*targ)();

#ifdef _SETJMP_LONGJMP_SUPPORT_
    /* if a longjmp is executed, then it has set the appropriate pc, 
     * and thus it does not need to be restored
     */
    if (!__PD_SL_longjmp_executed) {
      __PD_pc.reg.cr = pc;    /* restore PC */    
    }
#endif /* _SETJMP_LONGJMP_SUPPORT_ */
  }
}


/* interpreter loop */
void __PD_simulate(__PD_OP *code) 
{
  __PD_OP *pc;
  int i;

  for (i = 0, pc = code; !__PD_done; i++, pc++) {
    __PD_pc.reg.cr = (unsigned long) pc;

#ifdef _DEBUG_
    fprintf(stderr, "Issuing instruction id %d at time = %f\n",
	    pc->Rebel_id, __PD_GLOBAL_CLOCK);
#endif /* _DEBUG_ */

#ifdef _SPECULATION_SUPPORT_
    /* mark this op as a non-speculated operation */
    if (!(pc->Mask | pc->Speculated)) {
      /* if one of the sources was the result of a speculated instruction
       * that caused an exception, raise the exception now
       */
      if (__PD_has_speculated_sources(pc)) {
#ifdef _FULL_SPECULATION_SUPPORT_
	__PD_raise_exception(pc->Rebel_id, 0);
#endif /* _FULL_SPECULATION_SUPPORT_ */
      }
      else {
	/* set the flag to the current op's Rebel_id + 1 since
	 * the __PD_aclock operation has a Rebel_id of 0 by default
	 */
	__PD_DO_NOT_TRAP_RAISED_EXCEPTION = pc->Rebel_id + 1;
      }
    }
    
    /* this is a speculated operation, then may need to mask exceptions */
    else {
      __PD_DO_NOT_TRAP_RAISED_EXCEPTION = 0;
    }
#endif /* _SPECULATION_SUPPORT_ */

    /* note that operation marked Speculated or Promoted may not have
     * their Mask flag set, and will therefore be executed - these
     * operation are not expected to generate an exception
     */
    /* carry out the instruction (although do not really need to if one
     * of the current operation's sources has a true speculative tag bit.
     * if it causes an exception, then the destinations' speculative tag
     * will be set if it is a speculated operation
     */
    (*(pc->op))(pc);

#ifdef _SETJMP_LONGJMP_SUPPORT_
    /* when a longjmp is executed, the interpreter must force
     * the necessary number of function returns, so that the 
     * actual C program stack points to the proper function
     * a side effect of this approach is that any memory allocated
     * to preserve speculative tags may not be deallocated
     */
    if (__PD_SL_longjmp_executed) {
      if (*(__PD_SL_longjmp_depth) > 0) {
	(*__PD_SL_longjmp_depth)--;
	return;
      }
      /* the actual program stack frame now should point to the
       * "C" longjmp target function 
       */
      else __PD_SL_longjmp_executed = 0;
    }
#endif /* _SETJMP_LONGJMP_SUPPORT_ */

#ifdef _SPECULATION_SUPPORT_    
    /* once a signal is caught, resume here */
    if (setjmp(__PD_jump_buffer) == -1) {
    
      if (!(pc->Mask | pc->Speculated)) {
	/* clear the destination's speculative bit on a new definition */
	__PD_set_op_speculative_tag(pc, &__PD_pred_f.reg.pr);
      }
    
      else {
	/* if an exception was raised by the speculated (masked) operation, 
	 * set the speculative tag on the destination registers
	 */
	if (__PD_exception_raised) {
	  __PD_exception_raised = 0;
	  __PD_set_op_speculative_tag(pc, &__PD_pred_t.reg.pr);
	}
	/* if any of the sources have their speculative tag set to true,
	 * then propagate the exception
	 */
	else if (__PD_has_speculated_sources(pc)) {
	  __PD_set_op_speculative_tag(pc, &__PD_pred_t.reg.pr);
	}
      }
    }
#endif /* _SPECULATION_SUPPORT_ */
        
    if(__PD_params_vals->dynamic_stats) {
      /* update the statistics for committed instructions only,
       * ignoring those that are predicated on false 
       */
      if (!pc->Predicated) 
	__PD_update_stats(pc);
      
      else if (REG(pc->pred)->reg.pr) 
	__PD_update_stats(pc);
    }
    
    /* advance the program counter */
    pc = (__PD_OP *) __PD_pc.reg.cr;
  }

  __PD_done = 0;
}

/* end PD_main.c */
