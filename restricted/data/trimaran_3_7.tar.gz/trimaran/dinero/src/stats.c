/*
 * Dinero IV
 * Written by Jan Edler and Mark D. Hill
 *
 * Copyright (C) 1997 NEC Research Institute, Inc. and Mark D. Hill.
 * All rights reserved.
 * Copyright (C) 1985, 1989 Mark D. Hill.  All rights reserved.
 * 
 * Permission to  use, copy, modify, and distribute  this software and
 * its associated documentation  for non-commercial purposes is hereby
 * granted  (for commercial  purposes  see below),  provided that  the
 * above copyright  notice appears in all copies,  derivative works or
 * modified  versions of the  software and  any portions  thereof, and
 * that both the copyright notice and this permission notice appear in
 * the documentation.   NEC Research Institute  Inc. and Mark  D. Hill
 * shall  be given  a copy  of any  such derivative  work  or modified
 * version of the software and NEC Research Institute Inc.  and any of
 * its  affiliated companies  (collectively referred  to as  NECI) and
 * Mark D. Hill shall be  granted permission to use, copy, modify, and
 * distribute the software for internal use and research.  The name of
 * NEC Research Institute Inc.  and its affiliated companies shall not
 * be used in advertising or  publicity related to the distribution of
 * the  software, without  the  prior written  consent  of NECI.   All
 * copies,  derivative works,  or  modified versions  of the  software
 * shall be exported or  reexported in accordance with applicable laws
 * and  regulations  relating to  export  control.   This software  is
 * experimental.   NECI  and  Mark  D. Hill  make  no  representations
 * regarding  the suitability  of this  software for  any  purpose and
 * neither NECI nor Mark D. Hill will support the software.
 * 
 * Use of this software for  commercial purposes is also possible, but
 * only if,  in addition to the above  requirements for non-commercial
 * use, written permission for such  use is obtained by the commercial
 * user  from  NECI or  Mark  D. Hill  prior  to  the fabrication  and
 * distribution of the software.
 * 
 * THE SOFTWARE IS PROVIDED AS IS.   NECI AND MARK D. HILL DO NOT MAKE
 * ANY  WARRANTEES  EITHER  EXPRESS  OR  IMPLIED WITH  REGARD  TO  THE
 * SOFTWARE.  NECI  AND MARK D.  HILL ALSO DISCLAIM ANY  WARRANTY THAT
 * THE SOFTWARE  IS FREE OF INFRINGEMENT OF  ANY INTELLECTUAL PROPERTY
 * RIGHTS OF  OTHERS.  NO OTHER  LICENSE EXPRESS OR IMPLIED  IS HEREBY
 * GRANTED.   NECI  AND MARK  D.  HILL SHALL  NOT  BE  LIABLE FOR  ANY
 * DAMAGES, INCLUDING  GENERAL, SPECIAL, INCIDENTAL,  OR CONSEQUENTIAL
 * DAMAGES, ARISING OUT OF THE USE OR INABILITY TO USE THE SOFTWARE.
 *
 *
 * This  file   contains  the  startup,  overall   driving  code,  and
 * miscellaneous  stuff  needed  for  Dinero  IV  when  running  as  a
 * self-contained  simulator.  All  the really  hard stuff  is  in the
 * callable Dinero IV subroutines,  which may be used independently of
 * this program.
 *
 * Extracted from cmdmain.c - RCS header removed.
 */

#include <stddef.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <limits.h>
#include <stdio.h>
#include <errno.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <sys/stat.h>
#include "dinero.h"

/* avoid divide-by-zero exception */
#define NONZERO(i) (((i)==0.0) ? 1.0 : (double)(i))

/* raise 2 to the exp power */
#define pow2(exp) (1 << exp)

static FILE *output_file;
static void output(char *fmt, ...)
{
  va_list args;

  va_start(args, fmt);
  vfprintf(output_file, fmt, args);
  va_end(args);
}

/* print stats for one cache */
void dinero_print_cache_stats(FILE * outfile, d4cache * c)
{
  const char *dashes = "------";

  double demand_fetch_data, demand_fetch_alltype;
  double prefetch_fetch_data, prefetch_fetch_alltype;
  double demand_data, demand_alltype;
  double prefetch_data, prefetch_alltype;
  double demand_comp_data, demand_comp_alltype;
  double demand_cap_data, demand_cap_alltype;
  double demand_conf_data, demand_conf_alltype;
  double floatnum;

  output_file = outfile;

  /* Used in bus traffic calculations even if no prefetching. */
  prefetch_fetch_alltype = 0;

  /* print header */
  output("%s [size = %d, bsize = %d, sbsize = %d, assoc = %d, latency = %d]\n",
         c->name,
         pow2(c->lg2size),
         pow2(c->lg2blocksize), pow2(c->lg2subblocksize), c->assoc, c->latency);

  output("%-21s\t\t%+12s\t%+12s\t%+12s\t%+12s\t%+12s\t%+12s\n",
         "Metrics", "Total", "Instrn", "Data", "Read", "Write", "Misc");
  output("%-21s\t\t%+12s\t%+12s\t%+12s\t%+12s\t%+12s\t%+12s\n",
         "---------------------", dashes, dashes, dashes, dashes, dashes,
         dashes);

  /* print fetch numbers */
  demand_fetch_data =
    c->fetch[D4XMISC] + c->fetch[D4XREAD] + c->fetch[D4XWRITE];
  demand_fetch_alltype = demand_fetch_data + c->fetch[D4XINSTRN];

  output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
         "Demand Fetches",
         demand_fetch_alltype,
         c->fetch[D4XINSTRN],
         demand_fetch_data,
         c->fetch[D4XREAD], c->fetch[D4XWRITE], c->fetch[D4XMISC]);

  floatnum = NONZERO(demand_fetch_alltype);

  output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
         "Fraction of total",
         demand_fetch_alltype / floatnum,
         c->fetch[D4XINSTRN] / floatnum,
         demand_fetch_data / floatnum,
         c->fetch[D4XREAD] / floatnum,
         c->fetch[D4XWRITE] / floatnum, c->fetch[D4XMISC] / floatnum);

  /* prefetching? */
  prefetch_fetch_data =
    c->fetch[D4PREFETCH + D4XMISC] + c->fetch[D4PREFETCH + D4XREAD] +
    c->fetch[D4PREFETCH + D4XWRITE];

  if (c->prefetchf != d4prefetch_none) {
    prefetch_fetch_alltype =
      prefetch_fetch_data + c->fetch[D4PREFETCH + D4XINSTRN];

    output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
           "Prefetch Fetches",
           prefetch_fetch_alltype,
           c->fetch[D4PREFETCH + D4XINSTRN],
           prefetch_fetch_data,
           c->fetch[D4PREFETCH + D4XREAD],
           c->fetch[D4PREFETCH + D4XWRITE], c->fetch[D4PREFETCH + D4XMISC]);

    floatnum = NONZERO(prefetch_fetch_alltype);

    output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
           "Fraction",
           prefetch_fetch_alltype / floatnum,
           c->fetch[D4PREFETCH + D4XINSTRN] / floatnum,
           prefetch_fetch_data / floatnum,
           c->fetch[D4PREFETCH + D4XREAD] / floatnum,
           c->fetch[D4PREFETCH + D4XWRITE] / floatnum,
           c->fetch[D4PREFETCH + D4XMISC] / floatnum);

    output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
           "Total Fetches",
           demand_fetch_alltype + prefetch_fetch_alltype,
           c->fetch[D4XINSTRN] + c->fetch[D4PREFETCH + D4XINSTRN],
           demand_fetch_data + prefetch_fetch_data,
           c->fetch[D4XREAD] + c->fetch[D4PREFETCH + D4XREAD],
           c->fetch[D4XWRITE] + c->fetch[D4PREFETCH + D4XWRITE],
           c->fetch[D4XMISC] + c->fetch[D4PREFETCH + D4XMISC]);

    floatnum = NONZERO(demand_fetch_alltype + prefetch_fetch_alltype);

    output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
           "Fraction",
           (demand_fetch_alltype + prefetch_fetch_alltype) / floatnum,
           (c->fetch[D4XINSTRN] +
            c->fetch[D4PREFETCH + D4XINSTRN]) / floatnum,
           (demand_fetch_data + prefetch_fetch_data) / floatnum,
           (c->fetch[D4XREAD] + c->fetch[D4PREFETCH + D4XREAD]) / floatnum,
           (c->fetch[D4XWRITE] + c->fetch[D4PREFETCH + D4XWRITE]) / floatnum,
           (c->fetch[D4XMISC] + c->fetch[D4PREFETCH + D4XMISC]) / floatnum);

  }                             /* end of prefetching */
  output("\n");

  /* end of fetch numbers, print miss numbers */
  demand_data = c->miss[D4XMISC] + c->miss[D4XREAD] + c->miss[D4XWRITE];
  demand_alltype = demand_data + c->miss[D4XINSTRN];

  output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
         "Demand Misses",
         demand_alltype,
         c->miss[D4XINSTRN],
         demand_data, c->miss[D4XREAD], c->miss[D4XWRITE], c->miss[D4XMISC]);

  output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
         "Demand miss rate",
         demand_alltype / NONZERO(demand_fetch_alltype),
         c->miss[D4XINSTRN] / NONZERO(c->fetch[D4XINSTRN]),
         demand_data / NONZERO(demand_fetch_data),
         c->miss[D4XREAD] / NONZERO(c->fetch[D4XREAD]),
         c->miss[D4XWRITE] / NONZERO(c->fetch[D4XWRITE]),
         c->miss[D4XMISC] / NONZERO(c->fetch[D4XMISC]));

  if (c->flags & D4F_CCC) {
    demand_comp_data =
      c->comp_miss[D4XMISC] + c->comp_miss[D4XREAD] + c->comp_miss[D4XWRITE];
    demand_comp_alltype = demand_comp_data + c->comp_miss[D4XINSTRN];
    demand_cap_data =
      c->cap_miss[D4XMISC] + c->cap_miss[D4XREAD] + c->cap_miss[D4XWRITE];
    demand_cap_alltype = demand_cap_data + c->cap_miss[D4XINSTRN];
    demand_conf_data =
      c->conf_miss[D4XMISC] + c->conf_miss[D4XREAD] + c->conf_miss[D4XWRITE];
    demand_conf_alltype = demand_conf_data + c->conf_miss[D4XINSTRN];

    output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
           "Compulsory misses",
           demand_comp_alltype,
           c->comp_miss[D4XINSTRN],
           demand_comp_data,
           c->comp_miss[D4XREAD],
           c->comp_miss[D4XWRITE], c->comp_miss[D4XMISC]);

    output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
           "Capacity misses",
           demand_cap_alltype,
           c->cap_miss[D4XINSTRN],
           demand_cap_data,
           c->cap_miss[D4XREAD], c->cap_miss[D4XWRITE], c->cap_miss[D4XMISC]);

    output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
           "Conflict misses",
           demand_conf_alltype,
           c->conf_miss[D4XINSTRN],
           demand_conf_data,
           c->conf_miss[D4XREAD],
           c->conf_miss[D4XWRITE], c->conf_miss[D4XMISC]);

    output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
           "Compulsory fraction",
           demand_comp_alltype / NONZERO(demand_alltype),
           c->comp_miss[D4XINSTRN] / NONZERO(c->miss[D4XINSTRN]),
           demand_comp_data / NONZERO(demand_data),
           c->comp_miss[D4XREAD] / NONZERO(c->miss[D4XREAD]),
           c->comp_miss[D4XWRITE] / NONZERO(c->miss[D4XWRITE]),
           c->comp_miss[D4XMISC] / NONZERO(c->miss[D4XMISC]));

    output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
           "Capacity fraction",
           demand_cap_alltype / NONZERO(demand_alltype),
           c->cap_miss[D4XINSTRN] / NONZERO(c->miss[D4XINSTRN]),
           demand_cap_data / NONZERO(demand_data),
           c->cap_miss[D4XREAD] / NONZERO(c->miss[D4XREAD]),
           c->cap_miss[D4XWRITE] / NONZERO(c->miss[D4XWRITE]),
           c->cap_miss[D4XMISC] / NONZERO(c->miss[D4XMISC]));

    output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
           "Conflict fraction",
           demand_conf_alltype / NONZERO(demand_alltype),
           c->conf_miss[D4XINSTRN] / NONZERO(c->miss[D4XINSTRN]),
           demand_conf_data / NONZERO(demand_data),
           c->conf_miss[D4XREAD] / NONZERO(c->miss[D4XREAD]),
           c->conf_miss[D4XWRITE] / NONZERO(c->miss[D4XWRITE]),
           c->conf_miss[D4XMISC] / NONZERO(c->miss[D4XMISC]));
  }

  /* prefetch misses? */
  if (c->prefetchf != d4prefetch_none) {
    prefetch_data =
      c->miss[D4PREFETCH + D4XMISC] + c->miss[D4PREFETCH + D4XREAD] +
      c->miss[D4PREFETCH + D4XWRITE];
    prefetch_alltype = prefetch_data + c->miss[D4PREFETCH + D4XINSTRN];

    output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
           "Prefetch Misses",
           prefetch_alltype,
           c->miss[D4PREFETCH + D4XINSTRN],
           prefetch_data,
           c->miss[D4PREFETCH + D4XREAD],
           c->miss[D4PREFETCH + D4XWRITE], c->miss[D4PREFETCH + D4XMISC]);

    output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
           "PF miss rate",
           prefetch_alltype / NONZERO(prefetch_fetch_alltype),
           c->miss[D4PREFETCH +
                   D4XINSTRN] / NONZERO(c->fetch[D4PREFETCH + D4XINSTRN]),
           prefetch_data / NONZERO(prefetch_fetch_data),
           c->miss[D4PREFETCH +
                   D4XREAD] / NONZERO(c->fetch[D4PREFETCH + D4XREAD]),
           c->miss[D4PREFETCH +
                   D4XWRITE] / NONZERO(c->fetch[D4PREFETCH + D4XWRITE]),
           c->miss[D4PREFETCH +
                   D4XMISC] / NONZERO(c->fetch[D4PREFETCH + D4XMISC]));

    if (c->flags & D4F_CCC) {
      demand_comp_data =
        c->comp_miss[D4PREFETCH + D4XMISC] + c->comp_miss[D4PREFETCH +
                                                          D4XREAD] +
        c->comp_miss[D4PREFETCH + D4XWRITE];
      demand_comp_alltype =
        demand_comp_data + c->comp_miss[D4PREFETCH + D4XINSTRN];
      demand_cap_data =
        c->cap_miss[D4PREFETCH + D4XMISC] + c->cap_miss[D4PREFETCH +
                                                        D4XREAD] +
        c->cap_miss[D4PREFETCH + D4XWRITE];
      demand_cap_alltype =
        demand_cap_data + c->cap_miss[D4PREFETCH + D4XINSTRN];
      demand_conf_data =
        c->conf_miss[D4PREFETCH + D4XMISC] + c->conf_miss[D4PREFETCH +
                                                          D4XREAD] +
        c->conf_miss[D4PREFETCH + D4XWRITE];
      demand_conf_alltype =
        demand_conf_data + c->conf_miss[D4PREFETCH + D4XINSTRN];

      output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
             "PF compulsory misses",
             demand_comp_alltype,
             c->comp_miss[D4PREFETCH + D4XINSTRN],
             demand_comp_data,
             c->comp_miss[D4PREFETCH + D4XREAD],
             c->comp_miss[D4PREFETCH + D4XWRITE],
             c->comp_miss[D4PREFETCH + D4XMISC]);

      output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
             "PF capacity misses",
             demand_cap_alltype,
             c->cap_miss[D4PREFETCH + D4XINSTRN],
             demand_cap_data,
             c->cap_miss[D4PREFETCH + D4XREAD],
             c->cap_miss[D4PREFETCH + D4XWRITE],
             c->cap_miss[D4PREFETCH + D4XMISC]);

      output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
             "PF conflict misses",
             demand_conf_alltype,
             c->conf_miss[D4PREFETCH + D4XINSTRN],
             demand_conf_data,
             c->conf_miss[D4PREFETCH + D4XREAD],
             c->conf_miss[D4PREFETCH + D4XWRITE],
             c->conf_miss[D4PREFETCH + D4XMISC]);

      output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
             "PF compulsory fract",
             demand_comp_alltype / NONZERO(prefetch_alltype),
             c->comp_miss[D4PREFETCH +
                          D4XINSTRN] / NONZERO(c->miss[D4PREFETCH +
                                                       D4XINSTRN]),
             demand_comp_data / NONZERO(prefetch_data),
             c->comp_miss[D4PREFETCH +
                          D4XREAD] / NONZERO(c->miss[D4PREFETCH + D4XREAD]),
             c->comp_miss[D4PREFETCH +
                          D4XWRITE] / NONZERO(c->miss[D4PREFETCH + D4XWRITE]),
             c->comp_miss[D4PREFETCH +
                          D4XMISC] / NONZERO(c->miss[D4PREFETCH + D4XMISC]));

      output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
             "PF capacity fract",
             demand_cap_alltype / NONZERO(prefetch_alltype),
             c->cap_miss[D4PREFETCH +
                         D4XINSTRN] / NONZERO(c->miss[D4PREFETCH +
                                                      D4XINSTRN]),
             demand_cap_data / NONZERO(prefetch_data),
             c->cap_miss[D4PREFETCH +
                         D4XREAD] / NONZERO(c->miss[D4PREFETCH + D4XREAD]),
             c->cap_miss[D4PREFETCH +
                         D4XWRITE] / NONZERO(c->miss[D4PREFETCH + D4XWRITE]),
             c->cap_miss[D4PREFETCH +
                         D4XMISC] / NONZERO(c->miss[D4PREFETCH + D4XMISC]));

      output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
             "PF conflict fract",
             demand_conf_alltype / NONZERO(prefetch_alltype),
             c->conf_miss[D4PREFETCH +
                          D4XINSTRN] / NONZERO(c->miss[D4PREFETCH +
                                                       D4XINSTRN]),
             demand_conf_data / NONZERO(prefetch_data),
             c->conf_miss[D4PREFETCH +
                          D4XREAD] / NONZERO(c->miss[D4PREFETCH + D4XREAD]),
             c->conf_miss[D4PREFETCH +
                          D4XWRITE] / NONZERO(c->miss[D4PREFETCH + D4XWRITE]),
             c->conf_miss[D4PREFETCH +
                          D4XMISC] / NONZERO(c->miss[D4PREFETCH + D4XMISC]));
    }

    output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
           "Total Misses",
           demand_alltype + prefetch_alltype,
           c->miss[D4XINSTRN] + c->miss[D4PREFETCH + D4XINSTRN],
           demand_data + prefetch_data,
           c->miss[D4XREAD] + c->miss[D4PREFETCH + D4XREAD],
           c->miss[D4XWRITE] + c->miss[D4PREFETCH + D4XWRITE],
           c->miss[D4XMISC] + c->miss[D4PREFETCH + D4XMISC]);

    output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
           "Total miss rate",
           (demand_alltype +
            prefetch_alltype) / NONZERO(demand_fetch_alltype +
                                        prefetch_fetch_alltype),
           (c->miss[D4XINSTRN] +
            c->miss[D4PREFETCH + D4XINSTRN]) / NONZERO(c->fetch[D4XINSTRN] +
                                                       c->fetch[D4PREFETCH +
                                                                D4XINSTRN]),
           (demand_data + prefetch_data) / NONZERO(demand_fetch_data +
                                                   prefetch_fetch_data),
           (c->miss[D4XREAD] +
            c->miss[D4PREFETCH + D4XREAD]) / NONZERO(c->fetch[D4XREAD] +
                                                     c->fetch[D4PREFETCH +
                                                              D4XREAD]),
           (c->miss[D4XWRITE] +
            c->miss[D4PREFETCH + D4XWRITE]) / NONZERO(c->fetch[D4XWRITE] +
                                                      c->fetch[D4PREFETCH +
                                                               D4XWRITE]),
           (c->miss[D4XMISC] +
            c->miss[D4PREFETCH + D4XMISC]) / NONZERO(c->fetch[D4XMISC] +
                                                     c->fetch[D4PREFETCH +
                                                              D4XMISC]));
  }                             /* end of prefetch misses */
  output("\n");

  /* end of misses numbers, print block miss numbers */
  if (c->lg2subblocksize != c->lg2blocksize) {
    demand_data =
      c->blockmiss[D4XMISC] + c->blockmiss[D4XREAD] + c->blockmiss[D4XWRITE];
    demand_alltype = demand_data + c->blockmiss[D4XINSTRN];

    output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
           "Demand Block Misses",
           demand_alltype,
           c->blockmiss[D4XINSTRN],
           demand_data,
           c->blockmiss[D4XREAD],
           c->blockmiss[D4XWRITE], c->blockmiss[D4XMISC]);

    output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
           "DB miss rate",
           demand_alltype / NONZERO(demand_fetch_alltype),
           c->blockmiss[D4XINSTRN] / NONZERO(c->fetch[D4XINSTRN]),
           demand_data / NONZERO(demand_fetch_data),
           c->blockmiss[D4XREAD] / NONZERO(c->fetch[D4XREAD]),
           c->blockmiss[D4XWRITE] / NONZERO(c->fetch[D4XWRITE]),
           c->blockmiss[D4XMISC] / NONZERO(c->fetch[D4XMISC]));

    if (c->flags & D4F_CCC) {
      demand_comp_data =
        c->comp_blockmiss[D4XMISC] + c->comp_blockmiss[D4XREAD] +
        c->comp_blockmiss[D4XWRITE];
      demand_comp_alltype = demand_comp_data + c->comp_blockmiss[D4XINSTRN];
      demand_cap_data =
        c->cap_blockmiss[D4XMISC] + c->cap_blockmiss[D4XREAD] +
        c->cap_blockmiss[D4XWRITE];
      demand_cap_alltype = demand_cap_data + c->cap_blockmiss[D4XINSTRN];
      demand_conf_data =
        c->conf_blockmiss[D4XMISC] + c->conf_blockmiss[D4XREAD] +
        c->conf_blockmiss[D4XWRITE];
      demand_conf_alltype = demand_conf_data + c->conf_blockmiss[D4XINSTRN];

      output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
             "DB compulsory misses",
             demand_comp_alltype,
             c->comp_blockmiss[D4XINSTRN],
             demand_comp_data,
             c->comp_blockmiss[D4XREAD],
             c->comp_blockmiss[D4XWRITE], c->comp_blockmiss[D4XMISC]);

      output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
             "DB capacity misses",
             demand_cap_alltype,
             c->cap_blockmiss[D4XINSTRN],
             demand_cap_data,
             c->cap_blockmiss[D4XREAD],
             c->cap_blockmiss[D4XWRITE], c->cap_blockmiss[D4XMISC]);

      output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
             "DB conflict misses",
             demand_conf_alltype,
             c->conf_blockmiss[D4XINSTRN],
             demand_conf_data,
             c->conf_blockmiss[D4XREAD],
             c->conf_blockmiss[D4XWRITE], c->conf_blockmiss[D4XMISC]);

      output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
             "DB compulsory fract",
             demand_comp_alltype / NONZERO(demand_alltype),
             c->comp_blockmiss[D4XINSTRN] / NONZERO(c->blockmiss[D4XINSTRN]),
             demand_comp_data / NONZERO(demand_data),
             c->comp_blockmiss[D4XREAD] / NONZERO(c->blockmiss[D4XREAD]),
             c->comp_blockmiss[D4XWRITE] / NONZERO(c->blockmiss[D4XWRITE]),
             c->comp_blockmiss[D4XMISC] / NONZERO(c->blockmiss[D4XMISC]));

      output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
             "DB capacity fract",
             demand_cap_alltype / NONZERO(demand_alltype),
             c->cap_blockmiss[D4XINSTRN] / NONZERO(c->blockmiss[D4XINSTRN]),
             demand_cap_data / NONZERO(demand_data),
             c->cap_blockmiss[D4XREAD] / NONZERO(c->blockmiss[D4XREAD]),
             c->cap_blockmiss[D4XWRITE] / NONZERO(c->blockmiss[D4XWRITE]),
             c->cap_blockmiss[D4XMISC] / NONZERO(c->blockmiss[D4XMISC]));

      output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
             "DB conflict fract",
             demand_conf_alltype / NONZERO(demand_alltype),
             c->conf_blockmiss[D4XINSTRN] / NONZERO(c->blockmiss[D4XINSTRN]),
             demand_conf_data / NONZERO(demand_data),
             c->conf_blockmiss[D4XREAD] / NONZERO(c->blockmiss[D4XREAD]),
             c->conf_blockmiss[D4XWRITE] / NONZERO(c->blockmiss[D4XWRITE]),
             c->conf_blockmiss[D4XMISC] / NONZERO(c->blockmiss[D4XMISC]));
    }

    /* prefetch block misses? */
    if (c->prefetchf != d4prefetch_none) {
      prefetch_data =
        c->blockmiss[D4PREFETCH + D4XMISC] + c->blockmiss[D4PREFETCH +
                                                          D4XREAD] +
        c->blockmiss[D4PREFETCH + D4XWRITE];
      prefetch_alltype = prefetch_data + c->blockmiss[D4PREFETCH + D4XINSTRN];

      output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
             "Prefetch Block Misses",
             prefetch_alltype,
             c->blockmiss[D4PREFETCH + D4XINSTRN],
             prefetch_data,
             c->blockmiss[D4PREFETCH + D4XREAD],
             c->blockmiss[D4PREFETCH + D4XWRITE],
             c->blockmiss[D4PREFETCH + D4XMISC]);

      output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
             "PFB miss rate",
             prefetch_alltype / NONZERO(prefetch_fetch_alltype),
             c->blockmiss[D4PREFETCH +
                          D4XINSTRN] / NONZERO(c->fetch[D4PREFETCH +
                                                        D4XINSTRN]),
             prefetch_data / NONZERO(prefetch_fetch_data),
             c->blockmiss[D4PREFETCH +
                          D4XREAD] / NONZERO(c->fetch[D4PREFETCH + D4XREAD]),
             c->blockmiss[D4PREFETCH +
                          D4XWRITE] / NONZERO(c->fetch[D4PREFETCH +
                                                       D4XWRITE]),
             c->blockmiss[D4PREFETCH +
                          D4XMISC] / NONZERO(c->fetch[D4PREFETCH + D4XMISC]));

      if (c->flags & D4F_CCC) {
        demand_comp_data =
          c->comp_blockmiss[D4PREFETCH + D4XMISC] +
          c->comp_blockmiss[D4PREFETCH + D4XREAD] +
          c->comp_blockmiss[D4PREFETCH + D4XWRITE];
        demand_comp_alltype =
          demand_comp_data + c->comp_blockmiss[D4PREFETCH + D4XINSTRN];
        demand_cap_data =
          c->cap_blockmiss[D4PREFETCH + D4XMISC] +
          c->cap_blockmiss[D4PREFETCH + D4XREAD] +
          c->cap_blockmiss[D4PREFETCH + D4XWRITE];
        demand_cap_alltype =
          demand_cap_data + c->cap_blockmiss[D4PREFETCH + D4XINSTRN];
        demand_conf_data =
          c->conf_blockmiss[D4PREFETCH + D4XMISC] +
          c->conf_blockmiss[D4PREFETCH + D4XREAD] +
          c->conf_blockmiss[D4PREFETCH + D4XWRITE];
        demand_conf_alltype =
          demand_conf_data + c->conf_blockmiss[D4PREFETCH + D4XINSTRN];

        output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
               "PFB comp misses",
               demand_comp_alltype,
               c->comp_blockmiss[D4PREFETCH + D4XINSTRN],
               demand_comp_data,
               c->comp_blockmiss[D4PREFETCH + D4XREAD],
               c->comp_blockmiss[D4PREFETCH + D4XWRITE],
               c->comp_blockmiss[D4PREFETCH + D4XMISC]);

        output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
               "PFB cap misses",
               demand_cap_alltype,
               c->cap_blockmiss[D4PREFETCH + D4XINSTRN],
               demand_cap_data,
               c->cap_blockmiss[D4PREFETCH + D4XREAD],
               c->cap_blockmiss[D4PREFETCH + D4XWRITE],
               c->cap_blockmiss[D4PREFETCH + D4XMISC]);

        output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
               "PFB conf misses",
               demand_conf_alltype,
               c->conf_blockmiss[D4PREFETCH + D4XINSTRN],
               demand_conf_data,
               c->conf_blockmiss[D4PREFETCH + D4XREAD],
               c->conf_blockmiss[D4PREFETCH + D4XWRITE],
               c->conf_blockmiss[D4PREFETCH + D4XMISC]);

        output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
               "PFB comp fract",
               demand_comp_alltype / NONZERO(prefetch_alltype),
               c->comp_blockmiss[D4PREFETCH +
                                 D4XINSTRN] /
               NONZERO(c->blockmiss[D4PREFETCH + D4XINSTRN]),
               demand_comp_data / NONZERO(prefetch_data),
               c->comp_blockmiss[D4PREFETCH +
                                 D4XREAD] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                 D4XREAD]),
               c->comp_blockmiss[D4PREFETCH +
                                 D4XWRITE] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                  D4XWRITE]),
               c->comp_blockmiss[D4PREFETCH +
                                 D4XMISC] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                 D4XMISC]));

        output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
               "PFB cap fract",
               demand_cap_alltype / NONZERO(prefetch_alltype),
               c->cap_blockmiss[D4PREFETCH +
                                D4XINSTRN] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                  D4XINSTRN]),
               demand_cap_data / NONZERO(prefetch_data),
               c->cap_blockmiss[D4PREFETCH +
                                D4XREAD] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                D4XREAD]),
               c->cap_blockmiss[D4PREFETCH +
                                D4XWRITE] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                 D4XWRITE]),
               c->cap_blockmiss[D4PREFETCH +
                                D4XMISC] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                D4XMISC]));

        output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
               "PFB conf fract",
               demand_conf_alltype / NONZERO(prefetch_alltype),
               c->conf_blockmiss[D4PREFETCH +
                                 D4XINSTRN] /
               NONZERO(c->blockmiss[D4PREFETCH + D4XINSTRN]),
               demand_conf_data / NONZERO(prefetch_data),
               c->conf_blockmiss[D4PREFETCH +
                                 D4XREAD] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                 D4XREAD]),
               c->conf_blockmiss[D4PREFETCH +
                                 D4XWRITE] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                  D4XWRITE]),
               c->conf_blockmiss[D4PREFETCH +
                                 D4XMISC] / NONZERO(c->blockmiss[D4PREFETCH +
                                                                 D4XMISC]));
      }

      output("%-21s\t\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\t%12.0f\n",
             "Total Block Misses",
             demand_alltype + prefetch_alltype,
             c->blockmiss[D4XINSTRN] + c->blockmiss[D4PREFETCH + D4XINSTRN],
             demand_data + prefetch_data,
             c->blockmiss[D4XREAD] + c->blockmiss[D4PREFETCH + D4XREAD],
             c->blockmiss[D4XWRITE] + c->blockmiss[D4PREFETCH + D4XWRITE],
             c->blockmiss[D4XMISC] + c->blockmiss[D4PREFETCH + D4XMISC]);

      output("%-21s\t\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\t%12.4f\n",
             "Tot blk miss rate",
             (demand_alltype +
              prefetch_alltype) / NONZERO(demand_fetch_alltype +
                                          prefetch_fetch_alltype),
             (c->blockmiss[D4XINSTRN] +
              c->blockmiss[D4PREFETCH +
                           D4XINSTRN]) / NONZERO(c->fetch[D4XINSTRN] +
                                                 c->fetch[D4PREFETCH +
                                                          D4XINSTRN]),
             (demand_data + prefetch_data) / NONZERO(demand_fetch_data +
                                                     prefetch_fetch_data),
             (c->blockmiss[D4XREAD] +
              c->blockmiss[D4PREFETCH +
                           D4XREAD]) / NONZERO(c->fetch[D4XREAD] +
                                               c->fetch[D4PREFETCH +
                                                        D4XREAD]),
             (c->blockmiss[D4XWRITE] +
              c->blockmiss[D4PREFETCH +
                           D4XWRITE]) / NONZERO(c->fetch[D4XWRITE] +
                                                c->fetch[D4PREFETCH +
                                                         D4XWRITE]),
             (c->blockmiss[D4XMISC] +
              c->blockmiss[D4PREFETCH +
                           D4XMISC]) / NONZERO(c->fetch[D4XMISC] +
                                               c->fetch[D4PREFETCH +
                                                        D4XMISC]));
    }                           /* end of prefetch block misses */
    output("\n");
  }                             /* end of block misses */

  /* report multiblock and traffic to/from memory */
  output("%-21s\t\t%12.0f\n", "Multi-block refs", c->multiblock);
  output("%-21s\t\t%12.0f\n", "Bytes From Memory", c->bytes_read);
  output("%-21s\t\t%12.4f\n",
         "( / Demand Fetches)",
         c->bytes_read / NONZERO(demand_fetch_alltype));
  output("%-21s\t\t%12.0f\n", "Bytes To Memory", c->bytes_written);
  output("%-21s\t\t%12.4f\n",
         "( / Demand Writes)",
         c->bytes_written / NONZERO(c->fetch[D4XWRITE]));
  output("%-21s\t\t%12.0f\n", "Total Bytes r/w Mem",
         c->bytes_read + c->bytes_written);
  output("%-21s\t\t%12.4f\n", "( / Demand Fetches)",
         (c->bytes_read + c->bytes_written) / NONZERO(demand_fetch_alltype));
  output("\n");
}
