/* config.h.  Generated automatically by configure.  */
/*
 * config.h.in.  Generated initially from configure.in by autoheader,
 * but now maintained manually.
 */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The number of bytes in a short.  */
#define SIZEOF_SHORT 2

/* type for random, if not defined in stdlib.h */
/* #undef D4_RANDOM_DEF */

/* RMR - Define an address to be 8 bytes = 64 bits.  */
#define D4ADDR unsigned long long

#define u64bitint unsigned long long 
