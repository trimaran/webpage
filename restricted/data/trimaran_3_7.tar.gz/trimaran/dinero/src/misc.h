// Copyright 2002
// Weng-Fai Wong (wongwf@comp.nus.edu.sg)
// Rodric M. Rabbah (rabbah@ee.gatech.edu)
// All Rights Reserved


D4_INLINE void d4init_rep_lru(d4cache * c);
D4_INLINE void d4init_rep_fifo(d4cache * c);
D4_INLINE void d4init_rep_random(d4cache * c);
D4_INLINE void d4init_prefetch_none(d4cache * c);
D4_INLINE void d4init_prefetch_always(d4cache * c, int dist, int abortpct);
D4_INLINE void d4init_prefetch_loadforw(d4cache * c, int dist, int abortpct);
D4_INLINE void d4init_prefetch_subblock(d4cache * c, int dist, int abortpct);
D4_INLINE void d4init_prefetch_miss(d4cache * c, int dist, int abortpct);
D4_INLINE void d4init_prefetch_tagged(d4cache * c, int dist, int abortpct);
D4_INLINE void d4init_walloc_always(d4cache * c);
D4_INLINE void d4init_walloc_never(d4cache * c);
D4_INLINE void d4init_walloc_nofetch(d4cache * c);
D4_INLINE void d4init_wback_always(d4cache * c);
D4_INLINE void d4init_wback_never(d4cache * c);
D4_INLINE void d4init_wback_nofetch(d4cache * c);
D4_INLINE void d4movetotop(d4cache * c, int stacknum, d4stacknode * ptr);
D4_INLINE void d4movetobot(d4cache * c, int stacknum, d4stacknode * ptr);
D4_INLINE void d4hash(d4cache * c, int stacknum, d4stacknode * s);
D4_INLINE void d4_unhash(d4cache * c, int stacknum, d4stacknode * s);
D4_INLINE void d4put_mref(d4pendstack * m);
D4_INLINE void d4_dopending(d4cache * c, d4pendstack * newm);
D4_INLINE void d4_wbblock(d4cache * c, d4stacknode * ptr, const int lg2sbsize);
D4_INLINE void d4_invblock(d4cache * c, int stacknum, d4stacknode * ptr);
D4_INLINE void d4copyback(d4cache * c, const d4memref * m, int prop);
D4_INLINE void d4invalidate(d4cache * c, const d4memref * m, int prop);
D4_INLINE void d4_invinfcache(d4cache * c, const d4memref * m);
D4_INLINE void d4customize(FILE * f);
D4_INLINE d4stacknode *d4_find(d4cache * c, int stacknum, d4addr blockaddr);
D4_INLINE d4stacknode *d4findnth(d4cache * c, int stacknum, int n);
D4_INLINE d4pendstack *d4get_mref();
