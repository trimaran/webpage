#include <stdlib.h>

typedef struct {
  int x;
  int y;
} X;

int main()
{
  X* xxx;
  int i = 3;

  xxx = (X*) malloc(sizeof(X) * 100);
  
  xxx[i].y = 4;
  
  i = xxx[i].x;
  xxx->x = 1;
  i = xxx->y;

  printf("done\n");
  return 0;
}
