/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1994 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           operand.h
//      Authors:        Vinod Kathail, Sadun Anik, Richard Johnson,
//                      Santosh Abraham, Scott Mahlke, Dave August,
//                      Joel Jones, Greg Snider, Sumedh Sathaye
//      Created:        December 1994
//      Description:    Operand class declaration 
//
/////////////////////////////////////////////////////////////////////////////

/*--------------------------------------------------------------------------  
  Operand and its derived classes.
    Operand is a pure class and cannot be instantiated, only its subclasses
    can be. Reg class is mutable; all others are not. 

    Reg: This represents an EVR and its binding to a physical register.
    VR_name: This reperesents the name of an EVR (argument to remap())
    Mem_vr: Virtual registers for annotating  memory depndences 
    Macro_reg: Ala Lcode

    Int_lit: Integer literals
    Pred_lit: Predicate literal
    Float_lit: Single precision floating point literals
    Double_lit: Double precision floating point literals
    String_lit: String literals
    Label_lit: Labels 
    Cb: Control block ala Lcode

    Undefined: To denote operands that have not been specified.

    Derived classes have class specific functions, that can be accessed only
    through these classes. An Operand class must be first cast to one of
    these classes to make use of class specific functions.
    (Do we want to change this?) 

----------------------------------------------------------------------------*/
    

#ifndef _OPERAND_H
#define _OPERAND_H

#include <iostream.h>
#include "defs.h"
#include "string_class.h"
#include "hash_map.h"
#include "el_symbol_table.h"

class Symbol_table_info ;

extern int virtual_register_number; /* Virtual_register_number to generate 
                                       unique numbers */
void adjust_vr_num(int number);     /* set virtual_register_number to
                                    max of number and itself */
enum Data_type {
  // Integer data types
  EL_DT_VOID=0,
  EL_DT_bool,		// 1-bit data, not used as a guard
  EL_DT_CHAR,
  EL_DT_UCHAR,
  EL_DT_SHORT,
  EL_DT_USHORT,
  EL_DT_INT,
  EL_DT_UINT,
  EL_DT_LONG,
  EL_DT_ULONG,
  EL_DT_LLONG,
  EL_DT_ULLONG,
  EL_DT_LLLONG,
  EL_DT_ULLLONG,
  EL_DT_POINTER,
  // FP data types
  EL_DT_FLOAT,
  EL_DT_DOUBLE,
  // Misc data types
  EL_DT_BRANCH,		// branch target address
  EL_DT_PREDICATE,	// 1-bit data used as a guard
  // label+string data types
  EL_DT_LOCAL_ABS,
  EL_DT_LOCAL_GP,
  EL_DT_GLOBAL_ABS,
  EL_DT_GLOBAL_GP
};

extern eString data_type_to_text(Data_type d);

enum Reg_file {
  FIRST_FILE=0,
  GPR=0,
  FPR=1,
  PR=2,
  BTR=3,
  CR=4,
  VIR=5,
  VFR=6,
  LAST_FILE=6,
  NUM_REG_FILE=7
};

enum Reg_sr {
  STATIC,
  ROTATING
};

enum Macro_name {
  UNDEFINED=0,
  LOCAL,
  PARAM,
  SWAP,
  INT_RETURN_TYPE,
  FLT_RETURN_TYPE,
  DBL_RETURN_TYPE,
  INT_RETURN,
  INT_PARAM_1,
  INT_PARAM_2,
  INT_PARAM_3,
  INT_PARAM_4,
  FLT_RETURN,
  FLT_PARAM_1,
  FLT_PARAM_2,
  FLT_PARAM_3,
  FLT_PARAM_4,
  DBL_RETURN,
  DBL_PARAM_1,
  DBL_PARAM_2,
  INT_TM_TYPE,		/* INT Thru memory parameter */
  FLT_TM_TYPE,		/* INT Thru memory parameter */
  DBL_TM_TYPE,		/* INT Thru memory parameter */
  SP_REG,		/* Stack pointer */
  FP_REG,		/* Frame pointer */
  IP_REG,		/* pointer to incoming parameter space */
  OP_REG,		/* pointer to outgoing parameter space */
  LV_REG,		/* pointer to local variable space     */
  RGS_REG,		/* pointer to register swap space      */
  LC_REG,		/* Loop counter */
  ESC_REG,		/* Epilogue stage counter */
  ALL_PRED,  		/* used to refer to the entire predicate register file */
  ALL_ROT_PRED,		/* all the rotating predicate regs */
  ALL_STATIC_PRED,	/* all the non-rotating predicate regs */
  RRB,
  RETURN_ADDR,
  FLT_ZERO,
  FLT_ONE,
  DBL_ZERO,
  DBL_ONE,
  INT_ZERO,
  PRED_FALSE,
  PRED_TRUE,
  SPILL_TEMPREG,
  PV_0,                 // PV_0, ..., PV_7 are control register aliases for
  PV_1,                 // 32-bit wide access to predicate registers.
  PV_2,
  PV_3,
  PV_4,
  PV_5,
  PV_6,
  PV_7,
  LAST_MACRO		/* Insert all macros before this one! */
};


//
//	Operand for generic branch opcodes used for control flow analysis (BRDIR)
//
enum General_Branch_Cond {
  COND_W_FALSE=1,
  COND_W_EQ,
  COND_W_LT,
  COND_W_LEQ,
  COND_W_GT,
  COND_W_GEQ,
  COND_W_SV,
  COND_W_OD,
  COND_W_TRUE,
  COND_W_NEQ,
  COND_W_LLT,
  COND_W_LLEQ,
  COND_W_LGT,
  COND_W_LGEQ,
  COND_W_NSV,
  COND_W_EV,
  COND_S_FALSE,
  COND_S_EQ,
  COND_S_LT,
  COND_S_LEQ,
  COND_S_GT,
  COND_S_GEQ,
  COND_S_NEQ,
  COND_S_TRUE,
  COND_D_FALSE,
  COND_D_EQ,
  COND_D_LT,
  COND_D_LEQ,
  COND_D_GT,
  COND_D_GEQ,
  COND_D_NEQ,
  COND_D_TRUE,
  COND_LAST	// Not used!!
};

Reg_file data_type_to_file (Data_type d) ;

class Operand ;
class Base_operand ;

//////////////////////////////////////////////////////////////////////////
//
// Symboltable_entry class (like and operand butprovides deep equality for symbol table)
//
//////////////////////////////////////////////////////////////////////////

class Symboltable_entry {
   friend ostream& operator<<(ostream& os, const Symboltable_entry& operand);
   friend unsigned hash_symboltable_entry(Symboltable_entry&) ;
   friend class Operand ;
public:
   Symboltable_entry() ;
   Symboltable_entry(const Symboltable_entry&) ;
   Symboltable_entry(Base_operand*) ;
   ~Symboltable_entry() ;
   
   Symboltable_entry& operator=(const Symboltable_entry&) ;
   bool operator==(const Symboltable_entry&) const;
   bool operator!=(const Symboltable_entry&) const;
   bool operator<(const Symboltable_entry&) const;
   
private:
   Base_operand * operand_ptr ;
};

/*
   ---------------------------------------------------------------------------
   Base_operand base class
   ----------------------------------------------------------------------------
   */

class Base_operand {
   friend ostream& operator<<(ostream& os, const
			      Base_operand& operand);
public:
   Base_operand(); Base_operand (const Base_operand&);
   virtual Base_operand* clone() const = 0; //  Polymorphic copy operation.
   virtual ~Base_operand();

   Base_operand& operator=(const Base_operand&);
   virtual bool operator==(const Base_operand&) const = 0;
   virtual bool operator!=(const Base_operand&) const;

   virtual bool same_operand_class(const Base_operand&) const ;
   virtual bool is_identical(const Base_operand&) const = 0;

   virtual bool is_undefined() const;
   virtual bool is_reg() const;
   virtual bool is_vr_name() const;
   virtual bool is_mem_vr() const;
   virtual bool is_macro_reg() const;
   virtual bool is_lit() const;
   virtual bool is_int() const;
   virtual bool is_predicate() const;
   virtual bool is_predicate_true() const;
   virtual bool is_predicate_false() const;
   virtual bool is_float() const;
   virtual bool is_double() const;
   virtual bool is_string() const;
   virtual bool is_label() const; 
   virtual bool is_cb() const ;
   virtual bool assigned_to_file() const; // For literals,always returns true. 
   virtual bool allocated() const;        // For literals, always returns true.

   virtual int hash() const = 0 ;

   virtual int omega() const;
   virtual void set_omega(int) ;
   
   virtual Data_type data_type() const;
   virtual void set_data_type(Data_type);

   // Only for Reg, Macro_reg, VR_name, and Undefined asserts 0 for others
   virtual Reg_file file_type() const;

   // physical register file binding, for reg and lits, asserts 0 for others
   virtual eString physical_file_type() const ;
   virtual void bind_physical_file(eString phys_file) ;
   virtual void unbind_physical_file() ;
   virtual bool assigned_to_physical_file() const { return false; } ;

protected:
   virtual void print(ostream&) const = 0;
};


/*----------------------------------------------------------------------------
  Registers
  This class represents an EVR and its binding to a physical register. There
  is no separate class for just physical registers. 

  The class provides three types of equality operations. Equal_vr is used to
  check if two registers are the same virtual register (including omega).
  Equal_mc is used to check if they are the same physical register. The ==
  operator is somewhat unconvetional and encodes a frequently occuring test(I
  think).  If both registers are bound to physical registers, then == behaves
  like equal_mc. Otherwise, it behaves like equal_vr.

  Printed representation:  vr<int>[<omega>] :<file>
                          | <file><int> | <file>[<int>]
	  The first is used for vrs that are not bound to register. If omega =
	  0, then it is not printed. Similarly, if vr is not assigned to a
	  file, the file part is not printed. Second is used for vrs bound to
	  static registers, and the third for vrs bound to rotating registers.
----------------------------------------------------------------------------*/

class Reg  : public Base_operand {
public:
   Reg(Data_type);
   Reg(Data_type data_type, int vr_number, int omega = 0);
   Reg(Data_type data_type, Reg_file r_file, int vr_number);
   Reg(const Reg&);
   Reg(const class Operand&);  // initialize from Reg or VR_name
   Base_operand* clone() const;
   ~Reg();

   Reg& operator=(const Reg&);
   bool operator==(const Base_operand&) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_reg() const;
   bool assigned_to_file() const;
   bool allocated() const;

   /* Class specific functions */

   bool equal_vr(const Base_operand&) const;
   bool equal_mc(const Base_operand&) const;
      
   void set_data_type(Data_type) ;
   Data_type data_type() const;
   int vr_num() const;
   int omega() const;
   Reg_file file_type() const;
   bool is_static() const;
   bool is_rotating() const;
   int mc_num() const;
   Reg& rename();
   Reg& rename(int new_vr_rep);
   Reg& incr_omega (int incr = 1);
   Reg& bind_file(Reg_file, Reg_sr);
   Reg& bind_reg(int);
   Reg& unbind_reg();
   void set_vr_num(int);
   void set_omega(int) ;

   // physical register file binding, for reg and lits
   eString physical_file_type() const;
   void bind_physical_file(eString phys_file);
   void unbind_physical_file();
   bool assigned_to_physical_file() const;

   virtual int hash() const ;

protected:
   void print(ostream&) const;

private:
  Data_type d_type;		// data type of register
  Reg_file file;		// register file identifier
  eString physical_file;	// physical register file identifier
  int vr_rep;			// virtual register number
  int omega_num;		// omega
  int history;			// number for tracking renamed registers
  bool assigned;		// assigend to a register file
  bool alloc;			// allocated to a machine register
  Reg_sr sr;			// flag for static/dynamic register 
  int mc_rep;			// machine register number
};

////////////////////////////////////////////////////////////////////////////
//
//  VR_name 
//  This class provides the operand for a remap operation. This operand 
//  defines the virtual register name part of an EVR
//
////////////////////////////////////////////////////////////////////////////


class VR_name  : public Base_operand {
public:
   VR_name(const Reg);
   VR_name(const Operand);
   VR_name(Data_type data_type, int vr_number);
   Base_operand* clone() const;
   ~VR_name();

   bool operator==(const Base_operand&) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_vr_name() const;

   /* Class specific functions */

   bool same_name(const Base_operand&) const;
   Data_type data_type() const;
   void set_data_type(Data_type);
   int vr_num() const;
   VR_name& rename(const Reg&);
   void set_vr_num(int);

   virtual int hash() const ;

protected:
   void print(ostream&) const;

private:
   Data_type d_type;		// data type of register
   int vr_rep;			// virtual register number
};


/*----------------------------------------------------------------------------
 Mem_vr
  This class represents EVRs used for memory dependences. It is like Reg class
  except that these are not bound to physical registers.
  Mem_vrs are assumed to be assigned and allocated, i.e., the corresponding 
  queries always return TRUE.

  Printed representation:  vr<int>[<omega>]
                           If omega =  0, then it is not printed. 
----------------------------------------------------------------------------*/

class Mem_vr  : public Base_operand {
public:
   Mem_vr();
   Mem_vr(int vr_number, int omega = 0);
   Mem_vr(const Mem_vr&);
   Base_operand* clone() const;
   ~Mem_vr();

   Mem_vr& operator=(const Mem_vr&);
   bool operator==(const Base_operand&) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_mem_vr() const;

   /* Class specific functions */
   int vr_num() const;
   int omega() const;
   Mem_vr& rename();
   Mem_vr& rename(int);
   Mem_vr& incr_omega (int incr = 1);
   void set_vr_num(int);
   void set_omega(int);

   virtual int hash() const ;
      
protected:
   void print(ostream&) const;

private:
   int vr_rep;			// virtual register number
   int omega_num;		// omega
   int history;			// number for tracking renamed registers
};

/* -------------------------------------------------------------------------
   Macro Registers  
   ala Lcode
   Printed representation: mr.<string>:<file>
---------------------------------------------------------------------------- */

class Macro_reg : public Base_operand {
public:
   Macro_reg();
   Macro_reg(Macro_name) ;
   Macro_reg(const Macro_reg&) ;
   Base_operand* clone() const;
   ~Macro_reg() ;
   
   Macro_reg& operator=(const Macro_reg&) ;
   bool operator==(const Base_operand&) const ;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_macro_reg() const ;
   bool is_fragile_macro() const ;
   bool is_predicate_true() const;
   bool is_predicate_false() const;
  
   Data_type data_type() const;
   void set_data_type(Data_type);

   Reg_file file_type() const;

   /* class specific function */
   Macro_name name() const;
   void set_name(Macro_name);

   // physical register file binding, for reg and lits
   eString physical_file_type() const;
   void bind_physical_file(eString phys_file);
   void unbind_physical_file();
   bool assigned_to_physical_file() const;

   virtual int hash() const ;
  
protected:
   void print(ostream&) const;   

private:
   Data_type d_type;		// data type of register
   Reg_file file;		// register file identifier   
   eString physical_file;	// physical register file identifier
   Macro_name name_rep;
};
   


/* --------------------------------------------------------------------------
  Integer literals. 
   Printed represntation: I:<number>
--------------------------------------------------------------------------- */
class Int_lit : public Base_operand{

public:
  Int_lit(int, Data_type data_type = EL_DT_INT);
  Int_lit(const Int_lit&);
  Base_operand* clone() const;
  ~Int_lit();
  
  Int_lit& operator=(const Int_lit&);
  bool operator==(const Base_operand&) const;
  
  bool same_operand_class(const Base_operand&) const ;
  bool is_identical(const Base_operand&) const ;
  
  bool is_lit() const;
  bool is_int() const;
  
  /*   bool is_shortlit() const;
       bool is_mediumlit() const;
       bool is_longlit() const; */
  
  /* Class specific function */
  int value() const;
  int int_value() const;
  void set_value(int);
  Data_type data_type() const;
  void set_data_type(Data_type);

   // physical register file binding, for reg and lits
   eString physical_file_type() const;
   void bind_physical_file(eString phys_file);
   void unbind_physical_file();
   bool assigned_to_physical_file() const;

  virtual int hash() const ;
  
protected:
   void print(ostream&) const;

private:
   int rep;
   Data_type d_type;		// Data type of literal
   eString physical_file;	// physical register file identifier
};

/* ----------------------------------------------------------------------------
   Predicate literals. 
   Printed representation: P:<number>
---------------------------------------------------------------------------- */
class Pred_lit : public Base_operand{

public:
   Pred_lit(bool, Data_type data_type = EL_DT_PREDICATE);
   Pred_lit(const Pred_lit&);
   Base_operand* clone() const;
   ~Pred_lit() ;

   Pred_lit& operator=(const Pred_lit&);
   bool operator==(const Base_operand& op) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_lit() const;
   bool is_predicate() const;
   bool is_predicate_true() const;
   bool is_predicate_false() const;

   /* Class specific function */
   bool value() const;
   void set_value(bool);
   Data_type data_type() const;
   void set_data_type(Data_type);

   virtual int hash() const ;
  
protected:
   void print(ostream&) const;

private:
   bool rep;
   Data_type d_type;
};


/* --------------------------------------------------------------------------
  Single precision floating point literals. 
   Printed represntation: F:<number> 
--------------------------------------------------------------------------- */
class Float_lit : public Base_operand{
public:
   Float_lit(float, Data_type data_type = EL_DT_FLOAT);
   Float_lit(const Float_lit&);
   Base_operand* clone() const;
   ~Float_lit();

   Float_lit& operator=(const Float_lit&);
   bool operator==(const Base_operand&) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_lit() const;
   bool is_float() const;

   /* Class specific function */
   float value() const;
   void set_value(float);
   Data_type data_type() const;
   void set_data_type(Data_type);

   // physical register file binding, for reg and lits
   eString physical_file_type() const;
   void bind_physical_file(eString phys_file);
   void unbind_physical_file();
   bool assigned_to_physical_file() const;

   virtual int hash() const ;
  
protected:
   void print(ostream&) const;

private:
   float rep;
   Data_type d_type;
   eString physical_file;	// physical register file identifier
};

/* --------------------------------------------------------------------------
  Double precision floating point literals. 
   Printed represntation: D:<number> 
--------------------------------------------------------------------------- */
class Double_lit : public Base_operand{
public:
   Double_lit(double, Data_type data_type = EL_DT_DOUBLE);
   Double_lit(const Double_lit&);
   Base_operand* clone() const;
   ~Double_lit();

   Double_lit& operator=(const Double_lit&);
   bool operator==(const Base_operand&) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_lit() const;
   bool is_double() const;

   /* Class specific function */
   double value() const;
   void set_value(double);
   Data_type data_type() const;
   void set_data_type(Data_type);

   // physical register file binding, for reg and lits
   eString physical_file_type() const;
   void bind_physical_file(eString phys_file);
   void unbind_physical_file();
   bool assigned_to_physical_file() const;

   virtual int hash() const ;
  
protected:
   void print(ostream&) const;

private:
   double rep;
   Data_type d_type;
   eString physical_file;	// physical register file identifier
};

/* --------------------------------------------------------------------------
  String literals. 
   Printed represntation: S:<string> 
--------------------------------------------------------------------------- */
class String_lit : public Base_operand{
public:
   String_lit(const eString&, Data_type data_type = EL_DT_GLOBAL_ABS);
   String_lit(const String_lit&);
   Base_operand* clone() const;
   ~String_lit();

   String_lit& operator=(const String_lit&);
   bool operator==(const Base_operand&) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_lit() const;
   bool is_string() const;

   /* Class specific function */
   eString value() const;
   void set_value(eString);
   Data_type data_type() const;
   void set_data_type(Data_type);

   // physical register file binding, for reg and lits
   eString physical_file_type() const;
   void bind_physical_file(eString phys_file);
   void unbind_physical_file();
   bool assigned_to_physical_file() const;

   virtual int hash() const ;
  
protected:
   void print(ostream&) const;

private:
   eString rep;
   Data_type d_type;		// Data type of string
   eString physical_file;
};

/* --------------------------------------------------------------------------
  Labels
   Printed represntation: L:<string> 
--------------------------------------------------------------------------- */
class Label_lit : public Base_operand {
public:
   Label_lit(const eString&, Data_type data_type = EL_DT_GLOBAL_ABS);
   Label_lit(const Label_lit&);
   Base_operand* clone() const;
   ~Label_lit();

   Label_lit& operator=(const Label_lit&);
   bool operator==(const Base_operand&) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_lit() const;
   bool is_label() const;

   /* Class specific function */
   eString value() const;
   void set_value(eString);
   Data_type data_type() const;
   void set_data_type(Data_type);

   // physical register file binding, for reg and lits
   eString physical_file_type() const;
   void bind_physical_file(eString phys_file);
   void unbind_physical_file();
   bool assigned_to_physical_file() const;

   virtual int hash() const ;
  
protected:
   void print(ostream&) const;

private:
   eString rep;
   Data_type d_type;		// Data type of label
   eString physical_file;
};

/* ---------------------------------------------------------------------------
   Control Blocks
   Print CB:<number>
---------------------------------------------------------------------------- */

class Cb_operand : public Base_operand{

public:
   Cb_operand(int, Data_type data_type = EL_DT_BRANCH);
   Cb_operand(const Cb_operand&);
   Base_operand* clone() const;
   ~Cb_operand();

   Cb_operand& operator=(const Cb_operand&);
   bool operator==(const Base_operand&) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_lit() const;
   bool is_cb() const;

   /* Class specific function */
   int id() const;
   void set_id(int);
   Data_type data_type() const;
   void set_data_type(Data_type);

   // physical register file binding, for reg and lits
   eString physical_file_type() const;
   void bind_physical_file(eString phys_file);
   void unbind_physical_file();
   bool assigned_to_physical_file() const;

   virtual int hash() const ;
  
protected:
   void print(ostream&) const;

private:
   int id_rep;
   Data_type d_type;		// Data type of label
   eString physical_file;
};
/* --------------------------------------------------------------------------
   Undefined operand class. 
   Printed representation: undefined?
--------------------------------------------------------------------------  */
class Undefined : public Base_operand {
public:
   Undefined();
   Undefined (const Undefined&);
   Base_operand* clone() const;
   ~Undefined();

   Undefined& operator=(const Undefined&);
   bool operator==(const Base_operand&) const;

   bool same_operand_class(const Base_operand&) const ;
   bool is_identical(const Base_operand&) const ;

   bool is_undefined() const;
   virtual Data_type data_type() const { return (EL_DT_INT); }

   virtual int hash() const ;
  
protected:
   void print(ostream&) const;
};

////////////////////////////////////////////////////////////////////////////
//  Operand class  :  An envelope for Base_operand
////////////////////////////////////////////////////////////////////////////

class IR_outstream;

class Operand {
   friend IR_outstream &operator<<(IR_outstream &out, const Operand &);
   friend ostream& operator<<(ostream& os, const Operand& operand);
public:
   Operand() ;
   Operand(const Operand&) ;
   Operand(Base_operand*) ;
   ~Operand() ;
   
   Operand& operator=(const Operand&) ;
   bool operator==(const Operand&) const;
   bool operator!=(const Operand&) const;
   bool operator<(const Operand&) const;
   
   bool same_operand_class(const Operand&) const ;
   bool is_identical(const Operand&) const ;

   bool is_undefined() const;
   bool is_reg() const;
   bool is_vr_name() const;
   bool is_mem_vr() const;
   bool is_macro_reg() const;
   bool is_lit() const;
   bool is_int() const;
   bool is_predicate() const;
   bool is_predicate_true() const;
   bool is_predicate_false() const;
   bool is_float() const;
   bool is_double() const;
   bool is_string() const;
   bool is_label() const;
   bool is_cb() const ;
   bool assigned_to_file() const; // For literals,always returns true.
   bool allocated() const;        // For literals, always returns true.
   Reg_file file_type() const;
   Data_type data_type() const;
   void set_data_type(Data_type t);
   int data_type_width() const;   // hardwired according to datatypes

   // Reg class methods
   bool equal_vr(const Operand&) const;
   bool equal_mc(const Operand&) const;
   bool is_static() const;
   bool is_rotating() const;
   int mc_num() const;
   Operand& bind_file(Reg_file, Reg_sr);
   Operand& bind_reg(int);
   Operand& unbind_reg();
   
   // Reg and Memvr class methods
   int vr_num() const;
   int omega() const;
   int min_omega() const;
   int max_omega() const;   
   Operand& rename();
   Operand& rename(int);
   Operand& incr_omega (int incr = 1);
   void set_vr_num(int);
   void set_omega(int);

   // Vr_name methods
   bool is_same_name(const Operand&) const;
   
   // Macro_reg class methods
   Macro_name name() const;
   void set_name(Macro_name);
   bool is_fragile_macro();
  
   // Cb class methods
   int id() const ;
   void set_id(int);
   
   // value mehods for literal classes
   bool pred_value() ;
   void set_pred_value(bool);
   int int_value() ;
   void set_int_value(int);
   double float_value() ;
   void set_float_value(double);
   double double_value() ;
   void set_double_value(double);
   eString string_value() ;
   void set_string_value(eString);
   eString label_value() ;
   void set_label_value(eString);


   eString physical_file_type() const;
   void bind_physical_file(eString phys_file);
   void unbind_physical_file();
   bool assigned_to_physical_file() const;
    
   void validate_and_point_to(Base_operand* base_ptr) ;

   inline Base_operand* get_ptr() { return (sptr->optr) ; }

  // Global Symbol Table Management
  static void init_global_symbol_table();
  static void clear_global_symbol_table();

private:
   static Hash_map<Symboltable_entry,Symbol_table_info> global_symbol_table ;
   static Symbol_table_info* undefined_base ;
   Symbol_table_info* sptr ;
};


unsigned hash_operand(Operand& oprnd) ;
unsigned hash_symboltable_entry(Symboltable_entry& oprnd) ;




// Debug pointers (for use in gdb)
extern Operand *oper1, *oper2, *oper3 ;

#endif

