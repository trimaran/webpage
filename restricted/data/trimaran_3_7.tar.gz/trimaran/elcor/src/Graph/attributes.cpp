/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1994 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           attributes.cpp
//      Authors:        Sadun Anik, Richard Johnson, Santosh Abraham,
//                      Dave Agust, Vinod Kathail, Brian Deitrich
//      Created:        December 1994
//      Description:    Attributes for IR graph components.
//
/////////////////////////////////////////////////////////////////////////////

#include "attributes.h"
#include "edge.h"
#include "op.h"
#include "region.h"
#include "op_attributes.h"
#include "edge_attributes.h"
#include "region_attributes.h"
#include "el_error.h"

Graph_attribute::Graph_attribute() {}

Graph_attribute::Graph_attribute(Graph_attribute& attr) 
{
   attribute_map = attr.attribute_map ;
   for (Map_domain_iterator<Attribute_type, Base_attribute*> atr_mapi(attribute_map) ; 
	atr_mapi != 0 ; atr_mapi++){
      Attribute_type a_type = *atr_mapi ;
      Base_attribute* tmp_ptr = get_attribute(a_type) ;
      Base_attribute* new_ptr = tmp_ptr->clone_attribute() ;
      if (new_ptr != NULL) {
	 attribute_map.bind(*atr_mapi,new_ptr) ;
      }
   }
}

Graph_attribute::~Graph_attribute() 
{
   for (Map_domain_iterator<Attribute_type, Base_attribute*> atr_mapi(attribute_map) ; 
	atr_mapi != 0 ; ) {
      Attribute_type a_type = *atr_mapi ;
      atr_mapi++;
      Base_attribute* tmp_ptr = get_attribute(a_type) ;
      attribute_map.unbind(a_type) ;
      delete tmp_ptr ;
   }
}

Graph_attribute& Graph_attribute::operator=(Graph_attribute& attr) 
{
   if (this != &attr) {
      attribute_map = attr.attribute_map ;
      for (Map_domain_iterator<Attribute_type, Base_attribute*> atr_mapi(attribute_map);
	   atr_mapi != 0 ; atr_mapi++){
	 Attribute_type a_type = *atr_mapi ;
	 Base_attribute* tmp_ptr = get_attribute(a_type) ;
	 Base_attribute* new_ptr = tmp_ptr->clone_attribute() ;
	 if (new_ptr != NULL) {
	    attribute_map.bind(*atr_mapi,new_ptr) ;
	 }
      }
   }
   return (*this) ;
}

void Graph_attribute::insert_attribute(Attribute_type a_type, Base_attribute* attrib)
{
   attribute_map.bind(a_type,attrib) ;
}

Base_attribute* Graph_attribute::get_attribute(Attribute_type a_type)
{
   if (attribute_map.is_bound(a_type)) {
      return(attribute_map.value(a_type)) ;
   } else {
      return NULL ;
   }
}

void Graph_attribute::remove_attribute(Attribute_type a_type)
{
   Base_attribute* tmp_ptr = get_attribute(a_type) ;
   if (tmp_ptr) {
      delete tmp_ptr ;
      attribute_map.unbind(a_type) ;
   }
}

void Graph_attribute::IR_print_inline(IR_outstream &out)
{}

void Graph_attribute::IR_print_offline(IR_outstream &out)
{}

void Graph_attribute::IR_parse_inline(IR_instream &in)
{}

void Graph_attribute::IR_parse_offline(IR_instream &in)
{}

void Graph_attribute::IR_name_attributes(IR_outstream &out)
{}

/*

void Graph_attribute::delete_attribute(Attribute_type a_type, Base_attribute* ptr) 
{
   Control_flow_freq* cffq ;
   Lcode_attribute_map* lcode_at_map ;
   MemDepProf_attribute_map* mdp_at_map ;
   Liveness_info* li ;
   Merge_op_BB_id* mobbid;
   MS_constraints* constr;
   VR_map* vr_map;
   PQS* pqs;
   Msched_info* msched;
   Generic_attribute_map* gmap ;
   List<Operand>* crl ;
   
   switch (a_type) {
    case MERGE_OP_BB_ID:
      mobbid = (Merge_op_BB_id*) ptr ;
      delete mobbid ;
      break ;
    case CONTROL_FLOW_FREQ:
      cffq = (Control_flow_freq*) ptr ;
      delete cffq ;
      break ;
    case CALL_RETURN_USE_LIST:
    case CALL_RETURN_DEF_LIST:      
      crl = (List<Operand>*) ptr ;
      delete crl ;
      break ;
    case LCODE_ATTRIBUTES:
      lcode_at_map = (Lcode_attribute_map*) ptr ;
      delete lcode_at_map ;
      break ;
    case MEM_DEP_PROF_ATTRIBUTES:
      mdp_at_map = (MemDepProf_attribute_map*) ptr ;
      delete mdp_at_map ;
      break ;
    case LIVENESS_SET:
    case DOWN_EXPOSED_USES_SET:
    case UP_EXPOSED_DEFS_SET:
    case DOWN_EXPOSED_DEFS_SET:
      li = (Liveness_info*) ptr ;
      delete li ;
      break ;
    case MS_CONSTRAINTS:      // Meld scheduling constraints
      constr = (MS_constraints*)ptr;
      delete constr;
      break;
    case LOCAL_VR_MAP:
      vr_map = (VR_map*) ptr;
      delete vr_map;
      break;
    case LOCAL_PQS:
      pqs = (PQS*)ptr;
      delete pqs;
      break;
    case LOCAL_MDES:
      // MDES cannot be deleted
      break;
    case MSCHED_ATTRIBUTES:
      msched = (Msched_info*)ptr;
      delete msched;
      break;
    case GENERIC_ATTRIBUTES:
      gmap = (Generic_attribute_map*) ptr ;
      if (!gmap->is_empty()) {
	 El_warn(" Graph_attribute::delete_attribute: We can't safely delete generic attributes \n \t Some generic attributes are now garbage !") ; // We can't safely delete generic attributes
      }
      delete gmap ;
      break ;
    default:
      assert(0) ;  // add the attribute to the switch statement if necessary
      ;
   }
}
*/
/*
Base_attribute* Graph_attribute::clone_attribute(Attribute_type a_type, Base_attribute* ptr) 
{
   void* new_ptr ;
   Control_flow_freq* cffq ;
   Liveness_info* li ;
   Merge_op_BB_id* mobbid;
   MS_constraints* constr;
   Lcode_attribute_map* lcode_at_map ;
   MemDepProf_attribute_map* mdp_at_map ;
   Msched_info* msched;
   List<Operand>* crl ;
   
   switch (a_type) {
    case MERGE_OP_BB_ID:
      mobbid = (Merge_op_BB_id*) ptr ;
      new_ptr = (void*) (new Merge_op_BB_id(*mobbid));
      break ;
    case CONTROL_FLOW_FREQ:
      cffq = (Control_flow_freq*) ptr ;
      new_ptr = (void*) (new Control_flow_freq(*cffq)) ;
      break ;
    case CALL_RETURN_USE_LIST:
    case CALL_RETURN_DEF_LIST:      
      crl = (List<Operand>*) ptr ;
      new_ptr = (void*) (new List<Operand>(*crl)) ;
      break ;
    case LCODE_ATTRIBUTES:
      lcode_at_map = (Lcode_attribute_map*) ptr ;
      new_ptr = (void*) (new Lcode_attribute_map(*lcode_at_map)) ;
      break ;
    case MEM_DEP_PROF_ATTRIBUTES:
      mdp_at_map = (MemDepProf_attribute_map*) ptr ;
      new_ptr = (void*) (new MemDepProf_attribute_map(*mdp_at_map)) ;
      break ;
    case LIVENESS_SET:
    case DOWN_EXPOSED_USES_SET:
    case UP_EXPOSED_DEFS_SET:
    case DOWN_EXPOSED_DEFS_SET:
      li = (Liveness_info*) ptr ;
      new_ptr = (void*) (new Liveness_info(*li)) ;
      break ;
    case MS_CONSTRAINTS:      // Meld scheduling constraints
      constr = (MS_constraints*)ptr;
      new_ptr = (void*) (new MS_constraints(*constr));
      break;
    case LOCAL_VR_MAP:
      assert(0);
      break;
    case LOCAL_PQS:
      assert(0);
      break;
    case LOCAL_MDES:
      assert(0);
      break;
    case MSCHED_ATTRIBUTES:
      msched = (Msched_info*)ptr;
      new_ptr = (void*) (new Msched_info(*msched));
      break;
    case GENERIC_ATTRIBUTES:
      El_warn(" Graph_attribute::clone_attribute: We can't safely clone generic attributes \n \t Generic attributes are discarded") ;
      break ;
    default:
      assert(0) ;  // add the attribute to the switch statement if necessary
      ;
   }
   return(new_ptr)  ;
}
*/
///////////////////////////////////////////////////////////////////////////

Base_attribute::Base_attribute() {}

Base_attribute::~Base_attribute() {}

///////////////////////////////////////////////////////////////////////////


Merge_op_BB_id* get_existing_merge_op_bb_id(Op* op)
{
  Merge_op_BB_id* tmp_ptr ;
  
  tmp_ptr = (Merge_op_BB_id*) (op->attributes->get_attribute(MERGE_OP_BB_ID));
  return (tmp_ptr) ;
}

Merge_op_BB_id* get_merge_op_bb_id(Op* op)
{
  Merge_op_BB_id* tmp_ptr ;
  
  tmp_ptr = (Merge_op_BB_id*) (op->attributes->get_attribute(MERGE_OP_BB_ID));
  if (tmp_ptr == 0) {
    tmp_ptr = new Merge_op_BB_id;
    op->attributes->insert_attribute(MERGE_OP_BB_ID,tmp_ptr) ;
  }
  return (tmp_ptr) ;
}

void set_merge_op_bb_id(Op* op, Merge_op_BB_id* mobbid) {
  op->attributes->insert_attribute(MERGE_OP_BB_ID, mobbid) ;
}

void remove_merge_op_bb_id(Op* op) {
   op->attributes->remove_attribute(MERGE_OP_BB_ID) ;
}

///////////////////////////////////////////////////////////////////////////

Branch_info_attr* get_branch_info_attr(Op* op)
{
  Branch_info_attr* tmp_ptr ;

  tmp_ptr = (Branch_info_attr*) (op->attributes->get_attribute(BRANCH_INFO_ATTR));
  if (tmp_ptr == 0) {
    tmp_ptr = new Branch_info_attr;
    op->attributes->insert_attribute(BRANCH_INFO_ATTR,tmp_ptr) ;
  }
  return (tmp_ptr) ;
}

void set_branch_info_attr(Op* op, Branch_info_attr* data) {
  op->attributes->insert_attribute(BRANCH_INFO_ATTR, data) ;
}

void remove_branch_info_attr(Op* op) {
   op->attributes->remove_attribute(BRANCH_INFO_ATTR) ;
}

///////////////////////////////////////////////////////////////////////////

Jump_table_name* get_jump_table_name(Op* op)
{
  Jump_table_name* tmp_ptr ;

  tmp_ptr = (Jump_table_name*) (op->attributes->get_attribute(JUMP_TABLE_NAME));
  return (tmp_ptr) ;
}

void set_jump_table_name(Op* op, Jump_table_name* attr)
{
  op->attributes->insert_attribute(JUMP_TABLE_NAME, attr) ;
}

void remove_jump_table_name(Op* op)
{
   op->attributes->remove_attribute(JUMP_TABLE_NAME) ;
}


///////////////////////////////////////////////////////////////////////////

List<Operand>* get_implicit_use_list(Op* op)
{
   Call_return_def_use_list*  tmp_ptr ;
  
  tmp_ptr = (Call_return_def_use_list*)
            (op->attributes->get_attribute(CALL_RETURN_USE_LIST));
  if (tmp_ptr == NULL) {
     return (NULL) ;
  }
  return (tmp_ptr->list) ;
}

void set_implicit_use_list(Op* op, List<Operand>* uselist) {
   Call_return_def_use_list* tmp_ptr = new Call_return_def_use_list() ;
   tmp_ptr->list = uselist ;
   op->attributes->insert_attribute(CALL_RETURN_USE_LIST,tmp_ptr) ;
}
void remove_implicit_use_list(Op* op) {
   op->attributes->remove_attribute(CALL_RETURN_USE_LIST) ;
}

///////////////////////////////////////////////////////////////////////////

List<Operand>* get_implicit_def_list(Op* op)
{
   Call_return_def_use_list*  tmp_ptr ;
  
   tmp_ptr = (Call_return_def_use_list*)
      (op->attributes->get_attribute(CALL_RETURN_DEF_LIST));
  if (tmp_ptr == NULL) {
     return (NULL) ;
  }
   return (tmp_ptr->list) ;
}

void set_implicit_def_list(Op* op, List<Operand>* deflist) {
   Call_return_def_use_list* tmp_ptr = new Call_return_def_use_list() ;
   tmp_ptr->list = deflist ;
   op->attributes->insert_attribute(CALL_RETURN_DEF_LIST,tmp_ptr) ;
}
void remove_implicit_def_list(Op* op) {
   op->attributes->remove_attribute(CALL_RETURN_DEF_LIST) ;
}

///////////////////////////////////////////////////////////////////////////


Control_flow_freq* get_control_flow_freq(Edge* edge) {
   Control_flow_freq* tmp_ptr ;

   tmp_ptr = (Control_flow_freq*) (edge->attributes->get_attribute(CONTROL_FLOW_FREQ));

#if 0
   if (tmp_ptr == 0) {
      tmp_ptr = new Control_flow_freq;
      edge->attributes->insert_attribute(CONTROL_FLOW_FREQ,tmp_ptr) ;
   }
#endif
   return (tmp_ptr) ;
}

void set_control_flow_freq(Edge* edge, Control_flow_freq* cff) {
   edge->attributes->insert_attribute(CONTROL_FLOW_FREQ, cff) ;
}

void remove_control_flow_freq(Edge* edge) {
   edge->attributes->remove_attribute(CONTROL_FLOW_FREQ) ;
}

///////////////////////////////////////////////////////////////////////////


Liveness_info* get_liveness_info(Edge* edge) {
   Liveness_info_attrib* tmp_ptr ;

   tmp_ptr = (Liveness_info_attrib*) (edge->attributes->get_attribute(LIVENESS_SET));
   if (tmp_ptr == NULL) {
      return (NULL) ;
   }
   return (tmp_ptr->info) ;
}

void set_liveness_info(Edge* edge, Liveness_info* li) {
   Liveness_info_attrib* tmp_ptr ;
   tmp_ptr = (Liveness_info_attrib*) (edge->attributes->get_attribute(LIVENESS_SET));
   if (tmp_ptr == NULL) {
      tmp_ptr = new Liveness_info_attrib ;
      tmp_ptr->info = NULL ;
      edge->attributes->insert_attribute(LIVENESS_SET, tmp_ptr) ;
   }
   tmp_ptr->info = li ;
}

void remove_liveness_info(Edge* edge) {
   edge->attributes->remove_attribute(LIVENESS_SET) ;
}

///////////////////////////////////////////////////////////////////////////


Liveness_info* get_down_exposed_uses_info(Edge* edge) {
   Liveness_info_attrib* tmp_ptr ;

   tmp_ptr = (Liveness_info_attrib*) (edge->attributes->get_attribute(DOWN_EXPOSED_USES_SET));
   if (tmp_ptr == NULL) {
      return (NULL) ;
   }
   return (tmp_ptr->info) ;
}

void set_down_exposed_uses_info(Edge* edge, Liveness_info* li) {
   Liveness_info_attrib* tmp_ptr ;
   tmp_ptr = (Liveness_info_attrib*) (edge->attributes->get_attribute(DOWN_EXPOSED_USES_SET));
   if (tmp_ptr == NULL) {
      tmp_ptr = new Liveness_info_attrib ;
      tmp_ptr->info = NULL ;
      edge->attributes->insert_attribute(DOWN_EXPOSED_USES_SET, tmp_ptr) ;
   }
   tmp_ptr->info = li ;
}

void remove_down_exposed_uses_info(Edge* edge) {
   edge->attributes->remove_attribute(DOWN_EXPOSED_USES_SET) ;
}

///////////////////////////////////////////////////////////////////////////


Liveness_info* get_up_exposed_defs_info(Edge* edge) {
   Liveness_info_attrib* tmp_ptr ;

   tmp_ptr = (Liveness_info_attrib*) (edge->attributes->get_attribute(UP_EXPOSED_DEFS_SET));
   if (tmp_ptr == NULL) {
      return (NULL) ;
   }
   return (tmp_ptr->info) ;
}

void set_up_exposed_defs_info(Edge* edge, Liveness_info* li) {
   Liveness_info_attrib* tmp_ptr ;
   tmp_ptr = (Liveness_info_attrib*) (edge->attributes->get_attribute(UP_EXPOSED_DEFS_SET));
   if (tmp_ptr == NULL) {
      tmp_ptr = new Liveness_info_attrib ;
      tmp_ptr->info = NULL ;
      edge->attributes->insert_attribute(UP_EXPOSED_DEFS_SET, tmp_ptr) ;
   }
   tmp_ptr->info = li ;
}

void remove_up_exposed_defs_info(Edge* edge) {
   edge->attributes->remove_attribute(UP_EXPOSED_DEFS_SET) ;
}

///////////////////////////////////////////////////////////////////////////


Liveness_info* get_down_exposed_defs_info(Edge* edge) {
   Liveness_info_attrib* tmp_ptr ;

   tmp_ptr = (Liveness_info_attrib*) (edge->attributes->get_attribute(DOWN_EXPOSED_DEFS_SET));
   if (tmp_ptr == NULL) {
      return (NULL) ;
   }
   return (tmp_ptr->info) ;
}

void set_down_exposed_defs_info(Edge* edge, Liveness_info* li) {
   Liveness_info_attrib* tmp_ptr ;
   tmp_ptr = (Liveness_info_attrib*) (edge->attributes->get_attribute(DOWN_EXPOSED_DEFS_SET));
   if (tmp_ptr == NULL) {
      tmp_ptr = new Liveness_info_attrib ;
      tmp_ptr->info = NULL ;
      edge->attributes->insert_attribute(DOWN_EXPOSED_DEFS_SET, tmp_ptr) ;
   }
   tmp_ptr->info = li ;
}

void remove_down_exposed_defs_info(Edge* edge) {
   edge->attributes->remove_attribute(DOWN_EXPOSED_DEFS_SET) ;
}

/////////////////////////////////////////////////////////////////////
// 
//    Generic_attribute_map for edges
//
/////////////////////////////////////////////////////////////////////

Generic_attribute_map* get_generic_attribute_map(Edge* e)
{
   Generic_attribute_map_attrib* tmp_ptr ;

   tmp_ptr = (Generic_attribute_map_attrib*)
      (e->attributes->get_attribute(GENERIC_ATTRIBUTES));
   if (tmp_ptr == 0) {
      tmp_ptr = new Generic_attribute_map_attrib() ;
      tmp_ptr->map = new Generic_attribute_map() ;
      e->attributes->insert_attribute(GENERIC_ATTRIBUTES,tmp_ptr) ;
   }
   return (tmp_ptr->map) ;
}

void set_generic_attribute_map(Edge* e, Generic_attribute_map* lat)
{
   Generic_attribute_map_attrib* tmp_ptr = (Generic_attribute_map_attrib*)
      e->attributes->get_attribute(GENERIC_ATTRIBUTES);
   if (tmp_ptr == 0) {
      tmp_ptr = new Generic_attribute_map_attrib() ;
      tmp_ptr->map = 0 ;
   }
   delete tmp_ptr->map ;
   tmp_ptr->map = lat ;
}

void remove_generic_attribute_map(Edge* e)
{
   e->attributes->remove_attribute(GENERIC_ATTRIBUTES) ;
}


void* get_generic_attribute(Edge* e, const eString& str)
{
   Generic_attribute_map* gmap = get_generic_attribute_map(e) ;
   if (gmap->is_bound(str)) {
      return (gmap->value(str)) ;
   } else {
      return 0 ;
   }
}

void set_generic_attribute(Edge* e, const eString& str, void* gnrc_ptr)
{
   Generic_attribute_map* gmap = get_generic_attribute_map(e) ;
   gmap->bind(str,gnrc_ptr) ;
}

void remove_generic_attribute(Edge* e, const eString& str)
{
   Generic_attribute_map* gmap = get_generic_attribute_map(e) ;
   gmap->unbind(str) ;
   if (gmap->is_empty()) {
      remove_generic_attribute_map(e) ;
   }
}


///////////////////////////////////////////////////////////////////
//
//  Region attributes
//
/////////////////////////////////////////////////////////////////////

Control_cpr_info* get_control_cpr_info(Region *r)
{
  Control_cpr_info* tmp_ptr ;

  tmp_ptr = (Control_cpr_info*) (r->attributes->get_attribute(CONTROL_CPR_INFO));
  return (tmp_ptr) ;
}

void set_control_cpr_info(Region* r, Control_cpr_info* attr)
{
  r->attributes->insert_attribute(CONTROL_CPR_INFO, attr) ;
}

void remove_control_cpr_info(Region* r)
{
   r->attributes->remove_attribute(CONTROL_CPR_INFO) ;
}


/////////////////////////////////////////////////////////////////////
// 
//    Generic_attribute_map for regions
//
/////////////////////////////////////////////////////////////////////

Generic_attribute_map* get_generic_attribute_map(Region* r)
{
   Generic_attribute_map_attrib* tmp_ptr ;

   tmp_ptr = (Generic_attribute_map_attrib*)
      (r->attributes->get_attribute(GENERIC_ATTRIBUTES));
   if (tmp_ptr == 0) {
      tmp_ptr = new Generic_attribute_map_attrib ;
      tmp_ptr->map = new Generic_attribute_map ;      
      r->attributes->insert_attribute(GENERIC_ATTRIBUTES,tmp_ptr) ;
   }
   return (tmp_ptr->map) ;
   
}

void set_generic_attribute_map(Region* r, Generic_attribute_map* lat)
{
   Generic_attribute_map_attrib* tmp_ptr = (Generic_attribute_map_attrib*)
      r->attributes->get_attribute(GENERIC_ATTRIBUTES);
   if (tmp_ptr->map) delete tmp_ptr->map ;
}

void remove_generic_attribute_map(Region* r)
{
   r->attributes->remove_attribute(GENERIC_ATTRIBUTES) ;
}


void* get_generic_attribute(Region* r, const eString& str)
{
   Generic_attribute_map* gmap = get_generic_attribute_map(r) ;
   if (gmap->is_bound(str)) {
      return (gmap->value(str)) ;
   } else {
      return 0 ;
   }
}

void set_generic_attribute(Region* r, const eString& str, void* gnrc_ptr)
{
   Generic_attribute_map* gmap = get_generic_attribute_map(r) ;
   gmap->bind(str,gnrc_ptr) ;
}

void remove_generic_attribute(Region* r, const eString& str)
{
   Generic_attribute_map* gmap = get_generic_attribute_map(r) ;
   gmap->unbind(str) ;
   if (gmap->is_empty()) {
      remove_generic_attribute_map(r) ;
   }
}




/////////////////////////////////////////////////////////////////////
// 
//    Lcode_attribute_map 
//
/////////////////////////////////////////////////////////////////////

Lcode_attribute_map* get_lcode_attributes(Region* r)
{
   Lcode_attribute_map_attrib* tmp_ptr ;

   tmp_ptr = (Lcode_attribute_map_attrib*)
      (r->attributes->get_attribute(LCODE_ATTRIBUTES));
   if (tmp_ptr == 0) {
      tmp_ptr = new Lcode_attribute_map_attrib;
      tmp_ptr->map = new Lcode_attribute_map;      
      r->attributes->insert_attribute(LCODE_ATTRIBUTES,tmp_ptr) ;
   }
   return (tmp_ptr->map) ;
   
}

void set_lcode_attributes(Region* r, Lcode_attribute_map* lat)
{
   Lcode_attribute_map_attrib* tmp_ptr = (Lcode_attribute_map_attrib*)
      r->attributes->get_attribute(LCODE_ATTRIBUTES);
   if (tmp_ptr == 0) {
      tmp_ptr = new Lcode_attribute_map_attrib;
      tmp_ptr->map = 0 ;
   }
   delete tmp_ptr->map ;
   tmp_ptr->map = lat ;
   r->attributes->insert_attribute(LCODE_ATTRIBUTES, tmp_ptr) ;
}

void remove_lcode_attributes(Region* r)
{
   r->attributes->remove_attribute(LCODE_ATTRIBUTES) ;
}


/////////////////////////////////////////////////////////////////////
// 
//    MemDepProf_attribute_map 
//
/////////////////////////////////////////////////////////////////////

MemDepProf_attribute_map* get_mdp_attributes(Region* r)
{
   MemDepProf_attribute_map_attrib* tmp_ptr ;

   tmp_ptr = (MemDepProf_attribute_map_attrib*)
      (r->attributes->get_attribute(MEM_DEP_PROF_ATTRIBUTES));
   if (tmp_ptr == 0) {
      tmp_ptr = new MemDepProf_attribute_map_attrib;
      tmp_ptr->map = new MemDepProf_attribute_map;      
      r->attributes->insert_attribute(MEM_DEP_PROF_ATTRIBUTES,tmp_ptr) ;
   }
   return (tmp_ptr->map) ;
   
}

void set_mdp_attributes(Region* r, MemDepProf_attribute_map* lat)
{
   MemDepProf_attribute_map_attrib* tmp_ptr = (MemDepProf_attribute_map_attrib*)
      r->attributes->get_attribute(MEM_DEP_PROF_ATTRIBUTES);
   if (tmp_ptr == 0) {
      tmp_ptr = new MemDepProf_attribute_map_attrib;
      tmp_ptr->map = 0 ;
   }
   delete tmp_ptr->map ;
   tmp_ptr->map = lat ;
   r->attributes->insert_attribute(MEM_DEP_PROF_ATTRIBUTES, tmp_ptr) ;
}

void remove_mdp_attributes(Region* r)
{
   r->attributes->remove_attribute(MEM_DEP_PROF_ATTRIBUTES) ;
}

