/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           LiveRange.h
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#ifndef LiveRange_H
#define LiveRange_H

#include <list_set.h>
#include <pred_interface.h>
#include <ref.h>
#include <bit_vector.h>

#include  "RegisterBank.h"

class GlobalBoundMap;
class LiveSubRegion;
class LiveBlock;
class LiveUnit;
class RegAllocSolver;

class LiveRange {

public:
    enum CallerCalleeType {
	CALLER_SAVED,
	CALLEE_SAVED
    };

    enum RegBindState {
        UNDEFINED,
        CALLER_BOUND,
	CALLEE_BOUND,
        SPILLED,
        DELAYED
    };

private:
    LiveRange();

public:
    LiveRange(const Operand&);

    const List<El_ref>&	live_refs()const;
    List<Edge*>&	entry_edges()const;
    List<Edge*>&	exit_edges()const;
    const Operand&	variable()const;
    int			mc_num()const {return _var.mc_num();}
    RegBindState	reg_bind_state()const 	{return _reg_bind_state;}
    double		caller_benefit()const;
    double		callee_benefit()const;
    double		priority()const;

    bool		has_single_ref()const;
    bool		has_single_block()const;
    bool		is_pass_through()const;
    bool		is_constrained()const;

    bool 		init_interference_recursively(LiveRange* a_lr);
    //void		add_interference(LiveRange* a_lr);
    const List<LiveRange*>& inf_lrs()const { return _inf_lrs;}

    void		set_live_unit(LiveUnit* lu);
    void		add_adj_lrs(const GlobalBoundMap& b_map);
    void		add_adj_lr(Edge* e, LiveRange* lr);
    void		delete_adj_lr(LiveRange* a_lr);

public:
    void		bind_register(int reg_num, CallerCalleeType reg_save_type);
    void		get_patch_cost_table(const GlobalBoundMap& b_map);

private:
    void		upscale_forbidden();


public:
    RegBindState	coloring();
    void		coloring_pass_through();
private:
    void		force_coloring();
public:
    void		delaying();
    void		spilling();
    Pair<LiveRange*, LiveRange*> split();
    void		reconcile();
private:
    void		propagate_in(Edge* e, LiveRange* pref_lr);
    void		propagate_out(LiveRange* lr);
    void		allocate_new_register();
    int			select_register(CallerCalleeType _call_type);
    int			select_register_intra();
    void		color_by_patch_cost();

private:
    Operand		_var;
    LiveUnit*		_live_region;

    RegBindState        _reg_bind_state;
    RegisterBank	_reg_bank;

    // the following information is available in ONLY top level LiveRange
    List<LiveRange*> 	_adj_lrs;
    Map<Edge*, LiveRange*> _adj_lr_map;
    List<Edge*> 	_sorted_adj_edges;
    List<Edge*> 	_reconciled_edges;

private: // data members defined recursively
    List<LiveRange*>	_inf_lrs;
    List_set<int>	_forbidden_regs;
    Bitvector		_forbidden_bv;
    double		_priority;

private:
    double 		_patch_sum;
    Map<int,double>	_patch_cost_map;
    Bitvector		_prefer_regs;

public:
    static int		STORE_LATENCY;
    static int		LOAD_LATENCY;
    static int		MOVE_LATENCY;

};



#endif
