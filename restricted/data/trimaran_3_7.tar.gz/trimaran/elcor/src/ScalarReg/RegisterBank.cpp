/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           RegisterBank.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include <math.h>

#include "RegisterBank.h"

#include <el_sreg_driver.h>
#include "intf.h"
#include "regtochar.h"


int RegisterBank::SPILL_RESERVED = 2;
int RegisterBank::_count = 0;

RegisterBank::RegisterBank() : _macro_bv(512), _caller_bv(512), _callee_bv(512)
{

}

RegisterBank::RegisterBank(Reg_file file_type, const char* file_name_) 
  : _macro_bv(512), _caller_bv(512), _callee_bv(512)
{
    init(file_type, file_name_);
}

void
RegisterBank::init(Reg_file file_type, const char* file_name_) {
    _file_type = file_type;
    _file_name = file_name_;
    // _reg_index = MDES_reg_index(_file_name);
    _index = _count;
    _count++;

    _bit_width = MDES_reg_width((char*)_file_name);
    _size = MDES_reg_static_size((char*)_file_name);
    _reg_use_count.resize(_size);
    _stack_size = _size*_bit_width / 8;
    _macro_size = macro_register_size(file_type);

    if (MDES_reg_index((char*)_file_name) == PR) {
	_callee_size = _size - _macro_size;
	_caller_size = 0;
    }
    else {
	_caller_size = (_size - _macro_size) / 2;
	_callee_size = _size - _macro_size - _caller_size;
    }

    for (int i0 = 0; i0 < _macro_size; i0++) {
	_macro_set += i0;
	_macro_bv.set_bit(i0);
    }

    for (int i1 = _macro_size; i1 < _macro_size + _caller_size; i1++) {
	_caller_set += i1;
	_caller_bv.set_bit(i1);
    }

    for (unsigned int i2 = _size - _callee_size; i2 < _size; i2++) {
	_callee_set += i2;
	_callee_bv.set_bit(i2);
    }

}


void
RegisterBank::clear_reg_use_count() {
    
    for (int i = 0; i < _reg_use_count.dim(); i++) {
	_reg_use_count[i] = 0;
    }

}



//
// select temporary register for spilling
// returns value is decided by the port number of that variable
int
RegisterBank::spill_reg(int port_num) {
    int reg_num = (int)fmod(port_num, RegisterBank::SPILL_RESERVED);
    return reg_num;
}


bool 
RegisterBank::operator==(const RegisterBank& rb2) const {
    if (strcmp(_file_name, rb2._file_name) == 0)
	return true;
    else
	return false;
}


int
RegisterBank::index(const char* _file_name) {
    return MDES_reg_index((char*)_file_name);
}


int 
RegisterBank::macro_register_size(Reg_file rfile)
{
    int size = 0;

    switch (rfile) {
	case GPR:
	    size =(11);
	case FPR:
	    size =  (7);
	case PR:
	    size = (2);
	case BTR:
	    size = (1);
	case CR:
	    size =  (0);
	default:
	    size = (0);
    }

    return size + SPILL_RESERVED;
    // reserve one more register for spilling 
}


Reg_file
RegisterBank::file_type(const char* file_name) {
    Reg_file type = NUM_REG_FILE;
    if ( strcmp(file_name, regfile_to_char(GPR)) == 0 )
	type = GPR;
    else if ( strcmp(file_name, regfile_to_char(FPR)) == 0 )
	type = FPR;
    else if ( strcmp(file_name, regfile_to_char(PR)) == 0 )
	type = PR;
    else if ( strcmp(file_name, regfile_to_char(BTR)) == 0 )
	type = BTR;
    else if ( strcmp(file_name, regfile_to_char(CR)) == 0 )
	type = CR;

    return type;
}


// returns alias Control Register for given Predicate Register
int
RegisterBank::alias_CR( int pred_reg_num ) {
    int i = -1;
    while (pred_reg_num >= 0) {
	pred_reg_num -= 32;
	// 32 is the width of CR
	// needs mdes API to find register width given register file type
	// Is register file type physical or logical???
	i++;
    };
    return i;
}


// returns macro register PV number for give CR number
Macro_name
RegisterBank::PV_num(int CR_num) {
    switch (CR_num) {
    case 0:
	return PV_0;
	break;
    case 1:
	return PV_1;
	break;
    case 2:
	return PV_2;
	break;
    case 3:
	return PV_3;
	break;
    case 4:
	return PV_4;
	break;
    case 5:
	return PV_5;
	break;
    case 6:
	return PV_6;
	break;
    case 7:
	return PV_7;
	break;
    }
    return UNDEFINED;
}

/*
RegisterBank*
RegisterBank::reg_bank(Reg_file file_type) {
    char* file_name = regfile_to_char(file_type);
    RegisterBank* reg_bank = NULL;
    for (int i = 0; i < _reg_bank_pool.dim(); i++) {
	if (_reg_bank_pool[i]._file_name == file_name) {
	    reg_bank = &(_reg_bank_pool[i]);
	    break;
	}
    }
    assert(reg_bank != NULL);
    return reg_bank;
}


void
init_reg_bank() {

    if (RegisterBank::_init_reg_bank == false) {

	RegisterBank::_init_reg_bank = true;
	
	// Elcor has only one physical file for each Reg_file type
	// Scan each Reg_file one by one and initialize register files for each
	// physical file.
	// H. Kim  -- 4/10/98

	for (int i = FIRST_FILE; i < NUM_REG_FILE; ++i) {
	    RegisterBank::_reg_bank_pool.resize(NUM_REG_FILE);
	    char* file_name = regfile_to_char((Reg_file)i);
	    RegisterBank::_reg_bank_pool[i].init((Reg_file)i, file_name);
	    RegisterBank::_reg_bank_pool[i]._file_type = (Reg_file)i;
	    int size_bit = RegisterBank::_reg_bank_pool[i].bit_width()*RegisterBank::_reg_bank_pool[i]._size;
	    RegisterBank::_reg_bank_pool[i]._stack_size = size_bit / 8;
	}
    }
    else {
	for (int i = FIRST_FILE; i < NUM_REG_FILE; i++) {
	    RegisterBank::_reg_bank_pool[i].clear_reg_use_count();
	}
    }
}
*/

/*****************************************************************************
 * static variables
 *****************************************************************************/
RegisterBankPool* RegisterBankPool::a_instance = NULL;

RegisterBankPool::RegisterBankPool() {

    // Elcor has only one physical file for each Reg_file type
    // Scan each Reg_file one by one and initialize register files for each
    // physical file.
    // H. Kim  -- 4/10/98

    resize(NUM_REG_FILE);
    for (int i = FIRST_FILE; i < NUM_REG_FILE; ++i) {
	RegisterBank& a_bank = (*this)[i];
	char* file_name = regfile_to_char((Reg_file)i);
	a_bank.init((Reg_file)i, file_name);
	int size_bit = a_bank.bit_width()*a_bank._size;
	a_bank._stack_size = size_bit / 8;
    }
}

RegisterBank&
RegisterBankPool::bank(Reg_file file_type) {

#if 1
    return operator[] ((int)file_type);
#else
    char* file_name = regfile_to_char(file_type);
    for (int i = 0; i < _reg_bank_pool.dim(); i++) {
	if ((*this)[i]._file_name == file_name) {
	    reg_bank = (*this).[i];
	    break;
	}
    }
    return reg_bank;
#endif
}


RegisterBank&
RegisterBankPool::reg_bank(Reg_file file_type) {
    return a_instance->operator[] ((int)file_type);
}


RegisterBankPool&
RegisterBankPool::instance() {
    if (RegisterBankPool::a_instance == NULL)
	RegisterBankPool::a_instance = new RegisterBankPool();
    return *RegisterBankPool::a_instance;
}


void
RegisterBankPool::clear_reg_use_count() {
    for (int i = FIRST_FILE; i < NUM_REG_FILE; i++) {
	bank( (Reg_file)i ).clear_reg_use_count();
    }
}
