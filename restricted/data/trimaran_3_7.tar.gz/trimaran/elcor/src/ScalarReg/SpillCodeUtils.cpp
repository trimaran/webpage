/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           SpillCodeUtils.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include "ScalarRegAlloc.h"
#include "SpillCodeUtils.h"
#include "RegisterBank.h"
#include <attributes.h>
#include <connect.h>
#include <edge.h>
#include <edge_utilities.h>
#include <el_control.h>
#include <iterators.h>
#include <op.h>
#include <operand.h>
#include <opcode_load_store.h>
#include <region.h>
#include <reaching_defs_solver.h>

// copied from Control/el_control.h and modified with Macro register
// Hansoo Kim
void 
SpillCodeUtils::add_jump_to_region(Compound_region* region, Op* dest_op)
{
  Edge *edge;
  Op* pbr_op;
  Op* bru_op;
  Base_operand* base_oper;
  Operand* temp_oper;
  Op* last_op;
  Control_flow_freq *cfreq;
  
  for (Region_exit_edges exit_iter(region); exit_iter!=0; exit_iter++)
    {
      El_punt("Add_Jump_To_Region: Region already has an edge.");
    }

  last_op = get_last_region_op_from_subregions(region);
  
  // regist = new Reg(EL_DT_BRANCH, BTR, virtual_register_number);
  Operand addr_operand(new Macro_reg(RETURN_ADDR));
  Operand pred_operand(new Pred_lit(true));

  /* WWF { added compile time flag to support PBR */
#ifdef SUPPORT_PBR
  pbr_op = new Op(PBRR);
  region->add_region(pbr_op);
  pbr_op->set_parent(region);

  pbr_op->set_dest(DEST1, addr_operand);

  base_oper = new Cb_operand(dest_op->parent()->id());
  temp_oper = new Operand(base_oper);
  pbr_op->set_src(SRC1, *temp_oper);

  base_oper = new Int_lit(1);
  temp_oper = new Operand(base_oper);
  pbr_op->set_src(SRC2, *temp_oper);

  pbr_op->set_src(PRED1, pred_operand);
#else
  base_oper = new Cb_operand(dest_op->parent()->id());
  temp_oper = new Operand(base_oper);
#endif /* SUPPORT_PBR */
  /* } WWF */
  
  bru_op = new Op(BRU);
  region->add_region(bru_op);
  bru_op->set_parent(region);
  region->add_exit(bru_op);
  
  /* WWF { added compile time flag to support PBR */
#ifdef SUPPORT_PBR  
  bru_op->set_src(SRC1, addr_operand);
#else
  bru_op->set_src(SRC1, *temp_oper);
#endif /* SUPPORT_PBR */
  bru_op->set_src(PRED1, pred_operand);
  
#ifdef SUPPORT_PBR  
  C0_connect_fallthrough(last_op, pbr_op);
  C0_connect_fallthrough(pbr_op, bru_op);
#else
  C0_connect_fallthrough(last_op, bru_op);
#endif /* SUPPORT_PBR */
  /* } WWF */
  edge = C0_connect(bru_op, dest_op);
  cfreq = new Control_flow_freq();
  cfreq->freq = region->weight;
  set_control_flow_freq(edge, cfreq);
  
  bru_op->add_outedge_recursively_restricted(edge);
  dest_op->add_inedge_recursively_restricted(edge);
      
}


/*
 * connect_region_fallthrough()
 * 
 * Copied from El_connect_region_fallthrough() and modified not to remove 
 * existing in_edges
 *
 */
void connect_region_fallthrough(Compound_region* prev_reg, 
				Compound_region* next_reg,
				double freq)
{
  Op* last_op = get_last_region_op_from_subregions(prev_reg);
  
  Op* first_op = get_first_region_op_from_subregions(next_reg);
  
  for(Region_all_outedges exit_iter(prev_reg); exit_iter != 0; exit_iter++)
    {
      Edge* cur_edge = *exit_iter;
      if(cur_edge->src_alt() == 0)
	{
	      Edge* bad_edge = cur_edge;
	      last_op->remove_outedge_recursively(bad_edge);
	}
    }
 
  for(Region_all_inedges in_iter(next_reg); in_iter != 0; in_iter++) {
      Edge* cur_edge = *in_iter;
      if(cur_edge->dest_alt() == 0) {
	  Edge* bad_edge = cur_edge;
	  first_op->remove_inedge_recursively(bad_edge);
      }
  }
 

  Edge* edge = C0_connect_fallthrough(last_op, first_op) ;
  last_op->add_outedge_recursively_restricted(edge);
  first_op->add_inedge_recursively_restricted(edge);
  Control_flow_freq *cfreq = new Control_flow_freq();
  cfreq->freq = freq;
  set_control_flow_freq(edge, cfreq);
}


/*****************************************************************************
 *   This routine create a new Basicblock and insert it to given edge.
 *  Consider given edge E with operation op1 and op2 when op1 is branch operation
 *  in region R1 and op2 is the control merge operation in region R2
 *
 *	   R1                        R2
 *	----------------          -----------------
 *	|		|    E    |                |
 *	|          op1------------->op2            |
 *	|               |         |                |
 *	----------------          -----------------
 *		
 *
 *  Then, createBasicblock() will create new R3 and will be inserted between region
 *  R1 and R2. The edge E will be removed if bypass flag is true.
 *
 *   		R1                               R2
 *	----------------                        -----------------
 *	|		|           E           |                |
 *	|          op1-----...................--->op2            |
 *	|               | |                   ^ |                |
 *	----------------  |                   | -----------------
 *                        |                   |
 *                        |                   |
 *			  |    ------------   |
 *			  |    |	   |  |
 *			   --> |	   |--
 *			       |	   |
 *			       ------------
 *			        Basicblock
 *
 *
 *  H.Kim  Aug.18, 1997
 *
 ****************************************************************************/

Basicblock*
SpillCodeUtils::createBasicblock(Edge* e, bool bypass) {

    Op* dest_op = e->dest();	// entry operation of DEST region
    Op* src_op = e->src();	// exit operation of SRC region

    Compound_region* src_region = src_op->parent();	// SRC region of edge
    Compound_region* dest_region = dest_op->parent();	// DEST region of edge

    Compound_region* parent = dest_op->parent()->parent();

    Basicblock* new_Basicblock = new Basicblock;
    new_Basicblock->set_parent(parent);

    Control_flow_freq* cf_freq = get_control_flow_freq(e);
    double freq = cf_freq->freq;
    new_Basicblock->weight = freq;

    if (is_fall_through(e)) {
	// this is fall through edge
	Op* merge_op = new Op(C_MERGE) ;
	new_Basicblock->add_region(merge_op) ;
	merge_op->set_parent(new_Basicblock) ;
	new_Basicblock->add_entry(merge_op);
	parent->insert_before_region(new_Basicblock, dest_region);	
	
	Op* branch_op = new Op(DUMMY_BR);
	new_Basicblock->add_region(branch_op);
	branch_op->set_parent(new_Basicblock);
	new_Basicblock->add_exit(branch_op);
	C0_connect_fallthrough(merge_op, branch_op);
	
	connect_region_fallthrough(src_region, new_Basicblock, freq);
	connect_region_fallthrough(new_Basicblock, dest_region, freq);

    }
    else {
	// this edge is control jump
	Op* merge_op = new Op(C_MERGE) ;
	new_Basicblock->add_region(merge_op) ;
	merge_op->set_parent(new_Basicblock) ;
	new_Basicblock->add_entry(merge_op);
	parent->add_region(new_Basicblock);

	e->set_dest(merge_op, e->dest_port(), e->dest_alt());
	merge_op->add_inedge_recursively_restricted(e);
	/*
	Edge* inedgeToBasicblock = C0_connect(src_op, merge_op);
	src_op->remove_outedge_recursively(e);
	src_op->add_outedge_recursively(inedgeToBasicblock);
	*/

	dest_op->remove_inedge_recursively(e);
	SpillCodeUtils::add_jump_to_region(new_Basicblock, dest_op);

	Reaching_defs_info *rdi;
	rdi = get_reaching_defs_info(parent);
	Op* pbr_op = El_new_find_pbr_for_branch(src_op, rdi);
	pbr_op->src(SRC1).set_id(new_Basicblock->id());

	
	
	/*
	Edge* in_edge = C0_connect(src_op, merge_op);
	src_op->add_outedge_recursively(in_edge);
	merge_op->add_inedge_recursively(in_edge);
	
	// find all PBR operation, and update target address to new_Basicblock
	for (Op_inedges iter(src_op); iter != 0; iter++) {
	    // for all incoming edges
	    Edge* ied = *iter;
	    if (ied->if_reg_flow()) {
		// This is register data dependancy

		// if src operation is PBR, update target address to new Basicblock
		if ( is_pbr(ied->src()) ) {
		    Operand src1_operand(new Cb_operand(newBasicblock->id()));
		    ied->src()->set_src(SRC1, src1_operand);
		    Operand src2_operand(new Cb_operand(newBasicblock->id()));
		    ied->src()->set_src(SRC2, src2_operand);
		}
	    }
	}
	*/
	
    }

    if (bypass == true) {
    /*
	in_edge->attributes = e->attributes;
	out_edge->attributes = e->attributes;

	// remove original edge between region;
	src_op->remove_outedge_recursively(e);
	dest_op->remove_inedge_recursively(e);
    */
    }

    return new_Basicblock;
}



Op*
SpillCodeUtils::store_before(Operand& src_var, 
			     Operand& pred_var,
			     Op* point) {

    // var should be bound
    // If not, I do not know which register to be spilled
    assert(src_var.allocated() == true);

    int stack_loc = ScalarRegAlloc::_spill_stack.addr(src_var);

    Operand addr_operand (new Macro_reg (SPILL_TEMPREG));
    Operand sp_operand (new Macro_reg (SP_REG));
    Operand loc_operand (new Int_lit (stack_loc));

    Operand temp_var(new Reg(EL_DT_INT));
    int spill_reg = RegisterBankPool::reg_bank(temp_var.file_type()).spill_reg();
    temp_var.bind_reg(spill_reg);

    Op* addr_op = new Op ((Opcode) ADD_W);
    addr_op->set_src (SRC1, sp_operand);
    addr_op->set_src (SRC2, loc_operand);
    addr_op->set_src (PRED1, pred_var);
    addr_op->set_dest (DEST1, addr_operand);
    addr_op->set_flag (EL_OPER_SPILL_CODE);

    // instruction: STORE SPILL_TEMPREG, variable_operand
    Op* store_op = NULL;
    Op* movepg_op = NULL;

    switch (src_var.file_type()) {
    case GPR:
    case BTR:
    case CR:
	store_op = new Op ((Opcode)S_W_C1);
	store_op->set_src (SRC1, addr_operand);
	store_op->set_src (SRC2, src_var);
	store_op->set_src (PRED1, pred_var);
	store_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case FPR:
	store_op = new Op ((Opcode)FS_D_C1);
	store_op->set_src (SRC1, addr_operand);
	store_op->set_src (SRC2, src_var);
	store_op->set_src (PRED1, pred_var);
	store_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case PR:
	movepg_op = new Op((Opcode)MOVEPG);
	movepg_op->set_dest(DEST1, temp_var);
	movepg_op->set_src (SRC1, src_var);
	movepg_op->set_src (PRED1, pred_var);
	movepg_op->set_flag (EL_OPER_SPILL_CODE);

	store_op = new Op ((Opcode)SAVE);
	store_op->set_src (SRC1, addr_operand);
	store_op->set_src (SRC2, temp_var);
	store_op->set_src (PRED1, pred_var);
	store_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    default:
	assert (0);
    }

    if (movepg_op != NULL) {
	El_insert_op_before(point->parent(), store_op, point);
	El_insert_op_before(point->parent(), movepg_op, store_op);
	El_insert_op_before(point->parent(), addr_op, movepg_op);
    }
    else {
	El_insert_op_before(point->parent(), store_op, point);
	El_insert_op_before(point->parent(), addr_op, store_op);
    }
    return addr_op;
}


Op*
SpillCodeUtils::store_after(Operand& src_var, 
			    Operand& pred_var,
			    Op* point) {

    // var should be bound
    // If not, I do not know which register to be spilled
    assert(src_var.allocated() == true);

    int stack_loc = ScalarRegAlloc::_spill_stack.addr(src_var);

    Operand addr_operand (new Macro_reg (SPILL_TEMPREG));
    Operand sp_operand (new Macro_reg (SP_REG));
    Operand loc_operand (new Int_lit (stack_loc));

    Operand temp_var(new Reg(EL_DT_INT));
    int spill_reg = RegisterBankPool::reg_bank(temp_var.file_type()).spill_reg();
    temp_var.bind_reg(spill_reg);

    Op* addr_op = new Op ((Opcode) ADD_W);
    addr_op->set_src (SRC1, sp_operand);
    addr_op->set_src (SRC2, loc_operand);
    addr_op->set_src (PRED1, pred_var);
    addr_op->set_dest (DEST1, addr_operand);
    addr_op->set_flag (EL_OPER_SPILL_CODE);

    // instruction: STORE SPILL_TEMPREG, variable_operand
    Op* store_op = NULL;
    Op* movepg_op = NULL;

    switch (src_var.file_type()) {
    case GPR:
    case BTR:
    case CR:
	store_op = new Op ((Opcode)S_W_C1);
	store_op->set_src (SRC1, addr_operand);
	store_op->set_src (SRC2, src_var);
	store_op->set_src (PRED1, pred_var);
	store_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case FPR:
	store_op = new Op ((Opcode)FS_D_C1);
	store_op->set_src (SRC1, addr_operand);
	store_op->set_src (SRC2, src_var);
	store_op->set_src (PRED1, pred_var);
	store_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case PR:
	movepg_op = new Op((Opcode)MOVEPG);
	movepg_op->set_dest(DEST1, temp_var);
	movepg_op->set_src (SRC1, src_var);
	movepg_op->set_src (PRED1, pred_var);
	movepg_op->set_flag (EL_OPER_SPILL_CODE);

	store_op = new Op ((Opcode)SAVE);
	store_op->set_src (SRC1, addr_operand);
	store_op->set_src (SRC2, temp_var);
	store_op->set_src (PRED1, pred_var);
	store_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    default:
	assert (0);
    }

    if (movepg_op != NULL) {
	El_insert_op_after(point->parent(), addr_op, point);
	El_insert_op_after(point->parent(), movepg_op, addr_op);
	El_insert_op_after(point->parent(), store_op, movepg_op);
    }
    else {
	El_insert_op_after(point->parent(), addr_op, point);
	El_insert_op_after(point->parent(), store_op, addr_op);
    }
    return store_op;
}


Op*
SpillCodeUtils::load_before(Operand& dest_var, 
			    Operand& pred_var,
			    Op* point) {

    // var should be bound
    // If not, I do not know which register to be loaded
    assert(dest_var.allocated() == true);

    int stack_loc = ScalarRegAlloc::_spill_stack.addr(dest_var);

    Operand addr_operand (new Macro_reg (SPILL_TEMPREG));
    Operand sp_operand (new Macro_reg (SP_REG));
    Operand loc_operand (new Int_lit (stack_loc));

    Operand temp_var(new Reg(EL_DT_INT));
    int spill_reg = RegisterBankPool::reg_bank(temp_var.file_type()).spill_reg();
    temp_var.bind_reg(spill_reg);

    Operand lit0(new Int_lit(0));

    Op* addr_op = new Op ((Opcode) ADD_W);
    addr_op->set_src (SRC1, sp_operand);
    addr_op->set_src (SRC2, loc_operand);
    addr_op->set_src (PRED1, pred_var);
    addr_op->set_dest (DEST1, addr_operand);
    addr_op->set_flag (EL_OPER_SPILL_CODE);

    // instruction: STORE SPILL_TEMPREG, variable_operand
    Op* load_op = NULL;
    Op* movegbp_op = NULL;

    switch (dest_var.file_type()) {
    case GPR:
    case BTR:
    case CR:
	load_op = new Op( (Opcode) L_W_C1_C1);
	load_op->set_dest (DEST1, dest_var);
	load_op->set_src (SRC1, addr_operand);
	load_op->set_src (PRED1, pred_var);
	load_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case FPR:
	load_op = new Op( (Opcode) FL_D_C1_C1);
	load_op->set_dest (DEST1, dest_var);
	load_op->set_src (SRC1, addr_operand);
	load_op->set_src (PRED1, pred_var);
	load_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case PR:
	load_op = new Op ((Opcode)RESTORE);
	load_op->set_dest (DEST1, temp_var);
	load_op->set_src (SRC1, addr_operand);
	load_op->set_src (PRED1, pred_var);
	load_op->set_flag (EL_OPER_SPILL_CODE);

	movegbp_op = new Op((Opcode)MOVEGBP);
	movegbp_op->set_dest(DEST1, dest_var);
	movegbp_op->set_src (SRC1, temp_var);
	movegbp_op->set_src (SRC2, lit0);
	movegbp_op->set_src (PRED1, pred_var);
	movegbp_op->set_flag (EL_OPER_SPILL_CODE);

	break;
    default:
	assert (0);
    }

    if (movegbp_op != NULL) {
	El_insert_op_before(point->parent(), movegbp_op, point);
	El_insert_op_before(point->parent(), load_op, movegbp_op);
	El_insert_op_before(point->parent(), addr_op, load_op);
    }
    else {
	El_insert_op_before(point->parent(), load_op, point);
	El_insert_op_before(point->parent(), addr_op, load_op);
    }
    return addr_op;
}


Op*
SpillCodeUtils::load_after(Operand& dest_var, 
			    Operand& pred_var,
			    Op* point) {

    // var should be bound
    // If not, I do not know which register to be loaded
    assert(dest_var.allocated() == true);

    int stack_loc = ScalarRegAlloc::_spill_stack.addr(dest_var);

    Operand addr_operand (new Macro_reg (SPILL_TEMPREG));
    Operand sp_operand (new Macro_reg (SP_REG));
    Operand loc_operand (new Int_lit (stack_loc));

    Operand temp_var(new Reg(EL_DT_INT));
    int spill_reg = RegisterBankPool::reg_bank(temp_var.file_type()).spill_reg();
    temp_var.bind_reg(spill_reg);

    Operand lit0(new Int_lit(0));

    Op* addr_op = new Op ((Opcode) ADD_W);
    addr_op->set_src (SRC1, sp_operand);
    addr_op->set_src (SRC2, loc_operand);
    addr_op->set_src (PRED1, pred_var);
    addr_op->set_dest (DEST1, addr_operand);
    addr_op->set_flag (EL_OPER_SPILL_CODE);

    // instruction: STORE SPILL_TEMPREG, variable_operand
    Op* load_op = NULL;
    Op* movegbp_op = NULL;

    switch (dest_var.file_type()) {
    case GPR:
    case BTR:
    case CR:
	load_op = new Op( (Opcode) L_W_C1_C1);
	load_op->set_dest (DEST1, dest_var);
	load_op->set_src (SRC1, addr_operand);
	load_op->set_src (PRED1, pred_var);
	load_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case FPR:
	load_op = new Op( (Opcode) FL_D_C1_C1);
	load_op->set_dest (DEST1, dest_var);
	load_op->set_src (SRC1, addr_operand);
	load_op->set_src (PRED1, pred_var);
	load_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case PR:
	load_op = new Op ((Opcode)RESTORE);
	load_op->set_dest (DEST1, temp_var);
	load_op->set_src (SRC1, addr_operand);
	load_op->set_src (PRED1, pred_var);
	load_op->set_flag (EL_OPER_SPILL_CODE);

	movegbp_op = new Op((Opcode)MOVEGBP);
	movegbp_op->set_dest(DEST1, dest_var);
	movegbp_op->set_src (SRC1, temp_var);
	movegbp_op->set_src (SRC2, lit0);
	movegbp_op->set_src (PRED1, pred_var);
	movegbp_op->set_flag (EL_OPER_SPILL_CODE);

	break;
    default:
	assert (0);
    }

    if (movegbp_op != NULL) {
	El_insert_op_after(point->parent(), addr_op, point);
	El_insert_op_after(point->parent(), load_op, addr_op);
	El_insert_op_after(point->parent(), movegbp_op, load_op);
	return movegbp_op;
    }
    else {
	El_insert_op_after(point->parent(), addr_op, point);
	El_insert_op_after(point->parent(), load_op, addr_op);
	return load_op;
    }
}


Op*
SpillCodeUtils::move_before(Operand& src_var, 
			    Operand& dest_var,
			    Operand& pred_var,
			    Op* point) {

    Op* move_op = NULL;

    switch (src_var.file_type()) {
    case GPR:
    case BTR:
    case CR:
	move_op = new Op( (Opcode) MOVE);
	move_op->set_dest (DEST1, dest_var);
	move_op->set_src (SRC1, src_var);
	move_op->set_src (PRED1, pred_var);
	move_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case FPR:
	move_op = new Op( (Opcode) MOVEF_D);
	move_op->set_dest (DEST1, dest_var);
	move_op->set_src (SRC1, src_var);
	move_op->set_src (PRED1, pred_var);
	move_op->set_flag (EL_OPER_SPILL_CODE);
	break;

    case PR:
	move_op = new Op( (Opcode) MOVEGBP);
	move_op->set_dest (DEST1, dest_var);
	move_op->set_src (SRC1, src_var);
	move_op->set_src (PRED1, pred_var);
	move_op->set_flag (EL_OPER_SPILL_CODE);
	break;

    default:
	assert (0);
    }

    El_insert_op_before(point->parent(), move_op, point);
    return move_op;
}


Op*
SpillCodeUtils::move_after(Operand& src_var, 
			   Operand& dest_var,
			   Operand& pred_var,
			   Op* point) {

    Op* move_op = NULL;

    switch (src_var.file_type()) {
    case GPR:
    case BTR:
    case CR:
	move_op = new Op( (Opcode) MOVE);
	move_op->set_dest (DEST1, dest_var);
	move_op->set_src (SRC1, src_var);
	move_op->set_src (PRED1, pred_var);
	move_op->set_flag (EL_OPER_SPILL_CODE);
	break;
    case FPR:
	move_op = new Op( (Opcode) MOVEF_D);
	move_op->set_dest (DEST1, dest_var);
	move_op->set_src (SRC1, src_var);
	move_op->set_src (PRED1, pred_var);
	move_op->set_flag (EL_OPER_SPILL_CODE);
	break;

    case PR:
	move_op = new Op( (Opcode) MOVEGBP);
	move_op->set_dest (DEST1, dest_var);
	move_op->set_src (SRC1, src_var);
	move_op->set_src (PRED1, pred_var);
	move_op->set_flag (EL_OPER_SPILL_CODE);
	break;

    default:
	assert (0);
    }

    El_insert_op_after(point->parent(), move_op, point);
    return move_op;
}

