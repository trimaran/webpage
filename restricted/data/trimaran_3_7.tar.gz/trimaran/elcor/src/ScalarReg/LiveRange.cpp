/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           LiveRange.cpp
//      Authors:        Hansoo Kim
//      Created:        August 1998
//      Description:    
//
/////////////////////////////////////////////////////////////////////////////

#include <attributes.h>
#include <el_sreg_init.h>
#include <flow_analysis_solver.h>
#include <intf.h>
#include <iterators.h>
#include <math.h>
#include <opcode_properties.h>
#include <dbg.h>

#include "Clockhand.h"
#include "GlobalBoundMap.h"
#include "LiveRange.h"
#include "LiveUnit.h"
#include "ReconcileCode.h"
#include "RegisterBank.h"
#include "SpillCodeUtils.h"


int LiveRange::STORE_LATENCY = 1;
int LiveRange::LOAD_LATENCY = 2;
int LiveRange::MOVE_LATENCY = 1;

LiveRange::LiveRange() : _forbidden_bv(512), _prefer_regs(512) {
    _reg_bind_state = UNDEFINED;
}


LiveRange::LiveRange(const Operand& var_) : _forbidden_bv(512), _prefer_regs(512) {
    _var = var_;
    _reg_bind_state = UNDEFINED;
    _reg_bank = RegisterBankPool::instance().bank(_var.file_type());
    _patch_sum = 0;
}

const Operand&
LiveRange::variable()const {
    return _var;
}

const List<El_ref>&
LiveRange::live_refs()const {
    return _live_region->live_refs();
}


List<Edge*>&
LiveRange::entry_edges()const {
    return _live_region->_entry_edges;
}


List<Edge*>&
LiveRange::exit_edges()const {
    return _live_region->_exit_edges;
}


double
LiveRange::priority()const {
    return _priority;
}


double
LiveRange::caller_benefit()const {
    return _live_region->_caller_benefit;
}


double
LiveRange::callee_benefit()const {
    return _live_region->_callee_benefit;
}


bool
LiveRange::has_single_ref()const {
    return _live_region->has_single_ref();
}


bool
LiveRange::has_single_block()const {
    return _live_region->has_single_block();
}


bool
LiveRange::is_constrained()const {
    if (_var.assigned_to_physical_file()) {
	// you can use physical register name
	// this is the way it supposed to be
	eString phy_file_name = _var.physical_file_type();
	unsigned int static_reg_size =  MDES_reg_static_size(phy_file_name);
	if (_inf_lrs.size() < static_reg_size)
	    return false;
	else
	    return true;
    }
    else {
	eString file_name = _var.physical_file_type();
	int reg_size = MDES_reg_static_size(file_name);
	if (_inf_lrs.size() < (unsigned int)reg_size)
	    return false;
	else
	    return true;
    }
}

bool
LiveRange::is_pass_through()const {
    if ( _live_region->live_refs().size() > 0 )
	return false;
    else
	return true;
}



bool 		
LiveRange::init_interference_recursively(LiveRange* a_lr) {
    bool flag =  _live_region->init_interference_recursively(a_lr->_live_region);
    if (flag) {
	_inf_lrs.add_tail(a_lr);
	a_lr->_inf_lrs.add_tail(this);
    }
    return flag;
}


void
LiveRange::set_live_unit(LiveUnit* a_lu) {
    _live_region = a_lu;
    if (EL_call_cost_priority == 0) {
	_priority = a_lu->_priority;
    }
    else if (EL_call_cost_priority == 1) {
	_priority = a_lu->_priority / (a_lu->live_ops_count() + 1);
    }
    else {
	_priority = a_lu->_priority / (_inf_lrs.size() + 1);
    }
}

void
LiveRange::add_adj_lrs(const GlobalBoundMap& b_map) {

    if (b_map.is_bound(variable().vr_num())==false)
	return;

    List<LiveRange*> global_lrs = b_map.value(variable().vr_num());
    for (List_iterator<LiveRange*> g_iter(global_lrs); g_iter!=0; g_iter++) {
	LiveRange* adj_lr = *g_iter;

	for (List_iterator<Edge*> e_iter(adj_lr->entry_edges()); e_iter!=0; e_iter++) {
	    Edge* inter_e = *e_iter;
	    for (List_iterator<Edge*> e_iter2(this->exit_edges()); e_iter2!=0; e_iter2++) {
		Edge* cand_e = *e_iter2;
		if (*inter_e == *cand_e) {
		    this->add_adj_lr(inter_e, adj_lr);
		    adj_lr->add_adj_lr(inter_e, this);
		    break;
		}
	    }
	}  // end of for of entry edges

	for (List_iterator<Edge*> e_iter2(adj_lr->exit_edges()); e_iter2!=0; e_iter2++) {
	    Edge* inter_e = *e_iter2;
	    for (List_iterator<Edge*> e_iter2(this->entry_edges()); e_iter2!=0; e_iter2++) {
		Edge* cand_e = *e_iter2;
		if (*inter_e == *cand_e) {
		    this->add_adj_lr(inter_e, adj_lr);
		    adj_lr->add_adj_lr(inter_e, this);
		    break;
		}
	    }
	} // end of loop: for each exit edges
	
    } // end of loop: for each global LR
}



// add Map<Edge*, LiveRange*> to _adj_lts list.
// LiveRange is kept seperately for ???
// Edge is kept seperately in sorted order by its weight.
void
LiveRange::add_adj_lr(Edge* e, LiveRange* lr) {

    double freq = 0;
    Control_flow_freq* cf_freq = get_control_flow_freq(e);
    if (EL_use_frequency == 0) {
	freq = 1;
    }
    else if (cf_freq) {
	freq = cf_freq->freq;
    }
    else {
	assert(e->src()->parent() == e->dest()->parent());
	freq = e->src()->parent()->weight;
    }

    List_iterator<Edge*> before_i;
    for (List_iterator<Edge*> iter(_sorted_adj_edges); iter!=0; iter++) {
	Edge* se = *iter;
	double adj_freq = 0;
	Control_flow_freq* se_freq = get_control_flow_freq(se);
	if (se_freq) {
	    adj_freq = se_freq->freq;
	}
	else {
	    assert(se->src()->parent() == se->dest()->parent());
	    adj_freq = se->src()->parent()->weight;
	}
 
	if (freq < adj_freq) {
	    before_i = iter;
	}
	else
	    break;
    }
 

    if (before_i != 0) {
	_sorted_adj_edges.insert_after(before_i.iterator, e);
    }
    else
	_sorted_adj_edges.add_head(e);

    if (_adj_lrs.is_member(lr) == false)
	_adj_lrs.add_tail(lr);
    _adj_lr_map.bind(e, lr);
}



// Give a LR, 
//   1. remove LR from _adj_lrs
//   2. find matching Edge from _adj_lr_map and remove a map
//   3. remove Edge from _sorted_adj_edges
void
LiveRange::delete_adj_lr(LiveRange* a_lr) {
    Edge* e = NULL;

    _adj_lrs.remove(a_lr);

    for (Map_iterator<Edge*, LiveRange*> m_iter(_adj_lr_map); m_iter!=0; m_iter++) {
	Pair<Edge*, LiveRange*> a_map = *m_iter;
	if (a_map.second == a_lr) {
	    e = a_map.first;
	    _adj_lr_map.unbind(e);
	}
    }

    _sorted_adj_edges.remove(e);
}



void
LiveRange::get_patch_cost_table(const GlobalBoundMap& b_map) {

    for (Map_iterator<Edge*, LiveRange*> m_iter(_adj_lr_map); m_iter!=0; m_iter++) {

	Pair <Edge*,LiveRange*>& a_pair = *m_iter;
	Edge* e = a_pair.first;
	LiveRange* adj = a_pair.second;
	Control_flow_freq* cf_freq = get_control_flow_freq(e);
	double freq = 0;
	if (cf_freq) {
	    freq = cf_freq->freq;
	}
	else {
	    freq = _live_region->_region->weight;
	}

	switch (adj->_reg_bind_state) {
	case CALLER_BOUND:
	case CALLEE_BOUND: {
	    int reg = adj->_var.mc_num();
	    if (_patch_cost_map.is_bound(reg)) {
		_patch_cost_map.bind(reg, _patch_cost_map.value(reg)+freq);
	    }
	    else {
		_patch_cost_map.bind(reg, freq);
	    }
	    _prefer_regs.set_bit(reg);
	    break;
	}

	case SPILLED: 
	{
	    int reg = -1;
	    if (_patch_cost_map.is_bound(reg)) {
		_patch_cost_map.bind(reg, _patch_cost_map.value(reg)+freq);
	    }
	    else {
		_patch_cost_map.bind(reg, freq);
	    }
	    break;
	}

	case DELAYED: 
	{
	    for (Map_iterator<int,double> iter(_patch_cost_map); iter!=0; iter++) {
		Pair <int, double>& cost_pair = *iter;
		int reg = cost_pair.first;
		if (reg == -1) {
		    _patch_cost_map.bind(reg, cost_pair.second+freq);
		}
		else if (_forbidden_regs.is_member(reg)==false) {
		    _patch_cost_map.bind(reg, cost_pair.second+freq);
		    _prefer_regs.set_bit(reg);
		}
	    }
	    break;
	}

	default:
	    assert(0);
	}
    } 

}



// bind phisical register to LiveRange
// update forbidden set for itself and all interfered LiveRange
void
LiveRange::bind_register(int reg_num_,
			 CallerCalleeType reg_save_type) {

    if (reg_num_ < 0)
	return;

    if (reg_save_type == CALLER_SAVED)
	_reg_bind_state = CALLER_BOUND;
    else if (reg_save_type == CALLEE_SAVED)
	_reg_bind_state = CALLEE_BOUND;


    _var.bind_reg(reg_num_);
    _live_region->bind_register(reg_num_, reg_save_type);

    _forbidden_regs += reg_num_;
    _forbidden_bv.set_bit(reg_num_);
    for (List_iterator<LiveRange*> iter2(_inf_lrs); iter2 != 0; iter2++) {
	LiveRange* lr_ptr = *iter2;
	lr_ptr->_forbidden_regs += reg_num_;
	lr_ptr->_forbidden_bv.set_bit(reg_num_);
    }

    for (List_iterator<LiveRange*> iter(_adj_lrs); iter != 0; iter++) {
	LiveRange* adj_lr = *iter;
	adj_lr->_prefer_regs.set_bit(reg_num_);
    }

    RegisterBank& a_bank = RegisterBankPool::instance().bank(_var.file_type()); 
    a_bank._reg_use_count[reg_num_]++;
}


void
LiveRange::upscale_forbidden() {
    for (int i1 = 0; i1 <= _live_region->_forbidden_regs.last_one(); i1++) {
	if (_live_region->_forbidden_regs.bit(i1)) {
	    _forbidden_regs += i1;
	    _forbidden_bv.set_bit(i1);
	}
    }
}


//
// find a register for coloring this LiveUnit
//
LiveRange::RegBindState
LiveRange::coloring() {
    if (_forbidden_bv.ones_count() == _reg_bank._caller_size + _reg_bank._callee_size) {
	return _reg_bind_state;
    }

    if (caller_benefit() <0 && callee_benefit() < 0) {
	// both benefit_caller and benefit_caller is negative

	spilling();
	return _reg_bind_state;
    }

    if (is_pass_through()) {
	if (EL_do_delayed_binding) {
	    // this is pass through LiveUnit
	    delaying();
	}
	else {
	    int reg = select_register_intra();
	    if (reg == -1) {
		spilling();
	    }
	    else if (_reg_bank._caller_bv.bit(reg)) {
		bind_register(reg, CALLER_SAVED);
	    }
	    else if (_reg_bank._callee_bv.bit(reg)) {
		bind_register(reg, CALLEE_SAVED);
	    }
	}
	return _reg_bind_state;
    }

    force_coloring();
    return _reg_bind_state;
}


void
LiveRange::force_coloring() {
    int reg = select_register_intra();
    if (_patch_cost_map.is_bound(reg) == false && reg >= 0) {
	double benefit = 0;
	for (Map_iterator <Edge*, LiveRange*> m_iter(_adj_lr_map); m_iter!=0; m_iter++) {
	    Pair<Edge*, LiveRange*>& a_pair = *m_iter;
	    Edge* e = a_pair.first;
	    LiveRange* adj = a_pair.second;
	    if (adj->_reg_bind_state == DELAYED && adj->_forbidden_bv.bit(reg) == false) {
		Control_flow_freq* cf_freq = get_control_flow_freq(e);
		if (cf_freq)
		    benefit += get_control_flow_freq(e)->freq;
		else
		    benefit += _live_region->_region->weight;
	    }
	}
	_patch_cost_map.bind(reg, benefit);
	if (reg > -1)
	    _prefer_regs.set_bit(reg);
    }

    if (EL_propagate_coloring == true) {
	color_by_patch_cost();
    }
    else {
	if (reg == -1) {
	    spilling();
	}
	else if (_reg_bank._caller_bv.bit(reg)) {
	    bind_register(reg, CALLER_SAVED);
	}
	else if (_reg_bank._callee_bv.bit(reg)) {
	    bind_register(reg, CALLEE_SAVED);
	}
    }

    return ;
}

void
LiveRange::color_by_patch_cost() {
    int reg = -1;
    double max_benefit = -1;
    for (Map_iterator <int,double> iter(_patch_cost_map); iter!=0; iter++) {

	Pair <int,double>& a_pair = *iter;
	int adj_reg = a_pair.first;
	double benefit = a_pair.second -_patch_sum;

	if (adj_reg == -1) {
	    // spilled
	}
	else if (_forbidden_bv.bit(adj_reg)) {
	    continue;
	}
	else if (_reg_bank._caller_bv.bit(adj_reg)) {
	    benefit += _live_region->_caller_benefit;
	}
	else if (_reg_bank._callee_bv.bit(adj_reg)) {
	    benefit += _live_region->_callee_benefit;
	}
	else {
	    assert(0);
	}

	if (benefit > max_benefit) {
	    max_benefit = benefit;
	    reg = adj_reg;
	}
    }

    if (max_benefit >= 0) {
	if (reg == -1) {
	    spilling();
	}
	else if (_reg_bank._caller_bv.bit(reg)) {
	    bind_register(reg, CALLER_SAVED);
	}
	else if (_reg_bank._callee_bv.bit(reg)) {
	    bind_register(reg, CALLEE_SAVED);
	}
    }
}


int
LiveRange::select_register(CallerCalleeType _call_type) {
    int pref_reg = -1;
    RegisterBank& rb = RegisterBankPool::reg_bank(_var.file_type());
    List_set<int> reg_pool;
    int reg_size;

    if (_call_type == CALLER_SAVED) {
	reg_pool = rb.caller_set();
	reg_size = reg_pool.size();
    }
    else {
	reg_pool = rb.callee_set();
	reg_size = reg_pool.size();
    }

    // EL_register_choose;
    // 0: choose first available by number
    // 1: use hash function based
    // 2: clockhand algorithm
    if (EL_register_choose == 0) {
	for (List_set_iterator<int> iter(reg_pool); iter!=0; iter++) {
	    if (_forbidden_regs.is_member(*iter) == false) {
		pref_reg = *iter;
		break;
	    }
	}
    }
    else if (EL_register_choose == 1) {
	for (int i = 0; i < reg_size; i++) {
	    int reg = (_var.vr_num()+i) % reg_size + reg_pool.head();
	    if (_forbidden_regs.is_member(reg) == false) {
		pref_reg = reg;
		break;
	    }
	}
    }
    else if (EL_register_choose == 2) {
	int clockhand = get_clockhand(_live_region->region(), _call_type);
	for (int i = 0; i < reg_size; i++) {
	    int reg = (clockhand+i) % reg_size + reg_pool.head();
	    if (_forbidden_regs.is_member(reg) == false) {
		pref_reg = reg;
		update_clockhand(_live_region->region(), _call_type, reg);
		break;
	    }
	}
    }
    return pref_reg;
}

int
LiveRange::select_register_intra() {

    Bitvector reg_pool;

    if (_forbidden_bv.ones_count() == _reg_bank._caller_size + _reg_bank._callee_size) {
	return -1;
    }

    if (_live_region->_caller_benefit > _live_region->_callee_benefit) {
	reg_pool = _reg_bank._caller_bv;
	reg_pool -= _forbidden_bv;
	if (reg_pool.ones_count() == 0) {
	    reg_pool = _reg_bank._callee_bv;
	    reg_pool -= _forbidden_bv;
	    assert(reg_pool.ones_count()>0);
	}
    }
    else if (_live_region->_caller_benefit < _live_region->_callee_benefit) {
	reg_pool = _reg_bank._callee_bv;
	reg_pool -= _forbidden_bv;
	if (reg_pool.ones_count() == 0) {
	    reg_pool = _reg_bank._caller_bv;
	    reg_pool -= _forbidden_bv;
	    assert(reg_pool.ones_count()>0);
	}
    }
    else {
      //reg_pool = _reg_bank._callee_bv | _reg_bank._caller_bv;
      reg_pool = _reg_bank._callee_bv;
      reg_pool += _reg_bank._caller_bv;
	reg_pool -= _forbidden_bv;
	assert(reg_pool.ones_count()>0);
    }

    int selection = reg_pool.first_one();
    for (List_iterator<Edge*> iter(_sorted_adj_edges); iter!=0; iter++) {
	Edge* e = *iter;
	LiveRange* adj = _adj_lr_map.value(e);
	if (adj->reg_bind_state()==DELAYED) {
	    Bitvector pref = adj->_prefer_regs;
	    reg_pool -= pref;
	}
	if (reg_pool.ones_count() == 0) {
	    break;
	}
	else {
	    selection = reg_pool.first_one();
	}
    }

    /*
    {
	int hash_reg = _var.vr_num() % (_reg_bank._size - _reg_bank._macro_size) + _reg_bank._macro_size;
	if (reg_pool.bit(hash_reg)) {
	    selection=hash_reg;
	}

    }
    */

    return selection;
}


void
LiveRange::allocate_new_register() {

    int pref_reg;

    if (EL_call_cost_split == 0) {
	if (_live_region->_brl_num == 0) {
	    // use caller first
	    pref_reg = select_register(CALLER_SAVED);
	    if (pref_reg >= 0) {
		bind_register(pref_reg, CALLER_SAVED);
		return;
	    }
	    else {
		pref_reg = select_register(CALLEE_SAVED);
		bind_register(pref_reg, CALLEE_SAVED);
		return;
	    }
	}
	else {
	    pref_reg = select_register(CALLEE_SAVED);
	    if (pref_reg >= 0) {
		bind_register(pref_reg, CALLEE_SAVED);
		return;
	    }
	    else {
		pref_reg = select_register(CALLER_SAVED);
		bind_register(pref_reg, CALLER_SAVED);
		return;
	    }
	}	    
	return;
    }


    if (callee_benefit() > caller_benefit()) {
	pref_reg = select_register(CALLEE_SAVED);
	if (pref_reg >= 0) {
	    bind_register(pref_reg, CALLEE_SAVED);
	    return;
	}

	if (is_pass_through()) {
	    // this is pass through LiveUnit
	    delaying();
	    return;
	}
	else if (EL_call_cost_split == 1) {
	    if (caller_benefit() > 0) {
		pref_reg = select_register(CALLER_SAVED);
		bind_register(pref_reg, CALLER_SAVED);
	    }
	    else {
		spilling();
	    }
	}
	else {
	    return;  // for split
	}
    }
    else if (caller_benefit() >= callee_benefit()) {
	pref_reg = select_register(CALLER_SAVED);
	if (pref_reg >= 0) {
	    bind_register(pref_reg, CALLER_SAVED);
	    return;
	}
	    
	if (is_pass_through()) {
	    // this is pass through LiveUnit
	    delaying();
	    return;
	}
	else if (EL_call_cost_split == 1) {
	    if (callee_benefit() > 0) {
		pref_reg = select_register(CALLEE_SAVED);
		bind_register(pref_reg, CALLEE_SAVED);
	    }
	    else
		spilling();
	}
	else {
	    if (callee_benefit() > 0) {
		pref_reg = select_register(CALLEE_SAVED);
		bind_register(pref_reg, CALLEE_SAVED);
	    }
	    else
		return; // for split
	}
    }
}


// Coloring of this LiveRange is delayed. 
// Try to bind with adj_lrs information
void
LiveRange::coloring_pass_through() {

    assert(_reg_bind_state == DELAYED);

    if (_patch_cost_map.size()) {
	color_by_patch_cost();
    }

    if (_reg_bind_state == DELAYED) {
	if (_sorted_adj_edges.size() == entry_edges().size() + exit_edges().size()) {
	    force_coloring();
	}
    }

    return;
}


//
// Try to color this LiveUnit with the same register R1 to pref_lr.
// If R1 is not forbidden and its cost is minimum, R1 is used.
//
void
LiveRange::propagate_in(Edge* e, LiveRange* pref_lr) {

    double e_freq = 0;
    Control_flow_freq* cf_freq = get_control_flow_freq(e);
    if (EL_use_frequency == 0) {
	e_freq = 1;
    }
    else if (cf_freq) {
	e_freq = cf_freq->freq;
    }
    else {
	assert(e->src()->parent() == e->dest()->parent());
	e_freq = e->src()->parent()->weight;
    }


    switch(pref_lr->reg_bind_state()) {
    case LiveRange::UNDEFINED:
	break;
    case LiveRange::DELAYED:
	// This is not pass-through. Do not increase _forbidden_regs.
	//_forbidden_regs += adj_lr->_forbidden_regs;
	break;
    case LiveRange::SPILLED: {
	if (EL_call_cost_propagate) {
	    double bind_benefit = 0;
	    if (caller_benefit() > callee_benefit())
		bind_benefit = caller_benefit();
	    else
		bind_benefit = callee_benefit();

	    // Need to reconcile cost if you bind this LR to register
	    double reconcile_cost = 0;
	    if (entry_edges().is_member(e)) {
		reconcile_cost = LOAD_LATENCY * e_freq;
	    }
	    else if (exit_edges().is_member(e)){
		reconcile_cost = STORE_LATENCY * e_freq;
	    }
	    else {
		assert(0);
	    }
	    
	    if (bind_benefit - reconcile_cost) {
		// it is better to bind. Try another one.
	    }
	    else {
		// spill current LiveUnit
		spilling();
	    }
	}
	else {
	    spilling();
	}
	break;
    }

    case LiveRange::CALLER_BOUND: {
	if (EL_call_cost_propagate) {
	    int pref_reg = pref_lr->mc_num();
	    if (_forbidden_regs.is_member(pref_reg))
		break;
	    
	    if (caller_benefit() < callee_benefit() - MOVE_LATENCY * e_freq) {
		// absolute callee preferd. try another LR
	    }
	    else
		bind_register(pref_reg, CALLER_SAVED);
	}
	else {
	    int pref_reg = pref_lr->mc_num();
	    if (_forbidden_regs.is_member(pref_reg) == false)
		bind_register(pref_reg, CALLER_SAVED);
	}
	break;
    }

    case LiveRange::CALLEE_BOUND: {
	if (EL_call_cost_propagate) {
	    int pref_reg = pref_lr->mc_num();
	    if (_forbidden_regs.is_member(pref_reg))
		break;
	
	    if (callee_benefit() < caller_benefit() - MOVE_LATENCY * e_freq) {
		// absolute caller preferd. try another LR
	    }
	    else
		bind_register(pref_reg, CALLEE_SAVED);
	}
	else {
	    int pref_reg = pref_lr->mc_num();
	    if (_forbidden_regs.is_member(pref_reg) == false)
		bind_register(pref_reg, CALLEE_SAVED);
	}
	break;
    }

    default:
	assert(0);
    }

}


void
LiveRange::propagate_out(LiveRange* adj_lr) {

    if (EL_call_cost_propagate == 0) {
	if (reg_bind_state() == SPILLED) {
	    adj_lr->spilling();
	}
	else if (reg_bind_state() == CALLER_BOUND) {
	    int reg_num = _var.mc_num();
	    if (adj_lr->_forbidden_regs.is_member(reg_num) == false) {
		adj_lr->bind_register(reg_num, CALLER_SAVED);
	    }
	    else {
		adj_lr->spilling();
	    }
	}
	else if (reg_bind_state() == CALLEE_BOUND) {
	    int reg_num = _var.mc_num();
	    if (adj_lr->_forbidden_regs.is_member(reg_num) == false) {
		adj_lr->bind_register(reg_num, CALLEE_SAVED);
	    }
	    else {
		adj_lr->spilling();
	    }
	}
    }
    else {
	if (reg_bind_state() == SPILLED) {
	    adj_lr->spilling();
	}
	else if (reg_bind_state() == CALLER_BOUND) {
	    int reg_num = _var.mc_num();
	    if (adj_lr->_forbidden_regs.is_member(reg_num) == false
		&& adj_lr->caller_benefit() >= 0) {
		adj_lr->bind_register(reg_num, CALLER_SAVED);
	    }
	    else {
		adj_lr->spilling();
	    }
	}
	else if (reg_bind_state() == CALLEE_BOUND) {
	    int reg_num = _var.mc_num();
	    if (adj_lr->_forbidden_regs.is_member(reg_num) == false 
		&& adj_lr->callee_benefit() >= 0) {
		adj_lr->bind_register(reg_num, CALLEE_SAVED);
	    }
	    else {
		adj_lr->spilling();
	    }
	}
    }
}

void
LiveRange::delaying() {
    _reg_bind_state = DELAYED;
}

void
LiveRange::spilling() {
    _reg_bind_state = (SPILLED);
    _live_region->spilling();
    _var.bind_reg(-1);

}

// check each adjacent LR for
// if adj_lr is BOUND/SPILLED, add patch up between
// if adj_lr is DELAYED, propagate binding to adj_lr
void
LiveRange::reconcile() {

    for (List_iterator<Edge*> iter(_sorted_adj_edges); iter!=0; iter++) {

	Edge* e = *iter;
	LiveRange* adj_lr = _adj_lr_map.value(e);

	if (adj_lr->reg_bind_state() == DELAYED) {
	    this->propagate_out(adj_lr);
	    adj_lr->reconcile();
	}
	else if (_reconciled_edges.is_member(e) == false) {
	    _reconciled_edges.add_tail(e);
	    adj_lr->_reconciled_edges.add_tail(e);

	    if (entry_edges().is_member(e)) {
		ReconcileCodeSet::add2edge(LiveRangePair(e, adj_lr, this));
	    }
	    else if (exit_edges().is_member(e)) {
		ReconcileCodeSet::add2edge(LiveRangePair(e, this, adj_lr));
	    }
	    else {
		assert(0);
	    }
	}
    }
}






Pair<LiveRange*, LiveRange*>
LiveRange::split() {
    Pair<LiveRange*, LiveRange*> new_lr_pair;
    Pair<LiveUnit*, LiveUnit*> lu_pair;
    lu_pair = _live_region->split();
    LiveUnit* lu1 = lu_pair.first;
    LiveUnit* lu2 = lu_pair.second;

    LiveRange* lr1 = new LiveRange(lu1->_var);
    LiveRange* lr2 = new LiveRange(lu2->_var);
    lr1->set_live_unit(lu1);
    lr2->set_live_unit(lu2);
    new_lr_pair.first = lr1;
    new_lr_pair.second = lr2;


    // remove old_lr's effect
    // remove old_lr from adj_lr's adj_list
    for (List_iterator<LiveRange*> iter(_adj_lrs); iter != 0; iter++) {
	LiveRange* adj_lr = *iter;
	adj_lr->delete_adj_lr(this);
    }

    /*
      This is not necessary anymore.
      After creating a new LR, adj_lr information is created in 
      RegAllocSolver::process_coloring()

    // split adj_lr information
    for (Map_iterator<Edge*, LiveRange*> iter(_adj_lr_map); iter != 0; iter++) {
	Edge* adj_e = (*iter).first;
	LiveRange* adj_lr = (*iter).second;

	if (lu1->_entry_edges.is_member(adj_e) || lu1->_exit_edges.is_member(adj_e)) {
	    lr1->add_adj_lr(adj_e, adj_lr);
	}
	else if (lu2->_entry_edges.is_member(adj_e) || lu2->_exit_edges.is_member(adj_e)) {
	    lr2->add_adj_lr(adj_e, adj_lr);
	}
	else {
	    // impossible
	    assert(0);
	}
    }
    */

    // create new adj_lr info between new LR
    //lu1->add_all_adj_lr(lr1, lr2);


    // update interference graph
    for (List_iterator<LiveRange*> diter1(_inf_lrs); diter1!=0; diter1++) {
	LiveRange* lr_ptr = *diter1;
	
	// remove iterference information of old LiveRange
	lr_ptr->_inf_lrs.remove(this);

	if (lr1->_live_region->is_in_interference_set(lr_ptr->_live_region)) {
	    lr_ptr->_inf_lrs.add_tail(lr1);
	    lr1->_inf_lrs.add_tail(lr_ptr);
	}

	if (lr2->_live_region->is_in_interference_set(lr_ptr->_live_region)) {
	    lr_ptr->_inf_lrs.add_tail(lr2);
	    lr2->_inf_lrs.add_tail(lr_ptr);
	}
    }
    
    // split forbidden regs.
    lr1->upscale_forbidden();
    lr2->upscale_forbidden();

    return new_lr_pair;
}
