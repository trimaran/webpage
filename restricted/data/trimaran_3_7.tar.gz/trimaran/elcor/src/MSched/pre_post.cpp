/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1995 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           pre_post.cpp
//      Authors:        Vinod Kathail, Shail Aditya
//      Created:        September 1995
//      Description:    Pre/post processing of swp loop regions
//
/////////////////////////////////////////////////////////////////////////////

#include "defs.h"
#include "list.h"
#include "23set.h"
#include "vector.h"
#include "hash_functions.h"

#include "el_error.h"
#include "el_ssched_init.h"
#include "el_lsched_init.h"

#include "region.h"
#include "iterators.h"
#include "port.h"
#include "op.h"
#include "opcode.h"
#include "connect.h"
#include "el_bb_tools.h"
#include "opcode_properties.h"
#include "el_control.h"
#include "edge.h"
#include "edge_utilities.h"
#include "edge_drawing.h"
#include "attributes.h"
#include "msched_attributes.h"
#include "operand.h"
#include "pre_post.h"

//------------------------ Pre processing of loop and preloop --------------
// Functions to do the following:
// 1. Replace BRLC (or BRCT) by Brtop (or wtop) in loop
// 2. Insert staging predicates for all ops in loops
// 3. Hoist pbr to the pre-loop (only if El_lsched_hoist_pbr is true)

static void msched_convert_branch_and_insert_predicates(LoopBody* loop);
static Op* msched_convert_branch(Compound_region* body);
static Op* msched_construct_swp_branch(Op* non_swpbr);
static void msched_insert_predicates(Compound_region* body, Op* swpbr);
static void msched_hoist_pbr(LoopBody* loop);

// Do as described above
void msched_preprocess(LoopBody* loop){
  // we need to hoist pbr before inserting predicates
  if (El_lsched_hoist_pbr) msched_hoist_pbr(loop);
  msched_convert_branch_and_insert_predicates(loop);
}

// Convert branch in loop to Brtop and insert staging predicates
void msched_convert_branch_and_insert_predicates(LoopBody* loop){
    Compound_region* body = loop->kernel();
    Op* swpbr = msched_convert_branch(body);
    msched_insert_predicates(body, swpbr);
}

// Replace branch by Brtop
Op* msched_convert_branch(Compound_region* body) {
  Op *non_swpbr = *(Region_exit_ops(body));
  Op* swpbr = msched_construct_swp_branch(non_swpbr);
  // Replace old branch with Brtop
  El_replace_op(body, non_swpbr, swpbr);  
  // move the rel_ops of the old branch to the rel_ops of the new branch
  for (List_iterator<Op*> rels(non_swpbr->get_relops()); rels != 0; 
       rels++) {
    Op *rel_op = *rels;
    swpbr->add_relops(rel_op);
    rel_op->add_relops(swpbr);
    non_swpbr->remove_relops(rel_op);
    rel_op->remove_relops(non_swpbr);
  }
  // delete the old branch
  delete non_swpbr;
  return swpbr;
}

// Construct a new Brtop op
Op* msched_construct_swp_branch(Op* non_swpbr){
  Operand* brtarget = new Operand(non_swpbr->src(non_swpbr->first_src()));
  // Construct staging predicate output of Brtop. It is set to be static. 
  // remap insertion would convert it to be rotating.
  Operand staging_predicate(new Reg(EL_DT_PREDICATE));
  staging_predicate.bind_file(PR, STATIC); 

  // Construct esc and lc operands. These are explicit sources and 
  // destinations to brf in the compiler, but not in PalyDoh assembly
  Operand esc_opnd(new Macro_reg(ESC_REG));
  Operand lc_opnd(new Macro_reg(LC_REG));

  // Construct SWP loop branch
  Op* swpbr =  new Op(BRF_B_B_F);
  swpbr->set_dest(swpbr->first_dest(), staging_predicate);  
  swpbr->set_dest((swpbr->first_dest()) + 1 , lc_opnd);  
  swpbr->set_dest((swpbr->first_dest()) + 2, esc_opnd);  
  swpbr->set_src(swpbr->first_src(), *brtarget);
  swpbr->set_src((swpbr->first_src()) + 1, lc_opnd);
  swpbr->set_src((swpbr->first_src()) + 2, esc_opnd);
  return swpbr;
}

static void msched_insert_predicates(Compound_region* body, Op* swpbr){

  /*  for all ops except brtop and wtop
   *  if predicate input is undefined or true
   *    set predicate input to staging predicate
   * Note that remap for staging predicate happens before brtop so
   * evr offset for both brtop dest and pred input for ops is the same.
   */ 
   Operand& staging_predicate = swpbr->dest(DEST1);
   Op* op;
   for (Region_all_ops ops(body); ops != 0; ops++) {
       op = *ops;
       if (is_pseudo(op) || is_swp_branch(op) || is_pbr(op)) continue;
       Operand predicate = op->src(PRED1);
       if (predicate.is_undefined() || predicate.is_predicate_true()) {
	   op->set_src(PRED1, staging_predicate);
       }
   }
}

static void msched_hoist_pbr(LoopBody* loop) {
  Compound_region* kernel = loop->kernel();
  Compound_region* preloop = loop->preloop();
  Op *op;
  bool found = false;

  for (Region_ops_C0_order ops(kernel); ops != 0; ops++) {
    op = *ops;

    if (is_pbr(op) || is_movelb(op) || is_movelbx(op) || is_movelbs(op)) {
      El_remove_op(op);
      El_insert_op_before_switch(preloop, op);

      if (is_pbr(op)) {
	if (found) El_punt("MSCHED: Can't hoist more than one pbr.");
	found = true;
      }
    }
  }
}

// --------------------------- Post processing of preloop --------------------
// Does only one thing
//   1. Inserts ops to set esc in preloop.
//   2. Clear all rotating registers in preloop.
//   3. Set staging predicate in preloop. 
//   4. Insert copies from vrs to rotating regsiters for live-ins in the
//       preloop
//   5. Insert copies from rotating registers to vrs for live-outs in post-loop
//   Note: 4 and 5 are a crutch . They will not be done when scalar allocator 
//         is in place.

static void msched_insert_esc_op(Compound_region* preloop, int esc);
static void msched_insert_predicates_clear(Compound_region* preloop);
static void msched_insert_preloop_copies(Compound_region* preloop,
					 Map<Operand, int>& inmap,
					 Operand& stage_pred); 
static void msched_insert_postloop_copies(Compound_region* postloop,
					 Map<Operand, int>& outmap); 
static void msched_insert_copy_op(Compound_region* block, 
				  Operand& src, Operand& dest);

void msched_postprocess(LoopBody* loop){
  Compound_region* preloop = loop->preloop();
  Compound_region* postloop = loop->postloop();
  Region_exit_ops exo(loop->kernel());
  Op* swp_br = *exo;
  Operand& stage_pred =  swp_br->dest(swp_br->first_dest());

  // Set esc in preloop
  int esc = msched_info_esc(get_msched_info(loop));
  msched_insert_esc_op(preloop, esc);

  // Insert pred clear in preloop
  msched_insert_predicates_clear(preloop);

  // Insert copies in preloop including staging pred set
  Map<Operand, int>* inmap = (Map<Operand, int>*)
                               get_generic_attribute(loop, "Entry_alloc_map");
  if (inmap) msched_insert_preloop_copies(preloop, *inmap, stage_pred);
  // Insert copies in postloop
  Map<Operand, int>* outmap = (Map<Operand, int>*) 
                               get_generic_attribute(loop, "Exit_alloc_map");
  if (outmap) msched_insert_postloop_copies(postloop, *outmap);
}

// set the epilogue stage count register
void msched_insert_esc_op(Compound_region* preloop, int esc){
  Operand esc_opd(new Macro_reg(ESC_REG));
  Operand esc_lit(new Int_lit(esc));
  msched_insert_copy_op(preloop, esc_lit, esc_opd);
}

// Clear all the predicates. This needs to change after we decide how to
// proceed. Also edge drawing has to recognize this situation.

void msched_insert_predicates_clear(Compound_region* preloop){
  Op* clear_pred = new Op(PRED_CLEAR_ALL_ROTATING);
  Operand all_rot_pred(new Macro_reg(ALL_ROT_PRED));
  clear_pred->set_dest(clear_pred->first_dest(), all_rot_pred);
  El_insert_op_before_switch(preloop, clear_pred);
}

void msched_insert_preloop_copies(Compound_region* preloop, 
				  Map<Operand, int>& inmap,
				  Operand& stage_pred){
  for (Map_iterator<Operand, int> iter(inmap) ; iter != 0 ; iter++) {
    Operand& src = (*iter).first;
    int reg_num = (*iter).second;

    // Test for the staging predicate specially and initialize it with a PRED_SET
    if (src.is_reg() && src.file_type() == PR && 
	src.vr_num() == stage_pred.vr_num()) {
      Op* pred_set_op = new Op(PRED_SET);
      // make a copy of the staging predicate operand
      Operand pred_oprnd = Operand(stage_pred);
      // bind the staging predicate operand according to the map
      pred_oprnd.bind_reg(reg_num);
      pred_set_op->set_dest(pred_set_op->first_dest(), pred_oprnd);
      El_insert_op_before_switch(preloop, pred_set_op);
    } else {
      // make a copy and bind it according to the map
      Operand dest = Operand(src);
      dest.bind_reg(reg_num);
      dest.bind_file(dest.file_type(),ROTATING);
      msched_insert_copy_op(preloop, src, dest);
    }
  }
}

void msched_insert_postloop_copies(Compound_region* postloop, 
				   Map<Operand, int>& outmap){
  for (Map_iterator<Operand, int> iter(outmap) ; iter != 0 ; iter++) {
    Operand& dest = (*iter).first;
    int reg_num = (*iter).second;
    // make a copy and bind it according to the map
    Operand src = Operand(dest);
    src.bind_reg(reg_num);
    src.bind_file(src.file_type(),ROTATING);

// This inserts the instructions just before the switch rather
// than just after the merge. 10/04/95 Change this later.
    msched_insert_copy_op(postloop, src, dest);
  }
}

void msched_insert_copy_op(Compound_region* block, 
			   Operand& src, Operand& dest){
  Op* copy_op;

  switch (dest.file_type()) {
    case GPR: copy_op = new Op(MOVE);
              break;
    case CR:  copy_op = new Op(MOVE);
              break;
    case FPR: if (dest.data_type() == EL_DT_FLOAT) 
              copy_op = new Op(MOVEF_S);
	      else copy_op = new Op(MOVEF_D);
	      break;
    case PR: // copy_op = new Op(MOVEPG);
              El_warn("msched_insert_copy_op: General Predicate copies not possible");
	      return;
    default: El_warn("msched_insert_copy_op: Unsupported file type--BTR");
	     return;
	    }
  Operand pred_true = new Pred_lit(true);
  copy_op->set_src(PRED1, pred_true);
  copy_op->set_src(copy_op->first_src(), src);
  copy_op->set_dest(copy_op->first_dest(), dest);
  El_insert_op_before_switch(block, copy_op);
}

// -------------------------   Construct region for analysis ------------------
static Compound_region* msched_construct_compound_region(List<Region*>& rlist);

Compound_region* msched_construct_ppl_region(LoopBody* loop)
{
    List<Region*> l;
    Compound_region* preloop = (Compound_region*)loop->preloop();
    Compound_region* postloop = (Compound_region*)loop->postloop();
    l.add_tail(preloop);
    l.add_tail(loop);
    l.add_tail(postloop);
    return (msched_construct_compound_region(l));
}


Compound_region* msched_construct_compound_region(List<Region*>& rlist)
{
    Region* first = rlist.head();
    Region* last = rlist.tail();
    Compound_region* parent = (Compound_region*)(first->parent());
    Compound_region* new_region = new Compound_region;
    parent->insert_before_region(new_region, first);
    new_region->set_parent(parent);
    for(List_iterator<Region*> regs(rlist); regs !=0; regs++){
	Region* reg = *regs; 
	parent->remove_region(reg);
	new_region->add_region(reg);
	reg->set_parent(new_region);
    }

    for(Region_entry_edges in_edges(first); in_edges != 0; in_edges++){
	new_region->add_entry_safely(*in_edges);
    }
    for(Region_exit_edges out_edges(last); out_edges!= 0; out_edges++){
	new_region->add_exit_safely(*out_edges);
    }

    for(Region_entry_ops in_ops(first); in_ops != 0; in_ops++){
	new_region->add_entry(*in_ops);
    }
    for(Region_exit_ops out_ops(last); out_ops!= 0; out_ops++){
	new_region->add_exit(*out_ops);
    }
    return new_region;
}

// ---------------- Map livenes information taking allocation into account ----
static void msched_update_dataflow_set(Liveness_info* dataflow_set,
				       Map<Operand, int>* operand_map);


void msched_map_liveness_info(LoopBody* loop){
  Map<Operand, int>* inmap = (Map<Operand, int>*) 
                               get_generic_attribute(loop, "Entry_alloc_map");
  Map<Operand, int>* outmap = (Map<Operand, int>*)
			       get_generic_attribute(loop, "Exit_alloc_map");
  Edge* inedge = get_connecting_CONTROL0_edge(loop->preloop(), loop);
  Edge* outedge = get_connecting_CONTROL0_edge(loop, loop->postloop());

  msched_update_dataflow_set(get_liveness_info(inedge), inmap);
  msched_update_dataflow_set(get_liveness_info(outedge), outmap);
  msched_update_dataflow_set(get_down_exposed_uses_info(inedge), inmap);
  msched_update_dataflow_set(get_down_exposed_uses_info(outedge), outmap);
  msched_update_dataflow_set(get_up_exposed_defs_info(inedge), inmap);
  msched_update_dataflow_set(get_up_exposed_defs_info(outedge), outmap);
  msched_update_dataflow_set(get_down_exposed_defs_info(inedge), inmap);
  msched_update_dataflow_set(get_down_exposed_defs_info(outedge), outmap);
}

void msched_update_dataflow_set(Liveness_info* dataflow_set,
				Map<Operand, int>* operand_map) {
  if (dataflow_set == NULL || operand_map == NULL) return;
  for (Liveness_info_iterator liter(*dataflow_set) ; liter != 0 ; liter++) {
      // apply the operand allocation map to each live operand
      Operand& liveop = *liter;
      if (operand_map->is_bound(liveop)) {
	  int reg_num = operand_map->value(liveop);
	  liveop.bind_reg(reg_num);
	  liveop.bind_file(liveop.file_type(),ROTATING);
      }
  }
}


// ---------------- delete msched specific attributes ------------------------
void msched_delete_region_attributes(LoopBody* loop){
    Map<Operand, int>* inmap = (Map<Operand, int>*) 
                                get_generic_attribute(loop, "Entry_alloc_map");
    remove_generic_attribute(loop, "Entry_alloc_map");
    if (!(inmap == NULL)) delete inmap;
    Map<Operand, int>* outmap = (Map<Operand, int>*)
	                         get_generic_attribute(loop, "Exit_alloc_map");
    remove_generic_attribute(loop, "Exit_alloc_map");
    if (!(outmap == NULL)) delete outmap;      
}
