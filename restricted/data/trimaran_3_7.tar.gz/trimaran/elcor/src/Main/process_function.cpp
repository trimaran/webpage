/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1994 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           process_function.cpp
//      Authors:        Vinod Kathail
//      Created:        November 1995
//      Description:    Default Elcor Compiler Driver
//
/////////////////////////////////////////////////////////////////////////////


#include <iostream.h>
#include "process_function.h"

#include "defs.h"
#include "operand.h"
#include "connect.h"
#include "map.h"
#include "regtochar.h"
#include "stdlib.h"
#include "opcode.h"
#include "edge.h"
#include "edge_drawing.h"
#include "dbg.h"
#include "attributes.h"
#include "pred_analysis.h"
#include "opcode_load_store.h"
#include "hash_map.h"
#include "list.h"
#include "hash_set.h"
#include "el_loop_tools.h"
#include "el_swp_dsa_convert.h"
#include "stdio.h"
#include "matrix.h"
#include "unify_driver.h"
#include "msched_driver.h"
#include "iterators.h"
#include "el_lsched_init.h"

#include "graph_filters.h"
#include "mdes.h"
#include "mdes_attributes.h"
#include "intf.h"
#include "hash_functions.h"
#include "schedule.h"
#include "scalar_sched.h"
#include "el_stat_driver.h"
#include "el_main.h"
#include "el_opcode_usage.h"
#include "el_sreg_driver.h"
#include "el_opti_driver.h"

#include "el_dot_tools.h"
#include "ir_writer.h"
#include "el_clock.h"

#include "ScalarRegAlloc.h"

#ifdef CAR_INTERNAL
#include "gen_literal.h"
#include "restricted_io_formats.h"
#include "emulation.h"
#include "fusing.h"
#endif

#include "el_cpr_driver.h"
#include "el_cpr_prep.h"

//----------------------------------------------------------------------------
// This is the new Elcor compiler driver. The user-based process functions may
// wrap around this one or be completely separate. 
//--------------------------------------------------------------------------

Procedure *El_process_function(Procedure *f)
{
  if (El_do_null_processing==1)
    return (f);

  /* Selective processing skips functions if they meet a certain criteria */
  if (El_sel_processing_mode == EL_SEL_PROC_WEIGHT) {
    if (f->weight <= El_sel_processing_weight) {
      if (dbg (status, 1))
        cout << "Skipping procedure '" << f->get_name() << "'\n";
      if (El_do_stats_always) {
        El_collect_pre_processing_stats(f);
        El_collect_pre_scheduling_stats(f);
        El_collect_post_processing_stats(f);
      }
      return(f);
    }
  }
  else if (El_sel_processing_mode == EL_SEL_PROC_NAME) {
    if (! El_sel_processing_name_table->is_member(f->get_name())) {
      if (dbg (status, 1))
        cout << "Skipping procedure '" << f->get_name() << "'\n";
      if (El_do_stats_always) {
        El_collect_pre_processing_stats(f);
        El_collect_pre_scheduling_stats(f);
        El_collect_post_processing_stats(f);
      }
      return (f);
    }
  }

  f = common_process_function (f);

  return (f);
}

#ifdef SADUN
extern void sadun_process_function(Procedure *) ;
#endif

Procedure *common_process_function(Procedure *f)
{
#ifdef SADUN
   sadun_process_function(f) ;
#endif
   
  if (dbg (status, 1)) {
    cout << "Compiling procedure '" << f->get_name() << "'\n";
  }

  // Initialize da-vinci. We need some common way of initializing guis
#ifndef WIN32
  if (El_ssched_graph_display) {
    gui.initconnect();
    gui.test();
  }
#endif

  // Pre process statistic collection
  El_collect_pre_processing_stats(f); 

  el_opti_driver(f);
  if (dbg(status,5)) {
    char buff[256];
    sprintf(buff, "%s_opti.reb", (char*)f->get_name());
    cdbg << "Printing Rebel after optimization" << endl;
    IR_outstream dbg_out(buff);
    ir_write(dbg_out, f);
  }

  // Control CPR
  if (El_do_scalar_control_cpr) {
    if (dbg(status,2))
      cdbg << "Performing scalar control CPR" << endl;
    El_scalar_control_cpr(f);
  }

  // SLARSEN: Unify before setting up swp regions
  if (El_do_unify) {
    if (dbg(status,2))
      cdbg << "Unifying" << endl;
    unify_driver(f);
  }

  // call control-flow analysis to detect swp loops 
  if (El_do_modulo_scheduling) {
    if (dbg(status,2))
      cdbg << "Finding SWP loops" << endl;
    El_setup_swp_loop_regions(f);
  }

#ifdef CAR_INTERNAL
  // Code generation
  if(El_do_lit_histogram)
    do_literal_histogram(f);
  if(El_do_lit_codegen)
    do_literal_codegen(f);
  if(El_do_restricted_io_codegen)
    do_restricted_io_codegen(f);
  if(El_do_pattern_fusing)
    fusing_codegen(f);
  if(El_do_emulation_codegen)
    emulation_codegen(f);
  // temporary fix
  if (El_do_lit_codegen || El_do_restricted_io_codegen)
    fixup_literal_physical_files(f);
  if (dbg(status,5)) {
    char buff[256];
    sprintf(buff, "%s_codegen.reb", (char*)f->get_name());
    cdbg << "Printing Rebel after code generation" << endl;
    IR_outstream dbg_out(buff);
    ir_write(dbg_out, f);
  }
#endif

  // Stats after xforms, but before scheduling since analyzing scheduled
  // code may not be possible
  El_collect_pre_scheduling_stats(f); 

  // Compute liveness if going to schedule
  if (El_do_prepass_scalar_scheduling || El_do_postpass_scalar_scheduling ||
	El_do_modulo_scheduling || El_do_scalar_regalloc) {
    // Compute local vr_maps and PQS for dataflow analysis
    create_local_analysis_info_for_all_hbs_bbs(f);

    // compute global liveness and verify edge drawing
    if (dbg(status,2))
      cdbg << "Performing Liveness Analysis" << endl;
    if (El_show_edges) {
      el_flow_compute_four_dataflow_sets(f);
      insert_region_scalar_edges(f);
      for (Region_subregions subreg(f); subreg != 0; subreg++)
	  el_dot_display_dfg(*subreg);
      delete_region_edges(f);
      el_flow_delete_three_dataflow_sets(f);
    } else {
      el_flow_compute_liveness(f, ANALYZE_ALLREG);
    }
  }

  // Modulo schedule and allocate all loops in frequency order
  if (El_do_modulo_scheduling) {
    modulo_schedule_all_loops(f);
    if (dbg(status,5)) {
      char buff[256];
      sprintf(buff, "%s_modsched.reb", (char*)f->get_name());
      cdbg << "Printing Rebel after modulo scheduling" << endl;
      IR_outstream dbg_out(buff);
      ir_write(dbg_out, f);
    }
  }

  // Prepass acyclic scheduling of all HBs in frequency order
  if (El_do_prepass_scalar_scheduling) {
    if (dbg(status,2))
      cdbg << "Performing prepass acyclic scheduling" << endl;
    scalar_sched_prolog(f);
    scalar_schedule_all_hbs_bbs (f, EL_SCALAR_SCHED_PREPASS);
    scalar_sched_epilog(f);  
    if (dbg(status,5)) {
      char buff[256];
      sprintf(buff, "%s_presched.reb", (char*)f->get_name());
      cdbg << "Printing Rebel after pre-pass scheduling" << endl;
      IR_outstream dbg_out(buff);
      ir_write(dbg_out, f);
    }
  }

  // Scalar register allocation
  if (El_do_scalar_regalloc) {
    if (dbg(status,2))
      cdbg << "Performing scalar register allocation" << endl;
#ifdef CAR_INTERNAL
    if (El_use_nyu_scalar_regalloc) {
      if (dbg(status, 2))
        cdbg << "NYU register allocation" << endl;
      El_fix_all_pbr_info(f, false);
      create_local_analysis_info_for_all_hbs_bbs(f);
      ScalarRegAlloc reg_alloc(f);
    }
    else {
      if (dbg(status,2))
        cdbg << "Impact register allocation" << endl;
      f = El_scalar_regalloc(f);
    }
    if (El_do_lit_codegen || El_do_restricted_io_codegen)
      fixup_literal_physical_files(f);
    // final phase of codegen needed to handle spill code
    if(El_do_lit_codegen)
      do_literal_codegen(f, true); // postpass true
#else
    if (dbg(status, 2))
      cdbg << "NYU register allocation" << endl;
    El_fix_all_pbr_info(f, false);
    create_local_analysis_info_for_all_hbs_bbs(f);
    ScalarRegAlloc reg_alloc(f);
#endif
    delete_local_analysis_info_for_all_hbs_bbs(f);
    create_local_analysis_info_for_all_hbs_bbs(f);
    el_flow_compute_liveness(f,ANALYZE_ALLREG);
    if (dbg(status,5)) {
      char buff[256];
      sprintf(buff, "%s_regalloc.reb", (char*)f->get_name());
      cdbg << "Printing Rebel after scalar register allocation" << endl;
      IR_outstream dbg_out(buff);
      ir_write(dbg_out, f);
    }
  }

  // Postpass acyclic scheduling of all HBs in frequency order
  if (El_do_postpass_scalar_scheduling) {
    if (dbg(status,2))
      cdbg << "Performing postpass acyclic scheduling" << endl;
    scalar_sched_prolog(f);
    scalar_schedule_all_hbs_bbs (f, EL_SCALAR_SCHED_POSTPASS);
    scalar_sched_epilog(f);  
    if (dbg(status,5)) {
      char buff[256];
      sprintf(buff, "%s_postsched.reb", (char*)f->get_name());
      cdbg << "Printing Rebel after post-pass scheduling" << endl;
      IR_outstream dbg_out(buff);
      ir_write(dbg_out, f);
    }
  }

  // Delete liveness if it was computed
  if (El_do_prepass_scalar_scheduling || El_do_postpass_scalar_scheduling ||
	El_do_modulo_scheduling || El_do_scalar_regalloc) {
    el_flow_delete_liveness(f);
    // delete vr_maps and PQS  
    delete_local_analysis_info_for_all_hbs_bbs(f);
  }

  // Control CPR fixup code, delete unnecessary dummy brs, this may be necessary
  // even when not doing CPR
  if (El_do_scalar_control_cpr) {
    if (dbg(status,2))
      cdbg << "Performing DUMMY_BR fixup for scalar control CPR" << endl;
      El_fixup_dummy_branches(f);
  }
  
  // Post process statistic collection
  El_collect_post_processing_stats(f); 

  return (f);
}

//---------------------------------------------------------------------------
//  Iterate over a compound region and schedule all hbs and bbs 
//---------------------------------------------------------------------------
void scalar_schedule_all_hbs_bbs(Compound_region* r, El_Scalar_Sched_Phase phase)
{
  if (El_do_run_time) {
    El_clock2.reset();
    El_clock3.reset();
    El_clock4.reset();
    El_clock1.start();
  }

  for(Region_subregions_freq sub(r, HB_BB_FILTER, HB_BB_SCHED_FILTER ); 
	sub != 0; sub++){
	Compound_region* subregion = (Compound_region*)*sub;
	// SAM 4-97, temporary hack, so don't postpass sched SWPs where the 
        // loopbody indicator is lost going back thru Impact for scalar regalloc
	if (subregion->flag(EL_REGION_SOFTPIPE) &&
	    subregion->flag(EL_REGION_VIOLATES_LC_SEMANTICS)) {
	    subregion->set_flag(EL_REGION_SCHEDULED);
	    continue;
	}
	scalar_scheduler_driver(subregion, phase);
    }

  if (El_do_run_time) {
    El_clock1.stop();
    El_stopwatch_print_time("total_edge_drawing", El_clock2.total_elapsed());
    El_stopwatch_print_time("total_scalar_scheduling", El_clock3.total_elapsed());
    El_stopwatch_print_time("total_delete_edges", El_clock4.total_elapsed());
    El_stopwatch_print_time("scalar_schedule_all_hbs_bbs",
				El_clock1.last_elapsed());
  }
}

//---------------------------------------------------------------------------
//  Iterate over a compound region and schedule all hbs and bbs 
//---------------------------------------------------------------------------
void modulo_schedule_all_loops(Compound_region* r)
{

  if (El_do_run_time)
    El_clock1.start();

  for(Region_subregions_freq sub(r, LOOPBODY_FILTER, LOOPBODY_HB_BB_FILTER); 
      sub != 0; sub++){
    LoopBody* loop = (LoopBody*)*sub;
    r->set_flag(EL_PROC_ROT_REG_ALLOCATED);
    // Added SAM 4-98, Impact requires this flag to be set to properly analyze
    // the staging predicates created by msched
    r->set_flag(EL_PROC_HYPERBLOCK);
    modulo_scheduler_driver(loop);
  }

  if (El_do_run_time) {
    El_clock1.stop();
    El_stopwatch_print_time("modulo_schedule_all_loops",
                                El_clock1.last_elapsed());
  }
}
