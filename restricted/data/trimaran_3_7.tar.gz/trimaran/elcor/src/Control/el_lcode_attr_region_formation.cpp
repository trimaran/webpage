/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1996 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           el_lcode_attr_region_formation.cpp
//      Author:         Matthai Philipose
//      Created:        August 1996
//      Description:    Given a procedure with some bbs annotated as start-bbs
//                      of a desired compound region, along with the bbs that
//                      go into that compound region, create and if-convert
//                      these compound regions
//
/////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include "control_analysis_solver.h"
#include "iterators.h"
#include "list.h"
#include "el_bb_tools.h"
#include "map.h"
#include "el_if_converter.h"
#include "el_control.h"
#include "edge_utilities.h"
#include "op.h"
#include "edge.h"
#include "el_opti.h"
#include "connect.h"
#include "opcode_properties.h"
#include "attributes.h"
#include "edge_attributes.h"
#include "el_normalize_branches.h"
#include "dbg.h"
#include "pred_analysis.h"
#include "el_bb_tools.h"
#include "el_loop.h"
#include "el_profile_based_region_formation.h"
#include "el_control_init.h"
#include "el_lcode_attr_region_formation.h"
#include "el_tail_duplication.h"

void el_if_convert_lcode_attr_specified_regions(Procedure* f)
{
  Hash_set<Basicblock*> proc_bbs;
  Hash_set<Basicblock*> region_bbs;
  Hash_set<Edge*> top_entry_edges;
  
  //Extract all the bblocks in the cfg for the procedure
  El_confirm_BB_tiling(f,proc_bbs);
  
  
  //Iterate through the basic blocks searching for bbs annotated
  //with region entry info; form and if-convert these regions
  for(Hash_set_iterator<Basicblock*> bb_iter(proc_bbs);bb_iter!=0;bb_iter++)
    {
      Basicblock* start_bb=*bb_iter;
      Compound_region* cr;

      //if the current bb is a region entry, mark and if-convert the
      //region
      if(el_is_region_entry(start_bb))
	{
	  region_bbs.clear();
	  top_entry_edges.clear();
	  
	  //gather edges into the entry bblock of the loop body
	  for(Region_entry_edges e_iter(start_bb);e_iter!=0;e_iter++)
	    {
	      Edge* edge = *e_iter;
	      top_entry_edges += edge;
	    }
	  
	  el_find_region_bbs_from_attr(start_bb,region_bbs,proc_bbs);
	  
	  //form the cr corresponding to this loop body
	  cr=el_mark_cr_on_cfg(f,region_bbs,top_entry_edges);
	  
	  //tail duplicate
	  Hash_set<Edge*> side_entries=*compound_region_entry_edges(cr);
	  side_entries-= top_entry_edges;
	  Hash_set<Basicblock*> new_tail_bbs;
	  Hash_map<Basicblock*,Basicblock*> tail_map(hash_bb_ptr,MAX_BBS_IN_TAIL);
	  el_tail_duplicate(cr,side_entries,top_entry_edges,new_tail_bbs,tail_map);	  

	  //if-convert
	  El_if_convert(cr, El_frp_model);
	  
	  //nuke the region now it's not needed
	  El_remove_region(cr, true);  	  
	}
    }

  return;
}

bool el_is_region_entry(Basicblock* bb)
{
  Lcode_attribute_map* attr_map=get_lcode_attributes(bb);
  if(attr_map->is_bound("IMPACT_reg"))
    return true;
  else
    return false;
}

void el_find_region_bbs_from_attr(Basicblock* start_bb,Hash_set<Basicblock*>& region_bbs,
				  Hash_set<Basicblock*>& all_bbs) 
{
  Hash_set<int> bb_nums;
  
  Lcode_attribute_map* attr_map=get_lcode_attributes(start_bb);
  assert(attr_map->is_bound("IMPACT_reg"));
  
    List<Operand> bb_list=attr_map->value("IMPACT_reg");
      
    for(List_iterator<Operand> oiter(bb_list);oiter!=0;oiter++)
      {
	Operand opr=(*oiter);
	int bb_num=opr.int_value();
	bb_nums+=bb_num;
      }
      
    //find the bbs  corresponding to these bb nums
    for(Hash_set_iterator<Basicblock*> bb_iter(all_bbs); bb_iter != 0; bb_iter++)
      {
	Basicblock* cur_bb=*bb_iter;
	int id=cur_bb->id();
	  
	//If the bb is one named in the file,
	//put it in the list of region constituent bbs
	if(bb_nums.is_member(id))
	  region_bbs+=cur_bb;
      }
         
    return;
}
