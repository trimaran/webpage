/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1996 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           el_tree_formation.cpp
//      Authors:        Sumedh Sathaye
//      Created:        May 1996
//      Description:    For each procedure in the elcor {rebel,lcode}
//                      file, construct a tree out of the BBs, HBs, and the
//                      already existing trees (this is a maybe).
//      Notes:
//      18-May-1996 As a first cut, a BB-only input file is assumed.
//
//      20-May-1996 Extended to handle HB- and BB-only trees.
//
//      22-May-1996 Done buildind the tree regions,
//                  made sure the relative ordering of
//                  subregions in the tree is same as the
//                  original, and that where the fallthrus
//                  in the input break due to tree formation,
//                  inserted explicit BRUs.
//
/////////////////////////////////////////////////////////////////////////////

#include <iostream.h>
#include <fstream.h>
#include "el_main.h"
#include "iterators.h"
#include "el_tree_formation.h"
#include "edge_utilities.h"
#include "el_control.h"
#include "dbg.h"

// class Flat_tree: temporary flat tree, used
// later to construct the actual tree

inline Flat_tree::Flat_tree ()
{
}

inline Flat_tree::~Flat_tree ()
{
}

inline void Flat_tree::set_root (Region* rootnode)
{
  entry = rootnode;
}

inline void Flat_tree::add_othernode (Region* othernode)
{
  nodelist.add_tail (othernode);
}

inline void Flat_tree::add_leaf (Region* l)
{
  leaflist.add_tail (l);
}

inline void Flat_tree::add_exitedge (Edge* e)
{
  exedgelist.add_tail (e);
}
// ---------------------------------------------------------------------------

// tree region formation algo:

#define VISIT_VECTOR_DEFAULT_SIZE   (32)

// log the visits:
Bitvector visitvec (VISIT_VECTOR_DEFAULT_SIZE, false);

void El_grow_tree (Region* reg, Flat_tree* flattree)
{
  Edge* fallthru_edge = NULL;

  // check the vector overflows:
  while (reg->id () >= visitvec.size ())
    visitvec.resize (2 * visitvec.size());

  // if not already visited
  if (visitvec.bit (reg->id()) == false)
    visitvec.set_bit (reg->id());
  else
    return;

  // keep this node in the flat tree:
  flattree->add_othernode (reg);

  // visit the fallthru edge first:
  bool fallthru_dest_multientry = true;
  for (Region_exit_edges exte0 (reg, ALL_EDGES); exte0 != 0; exte0++) {
    if (fallthru_edge == NULL) {
      if (is_fall_through (*exte0)) {
	// note it down
	fallthru_edge = *exte0;

	// count number of entry edges to the dest
	bool all_dest_entry_edges_from_this_region = true;
	int  dest_entry_edge_count = 0;
	for (Region_entry_edges ente (((*exte0)->dest())->parent(), ALL_EDGES);
	     ente != 0; ente++) {
	  dest_entry_edge_count++;

	  if (((*ente)->src())->parent() != (Compound_region*)reg)
	    all_dest_entry_edges_from_this_region = false;
	}

	if (dbg (tree, 1))
	  cdbg << "\t[ft] dest reg-" << (((*exte0)->dest ())->parent ())->id ()
	    << " has " << dest_entry_edge_count << " entry edges" << endl;

	// is the dest a single-entry-edge region? (can't be 0)
	// or, all entry edges to dest are from this region?
	if ((dest_entry_edge_count == 1)
	    || (all_dest_entry_edges_from_this_region == true)) {
	  fallthru_dest_multientry = false;
	  El_grow_tree (((*exte0)->dest ())->parent (), flattree);
	}
      }
    }
    else
      break;
  }

  // visit the other exit edges next:
  /*
   * (Scott) These have to be visited in order of decreasing frequencies.
   * Will implement the sort-and-scan type control structure later.
   * - Sumedh
   */
  // for all the other exit edges:
  bool other_dest_multientry = true;
  for (Region_exit_edges exte (reg, ALL_EDGES); exte != 0; exte++) {
    // skip the fallthru edge:
    if (fallthru_edge == *exte)
      continue;

    // count number of entry edges to the dest
    bool all_dest_entry_edges_from_this_region = true;
    int  dest_entry_edge_count = 0;
    for (Region_entry_edges ente (((*exte)->dest ())->parent (), ALL_EDGES);
	 ente != 0; ente++) {
      dest_entry_edge_count++;

      if (((*ente)->src())->parent() != (Compound_region*)reg)
	all_dest_entry_edges_from_this_region = false;
    }

    if (dbg (tree, 1))
      cdbg << "\t\tdest reg-" << (((*exte)->dest ())->parent ())->id ()
	<< " has " << dest_entry_edge_count << " entry edges" << endl;

    // is the dest a single-entry-edge region? (can't be 0)
    // or, all entry edges to dest are from this region?
    if ((dest_entry_edge_count == 1)
	|| (all_dest_entry_edges_from_this_region == true)) {
      other_dest_multientry = false;
      El_grow_tree (((*exte)->dest ())->parent (), flattree);
    }
  }

  /*
   * Determine if this is a leaf node:
   * conditions are:
   * 1. When the fallthru dest is multientry
   *    (other destinations may or may not be multientry; in either case,
   *     this node is a leaf only if the fallthru dest is multientry.)
   */
  if (fallthru_dest_multientry == true)
    {
      if (dbg (tree, 1))
	cdbg << "leaf-marking: reg-" << reg->id() << " is a leaf." << endl;

      // keep this also as a leaf in the flat tree:
      flattree->add_leaf (reg);

      // copy the exit edges to the flat tree:
      for (Region_exit_edges exte2 (reg, ALL_EDGES); exte2 != 0; exte2++)
	flattree->add_exitedge (*exte2);

      return;
    }
}

void El_mark_tress (Region* reg, List<Flat_tree*>* ftreelist)
{
  // scan the subregions:
  for (Region_subregions subreg (reg); subreg != 0; subreg++) {
    // check the vector overflows:
    while ((*subreg)->id () >= visitvec.size ())
      visitvec.resize (2 * visitvec.size());

    // has already been visited?
    if (visitvec.bit ((*subreg)->id ()) == true)
      continue;

    // permissible tree member category?
    if ((*subreg)->is_bb() || (*subreg)->is_hb()) { // is_tree will come later
      if (dbg (tree, 1))
	cdbg << "-------" << endl << "bb-" << (*subreg)->id () << endl;

      // check the number of entry edges:
      int entry_edge_count = 0;
      for (Region_entry_edges ente (*subreg, ALL_EDGES); ente != 0; ente++)
	entry_edge_count++;

      // found a tree root?
      if ((entry_edge_count == 0) || (entry_edge_count > 1)) {
	if (dbg (tree, 1))
	  cdbg << "bb-" << (*subreg)->id () << " is a tree root:" << endl;

	// create a new flat tree, add it to the list:
	Flat_tree *newflat = new Flat_tree;
	ftreelist->add_tail (newflat);

	// keep the root node:
	newflat->set_root (*subreg);

	#if NOT_SURE_IF_NEEDED
	// see if there are no exit edges:
	int ex_count = 0;
	for (Region_exit_edges ex (*subreg, ALL_EDGES); ex != 0; ex++)
	  ex_count++;

	// only node in the tree?
	if (ex_count == 0) {
	  newflat->add_othernode (*subreg);
	  continue;
	}
	// grow the tree from this root:
	else
	  for (Region_exit_edges exte (*subreg, ALL_EDGES); exte != 0; exte++)
	    El_grow_tree (*subreg, newflat);
	#endif

	El_grow_tree (*subreg, newflat);
      }
    }
  }
}
// ---------------------------------------------------------------------------

void El_construct_tree_regions (Procedure* reg, List<Flat_tree*>* ftreelist)
{
  Region_entry_edges ente;
  List_iterator<Edge*> eiter;

  for (List_iterator<Flat_tree*> iter (*ftreelist); iter != 0; iter++) {
    Tree *curtree = new Tree;

    /* for all regions that belong to this tree ("entry" and "nodelist"):
     * 1. add it to the tree subregion list (by convention, first node in
     *    the list is the tree root);
     * 2. adjust it's parent-child relationship;
     * 3. disconnect it from the procedure's subregionlist;
     */
    for (List_iterator<Region*> riter ((*iter)->nodelist);
	 riter != 0; riter++) {
      curtree->add_region (*riter);
      (*riter)->set_parent (curtree);
      reg->remove_region (*riter);
    }

    #if THIS_SHOULD_WORK_HENCE_FIXIT_WITH_SCOTTS_HELP
    for (List_iterator<Region*> riter ((*iter)->get_nodelist());
	 riter != 0; riter++) {
      // debugging:
      if (dbg (tree, 0))
	cdbg << "node in the tree...." << endl;
      curtree->add_region (*riter);
    }
    #endif

    /* adjust the entry/exit edges to the tree;
     */
    for (ente ((*iter)->get_entry()); ente != 0; ente++)
      curtree->add_entry_safely (*ente);
    for (eiter ((*iter)->exedgelist); eiter != 0; eiter++)
      curtree->add_exit_safely (*eiter);

    /* adjust the entry/exit ops for the tree:
     */
    for (ente ((*iter)->get_entry()); ente != 0; ente++)
      curtree->add_entry ((*ente)->dest());
    for (eiter ((*iter)->exedgelist); eiter != 0; eiter++)
      curtree->add_exit ((*eiter)->src());

    /* set the weight of the tree:
     */
    curtree->weight = ((Compound_region*)(*iter)->get_entry())->weight;

    /* add the tree to the procedure's subregion list;
     */
    reg->add_region (curtree);
  }
}
// ---------------------------------------------------------------------------

/* this is copied from the El_add_jump_to_region routine in el_control.cpp
 * - only the condition check that is done there for non-existance of
 *   exit edges is removed.
 */
void El_add_jump_at_region_tail (Compound_region* region, Op* dest_op)
{
  Edge *edge;
  Op* pbr_op;
  Op* bru_op;
  Base_operand* regist;
  Base_operand* base_oper;
  Operand* temp_oper;
  Op* last_op;
  Control_flow_freq *cfreq;

  last_op = get_last_region_op_from_subregions(region);

  regist = new Reg(EL_DT_BRANCH, BTR, virtual_register_number);
  temp_oper = new Operand(regist);

  pbr_op = new Op(PBRR);
  region->add_region(pbr_op);
  pbr_op->set_parent(region);

  pbr_op->set_dest(DEST1, *temp_oper);
  base_oper = new Cb_operand(dest_op->parent()->id());
  temp_oper = new Operand(base_oper);
  pbr_op->set_src(SRC1, *temp_oper);
  base_oper = new Int_lit(1);
  temp_oper = new Operand(base_oper);
  pbr_op->set_src(SRC2, *temp_oper);
  base_oper = new Pred_lit(true);
  temp_oper = new Operand(base_oper);
  pbr_op->set_src(PRED1, *temp_oper);

  base_oper = new Reg(EL_DT_BRANCH, BTR, ((Reg*)regist)->vr_num());
  temp_oper = new Operand(base_oper);

  bru_op = new Op(BRU);
  region->add_region(bru_op);
  bru_op->set_parent(region);
  region->add_exit(bru_op);

  bru_op->set_src(SRC1, *temp_oper);
  base_oper = new Pred_lit(true);
  temp_oper = new Operand(base_oper);
  bru_op->set_src(PRED1, *temp_oper);

  C0_connect_fallthrough(last_op, pbr_op);
  C0_connect_fallthrough(pbr_op, bru_op);
  edge = C0_connect(bru_op, dest_op);
  cfreq = new Control_flow_freq();
  cfreq->freq = region->weight;
  set_control_flow_freq(edge, cfreq);

  bru_op->add_outedge_recursively(edge);
  dest_op->add_inedge_recursively(edge);
}

void El_add_new_jumpbb_at_region_tail (Compound_region* region,
					     Op* dest_op)
{
  Edge *edge;
  Op* last_op_from_prev_region;

  /*
   * Create a new BB:
   */
  Basicblock* jump_bb = new Basicblock;
  jump_bb->weight = region->weight;
  jump_bb->set_parent (region->parent());

  Op* jump_bb_merge_op = new Op (C_MERGE);
  jump_bb->add_region (jump_bb_merge_op);
  jump_bb_merge_op->set_parent (jump_bb);
  jump_bb->add_entry (jump_bb_merge_op);

  /*
   * Connect the new BB at the end of the "prev" region:
   */
  last_op_from_prev_region = get_last_region_op_from_subregions (region);
  C0_connect_fallthrough (last_op_from_prev_region, jump_bb_merge_op);
  edge = C0_connect (last_op_from_prev_region, jump_bb_merge_op);
  last_op_from_prev_region->add_outedge_recursively (edge);
  jump_bb_merge_op->add_inedge_recursively (edge);

  region->insert_after_region (jump_bb, region);

  /*
   * Now do the deed of adding the PBRR/BRU to the new jump_bb:
   */
  El_add_jump_at_region_tail (jump_bb, dest_op);
}

void El_tree_fallthrus_to_jumps (Procedure* reg, List<Flat_tree*>* ftreelist)
{
  /* For each leafnode in each tree:
   * - check if it has a fallthru (<==> the fallthru is to a tree),
   * - is yes, convert it to an explicit jump to the tree
   */
  for (List_iterator<Flat_tree*> ft (*ftreelist); ft != 0; ft++) {
    bool single_node_tree = false;
    for (List_iterator<Region*> riter ((*ft)->leaflist); riter != 0; riter++)
    {
      // only node in the tree?
      if (*riter == (*ft)->get_entry())
	single_node_tree = true;

      // count exit edges, keep the fallthru:
      int   exte_count = 0;
      Edge* fallthru_edge = NULL;
      for (Region_exit_edges exte (*riter, ALL_EDGES); exte != 0; exte++) {
	if (is_fall_through (*exte))
	  fallthru_edge = *exte;

	exte_count++;
      }

      // no need to do this?
      if (fallthru_edge == NULL)
	continue;

      // keep the ops:
      Op* fallthru_edge_src_op = fallthru_edge->src();
      Op* fallthru_edge_dest_op = fallthru_edge->dest();

      // delete the edge:
      fallthru_edge_src_op->remove_outedge_recursively (fallthru_edge);
      fallthru_edge_dest_op->remove_inedge_recursively (fallthru_edge);

      /* add the jump at the end of the hyperblock only.
       * if a BB, append a new basic block with the dummy branch,
       * only if there are more than one exit edges from the BB.
       */
      if ((*riter)->is_hb()) {
	if (fallthru_edge_src_op->opcode() == DUMMY_BR)
	  ((Compound_region*)(*riter))->remove_region (fallthru_edge_src_op);

	El_add_jump_at_region_tail ((Compound_region*)(*riter),
				    fallthru_edge_dest_op);
      }
      else if ((*riter)->is_bb()) {
	if (exte_count == 1) {
	  if (fallthru_edge_src_op->opcode() == DUMMY_BR)
	    ((Compound_region*)(*riter))->remove_region (fallthru_edge_src_op);

	  El_add_jump_at_region_tail ((Compound_region*)(*riter),
				      fallthru_edge_dest_op);
	}
	else
	  El_add_new_jumpbb_at_region_tail ((Compound_region*)(*riter),
					    fallthru_edge_dest_op);
      }
      else
	El_punt ("Error: found a non HB/BB region in tree fallthru adjust!");

      // take care of this special case
      if (single_node_tree == true)
	break;
    }
  }
}
// ---------------------------------------------------------------------------
// top-level control routine:

void El_procedure_tree_formation (Procedure* f)
{
  List<Flat_tree*> flattreelist;

  // clear the bit vector:
  visitvec.clear();

  // must be a procedure:
  assert (f->is_procedure () == true);

  // mark roots and grow the tree from the root:
  El_mark_tress (f, &flattreelist);

  // construct the tree regions:
  El_construct_tree_regions (f, &flattreelist);

  // convert fallthrus (between trees) to explicit jumps:
  El_tree_fallthrus_to_jumps (f, &flattreelist);
}
// ---------------------------------------------------------------------------
