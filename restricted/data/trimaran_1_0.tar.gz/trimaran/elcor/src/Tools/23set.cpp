/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1994 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           23set.cpp
//      Authors:        Sadun Anik
//      Created:        December 1994
//      Description:    23-tree based set implementation
//
/////////////////////////////////////////////////////////////////////////////

#include "23set.h"

template<class T>
Node23<T>::Node23() 
   : lowofsecond(0), lowofthird(0),
     child1(0), child2(0), child3(0), leaf_node(false)
{}

template<class T>
Node23<T>::Node23(const Node23<T>& node)
   : element(node.element), 
     lowofsecond(node.lowofsecond), lowofthird(node.lowofthird),
     child1(node.child1), child2(node.child2), child3(node.child3),
     leaf_node(node.leaf_node)
{}

template<class T>
Node23<T>::Node23(const T& x)
   : element(x), lowofsecond(0), lowofthird(0),
     child1(0), child2(0), child3(0), leaf_node(true)
{}

template<class T>
Node23<T>::~Node23() 
{}

template<class T>
void Node23<T>::set_leaf() 
{
   leaf_node = true ;
}

template<class T>
void Node23<T>::reset_leaf() 
{
   leaf_node = false ;
}

template<class T>
bool Node23<T>::is_leaf() const
{
   return leaf_node ;
}

template<class T>
int Node23<T>::children_count() const
{
   if (child3 != 0) return 3 ;
   else if (child2 != 0) return 2 ;
   else if (child1 != 0) return 1 ;
   else return 0 ;
}

////////////////////////////////////////////////////////////////
//
// Tree23 class
//
////////////////////////////////////////////////////////////////

template<class T>
Tree23<T>::Tree23()
{
   root = new Node23<T>() ;
}

template<class T>
Tree23<T>::Tree23(const Tree23<T>& tree)
{
   root = new Node23<T>() ;
   for (Tree23_iterator<T> ti(tree) ; ti != 0 ; ti++) {
      add(*ti) ;
   }
}

template<class T>
Tree23<T>::~Tree23()
{
   delete_subtree(root) ;
}


template<class T>
void Tree23<T>::delete_subtree(Node23<T>*& node)
{
   if (node->child1 != 0) delete_subtree(node->child1) ;
   if (node->child2 != 0) delete_subtree(node->child2) ;
   if (node->child3 != 0) delete_subtree(node->child3) ;
   
   delete node ;
}


template<class T>
bool Tree23<T>::is_in1(const T& item, const Node23<T>* tmproot) const
{
   if (!tmproot) return false ;
   
   if (tmproot->is_leaf()) {
      if (tmproot->element == item) return true ;
      else return false ;
   } else {
      if ((!tmproot->lowofsecond) || (item < *(tmproot->lowofsecond))) {
	 return (is_in1(item, tmproot->child1)) ;
      }
      else if ((!tmproot->lowofthird) || (item < *(tmproot->lowofthird))) {
	 return (is_in1(item, tmproot->child2)) ;
      }
      else {
	 return (is_in1(item, tmproot->child3)) ;
      }
   }
}

template<class T>
bool Tree23<T>::is_in(const T& item) const
{
   return (is_in1(item,root)) ;
}


template<class T>
T* Tree23<T>::locate1(const T& item, Node23<T>* tmproot) 
{
   if (!tmproot) return NULL ;
   
   if (tmproot->is_leaf()) {
      if (tmproot->element == item) return (&(tmproot->element)) ;
      else return NULL ;
   } else {
      if ((!tmproot->lowofsecond) || (item < *(tmproot->lowofsecond))) {
	 return (locate1(item, tmproot->child1)) ;
      }
      else if ((!tmproot->lowofthird) || (item < *(tmproot->lowofthird))) {
	 return (locate1(item, tmproot->child2)) ;
      }
      else {
	 return (locate1(item, tmproot->child3)) ;
      }
   }
}

template<class T>
T* Tree23<T>::locate(const T& item)
{
   return (locate1(item,root)) ;
}


template<class T>
Node23<T>* Tree23<T>::insert1(Node23<T>** node_ptr, const T& x, T*& low)
{
   int child ;
   T* lowback ;
   Node23<T> *pnew = 0, *pback = 0, **w = 0 ,*node = 0;

   node = *node_ptr;

   if (node->is_leaf()) {
      if (!(node->element == x)) {
	 pnew = new Node23<T>(x) ;

	 if (node->element < x) {
	    low = &(pnew->element) ;
	 }
	 else {
	    Node23<T>* tmp = pnew ;
	    pnew = node ;
	    *node_ptr = tmp ;
	    low = &(pnew->element) ;
	 }
      }
   }
   else {
      if (x < *(node->lowofsecond)) {
	 child = 1 ;
	 w = &(node->child1) ;
      }
      else if ((node->child3 == 0) || (x < *(node->lowofthird))) {
	 child = 2 ;
	 w = &(node->child2) ;
      }
      else {
	 child = 3 ;
	 w = &(node->child3) ;
      }
      pback = insert1(w,x,lowback) ;
      if (pback != 0) {
	 if (node->child3 == 0) {
	    if (child == 2) {
	       node->child3 = pback ;
	       node->lowofthird = lowback ;
	    }
	    else {
	       node->child3 = node->child2 ;
	       node->lowofthird = node->lowofsecond ;
	       node->child2 = pback ;
	       node->lowofsecond = lowback ;
	    }
	 }
	 else {
	    pnew = new Node23<T>() ;
	    pnew->leaf_node = 0 ;
	    if (child == 3) {
	       pnew->child1 = node->child3 ;
	       pnew->child2 = pback ;
	       pnew->child3 = 0 ;
	       pnew->lowofsecond = lowback ;
	       low = node->lowofthird ;
	       node->child3 = 0 ;
	    }
	    else {
	       pnew->child2 = node->child3 ;
	       pnew->lowofsecond = node->lowofthird ;
	       pnew->child3 = 0 ;
	       node->child3 = 0 ;
	    }
	    node->lowofthird = 0 ;  // 3-20-95 SA I think this is necessary. 
	    if (child == 2) {
	       pnew->child1 = pback ;
	       low = lowback ;
	    }
	    if (child == 1) {
	       pnew->child1 = node->child2 ;
	       low = node->lowofsecond ;
	       node->child2 = pback ;
	       node->lowofsecond = lowback ;
	    }
	 }
      }
   }
   return (pnew) ;
}

template<class T>
void Tree23<T>::add(const T& item)
{
   if (root->child1 == 0) {
      root->child1 = new Node23<T>(item) ;
      return ;
   }
   else if (root->child2 == 0) {
      if (root->child1->element == item) {
	 return ;
      }
      else {
	 if (root->child1->element < item) {
	    root->child2 = new Node23<T>(item) ;
	    root->lowofsecond = &(root->child2->element) ;
	 }
	 else {
	    root->child2 = root->child1 ;
	    root->lowofsecond = &(root->child2->element) ;
	    root->child1 = new Node23<T>(item) ;
	 }
	 return ;
      }
   }
   else {
      T* lowback = 0;
      Node23<T> *pback = insert1(&root, item, lowback) ;
      if (pback != 0) {
	 Node23<T>* newroot  = new Node23<T>() ;
	 newroot->child1 = root ;
	 newroot->child2 = pback ;
	 newroot->lowofsecond = lowback ;
	 root = newroot ;
      }
   }
}

template<class T>
bool Tree23<T>::delete1(Node23<T>*& node, const T& x,
			int& lowest_changed, T*& lowest)
// returns true if deletion results in a single child node
{
   bool onlyone, returnval ;

   returnval = false ;
   if (node->child1->is_leaf()) {
      int delete_pos = 0 ;
      if (node->child1->element == x) {
	 delete_pos = 1 ;
	 delete node->child1 ;
      }
      else if ((node->child2) && (node->child2->element == x)) {
	 delete_pos = 2 ;
	 delete node->child2 ;
      }
      else if ((node->child3) && (node->child3->element == x)) {
	 delete_pos = 3 ;
	 delete node->child3 ;
      }
      switch(delete_pos) {
       case 1:
	 node->child1 = node->child2 ;
       case 2:
	 node->child2 = node->child3 ;
	 node->lowofsecond = node->lowofthird ;
       case 3:
	 node->child3 = 0 ;
	 node->lowofthird = 0 ;
	 break;
       default:
	 ;
      }
      if (delete_pos == 1) {
	 lowest_changed = 1 ;
	 lowest = &(node->child1->element) ;
      } else {
	 lowest_changed = 0 ;
	 lowest = 0 ;
      }
      if (node->child2 == 0) { // Only one child
	 returnval = true ;
      }
   }
   else {  // node is at level 2 or higher
      Node23<T>* w ;
      int delete_pos = 0 ;
      if (x < *(node->lowofsecond)) {
	 w = node->child1 ;
	 delete_pos = 1 ;
      }
      else if ((node->lowofthird == 0) ||
	       ((node->lowofthird != 0) && (x < *(node->lowofthird)))) {
	 w = node->child2 ;
	 delete_pos = 2 ;
      }
      else {
	 w = node->child3 ;
	 delete_pos = 3 ;
      }
      onlyone = delete1(w,x,lowest_changed,lowest) ;
      // update lowest field if lowest has changed. If this happened
      // on the first child, just propogate it up, otherwise update
      // the proper fields of current node and block upwards propogation
      if (lowest_changed == 1) {
	 if (delete_pos != 1) {
	    if (delete_pos == 2) {
	       node->lowofsecond = lowest ;
	    }
	    else {
	       node->lowofthird = lowest ;
	    }
	    lowest_changed = 0 ;
	    lowest = 0 ;
	 }
	 else {  // Do nothing, the change will propogate up
	 }
      }
      if (onlyone) {
	 if (delete_pos == 1) {
	    if (node->child2->children_count() == 3) {
	       node->child1->child2 = node->child2->child1 ;
	       node->child1->lowofsecond = node->lowofsecond ;
	       node->lowofsecond = node->child2->lowofsecond ;
	       node->child2->child1 = node->child2->child2 ;
	       node->child2->child2 = node->child2->child3 ;
	       node->child2->lowofsecond = node->child2->lowofthird ;
	       node->child2->child3 = 0 ;
	       node->child2->lowofthird = 0 ;
	    }
	    else {   // child2 has one open spot
	       node->child2->child3 = node->child2->child2 ;
	       node->child2->lowofthird = node->child2->lowofsecond ;
	       node->child2->child2 = node->child2->child1 ;
	       node->child2->lowofsecond = node->lowofsecond ;
	       node->child2->child1 = node->child1->child1 ;
	       delete node->child1 ;
	       node->child1 = node->child2 ;
	       node->child2 = node->child3 ;
	       node->child3 = 0 ;
	       node->lowofsecond = node->lowofthird ;
	       node->lowofthird = 0 ;
	       if (node->children_count() == 1) {
		  returnval = true ;
	       }
	    }
	 }
	 else if (delete_pos == 2) {
	    if (node->child1->children_count() == 3) {
	       node->child2->child2 = node->child2->child1 ;
	       node->child2->lowofsecond = node->lowofsecond ;
	       node->child2->child1 = node->child1->child3 ;
	       node->lowofsecond = node->child1->lowofthird ;
	       node->child1->child3 = 0 ;
	       node->child1->lowofthird = 0 ;
	    }
	    else {
	       if ((node->child3 != 0) && (node->child3->children_count() == 3)){
		  node->child2->child2 = node->child3->child1 ;
		  node->child2->lowofsecond = node->lowofthird ;
		  node->lowofthird = node->child3->lowofsecond ;
		  node->child3->child1 = node->child3->child2 ;
		  node->child3->child2 = node->child3->child3 ;
		  node->child3->lowofsecond = node->child3->lowofthird ;
		  node->child3->child3 = 0 ;
		  node->child3->lowofthird = 0 ;
	       } else {
		  node->child1->child3 = node->child2->child1 ;
		  node->child1->lowofthird = node->lowofsecond ;
		  delete node->child2 ;
		  node->child2 = node->child3 ;
		  node->child3 = 0 ;
		  node->lowofsecond = node->lowofthird ;
		  node->lowofthird = 0 ;
		  if (node->children_count() == 1) {
		     returnval = true ;
		  }
	       }
	    }
	 }
	 else if (delete_pos == 3) {
	    if (node->child2->children_count() == 3) {
	       node->child3->child2 = node->child3->child1 ;
	       node->child3->lowofsecond = node->lowofthird ;
	       node->child3->child1 = node->child2->child3 ;
	       node->lowofthird = node->child2->lowofthird ;
	       node->child2->child3 = 0 ;
	       node->child2->lowofthird = 0 ;
	    }
	    else{
	       node->child2->child3 = node->child3->child1 ;
	       node->child2->lowofthird = node->lowofthird ;
	       delete node->child3 ;
	       node->child3 = 0 ;
	       node->lowofthird = 0 ;
	    }
	 }
      }
   }
   return (returnval) ;
}

template<class T>
void Tree23<T>::remove(const T& item) {
   if (root->child1 == 0) return ;
   if (root->child2 == 0) {
      if (root->child1->element == item) {
	 delete root->child1 ;
	 root->child1 = 0 ;
      }
      else { // do nothing
      }
      return ;
   }
   int l_changed = 0;
   T* lowest = 0 ;
   bool onlyone = delete1(root, item, l_changed, lowest) ;
   if (onlyone) {
     if (!root->child1->is_leaf()) {
       Node23<T>*  tmpr = root ;
       root = root->child1 ;
       delete tmpr ;
     }
   }
   return ;
}

template<class T>
bool Tree23<T>::is_empty() const
{
   if (root->child1) return false ;
   else return true ;
}

template<class T>
void Tree23<T>::clear() {
   delete_subtree(root) ;
   root = new Node23<T>() ;
}

////////////////////////////////////////////////////////////////
//
//  Set23 class
//
////////////////////////////////////////////////////////////////

template<class T>
Set23<T>::Set23()
{
   body = new Tree23<T> ;
}

template<class T>
Set23<T>::Set23(const Set23<T>& s)
{
   body = new Tree23<T>(*(s.body)) ;
}

template<class T>
Set23<T>::Set23(const T& s)
{
   body = new Tree23<T> ;
   body->add(s) ;
}

template<class T>
Set23<T>::~Set23()
{
   delete body ;
}

template<class T>
Set23<T>& Set23<T>::operator=(const Set23<T>& s)
{
   if (body != s.body) {
      delete body;
      body = new Tree23<T>(*(s.body)) ;
   }
   return *this ;
}

template<class T>
bool Set23<T>::operator==(const Set23<T>& s) const
{
   Set23<T> tmps = *this ;
   if(tmps.size()!=s.size()) return false; 
   tmps -= s ;
   if(tmps.is_empty()) {
      return true ;
   } else {
      return false;
   }
}

template<class T>
bool Set23<T>::operator!=(const Set23<T>& s) const
{
   if (*this == s) return false ;
   else return true ;
}
  
template<class T>
Set23<T>& Set23<T>::clear()
{
   body->clear() ;
   return (*this) ;
}
 
template<class T>
Set23<T>& Set23<T>::operator+=(const T& item)  //add an item
{
   body->add(item) ;
   return (*this) ;
}

template<class T>
Set23<T>& Set23<T>::operator-=(const T& item)  //remove an item
{
   body->remove(item) ;
   return (*this) ;
}

template<class T>
Set23<T>& Set23<T>::operator+=(const Set23<T>& s)   //union
{
   for (Set23_iterator<T> sit(s) ; sit != 0 ; ++sit) {
      operator+= (*sit) ;
   }
   return (*this) ;
}

template<class T>
Set23<T>& Set23<T>::operator-=(const Set23<T>& s)  //difference
{
   for (Set23_iterator<T> sit(s) ; sit != 0 ; ++sit) {
      operator-=(*sit) ;
   }
   return (*this) ;
}

template<class T>
Set23<T>& Set23<T>::operator*=(const Set23<T>& s)  //intersect
{
   Set23<T> tmpset(*this) ;
   for (Set23_iterator<T> sit(tmpset) ; sit != 0 ; ++sit) {
      if (!s.is_in(*sit)) {
      	operator-=(*sit) ;
      }
   }
   return (*this) ;
}

template<class T>
unsigned Set23<T>::size() const
{
   unsigned count = 0 ;
   for (Set23_iterator<T> sit(*this) ; sit != 0 ; ++sit) {
      count++ ;
   }
   return count ;
}
   
template<class T>
bool Set23<T>::is_empty() const
{
   return (body->is_empty()) ;
}

template<class T>
bool Set23<T>::is_in(const T& item) const
{
   return (body->is_in(item)) ;
}

template<class T>
bool Set23<T>::is_subset(const Set23<T>& s) const
{
   Set23<T> tmps(*this) ;
   tmps += s ;
   return(tmps == *this) ;
}

template<class T>
bool Set23<T>::is_proper_subset(const Set23<T>& s) const
{
   if(size() == s.size()) return(0) ;
   return(is_subset(s)) ;
}

template<class T>
T  Set23<T>::take() // gets an element from the set and removes it
{
   assert(0) ;
   T* dummy=0  ;
   return (*dummy) ;
}

template<class T>
T* Set23<T>::locate(const T& item)
{
   return(body->locate(item)) ;
}

template<class T>
T* Set23<T>::locate_and_add(const T& item)
{
   assert(0) ;
   return (NULL) ;
}



///////////////////////////////////////////////////////////////////////////


template<class T>
Tree23_iterator<T>::Tree23_iterator() 
{
}

template<class T>
Tree23_iterator<T>::Tree23_iterator(const Tree23<T>& t) 
{
   traverse(t.root) ;
   iterator(node_list) ;
}


template<class T>
void Tree23_iterator<T>::operator()(const Tree23<T>& t) 
{
   node_list.clear() ;
   traverse(t.root) ;
   iterator(node_list) ;
}

template<class T>
Tree23_iterator<T>::~Tree23_iterator() 
{
}

template<class T>
bool Tree23_iterator<T>::operator==(const int i) const 
{
   return (iterator==i) ;
}

template<class T>
bool Tree23_iterator<T>::operator!=(const int i) const 
{
   return (iterator!=i) ;
}

template<class T>
void Tree23_iterator<T>::operator++()
{
   iterator++ ;
}


template<class T>
void Tree23_iterator<T>::operator++(int)
{
   iterator++ ;
}

template<class T>
T& Tree23_iterator<T>::operator*()
{
   return ((*iterator)->element) ;
}

// ----- To let the use know that these are not supported. They do assert(0)
template<class T>
Tree23_iterator<T>::Tree23_iterator(const Tree23_iterator<T>& t)
{
   assert(0) ;
}

template<class T>
Tree23_iterator<T>& Tree23_iterator<T>::operator=(const Tree23_iterator<T>& t)
{
   assert(0) ;
   return (*this) ;
}



template<class T>
void Tree23_iterator<T>::traverse(const Node23<T>* node)
{
   if (node->is_leaf()) {
      node_list.add_tail((Node23<T>*)node) ;
   }
   else {
      if (node->child1) traverse(node->child1) ;
      if (node->child2) traverse(node->child2) ;
      if (node->child3) traverse(node->child3) ;
   }
}
      
      
////////////////////////////////////////////////////////////////
//
//  Set23_iterator class
//
////////////////////////////////////////////////////////////////


template<class T>
Set23_iterator<T>::Set23_iterator()
{
}

template<class T>
Set23_iterator<T>::Set23_iterator(const Set23<T>& s)
   : iterator(*(s.body))
{
}

template<class T>
void Set23_iterator<T>::operator()(const Set23<T>& s)
{
   iterator(*(s.body)) ;
}


template<class T>
Set23_iterator<T>::~Set23_iterator()
{
}
      
template<class T>
bool Set23_iterator<T>::operator==(const int i) const
{
   return(iterator == i) ;
}

template<class T>
bool Set23_iterator<T>::operator!=(const int i) const
{
   return(iterator != i) ;
}

template<class T>
void Set23_iterator<T>::operator++()
{
   iterator++ ;
}

template<class T>
void Set23_iterator<T>::operator++(int)
{
   iterator++ ;
}

template<class T>
T& Set23_iterator<T>::operator*()
{
   return(*iterator) ;
}
 
// ----- To let the user know that these are not supported. They do assert(0).
template<class T>
Set23_iterator<T>::Set23_iterator(const Set23_iterator<T>& s)
{
   iterator = s.iterator ;
}

template<class T>
Set23_iterator<T>& Set23_iterator<T>::operator=(const Set23_iterator<T>& s)
{
   iterator = s.iterator ;
   return (*this) ;
}

////////////////////////////////////////////////////////////////
//
//  Set23_filterator class
//
////////////////////////////////////////////////////////////////

template<class T>
Set23_filterator<T>::Set23_filterator() {}

template<class T>
Set23_filterator<T>::Set23_filterator(const Set23<T>& s, const Filter<T>* filter,
				  bool delete_flag)
	:Set23_iterator<T>(s), rep(filter), flag(delete_flag){

  while(!(Set23_iterator<T>::operator==(0) ||
	rep->filter(Set23_iterator<T>::operator*())))
    Set23_iterator<T>::operator++();
}

template<class T>
void Set23_filterator<T>::operator()(const Set23<T>& s, const Filter<T>* filter,
				   bool delete_flag)
{
  rep = filter;
  flag = delete_flag;
  Set23_iterator<T>::operator()(s);
  while(!(Set23_iterator<T>::operator==(0) ||
	rep->filter(Set23_iterator<T>::operator*())))
    Set23_iterator<T>::operator++();
}

template<class T>
Set23_filterator<T>::~Set23_filterator()
{
  if (flag) delete ((Filter<T>*) rep); 
}

template<class T>
void Set23_filterator<T>::operator++() 
{
  do Set23_iterator<T>::operator++();
  while(!(Set23_iterator<T>::operator==(0) ||
	rep->filter(Set23_iterator<T>::operator*())));
  return ;
}

template<class T>
void Set23_filterator<T>::operator++(int) 
{
   do Set23_iterator<T>::operator++();
   while(!(Set23_iterator<T>::operator==(0) ||
	 rep->filter(Set23_iterator<T>::operator*())));
   return ;
}

// Unsupported methods

template<class T>
Set23_filterator<T>::Set23_filterator(const Set23_filterator<T>&)
{
    assert(0); 
}

template<class T>
Set23_filterator<T>& Set23_filterator<T>::operator=(const Set23_filterator<T>&) 
{ 
    assert(0); 
    return *this; 
}
