/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1996 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

///////////////////////////////////////////////////////////////////////////
//									 //
//      File:           local_copy_propagate.cpp                         //
//      Authors:                                                         //
//      Created:        August 1996					 //
//      Description:    Simple Copy propagation for demo		 //
// 									 //
///////////////////////////////////////////////////////////////////////////

#include "local_copy_propagate.h"
#include "reaching_defs_solver.h"
#include "pred_analysis.h"
#include "iterators.h"
#include "opcode_properties.h"
#include "connect.h"
#include "flow_analysis_solver.h"
#include "attributes.h"
#include "dbg.h"
#include "el_opti_dead_code.h"

List<Pair<El_ref,El_ref>* > local_forward_copy_propagation_log ; 

static void do_forward_copy_propagation(Compound_region* region, 
					Reaching_defs_info* rdef);
static void forward_copy_propagate_hb_bb(Compound_region* region,
					 Reaching_defs_info* rdef);
static bool check_and_substitute(Compound_region* region,
				 Reaching_defs_info* rdef,  Op* copy_op,
				 Operand& src, El_ref& src_ref, 
				 Operand& dest, El_ref& use_ref);
static bool substitute_lit(Reaching_defs_info* rdef, Operand& src, 
			   Operand& dest, El_ref& use_ref);
static bool is_copy(Op* op);

static void do_backward_copy_propagation(Compound_region* region, 
					 Reaching_defs_info* rdef);
static void backward_copy_propagate_hb_bb(Compound_region* region,
					  Reaching_defs_info* rdef);


void local_copy_propagation(Compound_region* region)
{
    backward_local_copy_propagation(region);
    forward_local_copy_propagation(region);
    el_opti_eliminate_dead_code(region);
}

// The top level driver will change so that we don't do analysis over and 
// over again for different optimizations.  The copy propagation does update
//  reaching definition info. Also reaching definitions will be run on hb 
// basis once reaching defintions capture live ins/outs.

void forward_local_copy_propagation(Compound_region* region)
{
    if (dbg(opti,1))
	cdbg << " Forward Copy propagation " << endl;

   // Do reaching defs over the entire region (assume procedure)
   create_local_analysis_info_for_all_hbs_bbs(region);
   El_do_reaching_defs (region) ;
   Reaching_defs_info* rdef = get_reaching_defs_info (region) ;

   // Do copy propagation
   do_forward_copy_propagation(region, rdef);

   delete_local_analysis_info_for_all_hbs_bbs(region);
   remove_reaching_defs_info (region) ;
}

// Simple forward copy propgation.
static void do_forward_copy_propagation(Compound_region* region, 
					Reaching_defs_info* rdef)
{
    if (region->is_hb() || region->is_bb()) {
	forward_copy_propagate_hb_bb(region, rdef);
    }
    else {
	for(Region_subregions subs(region); subs != 0; subs++) {
	    do_forward_copy_propagation((Compound_region*)*subs, rdef);
	}
    }
}

static void forward_copy_propagate_hb_bb(Compound_region* region, 
					 Reaching_defs_info* rdef)
{
   // Go over all ops in forward order looking for a copy op 
   for(Region_ops_C0_order ops(region); ops != 0; ops++) {
       Op* an_op = *ops;
       if (is_copy(an_op)) {
	   if (dbg(opti,1))
	       cdbg << "Considering move op: " << an_op->id() << endl;
	   
	   // Get the source operand as well as reference to it
	   Op_explicit_sources srcs(an_op);
	   Operand src_opnd = *srcs;
	   El_ref src_ref = srcs.get_ref();
	   // Get the destination operand as well as reference to it
	   Op_explicit_dests dests(an_op);
	   Operand dest_opnd = *dests;
	   El_ref dest_ref = dests.get_ref();
	   if (dest_opnd.is_reg() || dest_opnd.is_macro_reg()) {
	       List<El_ref> dead_uses;
	       List<El_ref>* uses = rdef->get_du_chain(dest_ref) ;
	       
	       // Integer literal case
	       if (src_opnd.is_int()) {
		   // Now iterate over du chains of the dest operand of copy
		   for (List_iterator<El_ref> use_iter1(*uses); 
			use_iter1 != 0; use_iter1++) {
		       El_ref& an_use = *use_iter1;
		       if (substitute_lit(rdef, src_opnd, dest_opnd, an_use)) {
			   dead_uses.add_head(an_use);
			   if (dbg(opti,1))
			       cdbg << "Propagating: From " << an_op->id()
				    << "  To   " << (an_use.get_op())->id()
				    << endl;
		       }
		   }
	       }

	       // Register case
	       else if (src_opnd.is_reg() || src_opnd.is_macro_reg()) {
		   // Now iterate over du chains of the dest operand of copy
		   for (List_iterator<El_ref> use_iter(*uses); 
			use_iter != 0; use_iter++) {
		       El_ref& an_use = *use_iter;
		       if (check_and_substitute(region, rdef, an_op, src_opnd,
						src_ref, dest_opnd, an_use)){
			   dead_uses.add_head(an_use);
			   if (dbg(opti,1))
			       cdbg << "Propagating: From " << an_op->id()
				    << "  To   " << (an_use.get_op())->id() 
				    << endl;
		       }
		   }
	       }
	       else ; // There is nothing to do
           
           // Remove the old uses from reaching defs info. This is done
	   // separately to allow the list iterator above to work.
	       while(!(dead_uses.is_empty())) {
		   El_ref dead = dead_uses.pop();
		   rdef->remove_use(dead);
	       }
	   }
       }
   }
}


// Check if src of the copy is redefined between copy and use. Currently, we
// don't take predicates into account in doing this. Also, we assume that
// there are no remaps between copy and use.       
static bool check_and_substitute(Compound_region* region,
				 Reaching_defs_info* rdef, Op* copy_op, 
				 Operand& src, El_ref& src_ref, 
				 Operand& dest, El_ref& use_ref)
{
    Op* use_op = use_ref.get_op();
    // Make sure that the use op is in the region and that the 
    // ref is an explicit src
    if (!region_contains_op(region, use_op) || 
	(use_ref.get_ref_type() != EXP_SRC) ||
	(dest != use_ref.get_operand()))  return false; 

    // get the ud chain for the use and check that there is only one def 
    // reaching the use.
    List<El_ref>* defs = rdef->get_ud_chain(use_ref);
    if (defs->size() > 1) return false;

    // Check if it is redefined. Start from the the op after the copy op and 
    // scan until use.

    Region_ops_C0_order ops(region, copy_op);
    ops++;
    while ((ops != 0) && (*ops != use_op)) {
	for(Op_all_dests dests(*ops); dests != 0; dests++) {
	    // Redefinition
	    if (src == *dests) return false;
	}
	ops++;
    }
    // If we didn't reach the use op, then the op is at the back.
    if (ops == 0) return false; 

    // We can do copy propagation.
    Operand new_oprnd(src);
    use_op->set_src(use_ref.get_port_num(), new_oprnd);

    El_ref new_use_ref(use_op, &(use_op->src(use_ref.get_port_num())),
		       use_ref.get_ref_type()) ;
    
    Pair<El_ref,El_ref>* log_entry = new Pair<El_ref,El_ref>(src_ref,new_use_ref) ;
    local_forward_copy_propagation_log.add_tail(log_entry) ;

    

    // Construct reference for the new use and hook it up with defs of the src
    // of the copy op. Old use will be removed by the caller.

// Don't do incremental update of reaching def info for now.
/*
    Operand* oprnd_ptr = &(use_op->src(use_ref.get_port_num()));
    El_ref new_ref(use_op, oprnd_ptr, EXP_SRC);
    List<El_ref>* src_defs = rdef->get_ud_chain(src_ref);
    for (List_iterator<El_ref> di(*src_defs); di != 0; di++) {
	rdef->add_du_ud_links(*di, new_ref);
	if (dbg(opti,1))

	    cdbg << "Adding du-ud: <" 
		 << use_op->id() << "  " << oprnd_ptr->vr_num()
		 << "  To" 
		 << ((*di).get_op())->id() << "  " 
		 <<  ((*di).get_operand()).vr_num()
		 << endl;
    }
    */
    // We are done.
    return true;
}

static bool substitute_lit(Reaching_defs_info* rdef, Operand& src, 
			   Operand& dest, El_ref& use_ref)
{
    // Do only if it is an explicit src and the operands match.
    // For literals, we don't need to check that the op is in region or not, 
    // since literals are never killed. 
    if ((use_ref.get_ref_type() != EXP_SRC) || 
	(dest != use_ref.get_operand()))return false; 

    // get the ud chain for the use and check that there is only one def 
    // reaching the use.
    List<El_ref>* defs = rdef->get_ud_chain(use_ref);
    if (defs->size() > 1) return false;

    Op* use_op = use_ref.get_op();
    Operand new_oprnd(src);
    use_op->set_src(use_ref.get_port_num(), new_oprnd);
    return true;
}

static bool is_copy(Op* op)
{
    Opcode opc = op->opcode();
    return (opc == MOVE ||
	    opc == MOVEF_S ||
	    opc == MOVEF_D
	   );
}


// Simple backward copy propgation. 
void backward_local_copy_propagation(Compound_region* region)
{
    if (dbg(opti,1))
	cdbg << " Backward Copy propagation " << endl;
   // Do reaching defs over the entire region (assume procedure)
   create_local_analysis_info_for_all_hbs_bbs(region);
   El_do_reaching_defs (region) ;
   Reaching_defs_info* rdef = get_reaching_defs_info (region) ;

   // Do copy propagation
   do_backward_copy_propagation(region, rdef);

   delete_local_analysis_info_for_all_hbs_bbs(region);
   remove_reaching_defs_info (region) ;
}




static void do_backward_copy_propagation(Compound_region* region, 
					 Reaching_defs_info* rdef)
{
    if (region->is_hb() || region->is_bb()) {
	backward_copy_propagate_hb_bb(region, rdef);
    }
    else {
	for(Region_subregions subs(region); subs != 0; subs++) {
	    do_backward_copy_propagation((Compound_region*)*subs, rdef);
	}
    }
}

static void backward_copy_propagate_hb_bb(Compound_region* region, 
					  Reaching_defs_info* rdef)
{
   // Go over all ops in reverse order looking for a copy op 
   for(Region_ops_reverse_C0_order ops(region); ops != 0; ops++) {
       Op* copy_op = *ops;
       if (is_copy(copy_op)) { 
	 if (dbg(opti,1))
	   cdbg << "Considering move op: " << copy_op->id() << endl;

	 // We have an op of the form r = move(s)
	 // Get the source operand (s) and reference to it
	   bool ok_to_propagate = true;
	   Op_explicit_sources srcs(copy_op);
	   Operand copy_src = *srcs;
	   El_ref copy_src_ref = srcs.get_ref();
	   // Get the destination operand (r) and refernce to it
	   Op_explicit_dests dests(copy_op);
	   Operand copy_dest = *dests;
	   El_ref copy_dest_ref = dests.get_ref();

           // Check for suitability
	   // 1. Source must be a proper register to do copy propagation. 
           //    Macro registers are't copy propagated. 
	   // 2. For each reaching definition of copy's source (s):
	   //    a. The defining op itself must not be a copy operation.
	   //    b. The definition must be an explicit dest of the op
	   //    c. Copy's source must be the only use of the definition
           //    d. There must be no op defining copy's destination (r)
	   //       between the two ops.
	   if (copy_src.is_reg()) {
	     // Get reaching defs for the copy's source (s)
	     List<El_ref>* copy_src_defs = rdef->get_ud_chain(copy_src_ref);
	     // List of defining ops to help check 2d.
	     List<Op*> def_ops;
	     // Collect all defining ops in order to check for 2d
	     for (List_iterator<El_ref> defs(*copy_src_defs); defs != 0;
		  defs++ ) {
	       Op* a_def_op = (*defs).get_op();
	       def_ops.add_tail(a_def_op);
	     }
	     // Now check 2d by reverse walk over ops starting with the copy op
	     Region_ops_reverse_C0_order ops1(region, copy_op); 
	     ops1++ ;  // Skip the copy op
	     for( ;((ok_to_propagate == true) && (ops1 != 0) &&
		    !def_ops.is_empty()); ops1++) {
	       Op* prev_op = *ops1;
	       // If it is one of the defining ops, then remove from the list
	       if (def_ops.is_member(prev_op)) {
		 def_ops.remove(prev_op);
	       }
	       else {
		 // Go over all destinations of this op
		 for(Op_all_dests prev_op_dests(prev_op); prev_op_dests != 0; 
		     prev_op_dests++) {
		   Operand a_dest = *prev_op_dests;
		   // If it is also writing the same register as the 
		   // destination of copy, then we can't do propagation.
		   if (copy_dest == a_dest) {
		     ok_to_propagate = false;
		     break;
		   }
		 }
	       }
	     }
	     // The list of def_ops must be empty. If not, we have "loop 
	     // carried" reaching def, which this algorithm can't handle.
	     if (def_ops.is_empty()) {
	       // Now check for 2a, 2b and 2c
	       if (ok_to_propagate == true) {
		 for (List_iterator<El_ref> defs1(*copy_src_defs); defs1 != 0;
		      defs1++ ) {
		   El_ref def_ref = *defs1;
		   List<El_ref>* uses_of_def =  rdef->get_du_chain(def_ref);
		   if ((uses_of_def->size() != 1) ||
		       (def_ref.get_ref_type() != EXP_DEST) ||
		       // is_copy(def_ref.get_op()) ||
		       is_pseudo(def_ref.get_op())) {
		     ok_to_propagate = false;
		   }
		 }
	       }
	       // We have checked all the conditions. Now do the propagation 
	       // if possible by iterating over all reaching defs.
	       if (ok_to_propagate == true) {
		 for (List_iterator<El_ref> defs2(*copy_src_defs); defs2 != 0;
		      defs2++ ) {
		   El_ref def_ref = *defs2;
		   Op* def_op = def_ref.get_op();
		   Operand new_oprnd(copy_dest);
		   def_op->set_dest(def_ref.get_port_num(), new_oprnd);
		   if (dbg(opti,1)) {
		     cdbg << "Propagating: From " 
			  <<  copy_op->id()
			  << "  To   " << def_op->id() 
			  << endl;
		   }
		 }
	       // Make copy_op dest to be undefined, so that dead code will 
	       // pick it up. 
	       Operand undefined;
	       copy_op->set_dest(copy_dest_ref.get_port_num(), undefined);
	       }
	     }
	   }
       }
   }
}
