/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1996 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           mdes_reader.cpp
//      Authors:        Shail Aditya
//      Created:        January 1996
//      Description:    LMDES2 customizer(loader) into Elcor
//
//
/////////////////////////////////////////////////////////////////////////////

#include <iostream.h>
#ifndef WIN32
#include <stdiostream.h>
#else // WIN32 defined
#include <stdiostr.h>
#endif // WIN32 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dbg.h"
#include "string_class.h"
#include "hash_map.h"
#include "list.h"
#include "mdes.h"
#define MD_DEBUG_MACROS
#include "md.h"

#define REGMASK(i) (1<<(i))

FILE *MDES_out=stdout;
List<FILE*> MDES_out_stack;

static void build_reg_descr_kind(Reg_descr* reg_desc, MD_Entry* entry);
static int get_latency_time(MD_Entry *entry, MD_Field_Decl *decl, int index);
void process_properties(MD_Entry *opcs_entry, 
			ResClass *resclass, OpClass *opclass, bool *eager);
Alt_descr* make_alt_desc(MDES* mdesc, MD_Entry *alt_entry, Op_descr *opux);

/////////////////////////////////////////////////////////////////////////////
// MD Utilities

/* Assign each entry in a section an index.  
 * This index is used by get_entry_index().  -JCG 5/24/96
 */
static void assign_entry_indexes (MD_Section *section)
{
    MD_Entry *entry;
    MD_Field_Decl *index_field_decl;
    MD_Field *index_field;
    int index;
    
    /* Punt if there is already a field declared */
    if ((index_field_decl = MD_find_field_decl (section, "index")) != NULL)
	El_punt ("assign_entry_indexes: Section '%s' already has index field!",
		section->name);
    
    /* Create required index field with one INT */
    index_field_decl = MD_new_field_decl (section, "index", MD_REQUIRED_FIELD);
    MD_require_int (index_field_decl, 0);
    
    /* Add index to each entry, starting with 0 */
    index = 0;
    for (entry = MD_first_entry (section); entry != NULL;
	 entry = MD_next_entry (entry))
    {
	/* Create index field */
	index_field = MD_new_field (entry, index_field_decl, 1);
	MD_set_int (index_field, 0, index);
	
	index++;
    }
}

/* Get the index for an entry.  If the entry has not been assigned
 * an index already, assign indexes to the whole section. 
 * Used to emulate MD_entry_index(). -JCG 5/24/96
 */
int get_entry_index (MD_Entry *entry)
{
    MD_Field_Decl *index_field_decl;
    MD_Field *index_field;
    int index;

    /* Get the index field decl.  Assign indexes to whole section
     * if this index field is not present.
     */
    index_field_decl = MD_find_field_decl (entry->section, "index");
    if (index_field_decl == NULL)
    {
	/* Create an index for all entries in the entry's section */
	assign_entry_indexes (entry->section);

	/* Get the newly created index field declaration */
	index_field_decl = MD_find_field_decl (entry->section, "index");

	if (index_field_decl == NULL)
	    El_punt ("get_entry_index: assign_entry_indexes didn't work!");
    }
    
    /* Get the index for this entry */
    index_field = MD_find_field (entry, index_field_decl);
    index = MD_get_int (index_field, 0);

    return (index);
}

MD* El_read_md(char* mdfile) 
{
  FILE *mdstream;
  mdstream = fopen(mdfile, "r");
  if (!mdstream)
    El_punt("MD: Can not open LMDES file '%s'", mdfile);
  MD *md = MD_read_md(mdstream, mdfile);
  assert(MD_check_md(stderr, md) == 0);
  fclose(mdstream);
  return md;
}

void push_MDES_out(FILE* file) {
  MDES_out_stack.push(MDES_out);
  MDES_out = file;
}

void pop_MDES_out(void) {
  MDES_out = MDES_out_stack.pop();
}


/////////////////////////////////////////////////////////////////////////////
// MDES Reader

MDES::MDES(char *mdes_input, char *mdes_output, int hashsize) {
  input_file = strdup(mdes_input);
  hashtable = new MdesHashtable(this, hashsize);
  lat_descr_tab = NULL;
  reg_descr_tab = NULL;
  res_descr_tab = NULL;
  res_use_descr_tab = NULL;
  io_descr_tab = NULL;
  ft_descr_tab = NULL;

  // Read in the lmdes description
  MD *md = El_read_md(mdes_input);

  // debugging
  if (dbg(mdes)) {
    push_MDES_out(fopen(mdes_output, "a"));
    fprintf(MDES_out, "****MDES from input file: %s\n", input_file);
  }

  // setup resource table
  build_resource_table(md);

  // setup reservation table
  build_reservation_table(md);

  // setup latency table
  build_latency_table(md);

  // setup register table
  build_register_table(md);

  // setup field type table
  build_ftdescr_table(md);

  // setup io descriptor table
  build_iodescr_table(md);

  // setup ops
  build_opdescr_table(md);

  MD_delete_md(md);

  // debugging
  if (dbg(mdes)) { 
    print();
    fclose(MDES_out);
    pop_MDES_out();
  }
}

void MDES::build_resource_table(MD *md) {
  int i;
  MD_Section *res_section;
  MD_Field_Decl *disp_decl; 
  MD_Field *disp_field=NULL;
  MD_Entry  *res_entry;
  Res_descr *res_desc;
  char* name;

  res_section = MD_find_section(md, "Resource");
  if (res_descr_tab) delete res_descr_tab;
  res_descr_tab = new Vector<Res_descr*>(MD_num_entries(res_section));
  disp_decl = MD_find_field_decl(res_section, "display");

  // BRC July 1, 1996: display decl & field is optional and may not be
  // present.

  // 0 = int, 1 = float, 2 = mem, 3 = branch

  for (i=0, res_entry=MD_first_entry(res_section); 
       res_entry != NULL; i++, res_entry=MD_next_entry(res_entry)) {

    if (disp_decl)
      disp_field = MD_find_field(res_entry, disp_decl);

    res_desc = new Res_descr(this);
    MD_set_entry_ext(res_entry, res_desc);
    name = strdup(res_entry->name);

    if (disp_field)
      res_desc->set(name, MD_get_int(disp_field, 0));
    else
      res_desc->set(name, 1);  // optional, so always display

    (*res_descr_tab)[i] = res_desc;
  }
}

void MDES::build_reservation_table(MD *md) {
  int i, j, k;
  MD_Entry *resv_entry;
  Res_use_descr ruhead(this), *rutail;

  MD_Section* resv_section = MD_find_section(md, "Reservation_Table");
  if (res_use_descr_tab) delete res_use_descr_tab;
  res_use_descr_tab = new Vector<Res_use_descr*>(MD_num_entries(resv_section));
  MD_Field_Decl* decl1 = MD_find_field_decl(resv_section, "use");

  MD_Section* ru_section = MD_find_section(md, "Resource_Usage");
  MD_Field_Decl* decl2 = MD_find_field_decl(ru_section, "use");
  MD_Field_Decl* decl3 = MD_find_field_decl(ru_section, "time");

  // build reservation chains: 1 null + 1/resource
  for (i=0, resv_entry=MD_first_entry(resv_section);
       resv_entry != NULL; i++, resv_entry=MD_next_entry(resv_entry)) {
    rutail = &ruhead;
    // REQUIRED use(LINK(Table_Option|Resource_Unit|Resource_Usage)*);
    MD_Field* rufield = MD_find_field(resv_entry, decl1);
    for (j=0; j < MD_num_elements(rufield); j++) {
      MD_Entry* ru_entry = MD_get_link(rufield, j);
      // REQUIRED use(LINK(Resource));
      int res_index = get_entry_index(MD_get_link(MD_find_field(ru_entry, decl2),0));
      MD_Field* tfield = MD_find_field(ru_entry, decl3);
      for (k=0; k < MD_num_elements(tfield); k++) {
	// REQUIRED time(INT INT*);
	int time = MD_get_int(tfield, k);
	Res_use_descr* res_use_desc = new Res_use_descr(this);
	res_use_desc->set_res_use(res_index, time);
	rutail->set_next(res_use_desc);
	rutail = res_use_desc;
      }
    }
    rutail->set_next(NULL);
    (*res_use_descr_tab)[i] = ruhead.get_next();
    MD_set_entry_ext(resv_entry, ruhead.get_next());
  }
}

void MDES::build_latency_table(MD *md) {
  int i, j, k;
  MD_Section *lat_section;
  MD_Field_Decl *decl0, *decl1, *decl2, *decl3, *decl4, *decl5, *decl6; 
  MD_Entry *entry;
  Lat_descr *lat_desc;
  int lat_time[MDES_latencies_per_class];

  lat_section = MD_find_section(md, "Operation_Latency");
  if (lat_descr_tab) delete lat_descr_tab;
  lat_descr_tab = new Vector<Lat_descr*>(MD_num_entries(lat_section));

  decl0 = MD_find_field_decl(lat_section, "exc");
  decl1 = MD_find_field_decl(lat_section, "rsv");
  decl2 = MD_find_field_decl(lat_section, "pred");
  decl3 = MD_find_field_decl(lat_section, "src");
  decl4 = MD_find_field_decl(lat_section, "dest");
  decl5 = MD_find_field_decl(lat_section, "sync_src");
  decl6 = MD_find_field_decl(lat_section, "sync_dest");

  //di0 is the predicate input and rsv0, do0 are unused
  //exc rsv1 rsv2 rsv3 rsv4 di0 di1 di2 di3 di4 si0 si1 do1 do2 do3 do4 so0 so1

  for (i=0, entry=MD_first_entry(lat_section);
       entry != NULL; i++, entry=MD_next_entry(entry)) {
    lat_desc = new Lat_descr(this); k=0;
    MD_set_entry_ext(entry, lat_desc);
    lat_time[k++] = get_latency_time(entry, decl0, 0);
    for (j=0; j < MDES_maxout-1 ; j++)
      lat_time[k++] = get_latency_time(entry, decl1, j);
    lat_time[k++] = get_latency_time(entry, decl2, 0);
    for (j=0; j < MDES_maxin-1 ; j++)
      lat_time[k++] = get_latency_time(entry, decl3, j);
    for (j=0; j < MDES_maxsynchin ; j++)
      lat_time[k++] = get_latency_time(entry, decl5, j);
    for (j=0; j < MDES_maxout-1 ; j++)
      lat_time[k++] = get_latency_time(entry, decl4, j);
    for (j=0; j < MDES_maxsynchout ; j++)
      lat_time[k++] = get_latency_time(entry, decl6, j);
    lat_desc->set_lat_descr(lat_time);
    (*lat_descr_tab)[i] = lat_desc;
  }
}
    
void MDES::build_register_table(MD *md) {
  int i;
  MD_Entry *entry;
  MD_Field *field;

  MD_Section* regf_section = MD_find_section(md, "Register_File");
  if (reg_descr_tab) delete reg_descr_tab;
  reg_descr_tab = new Vector<Reg_descr*>(MD_num_entries(regf_section));

  MD_Field_Decl* decl1 = MD_find_field_decl(regf_section, "width");
  MD_Field_Decl* decl2 = MD_find_field_decl(regf_section, "static");
  MD_Field_Decl* decl3 = MD_find_field_decl(regf_section, "rotating");
  MD_Field_Decl* decl4 = MD_find_field_decl(regf_section, "speculative");
  MD_Field_Decl* decl5 = MD_find_field_decl(regf_section, "virtual");

  for (i=0, entry=MD_first_entry(regf_section);
       entry != NULL; i++, entry=MD_next_entry(entry)) {
    Reg_descr* reg_desc = new Reg_descr(this);
    MD_set_entry_ext(entry, reg_desc);
    char* name = strdup(entry->name);

    // REQUIRED width(INT);
    int width = MD_get_int(MD_find_field(entry, decl1), 0);
    // OPTIONAL static(LINK(Register)*);
    field = MD_find_field(entry, decl2);
    int scap = (field) ? MD_num_elements(field) : 0;
    // OPTIONAL rotating(LINK(Register)*);
    field = MD_find_field(entry, decl3);
    int rcap = (field) ? MD_num_elements(field) : 0;
    // OPTIONAL speculative(INT);
    field = MD_find_field(entry, decl4);
    bool tag = (field && MD_get_int(field,0)!=0) ? true : false;
    // OPTIONAL virtual(STRING);
    field = MD_find_field(entry, decl5);
    char* vname = (field) ? strdup(MD_get_string(field,0)) : name;
    // OPTIONAL intlist(INT*);         // actual literals
    // OPTIONAL intrange(INT*);        // range in pairs (lower, upper)
    // OPTIONAL doublelist(DOUBLE*);   // actual literals
    build_reg_descr_kind(reg_desc, entry);

    reg_desc->set_reg(vname, name, scap, rcap, width, tag, REGMASK(i));
    (*reg_descr_tab)[i] = reg_desc;
  }
}

void MDES::build_ftdescr_table(MD *md, IO_kind kind) {
  int iocode, i, j;
  MD_Section *ft_section;
  MD_Entry *entry;
  MD_Field_Decl *decl1, *decl2;
  MD_Field *field1, *field2;
  Ft_descr *ftdesc;
  char *name;

  ft_section = MD_find_section(md, "Field_Type");
  if (ft_descr_tab) delete ft_descr_tab;
  ft_descr_tab = new Vector<Ft_descr*>(MD_num_entries(ft_section));

  decl1 = MD_find_field_decl(ft_section, "regfile");
  decl2 = MD_find_field_decl(ft_section, "compatible_with");

  // we do two pass processing. First all base fields are processed
  // and assigned iocodes, then all compound fields are processed.
  // Shail Aditya 06/30/98

  // first pass skips over compound fields
  for (i=0, num_vreg_types=0, entry=MD_first_entry(ft_section);
       entry != NULL; entry=MD_next_entry(entry)) {
    field1 = MD_find_field(entry, decl1);
    field2 = MD_find_field(entry, decl2);
    if (field2) continue;

    num_vreg_types++;
    ftdesc = new Ft_descr(this, kind);
    MD_set_entry_ext(entry, ftdesc);
    name = strdup(entry->name);
    if (field1) {
      // if regfile field is present, setup iocode using it
      // Only one regfile mapping is allowed -- Shail Aditya 06/06/97
      assert(get_MDES_kind()==MDES_PHYSICAL);
      assert(kind==IO_PHYSICAL);
      Reg_descr* desc = (Reg_descr*)MD_get_entry_ext(MD_get_link(field1,0));
      assert(desc);
      iocode = desc->get_iocode();
    } else {
      // assign a new iocode to field type
      assert(get_MDES_kind()==MDES_VIRTUAL);
      assert(kind==IO_VIRTUAL);
      iocode = REGMASK(i);
    }
    ftdesc->set_ft_descr(name, iocode);
    (*ft_descr_tab)[i++] = ftdesc;
  }

  // second pass processes compound fields (IO set)
  for (entry=MD_first_entry(ft_section);
       entry != NULL; entry=MD_next_entry(entry)) {
    field1 = MD_find_field(entry, decl1);
    field2 = MD_find_field(entry, decl2);
    if (!field2) continue;

    ftdesc = new Ft_descr(this, kind);
    MD_set_entry_ext(entry, ftdesc);
    name = strdup(entry->name);
    for (iocode=0, j=0; j < MD_num_elements(field2); j++) {
      Ft_descr* desc = (Ft_descr*)MD_get_entry_ext(MD_get_link(field2,j));
      assert(desc);
      iocode |= desc->get_iocode(); 
      if (kind != desc->get_iokind()) 
	El_punt("MDES: Cannot mix virtual and physical field types.");
    }
    ftdesc->set_ft_descr(name, iocode);
    (*ft_descr_tab)[i++] = ftdesc;
  }
  assert(i==MD_num_entries(ft_section));
}

void MDES::build_iodescr_table(MD *md, IO_kind kind) {
  int iocode, i, j;
  MD_Section *io_section;
  MD_Entry *entry;
  MD_Field_Decl *decl1, *decl2, *decl3;
  MD_Field *field;
  Io_descr *iodesc;

  io_section = MD_find_section(md, "Operation_Format");
  if (io_descr_tab) delete io_descr_tab;
  io_descr_tab = new Vector<Io_descr*>(MD_num_entries(io_section));

  decl1 = MD_find_field_decl(io_section, "pred");
  decl2 = MD_find_field_decl(io_section, "src");
  decl3 = MD_find_field_decl(io_section, "dest");

  for (i=0, entry=MD_first_entry(io_section); 
       entry != NULL; i++, entry=MD_next_entry(entry)) {
    iodesc = new Io_descr(this, kind); 
    MD_set_entry_ext(entry, iodesc);

    field = MD_find_field(entry, decl1);
    if (field && MD_num_elements(field) != 0) {
      if (MD_num_elements(field)!=1) 
	El_warn("MDES: only one predicate field is allowed, rest will be ignored.");
      Ft_descr* ftdesc = (Ft_descr*)MD_get_entry_ext(MD_get_link(field,0));
      assert(ftdesc && ftdesc->get_iokind()==kind);
      iocode = ftdesc->get_iocode();
      iodesc->set_pred(iocode);
    }

    field = MD_find_field(entry,decl2);
    iodesc->set_numin(field ? MD_num_elements(field) : 0);
    for (j=0 ; j < MD_num_elements(field); j++) {
      Ft_descr* ftdesc = (Ft_descr*)MD_get_entry_ext(MD_get_link(field,j));
      assert(ftdesc && ftdesc->get_iokind()==kind);
      iocode = ftdesc->get_iocode();
      iodesc->set_in_reg(j, iocode);
    }

    field = MD_find_field(entry,decl3);
    iodesc->set_numout(field ? MD_num_elements(field) : 0);
    for (j=0 ; j < MD_num_elements(field); j++) {
      Ft_descr* ftdesc = (Ft_descr*)MD_get_entry_ext(MD_get_link(field,j));
      assert(ftdesc && ftdesc->get_iokind()==kind);
      iocode = ftdesc->get_iocode();
      iodesc->set_out_reg(j, iocode);
    }

    (*io_descr_tab)[i] = iodesc;
  }
}

void MDES::build_opdescr_table(MD *md) {
  int i, j, k, m;
  MD_Entry *opcs_entry, *opux_entry, *alt_entry, *io_entry;
  MD_Field *opfield, *altfield, *formatfield;
  int numin, numout, cspriority, uxpriority;
  ResClass resclass;
  OpClass opclass;
  bool eager, is_predicated;

  MD_Section* elop_section = MD_find_section(md, "Elcor_Operation");
  MD_Field_Decl* decl1 = MD_find_field_decl(elop_section, "op");

  MD_Section* op_section = MD_find_section(md, "Operation");
  MD_Field_Decl* decl2 = MD_find_field_decl(op_section, "alt");

  MD_Section* alt_section = MD_find_section(md, "Scheduling_Alternative");
  MD_Field_Decl* decl3 = MD_find_field_decl(alt_section, "format");

  // Make (generic) compiler ops
  for (i=0, opcs_entry=MD_first_entry(elop_section);
       opcs_entry != NULL; i++, opcs_entry=MD_next_entry(opcs_entry)) {
    Op_descr* opcs = new Op_descr(this);
    MD_set_entry_ext(opcs_entry, opcs);
    char* lname = strdup(opcs_entry->name);
    // install cop on generic name
    hashtable->insert_op(lname, opcs);

    // fill cop properties
    process_properties(opcs_entry, &resclass, &opclass, &eager);
    // We assume all alternatives have same io format structure (arity, predication)
    opux_entry = MD_get_link(MD_find_field(opcs_entry, decl1), 0);
    alt_entry = MD_get_link(MD_find_field(opux_entry, decl2), 0);
    io_entry = MD_get_link(MD_find_field(alt_entry, decl3), 0);
    Io_descr *iodesc = (Io_descr*)MD_get_entry_ext(io_entry);
    assert(iodesc);

    numin = iodesc->get_num_in();
    numout = iodesc->get_num_out();
    is_predicated = iodesc->is_predicated();
    cspriority = 0;
    opcs->fill_op(lname, lname, NULL, CLSTROP, numin,
		  is_predicated, numout, opclass, resclass, eager, cspriority);

    // Make (unit) architectural ops
    opfield = MD_find_field(opcs_entry, decl1);
    for (j=0; j < MD_num_elements(opfield); j++) {
      opux_entry = MD_get_link(opfield, j);
      Op_descr* opux = new Op_descr(this);
      MD_set_entry_ext(opux_entry, opux);
      char* aname = strdup(opux_entry->name);
      // install aop on arch name
      hashtable->insert_op(aname, opux);

      // fill aop properties. The execution priority of the opcode
      // reflects the hardware priority of the execution unit on which
      // this opcode executes. We use a combination of the resource
      // class of the opcode and the order of appearance of the
      // alternatives as the priority. -- Shail Aditya 02/26/98

      uxpriority = resclass * get_MDES_num_resources() + j;
      opux->fill_op(lname, aname, NULL, UNITOP, numin, 
		    is_predicated, numout, opclass, resclass, eager, uxpriority);

      // make scheduling alternatives
      altfield = MD_find_field(opux_entry, decl2);
      for (k=0; k < MD_num_elements(altfield); k++) {
	alt_entry = MD_get_link(altfield, k);
	Alt_descr *altdesc = make_alt_desc(this, alt_entry, opux);
	Alt_list altlist(altdesc);
	
	// install this alt on all io formats
	formatfield = MD_find_field(alt_entry, decl3);
	for (m=0; m < MD_num_elements(formatfield); m++) {
	  io_entry = MD_get_link(formatfield, m);
	  iodesc = (Io_descr*)MD_get_entry_ext(io_entry);
	  assert(iodesc && numin==iodesc->get_num_in() && 
		 numout==iodesc->get_num_out() &&
		 is_predicated==iodesc->is_predicated());
	  opux->add_alts(iodesc, altlist.copy());
	  opcs->add_alts(iodesc, altlist.copy());
	}
      }
    }
  }
}

void MDES::check_mdes() {}

/////////////////////////////////////////////////////////////////////////////
// Support functions

static void build_reg_descr_kind(Reg_descr* reg_desc, MD_Entry* entry) {
  int j;
  MD_Field* field;

  MD_Section* regf_section = entry->section;
  MD_Field_Decl* decl5 = MD_find_field_decl(regf_section, "intlist");
  MD_Field_Decl* decl6 = MD_find_field_decl(regf_section, "intrange");
  MD_Field_Decl* decl7 = MD_find_field_decl(regf_section, "doublelist");

  MD_Field* field5 = MD_find_field(entry, decl5);
  MD_Field* field6 = MD_find_field(entry, decl6);
  MD_Field* field7 = MD_find_field(entry, decl7);
  if ((field5 && field6) || (field6 && field7) || (field7 && field5))
    El_punt("MDES: only ONE of 'intlist', 'intrange', or 'doublelist' should be specified.");
  field = (field5) ? field5 : field6;
  if (field) {
    Vector<int>* vect = new Vector<int>(MD_num_elements(field));
    for (j=0; j<MD_num_elements(field); j++) (*vect)[j] = MD_get_int(field, j);
    reg_desc->set_regkind((field5) ? REG_LITINT : REG_LITINTRANGE);
    reg_desc->set_ilits(vect);
  }
  field = field7;
  if (field) {
    Vector<double>* vect = new Vector<double>(MD_num_elements(field));
    for (j=0; j<MD_num_elements(field); j++) (*vect)[j] = MD_get_double(field, j);
    reg_desc->set_regkind(REG_LITDOUBLE);
    reg_desc->set_dlits(vect);
  }

  // special case for unresolved literal and undefined reg files 
  // -- Shail Aditya 06/27/97
  if (strcmp(entry->name, "L")==0 || strcmp(entry->name, "U")==0)
    reg_desc->set_regkind(REG_UNDEFINED);
}

static int get_latency_time(MD_Entry *entry, MD_Field_Decl *decl, int index) {
  MD *md = entry->section->md;
  MD_Field_Decl *time_decl;
  MD_Entry *time_entry;

  time_decl = MD_find_field_decl(MD_find_section(md, "Operand_Latency"), "time");
  time_entry = MD_get_link(MD_find_field(entry, decl), index);
  return (MD_get_int(MD_find_field(time_entry, time_decl), 0));
}

Alt_descr* make_alt_desc(MDES* mdesc, MD_Entry *alt_entry, Op_descr *opux) {
  MD_Field_Decl *decl1, *decl2;
  MD_Field *latfield, *resvfield;
  Alt_descr *altdesc;
  Res_use_descr *resuse;
  Lat_descr *lat;

  decl1 = MD_find_field_decl(alt_entry->section, "latency");
  decl2 = MD_find_field_decl(alt_entry->section, "resv");

  latfield = MD_find_field(alt_entry, decl1);
  lat = (Lat_descr*)MD_get_entry_ext(MD_get_link(latfield,0));
  assert(lat);
  resvfield = MD_find_field(alt_entry, decl2);
  resuse = (Res_use_descr*)MD_get_entry_ext(MD_get_link(resvfield,0));

  altdesc = new Alt_descr(mdesc, opux, lat, resuse);
  return(altdesc);
}

void process_properties(MD_Entry *opcs_entry, 
			ResClass *resclass, OpClass *opclass, bool *eager) {
  // process flags
  MD *md = opcs_entry->section->md;
  MD_Section *flag_section = MD_find_section(md, "Elcor_Operation_Flag");
  int opbase = get_entry_index(MD_find_entry(flag_section, "NULLOP"));
  int resbase = get_entry_index(MD_find_entry(flag_section, "NULL"));
  int eagerbase = get_entry_index(MD_find_entry(flag_section, "NONSPECULATIVE"));
				   
  // flag1 = opclass, flag2 = resclass, flag3 = eager (if present)
  MD_Field_Decl *flagdecl = MD_find_field_decl(opcs_entry->section, "flags");
  MD_Field *flagfield = MD_find_field(opcs_entry, flagdecl);
  assert(MD_num_elements(flagfield) >= 2);
  *opclass = (OpClass)(get_entry_index(MD_get_link(flagfield, 0)) - opbase);
  *resclass = (ResClass)(get_entry_index(MD_get_link(flagfield, 1)) - resbase);
  *eager = (bool)(get_entry_index(MD_get_link(flagfield, 2)) - eagerbase);
}

