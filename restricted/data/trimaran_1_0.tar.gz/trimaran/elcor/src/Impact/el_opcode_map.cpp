/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1995 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           el_opcode_map.cpp                                     
// 	Author:         Scott A. Mahlke                                       
//      Created:        May 1995                                              
//      Description:    This file contains 2 maps used for translating        
//                      back and forth between Lcode and Elcor IRs.           
//                      a) map Elcor opcodes to corresponding opcodes in Lcode
//	                b) map Lcode opcodes to Elcor opcodes
//
/////////////////////////////////////////////////////////////////////////////

#include "el_main.h"
#include "opcode_load_store.h"
#include "hash_functions.h"

Hash_map<int,Opcode> el_lcode_to_elcor_opcode_map(hash_int, 400);
Hash_map<Opcode,int> el_elcor_to_lcode_opcode_map(hash_opcode, 400);

void el_init_lcode_opcode_maps()
{

//
//	Standard INT Arithmetic operations
//

   el_lcode_to_elcor_opcode_map.bind(Lop_NO_OP,NO_OP) ;
   el_elcor_to_lcode_opcode_map.bind(NO_OP,Lop_NO_OP) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_M_NO_OP,M_NO_OP) ;
   el_elcor_to_lcode_opcode_map.bind(M_NO_OP,PLAYDOHop_M_NO_OP) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_ABS,ABS_W) ;
   el_elcor_to_lcode_opcode_map.bind(ABS_W,Lop_ABS) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_ADD,ADD_W) ;
   el_elcor_to_lcode_opcode_map.bind(ADD_W,Lop_ADD) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_ADD_U,ADDL_W) ;
   el_elcor_to_lcode_opcode_map.bind(ADDL_W,Lop_ADD_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_AND,AND_W) ;
   el_elcor_to_lcode_opcode_map.bind(AND_W,Lop_AND) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_AND_COMPL,ANDCM_W) ;
   el_elcor_to_lcode_opcode_map.bind(ANDCM_W,Lop_AND_COMPL) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_DIV,DIV_W) ;
   el_elcor_to_lcode_opcode_map.bind(DIV_W,Lop_DIV) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_DIV_U,DIVL_W) ;
   el_elcor_to_lcode_opcode_map.bind(DIVL_W,Lop_DIV_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL,MPY_W) ;
   el_elcor_to_lcode_opcode_map.bind(MPY_W,Lop_MUL) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL_U,MPYL_W) ;
   el_elcor_to_lcode_opcode_map.bind(MPYL_W,Lop_MUL_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_NAND,NAND_W) ;
   el_elcor_to_lcode_opcode_map.bind(NAND_W,Lop_NAND) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_NOR,NOR_W) ;
   el_elcor_to_lcode_opcode_map.bind(NOR_W,Lop_NOR) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_OR,OR_W) ;
   el_elcor_to_lcode_opcode_map.bind(OR_W,Lop_OR) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_OR_COMPL,ORCM_W) ;
   el_elcor_to_lcode_opcode_map.bind(ORCM_W,Lop_OR_COMPL) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_REM,REM_W) ;
   el_elcor_to_lcode_opcode_map.bind(REM_W,Lop_REM) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_REM_U,REML_W) ;
   el_elcor_to_lcode_opcode_map.bind(REML_W,Lop_REM_U) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SH1ADDL,SH1ADDL_W) ;
   el_elcor_to_lcode_opcode_map.bind(SH1ADDL_W,PLAYDOHop_SH1ADDL) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SH2ADDL,SH2ADDL_W) ;
   el_elcor_to_lcode_opcode_map.bind(SH2ADDL_W,PLAYDOHop_SH2ADDL) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SH3ADDL,SH3ADDL_W) ;
   el_elcor_to_lcode_opcode_map.bind(SH3ADDL_W,PLAYDOHop_SH3ADDL) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LSL,SHL_W) ;
   el_elcor_to_lcode_opcode_map.bind(SHL_W,Lop_LSL) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LSR,SHR_W) ;
   el_elcor_to_lcode_opcode_map.bind(SHR_W,Lop_LSR) ;
   // SHLA has no equivalent in Lcode, all left shifts are logical there
   el_elcor_to_lcode_opcode_map.bind(SHLA_W,Lop_LSL);
   el_lcode_to_elcor_opcode_map.bind(Lop_ASR,SHRA_W) ;
   el_elcor_to_lcode_opcode_map.bind(SHRA_W,Lop_ASR) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_SUB,SUB_W) ;
   el_elcor_to_lcode_opcode_map.bind(SUB_W,Lop_SUB) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_SUB_U,SUBL_W) ;
   el_elcor_to_lcode_opcode_map.bind(SUBL_W,Lop_SUB_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_XOR,XOR_W) ;
   el_elcor_to_lcode_opcode_map.bind(XOR_W,Lop_XOR) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_NXOR,XORCM_W) ;	/* functionally equiv */
   el_elcor_to_lcode_opcode_map.bind(XORCM_W,Lop_NXOR) ;	/* functionally equiv */

//
//	Standard FP Arithmetic operations
//

   el_lcode_to_elcor_opcode_map.bind(Lop_ADD_F,FADD_S) ;
   el_elcor_to_lcode_opcode_map.bind(FADD_S,Lop_ADD_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_ADD_F2,FADD_D) ;
   el_elcor_to_lcode_opcode_map.bind(FADD_D,Lop_ADD_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_ABS_F,FABS_S) ;
   el_elcor_to_lcode_opcode_map.bind(FABS_S,Lop_ABS_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_ABS_F2,FABS_D) ;
   el_elcor_to_lcode_opcode_map.bind(FABS_D,Lop_ABS_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_DIV_F,FDIV_S) ;
   el_elcor_to_lcode_opcode_map.bind(FDIV_S,Lop_DIV_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_DIV_F2,FDIV_D) ;
   el_elcor_to_lcode_opcode_map.bind(FDIV_D,Lop_DIV_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MAX_F,FMAX_S) ;
   el_elcor_to_lcode_opcode_map.bind(FMAX_S,Lop_MAX_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MAX_F2,FMAX_D) ;
   el_elcor_to_lcode_opcode_map.bind(FMAX_D,Lop_MAX_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MIN_F,FMIN_S) ;
   el_elcor_to_lcode_opcode_map.bind(FMIN_S,Lop_MIN_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MIN_F2,FMIN_D) ;
   el_elcor_to_lcode_opcode_map.bind(FMIN_D,Lop_MIN_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL_F,FMPY_S) ;
   el_elcor_to_lcode_opcode_map.bind(FMPY_S,Lop_MUL_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL_F2,FMPY_D) ;
   el_elcor_to_lcode_opcode_map.bind(FMPY_D,Lop_MUL_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL_ADD_F,FMPYADD_S) ;
   el_elcor_to_lcode_opcode_map.bind(FMPYADD_S,Lop_MUL_ADD_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL_ADD_F2,FMPYADD_D) ;
   el_elcor_to_lcode_opcode_map.bind(FMPYADD_D,Lop_MUL_ADD_F2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FMPYADDN_S,FMPYADDN_S) ;
   el_elcor_to_lcode_opcode_map.bind(FMPYADDN_S,PLAYDOHop_FMPYADDN_S) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FMPYADDN_D,FMPYADDN_D) ;
   el_elcor_to_lcode_opcode_map.bind(FMPYADDN_D,PLAYDOHop_FMPYADDN_D) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL_SUB_REV_F,FMPYRSUB_S) ;
   el_elcor_to_lcode_opcode_map.bind(FMPYRSUB_S,Lop_MUL_SUB_REV_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL_SUB_REV_F2,FMPYRSUB_D) ;
   el_elcor_to_lcode_opcode_map.bind(FMPYRSUB_D,Lop_MUL_SUB_REV_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL_SUB_F,FMPYSUB_S) ;
   el_elcor_to_lcode_opcode_map.bind(FMPYSUB_S,Lop_MUL_SUB_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MUL_SUB_F2,FMPYSUB_D) ;
   el_elcor_to_lcode_opcode_map.bind(FMPYSUB_D,Lop_MUL_SUB_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_RCP_F,FRCP_S) ;
   el_elcor_to_lcode_opcode_map.bind(FRCP_S,Lop_RCP_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_RCP_F2,FRCP_D) ;
   el_elcor_to_lcode_opcode_map.bind(FRCP_D,Lop_RCP_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_SQRT_F,FSQRT_S) ;
   el_elcor_to_lcode_opcode_map.bind(FSQRT_S,Lop_SQRT_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_SQRT_F2,FSQRT_D) ;
   el_elcor_to_lcode_opcode_map.bind(FSQRT_D,Lop_SQRT_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_SUB_F,FSUB_S) ;
   el_elcor_to_lcode_opcode_map.bind(FSUB_S,Lop_SUB_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_SUB_F2,FSUB_D) ;
   el_elcor_to_lcode_opcode_map.bind(FSUB_D,Lop_SUB_F2) ;

//
//	Conversion operations
//    

   el_lcode_to_elcor_opcode_map.bind(Lop_F2_I,CONVDW) ;
   el_elcor_to_lcode_opcode_map.bind(CONVDW,Lop_F2_I) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_I_F2,CONVWD) ;
   el_elcor_to_lcode_opcode_map.bind(CONVWD,Lop_I_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_F_I,CONVSW) ;
   el_elcor_to_lcode_opcode_map.bind(CONVSW,Lop_F_I) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_I_F,CONVWS) ;
   el_elcor_to_lcode_opcode_map.bind(CONVWS,Lop_I_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_F2_F,CONVDS) ;
   el_elcor_to_lcode_opcode_map.bind(CONVDS,Lop_F2_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_F_F2,CONVSD) ;
   el_elcor_to_lcode_opcode_map.bind(CONVSD,Lop_F_F2) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_EXTRSB,EXTS_B) ;
   el_elcor_to_lcode_opcode_map.bind(EXTS_B,PLAYDOHop_EXTRSB) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_EXTRSH,EXTS_H) ;
   el_elcor_to_lcode_opcode_map.bind(EXTS_H,PLAYDOHop_EXTRSH) ;

//
//	Move operations
//    

   el_lcode_to_elcor_opcode_map.bind(Lop_MOV,MOVE) ;
   el_elcor_to_lcode_opcode_map.bind(MOVE,Lop_MOV) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEGF_L,MOVEGF_L) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEGF_L,PLAYDOHop_MOVEGF_L) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEGF_U,MOVEGF_U) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEGF_U,PLAYDOHop_MOVEGF_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MOV_F,MOVEF_S) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEF_S,Lop_MOV_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_MOV_F2,MOVEF_D) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEF_D,Lop_MOV_F2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEFG_L,MOVEFG_L) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEFG_L,PLAYDOHop_MOVEFG_L) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEFG_U,MOVEFG_U) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEFG_U,PLAYDOHop_MOVEFG_U) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEPG,MOVEPG) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEPG,PLAYDOHop_MOVEPG) ;
   // LDCM has no current mapping to Lcode.

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEGC,MOVEGC) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEGC,PLAYDOHop_MOVEGC) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVECG,MOVECG) ;
   el_elcor_to_lcode_opcode_map.bind(MOVECG,PLAYDOHop_MOVECG) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEGG,MOVEGG) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEGG,PLAYDOHop_MOVEGG) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEBB,MOVEBB) ;
   el_elcor_to_lcode_opcode_map.bind(MOVEBB,PLAYDOHop_MOVEBB) ;


//
//	Compare to register operations
//    

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_CMPR_FALSE,CMPR_W_FALSE) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_FALSE,PLAYDOHop_CMPR_FALSE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_EQ,CMPR_W_EQ) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_EQ,Lop_EQ) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LT,CMPR_W_LT) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_LT,Lop_LT) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LE,CMPR_W_LEQ) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_LEQ,Lop_LE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_GT,CMPR_W_GT) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_GT,Lop_GT) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_GE,CMPR_W_GEQ) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_GEQ,Lop_GE) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_CMPR_SV,CMPR_W_SV) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_SV,PLAYDOHop_CMPR_SV) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_CMPR_OD,CMPR_W_OD) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_OD,PLAYDOHop_CMPR_OD) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_NE,CMPR_W_NEQ) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_NEQ,Lop_NE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LT_U,CMPR_W_LLT) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_LLT,Lop_LT_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LE_U,CMPR_W_LLEQ) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_LLEQ,Lop_LE_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_GT_U,CMPR_W_LGT) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_LGT,Lop_GT_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_GE_U,CMPR_W_LGEQ) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_LGEQ,Lop_GE_U) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_CMPR_NSV,CMPR_W_NSV) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_NSV,PLAYDOHop_CMPR_NSV) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_CMPR_EV,CMPR_W_EV) ;
   el_elcor_to_lcode_opcode_map.bind(CMPR_W_EV,PLAYDOHop_CMPR_EV) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FCMPR_S_FALSE,FCMPR_S_FALSE) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_S_FALSE,PLAYDOHop_FCMPR_S_FALSE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_EQ_F,FCMPR_S_EQ) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_S_EQ,Lop_EQ_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LT_F,FCMPR_S_LT) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_S_LT,Lop_LT_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LE_F,FCMPR_S_LEQ) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_S_LEQ,Lop_LE_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_GT_F,FCMPR_S_GT) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_S_GT,Lop_GT_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_GE_F,FCMPR_S_GEQ) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_S_GEQ,Lop_GE_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_NE_F,FCMPR_S_NEQ) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_S_NEQ,Lop_NE_F) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FCMPR_S_TRUE,FCMPR_S_TRUE) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_S_TRUE,PLAYDOHop_FCMPR_S_TRUE) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FCMPR_D_FALSE,FCMPR_D_FALSE) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_D_FALSE,PLAYDOHop_FCMPR_D_FALSE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_EQ_F2,FCMPR_D_EQ) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_D_EQ,Lop_EQ_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LT_F2,FCMPR_D_LT) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_D_LT,Lop_LT_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_LE_F2,FCMPR_D_LEQ) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_D_LEQ,Lop_LE_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_GT_F2,FCMPR_D_GT) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_D_GT,Lop_GT_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_GE_F2,FCMPR_D_GEQ) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_D_GEQ,Lop_GE_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_NE_F2,FCMPR_D_NEQ) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_D_NEQ,Lop_NE_F2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FCMPR_D_TRUE,FCMPR_D_TRUE) ;
   el_elcor_to_lcode_opcode_map.bind(FCMPR_D_TRUE,PLAYDOHop_FCMPR_D_TRUE) ;

//
//	Compare to predicate operations (Note here only map to base
//		CMPP, dest modifiers are added later).
//    

   // BASE_CMPP_FALSE has no current mapping to Lcode.
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_EQ,(Opcode)BASE_CMPP_W_EQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_EQ,Lop_PRED_EQ) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_LT,(Opcode)BASE_CMPP_W_LT) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_LT,Lop_PRED_LT) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_LE,(Opcode)BASE_CMPP_W_LEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_LEQ,Lop_PRED_LE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_GT,(Opcode)BASE_CMPP_W_GT) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_GT,Lop_PRED_GT) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_GE,(Opcode)BASE_CMPP_W_GEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_GEQ,Lop_PRED_GE) ;
   // BASE_CMPP_SV has no current mapping to Lcode.
   // BASE_CMPP_OD has no current mapping to Lcode.
   // BASE_CMPP_TRUE has no current mapping to Lcode.
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_NE,(Opcode)BASE_CMPP_W_NEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_NEQ,Lop_PRED_NE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_LT_U,(Opcode)BASE_CMPP_W_LLT) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_LLT,Lop_PRED_LT_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_LE_U,(Opcode)BASE_CMPP_W_LLEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_LLEQ,Lop_PRED_LE_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_GT_U,(Opcode)BASE_CMPP_W_LGT) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_LGT,Lop_PRED_GT_U) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_GE_U,(Opcode)BASE_CMPP_W_LGEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_CMPP_W_LGEQ,Lop_PRED_GE_U) ;
   // BASE_CMPP_NSV has no current mapping to Lcode.
   // BASE_CMPP_EV has no current mapping to Lcode.

   // BASE_FCMPP_S_FALSE has no current mapping to Lcode.
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_EQ_F,(Opcode)BASE_FCMPP_S_EQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_S_EQ,Lop_PRED_EQ_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_LT_F,(Opcode)BASE_FCMPP_S_LT) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_S_LT,Lop_PRED_LT_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_LE_F,(Opcode)BASE_FCMPP_S_LEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_S_LEQ,Lop_PRED_LE_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_GT_F,(Opcode)BASE_FCMPP_S_GT) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_S_GT,Lop_PRED_GT_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_GE_F,(Opcode)BASE_FCMPP_S_GEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_S_GEQ,Lop_PRED_GE_F) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_NE_F,(Opcode)BASE_FCMPP_S_NEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_S_NEQ,Lop_PRED_NE_F) ;
   // BASE_FCMPP_S_TRUE has no current mapping to Lcode.

   // BASE_FCMPP_D_FALSE has no current mapping to Lcode.
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_EQ_F2,(Opcode)BASE_FCMPP_D_EQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_D_EQ,Lop_PRED_EQ_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_LT_F2,(Opcode)BASE_FCMPP_D_LT) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_D_LT,Lop_PRED_LT_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_LE_F2,(Opcode)BASE_FCMPP_D_LEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_D_LEQ,Lop_PRED_LE_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_GT_F2,(Opcode)BASE_FCMPP_D_GT) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_D_GT,Lop_PRED_GT_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_GE_F2,(Opcode)BASE_FCMPP_D_GEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_D_GEQ,Lop_PRED_GE_F2) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_NE_F2,(Opcode)BASE_FCMPP_D_NEQ) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BASE_FCMPP_D_NEQ,Lop_PRED_NE_F2) ;
   // BASE_FCMPP_D_TRUE has no current mapping to Lcode.


//
//	Standard GPR load operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_V1_V1, (Opcode)L_B_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_V1_V1,PLAYDOHop_L_B_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_V1_C1, (Opcode)L_B_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_V1_C1,PLAYDOHop_L_B_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_V1_C2, (Opcode)L_B_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_V1_C2,PLAYDOHop_L_B_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_V1_C3, (Opcode)L_B_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_V1_C3,PLAYDOHop_L_B_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C1_V1, (Opcode)L_B_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C1_V1,PLAYDOHop_L_B_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C1_C1, (Opcode)L_B_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C1_C1,PLAYDOHop_L_B_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C1_C2, (Opcode)L_B_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C1_C2,PLAYDOHop_L_B_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C1_C3, (Opcode)L_B_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C1_C3,PLAYDOHop_L_B_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C2_V1, (Opcode)L_B_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C2_V1,PLAYDOHop_L_B_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C2_C1, (Opcode)L_B_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C2_C1,PLAYDOHop_L_B_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C2_C2, (Opcode)L_B_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C2_C2,PLAYDOHop_L_B_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C2_C3, (Opcode)L_B_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C2_C3,PLAYDOHop_L_B_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C3_V1, (Opcode)L_B_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C3_V1,PLAYDOHop_L_B_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C3_C1, (Opcode)L_B_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C3_C1,PLAYDOHop_L_B_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C3_C2, (Opcode)L_B_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C3_C2,PLAYDOHop_L_B_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_C3_C3, (Opcode)L_B_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_C3_C3,PLAYDOHop_L_B_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_V1_V1, (Opcode)L_H_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_V1_V1,PLAYDOHop_L_H_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_V1_C1, (Opcode)L_H_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_V1_C1,PLAYDOHop_L_H_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_V1_C2, (Opcode)L_H_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_V1_C2,PLAYDOHop_L_H_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_V1_C3, (Opcode)L_H_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_V1_C3,PLAYDOHop_L_H_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C1_V1, (Opcode)L_H_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C1_V1,PLAYDOHop_L_H_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C1_C1, (Opcode)L_H_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C1_C1,PLAYDOHop_L_H_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C1_C2, (Opcode)L_H_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C1_C2,PLAYDOHop_L_H_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C1_C3, (Opcode)L_H_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C1_C3,PLAYDOHop_L_H_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C2_V1, (Opcode)L_H_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C2_V1,PLAYDOHop_L_H_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C2_C1, (Opcode)L_H_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C2_C1,PLAYDOHop_L_H_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C2_C2, (Opcode)L_H_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C2_C2,PLAYDOHop_L_H_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C2_C3, (Opcode)L_H_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C2_C3,PLAYDOHop_L_H_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C3_V1, (Opcode)L_H_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C3_V1,PLAYDOHop_L_H_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C3_C1, (Opcode)L_H_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C3_C1,PLAYDOHop_L_H_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C3_C2, (Opcode)L_H_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C3_C2,PLAYDOHop_L_H_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_C3_C3, (Opcode)L_H_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_C3_C3,PLAYDOHop_L_H_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_V1_V1, (Opcode)L_W_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_V1_V1,PLAYDOHop_L_W_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_V1_C1, (Opcode)L_W_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_V1_C1,PLAYDOHop_L_W_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_V1_C2, (Opcode)L_W_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_V1_C2,PLAYDOHop_L_W_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_V1_C3, (Opcode)L_W_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_V1_C3,PLAYDOHop_L_W_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C1_V1, (Opcode)L_W_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C1_V1,PLAYDOHop_L_W_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C1_C1, (Opcode)L_W_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C1_C1,PLAYDOHop_L_W_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C1_C2, (Opcode)L_W_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C1_C2,PLAYDOHop_L_W_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C1_C3, (Opcode)L_W_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C1_C3,PLAYDOHop_L_W_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C2_V1, (Opcode)L_W_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C2_V1,PLAYDOHop_L_W_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C2_C1, (Opcode)L_W_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C2_C1,PLAYDOHop_L_W_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C2_C2, (Opcode)L_W_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C2_C2,PLAYDOHop_L_W_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C2_C3, (Opcode)L_W_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C2_C3,PLAYDOHop_L_W_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C3_V1, (Opcode)L_W_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C3_V1,PLAYDOHop_L_W_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C3_C1, (Opcode)L_W_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C3_C1,PLAYDOHop_L_W_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C3_C2, (Opcode)L_W_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C3_C2,PLAYDOHop_L_W_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_C3_C3, (Opcode)L_W_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_C3_C3,PLAYDOHop_L_W_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_V1_V1, (Opcode)LI_B_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_V1_V1,PLAYDOHop_LI_B_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_V1_C1, (Opcode)LI_B_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_V1_C1,PLAYDOHop_LI_B_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_V1_C2, (Opcode)LI_B_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_V1_C2,PLAYDOHop_LI_B_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_V1_C3, (Opcode)LI_B_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_V1_C3,PLAYDOHop_LI_B_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C1_V1, (Opcode)LI_B_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C1_V1,PLAYDOHop_LI_B_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C1_C1, (Opcode)LI_B_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C1_C1,PLAYDOHop_LI_B_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C1_C2, (Opcode)LI_B_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C1_C2,PLAYDOHop_LI_B_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C1_C3, (Opcode)LI_B_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C1_C3,PLAYDOHop_LI_B_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C2_V1, (Opcode)LI_B_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C2_V1,PLAYDOHop_LI_B_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C2_C1, (Opcode)LI_B_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C2_C1,PLAYDOHop_LI_B_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C2_C2, (Opcode)LI_B_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C2_C2,PLAYDOHop_LI_B_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C2_C3, (Opcode)LI_B_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C2_C3,PLAYDOHop_LI_B_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C3_V1, (Opcode)LI_B_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C3_V1,PLAYDOHop_LI_B_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C3_C1, (Opcode)LI_B_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C3_C1,PLAYDOHop_LI_B_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C3_C2, (Opcode)LI_B_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C3_C2,PLAYDOHop_LI_B_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_B_C3_C3, (Opcode)LI_B_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_B_C3_C3,PLAYDOHop_LI_B_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_V1_V1, (Opcode)LI_H_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_V1_V1,PLAYDOHop_LI_H_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_V1_C1, (Opcode)LI_H_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_V1_C1,PLAYDOHop_LI_H_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_V1_C2, (Opcode)LI_H_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_V1_C2,PLAYDOHop_LI_H_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_V1_C3, (Opcode)LI_H_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_V1_C3,PLAYDOHop_LI_H_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C1_V1, (Opcode)LI_H_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C1_V1,PLAYDOHop_LI_H_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C1_C1, (Opcode)LI_H_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C1_C1,PLAYDOHop_LI_H_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C1_C2, (Opcode)LI_H_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C1_C2,PLAYDOHop_LI_H_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C1_C3, (Opcode)LI_H_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C1_C3,PLAYDOHop_LI_H_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C2_V1, (Opcode)LI_H_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C2_V1,PLAYDOHop_LI_H_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C2_C1, (Opcode)LI_H_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C2_C1,PLAYDOHop_LI_H_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C2_C2, (Opcode)LI_H_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C2_C2,PLAYDOHop_LI_H_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C2_C3, (Opcode)LI_H_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C2_C3,PLAYDOHop_LI_H_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C3_V1, (Opcode)LI_H_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C3_V1,PLAYDOHop_LI_H_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C3_C1, (Opcode)LI_H_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C3_C1,PLAYDOHop_LI_H_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C3_C2, (Opcode)LI_H_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C3_C2,PLAYDOHop_LI_H_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_H_C3_C3, (Opcode)LI_H_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_H_C3_C3,PLAYDOHop_LI_H_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_V1_V1, (Opcode)LI_W_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_V1_V1,PLAYDOHop_LI_W_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_V1_C1, (Opcode)LI_W_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_V1_C1,PLAYDOHop_LI_W_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_V1_C2, (Opcode)LI_W_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_V1_C2,PLAYDOHop_LI_W_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_V1_C3, (Opcode)LI_W_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_V1_C3,PLAYDOHop_LI_W_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C1_V1, (Opcode)LI_W_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C1_V1,PLAYDOHop_LI_W_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C1_C1, (Opcode)LI_W_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C1_C1,PLAYDOHop_LI_W_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C1_C2, (Opcode)LI_W_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C1_C2,PLAYDOHop_LI_W_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C1_C3, (Opcode)LI_W_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C1_C3,PLAYDOHop_LI_W_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C2_V1, (Opcode)LI_W_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C2_V1,PLAYDOHop_LI_W_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C2_C1, (Opcode)LI_W_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C2_C1,PLAYDOHop_LI_W_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C2_C2, (Opcode)LI_W_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C2_C2,PLAYDOHop_LI_W_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C2_C3, (Opcode)LI_W_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C2_C3,PLAYDOHop_LI_W_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C3_V1, (Opcode)LI_W_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C3_V1,PLAYDOHop_LI_W_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C3_C1, (Opcode)LI_W_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C3_C1,PLAYDOHop_LI_W_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C3_C2, (Opcode)LI_W_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C3_C2,PLAYDOHop_LI_W_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LI_W_C3_C3, (Opcode)LI_W_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LI_W_C3_C3,PLAYDOHop_LI_W_C3_C3) ;

//
//	Standard FPR load operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_V1_V1, (Opcode)FL_S_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_V1_V1,PLAYDOHop_FL_S_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_V1_C1, (Opcode)FL_S_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_V1_C1,PLAYDOHop_FL_S_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_V1_C2, (Opcode)FL_S_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_V1_C2,PLAYDOHop_FL_S_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_V1_C3, (Opcode)FL_S_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_V1_C3,PLAYDOHop_FL_S_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C1_V1, (Opcode)FL_S_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C1_V1,PLAYDOHop_FL_S_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C1_C1, (Opcode)FL_S_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C1_C1,PLAYDOHop_FL_S_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C1_C2, (Opcode)FL_S_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C1_C2,PLAYDOHop_FL_S_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C1_C3, (Opcode)FL_S_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C1_C3,PLAYDOHop_FL_S_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C2_V1, (Opcode)FL_S_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C2_V1,PLAYDOHop_FL_S_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C2_C1, (Opcode)FL_S_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C2_C1,PLAYDOHop_FL_S_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C2_C2, (Opcode)FL_S_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C2_C2,PLAYDOHop_FL_S_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C2_C3, (Opcode)FL_S_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C2_C3,PLAYDOHop_FL_S_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C3_V1, (Opcode)FL_S_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C3_V1,PLAYDOHop_FL_S_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C3_C1, (Opcode)FL_S_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C3_C1,PLAYDOHop_FL_S_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C3_C2, (Opcode)FL_S_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C3_C2,PLAYDOHop_FL_S_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_C3_C3, (Opcode)FL_S_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_C3_C3,PLAYDOHop_FL_S_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_V1_V1, (Opcode)FL_D_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_V1_V1,PLAYDOHop_FL_D_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_V1_C1, (Opcode)FL_D_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_V1_C1,PLAYDOHop_FL_D_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_V1_C2, (Opcode)FL_D_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_V1_C2,PLAYDOHop_FL_D_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_V1_C3, (Opcode)FL_D_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_V1_C3,PLAYDOHop_FL_D_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C1_V1, (Opcode)FL_D_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C1_V1,PLAYDOHop_FL_D_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C1_C1, (Opcode)FL_D_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C1_C1,PLAYDOHop_FL_D_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C1_C2, (Opcode)FL_D_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C1_C2,PLAYDOHop_FL_D_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C1_C3, (Opcode)FL_D_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C1_C3,PLAYDOHop_FL_D_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C2_V1, (Opcode)FL_D_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C2_V1,PLAYDOHop_FL_D_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C2_C1, (Opcode)FL_D_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C2_C1,PLAYDOHop_FL_D_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C2_C2, (Opcode)FL_D_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C2_C2,PLAYDOHop_FL_D_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C2_C3, (Opcode)FL_D_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C2_C3,PLAYDOHop_FL_D_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C3_V1, (Opcode)FL_D_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C3_V1,PLAYDOHop_FL_D_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C3_C1, (Opcode)FL_D_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C3_C1,PLAYDOHop_FL_D_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C3_C2, (Opcode)FL_D_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C3_C2,PLAYDOHop_FL_D_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_C3_C3, (Opcode)FL_D_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_C3_C3,PLAYDOHop_FL_D_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_V1_V1, (Opcode)FLI_S_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_V1_V1,PLAYDOHop_FLI_S_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_V1_C1, (Opcode)FLI_S_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_V1_C1,PLAYDOHop_FLI_S_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_V1_C2, (Opcode)FLI_S_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_V1_C2,PLAYDOHop_FLI_S_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_V1_C3, (Opcode)FLI_S_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_V1_C3,PLAYDOHop_FLI_S_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C1_V1, (Opcode)FLI_S_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C1_V1,PLAYDOHop_FLI_S_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C1_C1, (Opcode)FLI_S_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C1_C1,PLAYDOHop_FLI_S_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C1_C2, (Opcode)FLI_S_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C1_C2,PLAYDOHop_FLI_S_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C1_C3, (Opcode)FLI_S_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C1_C3,PLAYDOHop_FLI_S_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C2_V1, (Opcode)FLI_S_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C2_V1,PLAYDOHop_FLI_S_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C2_C1, (Opcode)FLI_S_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C2_C1,PLAYDOHop_FLI_S_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C2_C2, (Opcode)FLI_S_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C2_C2,PLAYDOHop_FLI_S_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C2_C3, (Opcode)FLI_S_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C2_C3,PLAYDOHop_FLI_S_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C3_V1, (Opcode)FLI_S_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C3_V1,PLAYDOHop_FLI_S_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C3_C1, (Opcode)FLI_S_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C3_C1,PLAYDOHop_FLI_S_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C3_C2, (Opcode)FLI_S_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C3_C2,PLAYDOHop_FLI_S_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_S_C3_C3, (Opcode)FLI_S_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_S_C3_C3,PLAYDOHop_FLI_S_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_V1_V1, (Opcode)FLI_D_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_V1_V1,PLAYDOHop_FLI_D_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_V1_C1, (Opcode)FLI_D_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_V1_C1,PLAYDOHop_FLI_D_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_V1_C2, (Opcode)FLI_D_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_V1_C2,PLAYDOHop_FLI_D_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_V1_C3, (Opcode)FLI_D_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_V1_C3,PLAYDOHop_FLI_D_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C1_V1, (Opcode)FLI_D_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C1_V1,PLAYDOHop_FLI_D_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C1_C1, (Opcode)FLI_D_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C1_C1,PLAYDOHop_FLI_D_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C1_C2, (Opcode)FLI_D_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C1_C2,PLAYDOHop_FLI_D_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C1_C3, (Opcode)FLI_D_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C1_C3,PLAYDOHop_FLI_D_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C2_V1, (Opcode)FLI_D_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C2_V1,PLAYDOHop_FLI_D_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C2_C1, (Opcode)FLI_D_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C2_C1,PLAYDOHop_FLI_D_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C2_C2, (Opcode)FLI_D_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C2_C2,PLAYDOHop_FLI_D_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C2_C3, (Opcode)FLI_D_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C2_C3,PLAYDOHop_FLI_D_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C3_V1, (Opcode)FLI_D_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C3_V1,PLAYDOHop_FLI_D_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C3_C1, (Opcode)FLI_D_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C3_C1,PLAYDOHop_FLI_D_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C3_C2, (Opcode)FLI_D_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C3_C2,PLAYDOHop_FLI_D_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLI_D_C3_C3, (Opcode)FLI_D_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLI_D_C3_C3,PLAYDOHop_FLI_D_C3_C3) ;

//
//	Standard GPR store operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_B_V1, (Opcode)S_B_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_B_V1,PLAYDOHop_S_B_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_B_C1, (Opcode)S_B_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_B_C1,PLAYDOHop_S_B_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_B_C2, (Opcode)S_B_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_B_C2,PLAYDOHop_S_B_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_B_C3, (Opcode)S_B_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_B_C3,PLAYDOHop_S_B_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_H_V1, (Opcode)S_H_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_H_V1,PLAYDOHop_S_H_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_H_C1, (Opcode)S_H_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_H_C1,PLAYDOHop_S_H_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_H_C2, (Opcode)S_H_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_H_C2,PLAYDOHop_S_H_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_H_C3, (Opcode)S_H_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_H_C3,PLAYDOHop_S_H_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_W_V1, (Opcode)S_W_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_W_V1,PLAYDOHop_S_W_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_W_C1, (Opcode)S_W_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_W_C1,PLAYDOHop_S_W_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_W_C2, (Opcode)S_W_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_W_C2,PLAYDOHop_S_W_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_W_C3, (Opcode)S_W_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_W_C3,PLAYDOHop_S_W_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_B_V1, (Opcode)SI_B_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_B_V1,PLAYDOHop_SI_B_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_B_C1, (Opcode)SI_B_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_B_C1,PLAYDOHop_SI_B_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_B_C2, (Opcode)SI_B_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_B_C2,PLAYDOHop_SI_B_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_B_C3, (Opcode)SI_B_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_B_C3,PLAYDOHop_SI_B_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_H_V1, (Opcode)SI_H_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_H_V1,PLAYDOHop_SI_H_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_H_C1, (Opcode)SI_H_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_H_C1,PLAYDOHop_SI_H_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_H_C2, (Opcode)SI_H_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_H_C2,PLAYDOHop_SI_H_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_H_C3, (Opcode)SI_H_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_H_C3,PLAYDOHop_SI_H_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_W_V1, (Opcode)SI_W_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_W_V1,PLAYDOHop_SI_W_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_W_C1, (Opcode)SI_W_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_W_C1,PLAYDOHop_SI_W_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_W_C2, (Opcode)SI_W_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_W_C2,PLAYDOHop_SI_W_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SI_W_C3, (Opcode)SI_W_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) SI_W_C3,PLAYDOHop_SI_W_C3) ;

//
//	Standard FPR store operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_S_V1, (Opcode)FS_S_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_S_V1,PLAYDOHop_FS_S_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_S_C1, (Opcode)FS_S_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_S_C1,PLAYDOHop_FS_S_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_S_C2, (Opcode)FS_S_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_S_C2,PLAYDOHop_FS_S_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_S_C3, (Opcode)FS_S_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_S_C3,PLAYDOHop_FS_S_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_D_V1, (Opcode)FS_D_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_D_V1,PLAYDOHop_FS_D_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_D_C1, (Opcode)FS_D_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_D_C1,PLAYDOHop_FS_D_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_D_C2, (Opcode)FS_D_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_D_C2,PLAYDOHop_FS_D_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_D_C3, (Opcode)FS_D_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_D_C3,PLAYDOHop_FS_D_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSI_S_V1, (Opcode)FSI_S_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FSI_S_V1,PLAYDOHop_FSI_S_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSI_S_C1, (Opcode)FSI_S_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FSI_S_C1,PLAYDOHop_FSI_S_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSI_S_C2, (Opcode)FSI_S_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FSI_S_C2,PLAYDOHop_FSI_S_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSI_S_C3, (Opcode)FSI_S_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FSI_S_C3,PLAYDOHop_FSI_S_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSI_D_V1, (Opcode)FSI_D_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FSI_D_V1,PLAYDOHop_FSI_D_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSI_D_C1, (Opcode)FSI_D_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FSI_D_C1,PLAYDOHop_FSI_D_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSI_D_C2, (Opcode)FSI_D_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FSI_D_C2,PLAYDOHop_FSI_D_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSI_D_C3, (Opcode)FSI_D_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FSI_D_C3,PLAYDOHop_FSI_D_C3) ;

//
//	Data speculative GPR load operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_V1_V1, (Opcode)LDS_B_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_V1_V1,PLAYDOHop_LDS_B_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_V1_C1, (Opcode)LDS_B_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_V1_C1,PLAYDOHop_LDS_B_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_V1_C2, (Opcode)LDS_B_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_V1_C2,PLAYDOHop_LDS_B_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_V1_C3, (Opcode)LDS_B_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_V1_C3,PLAYDOHop_LDS_B_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C1_V1, (Opcode)LDS_B_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C1_V1,PLAYDOHop_LDS_B_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C1_C1, (Opcode)LDS_B_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C1_C1,PLAYDOHop_LDS_B_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C1_C2, (Opcode)LDS_B_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C1_C2,PLAYDOHop_LDS_B_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C1_C3, (Opcode)LDS_B_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C1_C3,PLAYDOHop_LDS_B_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C2_V1, (Opcode)LDS_B_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C2_V1,PLAYDOHop_LDS_B_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C2_C1, (Opcode)LDS_B_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C2_C1,PLAYDOHop_LDS_B_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C2_C2, (Opcode)LDS_B_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C2_C2,PLAYDOHop_LDS_B_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C2_C3, (Opcode)LDS_B_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C2_C3,PLAYDOHop_LDS_B_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C3_V1, (Opcode)LDS_B_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C3_V1,PLAYDOHop_LDS_B_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C3_C1, (Opcode)LDS_B_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C3_C1,PLAYDOHop_LDS_B_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C3_C2, (Opcode)LDS_B_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C3_C2,PLAYDOHop_LDS_B_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_B_C3_C3, (Opcode)LDS_B_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_B_C3_C3,PLAYDOHop_LDS_B_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_V1_V1, (Opcode)LDS_H_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_V1_V1,PLAYDOHop_LDS_H_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_V1_C1, (Opcode)LDS_H_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_V1_C1,PLAYDOHop_LDS_H_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_V1_C2, (Opcode)LDS_H_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_V1_C2,PLAYDOHop_LDS_H_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_V1_C3, (Opcode)LDS_H_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_V1_C3,PLAYDOHop_LDS_H_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C1_V1, (Opcode)LDS_H_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C1_V1,PLAYDOHop_LDS_H_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C1_C1, (Opcode)LDS_H_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C1_C1,PLAYDOHop_LDS_H_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C1_C2, (Opcode)LDS_H_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C1_C2,PLAYDOHop_LDS_H_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C1_C3, (Opcode)LDS_H_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C1_C3,PLAYDOHop_LDS_H_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C2_V1, (Opcode)LDS_H_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C2_V1,PLAYDOHop_LDS_H_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C2_C1, (Opcode)LDS_H_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C2_C1,PLAYDOHop_LDS_H_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C2_C2, (Opcode)LDS_H_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C2_C2,PLAYDOHop_LDS_H_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C2_C3, (Opcode)LDS_H_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C2_C3,PLAYDOHop_LDS_H_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C3_V1, (Opcode)LDS_H_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C3_V1,PLAYDOHop_LDS_H_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C3_C1, (Opcode)LDS_H_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C3_C1,PLAYDOHop_LDS_H_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C3_C2, (Opcode)LDS_H_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C3_C2,PLAYDOHop_LDS_H_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_H_C3_C3, (Opcode)LDS_H_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_H_C3_C3,PLAYDOHop_LDS_H_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_V1_V1, (Opcode)LDS_W_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_V1_V1,PLAYDOHop_LDS_W_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_V1_C1, (Opcode)LDS_W_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_V1_C1,PLAYDOHop_LDS_W_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_V1_C2, (Opcode)LDS_W_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_V1_C2,PLAYDOHop_LDS_W_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_V1_C3, (Opcode)LDS_W_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_V1_C3,PLAYDOHop_LDS_W_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C1_V1, (Opcode)LDS_W_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C1_V1,PLAYDOHop_LDS_W_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C1_C1, (Opcode)LDS_W_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C1_C1,PLAYDOHop_LDS_W_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C1_C2, (Opcode)LDS_W_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C1_C2,PLAYDOHop_LDS_W_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C1_C3, (Opcode)LDS_W_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C1_C3,PLAYDOHop_LDS_W_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C2_V1, (Opcode)LDS_W_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C2_V1,PLAYDOHop_LDS_W_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C2_C1, (Opcode)LDS_W_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C2_C1,PLAYDOHop_LDS_W_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C2_C2, (Opcode)LDS_W_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C2_C2,PLAYDOHop_LDS_W_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C2_C3, (Opcode)LDS_W_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C2_C3,PLAYDOHop_LDS_W_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C3_V1, (Opcode)LDS_W_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C3_V1,PLAYDOHop_LDS_W_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C3_C1, (Opcode)LDS_W_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C3_C1,PLAYDOHop_LDS_W_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C3_C2, (Opcode)LDS_W_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C3_C2,PLAYDOHop_LDS_W_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDS_W_C3_C3, (Opcode)LDS_W_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDS_W_C3_C3,PLAYDOHop_LDS_W_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_V1_V1, (Opcode)LDSI_B_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_V1_V1,PLAYDOHop_LDSI_B_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_V1_C1, (Opcode)LDSI_B_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_V1_C1,PLAYDOHop_LDSI_B_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_V1_C2, (Opcode)LDSI_B_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_V1_C2,PLAYDOHop_LDSI_B_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_V1_C3, (Opcode)LDSI_B_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_V1_C3,PLAYDOHop_LDSI_B_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C1_V1, (Opcode)LDSI_B_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C1_V1,PLAYDOHop_LDSI_B_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C1_C1, (Opcode)LDSI_B_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C1_C1,PLAYDOHop_LDSI_B_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C1_C2, (Opcode)LDSI_B_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C1_C2,PLAYDOHop_LDSI_B_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C1_C3, (Opcode)LDSI_B_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C1_C3,PLAYDOHop_LDSI_B_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C2_V1, (Opcode)LDSI_B_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C2_V1,PLAYDOHop_LDSI_B_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C2_C1, (Opcode)LDSI_B_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C2_C1,PLAYDOHop_LDSI_B_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C2_C2, (Opcode)LDSI_B_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C2_C2,PLAYDOHop_LDSI_B_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C2_C3, (Opcode)LDSI_B_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C2_C3,PLAYDOHop_LDSI_B_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C3_V1, (Opcode)LDSI_B_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C3_V1,PLAYDOHop_LDSI_B_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C3_C1, (Opcode)LDSI_B_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C3_C1,PLAYDOHop_LDSI_B_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C3_C2, (Opcode)LDSI_B_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C3_C2,PLAYDOHop_LDSI_B_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_B_C3_C3, (Opcode)LDSI_B_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_B_C3_C3,PLAYDOHop_LDSI_B_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_V1_V1, (Opcode)LDSI_H_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_V1_V1,PLAYDOHop_LDSI_H_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_V1_C1, (Opcode)LDSI_H_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_V1_C1,PLAYDOHop_LDSI_H_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_V1_C2, (Opcode)LDSI_H_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_V1_C2,PLAYDOHop_LDSI_H_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_V1_C3, (Opcode)LDSI_H_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_V1_C3,PLAYDOHop_LDSI_H_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C1_V1, (Opcode)LDSI_H_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C1_V1,PLAYDOHop_LDSI_H_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C1_C1, (Opcode)LDSI_H_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C1_C1,PLAYDOHop_LDSI_H_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C1_C2, (Opcode)LDSI_H_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C1_C2,PLAYDOHop_LDSI_H_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C1_C3, (Opcode)LDSI_H_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C1_C3,PLAYDOHop_LDSI_H_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C2_V1, (Opcode)LDSI_H_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C2_V1,PLAYDOHop_LDSI_H_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C2_C1, (Opcode)LDSI_H_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C2_C1,PLAYDOHop_LDSI_H_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C2_C2, (Opcode)LDSI_H_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C2_C2,PLAYDOHop_LDSI_H_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C2_C3, (Opcode)LDSI_H_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C2_C3,PLAYDOHop_LDSI_H_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C3_V1, (Opcode)LDSI_H_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C3_V1,PLAYDOHop_LDSI_H_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C3_C1, (Opcode)LDSI_H_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C3_C1,PLAYDOHop_LDSI_H_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C3_C2, (Opcode)LDSI_H_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C3_C2,PLAYDOHop_LDSI_H_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_H_C3_C3, (Opcode)LDSI_H_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_H_C3_C3,PLAYDOHop_LDSI_H_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_V1_V1, (Opcode)LDSI_W_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_V1_V1,PLAYDOHop_LDSI_W_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_V1_C1, (Opcode)LDSI_W_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_V1_C1,PLAYDOHop_LDSI_W_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_V1_C2, (Opcode)LDSI_W_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_V1_C2,PLAYDOHop_LDSI_W_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_V1_C3, (Opcode)LDSI_W_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_V1_C3,PLAYDOHop_LDSI_W_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C1_V1, (Opcode)LDSI_W_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C1_V1,PLAYDOHop_LDSI_W_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C1_C1, (Opcode)LDSI_W_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C1_C1,PLAYDOHop_LDSI_W_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C1_C2, (Opcode)LDSI_W_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C1_C2,PLAYDOHop_LDSI_W_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C1_C3, (Opcode)LDSI_W_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C1_C3,PLAYDOHop_LDSI_W_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C2_V1, (Opcode)LDSI_W_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C2_V1,PLAYDOHop_LDSI_W_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C2_C1, (Opcode)LDSI_W_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C2_C1,PLAYDOHop_LDSI_W_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C2_C2, (Opcode)LDSI_W_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C2_C2,PLAYDOHop_LDSI_W_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C2_C3, (Opcode)LDSI_W_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C2_C3,PLAYDOHop_LDSI_W_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C3_V1, (Opcode)LDSI_W_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C3_V1,PLAYDOHop_LDSI_W_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C3_C1, (Opcode)LDSI_W_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C3_C1,PLAYDOHop_LDSI_W_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C3_C2, (Opcode)LDSI_W_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C3_C2,PLAYDOHop_LDSI_W_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDSI_W_C3_C3, (Opcode)LDSI_W_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) LDSI_W_C3_C3,PLAYDOHop_LDSI_W_C3_C3) ;

//
//	Data speculative FPR load operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_V1_V1, (Opcode)FLDS_S_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_V1_V1,PLAYDOHop_FLDS_S_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_V1_C1, (Opcode)FLDS_S_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_V1_C1,PLAYDOHop_FLDS_S_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_V1_C2, (Opcode)FLDS_S_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_V1_C2,PLAYDOHop_FLDS_S_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_V1_C3, (Opcode)FLDS_S_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_V1_C3,PLAYDOHop_FLDS_S_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C1_V1, (Opcode)FLDS_S_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C1_V1,PLAYDOHop_FLDS_S_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C1_C1, (Opcode)FLDS_S_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C1_C1,PLAYDOHop_FLDS_S_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C1_C2, (Opcode)FLDS_S_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C1_C2,PLAYDOHop_FLDS_S_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C1_C3, (Opcode)FLDS_S_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C1_C3,PLAYDOHop_FLDS_S_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C2_V1, (Opcode)FLDS_S_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C2_V1,PLAYDOHop_FLDS_S_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C2_C1, (Opcode)FLDS_S_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C2_C1,PLAYDOHop_FLDS_S_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C2_C2, (Opcode)FLDS_S_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C2_C2,PLAYDOHop_FLDS_S_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C2_C3, (Opcode)FLDS_S_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C2_C3,PLAYDOHop_FLDS_S_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C3_V1, (Opcode)FLDS_S_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C3_V1,PLAYDOHop_FLDS_S_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C3_C1, (Opcode)FLDS_S_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C3_C1,PLAYDOHop_FLDS_S_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C3_C2, (Opcode)FLDS_S_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C3_C2,PLAYDOHop_FLDS_S_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_S_C3_C3, (Opcode)FLDS_S_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_S_C3_C3,PLAYDOHop_FLDS_S_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_V1_V1, (Opcode)FLDS_D_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_V1_V1,PLAYDOHop_FLDS_D_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_V1_C1, (Opcode)FLDS_D_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_V1_C1,PLAYDOHop_FLDS_D_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_V1_C2, (Opcode)FLDS_D_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_V1_C2,PLAYDOHop_FLDS_D_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_V1_C3, (Opcode)FLDS_D_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_V1_C3,PLAYDOHop_FLDS_D_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C1_V1, (Opcode)FLDS_D_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C1_V1,PLAYDOHop_FLDS_D_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C1_C1, (Opcode)FLDS_D_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C1_C1,PLAYDOHop_FLDS_D_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C1_C2, (Opcode)FLDS_D_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C1_C2,PLAYDOHop_FLDS_D_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C1_C3, (Opcode)FLDS_D_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C1_C3,PLAYDOHop_FLDS_D_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C2_V1, (Opcode)FLDS_D_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C2_V1,PLAYDOHop_FLDS_D_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C2_C1, (Opcode)FLDS_D_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C2_C1,PLAYDOHop_FLDS_D_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C2_C2, (Opcode)FLDS_D_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C2_C2,PLAYDOHop_FLDS_D_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C2_C3, (Opcode)FLDS_D_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C2_C3,PLAYDOHop_FLDS_D_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C3_V1, (Opcode)FLDS_D_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C3_V1,PLAYDOHop_FLDS_D_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C3_C1, (Opcode)FLDS_D_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C3_C1,PLAYDOHop_FLDS_D_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C3_C2, (Opcode)FLDS_D_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C3_C2,PLAYDOHop_FLDS_D_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDS_D_C3_C3, (Opcode)FLDS_D_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDS_D_C3_C3,PLAYDOHop_FLDS_D_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_V1_V1, (Opcode)FLDSI_S_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_V1_V1,PLAYDOHop_FLDSI_S_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_V1_C1, (Opcode)FLDSI_S_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_V1_C1,PLAYDOHop_FLDSI_S_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_V1_C2, (Opcode)FLDSI_S_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_V1_C2,PLAYDOHop_FLDSI_S_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_V1_C3, (Opcode)FLDSI_S_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_V1_C3,PLAYDOHop_FLDSI_S_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C1_V1, (Opcode)FLDSI_S_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C1_V1,PLAYDOHop_FLDSI_S_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C1_C1, (Opcode)FLDSI_S_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C1_C1,PLAYDOHop_FLDSI_S_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C1_C2, (Opcode)FLDSI_S_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C1_C2,PLAYDOHop_FLDSI_S_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C1_C3, (Opcode)FLDSI_S_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C1_C3,PLAYDOHop_FLDSI_S_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C2_V1, (Opcode)FLDSI_S_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C2_V1,PLAYDOHop_FLDSI_S_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C2_C1, (Opcode)FLDSI_S_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C2_C1,PLAYDOHop_FLDSI_S_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C2_C2, (Opcode)FLDSI_S_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C2_C2,PLAYDOHop_FLDSI_S_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C2_C3, (Opcode)FLDSI_S_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C2_C3,PLAYDOHop_FLDSI_S_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C3_V1, (Opcode)FLDSI_S_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C3_V1,PLAYDOHop_FLDSI_S_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C3_C1, (Opcode)FLDSI_S_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C3_C1,PLAYDOHop_FLDSI_S_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C3_C2, (Opcode)FLDSI_S_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C3_C2,PLAYDOHop_FLDSI_S_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_S_C3_C3, (Opcode)FLDSI_S_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_S_C3_C3,PLAYDOHop_FLDSI_S_C3_C3) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_V1_V1, (Opcode)FLDSI_D_V1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_V1_V1,PLAYDOHop_FLDSI_D_V1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_V1_C1, (Opcode)FLDSI_D_V1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_V1_C1,PLAYDOHop_FLDSI_D_V1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_V1_C2, (Opcode)FLDSI_D_V1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_V1_C2,PLAYDOHop_FLDSI_D_V1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_V1_C3, (Opcode)FLDSI_D_V1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_V1_C3,PLAYDOHop_FLDSI_D_V1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C1_V1, (Opcode)FLDSI_D_C1_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C1_V1,PLAYDOHop_FLDSI_D_C1_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C1_C1, (Opcode)FLDSI_D_C1_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C1_C1,PLAYDOHop_FLDSI_D_C1_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C1_C2, (Opcode)FLDSI_D_C1_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C1_C2,PLAYDOHop_FLDSI_D_C1_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C1_C3, (Opcode)FLDSI_D_C1_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C1_C3,PLAYDOHop_FLDSI_D_C1_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C2_V1, (Opcode)FLDSI_D_C2_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C2_V1,PLAYDOHop_FLDSI_D_C2_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C2_C1, (Opcode)FLDSI_D_C2_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C2_C1,PLAYDOHop_FLDSI_D_C2_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C2_C2, (Opcode)FLDSI_D_C2_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C2_C2,PLAYDOHop_FLDSI_D_C2_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C2_C3, (Opcode)FLDSI_D_C2_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C2_C3,PLAYDOHop_FLDSI_D_C2_C3) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C3_V1, (Opcode)FLDSI_D_C3_V1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C3_V1,PLAYDOHop_FLDSI_D_C3_V1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C3_C1, (Opcode)FLDSI_D_C3_C1) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C3_C1,PLAYDOHop_FLDSI_D_C3_C1) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C3_C2, (Opcode)FLDSI_D_C3_C2) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C3_C2,PLAYDOHop_FLDSI_D_C3_C2) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDSI_D_C3_C3, (Opcode)FLDSI_D_C3_C3) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FLDSI_D_C3_C3,PLAYDOHop_FLDSI_D_C3_C3) ;

//
//	Data verify GPR load operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDV_B,LDV_B) ;
   el_elcor_to_lcode_opcode_map.bind(LDV_B,PLAYDOHop_LDV_B) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDV_H,LDV_H) ;
   el_elcor_to_lcode_opcode_map.bind(LDV_H,PLAYDOHop_LDV_H) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_LDV_W,LDV_W) ;
   el_elcor_to_lcode_opcode_map.bind(LDV_W,PLAYDOHop_LDV_W) ;

//
//	Data verify FPR load operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDV_S,FLDV_S) ;
   el_elcor_to_lcode_opcode_map.bind(FLDV_S,PLAYDOHop_FLDV_S) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FLDV_D,FLDV_D) ;
   el_elcor_to_lcode_opcode_map.bind(FLDV_D,PLAYDOHop_FLDV_D) ;

//
//	Local memory operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_B_LM, (Opcode)L_B_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_B_LM,PLAYDOHop_L_B_LM) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_H_LM, (Opcode)L_H_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_H_LM,PLAYDOHop_L_H_LM) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_L_W_LM, (Opcode)L_W_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) L_W_LM,PLAYDOHop_L_W_LM) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_S_LM, (Opcode)FL_S_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_S_LM,PLAYDOHop_FL_S_LM) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FL_D_LM, (Opcode)FL_D_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FL_D_LM,PLAYDOHop_FL_D_LM) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_B_LM, (Opcode)S_B_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_B_LM,PLAYDOHop_S_B_LM) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_H_LM, (Opcode)S_H_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_H_LM,PLAYDOHop_S_H_LM) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_S_W_LM, (Opcode)S_W_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) S_W_LM,PLAYDOHop_S_W_LM) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_S_LM, (Opcode)FS_S_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_S_LM,PLAYDOHop_FS_S_LM) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FS_D_LM, (Opcode)FS_D_LM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode) FS_D_LM,PLAYDOHop_FS_D_LM) ;

//
//	Branch operations
//

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_PBRR,PBRR) ;
   el_elcor_to_lcode_opcode_map.bind(PBRR,PLAYDOHop_PBRR) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_PBRA,PBRA) ;
   el_elcor_to_lcode_opcode_map.bind(PBRA,PLAYDOHop_PBRA) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRU,BRU) ;
   el_elcor_to_lcode_opcode_map.bind(BRU,PLAYDOHop_BRU) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRCT,BRCT) ;
   el_elcor_to_lcode_opcode_map.bind(BRCT,PLAYDOHop_BRCT) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRCF,BRCF) ;
   el_elcor_to_lcode_opcode_map.bind(BRCF,PLAYDOHop_BRCF) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRL,BRL) ;
   el_elcor_to_lcode_opcode_map.bind(BRL,PLAYDOHop_BRL) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRLC,BRLC) ;
   el_elcor_to_lcode_opcode_map.bind(BRLC,PLAYDOHop_BRLC) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_RTS,RTS) ;
   el_elcor_to_lcode_opcode_map.bind(RTS,Lop_RTS) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRF_B_B_F,BRF_B_B_F) ;
   el_elcor_to_lcode_opcode_map.bind(BRF_B_B_F,PLAYDOHop_BRF_B_B_F) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRF_B_F_F,BRF_B_F_F) ;
   el_elcor_to_lcode_opcode_map.bind(BRF_B_F_F,PLAYDOHop_BRF_B_F_F) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRF_F_B_B,BRF_F_B_B) ;
   el_elcor_to_lcode_opcode_map.bind(BRF_F_B_B,PLAYDOHop_BRF_F_B_B) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRF_F_F_B,BRF_F_F_B) ;
   el_elcor_to_lcode_opcode_map.bind(BRF_F_F_B,PLAYDOHop_BRF_F_F_B) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRF_F_F_F,BRF_F_F_F) ;
   el_elcor_to_lcode_opcode_map.bind(BRF_F_F_F,PLAYDOHop_BRF_F_F_F) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRW_B_B_F,BRW_B_B_F) ;
   el_elcor_to_lcode_opcode_map.bind(BRW_B_B_F,PLAYDOHop_BRW_B_B_F) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRW_B_F_F,BRW_B_F_F) ;
   el_elcor_to_lcode_opcode_map.bind(BRW_B_F_F,PLAYDOHop_BRW_B_F_F) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRW_F_B_B,BRW_F_B_B) ;
   el_elcor_to_lcode_opcode_map.bind(BRW_F_B_B,PLAYDOHop_BRW_F_B_B) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRW_F_F_B,BRW_F_F_B) ;
   el_elcor_to_lcode_opcode_map.bind(BRW_F_F_B,PLAYDOHop_BRW_F_F_B) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRW_F_F_F,BRW_F_F_F) ;
   el_elcor_to_lcode_opcode_map.bind(BRW_F_F_F,PLAYDOHop_BRW_F_F_F) ;

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRDVI,BRDVI) ;
   el_elcor_to_lcode_opcode_map.bind(BRDVI,PLAYDOHop_BRDVI) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRDVF,BRDVF) ;
   el_elcor_to_lcode_opcode_map.bind(BRDVF,PLAYDOHop_BRDVF) ;

   //
   // Regalloc ops
   //

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_SAVE,(Opcode)SAVE) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)SAVE,PLAYDOHop_SAVE) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_RESTORE,(Opcode)RESTORE) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)RESTORE,PLAYDOHop_RESTORE) ;
   // Explicitly may FSAVE and FRESTORE to the Playdoh double precision versions
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSAVE_S,(Opcode)FSAVE) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FRESTORE_S,(Opcode)FRESTORE) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FSAVE_D,(Opcode)FSAVE) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)FSAVE,PLAYDOHop_FSAVE_D) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_FRESTORE_D,(Opcode)FRESTORE) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)FRESTORE,PLAYDOHop_FRESTORE_D) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BSAVE,(Opcode)BSAVE) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BSAVE,PLAYDOHop_BSAVE) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_BRESTORE,(Opcode)BRESTORE) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)BRESTORE,PLAYDOHop_BRESTORE) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEGBP,(Opcode)MOVEGBP) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)MOVEGBP,PLAYDOHop_MOVEGBP) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVEGCM,(Opcode)MOVEGCM) ;
   el_elcor_to_lcode_opcode_map.bind((Opcode)MOVEGCM,PLAYDOHop_MOVEGCM) ;
  
   //
   // Literal-forming operations
   //

   // Literal moves to btr, pbrs with literals

   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVELB,MOVELB) ;
   el_elcor_to_lcode_opcode_map.bind(MOVELB,PLAYDOHop_MOVELB) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVELBS,MOVELBS) ;
   el_elcor_to_lcode_opcode_map.bind(MOVELBS,PLAYDOHop_MOVELBS) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVELBX,MOVELBX) ;
   el_elcor_to_lcode_opcode_map.bind(MOVELBX,PLAYDOHop_MOVELBX) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_PBRAL,PBRAL) ;
   el_elcor_to_lcode_opcode_map.bind(PBRAL,PLAYDOHop_PBRAL) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_PBRRL,PBRRL) ;
   el_elcor_to_lcode_opcode_map.bind(PBRRL,PLAYDOHop_PBRRL) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_PBRALBS,PBRALBS) ;
   el_elcor_to_lcode_opcode_map.bind(PBRALBS,PLAYDOHop_PBRALBS) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_PBRRLBS,PBRRLBS) ;
   el_elcor_to_lcode_opcode_map.bind(PBRRLBS,PLAYDOHop_PBRRLBS) ;
  
   // Literal move operations
 
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVELG,MOVELG) ;
   el_elcor_to_lcode_opcode_map.bind(MOVELG,PLAYDOHop_MOVELG) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVELGS,MOVELGS) ;
   el_elcor_to_lcode_opcode_map.bind(MOVELGS,PLAYDOHop_MOVELGS) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVELGX,MOVELGX) ;
   el_elcor_to_lcode_opcode_map.bind(MOVELGX,PLAYDOHop_MOVELGX) ;
 
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVELF,MOVELF) ;
   el_elcor_to_lcode_opcode_map.bind(MOVELF,PLAYDOHop_MOVELF) ;
   el_lcode_to_elcor_opcode_map.bind(PLAYDOHop_MOVELFS,MOVELFS) ;
   el_elcor_to_lcode_opcode_map.bind(MOVELFS,PLAYDOHop_MOVELFS) ;
 

//
//	Lcode operations
// 

   el_lcode_to_elcor_opcode_map.bind(Lop_PROLOGUE,PROLOGUE) ;
   el_elcor_to_lcode_opcode_map.bind(PROLOGUE,Lop_PROLOGUE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_EPILOGUE,EPILOGUE) ;
   el_elcor_to_lcode_opcode_map.bind(EPILOGUE,Lop_EPILOGUE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_DEFINE,DEFINE) ;
   el_elcor_to_lcode_opcode_map.bind(DEFINE,Lop_DEFINE) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_ALLOC,ALLOC) ;
   el_elcor_to_lcode_opcode_map.bind(ALLOC,Lop_ALLOC) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_SIM_DIR,SIM_DIR) ;
   el_elcor_to_lcode_opcode_map.bind(SIM_DIR,Lop_SIM_DIR) ;
 
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_CLEAR,PRED_CLEAR) ;
   el_elcor_to_lcode_opcode_map.bind(PRED_CLEAR,Lop_PRED_CLEAR) ;
   el_elcor_to_lcode_opcode_map.bind(PRED_CLEAR_ALL,Lop_PRED_CLEAR) ;
   el_elcor_to_lcode_opcode_map.bind(PRED_CLEAR_ALL_STATIC,Lop_PRED_CLEAR) ;
   el_elcor_to_lcode_opcode_map.bind(PRED_CLEAR_ALL_ROTATING,Lop_PRED_CLEAR) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_SET,PRED_SET) ;
   el_elcor_to_lcode_opcode_map.bind(PRED_SET,Lop_PRED_SET) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_AND,PRED_AND) ;
   el_elcor_to_lcode_opcode_map.bind(PRED_AND,Lop_PRED_AND) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_COMPL,PRED_COMPL) ;
   el_elcor_to_lcode_opcode_map.bind(PRED_COMPL,Lop_PRED_COMPL) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_LD_BLK,PRED_LOAD_ALL) ;
   el_elcor_to_lcode_opcode_map.bind(PRED_LOAD_ALL,Lop_PRED_LD_BLK) ;
   el_lcode_to_elcor_opcode_map.bind(Lop_PRED_ST_BLK,PRED_STORE_ALL) ;
   el_elcor_to_lcode_opcode_map.bind(PRED_STORE_ALL,Lop_PRED_ST_BLK) ;
}
