/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   LiveRange.cpp
// Author: Hansoo Kim
///////////////////////////////////////////////////////////////////////////////

#include <intf.h>
#include <regtochar.h>
#include "el_control.h"
#include <iterators.h>
#include "operand.h"
#include "opcode_cmpp.h"
#include "opcode_load_store.h"
#include "opcode_properties.h"
#include "regtochar.h"
#include "dlist.h"
#include "LiveRange.h"
#include "ReconcileData.h"
#include "SpillCodeUtils.h"

// needs to be revised
#define STORE_LATENCY 1
#define LOAD_LATENCY 2

LiveRange::LiveRange(const Operand& variable_, 
		     const Compound_region* region_) {
    _variable = variable_;
    _region = (Compound_region*)region_;
    _reg_num = -1;
    _processed = false;
    _bound = false;
    _brl_num = 0;
    _def_num = 0;
    _use_num = 0;

    _spill_cost = 0;
    _caller_benefit = 0;
    _callee_benefit = 0;
    _priority = 0;

    char* file_name = regfile_to_char(_variable.file_type());
    _reg_bank =  &RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)];
    _forbidden = _reg_bank->_macro_set;
    _pre_lr = NULL;
    _post_lr = NULL;
    
    _reg_bind_state = UNDEFINED;
    _delayed_bind = false;
    _reconciled = false;
}


bool
LiveRange::is_constrained()const {
    if (_variable.assigned_to_physical_file()) {
	// you can use physical register name
	// this is the way it supposed to be
	eString phy_file_name = _variable.physical_file_type();
	unsigned int static_reg_size =  MDES_reg_static_size(phy_file_name);
	if (_inf_set.size() < static_reg_size)
	    return false;
	else
	    return true;
    }
    else {
	eString file_name = _variable.physical_file_type();
	int reg_size = MDES_reg_static_size(file_name);
	if ((int)_inf_set.size() < reg_size)
	    return false;
	else
	    return true;
    }
}

// bind phisical register to LiveRange
// update forbidden set for itself and all interfered LiveRange
void
LiveRange::bind_register(int reg_num_) {
    _reg_bind_state = BOUND;
    _processed = true;
    _bound = true;
    _reg_num = reg_num_;

    _variable.bind_reg(reg_num_);
    for (Dlist_iterator<El_ref> iter1(_live_refs); iter1 != 0; iter1++) {
	(*iter1).get_operand().bind_reg(reg_num_);
    }

    add_forbidden(reg_num_);
    for (List_set_iterator<LiveRange*> iter2(_inf_set);
	 iter2 != 0; iter2++) {
	LiveRange* lr_ptr = *iter2;
	lr_ptr->add_forbidden(reg_num_);
    }
    
    eString file_name = _variable.physical_file_type();
    //char* file_name = regfile_to_char_vector[_variable.file_type()];
    List_set<int> caller_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._caller_set;
    List_set<int> callee_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._callee_set;
    if (caller_pool.is_member(reg_num_))
	_reg_convention = CALLER_SAVED;
    else if (callee_pool.is_member(reg_num_))
	_reg_convention = CALLEE_SAVED;
    else
	assert(0);

    if (_reg_convention == CALLER_SAVED) {
	for (Dlist_iterator<Op*> iter(_live_ops); iter != 0; iter++) {
	    Op* op_ptr = *iter;
	    if (is_brl(op_ptr)) {
		//if ( _live_ops.is_member(op_ptr->next()) &&
		//    _live_ops.is_member(op_ptr->prev())) {
		if (_live_ops.head() != op_ptr) {
		    // We do not have to spill for last BRL operation
		    SpillCodeUtils::store_before(_variable, op_ptr);
		    SpillCodeUtils::load_after(_variable, op_ptr);
		}
	    }
	}
    }
}


/* 
 * This function is for split live-range ONLY
 * The live range is internal pass-through
 * Try to bind with adject live range or spill
 */
void
LiveRange::bind_register() {
    assert(_pre_lr || _post_lr);
    assert(_live_refs.size() == 0);

    RegCallingConvention pref_class;
    if (is_leaf())
        pref_class = CALLER_SAVED;
    else
        pref_class = CALLEE_SAVED;
   

    // use the same register to splitted live-range, if available.
    if (_pre_lr != NULL && _pre_lr->_reg_bind_state == BOUND
        && _pre_lr->reg_convention() == pref_class) {
        if (!_forbidden.is_member(_pre_lr->_reg_num)) {
            bind_register(_pre_lr->_reg_num);
	    return;
        }
    }

    if (_post_lr != NULL && _post_lr->_reg_bind_state == BOUND
        && _post_lr->reg_convention() == pref_class) {
        if (!_forbidden.is_member(_post_lr->_reg_num)) {
	    bind_register(_post_lr->_reg_num);
	    return;
        }
    }

    reg_bind_state(SPILLED);
}



void
LiveRange::spilling() {

    // This function may be called when a variable is dead (dead code operation)

    for (Dlist_iterator<El_ref> iter(_live_refs); iter != 0; iter++) {
	El_ref& ref = *iter;
	int port_num = ref.get_port_num();

	// register is reserved for spilling
	int pref_reg = _reg_bank->spill_reg(port_num);
	ref.get_operand().bind_reg(pref_reg);

	El_ref_type ref_type= ref.get_ref_type();
	if (ref_type == EXP_DEST) {
	    SpillCodeUtils::store_after(ref.get_operand(), ref.get_op());
	}
	else if (ref_type == EXP_SRC) {
	    SpillCodeUtils::load_before(ref.get_operand(), ref.get_op());
	}
    }
    

    reg_bind_state(SPILLED);
}

void
LiveRange::set_pre_lr(LiveRange* lr_) {
    _pre_lr = lr_;
}


void
LiveRange::set_post_lr(LiveRange* lr_) {
    _post_lr = lr_;
}


RegCallingConvention
LiveRange::pref_reg_class() {
    RegCallingConvention pref_class;
    if (is_leaf())
        pref_class = CALLER_SAVED;
    else
        pref_class = CALLEE_SAVED;
   
    return pref_class;
}


/*
 * If current LiveRange is leaf (there are no function calling in this liverange)
 *    then use CALLER saved register
 *    else use CALLEE saved register
 *
 * If prefered register was CALLER saved register, but all CALLER saved register
 * was used then use CALLEE saved register.
 * If prefered register was CALLEE saved register but all CALLEE saved register
 * was used, then split this liverange.
 *
 * CALLEE saved registers are prefered, if there are function calling within a liverange,
 * and if CALLER saved registers are used it has 2 spill codes around every function
 * call. The heuristic in this case is that by splitting the liverange, 
 *  1. we expect to reduce CALLEE saved register pressure
 *  2. we divide original liverange into 2 smaller liverange and expect one of them 
 *     (say liverange A) does not have function calling. We can use CALLER saved register 
 *     for liverange A.
 */

int
LiveRange::find_split_register() {
    int prefered_reg = -1;

    // If current LR was split with _pre_lr, try to use the register
    // of _pre_lr
    // You should check
    //   1. current LR was splitted
    //   2. _pre_lr is binded
    //   3. binded register was same register convention with current LR
    //   4. binded register is not forbidden in current LR
    if (_pre_lr != NULL && _pre_lr->_reg_bind_state == BOUND
	&& _pre_lr->reg_convention() == _pref_class) {
	if (!_forbidden.is_member(_pre_lr->_reg_num)) {
	    prefered_reg = _pre_lr->_reg_num;
	    // _reg_convention = pref_class;
	    return prefered_reg;
	}
    }

    // check the same thing to the above with _post_lr 
    if (_post_lr != NULL && _post_lr->_reg_bind_state == BOUND
	&& _post_lr->reg_convention() == _pref_class) {
	if (!_forbidden.is_member(_post_lr->_reg_num)) {
	    prefered_reg = _post_lr->_reg_num;
	    // _reg_convention = pref_class;
	    return prefered_reg;
	}
    }
    return prefered_reg;
}

int
LiveRange::find_bound_register()   {
	
    int prefered_reg = -1;
    char* file_name = regfile_to_char(_variable.file_type());

    // select register from bounded list
    // by frequency order
    List_set<int> caller_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._caller_set;
    List_set<int> callee_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._callee_set;
    
    // checking all global bindings by frequency order
    List<LiveRange*> g_LRs = ReconcileData::global_LRs(this);

    if (_pref_class == CALLEE_SAVED) {
	// If pref_class is CALLEE_SAVED, this range does have one or
	// more function calls. (not leaf-node)
	// Use CALLER_SAVED needs many spill codes for each function
	// call, and so use CALLEE_SAVED ONLY
	for (List_iterator<LiveRange*> iter(g_LRs); iter != 0; iter++) {
	    LiveRange* lr = *iter;
	    int reg = lr->reg_num();
	    
	    if (reg < 0) {
		continue;
	    }
	    else if (callee_pool.is_member(reg) && !_forbidden.is_member(reg)) {
		prefered_reg = reg;
		break;
	    }
	}
    }
    else { 
	// (pref_class == CALLER_SAVED), use CALLER and CALLEE as available
	for (List_iterator<LiveRange*> iter(g_LRs); iter != 0; iter++) {
	    LiveRange* lr = *iter;
	    int reg = lr->reg_num();
	    
	    if ( reg < 0 ) {
		continue;
	    }
	    else if (!_forbidden.is_member(reg)) {
		prefered_reg = reg;
		break;
	    }
	}
    }
    return prefered_reg;
}

int
LiveRange::find_register_in_pref_class()    {

    int prefered_reg = -1;
    char* file_name = regfile_to_char(_variable.file_type());

    prefered_reg = find_split_register();
    if (prefered_reg >= 0) {
	return prefered_reg;
    }


    prefered_reg = find_bound_register();
    if (prefered_reg >= 0) {
	return prefered_reg;
    }

    // no bounded regsiters are available for me
    // find new one
    // Avoid registers which is used in interfered liverange
    List_set<int> caller_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._caller_set;
    List_set<int> callee_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._callee_set;
     List_set<int>  available_regs;
     if (_pref_class == CALLER_SAVED) {
	 available_regs = caller_pool;
     }
     else {
	 available_regs += callee_pool;
     }
     available_regs -= _forbidden;

     List_set_iterator<LiveRange*> iter(_inf_set);
     while (1) {
	 if (available_regs.size() > 0) {
	     prefered_reg = available_regs.head();
	 }
	 else {
	     break;
	 }

	 if (iter != 0) {
	     LiveRange* inf_lr = *iter;
	     List_set<int> gForbidden = ReconcileData::usedRegs(inf_lr);
	     available_regs -= gForbidden;
	 }
	 else
	     break;
	 iter++;
     }
     return prefered_reg;
}


int
LiveRange::find_register_in_reverse_class()    {

    int prefered_reg = -1;
    char* file_name = regfile_to_char(_variable.file_type());

     // no bounded regsiters are available for me
     // find new one
     // Avoid registers which is used in interfered liverange
     List_set<int> caller_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._caller_set;
     List_set<int> callee_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._callee_set;
     List_set<int>  available_regs;
     if (_pref_class == CALLER_SAVED) {
	 available_regs = callee_pool;
     }
     else {
	 available_regs += caller_pool;
     }
     available_regs -= _forbidden;

     List_set_iterator<LiveRange*> iter(_inf_set);
     while (1) {
	 if (available_regs.size() > 0) {
	     prefered_reg = available_regs.head();
	 }
	 else {
	     break;
	 }

	 if (iter != 0) {
	     LiveRange* inf_lr = *iter;
	     List_set<int> gForbidden = ReconcileData::usedRegs(inf_lr);
	     available_regs -= gForbidden;
	 }
	 else
	     break;
	 iter++;
     }
     return prefered_reg;
}


int
LiveRange::find_global_register() {

    int prefered_reg = -1;
    char* file_name = regfile_to_char(_variable.file_type());

    List<LiveRange*> global_LRs = ReconcileData::global_LRs(this);
    
    List_set<int> caller_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._caller_set;
    List_set<int> callee_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._callee_set;
    List_set<int>  available_regs;
    if (_pref_class == CALLER_SAVED) {
	available_regs += caller_pool;
    }
    else {
	available_regs += callee_pool;
    }
    
    LiveRange* lr = (LiveRange*)this;
    List_iterator<LiveRange*> iter(global_LRs);
    while (1) {
	available_regs -= lr->_forbidden;
	if (available_regs.size() > 0) {
	    prefered_reg = available_regs.head();
	}
	else {
	    break;
	}
	
	if (iter != 0)
	    lr = *iter;
	else
	    break;
	iter++;
    }
    return prefered_reg;
}


#if 0
{
    List_set<int> caller_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._caller_set;
    List_set<int> callee_pool = RegisterBank::_reg_bank_pool[RegisterBank::index(file_name)]._callee_set;

    List_set<int> candidate_regs;
    if (pref_class == CALLEE_SAVED)
	candidate_regs = callee_pool;
    else
	candidate_regs = caller_pool;
	
    // 2. Now, let's check prefered bindings of adjacent Region
    // List_set<int> reg_pool = avlblRegsForPrecoloring(_region, this);
    List<LiveRange*> adj_LRs = ReconcileData::sorted_adj_LRs(this);

    if (pref_class == CALLEE_SAVED) {
	for (List_iterator<LiveRange*> iter(adj_LRs); iter != 0; iter++) {
	    LiveRange* lr = *iter;
	    int reg = lr->reg_num();
	    if (callee_pool.is_member(reg) && !_forbidden.is_member(reg)) {
		prefered_reg = reg;
		break;
	    }
	}
    }
    else { 
	// (pref_class == CALLER_SAVED)
	// use CALLER and CALLEE as available
	for (List_iterator<LiveRange*> iter(adj_LRs); iter != 0; iter++) {
	    LiveRange* lr = *iter;
	    int reg = lr->reg_num();
	    // if (caller_pool.is_member(reg) && !_forbidden.is_member(reg)) {
	    if (!_forbidden.is_member(reg)) {
		prefered_reg = reg;
		break;
	    }
	}
    }


    // 3. Now, try global prefered register
    if (prefered_reg < 0) {
	if (pref_class == CALLEE_SAVED) {
	    if (ReconcileData::_pref_callee_map.is_bound(_variable.vr_num())) {
		int global_reg = ReconcileData::_pref_callee_map.value(_variable.vr_num());
		if (candidate_regs.is_member(global_reg)
		    && !_forbidden.is_member(global_reg)) {
		    prefered_reg = global_reg;
		}
	    }
	}
	else {
	    if (ReconcileData::_pref_caller_map.is_bound(_variable.vr_num())) {
		int global_reg = ReconcileData::_pref_caller_map.value(_variable.vr_num());
		if (candidate_regs.is_member(global_reg)
		    && !_forbidden.is_member(global_reg)) {
		    prefered_reg = global_reg;
		}
	    }
	}
    }

    // 4. This is first time register selection for this VR
    //    Try to see, any available which is not interfered
    if (prefered_reg < 0) {
	// find all registers which is used in neighboring LR
	// and avoid to use them
	

	List_set<int> unprefered_regs;
	// scan all the registers of interfered LiveRange
	// and collect them as unprefered_reg
	for (List_set_iterator<LiveRange*> lr_iter(_inf_set); lr_iter != NULL; lr_iter++) {
	    LiveRange* inf_lr = *lr_iter;
	    if (pref_reg_map->is_bound(inf_lr->variable().vr_num())) {
		unprefered_regs+= pref_reg_map->value(inf_lr->variable().vr_num());
	    }
	}

	List_set<int> pref_regs= candidate_regs;
	pref_regs -= unprefered_regs;
	for (List_set_iterator<int> iter(pref_regs); iter != 0; iter++) {
	    if (_forbidden.is_member(*iter) == false) {
		prefered_reg = *iter;
		pref_reg_map->bind(_variable.vr_num(), prefered_reg);
		break;
	    }
	}
    }


    // 5. This is first time register selection for this VR
    if (prefered_reg < 0) {
	if (pref_class == CALLEE_SAVED) {
	    for (List_set_iterator<int> iter(callee_pool); iter != 0; iter++) {
		if (_forbidden.is_member(*iter) == false) {
		    prefered_reg = *iter;
		    break;
		}
	    }
	    if (prefered_reg == -1) {
		// no CALLER saved register available
		// use CALLEE saved register, if any
		pref_class = CALLER_SAVED;

		for (List_set_iterator<int> iter(caller_pool); iter != 0; iter++) {
		    if (_forbidden.is_member(*iter) == false) {
			prefered_reg = *iter;
			break;
		    }
		}
	    }
	}
	else {
	    for (List_set_iterator<int> iter(caller_pool); iter != 0; iter++) {
		if (_forbidden.is_member(*iter) == false) {
		    prefered_reg = *iter;
		    break;
		}
	    }

	    if (prefered_reg == -1) {
		// no CALLER saved register available
		// use CALLEE saved register, if any
		pref_class = CALLEE_SAVED;
		
		for (List_set_iterator<int> iter(callee_pool); iter != 0; iter++) {
		    if (_forbidden.is_member(*iter) == false) {
			prefered_reg = *iter;
			break;
		    }
		}
	    }
	}
    }
    return prefered_reg;
}
#endif
	    

int
LiveRange::reg_num()const {
    return _reg_num;
}


void
LiveRange::reconcile_pre_lr() {
    if (_pre_lr == NULL)
	return;

    if (reg_bind_state() == LiveRange::UNDEFINED) {
	assert(0);
    }
    else if (reg_bind_state() == LiveRange::BOUND) {
	
	switch(_pre_lr->reg_bind_state()) {
	case LiveRange::UNDEFINED:
	    // delay
	    break;

	case LiveRange::BOUND:
	    // both current variable and preceeding variable are binded
	    // if physical registers b/w them are different, COPY code is needed
	    if (reg_num() != _pre_lr->reg_num()) {
		Op* new_op = copy_op(_pre_lr->_variable, _variable);
		El_insert_op_before(_live_ops.head()->parent(), 
				    new_op, _live_ops.head());
	    }
	    break;

	case  SPILLED: {
	    SpillCodeUtils::load_before(_variable, _live_ops.tail());
	}
	break;

	default:
		assert(0);

	}
    }
    else if (reg_bind_state() == LiveRange::SPILLED) {
	switch(_pre_lr->reg_bind_state()) {
	case LiveRange::UNDEFINED:
	    // delay
	    break;

	case LiveRange::BOUND: {
	    SpillCodeUtils::load_after(_pre_lr->_variable, 
				       _pre_lr->_live_ops.head());
	}
	break;

	case  SPILLED:
	    // both spilled
	    break;

	default:
		assert(0);

	}

    }
    else {
	assert(0);
    }
}


void
LiveRange::reconcile_post_lr() {
    if (_post_lr == NULL)
	return;

    if (reg_bind_state() == LiveRange::UNDEFINED) {
	assert(0);
    }
    else if (reg_bind_state() == LiveRange::BOUND) {
	
	switch(_post_lr->reg_bind_state()) {
	case LiveRange::UNDEFINED:
	    // delay
	    break;

	case LiveRange::BOUND:
		// both current variable and preceeding variable are binded
	    // if physical registers b/w them are different, COPY code is needed
	    if (reg_num() != _post_lr->reg_num()) {
		Op* new_op = copy_op(_variable, _post_lr->_variable);
		El_insert_op_after(_live_ops.head()->parent(), 
					new_op, _live_ops.head());
	    }
	    break;

	case LiveRange::SPILLED: {
	    SpillCodeUtils::store_after(_variable, _live_ops.head());
	}
	break;

	default:
		assert(0);

	}
    }
    else if (reg_bind_state() == LiveRange::SPILLED) {
	switch(_post_lr->reg_bind_state()) {
	case LiveRange::UNDEFINED:
	    // delay
	    break;

	case LiveRange::BOUND: {
	    SpillCodeUtils::load_after(_post_lr->_variable, _live_ops.head());
	}
	break;

	case LiveRange::SPILLED:
	    // both spilled
	    break;

	default:
		assert(0);

	}

    }
    else {
	assert(0);
    }
}


/*
 * set expected save cost by register allocation 
 */
void
LiveRange::set_priority() {
    Op* last_op = _live_ops.head();
    for (Dlist_iterator<Op*> op_iter(_live_ops); op_iter != 0; op_iter++) {
	Op* op = *op_iter;
	if (is_brl(op)) {
	    if (op != last_op) {
		// exclude last brl operation
		// variable is not live-out from brl operation
		_brl_num++;
	    }
	} 
    }

    for (Dlist_iterator<El_ref> iter(_live_refs); iter != 0; iter++) {
	El_ref& ref = *iter;
	El_ref_type ref_type= ref.get_ref_type();
	if (ref_type == EXP_SRC) {
	    _def_num++;
	    //_priority += LOAD_LATENCY * op->weight();
	    //_priority += LOAD_LATENCY; 
	}
	else if (ref_type == EXP_DEST) {
	    _use_num++;
	    //_priority += STORE_LATENCY *  op->weight();
	    //_priority += STORE_LATENCY;
	}
    }


    // callee saved register needs to spilling that register at the function
    // boundaries (in prologue and epilogue).
    // This extra cost can be spread out to all live ranges in this function
    // which is using that callee saved register.
    // To estimate this cost, I use 1/2 in the following code
    _spill_cost = _def_num * STORE_LATENCY + _use_num * LOAD_LATENCY;
    _caller_benefit = _spill_cost - _brl_num * (STORE_LATENCY+LOAD_LATENCY);
    _callee_benefit = _spill_cost - 0.5 * (STORE_LATENCY+LOAD_LATENCY);
    
    if (_callee_benefit > _caller_benefit) {
	_priority = _callee_benefit;
	_pref_class = CALLEE_SAVED;
    }
    else {
	_priority = _caller_benefit;
	_pref_class = CALLER_SAVED;
    }
}



//
// LiveRange::set_live_region
//
// Save current snapshot of Pred_cookie into _pred_pool and update a region
// with pgred_ condition
//
#if 0
void
LiveRange::set_live_region(const int index_, const Pred_cookie& pred_) {
    _pred_pool += pred_;
    _live_region[index] = _pred_pool.find(pred_);
    
}
#endif


////////////////////////////////////////////////////////////////////////////////
#if EDGE_BASED
void
LiveRange::add_live_region(const Edge* edge_, const Pred_cookie& pred_) {
    _live_regions += edge_;
    Pred_cookie* pos = _pred_pool.find_and_add(pred_);
    _live_segs.bind(edge_, pos);
}

#else

void
LiveRange::add_live_region(Op* op_, const Pred_cookie& pred_) {
    Dnode<Op*>* op_ptr = _live_ops.find(op_);
    if (op_ptr == NULL) {
	_live_ops.push_tail( op_ );
	Pred_cookie* pos = _pred_pool.find_and_add((Pred_cookie&)pred_);
	_live_regions.bind(op_, pos);
    }
    else {
	// rebind operation with new Pred_cookie
	Pred_cookie* pos = _pred_pool.find_and_add((Pred_cookie&)pred_);
	_live_regions.bind(op_, pos);
    }
}
#endif


////////////////////////////////////////////////////////////////////////////////
void
LiveRange::add_live_ref(El_ref& ref_) {
    _live_refs.push_tail(ref_);
}


//
// LiveRange::set_live_region
//
// Save current snapshot of Pred_cookie into _pred_pool and update a region
// with pred_ condition
//
#if 0	// implemented with Operation
void
LiveRange::set_live_region(const int index_, const Pred_cookie& pred_) {
    _pred_pool += pred_;
    _live_region[index] = _pred_pool.find(pred_);
    
}
 // implemented with Edges
void 
LiveRange::set_live_region(const Edge* c_edge_, const Pred_cookie& pred_) {
    _pred_pool += pred_;
    _live_regions.bind(c_edge_, _pred_pool.find(pred_));
    
}
#endif


void 
LiveRange::update_interfered(LiveRange* lr_) {

    bool is_interfered = false;

    if (_live_refs.size() == 0) {
	// this is pass-through
	// will interfere anyway
	_inf_set += lr_;
	lr_->_inf_set += (this);
    }
    else if (lr_->_live_refs.size() == 0) {
	// this is pass-through
	// will interfere anyway
	_inf_set += lr_;
	lr_->_inf_set += (this);
    }
    else {
	for (Dlist_iterator<El_ref> iter1(_live_refs); iter1 != 0; iter1++) {
	    El_ref ref = *iter1;
	    switch (ref.get_ref_type()) {
	    case EXP_DEST:
	    case IMP_DEST:
	    case EXP_SRC:
	    case IMP_SRC: 
	    case PRED_SRC:
	    {
		if (!lr_->_live_regions.is_bound(ref.get_op())) {
		    // currrent operation is not live in lr_
		    break;
		}

#if EDGE_BASED
		Edge* c_edge = get_outgoing_CONTROL0_edge(ref.op());
		Pred_cookie pred1 = _live_segs.value(c_edge);
		Pred_cookie pred2 = lr_->_live_segs.value(c_edge);
#else
		Pred_cookie* pred1 = _live_regions.value(ref.get_op());
		Pred_cookie* pred2 = lr_->_live_regions.value(ref.get_op());
#endif
		if ( !pred1->is_disjoint(*pred2) ) {
		    is_interfered = true;
		}
	    }
	    break;
	    
	    default:
		// Is this valid case? Check this.
		assert(0);
	    }
	}

	for (Dlist_iterator<El_ref> iter2(lr_->_live_refs); iter2 != 0; iter2++) {
	    El_ref ref = *iter2;
	    switch (ref.get_ref_type()) {
	    case EXP_DEST:
	    case IMP_DEST:
	    case EXP_SRC:
	    case IMP_SRC:
	    case PRED_SRC:
	    {
		if (!_live_regions.is_bound(ref.get_op())) {
		    // currrent operation is not live in lr_
		    break;
		}

		Pred_cookie* pred1 = _live_regions.value(ref.get_op());
		Pred_cookie* pred2 = lr_->_live_regions.value(ref.get_op());

		if ( !pred1->is_disjoint(*pred2) ) {
		    is_interfered = true;
		}
	    }
	    break;

	    default:
		// Is this valid case? Check this.
		assert(0);
	    }
	}

	if (is_interfered) {
	    // interfered
	    _inf_set += lr_;
	    lr_->_inf_set += (this);
	}
    }
}


void
LiveRange::delete_interfered(const LiveRange* lr_) {
    _inf_set -= ( (LiveRange*)lr_);
}


void
LiveRange::add_forbidden(List_set<int> regs_) {
    _forbidden += regs_;
}


void
LiveRange::add_forbidden(const int reg_num_) {
    _forbidden += reg_num_;
}


// find Pred_cookie for the Op
const Pred_cookie&
LiveRange::predicate(Op* op_)const {
    Pred_cookie* pred = _live_regions.value(op_);
    return (*pred);
}


List_set<const Op*>
LiveRange::EntryOps()const {
    List_set<const Op*> op_set;
    for (Dlist_iterator<Op*> iter(_live_ops); iter!=0; iter++) {
	if (is_control_merge(*iter))
	    op_set += *iter;
    }
    return op_set;
}


List_set<const Op*>
LiveRange::ExitOps()const {
    List_set<const Op*> op_set;
    for (Dlist_iterator<Op*> iter(_live_ops); iter!=0; iter++) {
	if (is_branch(*iter))
	    op_set += *iter;
    }
    return op_set;
}


List_set<Edge*>
LiveRange::entry_edges()const {
    List_set<const Op*> entry_ops = EntryOps();
    List_set<Edge*> entry_edges;

    for (List_set_iterator<const Op*> iter(entry_ops); iter != 0; iter++) {
	Op* op = (Op*)(*iter);
	for (Op_inedges it(op); it!=0; it++) {
	    entry_edges += (*it);
	}
    }
    return entry_edges;
}

    
List_set<Edge*>
LiveRange::exit_edges()const {
    List_set<const Op*> exit_ops = ExitOps();
    List_set<Edge*> exit_edges;

    for (List_set_iterator<const Op*> iter(exit_ops); iter != 0; iter++) {
	Op* op = (Op*)(*iter);
	for (Op_outedges it(op); it!=0; it++) {
	    exit_edges += (*it);
	}
    }
    return exit_edges;
}
    
//
// number of function calls in the liverange
int
LiveRange::brl_ops_num()const {
    return _brl_num;
}

double
LiveRange::reg_bind_benefit(const RegCallingConvention& reg_conv) {
    if (reg_conv == CALLER_SAVED)
	return caller_benefit();
    else if (reg_conv == CALLEE_SAVED) {
	//return callee_benefit();
	return _priority;
    }
    else
	return 0;
}

double
LiveRange::caller_benefit()const {
    return _caller_benefit;
}

double
LiveRange::callee_benefit()const {
    return _callee_benefit;
}

/*
 * Following 2 functions are refered from IMPACT implementation.
 * It should be revised with correct value later.
 */
int 
LiveRange::caller_cost()const {

    /* 
     * In the case of the HPPA, the caller cost is one save and one restore
     * per subroutine call.  In the case of leaf functions, there is no penalty
     * for the use of caller save registers.
     */
    int cost = brl_ops_num() * (STORE_LATENCY + LOAD_LATENCY);
    return cost;
}

int 
LiveRange::callee_cost()const {
  /* 
   * In the case of the HPPA, the callee cost is one save at the beginning
   * of the function and one restore and the end, of the function
   */
    //return(2);
    return (STORE_LATENCY + LOAD_LATENCY);
}

bool
LiveRange::is_leaf()const {
    if (brl_ops_num() > 0)
	return false;
    else
	return true;
}

// check it current LiveRange is inside of region ONLY
bool
LiveRange::is_intra_region()const {
    bool flag  = true;

    for (List_set_iterator<const Op*> iter1(EntryOps()); iter1 != 0; iter1++) {
	if (_region->is_entry_op((Op*)*iter1)) {
	    flag = false;
	    break;
	}
    }
    if (!flag)
	return flag;

    for (List_set_iterator<const Op*> iter2(ExitOps()); iter2 != 0; iter2++) {
	Op* exit_op = (Op*)*iter2;
	for (Op_pseudo_sources lives(exit_op); lives != 0; lives++) {
	    El_ref cur_ref = lives.get_ref();
	    Operand& var = cur_ref.get_operand();
	    if (var.is_reg()) {
		if (var.vr_num() == _variable.vr_num()) {
		   flag = false;
		   break; 
		}
	    }
	}
    }
    return flag;
}


bool
LiveRange::is_split()const {
    if (_pre_lr || _post_lr)
	return true;
    else
	return false;
}


Op*
LiveRange::copy_op(const Operand& src_operand_, const Operand& dest_operand_)const
{
    assert(src_operand_.file_type() == dest_operand_.file_type());

    Op* copy_op = NULL;

    switch(_variable.file_type()) {
    case GPR:
    case CR:
	copy_op = new Op( (Opcode)MOVE);
	break;
    case FPR:
	copy_op = new Op( (Opcode)MOVEF_D);
	break;
    case PR:
	copy_op = new Op( (Opcode)CMPP_W_EQ_UC_UC);
	break;
    case BTR:
	copy_op = new Op( (Opcode)MOVE);
	break;
    default:
	break;
    }

    copy_op->set_dest(copy_op->first_dest(), (Operand&)dest_operand_);
    copy_op->set_src(copy_op->first_src(), (Operand&)src_operand_);
    Operand pred_operand(new Pred_lit(true));
    copy_op->set_src(PRED1, pred_operand);
    copy_op->set_flag(EL_OPER_SPILL_CODE);
    
    return copy_op;
}

void
LiveRange::print()const {
    cout << _variable << endl;
    cout << *_region << endl << flush;
}

/*************************************************************************
 *
 * class LiveRangePair
 *
 ************************************************************************/
LiveRangePair::LiveRangePair() {
    _e = NULL;
    _src_lr = NULL;
    _dest_lr = NULL;
}

LiveRangePair::LiveRangePair(Edge* e, LiveRange* src_lr, LiveRange* dest_lr) {
    _e = e;
    _src_lr = src_lr;
    _dest_lr = dest_lr;
}
