/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   LiveRange.h
// Author: Hansoo Kim
///////////////////////////////////////////////////////////////////////////////

#ifndef _LiveRange_H_
#define _LiveRange_H_

// LiveRange was constructed with Operation originally, but I believe liveness 
// information is realted to Edge rather than Operation. In new implementation,
// LiveRange has set of Edge's where the varaialve is live instead of Operation's
// 7.17.97 -- H.Kim
// After the discussion with Vinod, we decided to implement Live Range with operation.
// since source operand and destination operand in a operation may interfere by 
// latency
// Aug 5, 97
#define EDGE_BASED	0

/*
#include <Analysis/pred_interface.h>
#include <Tools/pred_interface.h>
#include <Graph/ref.h>
*/

#include <attributes.h>
#include <pred_interface.h>
#include <ref.h>
#include <list_set.h>
#include <dlist.h>
#include "RegisterBank.h"

class Edge;
class Op;

class LiveRange {

public:
    enum RegBindState {
	UNDEFINED,
	BOUND,
	SPILLED,
	DELAYED
    };

public:
    LiveRange(const Operand& variable_, const Compound_region* region_);

    inline const Dlist<Edge*>& live_regions()const;
    const List_set<LiveRange*>& inf_set()const { return _inf_set; }

    bool	is_constrained()const;
    bool	is_leaf()const;
    RegBindState reg_bind_state()const { return _reg_bind_state; }
    void	reg_bind_state(RegBindState state) { _reg_bind_state = state; }

    /*
    inline Bool is_bound()const;	// Is LR bound to physical register?
    inline Bool is_processed()const;	// Is register allocation processed?
    void	set_processed(Bool tag_) { _processed = tag_; }

    Bool 	is_reconciled()const { return _reconciled; }
    void	set_reconciled(Bool tag_) { _reconciled = tag_; }
    Bool 	is_delayed_bind()const { return _delayed_bind; }
    void	set_delayed_bind(Bool tag_) { _delayed_bind = tag_; }
    */

    bool	is_intra_region()const;
    bool	is_split()const;

    const Compound_region* region()const { return _region; }
    const Dlist<El_ref>& live_refs() {return _live_refs;}
    const Dlist<Op*>& live_ops()const { return _live_ops; }
    const Map<Op*, Pred_cookie*>& live_regions() { return _live_regions; }
    const Operand& variable()const {return _variable;}
    const RegCallingConvention& reg_convention()const {return _reg_convention;}
    const double 	priority()const { return _priority; }
    const List_set<int>& forbidden()const { return _forbidden; }
    const Pred_cookie& predicate(Op*)const;
    List_set<const Op*> EntryOps()const;
    List_set<const Op*> ExitOps()const;
    List_set<Edge*>	entry_edges()const;
    List_set<Edge*> exit_edges()const;
    Op* copy_op(const Operand& src_operand_, const Operand& dest_operand_)const;
    LiveRange*	pre_lr()const {return _pre_lr;}
    LiveRange*	post_lr()const {return _post_lr;}


    void	set_priority();
    void	add_live_region( Op* op_, const Pred_cookie& pred_);
    void	add_live_ref(El_ref& ref_);
    void	add_forbidden(List_set<int> regs_);
    void	update_interfered(LiveRange* lr);
    void	delete_interfered(const LiveRange* lr_);
    void	bind_register(int reg_num_);
    void	bind_register();
    void	spilling();
    void	set_pre_lr(LiveRange* lr_);
    void	set_post_lr(LiveRange* lr_);

    int		reg_num()const;
    int		vr_num()const { return _variable.vr_num(); }
    int		func_num()const { return brl_ops_num(); }  // number of function call

    int		find_split_register();
    int 	find_bound_register();
    int 	find_register_in_pref_class();
    int 	find_register_in_reverse_class();
    int 	find_global_register();

    RegCallingConvention pref_reg_class();
    double	reg_bind_benefit(const RegCallingConvention& reg_conv);
    double	caller_benefit()const;
    double	callee_benefit()const;

    void 	reconcile_pre_lr();
    void	reconcile_post_lr();

    static Op*  pos_op(const Operand& var_);
    static Op*  store_op(const Operand& var_);
    static Op*  load_op(const Operand& var_);

    void	print()const;

private:
    void	add_forbidden(const int reg_num_);
    // void	add_spill_code();

    int 	brl_ops_num()const;	// number of BRL operation (function calling)
    int		caller_cost()const;
    int		callee_cost()const;

    Compound_region*	_region;	// Compund Region where this LR
						// belongs to

#if EDGE_BASED
    Dlist<Edge*>		_live_regions;	// listed by topological sort order
    List_set<Pred_cookie>	_pred_pool;
    Hash_map<Edge*, Pred_cookie*> _live_segs;	
#else
    // set of live Operaion (or basic blocks in Chow and Hennessy)
    // If Op[i] in _int_op_map is belonging to this LiveRange,
    // then _live_regions[i] is pointing to the Pred_cookie condition 
    // where the operand is live
    // else _live_regions[i] is NULL
    Dlist<Op*>			_live_ops;
    List_set<Pred_cookie>	_pred_pool;
    Map<Op*, Pred_cookie*>	_live_regions;	
#endif

    Dlist<El_ref>	_live_refs; // information for refering variable
    List_set<LiveRange*> _inf_set;
    List_set<int> 	_forbidden;
    Operand		_variable;
    LiveRange*		_pre_lr;
    LiveRange*		_post_lr;
    int 		_reg_num;

    int			_brl_num;
    int			_def_num;
    int			_use_num;
    
    double		_spill_cost;
    double		_caller_benefit;
    double		_callee_benefit;
    double		_priority;

    RegCallingConvention  _pref_class;		// prefered reg class
    RegCallingConvention  _reg_convention;	// allocated reg class

    RegBindState	_reg_bind_state;

    bool		_processed;
    bool		_bound;

    // following two members are for Reconcile()
    bool		_delayed_bind;
    bool		_reconciled;

    RegisterBank*	_reg_bank;
};

/*
inline Bool 
LiveRange::is_processed()const {
    return _processed;
}
*/

/*
inline Bool
LiveRange::is_bound()const {
    if (_reg_bind_state == BOUND)
	return TRUE;
    else
	return FALSE;
}
*/


class LiveRangePair {
public:
    LiveRangePair();
    LiveRangePair(Edge* e, LiveRange* src_lr, LiveRange* dest_lr);

    bool operator==(const LiveRangePair& b)const {
	if (_e != b._e)
	    return false;
	else if (_src_lr != b._src_lr)
	    return false;
	else if (_dest_lr != b._dest_lr)
	    return false;
	else 
	    return true;
    }

    bool operator!=(const LiveRangePair& b)const {
        return ( !(*this == b) );
    }

    Edge* _e;
    LiveRange* _src_lr;
    LiveRange* _dest_lr;
};


enum EdgeDir {NONE, ENTRY, EXIT, ENTRY_EXIT, ALLEDGES};
typedef Pair<Edge*, EdgeDir> DirEdge;

class EdgedLiveRange {
public:
    EdgedLiveRange(): _d(DirEdge((Edge*)NULL, NONE)), _b(NULL) {}
    EdgedLiveRange(const DirEdge& d, LiveRange* b): _d(d), _b(b) {}

    EdgedLiveRange& operator=(const EdgedLiveRange& elr) {
	_b = elr._b;
	_d = elr._d;
	return *this;
    }

    const LiveRange* live_range() const {
        return _b;
    }

    LiveRange* live_range() {
        return _b;
    }

    const DirEdge& diredge() const {
        return _d;
    }

    const Edge* edge() const {
        return _d.first;
    }

    Edge* edge() {
        return _d.first;
    }

    const EdgeDir edge_dir()const {
	return _d.second;
    }

    bool operator<(const EdgedLiveRange& bb)const {
	Control_flow_freq* cff1 = get_control_flow_freq(_d.first);
	Control_flow_freq* cff2 = get_control_flow_freq(bb._d.first);

        return (cff1->freq < cff2->freq);
    }

    bool operator==(const EdgedLiveRange& b)const {
        return (_d == b._d && _b == b._b);
    }

    bool operator!=(const EdgedLiveRange& b)const {
        return ( !(*this == b) );
    }

    bool is_null()const {
	return (_b == NULL && _d.first == NULL);
    }

private:
    DirEdge _d;
    LiveRange* _b;
};

#endif
