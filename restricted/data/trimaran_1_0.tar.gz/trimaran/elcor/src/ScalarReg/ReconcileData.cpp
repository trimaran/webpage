/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   ReconcileData.cpp
// Author: Hansoo Kim
///////////////////////////////////////////////////////////////////////////////

#include "ReconcileData.h"

#include <edge.h>
#include <list_set.h>

// list of LiveRange map for each VR(Virtual Register)
Map<VR_Reg, List<LiveRange*> > ReconcileData::_global_LR_map;

// prefered register map for each VR inside Procedure used
Map<int, int> ReconcileData::_pref_caller_map;
Map<int, int> ReconcileData::_pref_callee_map;

// stack position information for VR spilling
SpillStack ReconcileData::_spill_stack;


void
ReconcileData::clear() {
    _spill_stack.clear();
    _pref_caller_map.clear();
    _pref_callee_map.clear();
    _global_LR_map.clear();
}

void
ReconcileData::add2global_LR_map(LiveRange* l) {
    const VR_Reg& vr = l->variable().vr_num();
    if (_global_LR_map.is_bound(vr)) {
        List<LiveRange*>& lr_list = _global_LR_map.value(vr);
        lr_list.add_tail(l);  
    } 
    else {
        _global_LR_map.bind(vr, *(new List<LiveRange*>(l)));
    }
}

List<LiveRange*>
ReconcileData::global_LRs(const LiveRange* lr_) {
    List<LiveRange*> lr_list;
    VR_Reg vr_num = lr_->variable().vr_num();
    if (_global_LR_map.is_bound(vr_num)) {
	lr_list = _global_LR_map.value(vr_num);
    }
    return lr_list;
}


List<LiveRangePair>
ReconcileData::sorted_adj_eLRs(LiveRange* lr_) {
    List<LiveRangePair> adj_LRs;

    List_set<Edge*> entry_edges = lr_->entry_edges();
    List_set<Edge*> exit_edges = lr_->exit_edges();

    List<LiveRange*> lr_list;
    VR_Reg vr_num = lr_->variable().vr_num();
    if (_global_LR_map.is_bound(vr_num)) {
	lr_list = _global_LR_map.value(vr_num);
    }

    // _global_LR_map is sorted by weight

    for (List_iterator<LiveRange*> iter(lr_list); iter != 0; iter ++) {
	LiveRange* adj_lr = *iter;
	if (adj_lr == lr_)
	    continue;	// Skip

	List_set<Edge*> intersect_e;

	List_set<Edge*> adj_entry_edges = adj_lr->entry_edges();
	List_set<Edge*> adj_exit_edges = adj_lr->exit_edges();

	// find intersect
	intersect_e = entry_edges;
	intersect_e *= adj_exit_edges;

	// If Src LIveRange is from HyperBlock, it can be bigger than 1
	// add them all

	for (List_set_iterator<Edge*> eIter( intersect_e); eIter!=0; eIter++) {
	    // adj_lr is SRC, lr_ is DEST
	    Edge* e = *eIter;
	    adj_LRs.add_tail( LiveRangePair(e, adj_lr, lr_)  );
	}

	intersect_e = exit_edges;
	intersect_e *= adj_entry_edges;

	for (List_set_iterator<Edge*> eIter2( intersect_e); eIter2!=0; eIter2++) {
	    // lr_ is SRC, adj_lr is DEST
	    Edge* e = *eIter2;
	    adj_LRs.add_tail( LiveRangePair(e, lr_, adj_lr)  );
	}
    }

    return adj_LRs;

}


List<LiveRange*>
ReconcileData::sorted_adj_LRs(const LiveRange* lr_) {
    List<LiveRange*> adj_LRs;

    List_set<Edge*> entry_edges = lr_->entry_edges();
    List_set<Edge*> exit_edges = lr_->exit_edges();

    List<LiveRange*> lr_list;
    VR_Reg vr_num = lr_->variable().vr_num();
    if (_global_LR_map.is_bound(vr_num)) {
	lr_list = _global_LR_map.value(vr_num);
    }
	
    for (List_iterator<LiveRange*> iter(lr_list); iter != 0; iter ++) {
	LiveRange* adj_lr = *iter;
	assert(adj_lr->variable() == lr_->variable());

	List_set<Edge*> adj_entry_edges = adj_lr->entry_edges();
	List_set<Edge*> adj_exit_edges = adj_lr->exit_edges();

	// find intersect
	adj_entry_edges *= entry_edges;
	if (adj_entry_edges.size() > 0) {
	    adj_LRs.add_tail( adj_lr );
	    continue;
	}

	adj_exit_edges *= entry_edges;
	if (adj_exit_edges.size() > 0) {
	    adj_LRs.add_tail( adj_lr );
	    continue;
	}
    }

    return adj_LRs;
}

List_set<int>	
ReconcileData::usedRegs(const LiveRange* lr_) {
    List_set<int> usedRegs;
    List<LiveRange*> global_LRs = ReconcileData::global_LRs(lr_);

    for (List_iterator<LiveRange*> iter(global_LRs); iter != 0; iter++) {
	LiveRange* lr = *iter;
	usedRegs += lr->reg_num();
    }
    return usedRegs;

}

