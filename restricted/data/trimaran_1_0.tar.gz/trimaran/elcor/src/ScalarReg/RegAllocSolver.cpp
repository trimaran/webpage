/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   RegAllocSolver.cpp
// Author: Hansoo Kim
///////////////////////////////////////////////////////////////////////////////

#ifdef __GNUC__
#include <typeinfo>
#endif

/*
#include <Analysis/dfa.h>
#include <Analysis/pred_analysis.h>
#include <Mdes/intf.h>
#include <Mdes/mdes.h>
#include <Graph/iterators.h>
#include <Graph/edge_utilities.h>
#include <Graph/opcode_properties.h>
*/

#include "dfa.h"
#include "pred_analysis.h"
#include "intf.h"
#include "mdes.h"
#include "iterators.h"
#include "edge_utilities.h"
#include "opcode_properties.h"

#include "LiveRange.h"
#include "RegAllocSolver.h"
#include "RegisterBank.h"

/********************************************************************************
** class RegAllocSolver
********************************************************************************/
RegAllocSolver::RegAllocSolver(Compound_region* r_) {
    _region = r_;

    // initialize <int, OP*> map
    // needs mapping each operation to number
    // Is this map necessay? TBD
#if 0
    int index = 0;
    for(Region_all_ops op_iter(r_) ; op_iter != 0 ; op_iter++) {
	Op* cur_op = *op_iter ;
	_int_op_map.bind(index, cur_op);
	_op_int_map(cur_op, index);
	index++;
    }
#endif

    // create local VR_map and PQS info
    delete_local_analysis_info_for_all_hbs_bbs(r_);
    create_local_analysis_info_for_all_hbs_bbs(r_);


    // create LiveRange Entry
    // create_LR_map(r_);

    construct_live_ranges(r_);

    assert(current_MDES);	// current_MDES is defined as global static variable
                                // in <Mdes.intf.h>
    for (int i = 0; i <current_MDES->get_MDES_num_reg_types(); i++) {
	Reg_descr* cur_descr = current_MDES->get_MDES_reg_descr(i);
	char* file_name = cur_descr->get_aname();
	RegAllocSolverData* s_data = new RegAllocSolverData(file_name);
	// s_data->_reg_size = cur_descr->get_scap() + cur_descr->get_rcap();
	s_data->_reg_size = cur_descr->get_scap();
	for (List_set_iterator<LiveRange*> iter(_lrs); iter != 0; iter++) {
	    const Operand var = (*iter)->variable();
	    if ( var.physical_file_type() == (eString) file_name) {
		s_data->_lrs += *iter;
		//_lrs -= *iter;
	    }
	}

	if (s_data->_lrs.size() > 0) {
	    _data_list.push_tail(s_data);
	    s_data->process_coloring();
	}
    }
}

/* Elcor doesn't like it when this destuctor is put in
 * the header file (aCC complains, gcc is silent), so
 * I assume this should not be called. -JCG 8/17/98
 */
#if 0
RegAllocSolver::~RegAllocSolver() {
    for (List_set_iterator<LiveRange*> lr_iter1(_lrs);
	 lr_iter1 != 0; lr_iter1++) {
	LiveRange* lr_ptr = *lr_iter1;
	delete (lr_ptr);
    }

    for (Dlist_iterator<RegAllocSolverData*> iter(_data_list);
	 iter != 0; iter++) {

	RegAllocSolverData* solver_data = *iter;
	delete (solver_data);
    }

}
#endif


//
//	create all LiveRange for VR in Region
//
void
RegAllocSolver::create_LR_map(Compound_region* r_) {
    if (r_->is_bb() || r_->is_hb()) {
	VR_map* local_map = get_local_vr_map(r_);
	for (int i = 0; i < local_map->vr_count; i++) {
	    if (local_map->index_to_vr[i].is_reg() 
		&& !_lr_map.is_bound(local_map->index_to_vr[i])) {
		// only Reg operand is the domain for coloring
		LiveRange* lr = new LiveRange(local_map->index_to_vr[i], _region);
		_lrs += lr;
		_lr_map.bind(local_map->index_to_vr[i], lr);
	    }
	}
    }
    else {
        for (Region_subregions subr(r_); subr != 0; subr++) {
            Compound_region* subregion = (Compound_region*)*subr;
            create_LR_map(subregion);
	}
    }
}


void
RegAllocSolver::construct_live_ranges(Compound_region* r_) 
{
    if (r_->is_bb() || r_->is_hb()) {

	// initialize <int, OP*> map
	// needs mapping each operation to number
#if 0
	int index = 0;
	for(Region_all_ops op_iter(r_) ; op_iter != 0 ; op_iter++) {
	    Op* cur_op = *op_iter ;
	    _int_op_map.bind(index, cur_op);
	    _op_int_map(cur_op, index);
	    index++;
	}
#endif

	/*
	// create Liveness and Ded for every operation
	// initialize DList<LiveRange*>
	VR_map* local_map = get_local_vr_map(r_);
	for (int i = 0; i < vr_count; i++) {
	    if (index_to_vr[i].is_vr() && unbinded ) {
		LiveRange* lr = new LiveRange(index_to_vr[i]);
		_lr_map.bind(index_to_vr[i], lr);
	    }
	}
	*/

	Map<Operand, Pred_cookie> map;
	local_liveness_walk(r_, map);
    }
    else {
	// traverse all sub-region by topological sort order
	Alist_region_tiling_graph c_graph(r_,GRAPH_OPS_PLUS );
	for (Alist_graph_post_dfs r_iter(c_graph, UP);
	     r_iter != 0; r_iter++) {
	    int index = *r_iter;
	    // construct_live_ranges(dynamic_cast<Compound_region*>(c_graph.b_map[index]));
	    construct_live_ranges((Compound_region*)(c_graph.b_map[index]));
	}
    }
}




// This is the code for initializing pseudo sources before you call the
// Op_pseudo_sources iterator. Call this function before any call to
// Op_pseudo_sources, preferably call it right in the beginning of the
// intra-region allocation.
//
// This is a cleaned-up version of some of the code in reaching definitions. 
// See the function 
//  Reaching_defs_maps::Reaching_defs_maps 
// (between the comments // use liveness and // create the operand map)
// in file
//	 reaching_defs_solver.cpp.
//
//
// Vinod Kathail

static void 
initialize_pseudo_sources(Region* r)
{
    //
    // Use liveness information for entry/exit processing
    //
    // Compute pseudo defs for entry operations
    //
    for (Region_entry_ops en_op_iter(r) ; en_op_iter != 0 ; en_op_iter++) {
	Op* cur_op = *en_op_iter ;
	List<Operand>* entry_pseudo_defs = 
	    (List<Operand>*)get_generic_attribute(cur_op, "entry_pseudo_defs") ;
	if (entry_pseudo_defs == NULL) {
	    entry_pseudo_defs = new List<Operand>();
	}
	else {
	    entry_pseudo_defs->clear() ;
	}
	for(Region_entry_edges en_edge_iter(r) ; en_edge_iter != 0 ;
	    en_edge_iter++) {
	    Edge* cur_edge = *en_edge_iter ;
	    if (cur_edge->dest() != cur_op) continue ;
	    
	    Liveness_info* linfo = get_liveness_info(cur_edge) ;
	    if (linfo) {
		for (Liveness_info_iterator li(*linfo) ; li != 0 ; li++) {
		    Operand& tmpoper = *li ;
		    if (!entry_pseudo_defs->is_member(tmpoper)){
			entry_pseudo_defs->add_tail(tmpoper) ;
		    }
		}
	    }
	}

	if (entry_pseudo_defs->is_empty()) {
	    delete entry_pseudo_defs ;
	}
	else {
	    set_generic_attribute(cur_op, "entry_pseudo_defs", entry_pseudo_defs);
	}
    }
   
    //
    // Now compute pseudo uses for exit ops
    //

    for(Region_exit_ops ex_op_iter(r) ; ex_op_iter != 0 ; ex_op_iter++) {
	Op* cur_op = *ex_op_iter ;
	List<Operand>* taken_exit_pseudo_uses = 
	    (List<Operand>*)get_generic_attribute(cur_op, "taken_exit_pseudo_uses") ;
	List<Operand>* fallthrough_exit_pseudo_uses = 
	    (List<Operand>*)get_generic_attribute(cur_op, "fallthrough_exit_pseudo_uses") ;
	if (taken_exit_pseudo_uses == NULL) {
	    taken_exit_pseudo_uses = new List<Operand>();
	}
	else {
	    taken_exit_pseudo_uses->clear() ;
	}
	if (fallthrough_exit_pseudo_uses == NULL) {
	    fallthrough_exit_pseudo_uses = new List<Operand>();
	}
	else {
	    fallthrough_exit_pseudo_uses->clear() ;
	}
	for(Region_exit_edges ex_edge_iter(r) ; ex_edge_iter != 0 ; 
	    ex_edge_iter++) {
	    Edge* cur_edge = *ex_edge_iter ;
	    if (cur_edge->src() != cur_op) continue ;
	    
	    List<Operand>* tmp_exit_pseudo_uses ;
	    if (is_fall_through(cur_edge)) {
		tmp_exit_pseudo_uses = fallthrough_exit_pseudo_uses ;
	    }
	    else {
		tmp_exit_pseudo_uses = taken_exit_pseudo_uses ;
	    }
	 
	    Liveness_info* linfo = get_liveness_info(cur_edge) ;
	    if (linfo) {
		for (Liveness_info_iterator li(*linfo) ; li != 0 ; li++) {
		    Operand& tmpoper = *li ;
		    if (!tmp_exit_pseudo_uses->is_member(tmpoper)){
			tmp_exit_pseudo_uses->add_tail(tmpoper) ;
		    }
		}
	    }
	}
	if (taken_exit_pseudo_uses->is_empty()) {
	    delete taken_exit_pseudo_uses ;
	}
	else {
	    set_generic_attribute (cur_op, "taken_exit_pseudo_uses", taken_exit_pseudo_uses) ;
	}
	if (fallthrough_exit_pseudo_uses->is_empty()) {
	    delete fallthrough_exit_pseudo_uses ;
	}
	else {
	    set_generic_attribute (cur_op, "fallthrough_exit_pseudo_uses", fallthrough_exit_pseudo_uses) ;
	}
    }
}



// RegAllocSolver::local_liveness_walk

void 
RegAllocSolver::local_liveness_walk (
    Compound_region* r, 
    Map<Operand, Pred_cookie>& liveness_map_,
    Op* entry_op, 
    Op* exit_op)
{

#if 1

    Pred_jar pj(r);
    initialize_pseudo_sources(r);
    for (Region_ops_reverse_C0_order ops(r, exit_op); ops != 0; ops++) {
	Op* op = *ops;
	if (entry_op != NULL && op == entry_op) break;

	if (is_branch(op)){
	    for(Op_pseudo_sources lives(op); lives != 0; lives++) {
		El_ref cur_ref = lives.get_ref();
		Operand& var = cur_ref.get_operand();
		if (!var.is_reg()) {
		    continue;
                }

                if (var.is_rotating()) {
                    // rotate register allocation for static variable
                    // will be added.
                    continue;
                }

		Pred_cookie guard = pj.get_lub_guard(cur_ref);
		if (liveness_map_.is_bound(cur_ref.get_operand())) {
		    Pred_cookie& p = liveness_map_.value(cur_ref.get_operand());
		    p.lub_sum(guard);
		    if (p == Pred_jar::get_false()) {
			liveness_map_.unbind(cur_ref.get_operand());
		    }
		}
		else {
		    if (guard != Pred_jar::get_false()) {
			liveness_map_.bind(cur_ref.get_operand(),Pred_jar::get_true() );
		    }
		}
	    }
	}

	// update LiveRanges
	for (Map_iterator<Operand, Pred_cookie> iter(liveness_map_); iter != 0; iter++) {
	    Pair<Operand, Pred_cookie>& ele = *iter;
	    Operand& var = ele.first;

            // Rotating registers are not used for static register allocation
            // right now
            assert(var.is_rotating()==false);

	    LiveRange* cur_lr = NULL;
	    if (_lr_map.is_bound(ele.first)) {
		cur_lr = _lr_map.value(ele.first);
	    }
	    else {
		cur_lr = new LiveRange(var, _region);
		_lr_map.bind(var, cur_lr);
                if (var.is_rotating()) {
                    // rotate register allocation for static variable
                    // will be added.
                    //_rr_lrs += cur_lr;
                }
                else {
                    _lrs += cur_lr;
                }
	    }

	    cur_lr->add_live_region(op, ele.second);
	    // cur_lr->add_live_region(get_incoming_CONTROL0_edge(op), ele.second);
	    // used for EDGE based
	}

	for(Op_all_dests dests(op); dests != 0; dests++) {

	    El_ref cur_ref = dests.get_ref();
            Operand& var = cur_ref.get_operand();

 	    if (!var.is_reg()) {
		// only Reg operand is the target for static register
		// allocation
		continue;
	    }

            if (var.is_rotating()) {
                // rotate register allocation for static variable
                // will be added.
                continue;
            }

	    Pred_cookie guard = pj.get_glb_guard(cur_ref);

	    LiveRange* cur_lr = NULL;
	    if (_lr_map.is_bound(var)) {
		cur_lr = _lr_map.value(var);
	    }
	    else {
		cur_lr = new LiveRange(var, _region);
		_lr_map.bind(var, cur_lr);
                _lrs += cur_lr;
	    }


	    if (liveness_map_.is_bound(cur_ref.get_operand())) {
		Pred_cookie& p = liveness_map_.value(cur_ref.get_operand());
		p.lub_diff(guard);
		if (p == Pred_jar::get_false()) {
		    liveness_map_.unbind(cur_ref.get_operand());
		}
	    }
	    else {
                // This definition is dead code.
                // Do not bind this variable to liveness map.
                // liveness_map_.bind(cur_ref.get_operand(), guard)
                cur_lr->add_live_region(op, Pred_jar::get_true());
	    }

	    cur_lr->add_live_ref(cur_ref);
	}

	for(Op_all_inputs ins(op); ins != 0; ins++) {
	    El_ref cur_ref = ins.get_ref();
            Operand& var = cur_ref.get_operand();
	    Pred_cookie guard = pj.get_lub_guard(cur_ref);

 	    if (!var.is_reg()) {
		// only Reg operand is the target for static register
		// allocation
		continue;
	    }

            if (var.is_rotating()) {
                // rotate register allocation for static variable
                // will be added.
                continue;
            }

	    if (liveness_map_.is_bound(var)) {
		Pred_cookie& p = liveness_map_.value(cur_ref.get_operand());
		p.lub_sum(guard);
	    }
	    else {
		liveness_map_.bind(var, Pred_jar::get_true());
	    }

	    LiveRange* cur_lr = NULL;
	    if (_lr_map.is_bound(var)) {
		cur_lr = _lr_map.value(var);
	    }
	    else {
		cur_lr = new LiveRange(var, _region);
		_lr_map.bind(var, cur_lr);
                _lrs += cur_lr;
	    }

	    cur_lr->add_live_ref(cur_ref);
	    cur_lr->add_live_region(op, liveness_map_.value(var));
	}
    } // end of for
    
#else

    Pred_jar pj(r);
    initialize_pseudo_sources(r);
    for (Region_ops_reverse_C0_order ops(r, exit_op); ops != 0; ops++) {
	Op* op = *ops;
	if (entry_op != NULL && op == entry_op) break;

	if (is_branch(op)){
	    for(Op_pseudo_sources lives(op); lives != 0; lives++) {
		El_ref cur_ref = lives.get_ref();
		Operand& var = cur_ref.get_operand();
		if (!var.is_reg()) {
		    continue;
                }

                if (var.is_rotating()) {
                    // rotate register allocation for static variable
                    // will be added.
                    continue;
                }

		Pred_cookie guard = pj.get_lub_guard(cur_ref);
		if (liveness_map_.is_bound(cur_ref.get_operand())) {
		    Pred_cookie& p = liveness_map_.value(cur_ref.get_operand());
		    p.lub_sum(guard);
		    if (p == Pred_jar::get_false()) {
			liveness_map_.unbind(cur_ref.get_operand());
		    }
		}
		else {
		    if (guard != Pred_jar::get_false()) {
			liveness_map_.bind(cur_ref.get_operand(), guard);
		    }
		}
	    }
	}

	// update LiveRanges
	for (Map_iterator<Operand, Pred_cookie> iter(liveness_map_); iter != 0; iter++) {
	    Pair<Operand, Pred_cookie>& ele = *iter;
	    Operand& var = ele.first;

            // Rotating registers are not used for static register allocation
            // right now
            assert(var.is_rotating()==false);

	    LiveRange* cur_lr = NULL;
	    if (_lr_map.is_bound(ele.first)) {
		cur_lr = _lr_map.value(ele.first);
	    }
	    else {
		cur_lr = new LiveRange(var, _region);
		_lr_map.bind(var, cur_lr);
                if (var.is_rotating()) {
                    // rotate register allocation for static variable
                    // will be added.
                    //_rr_lrs += cur_lr;
                }
                else {
                    _lrs += cur_lr;
                }
	    }

	    cur_lr->add_live_region(op, ele.second);
	    // cur_lr->add_live_region(get_incoming_CONTROL0_edge(op), ele.second);
	    // used for EDGE based
	}

	for(Op_all_dests dests(op); dests != 0; dests++) {

	    El_ref cur_ref = dests.get_ref();
            Operand& var = cur_ref.get_operand();

 	    if (!var.is_reg()) {
		// only Reg operand is the target for static register
		// allocation
		continue;
	    }

            if (var.is_rotating()) {
                // rotate register allocation for static variable
                // will be added.
                continue;
            }

	    Pred_cookie guard = pj.get_glb_guard(cur_ref);

	    LiveRange* cur_lr = NULL;
	    if (_lr_map.is_bound(var)) {
		cur_lr = _lr_map.value(var);
	    }
	    else {
		cur_lr = new LiveRange(var, _region);
		_lr_map.bind(var, cur_lr);
                _lrs += cur_lr;
	    }


	    if (liveness_map_.is_bound(cur_ref.get_operand())) {
		Pred_cookie& p = liveness_map_.value(cur_ref.get_operand());
		p.lub_diff(guard);
		if (p == Pred_jar::get_false()) {
		    liveness_map_.unbind(cur_ref.get_operand());
		}
	    }
	    else {
                // This definition is dead code.
                // Do not bind this variable to liveness map.
                // liveness_map_.bind(cur_ref.get_operand(), guard)
                cur_lr->add_live_region(op, guard);
	    }

	    cur_lr->add_live_ref(cur_ref);
	}

	for(Op_all_inputs ins(op); ins != 0; ins++) {
	    El_ref cur_ref = ins.get_ref();
            Operand& var = cur_ref.get_operand();
	    Pred_cookie guard = pj.get_lub_guard(cur_ref);

 	    if (!var.is_reg()) {
		// only Reg operand is the target for static register
		// allocation
		continue;
	    }

            if (var.is_rotating()) {
                // rotate register allocation for static variable
                // will be added.
                continue;
            }

	    if (liveness_map_.is_bound(var)) {
		Pred_cookie& p = liveness_map_.value(cur_ref.get_operand());
		p.lub_sum(guard);
	    }
	    else {
		liveness_map_.bind(var, guard);
	    }

	    LiveRange* cur_lr = NULL;
	    if (_lr_map.is_bound(var)) {
		cur_lr = _lr_map.value(var);
	    }
	    else {
		cur_lr = new LiveRange(var, _region);
		_lr_map.bind(var, cur_lr);
                _lrs += cur_lr;
	    }

	    cur_lr->add_live_ref(cur_ref);
	    cur_lr->add_live_region(op, liveness_map_.value(var));
	}
    } // end of for
#endif

}

	    

/***********************************************************************
** class RegAllocSolverData
************************************************************************/

RegAllocSolverData::RegAllocSolverData(const char* file_name_) {
    _reg_file_name = file_name_;
}

RegAllocSolverData::~RegAllocSolverData() {
}

void
RegAllocSolverData::process_coloring() {
    // initialize interference graph
    init_interference_graph();


    // find priority of each LiveRange
    set_priority();

    // divide _lrs into Set constrained vs. un_constrained;
    for (List_set_iterator<LiveRange*> lr_iter1(_lrs);
	 lr_iter1 != 0; lr_iter1++) {
	LiveRange* lr_ptr = *lr_iter1;
	if (lr_ptr->is_constrained()) {
	    _constrained += lr_ptr;
	}
	else
	    _unconstrained += lr_ptr;
    }

    /*
    while (1) {
	LiveRange* clr = prior_live_range();
	if (clr == NULL)
	    break;
	else
	    _constrained -= clr;

	
	if ( clr->live_refs().size() == 0 ) {
	    // pass-through live-range
	    if (clr->is_split()) {
		clr->bind_register();
		clr->reconcile_pre_lr();
		clr->reconcile_post_lr();
		// clr->add_spill_code();
	    }
	    else {
		clr->reg_bind_state(LiveRange::DELAYED);
	    }
	}
	else if (clr->live_refs().size() == 1) {
	    // spill the live range
	    int reg = clr->select_register(); // find available register
	    clr->spilling();
	}
	else {
	    // non pass-through live-range
	    if (clr->is_colorable()) {
		// find available register and color current LiveRange
		int reg = clr->select_register(); // find available register
		clr->bind_register(reg);
		// clr->add_spill_code();
		clr->reconcile_pre_lr();
		clr->reconcile_post_lr();
	    }
	    else {
		if (
		// split clr and add 2 new LiveRange
		split(clr);
	    }
	}
    }

    for (List_set_iterator<LiveRange*> lr_iter2(_unconstrained); lr_iter2 != 0; lr_iter2++) {

	LiveRange* clr = *lr_iter2;
	if (clr->live_refs().size() > 0) {
	    // find available register and color current LiveRange
	    int reg = clr->select_register(); // find available register
	    clr->bind_register(reg);
	    // clr->add_spill_code();
	    clr->reconcile_pre_lr();
	    clr->reconcile_post_lr();
	}
	else {
	    // pass-through live-range
	    if (clr->is_split()) {
		clr->bind_register();
		clr->reconcile_pre_lr();
		clr->reconcile_post_lr();
		// clr->add_spill_code();
	    }
	    else
		clr->reg_bind_state(LiveRange::DELAYED);
	}
    }
    */

    while (1) {
	LiveRange* clr = prior_live_range();
	if (clr == NULL)
	    break;

	
 	if ( clr->live_refs().size() == 0 ) {
	    // pass-through live-range
	    if (clr->is_split()) {
		clr->bind_register();
		clr->reconcile_pre_lr();
		clr->reconcile_post_lr();
		// clr->add_spill_code();
	    }
	    else {
		clr->reg_bind_state(LiveRange::DELAYED);
	    }
	}
	else {
	    // non pass-through live-range

	    int reg = clr->find_register_in_pref_class(); // find available register
	    if (reg >= 0) {
		// find available register and color current LiveRange
		clr->bind_register(reg);

		// clr->add_spill_code();
		clr->reconcile_pre_lr();
		clr->reconcile_post_lr();
	    }
	    else {
                // Live range is not colorable
                // split the LR or spill

                if (clr->live_refs().size() == 1) {
                    // optimization
                    // LR containes only one reference.
                    // spilling LR without further splitting
                    clr->spilling();
                    clr->reconcile_pre_lr();
                    clr->reconcile_post_lr();
                }
		else if (clr->pref_reg_class() == CALLER_SAVED &&
			 clr->callee_benefit() < 0) {
		    clr->spilling();
		    clr->reconcile_pre_lr();
		    clr->reconcile_post_lr();
		}
		else if (clr->pref_reg_class() == CALLEE_SAVED &&
			 clr->caller_benefit() < 0) {
		    clr->spilling();
		    clr->reconcile_pre_lr();
		    clr->reconcile_post_lr();
		}
		else {
		    reg = clr->find_register_in_reverse_class();
		    if (reg >=0) {
			clr->bind_register(reg);
			clr->reconcile_pre_lr();
			clr->reconcile_post_lr();
		    }
		    else {
			// split clr and add 2 new LiveRange
			split(clr);
		    }
                }

	    }
	}
    } // end of while()

}


void
RegAllocSolverData::init_interference_graph() {

    // set InterferenceGraph
    List<LiveRange*> tmp_list;
    for (List_set_iterator<LiveRange*> iter1(_lrs); iter1 != 0; iter1++) {
	LiveRange* lr_ptr1 = *iter1;
	for (List_iterator<LiveRange*> iter2(tmp_list); iter2 != 0; iter2++) {
	    LiveRange* lr_ptr2 = *iter2;
	    lr_ptr1->update_interfered(lr_ptr2);
	}
	tmp_list.add_tail(lr_ptr1);
    }
}


void
RegAllocSolverData::set_priority() {

    for (List_set_iterator<LiveRange*> iter(_lrs); iter != 0; iter++) {
	LiveRange* lr_ptr = *iter;
	lr_ptr->set_priority();
    }
}


//
// find LiveRange with the highest priority
// pop it from _constrained
//
LiveRange*
RegAllocSolverData::prior_live_range() {
    double priority = -100000;
    LiveRange* prior_lr = 0;

    if (_constrained.size()) {
	for (List_set_iterator<LiveRange*> iter(_constrained); iter != 0; iter++) {
	    LiveRange* lr_ptr = *iter;
	    if (lr_ptr->priority() > priority) {
		priority = lr_ptr->priority();
		prior_lr = lr_ptr;
	    }
	}
	_constrained -= prior_lr;
    }
    else if (_unconstrained.size()) {
	for (List_set_iterator<LiveRange*> iter(_unconstrained); iter != 0; iter++) {
	    LiveRange* lr_ptr = *iter;
	    if (lr_ptr->priority() >= priority) {
		priority = lr_ptr->priority();
		prior_lr = lr_ptr;
	    }
	}
	_unconstrained -= prior_lr;
    }
    
    return prior_lr;
}



//
// split LiveRange* lr into  2 new LiveRange *new_lr1 and *new_lr2
// and insert it into _lrs
//
#if EDGE_BASED
void
RegAllocSolverData::split(LiveRange* old_lr) {
    
    LiveRange* new_lr1 = new LiveRange(old_lr->variable(), old_lr->region());
    LiveRange* new_lr2 = new LiveRange(old_lr->variable(), old_lr->region());
    int index = 0;

    Dlist_iterator<Edge*> iter(old_lr.live_regions());
    while(*iter) {
	Edge* c_edge = *iter;
	iter++;

	// find all used(live) registers in the current Edge
	List_set<int> cur_forbidden = used_registers(c_edge);

	if ( (cur_forbidden += (*iter)->new_lr1->forbidden()) < _register_size ) {
	    // merge cur_edge into new_lr1
	    new_lr1->add_live_region(c_edge, old_lr->pred(c_edge));
	    new_lr1->add_forbidden(cur_forbidden);
	}
	else {
	    break;
	}
    }
    
    while (*iter) {
	Edge* c_edge = *iter;
	iter++;

	// find all used(live) registers in the current Edge
	List_set<int> cur_forbidden = used_registers(c_edge);

	// copy rest of old_lr into new_lr2
	new_lr2->add_live_region(c_edge, old_lr->pred(c_edge));
	new_lr2->add_forbidden(cur_forbidden);
    }


    // split El_ref
    split_live_refs(old_lr->live_refs(), new_lr1, new_lr2);

    // update interference graph
    for (Dlist_iterator<LiveRange*> diter(old_lr->inf_list()); diter!=0; diter++) {
	// remove iterference information of old LiveRange
	(*diter)->delete_interferenc(old_lr);

	// verify that it is interfere with new LiveRanges, and update
	(*diter)->update_interference(new_lr1);
	(*diter)->update_interference(new_lr2);
    }
	
	     
    // update constrained set information
    for (Dlist_iterator<LiveRange*> diter(old_lr->inf_list()); diter!=0; diter++) {
	if ( (*diter)->is_constrained() ) {
	    if (_constrained.is_member(*diter)) {
		// do nothing
	    }
	    else {
		_unconstrained += *diter;
		_constrained -= *diter;
	    }
	}
	else {
	    if (_constrained.is_member(*diter)) {
		_constrained += *diter;
		_unconstrained -= *diter;
	    }
	    else {
		// do nothing
	    }
	}
    }

    if (new_lr1->is_constrained())
	_constrained += new_lr1;
    else
	_unconstrained += new_lr1;

    if (new_lr2->is_constrained())
	_constrained += new_lr2;
    else
	_unconstrained += new_lr2;

    new_lr1->set_post_lr(new_lr2);
    new_lr2->set_pre_lr(new_lr1);
    _lrs += new_lr1;
    _lrs += new_lr2;
    _lrs -= old_lr;
}

#else

void
RegAllocSolverData::split(LiveRange* old_lr) {
    cout << "Split variable " << old_lr->variable().vr_num() << " in "
	 << "region " << old_lr->region()->id() << endl << flush;

    _lrs -= old_lr;

    LiveRange* new_lr1 = new LiveRange(old_lr->variable(), old_lr->region());
    LiveRange* new_lr2 = new LiveRange(old_lr->variable(), old_lr->region());

    Dlist_iterator<Op*> iter(old_lr->live_ops());

    // initial condition
    // create new_lr1 with one op.
    Op* cur_op = *iter;
    new_lr1->add_live_region(cur_op, old_lr->predicate(cur_op));
    new_lr1->add_forbidden(used_registers(cur_op));
    iter++;
    
    while(iter != 0) {
	Op* cur_op = *iter;

	// find all used registers for the current Op
	List_set<int> cur_forbidden = used_registers(cur_op);

	if ( (cur_forbidden += new_lr1->forbidden()).size() < _reg_size ) {
	    // merge cur_op into new_lr1
	    new_lr1->add_live_region(cur_op, old_lr->predicate(cur_op));
	    new_lr1->add_forbidden(cur_forbidden);
	    iter++;
	}
	else {
	    // iter++;
	    break;
	}
    }
    assert(new_lr1->live_ops().size() > 0);
    assert(new_lr1->live_ops().size() < old_lr->live_ops().size());

    while (iter != 0) {
	Op* cur_op = *iter;

	// find all used(live) registers in the current Edge
	List_set<int> cur_forbidden = used_registers(cur_op);

	// copy rest of old_lr into new_lr2
	new_lr2->add_live_region(cur_op, old_lr->predicate(cur_op));
	new_lr2->add_forbidden(cur_forbidden);
	iter++;
    }

    // split El_ref
    split_live_refs(old_lr->live_refs(), new_lr1, new_lr2);

    // update interference graph
    for (List_set_iterator<LiveRange*> diter1(old_lr->inf_set()); diter1!=0; diter1++) {
	LiveRange* lr_ptr = *diter1;

	// remove iterference information of old LiveRange
	lr_ptr->delete_interfered(old_lr);

	// verify that it is interfere with new LiveRanges, and update
	lr_ptr->update_interfered(new_lr1);
	lr_ptr->update_interfered(new_lr2);
    }
	
	     
    // update constrained set information
    /*
    for (List_set_iterator<LiveRange*> diter2(old_lr->inf_set()); diter2!=0; diter2++) {
	LiveRange* lr = *diter2;
	if (lr->reg_bind_state() != LiveRange::UNDEFINED) {
	    continue;
	}
	else if ( (*diter2)->is_constrained() ) {
	    if (_constrained.is_member(*diter2)) {
		// do nothing
	    }
	    else {
		_unconstrained += *diter2;
		_constrained -= *diter2;
	    }
	}
	else {
	    if (_constrained.is_member(*diter2)) {
		_constrained += *diter2;
		_unconstrained -= *diter2;
	    }
	    else {
		// do nothing
	    }
	}
    }
    */

    if (new_lr1->is_constrained())
	_constrained += new_lr1;
    else
	_unconstrained += new_lr1;

    if (new_lr2->is_constrained())
	_constrained += new_lr2;
    else
	_unconstrained += new_lr2;

	     
    new_lr1->set_pre_lr(new_lr2);
    new_lr1->set_post_lr(old_lr->post_lr());
    new_lr2->set_pre_lr(old_lr->pre_lr());
    new_lr2->set_post_lr(new_lr1);
    _lrs += new_lr1;
    _lrs += new_lr2;
}
#endif


#if EDGE_BASED
void
RegAllocSolverData::split_live_refs(const Dlist<El_ref>& u_list,
				     LiveRange* new_lr1,
				     LiveRange* new_lr2) {

    for (Dlist_iterator<El_ref> iter(u_list); iter !=0; iter++) {
	El_ref& c_ref = *iter;
	if (c_ref.get_ref_type() == EXP_SRC) {
	    Edge* in_edge = get_incoming_CONTROL0_edge(c_ref.get_op());
	    if (new_lr1->live_regions().is_member(in_edge)) {
		new_lr1->add_live_ref(c_ref);
	    }
	    else {
		new_lr2->add_live_ref(c_ref);
	    }
	}
	else if (c_ref.get_ref_type() == EXP_DEST) {
	    Edge* out_edge = get_outpoing_CONTROL0_edge(c_ref.get_op());
	    if (new_lr1->live_ops().is_member(out_edge)) {
		new_lr1->add_live_ref(c_ref);
	    }
	    else {
		new_lr2->add_live_ref(c_ref);
	    }
	}
	else {
	    assert(0);
	}
    }
}
#else
void
RegAllocSolverData::split_live_refs(const Dlist<El_ref>& u_list,
				     LiveRange* new_lr1,
				     LiveRange* new_lr2) {

    for (Dlist_iterator<El_ref> iter(u_list); iter !=0; iter++) {
	El_ref& c_ref = *iter;
	if (c_ref.get_ref_type() == EXP_SRC) {
	    if (new_lr1->live_ops().is_member(c_ref.get_op())) {
		new_lr1->add_live_ref(c_ref);
	    }
	    else {
		new_lr2->add_live_ref(c_ref);
	    }
	}
	else if (c_ref.get_ref_type() == EXP_DEST) {
	    if (new_lr1->live_ops().is_member(c_ref.get_op())) {
		new_lr1->add_live_ref(c_ref);
	    }
	    else {
		new_lr2->add_live_ref(c_ref);
	    }
	}
	else {
	    assert(0);
	}
    }
}
#endif

//
// find all colored live variables in given edges 
//
#if EDGE_BASED
const List_set<int>
RegAllocSolverData::used_registers(const Edge* live_edge_) {
    List_set<int> forbidden;

    // find all the LiveRanges which is live at live_edge_
    for (List_set_iterator<LiveRange*> iter; iter != 0; iter++) {
	LiveRange* c_lr = *iter;
	if (c_lr->live_regions().is_member(live_edge_)) {
	    if (c_lr->is_colored())
		forbidden += c_lr->register();
	}	    
    }
    
    return forbidden;
}
#else
const List_set<int>
RegAllocSolverData::used_registers(const Op* live_op_) {
    List_set<int> forbidden;

    // find all the LiveRanges which is live at live_op_
    for (List_set_iterator<LiveRange*> iter(_lrs); iter != 0; iter++) {
	LiveRange* c_lr = *iter;
	if (c_lr->live_ops().is_member( (Op*)live_op_)) {
	    if (c_lr->reg_bind_state() == LiveRange::BOUND)
		forbidden += c_lr->reg_num();
	}	    
    }
    
    return forbidden;
}
#endif


