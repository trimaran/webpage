/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   ReconcileCode.cpp
// Author: Hansoo Kim
///////////////////////////////////////////////////////////////////////////////

#include "ReconcileCode.h"

#include <opcode_cmpp.h>
#include <opcode_properties.h>

ostream& 
ReconcileCodeData::print( ostream& os) const {
    if ( _type == LOAD ) {
	cout << "LOAD ";
    }
    else if ( _type == STORE ) {
	cout << "STORE ";
    }
    else if ( _type == MOVE ) {
	cout << "MOVE ";
    }
    else {
	cout << "Uninitialized\n";
	return os;
    }
    cout << _src_var << " " << _dest_var << "\n";
    return os;
}

int
ReconcileCodeData::operator==(const ReconcileCodeData p) const {
    return ((_src_var == p._src_var) &&
	    (_dest_var == p._dest_var) &&
	    (_type == p._type ));
}

int
ReconcileCodeData::operator!=(const ReconcileCodeData p) const {
    return (*this==p? 0:1);
}


/****************************************************************************
 * class implementation
 * ReconcileCodeSet
 ****************************************************************************/
Map<Edge*, List<ReconcileCodeData>* > ReconcileCodeSet::_unordered_ops;

//
// Take only the move ops that are in the entire list of operands, and order
//  the moves the following way:
//
// Iterate through from the beginning to the Initial End of the list.
//  Check the source operand against the rest of the moves to ensure that it 
//  does not conflict with the dest operand.  If there is a conflict, and
//  if the instruction that it conflicts with is not past the initial
//  end of the list, put it at the end of the list.  (the list is now longer
//  than it was initially).  If there is a conflict and the conflict is past
//  the initial end of the list, there is a circular move.  Issue a 
//  Store(src) and Load(dest) operation, and delete the instruction from the
//  queue.
//
//  After all of the moves have been sorted, iterate through the unordered
//   instruction list and put all of the stores in front and all of the loads
//   at the end.  Return this list.
//

void
ReconcileCodeSet::clear() {
    for (Map_iterator<Edge*, List<ReconcileCodeData>* >  iter(_unordered_ops); iter != 0; iter++) {

	Pair< Edge*, List<ReconcileCodeData>* > pair = *iter;
	Edge* e = pair.first;
	// List<ReconcileCodeData>& unordered_patchs = pair.second;
	List<ReconcileCodeData>* ordered_patches = order_ops(pair.first);
	delete (ordered_patches);
    }
    _unordered_ops.clear();
}


List<ReconcileCodeData>*
ReconcileCodeSet::order_ops(Edge* e_) {
    List<ReconcileCodeData>* move_list = new List<ReconcileCodeData>;
    List<ReconcileCodeData>* ordered_list = NULL;
    List<ReconcileCodeData>* unordered_list = NULL;

    if (_unordered_ops.is_bound(e_)) {
	unordered_list =  _unordered_ops.value(e_);
    }
    else {  // No list, nothing to do
	return ordered_list;
    }

    // Create a list with all of the move instructions
    for ( List_iterator<ReconcileCodeData> iter(*unordered_list); iter != 0; iter++) {
	ReconcileCodeData p = *iter;
	if ( p.type() == ReconcileCodeData::MOVE ) {
	    move_list->add_head(p);
	}
    }

    ordered_list = order_moves(move_list, e_);

    for ( List_iterator<ReconcileCodeData> iter2(*unordered_list); iter2 != 0; iter2++) {
	ReconcileCodeData p = *iter2;
	if ( p.type() == ReconcileCodeData::STORE ) {
	    ordered_list->add_head(p);
	}
	else if ( p.type() == ReconcileCodeData::LOAD ) {
	    ordered_list->add_tail(p);
	}
    }

    return ordered_list;
}


List<ReconcileCodeData>*
ReconcileCodeSet::order_moves(List<ReconcileCodeData>* ordered_list, Edge *e_) {

    // Nothing to do on size 0 or 1 lists
    if (ordered_list->size() < 2) {
	return ordered_list;
    }

    List<ReconcileCodeData> work_list(*ordered_list);
    List<ReconcileCodeData> pend_list;
    ordered_list->clear();

    while (1) {

	for ( List_iterator<ReconcileCodeData> dest_ins(work_list); dest_ins != 0; ) { 
	    ReconcileCodeData d = *dest_ins;
	    dest_ins++;

	    for ( List_iterator<ReconcileCodeData> src_ins(dest_ins); src_ins != 0; src_ins++) {
		ReconcileCodeData s = *src_ins;
		if (s.getsrc().mc_num() == d.getdest().mc_num()) {
		    break;
		}
	    }
	    if (src_ins == 0)
		ordered_list->add_tail(d);
	    else
		pend_list.add_tail(d);
	}

	if (pend_list.size() == work_list.size() ) {
	    // nothing cannot be scheduled.
	    ReconcileCodeData victim = pend_list.pop();
	    add_store(e_, victim.getsrc());
	    add_load(e_, victim.getdest());
	}

	if (pend_list.size()) {
	    work_list = pend_list;
	    pend_list.clear();
	}
	else
	    break;

    }


#if 0
    // Nothing to do on size 0 or 1 lists
    if (ordered_list->size() < 2) {
	return ordered_list;
    }

    ReconcileCodeData last = ordered_list->tail();

    for ( List_iterator<ReconcileCodeData> dest_ins(*ordered_list); dest_ins != 0;){
	int past_end = 0;
	ReconcileCodeData d = *dest_ins;
	if (d==last)
	    past_end = 1;
	dest_ins++;
	
	for ( List_iterator<ReconcileCodeData> src_ins(dest_ins); src_ins != 0; ) {
	    ReconcileCodeData s = *src_ins;
	    src_ins++;

	    // Do we have a conflict of destination and source
	    if (s.getsrc().mc_num() == d.getdest().mc_num()) {
		if ( past_end == 0 ) {
		    // Leave the iterator in a sane state
		    ordered_list->remove(d);
		    ordered_list->add_tail(d);
		    break;
		}
		else {
		    add_store(e_, d.getsrc());
		    add_load(e_, d.getdest());
		    ordered_list->remove(d);
		    break;
		}
	    }

	    if ( s == last ) {
		past_end = 1;
	    }
	}
	
	if ( d == last ) {
	    break;
	}
    }

#endif

    return ordered_list;
}
//
// Add a load command to the unordered ops list
//
void 
ReconcileCodeSet::add_load(Edge* edge_, const Operand& var_) {
	Operand temp_operand(new Macro_reg(SPILL_TEMPREG));
	ReconcileCodeData p(ReconcileCodeData::LOAD, temp_operand, var_);
	if (_unordered_ops.is_bound(edge_)) {
		List<ReconcileCodeData>* code_list = _unordered_ops.value(edge_);
		code_list->add_head(p);
	}
	else {
		_unordered_ops.bind(edge_, new List<ReconcileCodeData> (p));
	}
}

//
// Add a store command to the unordered ops list
//
void 
ReconcileCodeSet::add_store(Edge* edge_, const Operand& var_) {
	Operand temp_operand(new Macro_reg(SPILL_TEMPREG));
	ReconcileCodeData p(ReconcileCodeData::STORE, var_, temp_operand);
	if (_unordered_ops.is_bound(edge_)) {
		List<ReconcileCodeData>* code_list = _unordered_ops.value(edge_);
		code_list->add_head(p);
	}
	else {
		_unordered_ops.bind(edge_, new List<ReconcileCodeData> (p));
	}
}

//
// Add a move command to the unordered ops list
//
void 
ReconcileCodeSet::add_move(Edge* edge_, const Operand& src_var, const Operand& dest_var) {
	ReconcileCodeData p(ReconcileCodeData::MOVE, src_var, dest_var);
	if (_unordered_ops.is_bound(edge_)) {
		List<ReconcileCodeData>* code_list = _unordered_ops.value(edge_);
		code_list->add_head(p);
	}
	else {
		_unordered_ops.bind(edge_, new List<ReconcileCodeData> (p));
	}
}
//
// Instruction selection for ReconcileCodeData
//
Op* 
ReconcileCodeSet::select_op(ReconcileCodeData _p) {
	Op* _patch_op;
	Operand pred_operand(new Pred_lit(true));
	Operand _o;
	if ( _p.type() == ReconcileCodeData::LOAD) {
		_o = _p.getdest();
	}
	else if ( (_p.type() == ReconcileCodeData::MOVE) || 
	   (_p.type() == ReconcileCodeData::STORE) ) {
		_o = _p.getsrc();
	}
	// Take care of UNINITIALIZED
	else {
		assert(0);
	}
	switch(_o.file_type()) {
	case GPR:
	case PR:
	case BTR:
	case CR:
		if ( _p.type() == ReconcileCodeData::STORE ) {
			_patch_op = new Op((Opcode) S_W_C1);
		}
		else if ( _p.type() == ReconcileCodeData::LOAD ) {
			_patch_op = new Op((Opcode) L_W_C1_C1);
		}
		else if ( _p.type() == ReconcileCodeData::MOVE ) {
			_patch_op = new Op((Opcode) MOVE);
		}
		else {
			assert(0);
		}
		break;
	case FPR:
		if ( _p.type() == ReconcileCodeData::STORE ) {
			_patch_op = new Op((Opcode) FS_D_C1);
		}
		else if ( _p.type() == ReconcileCodeData::LOAD ) {
			_patch_op = new Op((Opcode) FL_D_C1_C1);
		}
		else if ( _p.type() == ReconcileCodeData::MOVE ) {
			_patch_op = new Op((Opcode) MOVEF_D);
		}
		else {
			assert(0);
		}
		break;
	default:
		assert(0);
		break;
	}
	if ( _p.type() == ReconcileCodeData::STORE ) {
		_patch_op->set_src(SRC1, (Operand&)_p.getdest());
		_patch_op->set_src(SRC2, (Operand&)_p.getsrc());
	}
	else {
		_patch_op->set_dest(DEST1, (Operand&)_p.getdest());
		_patch_op->set_src(SRC1, (Operand&)_p.getsrc());
	}
	_patch_op->set_src(PRED1, pred_operand);
	_patch_op->set_flag(EL_OPER_SPILL_CODE);
	return _patch_op;
}

//
// Instruction selection for stack manipulation
//
Op* 
ReconcileCodeSet::set_stack(ReconcileCodeData _p) {
	Operand o, temp;
	if ( _p.type() == ReconcileCodeData::LOAD) {
		o = _p.getdest();
		temp = _p.getsrc();

	}
	else if ( _p.type() == ReconcileCodeData::STORE) {
		o = _p.getsrc();
		temp = _p.getdest();
	}
	else {
		assert(0);
	}
	int stack_loc = ReconcileData::_spill_stack.addr(o);

	Op* pos_op = new Op((Opcode) ADD_W);
	Operand pred_operand(new Pred_lit(true));
	Operand sp_operand(new Macro_reg(SP_REG));
	Operand loc_operand(new Int_lit(stack_loc));
	pos_op->set_dest(DEST1, temp);
	pos_op->set_src(SRC1, sp_operand);
	pos_op->set_src(SRC2, loc_operand);
	pos_op->set_src(PRED1, pred_operand);
	pos_op->set_flag(EL_OPER_SPILL_CODE);
	return pos_op;
}


void
ReconcileCodeData::generate_load (Compound_region* region) {
    assert (_type == LOAD);
    // need to load it

    int stack_loc = ReconcileData::_spill_stack.addr (_src_var);
    Op* pos_op = new Op ((Opcode)ADD_W);
    Operand temp_operand (new Macro_reg (SPILL_TEMPREG));
    Operand pred_operand (new Pred_lit (true));
    Operand sp_operand (new Macro_reg (SP_REG));
    Operand loc_operand (new Int_lit (stack_loc));

    pos_op->set_src(SRC1, sp_operand);
    pos_op->set_src(SRC2, loc_operand);
    pos_op->set_src(PRED1, pred_operand);
    pos_op->set_dest(DEST1, temp_operand);
    pos_op->set_flag(EL_OPER_SPILL_CODE);
      
    Op* load_op = NULL;
    switch (_src_var.file_type()) {
    case GPR:
    case PR:
    case BTR:
    case CR:
	load_op = new Op ((Opcode) L_W_C1_C1);
	break;
    case FPR:
	load_op = new Op ((Opcode) FL_D_C1_C1);
	break;
    default:
	assert(0);
    }
    
    load_op->set_src(SRC1, temp_operand);
    load_op->set_src(PRED1, pred_operand);
    load_op->set_dest(DEST1, _src_var);
    load_op->set_flag(EL_OPER_SPILL_CODE);
    
    El_insert_op_before_switch(region, pos_op);
    El_insert_op_before_switch(region, load_op);
}


void
ReconcileCodeData::generate_store (Compound_region* region) {
    assert (_type == STORE);

    int stack_loc = ReconcileData::_spill_stack.addr(_src_var);
    // instruction: ADD SP, stack_loc, SPILL_TEMPREG.

    Op* pos_op = new Op ((Opcode) ADD_W);
    Operand temp_operand (new Macro_reg (SPILL_TEMPREG));
    Operand pred_operand (new Pred_lit (true));
    Operand sp_operand (new Macro_reg (SP_REG));
    Operand loc_operand (new Int_lit (stack_loc));
    pos_op->set_src (SRC1, sp_operand);
    pos_op->set_src (SRC2, loc_operand);
    pos_op->set_src (PRED1, pred_operand);
    pos_op->set_dest (DEST1, temp_operand);
    pos_op->set_flag (EL_OPER_SPILL_CODE);

    // instruction: STORE SPILL_TEMPREG, variable_operand
    Op* store_op = NULL;
    switch (_src_var.file_type()) {
    case GPR:
    case PR:
    case BTR:
    case CR:
	store_op = new Op ((Opcode)S_W_C1);
	break;
    case FPR:
	store_op = new Op ((Opcode)FS_D_C1);
	break;
    default:
	assert (0);
    }
    store_op->set_src (SRC1, temp_operand);
    store_op->set_src (SRC2, _src_var);
    store_op->set_src (PRED1, pred_operand);
    store_op->set_flag (EL_OPER_SPILL_CODE);

    El_insert_op_before_switch(region, pos_op);
    El_insert_op_before_switch(region, store_op);

}



void
ReconcileCodeData::generate_move (Compound_region* region) {
    assert (_type == MOVE);
    Op* copy_op = NULL;

    assert(_src_var.file_type() == _dest_var.file_type());

    switch(_src_var.file_type()) {
    case GPR:
    case CR:
        copy_op = new Op( (Opcode)MOVE);
        break;
    case FPR:
        copy_op = new Op( (Opcode)MOVEF_D);
        break;
    case PR:
        copy_op = new Op( (Opcode)CMPP_W_EQ_UC_UC);
        break;
    case BTR:
        copy_op = new Op( (Opcode)MOVE);
        break;
    default:
        break;
    }

    copy_op->set_dest(copy_op->first_dest(), _dest_var);
    copy_op->set_src(copy_op->first_src(), _src_var);
    Operand pred_operand(new Pred_lit(true));
    copy_op->set_src(PRED1, pred_operand);
    copy_op->set_flag(EL_OPER_SPILL_CODE);

    El_insert_op_before_switch(region, copy_op);
}


void
reconcileToNewRegion(Edge* e) {

    List<ReconcileCodeData>* ordered_patches = ReconcileCodeSet::order_ops(e);
    Basicblock* b = SpillCodeUtils::createBasicblock(e);
    Op* insert_after_op = get_first_region_op_from_subregions(b);

    for(List_iterator<ReconcileCodeData> li(*ordered_patches); li != 0; li++ ) {
	ReconcileCodeData p = *li;
	if ( p.type() == ReconcileCodeData::MOVE ) {
	    Op* move_op = ReconcileCodeSet::select_op(p);
	    El_insert_op_after(b, move_op, insert_after_op);
	    insert_after_op = move_op;
	}
	else if (p.type() == ReconcileCodeData::STORE) {
	    Op* stack_op = ReconcileCodeSet::set_stack(p);
	    Op* ld_st_op = ReconcileCodeSet::select_op(p);
	    El_insert_op_after(b, stack_op, insert_after_op);
	    El_insert_op_after(b, ld_st_op, stack_op);
	    insert_after_op = ld_st_op;
	}
	else if (p.type() == ReconcileCodeData::LOAD) {
	    Op* stack_op = ReconcileCodeSet::set_stack(p);
	    Op* ld_st_op = ReconcileCodeSet::select_op(p);
	    El_insert_op_after(b, stack_op, insert_after_op);
	    El_insert_op_after(b, ld_st_op, stack_op);
	    insert_after_op = ld_st_op;
	}
	else {
	    assert(0);
	}
    }
}


void
reconcileToDestRegion(Edge* e) {

    List<ReconcileCodeData>* ordered_patches = ReconcileCodeSet::order_ops(e);
    Op* insert_after_op = e->dest();
    Compound_region* b = insert_after_op->parent();
    bool pred_store = false;
    bool pred_load = false;

    for(List_iterator<ReconcileCodeData> li(*ordered_patches); li != 0; li++ ) {
	ReconcileCodeData p = *li;
	if ( p.type() == ReconcileCodeData::MOVE ) {
	    Op* move_op = ReconcileCodeSet::select_op(p);
	    El_insert_op_after(b, move_op, insert_after_op);
	    insert_after_op = move_op;
	}
	else if (p.type() == ReconcileCodeData::STORE) {
#if 0
	    Reg_file fType = p.getsrc().file_type();
	    if (fType == PR) {
		// do not store individually, use PRED_STORE_ALL
		pred_store = true;
		continue;
	    }
#endif
	    Op* stack_op = ReconcileCodeSet::set_stack(p);
	    Op* ld_st_op = ReconcileCodeSet::select_op(p);
	    El_insert_op_after(b, stack_op, insert_after_op);
	    El_insert_op_after(b, ld_st_op, stack_op);
	    insert_after_op = ld_st_op;
	}
	else if (p.type() == ReconcileCodeData::LOAD) {
#if 0
	    Reg_file fType = p.getdest().file_type();
	    if (fType == PR) {
		// do not load individually, use PRED_LOAD_ALL
		pred_load = true;
		continue;
	    }
#endif
	    Op* stack_op = ReconcileCodeSet::set_stack(p);
	    Op* ld_st_op = ReconcileCodeSet::select_op(p);
	    El_insert_op_after(b, stack_op, insert_after_op);
	    El_insert_op_after(b, ld_st_op, stack_op);
	    insert_after_op = ld_st_op;
	}
	else {
	    assert(0);
	}
    }
}


void
reconcileToSrcRegion(Edge* e) {

    List<ReconcileCodeData>* ordered_patches = ReconcileCodeSet::order_ops(e);
    Op* merge_op = e->src();
    Compound_region* b = merge_op->parent();
    bool pred_store = false;
    bool pred_load = false;

    for(List_iterator<ReconcileCodeData> li(*ordered_patches); li != 0; li++ ) {
	ReconcileCodeData p = *li;
	if ( p.type() == ReconcileCodeData::MOVE ) {
	    Op* move_op = ReconcileCodeSet::select_op(p);
	    El_insert_op_before(b, move_op, merge_op);
	}
	else if (p.type() == ReconcileCodeData::STORE) {
#if 0
	    Reg_file fType = p.getsrc().file_type();
	    if (fType == PR) {
		// do not store individually, use PRED_STORE_ALL
		pred_store = true;
		continue;
	    }
#endif
	    Op* stack_op = ReconcileCodeSet::set_stack(p);
	    Op* ld_st_op = ReconcileCodeSet::select_op(p);
	    El_insert_op_before(b, stack_op, merge_op);
	    El_insert_op_before(b, ld_st_op, merge_op);
	}
	else if (p.type() == ReconcileCodeData::LOAD) {
#if 0
	    Reg_file fType = p.getdest().file_type();
	    if (fType == PR) {
		// do not load individually, use PRED_LOAD_ALL
		pred_load = true;
		continue;
	    }
#endif
	    Op* stack_op = ReconcileCodeSet::set_stack(p);
	    Op* ld_st_op = ReconcileCodeSet::select_op(p);
	    El_insert_op_before(b, stack_op, merge_op);
	    El_insert_op_before(b, ld_st_op, merge_op);
	}
	else {
	    assert(0);
	}
    }

}


//
// Generate the basic blocks on the edges.  Iterate through each edge,
//  order the instruction set, and output the code.
//
void 
ReconcileCodeSet::generate_reconcile_code() {
    List<ReconcileCodeData> patch_list;
    for (Map_iterator<Edge*, List<ReconcileCodeData>* >  iter(_unordered_ops); iter != 0; iter++) {

	Pair< Edge*, List<ReconcileCodeData>* > pair = *iter;
	Edge* e = pair.first;

	Op* src_op = e->src();
	Op* dest_op = e->dest();

#if 0
        reconcileToNewRegion(e);
#else
	if (is_dummy_branch(src_op)) {
	    // src has one out edge
	    assert( ((Region*)src_op)->outedges().size() == 1);
	    reconcileToSrcRegion(e);
	}
	else if ( ((Region*)dest_op)->inedges().size() == 1) {
	    reconcileToDestRegion(e);
	}
	else {
	    reconcileToNewRegion(e);
	}
#endif
    }
}


void 
ReconcileCodeSet::add2edge(const LiveRangePair& lr_pair) {
    LiveRange* from = lr_pair._src_lr;
    LiveRange* to = lr_pair._dest_lr;
    Edge* e = lr_pair._e;

    if (from->reg_bind_state() == LiveRange::SPILLED) {
	if (to->reg_bind_state() == LiveRange::SPILLED) {
	    // both LR are SPILLED, no patch code
	}
	else if (to->reg_bind_state() == LiveRange::BOUND) {
	    // dest LR is bound, need ReconcileCodeData::LOAD
	    add_load(e, to->variable());
	}
	else {
	    assert(0);
	}
    }
    else if (from->reg_bind_state() == LiveRange::BOUND) {
	if (to->reg_bind_state() == LiveRange::SPILLED) {
	    // src LR is bound, need ReconcileCodeData::STORE
	    add_store(e, from->variable());
	}
	else if (to->reg_bind_state() == LiveRange::BOUND) {
	    // both LR are BOUND
	    if (from->reg_num() != to->reg_num()) {
		add_move(e, from->variable(), to->variable());
	    }
	}
	else {
	    assert(0);
	}
    }
    else {
	assert(0);
    }
}
