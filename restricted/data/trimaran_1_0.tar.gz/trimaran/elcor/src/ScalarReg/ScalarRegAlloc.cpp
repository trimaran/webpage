/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   ScalarRegAlloc.cpp
// Author: Hansoo Kim
///////////////////////////////////////////////////////////////////////////////

#include "ScalarRegAlloc.h"

#include "EdgeOpsMap.h"
#include "LiveRange.h"
#include "ReconcileCode.h"
#include "ReconcileData.h"
#include "RegisterBank.h"
#include "RegAllocSolver.h"
#include "SpillCodeUtils.h"
#include "SpillStack.h"
#include "dbg.h"

#include <ir_writer.h>
#include <regtochar.h>
#include <opcode_load_store.h>
#include <connect.h>
#include <edge.h>
#include <edge_utilities.h>
#include <el_control.h>
#include <intf.h>
#include <iterators.h>
#include <mdes.h>
#include <opcode.h>
#include <operand.h>
#include <reaching_defs_solver.h>
#include <region.h>
#include <slist.h>
#include <tuples.h>
#include <el_sreg_init.h>
#include <bit_vector.h>

/*************************************************************************
 * static data and functions
 *************************************************************************/

static void 	initialize(Procedure* proc_);
static void 	region_reg_alloc(Compound_region* r);  
static int	is_base_region(Region* r);
static void	reg_reconcile(const List_set<LiveRange*>& lr_list);
static void	propagate_binding (LiveRange* lr_);
static void	reg_alloc_pass_through (LiveRange* lr_);
static List<EdgedLiveRange> get_adj_edged_LR(const LiveRange* lr_, EdgeDir what);
static void	resolve_delayed_lr(const LiveRange* bound_lr_, LiveRange* target_lr_);
static void 	bind_lrs(const LiveRange* l, LiveRange* llr);
static List<Edge*> entry_edges(LiveRange* l);
static List<Edge*> exit_edges(LiveRange* l);


static Compound_region* _prologue_region = NULL;
static Compound_region* _epilogue_region = NULL;
    
// maps edges to list of ops (patchup code)
static EdgeOpsMap _spill_ops_map;

void
ScalarRegAlloc::driver(Procedure* proc_) {
    // static initialize
    init_reg_bank();

    initialize(proc_);

    El_do_reaching_defs(proc_);
    region_reg_alloc(proc_);

    generate_spill_code(proc_);

    ReconcileData::clear();
    ReconcileCodeSet::clear();
    _spill_ops_map.clear();
	
}


static void
initialize(Procedure* proc_) {
    
    // find prologue and epilogue region
    for (Region_subregions iter(proc_); iter != 0; iter++) {
	// save prologue region and epilogue region
	Region* sub_region = (*iter);
	if (sub_region->flag(EL_REGION_HAS_PROLOGUE_OP))
	    _prologue_region = (Compound_region*)sub_region;
	else if (sub_region->flag(EL_REGION_HAS_EPILOGUE_OP))
	    _epilogue_region = (Compound_region*)sub_region;
    }

    //    ReconcileData::clear();
    ReconcileData::_spill_stack.set_stack_locs(proc_);
    //    ReconcileCodeSet::clear();

    //    _spill_ops_map.clear();

}


static void
region_reg_alloc(Compound_region* r) { 

    if (!r) 
	El_punt("Null region passed to reg alloc!\n");
    else if (!is_base_region(r)) {
	// Sort the region by weight and keep the separate list
	// Original list may be added with SPILL block and we do not 
	// want to process with SPILL block again. -- Hansoo Kim
	List<Compound_region*> sorted_region_list; 

#if 1	
// region frequency order
	for (Region_subregions_freq subregs_by_freq(r); 
		 subregs_by_freq!=0; subregs_by_freq++) {
		sorted_region_list.add_tail((Compound_region*)*subregs_by_freq);
	}
#else
	for (Region_subregions subreg(r); subreg!=0; subreg++) {
		sorted_region_list.add_tail((Compound_region*)*subreg);
	}
#endif
	
	for(List_iterator<Compound_region*> iter(sorted_region_list); iter != 0; iter++) {
            region_reg_alloc(*iter);
        }
    }
    else {
        if (dbg(status, 1)) {
	  cout << "(Reg Alloc)";
	  cout << (r->is_bb() ? "bb: " : "hb: ") << r->id() << endl;
	  cout << flush;
        }

        RegAllocSolver rData(r); //dynamic_cast<Compound_region *>(r)); 
             // 1: locates all bindings that are extant on 
             //    the boundaries of *subregs_by_freq and uses them as a hint
             // 2: allocates regs only for A, Bin and Bout liveranges but
             //    Reconcile assumes that an iterator is provided to enumerate
             //    all liveranges; each liverange also has info about accesses
             // 3: assumes that calleR/E regs are known
             // 4: assumes that each liverange can be queried as to its 
             //    entry and exit edges within a region, if any
             // 5: Reconcile provides a function that gives the most preferred
             //    binding for a liverange in a region (prefBindings)

        // solve intra-RA for each data type and then call reconcile
	for (Dlist_iterator<RegAllocSolverData*> iter(rData.data_list());
	        iter != 0; iter++) {

	    RegAllocSolverData* solver_data = *iter; //should use prefBindings
            // populates data structure with reg bindings

	    const List_set<LiveRange*>& lr_set = solver_data->lr_set();
            // set of liveranges of a particular datatype

	    reg_reconcile(lr_set);
	    
	    // find all CALLEE saved register used in this region and
	    // update table
	    int i = 0;
	    for (i = FIRST_FILE; i < NUM_REG_FILE; i++) {
		if (solver_data->reg_file_name() == regfile_to_char((Reg_file)i))
		    break;
	    }

	    List_set<int>& used_callee_set = RegisterBank::_reg_bank_pool[i]._used_callee;

	    for (List_set_iterator<LiveRange*> lr_iter(lr_set); lr_iter != 0;
		 lr_iter++) {
		LiveRange* lr_ptr = *lr_iter;
		if (lr_ptr->reg_bind_state() == LiveRange::BOUND && 
		    lr_ptr->reg_convention() == CALLEE_SAVED) {
		    used_callee_set += lr_ptr->reg_num();
		}
	    }
	}
    }
}

// add non-A bindings (from region just allocated) to global bindings 
// also, propagate this to db
static void
reg_reconcile(const List_set<LiveRange*>& lr_list) {

    for (List_set_iterator<LiveRange*> li(lr_list); li!=0; li++) { 
        LiveRange* l = *li;

        // we are not interested in intra liveranges
	if (l->is_intra_region()) {
	    continue;
	}
	else {
	    ReconcileData::add2global_LR_map(l);
            //!!! add spill binding also to keep track of priority
	    //!!! assuming for the time that adding at tail will ensure
	    //!!! that edges into/out of region will be roughly in freq order
	 
	    if (l->reg_bind_state() == LiveRange::DELAYED) {
		// assert it is pass-through LiveRange
		assert(l->live_refs().size() == 0);

		// now, decide to DELAY, BIND or SPILL
		reg_alloc_pass_through(l);
	    }
	    propagate_binding(l);
	}
    }
}

static void
reg_alloc_pass_through (LiveRange* lr_) {
    assert(lr_->reg_bind_state() == LiveRange::DELAYED);

    if (lr_->caller_benefit() <0 
	&& lr_->reg_bind_benefit(CALLEE_SAVED) < 0) {
	// both benefit_caller and benefit_caller is negative
	// better spilling
	lr_->reg_bind_state(LiveRange::SPILLED);
    }
    else {
	List<LiveRangePair> sorted_lrs = ReconcileData::sorted_adj_eLRs(lr_);
	LiveRange* pref_lr = NULL;

	for (List_iterator<LiveRangePair> iter(sorted_lrs); iter != 0; iter++) {

	    LiveRangePair lr_pair = *iter;
	    LiveRange* adj_lr = NULL;
	    if (lr_pair._src_lr == lr_) {
		adj_lr = lr_pair._dest_lr;
	    }
	    else if (lr_pair._dest_lr == lr_) {
		adj_lr = lr_pair._src_lr;
	    }
	    else {
		assert(0);
	    }

	    if (adj_lr->reg_bind_state() == LiveRange::DELAYED) {
		continue;
	    }
	    else {
		pref_lr = adj_lr;
		break;
	    }
	}

	if (pref_lr == NULL) {
	    lr_->reg_bind_state(LiveRange::DELAYED);
	}
	else {
	    lr_->reg_bind_state(LiveRange::DELAYED);
	    resolve_delayed_lr(pref_lr, lr_);
	}
    }
}

//  propagate to nearby db
static void
propagate_binding (LiveRange* lr_) {
    
    assert(lr_->reg_bind_state() != LiveRange::UNDEFINED);

    // check Live-Range is bound
    if (lr_->reg_bind_state() == LiveRange::DELAYED) {
	return;
    }

    // now propagate to nearby db
    // List<EdgedLiveRange> leb = get_adj_edged_LR(lr_, ENTRY_EXIT);
    List<LiveRangePair> leb = ReconcileData::sorted_adj_eLRs(lr_);
    for (List_iterator<LiveRangePair> li(leb); li!=0; li++) {
	LiveRangePair lr_pair = *li;
	LiveRange* adj_lr = NULL;
	if (lr_pair._src_lr == lr_) {
	    adj_lr = lr_pair._dest_lr;
	}
	else if (lr_pair._dest_lr == lr_) {
	    adj_lr = lr_pair._src_lr;
	}
	else {
	    assert(0);
	}

	if (adj_lr->reg_bind_state() == LiveRange::DELAYED) {
            resolve_delayed_lr(lr_, adj_lr);
	    propagate_binding(adj_lr);
        }
        else {
	    ReconcileCodeSet::add2edge(lr_pair);
        }
    }
}



// there is a db on EdgedLiveRange eb & liverange l is the most preferred
// source of binding for db. bind from l to eb's liverange and propagate
// to other dbs
static void
resolve_delayed_lr(const LiveRange* bound_lr_, LiveRange* target_lr) {

    assert(target_lr->reg_bind_state() == LiveRange::DELAYED);

    // first try binding
    if (bound_lr_->reg_bind_state() == LiveRange::SPILLED) {
	target_lr->reg_bind_state(LiveRange::SPILLED);
    }
    else if (bound_lr_->reg_bind_state() == LiveRange::BOUND) {
	bind_lrs(bound_lr_, target_lr);
    }
    else {
	// INVALID
	assert(0);
    }
}


// bind the binding from liverange l (in one region) to liverange llr
// in another region; spill if reg already busy in latter
static void 
bind_lrs(const LiveRange* l, LiveRange* llr) {

    assert(l->reg_bind_state() == LiveRange::BOUND);
    assert(llr->reg_bind_state() == LiveRange::DELAYED);

    int reg = l->reg_num();
    // llr will be bound, only if
    //   1. l->reg_num() is not forbidden in llr
    //   2. caller_benefit/callee_benefit (according to l->reg_num())
    //      is positive  (ie. there is no function call)
    // otherwise SPILL llr

    if (El_spill_prefered_binding) {
	if (llr->forbidden().is_member(reg)) {
	    llr->reg_bind_state(LiveRange::SPILLED);
	}
	else if (llr->reg_bind_benefit(l->reg_convention())< 0) {
	    llr->reg_bind_state(LiveRange::SPILLED);
	}
	else {
	    llr->reg_bind_state(LiveRange::BOUND);
	    llr->bind_register(reg);
	    //also adds register to forbidden set of all other interfering lrs
	}
    }
    else {
	if (llr->forbidden().is_member(reg) ||
	    llr->reg_bind_benefit(l->reg_convention())< 0) {

	    reg = llr->find_register_in_pref_class();
	    if (reg < 0 || llr->reg_bind_benefit(llr->pref_reg_class()) < 0) {
		llr->reg_bind_state(LiveRange::SPILLED);
	    }
	    else {
		llr->reg_bind_state(LiveRange::BOUND);
		llr->bind_register(reg);
	    }

	}
	else {
	    llr->reg_bind_state(LiveRange::BOUND);
	    llr->bind_register(reg);
	}
    }

}




// get candidate list of directed edges & liveranges
//  
List<EdgedLiveRange>
get_adj_edged_LR(const LiveRange* lr_, EdgeDir what) {

    // get the dir edges of interest
    List<DirEdge> diredges;
    if(what==ENTRY) {
        List<Edge*> elist1= entry_edges((LiveRange*)lr_);  
	for (List_iterator<Edge*> li(elist1); li!=0; li++) {
            diredges.add_tail(DirEdge(*li, what));
        }
    } 
    else if (what==EXIT) {
        List<Edge*> elist2= exit_edges((LiveRange*)lr_);  
	for (List_iterator<Edge*> lj(elist2); lj!=0; lj++) {
            diredges.add_tail(DirEdge(*lj, what));
        }
    } 
    else if (what==ENTRY_EXIT) {
        List<Edge*> elist3= entry_edges((LiveRange*)lr_);  	
	for (List_iterator<Edge*> lk(elist3); lk!=0; lk++) {
            diredges.add_tail(DirEdge(*lk, ENTRY));
        }
        List<Edge*> elist4 = exit_edges((LiveRange*)lr_);
	for (List_iterator<Edge*> lm(elist4); lm!=0; lm++) {
            diredges.add_tail(DirEdge(*lm, EXIT));
        }
    } 
    else El_punt("Error in getCandidateEdgeBindingList\n");

    List<EdgedLiveRange> candlist;

    // now loop thru edges of interest and collect connected already extant
    // bindings for the same VR in other regions
    for (List_iterator<DirEdge> li(diredges); li!=0; li++) {
       DirEdge directed_edge = *li;
       Edge* e = (directed_edge).first;
       int dir = (directed_edge).second;
       // get to the region on the other side of edge e
       Op* counter_op = (dir==ENTRY)? e->src(): e->dest();
       Region* counter_region = counter_op->parent();
       
       // list of bindings for VR in all regions
       List<LiveRange*> lr_list = ReconcileData::global_LRs(lr_);

       for (List_iterator<LiveRange*> lli(lr_list); lli!=0; lli++) {
            LiveRange* g_lr = *lli;
            assert (g_lr->variable().vr_num() == lr_->variable().vr_num());

            if ( counter_region != (Region*)(g_lr->region()) ) 
		continue;

            // get CONNECTED bindings in counter_region with vr
            List_set<const Op*> ops;
            ops = (dir==ENTRY)? g_lr->ExitOps():g_lr->EntryOps();
            if (!ops.is_member(counter_op)) continue;
            // it is connected!
            if (g_lr->reg_bind_state() == LiveRange::DELAYED) {
		// add2DelayedBindings(directed_edge, binding, b);
		// List<DelayedBinding*>& dbl = delayedBindings.value(vr_name(lr));
		// dbl.add_tail(new DelayedBinding(directed_edge, binding, b)); 
            }
            candlist.add_tail(EdgedLiveRange(directed_edge, g_lr)); 
	}
    }
    return candlist;
}


// a region is base if unit of reg alloc/reconcile 
static int
is_base_region(Region* r) { 
    return (r->is_bb() || r->is_hb());
    // || r->is_loopbody(); // loop to be supported later 
}

// the entry edges of a liverange
static List<Edge*>
entry_edges(LiveRange* l) {

    List<Edge*> edges;
    List_set<const Op*> entryops=l->EntryOps();
    
    Compound_region* r = (Compound_region*)(l->region());
    for (List_set_iterator<const Op*> hsi(entryops); hsi!=0; hsi++) {
        const Op* op = *hsi;
        if (r->is_entry_op((Op*)op))
            for (Op_inedges it(op); it!=0; it++) {
                edges.add_tail(*it);
	    }
    }
    return edges;
}

// the exit edges of a liverange
static List<Edge*>
exit_edges(LiveRange* l) {

    List<Edge*> edges;
    List_set<const Op*> exitops=l->ExitOps();
    Compound_region* r = (Compound_region*)l->region();
    for (List_set_iterator<const Op*> hsi(exitops); hsi!=0; hsi++) {
        const Op* op = *hsi;
        if (r->is_exit_op((Op*)op))
            for (Op_outedges it(op); it!=0; it++) {
               edges.add_tail(*it);
	    }
    }
    return edges;
}


// Once a region passthrus are resolved, postprocessing 
// adds the code on edges
void 
ScalarRegAlloc::generate_spill_code(Procedure* r) {

    //
    // Now iterate thru all the edges with patchup code and 
    // create BBs

    ReconcileCodeSet::generate_reconcile_code();



    // find all used CALLEE saved register and add spill code 
    // in EPILOGUE and PROLOGUE
    int base = 0;
    int i;
    Operand pred_operand(new Pred_lit(true));
    Operand temp_operand( new Macro_reg(SPILL_TEMPREG) );

    for (i = FIRST_FILE; i < NUM_REG_FILE; i++) {
	char* file_name = regfile_to_char((Reg_file)i);
	RegisterBank& reg_bank = RegisterBank::_reg_bank_pool[i];
	List_set<int>& reg_set = RegisterBank::_reg_bank_pool[i]._used_callee;

	Data_type d_type;
	Reg_file f_type;
	if (i == GPR) {
	    d_type = EL_DT_INT;
	    f_type = GPR;
	}
	else if (i == FPR) {
	    d_type = EL_DT_DOUBLE;
	    f_type = FPR;
	}
	else if (i == PR) {
	    d_type = EL_DT_PREDICATE;
	    f_type = PR;
	    
#if 0
	    // PR will be cared by CR later. Hansoo Kim
	    if (reg_set.size() > 0) {	// temporary code for PR spilling
		Operand pr_operand(new Macro_reg(ALL_PRED));

		Op* st_pos_op = new Op( (Opcode)ADD_W);
		int stack_loc = ReconcileData::_spill_stack._var_spill_size + base;
		Operand sp_operand(new Macro_reg(SP_REG));
		Operand loc_operand(new Int_lit(stack_loc));
		st_pos_op->set_dest(DEST1, temp_operand);
		st_pos_op->set_src(SRC1, sp_operand);
		st_pos_op->set_src(SRC2, loc_operand);
		st_pos_op->set_src(PRED1, pred_operand);
		st_pos_op->set_flag(EL_OPER_SPILL_CODE);

		Op* store_op = new Op(PRED_STORE_ALL);
		store_op->set_src(SRC1, temp_operand);
		store_op->set_src(SRC2, pr_operand);
		store_op->set_src(PRED1, pred_operand);
		store_op->set_flag(EL_OPER_SPILL_CODE);

		//El_insert_op_before_switch(_prologue_region, st_pos_op);
		//El_insert_op_before_switch(_prologue_region, store_op);
		El_insert_op_after_merge(_prologue_region, store_op);
		El_insert_op_after_merge(_prologue_region, st_pos_op);
		
		Op* load_op = new Op(PRED_LOAD_ALL);
		load_op->set_dest(DEST1, pr_operand);
		load_op->set_src(SRC1, temp_operand);
		load_op->set_src(PRED1, pred_operand);
		load_op->set_flag(EL_OPER_SPILL_CODE);

		Op* ld_pos_op = new Op( (Opcode)ADD_W);
		ld_pos_op->set_dest(DEST1, temp_operand);
		ld_pos_op->set_src(SRC1, sp_operand);
		ld_pos_op->set_src(SRC2, loc_operand);
		ld_pos_op->set_src(PRED1, pred_operand);
		ld_pos_op->set_flag(EL_OPER_SPILL_CODE);

		//El_insert_op_after_merge(_epilogue_region, load_op);
		//El_insert_op_after_merge(_epilogue_region, ld_pos_op);
		El_insert_op_before_switch(_epilogue_region, ld_pos_op);
		El_insert_op_before_switch(_epilogue_region, load_op);

	    }
	    base += RegisterBank::_reg_bank_pool[i]._stack_size;
#else

	    generate_PR_spill_code(reg_bank, reg_set, base);
#endif
	    continue;
	}
	else if (i == BTR) {
	    d_type = EL_DT_BRANCH;
	    f_type = BTR;
	}
	else if (i == CR) {
	    d_type = EL_DT_POINTER;
	    f_type = CR;
	}
	else {
	    d_type = EL_DT_VOID;
	    f_type = NUM_REG_FILE;
	}

	for (List_set_iterator<int> reg_iter(reg_set); reg_iter != 0; reg_iter++) {
	    int reg_num = *reg_iter;
	    

	    int pos = reg_num;
	    int stack_loc = ReconcileData::_spill_stack._var_spill_size + base + RegisterBank::_reg_bank_pool[i].bit_width()*pos/8;

	    Operand sp_operand(new Macro_reg(SP_REG));
	    Operand loc_operand(new Int_lit(stack_loc));
	    Operand reg_operand( new Reg(d_type) );
	    reg_operand.bind_reg(reg_num);

	    Op* st_pos_op = new Op( (Opcode)ADD_W);
	    st_pos_op->set_dest(DEST1, temp_operand);
	    st_pos_op->set_src(SRC1, sp_operand);
	    st_pos_op->set_src(SRC2, loc_operand);
	    st_pos_op->set_src(PRED1, pred_operand);
	    st_pos_op->set_flag(EL_OPER_SPILL_CODE);

	    Op* store_op = NULL;
	    switch (f_type) {
	    case GPR:
	    case PR:
	    case BTR:
	    case CR:
		store_op = new Op( (Opcode)S_W_C1 );
		break;
	    case FPR:
		store_op = new Op( (Opcode)FS_D_C1 );
		break;
	    default:
		assert(0);
	    }

	    store_op->set_src(SRC1, temp_operand);
	    store_op->set_src(SRC2, reg_operand);
	    store_op->set_src(PRED1, pred_operand);
	    store_op->set_flag(EL_OPER_SPILL_CODE);

	    //El_insert_op_before_switch(_prologue_region, st_pos_op);
	    //El_insert_op_before_switch(_prologue_region, store_op);
	    El_insert_op_after_merge(_prologue_region, store_op);
	    El_insert_op_after_merge(_prologue_region, st_pos_op);

	    Op* load_op = NULL;
	    switch (f_type) {
	    case GPR:
	    case PR:
	    case BTR:
	    case CR:
		load_op = new Op( (Opcode) L_W_C1_C1);// datatype?
		break;
	    case FPR:
		load_op = new Op( (Opcode) FL_D_C1_C1);// datatype?
		break;
	    default:
		assert(0);
	    }
	    load_op->set_dest(DEST1, reg_operand);
	    load_op->set_src(SRC1, temp_operand);
	    load_op->set_src(PRED1, pred_operand);
	    load_op->set_flag(EL_OPER_SPILL_CODE);

	    Op* ld_pos_op = new Op( (Opcode)ADD_W);
	    ld_pos_op->set_dest(DEST1, temp_operand);
	    ld_pos_op->set_src(SRC1, sp_operand);
	    ld_pos_op->set_src(SRC2, loc_operand);
	    ld_pos_op->set_src(PRED1, pred_operand);
	    ld_pos_op->set_flag(EL_OPER_SPILL_CODE);

	    //El_insert_op_after_merge(_epilogue_region, ld_pos_op);
	    //El_insert_op_after_merge(_epilogue_region, load_op);
	    El_insert_op_before_switch(_epilogue_region, ld_pos_op);
	    El_insert_op_before_switch(_epilogue_region, load_op);
	}
	
	base += RegisterBank::_reg_bank_pool[i]._stack_size;
    }

    // define SWAP with register spill area size
    // Hansoo Kim
    Op* define_op = new Op((Opcode)DEFINE);
    Operand sp_operand(new Macro_reg(SWAP));
    define_op->set_dest(DEST1, sp_operand);
    Operand loc_operand(new Int_lit(ReconcileData::_spill_stack._var_spill_size+ base));
    define_op->set_src(SRC1, loc_operand);
    Region_entry_ops op_iter(r);
    Op* first_op = *op_iter;
    El_insert_op_after(first_op->parent(), define_op, first_op);

}

void
ScalarRegAlloc::generate_PR_spill_code(RegisterBank& PR_reg_bank_,
				       List_set<int>& used_PR_reg_set_,
				       int base_) 
{
    int reg_size = PR_reg_bank_._size;
    int CR_width = 32; // hard coded, fix it later

    Bitvector callee_vector(reg_size);
    for (List_set_iterator<int> reg_iter(used_PR_reg_set_); 
	 reg_iter != 0; reg_iter++) {
	int reg_num = *reg_iter;

	callee_vector.set_bit(reg_num);
    }

    for (int index = 0; index < reg_size/CR_width; index++) {
	//int mask = 0xF << index*CR_width;
	//Bitvector mask_vec(reg_size);
	//mask_vec.set_from_mask(mask);
	//cout << mask_vec << flush;

	int counter = 0;
	for (int cb = index*CR_width; cb < (index+1)*CR_width; cb++) {
	    if (callee_vector.bit(cb) == true ) {
		counter++;
	    }
	}

	//if ( (mask_vec *= callee_vector).ones_count() > 0 ) {
	if (counter > 0) {

	    Macro_name PV_i = RegisterBank::PV_num(index);
	    Operand pr_operand(new Macro_reg(PV_i));

	    int stack_loc = ReconcileData::_spill_stack._var_spill_size + base_;

	    // generate code
	    Op* st_pos_op = new Op( (Opcode)ADD_W);

	    Operand temp_operand( new Macro_reg(SPILL_TEMPREG) );
	    Operand sp_operand(new Macro_reg(SP_REG));
	    Operand loc_operand(new Int_lit(stack_loc));
	    Operand pred_operand(new Pred_lit(true));

	    st_pos_op->set_dest(DEST1, temp_operand);
	    st_pos_op->set_src(SRC1, sp_operand);
	    st_pos_op->set_src(SRC2, loc_operand);
	    st_pos_op->set_src(PRED1, pred_operand);
	    st_pos_op->set_flag(EL_OPER_SPILL_CODE);

	    Op* store_op = new Op( (Opcode)SAVE) ;
	    store_op->set_src(SRC1, temp_operand);
	    store_op->set_src(SRC2, pr_operand);
	    store_op->set_src(PRED1, pred_operand);
	    store_op->set_flag(EL_OPER_SPILL_CODE);

	    //El_insert_op_before_switch(_prologue_region, st_pos_op);
	    //El_insert_op_before_switch(_prologue_region, store_op);
	    El_insert_op_after_merge(_prologue_region, store_op);
	    El_insert_op_after_merge(_prologue_region, st_pos_op);
		
	    Op* load_op = new Op( (Opcode) RESTORE );
	    load_op->set_dest(DEST1, pr_operand);
	    load_op->set_src(SRC1, temp_operand);
	    load_op->set_src(PRED1, pred_operand);
	    load_op->set_flag(EL_OPER_SPILL_CODE);

	    Op* ld_pos_op = new Op( (Opcode)ADD_W);
	    ld_pos_op->set_dest(DEST1, temp_operand);
	    ld_pos_op->set_src(SRC1, sp_operand);
	    ld_pos_op->set_src(SRC2, loc_operand);
	    ld_pos_op->set_src(PRED1, pred_operand);
	    ld_pos_op->set_flag(EL_OPER_SPILL_CODE);

	    //El_insert_op_after_merge(_epilogue_region, load_op);
	    //El_insert_op_after_merge(_epilogue_region, ld_pos_op);
	    El_insert_op_before_switch(_epilogue_region, ld_pos_op);
	    El_insert_op_before_switch(_epilogue_region, load_op);

	    base_ += (CR_width/8);

	}
    }
}


