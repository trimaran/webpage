/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1995 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           el_loop.cpp
//      Author:         David I. August
//      Created:        May 1995
//      Description:    Loop Class Definition
//
/////////////////////////////////////////////////////////////////////////////

#include "op.h"
#include "adjlist_graph.h"
#include "control_analysis_solver.h"
#include "el_bb_tools.h"
#include "el_control.h"
#include "el_induction_var.h"
#include "el_loop.h"
#include "el_loop_iterators.h"
#include "el_loop_filters.h"
#include "el_loop_tools.h"
#include "iterators.h"
#include "attributes.h"
#include "connect.h"
#include "edge_attributes.h"
#include "opcode_properties.h"
#include "list_ofp.h"
#include "edge.h"
#include "hash_functions.h"
#include "el_tail_duplication.h"

#undef DEBUG


////////////////////////////////////////////////////////////
//  Class El_Loop
////////////////////////////////////////////////////////////

El_Loop::El_Loop()
{
  id = -1;
  nesting_level = -1;
  category = UNCLASSIFIED;
  swp_status = UNKNOWN;
  preloop_block = NULL;
  header_block = NULL;
  num_invocation = 0;
  num_iteration = 0;
}

El_Loop::El_Loop(int new_id, Basicblock* new_head)
{
  id = new_id;
  header_block = new_head;

  nesting_level = -1;
  category = UNCLASSIFIED;
  swp_status = UNKNOWN;
  preloop_block = NULL;
  num_invocation = 0;
  num_iteration = 0;
}

El_Loop::~El_Loop()
{
}


// Loop print function 
ostream& operator<<(ostream& os, const El_Loop& loop)
{
  loop.print(os);
  return os;
}


void El_Loop::print(ostream& os) const
{

  os << "LOOP:" << endl;
  os << "      ID: " << id << endl;
  os << "      Header: " << header_block->id() << endl;
  os << "      Invocations: " << num_invocation << endl;
  os << "      Iteratinos: " << num_iteration << endl;
  
  os << "      Category: ";
  switch(category)
    {
    case UNCLASSIFIED:
      cout << "UNCLASSIFIED" << endl;
      break;
    case MARKED_FOR_DELETION:
      cout << "MARKED_FOR_DELETION" << endl;
      break;
    case DO_LOOP:
      cout << "DO_LOOP" << endl;
      break;
    case WHILE_LOOP:
      cout << "WHILE_LOOP" << endl;
      break;
    default:
      El_punt("El_Loop::print: unknown category.");
    }

  os << "      SWP Status: ";
  switch(swp_status)
    {
    case UNKNOWN:
      cout << "UNKNOWN" << endl;
      break;
    case NOT_SWP_ABLE:
      cout << "NOT_SWP_ABLE" << endl;
      break;
    case SWP_ABLE:
      cout << "SWP_ABLE" << endl;
      break;
    default:
      El_punt("El_Loop::print: unknown swp status.");
    }
  
  os << "      Nest Level: " << nesting_level << endl;
  if(preloop_block)
    {
      os << "      Preloop Block: " << preloop_block->id() << endl;
    }
  else
    {
      os << "      Preloop Block: NONE" << endl;
    }

  os << "      Loop Blocks: ";
  Hash_set_iterator<Basicblock*> bb_iter ;
  for(bb_iter(loop_blocks); bb_iter != 0; bb_iter++)
    {
      os << (*bb_iter)->id() << " ";
    }
  os << endl;
  os << "      Back Edge Blocks: ";
  for(bb_iter(back_edge_blocks); bb_iter != 0; bb_iter++)
    {
      os << (*bb_iter)->id() << " ";
    }
  os << endl;
  os << "      Exit Blocks: ";
  for(bb_iter(exit_blocks); bb_iter != 0; bb_iter++)
    {
      os << (*bb_iter)->id() << " ";
    }
  os << endl;
  os << "      Postloop Blocks: ";
  for(bb_iter(postloop_blocks); bb_iter != 0; bb_iter++)
    {
      os << (*bb_iter)->id() << " ";
    }
  os << endl;

  os << "      Basic Induction Variables: " << endl;
  for(Hash_set_iterator<Operand> oper_iter(basic_ind_var); oper_iter != 0; oper_iter++)
    {
      os << "            " << (*oper_iter) << endl;
    }
  os << endl;
  
  os << "      Basic Induction Variable Ops: ";
  Hash_set_iterator<Op*> op_iter ;
  for(op_iter(basic_ind_var_ops); op_iter != 0; op_iter++)
    {
      os << (*op_iter)->id() << " ";
    }
  os << endl << endl;
  
  os << "      Primary Induction Variable:" << primary_ind_var << endl;
  
  os << "      Primary Induction Variable Ops: ";
  for(op_iter(primary_ind_var_ops); op_iter != 0; op_iter++)
    {
      os << (*op_iter)->id() << " ";
    }
  os << endl;
  os << endl;
  
}

////////////////////////////////////////////////////////////
//  Class El_Loop_Graph
////////////////////////////////////////////////////////////


void El_Loop_Graph::Find_Blocks_In_Loop(El_Loop* loop)
{
  Hash_set<Basicblock*> temp_loop_blocks ;
  
  if(!loop)
    {
      El_punt("El_Loop_Graph::Find_Blocks_In_Loop: Passed NULL pointer.");
    }

  for(Hash_set_iterator<Basicblock*> back_iter(loop->back_edge_blocks); back_iter != 0; back_iter++)
    {
      int start = control->graph->f_map.value(*back_iter);
      temp_loop_blocks += loop->back_edge_blocks.head();
      int stop = control->graph->f_map.value(loop->header_block);
      temp_loop_blocks += loop->header_block;

      for(Alist_graph_bfs node_iter(*(control->graph), UP, start, stop); node_iter != 0; node_iter++)
	{
	  temp_loop_blocks += (Basicblock*) control->graph->b_map[*node_iter];
#ifdef DEBUG
	  cout << "Adding Block to Loop " << ((Basicblock*) control->graph->b_map[*node_iter])->id();
#endif
	}
    }

  loop->loop_blocks.clear();
  /*
  **  Go through all the ops in layout order to make the loop_blocks list be in layout order
  */
  for(Hash_set_iterator<Basicblock*> bb_iter(bb_set) ; bb_iter != 0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter ;
      
      if (temp_loop_blocks.is_member(cur_bb))
	{
	  loop->loop_blocks += cur_bb;
	}
    }
   
}

void El_Loop_Graph::Find_Exit_Blocks_In_Loop(El_Loop* loop)
{
  if(!loop)
    {
      El_punt("El_Loop_Graph::Find_Exit_Blocks_In_Loop: Passed NULL pointer.");
    }
  loop->exit_blocks.clear();
  loop->postloop_blocks.clear();

  if(loop->loop_blocks.is_empty())
    {
      El_punt("El_Loop_Graph::Find_Exit_Blocks_In_Loop: Empty Loop.");
    }
  
  for(Hash_set_iterator<Basicblock*> bb_iter(loop->loop_blocks); bb_iter != 0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter;
#ifdef DEBUG
      cout << "Loop Block " << cur_bb->id() << endl;
#endif
      for (Region_exit_edges exit_iter(cur_bb); exit_iter!=0; exit_iter++)
	{
#ifdef DEBUG
	  cout << "Dest Block " << (*exit_iter)->dest()->parent()->id() << endl;
#endif
	  Basicblock* dest_bb = (Basicblock*) (*exit_iter)->dest()->parent();
	  
	  if (!loop->loop_blocks.is_member(dest_bb))
	    {
	      loop->exit_blocks += cur_bb;
	      loop->postloop_blocks += dest_bb;
	    }
	}
    }
}

void El_Loop_Graph::Delete_Marked_Loops()
{
  Listofp<El_Loop*> loop_list;
    
  for(Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      loop_list.add_tail((*loop_iter).second);
    }
  
  for(Listofp_iterator<El_Loop*> loop_iter1(loop_list); loop_iter1 != 0; loop_iter1++)
    {
      El_Loop* loop1 = *loop_iter1;
      
      // Delete Marked Loops
      if(loop1->category == MARKED_FOR_DELETION)
	{
	  id.unbind(loop1->id);
	  child.unbind(loop1);
	  parent.unbind(loop1);
	  sibling.unbind(loop1);
	  delete loop1;
	}
    }
  
}


void El_Loop_Graph::Merge_Loops()
{
  Listofp<El_Loop*> loop_list;
  
  for(Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      loop_list.add_tail((*loop_iter).second);
    }
  
  for(Listofp_iterator<El_Loop*> loop_iter1(loop_list); loop_iter1 != 0; loop_iter1++)
    {
      Listofp_iterator<El_Loop*> loop_iter2;
      for((loop_iter2 = loop_iter1), loop_iter2++; loop_iter2 != 0; loop_iter2++)
	{
	  El_Loop* loop1 = *loop_iter1;
	  El_Loop* loop2 = *loop_iter2;
	  
	  // Merge Loops if their headers are equal
	  if(loop1->category == MARKED_FOR_DELETION ||
	     loop2->category == MARKED_FOR_DELETION)
	    {
	      continue;
	    }
	  if(loop1->header_block == loop2->header_block)
	    {
	      // Both loop get merged into Loop 1
	      loop1->loop_blocks += loop2->loop_blocks;
	      loop1->back_edge_blocks += loop2->back_edge_blocks;
	      loop2->category = MARKED_FOR_DELETION;
	    } 
	}
    }
  Delete_Marked_Loops();
}

void El_Loop_Graph::Find_Num_Invocation(El_Loop* loop)
{
  if(!loop)
    {
      El_punt("El_Loop_Graph::Find_Num_Invocation: Passed NULL pointer.");
    }
  loop->num_iteration = loop->header_block->weight;
  loop->num_invocation = loop->header_block->weight;
  for (Region_entry_edges entry_iter(loop->header_block); entry_iter!=0; entry_iter++)
    {
      Basicblock* src_bb = (Basicblock*) (*entry_iter)->src()->parent();
      
      if (loop->loop_blocks.is_member(src_bb))
	{
	  loop->num_invocation -= get_control_flow_freq(*entry_iter)->freq;
	}
    }
  
}

void El_Loop_Graph::Loop_Detection()
{
  Basicblock* cur_bb;
  Basicblock* dest_bb;
  
  for(Hash_set_iterator<Basicblock*> bb_iter(bb_set); bb_iter != 0; bb_iter++)
    {
      cur_bb = *bb_iter;

      for (Region_exit_edges exit_iter(cur_bb); exit_iter!=0; exit_iter++)
	{
	  dest_bb = (Basicblock*) (*exit_iter)->dest()->parent();
	  
	  if (control->is_dom(dest_bb, cur_bb))
	    {
#ifdef DEBUG
	      cout << "FOUND A LOOP" << cur_bb->id() << " : " << dest_bb->id() << endl;
#endif
	      El_Loop* new_loop = new El_Loop(cur_id, dest_bb);
	      id.bind(cur_id, new_loop);
	      new_loop->back_edge_blocks += cur_bb;
	      Find_Blocks_In_Loop(new_loop);
	      Find_Exit_Blocks_In_Loop(new_loop);
	      cur_id++;
	    }
	}
    }
  
  Merge_Loops();

  for(Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      El_Loop* loop = (*loop_iter).second;
	  
      Find_Exit_Blocks_In_Loop(loop);
      Find_Num_Invocation(loop);
    }
}

Basicblock* El_Loop_Graph::Create_Loop_Preheader(El_Loop* loop)
{
  Basicblock* preheader = new Basicblock;
  Op* merge_op;
  Op* switch_op;
  Op* header_op;
  Op* last_op;
  Compound_region* insert_region;
  Edge* edge;
  Compound_region* header_region;
  bool fall_through;
  Control_flow_freq *cfreq;
  
  preheader->weight = loop->num_invocation;
  preheader->set_parent(region);
  preheader->set_flag(EL_REGION_PRELOOP_BLOCK);
  
  merge_op = new Op(C_MERGE) ;
  preheader->add_region(merge_op) ;
  merge_op->set_parent(preheader) ;
  preheader->add_entry(merge_op);
  
  fall_through = true;
  Region_entry_edges entry_iter ;
  for (entry_iter(loop->header_block); entry_iter!=0; entry_iter++)
    {
      Basicblock* prev_bb = (Basicblock*) (*entry_iter)->src()->parent();
      Edge* edge = (*entry_iter);

      if(edge->dest_alt() == 0)
	{
	  if(loop->loop_blocks.is_member(prev_bb))
	    {
	      fall_through = false;
	    }
	}
    }

  header_op = get_first_region_op_from_subregions(loop->header_block);
  
  if(fall_through)
    {
      switch_op = new Op(DUMMY_BR) ;
      preheader->add_region(switch_op) ;
      switch_op->set_parent(preheader) ;
      preheader->add_exit(switch_op);
      
      C0_connect_fallthrough(merge_op, switch_op) ;

      header_region = loop->header_block;
      while (header_region->parent() != region)
	{
	  header_region = header_region->parent();
	}
      region->insert_before_region(preheader, header_region);
      
      Region_entry_edges entry_iter ;
      for (entry_iter(loop->header_block); entry_iter!=0; entry_iter++)
	{
	  Basicblock* prev_bb = (Basicblock*) (*entry_iter)->src()->parent();
	  Edge* edge = (*entry_iter);
	  
	  if((!loop->loop_blocks.is_member(prev_bb)) && (preheader != prev_bb))
	    {
	      edge->set_dest(merge_op, edge->dest_port(), edge->dest_alt());
	      merge_op->add_inedge_recursively(edge);
	    }
	}

      edge = C0_connect_fallthrough(switch_op, header_op) ;
      switch_op->add_outedge_recursively(edge);
      header_op->add_inedge_recursively(edge);
      cfreq = new Control_flow_freq();
      cfreq->freq = preheader->weight;
      set_control_flow_freq(edge, cfreq);
      
      for (entry_iter(preheader); entry_iter!=0; entry_iter++)
	{
	  Edge* edge = (*entry_iter);
	  header_op->remove_inedge_recursively(edge);
	}
    }
  else
    {
      last_op = get_last_region_op_from_subregions(region);
      insert_region = last_op->parent();
      while (insert_region->parent() != region)
	{
	  insert_region = insert_region->parent();
	}
      region->insert_after_region(preheader, insert_region);

      El_add_jump_to_region(preheader, header_op);

      Region_entry_edges entry_iter ;
      for (entry_iter(loop->header_block); entry_iter!=0; entry_iter++)
	{
	  Basicblock* prev_bb = (Basicblock*) (*entry_iter)->src()->parent();
	  Edge* edge = (*entry_iter);
	  
	  if((!loop->loop_blocks.is_member(prev_bb)) && (preheader != prev_bb))
	    {
	      if(edge->dest_alt() == 0)
		{
		   edge->set_dest(merge_op, edge->dest_port(),
				  get_new_in_alt_num(edge->dest()));
		}
	      else
		{
		  edge->set_dest(merge_op, edge->dest_port(), edge->dest_alt());
		}
	      merge_op->add_inedge_recursively(edge);
	    }
	}

      edge = C0_connect(switch_op, header_op) ;
      switch_op->add_outedge_recursively(edge);
      header_op->add_inedge_recursively(edge);

      for (entry_iter(preheader); entry_iter!=0; entry_iter++)
	{
	  Edge* edge = (*entry_iter);

	  header_op->remove_inedge_recursively(edge);
	}
    }
  
  return preheader;
}

void El_Loop_Graph::create_preloop_blocks(const Loop_filter* filter)
{
   Map_iterator<int, El_Loop*> loop_iter ;
   for(loop_iter(id); loop_iter != 0; loop_iter++)
      {
	 El_Loop* loop = (*loop_iter).second;

	 if(!filter_match(filter, loop))
	 {
	    continue;
	 }
      
	 for (Region_entry_edges entry_iter(loop->header_block); entry_iter!=0; entry_iter++)
	 {
	    Basicblock* prev_bb = (Basicblock*) (*entry_iter)->src()->parent();
	  
	    if (prev_bb->flag(EL_REGION_PRELOOP_BLOCK))
	    {
	       loop->preloop_block = prev_bb;
	    }
	 }
	 if(loop->preloop_block == NULL)
	 {
	    loop->preloop_block = Create_Loop_Preheader(loop);
	 }
      }
  
   delete control;
   control = new Dominator_CFA_solver(region);
   control->solve();

   for(loop_iter(id); loop_iter != 0; loop_iter++)
   {
      El_Loop* loop = (*loop_iter).second;
      
      Find_Blocks_In_Loop(loop);
      Find_Exit_Blocks_In_Loop(loop);
   }
  
}

Basicblock* El_Loop_Graph::Create_Loop_Postheader(El_Loop* loop, Basicblock* exit_bb, Basicblock* dest_bb)
{
  Basicblock* postheader = new Basicblock;
  Edge* orig_edge;
  Edge* new_edge;
  Edge* fall_through_edge = NULL;
  Op* merge_op;
  Op* switch_op;
  Op* dest_op;
  Op* last_op;
  Compound_region* insert_region;
  Control_flow_freq *cfreq;
    
  postheader->set_flag(EL_REGION_POSTLOOP_BLOCK);
  
  merge_op = new Op(C_MERGE) ;
  postheader->add_region(merge_op) ;
  merge_op->set_parent(postheader) ;
  postheader->add_entry(merge_op);
  
  fall_through_edge = NULL;
  for (Region_entry_edges entry_iter(dest_bb); entry_iter!=0; entry_iter++)
    {
      Basicblock* src_bb = (Basicblock*) (*entry_iter)->src()->parent();
      
      if (src_bb == exit_bb)
	{
	  postheader->weight = get_control_flow_freq(*entry_iter)->freq;
	  orig_edge = *entry_iter;
	  
	  if((*entry_iter)->dest_alt() == 0)
	    {
	      fall_through_edge = (*entry_iter);
	    }
	}
    }

  if (fall_through_edge)
    {
      switch_op = new Op(DUMMY_BR) ;
      postheader->add_region(switch_op) ;
      switch_op->set_parent(postheader) ;
      postheader->add_exit(switch_op);
      
      C0_connect_fallthrough(merge_op, switch_op);
      
      Compound_region* dest_bb_region;

      dest_op = get_first_region_op_from_subregions(dest_bb);
      dest_bb_region = dest_bb;
      while (dest_bb_region->parent() != region &&
	     dest_op == get_first_region_op_from_subregions(dest_bb_region->parent()))
	{
	  dest_bb_region = dest_bb_region->parent();
	}

      postheader->set_parent(dest_bb_region->parent());
      dest_bb_region->parent()->insert_before_region(postheader, dest_bb_region);
      
      new_edge = C0_connect_fallthrough(switch_op, dest_op) ;
      switch_op->add_outedge_recursively(new_edge);
      dest_op->add_inedge_recursively(new_edge);
      cfreq = new Control_flow_freq();
      cfreq->freq = postheader->weight;
      set_control_flow_freq(new_edge, cfreq);
      
      orig_edge->set_dest(merge_op, orig_edge->dest_port(), orig_edge->dest_alt());
      merge_op->add_inedge_recursively(orig_edge);
      dest_op->remove_inedge_recursively(orig_edge);
    }
  else
    {
      postheader->set_parent(region);

      dest_op = get_first_region_op_from_subregions(dest_bb);

      last_op = get_last_region_op_from_subregions(region);
      insert_region = last_op->parent();
      while (insert_region->parent() != region)
	{
	  insert_region = insert_region->parent();
	}
      region->insert_after_region(postheader, insert_region);

      El_add_jump_to_region(postheader, dest_op);
      
      orig_edge->set_dest(merge_op, orig_edge->dest_port(), orig_edge->dest_alt());
      merge_op->add_inedge_recursively(orig_edge);
      dest_op->remove_inedge_recursively(orig_edge);
    }
  
  return postheader;
}

void El_Loop_Graph::create_postloop_blocks(const Loop_filter* filter)
{
   Map_iterator<int, El_Loop*> loop_iter ;
   for(loop_iter(id); loop_iter != 0; loop_iter++)
   {
      El_Loop* loop = (*loop_iter).second;

      if(!filter_match(filter, loop))
      {
	 continue;
      }
      
      for(Hash_set_iterator<Basicblock*> exit(loop->exit_blocks); exit != 0; exit++)
      {
	 Basicblock* exit_bb = *exit;
	  
	 for (Region_exit_edges exit_iter(exit_bb); exit_iter!=0; exit_iter++)
	 {
	    Basicblock* dest_bb = (Basicblock*) (*exit_iter)->dest()->parent();

	    if (!loop->loop_blocks.is_member(dest_bb))
	    {
	       if (dest_bb->flag(EL_REGION_POSTLOOP_BLOCK))
	       {
#ifdef DEBUG
		  cout << "This is no good it's id is " << dest_bb->id() << endl;
#endif
		  break;
	       }
#ifdef DEBUG
	       cout << "SHOULD CREATE POSTHEADER" << endl;
#endif
	       loop->postloop_blocks += Create_Loop_Postheader(loop, exit_bb, dest_bb);
	    }
	 }
      }
   }
  
  
   delete control;
   control = new Dominator_CFA_solver(region);
   control->solve();
  
   for(loop_iter(id); loop_iter != 0; loop_iter++)
   {
      El_Loop* loop = (*loop_iter).second;

      Find_Blocks_In_Loop(loop);
      Find_Exit_Blocks_In_Loop(loop);
   }
  
}

void El_Loop_Graph::Find_Nesting_Levels()
{
   Map_iterator<int, El_Loop*> loop_iter1 ;
   for(loop_iter1(id); loop_iter1 != 0; loop_iter1++)
   {
      El_Loop* loop1 = (*loop_iter1).second;
      
      loop1->nesting_level = 1;
   }
   for(loop_iter1(id); loop_iter1 != 0; loop_iter1++)
   {
      El_Loop* loop1 = (*loop_iter1).second;
      
      for(Map_iterator<int, El_Loop*> loop_iter2(id); loop_iter2 != 0; loop_iter2++)
      {
	 El_Loop* loop2 = (*loop_iter2).second;

	 if (loop1 == loop2)
	 {
	    continue;
	 }
	  
	 if (El_loop_is_nested(loop1, loop2))
	 {
	    loop2->nesting_level += 1;
	 }
      }
   }
}

void El_Loop_Graph::Connect_Loop_Hierarchy()
{
  for(Map_iterator<int, El_Loop*>loop_iter2(id); loop_iter2 != 0; loop_iter2++)
    {
      El_Loop* loop2 = (*loop_iter2).second;
      if(loop2->nesting_level == 1)
	{
	  continue;
	}
      
      for(Map_iterator<int, El_Loop*> loop_iter1(id); loop_iter1 != 0; loop_iter1++)
	{
	  El_Loop* loop1 = (*loop_iter1).second;

	  if (loop1 == loop2)
	    {
	      continue;
	    }

	  if (loop2->nesting_level == (loop1->nesting_level + 1))
	    {
	      if(El_loop_is_nested(loop1, loop2))
		{
		  parent.bind(loop2, loop1);
		  if(child.is_bound(loop1))
		    {
		      sibling.bind(loop2, child.value(loop1));
		    }
		  child.bind(loop1, loop2);
		  break;
		}
	    }
	}
    }
  
  first_loop = NULL;
  El_Loop* loop2 = NULL;
  for(Map_iterator<int, El_Loop*>loop_iter1(id); loop_iter1 != 0; loop_iter1++)
    {
      El_Loop* loop1 = (*loop_iter1).second;
      if(loop1->nesting_level == 1)
	{
	  if(!first_loop)
	    {
	      first_loop = loop1;
	    }
	  else
	    {
	      sibling.bind(loop2, loop1);
	    }
	  loop2 = loop1;
	}
    }
}

void El_Loop_Graph::Build_Loop_Hierarchy()
{
  Find_Nesting_Levels();
  Connect_Loop_Hierarchy();

  num_loops = 0;
  for(Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      num_loops++;
    }
}


El_Loop_Graph::El_Loop_Graph()
{
}

El_Loop_Graph::El_Loop_Graph(Compound_region *reg)
{
  region = reg;
  cur_id = 0;
  first_loop = NULL;

  if(!El_confirm_BB_tiling(region, bb_set)) { // this not only confirms tiling
                                              // but also fills bb_set
     El_punt("El_Loop_Graph::El_Loop_Graph: Not a full BB tiling");
  }
  control = new Dominator_CFA_solver(reg);
  control->solve();
  
  Loop_Detection();
  
  Build_Loop_Hierarchy();
       
}


El_Loop_Graph::~El_Loop_Graph()
{
  delete control;
  for(Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      delete((*loop_iter).second);
    }
  
}

// Loop Graph print function 
ostream& operator<<(ostream& os, const El_Loop_Graph& loop_graph)
{
  loop_graph.print(os);
  return os;
}

void El_Loop_Graph::print(ostream& os) const
{
  os << "LOOP GRAPH:" << endl << endl;

  for(Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      os << *((*loop_iter).second) << endl;
    }
}




////////////////////////////////////////////////////////////
//  El_Loop_Graph: Induction variable functions
////////////////////////////////////////////////////////////

bool El_Loop::is_invariant(Operand* operand)
{
  for(Hash_set_iterator<Basicblock*> bb_iter(loop_blocks); bb_iter != 0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter;
      if(!El_is_invariant(cur_bb, operand))
	{
	  return false;
	}
    }
  return true;
}


bool El_Loop::is_unique_def(Op* op)
{
  for(Hash_set_iterator<Basicblock*> bb_iter(loop_blocks); bb_iter != 0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter;
      if(!El_is_unique_def(cur_bb, op))
	{
	  return false;
	}
    }
  return true;
}

void El_Loop::find_induction_variables()
{
  for (Hash_set_iterator<Basicblock*> bb_iter(loop_blocks); bb_iter != 0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter;
      El_normalize_operands_by_type(cur_bb);

      for (Region_all_ops op_iter(cur_bb); op_iter != 0; op_iter++)
	{
	  Op* cur_op = *op_iter;

	  /*
	  ** BRLC ops are special since they LC = LC + 1 implicitely
	  */
	  if(is_brlc(cur_op))
	    {
	      basic_ind_var += cur_op->dest(DEST1);
	      continue;
	    }
	  if (!El_op_has_induction_pattern(cur_op))
	    {
	      continue;
	    }
	  if (basic_ind_var.is_member(cur_op->dest(DEST1)))
	    {
	      continue;
	    }
	  if(!is_invariant(&cur_op->src(SRC2)))
	    {
	      continue;
	    }
	  if(!is_unique_def(cur_op))
	    {
	      continue;
	    }
	  
	  /*
	   *  Record as basic induction variable
	   */
	  
	  basic_ind_var += cur_op->dest(DEST1);
	}
    }
}

void El_Loop::find_induction_ops()
{
  for (Hash_set_iterator<Basicblock*> bb_iter(loop_blocks); bb_iter != 0; bb_iter++)
    {
      for (Region_all_ops op_iter(*bb_iter); op_iter != 0; op_iter++)
	{
	  Op* cur_op = *op_iter;

	    if (cur_op->num_dests() < 1 || !cur_op->dest(DEST1).is_reg())
	      {
		continue;
	      }
            if (!basic_ind_var.is_member(cur_op->dest(DEST1)))
	      {
		continue;
	      }
	  	  
	  /*
	   *  Record as basic induction variable op
	   */
	  
	  basic_ind_var_ops += cur_op;
	}
    }
}



int El_Loop::potential_primary_ind_op_count(Basicblock* bb)
{
  Hash_set<Basicblock*> visited(hash_bb_ptr, 197);
  Hash_set<Basicblock*> to_visit(hash_bb_ptr, 197);
  int count=0;
  
  to_visit += bb;

  while(!to_visit.is_empty())
    {
      Basicblock* cur_bb = to_visit.pop();
      visited += cur_bb;

      if(cur_bb != header_block)
	{
	  for (Region_entry_edges entry_iter(cur_bb); entry_iter != 0; entry_iter++)
	    {
	      Basicblock* src_bb = (Basicblock*)(*entry_iter)->src()->parent();
	      
	      if (loop_blocks.is_member(src_bb) && !visited.is_member(src_bb))
		{
		  to_visit += src_bb;
		}
	    }
	}

      for(Region_all_ops op_iter(cur_bb); op_iter != 0; op_iter++)
	{
	  Op* cur_op = (Op*) *op_iter;

	  if(primary_ind_var_ops.is_member(cur_op))
	    {
	      count++;
	    }
	}
    }
  
  return count;
  
}

void El_Loop::find_primary_ind_var(Dominator_CFA_solver *control)
{
  Op* branch_op;
  Hash_set<Operand> potential_primary_ind_var;
  Hash_set_iterator<Basicblock*> bb_iter;
  Hash_set_iterator<Op*> op_iter;
  int can_encounter_ops;

  if(category != UNCLASSIFIED)
    {
      El_punt("find_primary_ind_var: Can only be run on unclassified loops");
    }
  
  for (bb_iter(back_edge_blocks); bb_iter != 0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter;
      El_normalize_operands_by_list(cur_bb, basic_ind_var);

      branch_op = El_get_branch_op(cur_bb);

      /*
      ** This may already be a brlc'ified loop
      */
      if(is_brlc(branch_op))
	{
	  primary_ind_var = branch_op->dest(DEST1);
	  find_primary_ind_var_ops();
	  category = DO_LOOP;
	  return;
	}
      
      if(!is_conditional_branch(branch_op))
	{
	  category = WHILE_LOOP;
	  return;
	}

      Op* cond_op = El_get_cond_for_branch(branch_op);

      // If condition is not invariant, we have a while_loop
      if(!is_invariant(&cond_op->src(SRC2)))
	{
	  category = WHILE_LOOP;
	  return;
	}

      if(basic_ind_var.is_member(cond_op->src(SRC1)))
	{
	  potential_primary_ind_var += cond_op->src(SRC1);
	}
    }
  
  if(potential_primary_ind_var.size() != 1)
    {
      category = WHILE_LOOP;
      return;
    }
  
  primary_ind_var = potential_primary_ind_var.head();
  find_primary_ind_var_ops();

  /*
   *  Ensure that all invariants are the same and that all the
   *  ops are not predicated.
   */

  Operand invariant = primary_ind_var_ops.head()->src(SRC2);
  for(op_iter(primary_ind_var_ops); op_iter != 0; op_iter++)
    {
      Op* cur_op = *op_iter;

      if(!cur_op->src(PRED1).is_predicate_true())
	{
	  category = WHILE_LOOP;
	  return;
	}

      if(cur_op->src(SRC2) != invariant)
	{
	  category = WHILE_LOOP;
	  return;
	}
    }
    
  /*
   *  Ensure all backedges have the same number of potential
   *  primary induction ops.
   */
  
  can_encounter_ops = -1;
  for(bb_iter(back_edge_blocks); bb_iter != 0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter;
      
      if(can_encounter_ops == -1)
	{
	  can_encounter_ops = potential_primary_ind_op_count(cur_bb);
	}
      else
	{
	  if(can_encounter_ops != potential_primary_ind_op_count(cur_bb))
	    {
	      category = WHILE_LOOP;
	      return;
	    }
	}
    }
    
  /*
   *  Insure that all backedges are dominated by the same number of
   *  potential primary induction ops.
   */
  
  for(bb_iter(back_edge_blocks); bb_iter != 0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter;
      int must_encounter_ops = 0;
      for(op_iter(primary_ind_var_ops); op_iter != 0; op_iter++)
	{
	  Op* cur_op = *op_iter;

	  if(control->is_dom((Basicblock*)cur_op->parent(), cur_bb))
	    {
	      must_encounter_ops++;
	    }
	}
      if(must_encounter_ops != can_encounter_ops)
	{
	  category = WHILE_LOOP;
	  return;
	}
    }

  /*
  **  Insure that all backedges have the same branch cond
  */
  
  for(bb_iter(back_edge_blocks); bb_iter != 0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter;
      Op* cond_op = NULL;
      if(!cond_op)
	{
	  Op* branch_op = El_get_conditional_branch_op(cur_bb);
	  cond_op = El_get_cond_for_branch(branch_op);
	}
      else
	{
	  Op* branch_op = El_get_conditional_branch_op(cur_bb);
	  if(cond_op != El_get_cond_for_branch(branch_op))
	    {
	      category = WHILE_LOOP;
	      return;
	    }
	}
    }

  /*
  **  We made it, this must be a do loop.
  */
  category = DO_LOOP;
    
}

void El_Loop::find_primary_ind_var_ops()
{

  for (Hash_set_iterator<Basicblock*> bb_iter(loop_blocks); bb_iter != 0; bb_iter++)
    {
      for (Region_all_ops op_iter(*bb_iter); op_iter != 0; op_iter++)
	{
	  Op* cur_op = *op_iter;

	    if (cur_op->num_dests() < 1 || !cur_op->dest(DEST1).is_reg())
	      {
		continue;
	      }
            if (primary_ind_var != (cur_op->dest(DEST1)))
	      {
		continue;
	      }
	  	  
	  /*
	   *  Record as basic induction variable op
	   */
	  
	  primary_ind_var_ops += cur_op;
	}
    }
}

void El_Loop_Graph::find_induction_variable_info(const Loop_filter* filter)
{
  for (Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      El_Loop* loop = (*loop_iter).second;

      if (!filter_match(filter, loop))
	{
	  continue;
	}

      loop->find_induction_variables();
      loop->find_induction_ops(); 

      loop->find_primary_ind_var(control);
    }
}



/*
 *  The following is used to determine if a loop is SWP
 */

void El_Loop::mark_swp_able()
{

  // If it is not a counted loop, it is not swpable
  if(category == WHILE_LOOP)
    {
      swp_status = NOT_SWP_ABLE;
      return;
    }

  if(category != DO_LOOP)
    {
      El_punt("El_Loop::mark_swp_able: You must run find_induction_variable_info first");
    }

  // if it doesn't have exactly 1 back edge, it is not swpable
  if(back_edge_blocks.size() != 1)
    {
      swp_status = NOT_SWP_ABLE;
      return;
    }
  
  // if it doesn't have exactly 1 exit edges, it is not swpable
  if(exit_blocks.size() != 1)
    {
      swp_status = NOT_SWP_ABLE;
      return;
    }

  // if it contains a jsr, it is not swpable
  for(Hash_set_iterator<Basicblock*> bb_iter(loop_blocks); bb_iter!=0; bb_iter++)
    {
      if(El_region_has_jsr(*bb_iter))
	{
	  swp_status = NOT_SWP_ABLE;
	  return;
	}
    }

  // If it is not contigous, it is not swpable

  if(!is_contiguous())
    {
      swp_status = NOT_SWP_ABLE;
      return;
    } 

  // If it contains any internal control flow its not swpable
  // This check is too pessimistic, need to fix

  if (loop_blocks.size() != 1)
    {
      swp_status = NOT_SWP_ABLE;
      return;
    }

  swp_status = SWP_ABLE;
  return;
  
}


void El_Loop_Graph::find_swp_able_loops(const Loop_filter* filter)
{
  for (Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      El_Loop* loop = (*loop_iter).second;

      if (!filter_match(filter, loop))
	{
	  continue;
	}
      
      // if it is not an INNERMOST loop then it is not swpable
      if (child.is_bound(loop))
	{
	  loop->swp_status = NOT_SWP_ABLE;
	  continue;
	}

      loop->mark_swp_able();

    }
}


/*
 *  The following inserts brlc into counted loops
 */


void El_Loop::insert_brlc()
{
  if (preloop_block == NULL)
    {
      El_punt("El_Loop::insert_brlc: Loop must have preheader.");
    }
  
  if (category != DO_LOOP)
    {
      El_punt("El_Loop::insert_brlc: BRLC can only be inserted into counted loops");
    }
  
  Op* branch_op = El_get_branch_op(back_edge_blocks.head());

  if(is_brlc(branch_op))
    {
      /* BRLC already created for this loop */
      return;
    }

  Op* cond_op = El_get_cond_for_branch(branch_op);
  
  Opcode test_cond = cond_op->opcode();

  Operand final_var = cond_op->src(SRC2);
  Operand ind_var = cond_op->src(SRC1);
  Operand pred_true = new Pred_lit(true);

  if(ind_var != primary_ind_var)
    {
      El_punt("El_Loop::insert_brlc: Something funny is going on with primary_ind_var's");
    }

  Operand step_var = primary_ind_var_ops.head()->src(SRC2);
  bool step_var_inverted = false;

  /* Invert step var if is an int and its negative */
  if (step_var.is_int() && step_var.int_value()<0) {
	step_var = new Int_lit(-step_var.int_value());
	step_var_inverted = true;
  }

  Operand loop_count_var = new Macro_reg(LC_REG);
  Operand literal_one = new Int_lit(1);
  
  Opcode subtract = El_subtract_opcode_for_induction_op(primary_ind_var_ops.head());
  Op* new_op = new Op(subtract);
  new_op->set_dest(DEST1, loop_count_var);
  new_op->set_src(PRED1, pred_true);
  if (! step_var_inverted) {
    new_op->set_src(SRC1, final_var);
    new_op->set_src(SRC2, ind_var);
  }
  else {
    new_op->set_src(SRC1, ind_var);
    new_op->set_src(SRC2, final_var);
  }
  El_insert_op_before_switch(preloop_block, new_op);

  // Insert a divide if non-unit step 
  if ((!step_var.is_int()) || (step_var.int_value()!=1)) {
    Opcode divide = El_divide_opcode_for_induction_op(primary_ind_var_ops.head());
    new_op = new Op(divide);
    new_op->set_src(SRC1, loop_count_var);
    new_op->set_src(SRC2, step_var);
    new_op->set_dest(DEST1, loop_count_var);
    new_op->set_src(PRED1, pred_true);
    El_insert_op_before_switch(preloop_block, new_op);
  }

  // Insert a subtract 1 if not <= or >= loop 
  if(El_sub_one_from_loop_count(test_cond))
    {
      Opcode sub = El_subtract_opcode_for_induction_op(primary_ind_var_ops.head());
      Op* new_op = new Op(sub);
      new_op->set_src(SRC1, loop_count_var);
      new_op->set_src(SRC2, literal_one);
      new_op->set_dest(DEST1, loop_count_var);
      new_op->set_src(PRED1, pred_true);
      El_insert_op_before_switch(preloop_block, new_op);
    }
  
  /*
  ** Remove BRANCH and COMPARE, replace with BRLC
  */
  for(Hash_set_iterator<Basicblock*> bb_iter(back_edge_blocks); bb_iter!=0; bb_iter++)
    {
      Basicblock* cur_bb = *bb_iter;
      Op* branch_op = El_get_conditional_branch_op(cur_bb);
      Operand pbr_dest = branch_op->src(SRC1);
      Pred_lit *br_pred_lit = new Pred_lit(true);
      Operand br_pred(br_pred_lit);

      Op* cond_op = El_get_cond_for_branch(branch_op);
      El_remove_op(cond_op);
      delete cond_op;

      Op* brlc_op = new Op(BRLC);
      brlc_op->set_src(PRED1, br_pred);
      brlc_op->set_src(SRC1, pbr_dest);
      brlc_op->set_src(SRC2, loop_count_var);
      brlc_op->set_dest(DEST1, loop_count_var);
      El_replace_op(cur_bb, branch_op, brlc_op);
      delete branch_op;
    }
}


void El_Loop_Graph::insert_brlc(const Loop_filter* filter)
{
  for (Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      El_Loop* loop = (*loop_iter).second;

      if (!filter_match(filter, loop))
	{
	  continue;
	}

      if(loop->category == DO_LOOP)
	{
	  loop->insert_brlc();
	}
    }
}


bool El_Loop::region_is_subset(Compound_region* reg)
{
  for(Region_all_ops op_iter(reg); op_iter != 0; op_iter++) 
    {
      Basicblock* second_layer = (Basicblock*)(*op_iter)->parent();
      if(!second_layer->is_bb())
	{
	  El_punt("El_Loop::region_is_subset: What happened to the bb tiling?");
	}

      /*
      ** if the bb in the region is not a member of the loop it is not a subset
      */
      if(!loop_blocks.is_member(second_layer))
	{
	  return false;
	}
    }
  /*
  ** If we get here we must be a subset
  */
  return true;
}

bool El_Loop::region_is_subset(Op* op)
{
  Basicblock* second_layer = (Basicblock*)op->parent();
  if(!second_layer->is_bb())
    {
      El_punt("El_Loop::region_is_subset: What happened to the bb tiling?");
    }
  
  /*
  ** if the bb in the region is not a member of the loop it is not a subset
  */
  if(!loop_blocks.is_member(second_layer))
    {
      return false;
    }
      
  return true;
}

/*
 *  The following inserts loop regions
 */

void El_Loop_Graph::insert_loop_regions(const Loop_filter* filter)
{
  for (Map_iterator<int, El_Loop*> loop_iter(id); loop_iter != 0; loop_iter++)
    {
      El_Loop* loop = (*loop_iter).second;

      if (!filter_match(filter, loop))
	{
	  continue;
	}

      loop->insert_loop_region();

    }
}


bool El_Loop::is_contiguous()
{
  /*
  ** We can assume loop blocks are in order.
  */

  Compound_region* outer_most = header_block;
  while (outer_most->parent())
    {
      outer_most = outer_most->parent();
    }
  
  Basicblock* cur_block = NULL;
  Hash_set<Basicblock*> blocks(loop_blocks);
  for(Region_all_ops op_iter(outer_most); op_iter != 0; op_iter++)
    {
      Basicblock* cur_bb = (Basicblock*)((*op_iter)->parent());

      if (loop_blocks.is_member(cur_bb))
	{
	  if(!cur_block)
	    {
	      if (blocks.head() == cur_bb)
		{
		  cur_block = cur_bb;
		  blocks -= cur_bb;
		}
	      else
		{
		  El_punt("El_Loop::is_contiguous: loop blocks are not in order.");
		}
	    }
	  else
	    {
	      if (cur_block != cur_bb)
		{
		  if (blocks.head() == cur_bb)
		    {
		       cur_block = cur_bb;
		       blocks -= cur_bb;
		    }
		  else
		    {
		      return false;
		    }
		}
	    }
	}
      else
	{
	  if(cur_block)
	    {
	      return false;
	    }
	}
      if (blocks.is_empty())
	{
	  return true;
	}
    }
  return true;
}


void El_Loop::insert_loop_region()
{
  /*
  **  Check to make sure region has not been already created
  */

  Op* entry_op = get_first_region_op_from_inops(header_block);
  Compound_region* parent_indx = entry_op->parent();
  while(parent_indx && !parent_indx->is_loopbody())
    {
      parent_indx = parent_indx->parent();
    }
  if(parent_indx && parent_indx->is_loopbody() &&
     entry_op == get_first_region_op_from_inops(parent_indx))
    {
      /* Loop region already exists for this loop */
      return;
    }

  
  /*
  ** Assert loop is contiguous
  */
  if(!is_contiguous())
    {
      El_punt("El_Loop::insert_loop_region: can only hand contiguous loop bodies");
    }
  
  /*
  ** Compute a list of all loop immediate subregions
  */
  Hash_set<Compound_region*> loop_imm_subregions;
  Hash_set_iterator<Basicblock*> bb_iter ;
  for(bb_iter(loop_blocks); bb_iter != 0; bb_iter++)
    {
      Compound_region* parent = (*bb_iter);
      while(region_is_subset(parent->parent()))
	{
	  parent = parent->parent();
	}
      loop_imm_subregions += parent;
      parent->set_flag(EL_REGION_SOFTPIPE);
      parent->set_flag(EL_REGION_VIOLATES_LC_SEMANTICS);
    }
  
  LoopBody* loop_region = new LoopBody();
  loop_region->weight = num_invocation;

  /*
  ** Set parent child/relationship with parent of loop region
  */
  Compound_region* head = loop_imm_subregions.head();
  head->parent()->insert_before_region(loop_region, head);
  loop_region->set_parent(head->parent());

  /*
  ** Set parent child/relationship with subregions of loop region
  */
  for(Hash_set_iterator<Compound_region*> reg_iter(loop_imm_subregions);
      reg_iter != 0; reg_iter++)
    {
      Compound_region* reg = *reg_iter;
      reg->parent()->remove_region(reg);
      reg->set_parent(loop_region);
      loop_region->add_region(reg);
    }
      
  /*
  ** Set the in and out ops/edges
  */
  for(bb_iter(exit_blocks); bb_iter != 0; bb_iter++)
    {
      Basicblock* exit = (*bb_iter);
      Op* out_op = get_last_region_op_from_outops(exit);
      loop_region->add_exit(out_op);
      for(Region_all_outedges edge_iter(out_op); edge_iter != 0; edge_iter++)
	{
	  Edge* edge = *edge_iter;
	  if(!loop_blocks.is_member((Basicblock*)edge->dest()->parent()))
	    {
	      out_op->add_outedge_recursively(edge);
	    }
	  else
	    {
	      loop_region->addBackEdge(edge);
	    }
	}
    }
  Op* in_op = get_first_region_op_from_inops(header_block);
  loop_region->add_entry(in_op);
  for(Region_all_inedges edge_iter(in_op); edge_iter != 0; edge_iter++)
    {
      Edge* edge = *edge_iter;
      if(!loop_blocks.is_member((Basicblock*)edge->src()->parent()))
	{
	  in_op->add_inedge_recursively(edge);
	}
    }
}

#if 0
Compound_region* El_Loop::insert_compound_region() 
{
    Compound_region *cr, *f;
    Hash_set<Edge*> top_entry_edges;
    Edge *edge;

    f = header_block;
    while (! f->is_procedure())
	f = f->parent();

    for(Region_entry_edges e_iter(header_block);e_iter!=0;e_iter++) {
        edge = *e_iter;
        top_entry_edges += edge;
    }

    cr=el_mark_cr_on_cfg((Procedure *)f,  loop_blocks, top_entry_edges);
    return (cr);
}
#endif

Compound_region* El_Loop::insert_compound_region() 
{
   int i ;
   List_iterator<int> li ;
   // Find where in the region hierarchy this compond
   // region will be inserted, also find which regions
   // will be in it

   // find the root of the region hierarchy
   Compound_region* root = header_block ;
   while(root->parent() != NULL) root = root->parent() ;
				  
   Alist_region_hierarchy_graph gr(root) ;
   Bitvector in_comp_reg(gr.node_count) ;
   for(Hash_set_iterator<Basicblock*> bbi(loop_blocks) ; bbi != 0 ; bbi++) {
      in_comp_reg.set_bit(gr.f_map.value(*bbi)) ;
   }
   for(Alist_graph_post_dfs nodei(gr) ; nodei != 0 ; nodei++) {
      int cur_node = *nodei ;
      bool all_succ_in = true ;
      if (!in_comp_reg.bit(cur_node)) {
	 // cur_node will not be included in the set of regions if
	 // (i) it is a leaf node and it is not included in the initial
	 //     set of subregions
	 // (ii) it has subregions and not all of the subregions are marked
	 //      to be included in the set
	 li(gr.succ_list[cur_node]) ;
	 if (li == 0) all_succ_in = false ; 
	 for ( ; li != 0 ; li++) {
	    int cur_succ = *li ;
	    if (!in_comp_reg.bit(cur_succ)) {
	       all_succ_in = false ;
	    }
	 }
      }
      if (all_succ_in) {
	 // insert this node to the set and remove its subregions
	 // this will ensure that the set at he end of this loop will
	 // include only the covering regions and does not include
	 // any regions which are covered
	 in_comp_reg.set_bit(cur_node) ;
	 // reset all successors bits so that we have the coverage set
	 for (li(gr.succ_list[cur_node]) ; li != 0 ; li++) {
	    int cur_succ = *li ;
	    in_comp_reg.reset_bit(cur_succ) ;
	 }
      }
   }
   // At this point in_comp_reg is a coverage of the original set
   // Check if all elements of the set have the same parent
   // if that is the case insertion is successful, otherwise
   // either return NULL or exit with an error
   Compound_region* common_parent = NULL ;
   i = 0 ;
   while ((!in_comp_reg.bit(i)) && (i < gr.node_count)) i++ ;
   if (i < gr.node_count) {
      common_parent = gr.b_map[i]->parent() ;
      i++ ;
   }
   while (i < gr.node_count) {
     if (in_comp_reg.bit(i)) {
       if (common_parent != gr.b_map[i]->parent()) {
	 // assert(0) ; // The nodes don't share a common parent
	 return NULL ;
       }
     }
     i++ ;
   }
   
   // first fix the parent subregion pointers
   Compound_region* new_cr = new Compound_region() ;
   new_cr->set_parent(common_parent) ;
   common_parent->add_region(new_cr) ;
   for (i = 0 ; i < gr.node_count ; i++) {
      if (in_comp_reg.bit(i)) {
	 Region* cur_reg = gr.b_map[i] ;
	 common_parent->remove_region(cur_reg) ;
	 new_cr->add_region(cur_reg) ;
	 cur_reg->set_parent(new_cr) ;
      }
   }
   // second set the region entry edges and ops for new_cr
   Hash_set_iterator<Basicblock*> bb_iter ;
   for(bb_iter(exit_blocks); bb_iter != 0; bb_iter++)
   {
      Basicblock* exit = (*bb_iter);
      Op* out_op = get_last_region_op_from_outops(exit);
      new_cr->add_exit(out_op);
      for(Region_all_outedges edge_iter(out_op); edge_iter != 0; edge_iter++)
      {
	 Edge* edge = *edge_iter;
	 if(!loop_blocks.is_member((Basicblock*)edge->dest()->parent()))
	 {
	    // This handles all loop exits. Loop-back edges are not
	    // region exits
	    new_cr->add_exit(edge);
	 }
      }
   }
  
   Op* in_op = get_first_region_op_from_inops(header_block);
   new_cr->add_entry(in_op);
   for(Region_all_inedges edge_iter(in_op); edge_iter != 0; edge_iter++)
   {
      Edge* edge = *edge_iter;
      if(!(loop_blocks.is_member((Basicblock*)edge->src()->parent()))) {
	 new_cr->add_entry(edge);
      }
   }
   return(new_cr) ;
}


/*
 * Loop filter - This determines which loops get processed when a filter is passed
 */

bool El_Loop_Graph::filter_match(const Loop_filter* filter, El_Loop* loop)
{
  return(filter->filter(loop));
}


El_Loop*  el_find_innermost_loop_containing_bb(El_Loop_Graph& loops,Basicblock* bb)
{
  
 for(El_Loop_Graph_Post_DFS l_iter(loops);l_iter!=0;l_iter++)
   {
     El_Loop* loop=*l_iter;
     if(loop->loop_blocks.is_member(bb))
       return loop;
   }
 return NULL; 
}



//Given a loop, find all the bbs in that loop that are not in
//one of it nested loops; in practice, we only need to test
//the bb is not in any loop of nesting level greater than that of
//the current loop
void el_find_loop_bbs_not_in_nested_loops(El_Loop* loop, El_Loop_Graph& loops,
				       Hash_set<Basicblock*>& todo_bbs)
{
  for(Hash_set_iterator<Basicblock*> lb_iter(loop->loop_blocks);lb_iter!=0;lb_iter++)
    {
      Basicblock* bb = *lb_iter;

      
      bool include=true;
      //bb shouldn't be in _any_ loop of higher nesting level
      for(El_Loop_Graph_Post_DFS l_iter(loops);l_iter!=0;l_iter++)
	{
	  El_Loop* other_loop=*l_iter;
	  if((other_loop->nesting_level>loop->nesting_level)&&
	     (other_loop->loop_blocks.is_member(bb)))
	    include=false;
	}
      if(include)
	todo_bbs+=bb;

    }
  return;
}

