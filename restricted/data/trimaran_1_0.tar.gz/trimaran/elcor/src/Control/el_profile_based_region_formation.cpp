/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1996 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           el_profile_based_region_formation.cpp
//      Author:         Matthai Philipose
//      Created:        August 27 1996
//      Description:    Given a procedure, figure out regions based on profile
//                      
/////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include "control_analysis_solver.h"
#include "iterators.h"
#include "list.h"
#include "el_bb_tools.h"
#include "map.h"
#include "el_if_converter.h"
#include "el_control.h"
#include "edge_utilities.h"
#include "op.h"
#include "edge.h"
#include "el_opti.h"
#include "connect.h"
#include "opcode_properties.h"
#include "attributes.h"
#include "edge_attributes.h"
#include "el_normalize_branches.h"
#include "dbg.h"
#include "pred_analysis.h"
#include "el_bb_tools.h"
#include "el_loop.h"
#include "el_profile_based_region_formation.h"
#include "el_control_init.h"
#include "el_region_formation_tools.h"
#include "hash_map.h"


double threshold_pred_succ=0.01;
double threshold_seed=0.01;
double threshold_ht_ratio_hi=3.0;
double threshold_ht_ratio_lo=0.3;
#define MAX_BBS_IN_FUNCTION 1001

void el_form_regions_profile_based(Procedure *f,
				   Hash_map<Basicblock*,int>& bb_heights,
				   Hash_map<Basicblock*,int>& bb_num_jsrs)
{
  //decomposition into bbs
  Hash_set<Basicblock*> todo_bbs;
  El_confirm_BB_tiling(f,todo_bbs);
  
  //compute loop info
  El_Loop_Graph loops(f);
  Hash_set<Basicblock*> all_loop_bbs;
  for(El_Loop_Graph_Post_DFS l_iter(loops);l_iter!=0;l_iter++)
    {
      El_Loop* loop=*l_iter;      
      all_loop_bbs+=loop->loop_blocks;
    }
  

  //loop, finding seeds and growing out to form regions
  Basicblock* seed=find_seed_profile_based(todo_bbs);
  Hash_set<Basicblock*> cur_region;
  Hash_set<Basicblock*> exclusive_loop_bbs;

  Hash_set<Basicblock*> new_tail_bbs;
  Hash_map<Basicblock*,Basicblock*> tail_map(hash_bb_ptr,MAX_BBS_IN_TAIL);      

  while(seed)
    {
      cur_region.clear();
      cur_region+=seed;
      
      El_Loop* loop=el_find_innermost_loop_containing_bb(loops,seed);
      //bbs in loop, but not in any nested loop
      exclusive_loop_bbs.clear();
      if(loop)
	//find bbs that are exclusively in loop (i.e. in not in any nested loops)
	el_find_loop_bbs_not_in_nested_loops(loop,loops,exclusive_loop_bbs);

      //Figure out the single-entry-region that can be grown
      //from the seed
      
      //first pass: grow downwards from seed
      Basicblock* cur_seed=seed;
      Basicblock* cur_succ=most_frequent_successor(seed);
      while((!cur_region.is_member(cur_succ))&&
	    todo_bbs.is_member(cur_succ)&&
	    is_eligible_succ(cur_seed,cur_succ,seed,loop,exclusive_loop_bbs,all_loop_bbs,
			     bb_heights,bb_num_jsrs,false))
	{
	  cur_region += cur_succ;
	  cur_seed=cur_succ;
	  cur_succ=most_frequent_successor(cur_seed);
	}
      

      //second pass: grow upwards from seed
      cur_seed=seed;
      Basicblock* cur_pred=most_frequent_predecessor(seed);
      if(cur_pred)//cur_pred may be null if cur_seed is the program entry block
	while((!cur_region.is_member(cur_pred))&&
	      todo_bbs.is_member(cur_pred)&&
	      is_eligible_pred(cur_seed,cur_pred,seed,loop,exclusive_loop_bbs,all_loop_bbs))
	  {
	    cur_region += cur_pred;
	    cur_seed=cur_pred;
	    cur_pred=most_frequent_predecessor(cur_seed);
	    if(!cur_pred)
	      break;
	  }
      

      //third pass: grow away from the central trace
      Dlist<Basicblock*> main_trace_stack;
      //initialize the stack to blocks on the central trace...
      for(Hash_set_iterator<Basicblock*> bb_iter(cur_region);bb_iter!=0;bb_iter++)
	{       
	  Basicblock* bb=*bb_iter;
	  main_trace_stack.push(bb);
	}

      while(!main_trace_stack.is_empty())
	{
	  cur_seed=main_trace_stack.pop();
	  for(Region_exit_edges e_iter(cur_seed);e_iter!=0;e_iter++)
	    {
	      Edge* edge=*e_iter;
	      Basicblock* dest_bb=(Basicblock*)edge->dest()->parent();
	      
	      assert(dest_bb->is_bb());
	      
	      if((!cur_region.is_member(dest_bb))&&
		 todo_bbs.is_member(dest_bb)&&
		 (is_eligible_succ(cur_seed,dest_bb,seed,loop,
				   exclusive_loop_bbs,all_loop_bbs,
				   bb_heights,bb_num_jsrs,true)))
		{
		  cur_region+=dest_bb;
		  main_trace_stack.push(dest_bb);
		}		  
	    } 
	}
      
      //if-convert the region we just identified:

      //step 1: Mark the current region on the cfg
      Hash_set<Edge*> header_entry_edges;
      Hash_set<Basicblock*> loop_header_bbs;
      find_all_loop_header_bbs(loops,loop_header_bbs);//find the header bb for the region
      Basicblock* header_bb=find_header_bb(cur_region,loop_header_bbs);
      
      //first print everything going into the region
      cout << "Region Found: (Header is bb" << header_bb->id() << ")\n bbs are:\n" ;	  
      for(Hash_set_iterator<Basicblock*> db_iter(cur_region);db_iter!=0;db_iter++)
	{
	  Basicblock* bb=*db_iter;
	  cout << bb->id() << "\n";
	}
	
      //now go ahead and form the region
      for(Region_entry_edges re_iter(header_bb);re_iter!=0;re_iter++)
	{
	  Edge* edge = *re_iter;
	  header_entry_edges += edge;
	}
      Compound_region* cr=el_mark_cr_on_cfg(f,cur_region,header_entry_edges);
      

      //step 2: tail-duplicate
      Hash_set<Edge*> side_entries=*compound_region_entry_edges(cr);
      side_entries-= header_entry_edges;

      new_tail_bbs.clear();
      tail_map.clear();
      el_tail_duplicate(cr,side_entries,header_entry_edges,new_tail_bbs,tail_map);
      //Add heights of new BBS (i.e. those in the duplicated tail to height map)
      if(strcasecmp(El_region_formation_model,"heuristic")==0)
	{
	  for (Hash_map_iterator<Basicblock*, Basicblock*>  miter(tail_map);  
	       miter != 0; miter++)
	    {
	      Basicblock* new_bb = (*miter).first;
	      Basicblock* old_bb = (*miter).second;
	      
	      bb_heights.bind(new_bb,bb_heights.value(old_bb));
	       bb_num_jsrs.bind(new_bb,bb_num_jsrs.value(old_bb));
	       
	    }
	}

      //Update the loop information (changed by the addition of the tail
      //duplicated blocks)
      if(loop)
	{
	  all_loop_bbs+=new_tail_bbs;
	  loop->loop_blocks+=new_tail_bbs;
	}

      //step 3: if-convert
      El_if_convert(cr, El_frp_model);
      
      //step 4:nuke the region now it's not needed
      El_remove_region(cr, true);      

      //update the bbs left to be processed
      todo_bbs-=cur_region;
      todo_bbs+=new_tail_bbs; //add in the new blocks produced by the tail-duplicator
      seed=find_seed_profile_based(todo_bbs);      
    }
  
  return;
}

void find_all_loop_header_bbs( El_Loop_Graph& loops, Hash_set<Basicblock*> &loop_header_bbs)
{
  //remove all bbs that are in loops
  for(El_Loop_Graph_Post_DFS l_iter(loops);l_iter!=0;l_iter++)
    {
      El_Loop* loop=*l_iter;      
      loop_header_bbs+=loop->header_block;
    }
  
  return;
}

//The block with maximum, nonzero weight is the seed
Basicblock* find_seed_profile_based(Hash_set<Basicblock*>& todo_bbs)
{
  double max_so_far=-1.0;
  Basicblock* mfb=NULL;
  
  for(Hash_set_iterator<Basicblock*> bb_iter(todo_bbs);bb_iter!=0;bb_iter++)
    {
      Basicblock* bb=*bb_iter;
      double wt=bb->weight;
      
      if((wt > max_so_far)&&
	 (wt > 0)&&
	 (!bb->flag(EL_REGION_HAS_EPILOGUE_OP)))
	{
	  mfb=bb;
	  max_so_far = wt;
	}
    }

  return mfb; //may be NULL. i.e., no seed found
}

Basicblock* most_frequent_predecessor(Basicblock* seed)
{
  double max_so_far=-1.0;
  Basicblock* mfp=NULL;
  
  for(Region_entry_edges e_iter(seed);e_iter!=0;e_iter++)
    {
      Edge *edge=*e_iter;
      Control_flow_freq *cfreq = get_control_flow_freq(edge);
      double wt=cfreq->freq;
      if(wt > max_so_far)
	{
	  mfp=(Basicblock*)edge->src()->parent();
	  max_so_far = wt;
	}
    }
  assert(mfp||seed->flag(EL_REGION_HAS_PROLOGUE_OP));
  return mfp;
}

Basicblock* most_frequent_successor(Basicblock* seed)
{
  double max_so_far=-1.0;
  Basicblock* mfs=NULL;
  
  for(Region_exit_edges e_iter(seed);e_iter!=0;e_iter++)
    {
      Edge *edge=*e_iter;
      Control_flow_freq *cfreq = get_control_flow_freq(edge);
      double wt=cfreq->freq;
      if(wt > max_so_far)
	{
	  mfs=(Basicblock*)edge->dest()->parent();
	  max_so_far = wt;
	}
    }
  assert(mfs);
  return mfs;
}


bool is_eligible_succ(Basicblock* bb,Basicblock* succ,Basicblock* seed, El_Loop* loop, 
		      Hash_set<Basicblock*>&  exc_loop_bbs,
		      Hash_set<Basicblock*>&  all_loop_bbs,
		      Hash_map<Basicblock*,int>& bb_heights,
		      Hash_map<Basicblock*,int>& bb_num_jsrs,
		      bool is_off_main_trace) 		      
{
  //note that weight needs to be gt 0 for eligibility
  //need to prevent all loop-headers of inner loops from getting
  //included
  
  Edge* edge= get_connecting_CONTROL0_edge(bb,succ);
  Control_flow_freq *cfreq = get_control_flow_freq(edge);
  
  double edge_wt=cfreq->freq;
  double bb_wt=bb->weight;
  double succ_wt=succ->weight;
  double seed_wt=seed->weight;
  
  //Backedges are not allowed any more 
  if(loop)
    if(succ==loop->header_block)
      return false;


  //We don't want the epilog bb to be in any region;
  //(talk to Scott about this restriction)
  if(succ->flag(EL_REGION_HAS_EPILOGUE_OP))
    return false;

  //succ should have non-zero chance of executing,
  //given the current bb executed
  if((edge_wt==0.0) && 
     (strcasecmp(El_region_formation_model,"heuristic")!=0)) 
    return false;

  //if the successor takes you outside the current loop, it's out
  if(loop)//if we're currently inside a loop...
    {
      //...avoid expanding into nested/outer loops
      if(!exc_loop_bbs.is_member(succ))
	return false;
    }
  else
    {
      //...otherwise avoid expanding into nested loop
      if(all_loop_bbs.is_member(succ))
	return false;
    }

  //The successor now needs to satisfy the weight criteria
  bool consider_succ=(((edge_wt/bb_wt) >= threshold_pred_succ)&&
		      ((succ_wt/seed_wt) >= threshold_seed));

  //Apply heurisitics (other than the profile weight) if needed
  if(is_off_main_trace && //heuristics are not applied for main-trace bbs
     (strcasecmp(El_region_formation_model,"heuristic")==0))
    {
      
      //find the ratio of the heights of the two successor bbs
      //of bb (note that succ_bb is one of these successors)
      Basicblock* alt0_succ;
      Basicblock* other_succ;
      int num_succs=0;
      double ht_ratio;
      for(Region_exit_edges eiter(bb);eiter!=0;eiter++,num_succs++)
	{
	  Edge* succ_edge =*eiter;
	  if(succ_edge->src_alt()==0)
	    alt0_succ=(Basicblock*)succ_edge->dest()->parent();
	  else
	    other_succ=(Basicblock*)succ_edge->dest()->parent();
	}	
      
      int succ_height;
      if(num_succs==2)
	{
	  assert(alt0_succ);
	  assert(other_succ);
	  succ_height=bb_heights.value(succ);
	  if(succ==alt0_succ) 
	    ht_ratio=((double)(succ_height))/bb_heights.value(other_succ);
	  else
	    ht_ratio=((double)succ_height)/bb_heights.value(alt0_succ);
	}
      
      //Even though the weight test says the successor is eligible,
      //the succ may be disqualified by the following 2 heuristics
      if(consider_succ)
	{
	  //heuristic 1: no jsrs allowed in the side trace
	  if(bb_num_jsrs.value(succ)>0)
	    return false;  
	  
	  //heuristic 2: check relative heights of bbs in the case that the
	  //bb has two successors; the new bb shouldn't be much taller
	  //then the old one
	  if((num_succs==2) && (ht_ratio>=threshold_ht_ratio_hi))
	    return false;

	  //passed height and jsr tests... the succ is eligible
	  return true;
	}
      else
	{
	  //heuristic 3: Even though the weight test is against the succ, if the succ has
	  //small enough relative height, we may include it
	  if((num_succs==2) && 
	     ((ht_ratio<=threshold_ht_ratio_lo)|| (succ_height <= 2))&&
	     (bb_num_jsrs.value(succ)==0))
	    return true;
	  else
	    return false;
	}  
    }
  else
    return consider_succ;
      
}




bool is_eligible_pred(Basicblock* bb,Basicblock* pred,Basicblock* seed,El_Loop* loop, 
		      Hash_set<Basicblock*>&  exc_loop_bbs,
		      Hash_set<Basicblock*>&  all_loop_bbs)
{
    //note that weight needs to be gt 0 for eligibility
  //need to prevent all loop-headers of inner loops from getting
  //included
  
  Edge* edge= get_connecting_CONTROL0_edge(pred,bb);
  Control_flow_freq *cfreq = get_control_flow_freq(edge);
  
  double edge_wt=cfreq->freq;
  double bb_wt=bb->weight;
  double pred_wt=pred->weight;
  double seed_wt=seed->weight;

  //Backedges are not allowed any more 
  if(loop)
    if(bb==loop->header_block)
      return false;

  if((pred->weight==0.0)|| (edge_wt==0.0))   
    return false;

  //if the predessor takes you outside the current loop, it's out
  if(loop)//if we're currently inside a loop...
    {
      //...avoid expanding into nested/outer loops
      if(!exc_loop_bbs.is_member(pred))
	return false;
    }
  else
    {
      //...otherwise avoid expanding into nested loop
      if(all_loop_bbs.is_member(pred))
	return false;
    }

  //The predessor now needs to satisfy the weight criteria
  return (((edge_wt/pred_wt) >= threshold_pred_succ)&&
	  ((pred_wt/seed_wt) >= threshold_seed));
}


Basicblock* find_header_bb(Hash_set<Basicblock*>& cur_region,Hash_set<Basicblock*>& loop_header_bbs)
{
  Basicblock* result_bb;
  for(Hash_set_iterator<Basicblock*> bb_iter(cur_region);bb_iter!=0;bb_iter++)
    {
      result_bb= *bb_iter;
      bool is_header=true;
      for(Region_entry_edges e_iter(result_bb);e_iter!=0;e_iter++)
	{
	  Edge *edge=*e_iter;
	  Basicblock* src_bb=(Basicblock*)edge->src()->parent();
	  if(cur_region.is_member(src_bb))
	    {
	      is_header=false;
	      break;
	    }
	}
      if(is_header)
	return result_bb;
    }
  
  //no header found yet; find the loop header block
  for(Hash_set_iterator<Basicblock*> b_iter(cur_region);b_iter!=0;b_iter++)
    {
      result_bb=*b_iter;
      if(loop_header_bbs.is_member(result_bb))
	return result_bb;
    }
  
  assert(0); //should have found a header block by now!
  return NULL;
}
