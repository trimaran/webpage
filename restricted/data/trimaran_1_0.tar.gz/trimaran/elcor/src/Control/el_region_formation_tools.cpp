/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1996 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           el_region_formation_tools.cpp
//      Author:         Matthai Philipose
//      Created:        August 23 1996
//      Description:    Given a procedure, decompose it into single-entry dags
//                      and if-convert all the dags
//                      
/////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include "iterators.h"
#include "list.h"
#include "el_bb_tools.h"
#include "map.h"
#include "el_control.h"
#include "edge_utilities.h"
#include "op.h"
#include "edge.h"
#include "connect.h"
#include "opcode_properties.h"
#include "attributes.h"
#include "edge_attributes.h"
#include "dbg.h"
#include "el_control_init.h"
#include "el_region_formation_tools.h"
#include "edge_drawing.h"
#include "sched_functions.h"
#include "el_loop.h"

void el_calculate_block_heights(Procedure *f,Hash_map<Basicblock*,int>& bb_heights)
{
  Hash_set<Basicblock*> proc_bbs;
  if(!El_confirm_BB_tiling(f,proc_bbs))
    {
      El_form_basic_blocks(f);
      El_confirm_BB_tiling(f,proc_bbs);
    }

  // Compute local vr_maps and PQS for dataflow analysis
  create_local_analysis_info_for_all_hbs_bbs(f);
  el_flow_compute_liveness(f);
  
  Hash_map<Op*, int> early_map (hash_op_ptr, 197);

  static char outfile[128] = "BB_PROFILE_HEIGHT_STATS";
  ofstream  oFile(outfile,ios::app);//open the file in append mode all subsequent times
  
  for(Hash_set_iterator<Basicblock*> bb_iter(proc_bbs); bb_iter != 0; bb_iter++)
    {
      Basicblock* bb=*bb_iter;
      
      insert_region_scalar_edges(bb);

      early_map.clear();
      Region_entry_ops entry_op_iter(bb);
      Op *entry_op=*entry_op_iter;
      calculate_earliest_times_from_entry_op(bb, entry_op, early_map,
					     NON_CONTROL0_INEDGES);
      
      Region_exit_ops exit_op_iter(bb);
      Op *exit_op=*exit_op_iter;
      
      int height=early_map.value(exit_op)+1;
      bb_heights.bind(bb,height);

      oFile << bb->id() << " " << bb->weight << " " << height << endl;

      delete_region_edges(bb);
    }

  // delete vr_maps and PQS  
  delete_local_analysis_info_for_all_hbs_bbs(f);
  return;
}


void el_calculate_block_num_ops(Procedure *f,Hash_map<Basicblock*,int>& bb_num_ops)
{
  Hash_set<Basicblock*> proc_bbs;
  if(!El_confirm_BB_tiling(f,proc_bbs))
    {
      El_form_basic_blocks(f);
      El_confirm_BB_tiling(f,proc_bbs);
    }
  
  int num_ops;
  
  static char outfile[128] = "BB_PROFILE_OP_STATS";
  ofstream  oFile(outfile,ios::app);//open the file in append mode all subsequent times
  
  for(Hash_set_iterator<Basicblock*> bb_iter(proc_bbs); bb_iter != 0; bb_iter++)
    {
      Basicblock* bb=*bb_iter;
      
      num_ops=0;
      //count ops in bb
      for(Region_all_ops oiter(bb);oiter!=0;oiter++,num_ops++);
      bb_num_ops.bind(bb,num_ops);
      oFile << bb->id() << " " << bb->weight << " " << num_ops << endl;
    }
  return;
}


void el_calculate_block_num_jsrs(Procedure *f,Hash_map<Basicblock*,int>& bb_num_jsrs)
{
  Hash_set<Basicblock*> proc_bbs;
  
  if(!El_confirm_BB_tiling(f,proc_bbs))
    {
      El_form_basic_blocks(f);
      El_confirm_BB_tiling(f,proc_bbs);
    }
  
  int num_jsrs;
  
  static char outfile[128] = "BB_PROFILE_JSR_STATS";
  ofstream  oFile(outfile,ios::app);//open the file in append mode all subsequent times

  for(Hash_set_iterator<Basicblock*> bb_iter(proc_bbs); bb_iter != 0; bb_iter++)
    {
      Basicblock* bb=*bb_iter;
      
      num_jsrs=0;
      //count ops in bb
      for(Region_all_ops oiter(bb);oiter!=0;oiter++)
	{
	  Op* op=*oiter;
	  if(is_brl(op))
	    num_jsrs++;
	}

      oFile << bb->id() << " " << bb->weight << " " << num_jsrs << endl; 
      bb_num_jsrs.bind(bb,num_jsrs);      
    }
  return;
}


void el_calculate_block_succ_ratios(Procedure* f,
				    Hash_map<Basicblock*,double> &bb_height_ratios,
				    Hash_map<Basicblock*,double> &bb_num_op_ratios,
				    Hash_map<Basicblock*,double> &bb_num_jsrs_ratios,
				    Hash_map<Basicblock*,double> &bb_freq_ratios,
				    Hash_map<Basicblock*,int> &bb_ops,
				    Hash_map<Basicblock*,int> &bb_jsrs,
				    Hash_map<Basicblock*,int> &bb_heights)
{
  Hash_set<Basicblock*> proc_bbs;
  if(!El_confirm_BB_tiling(f,proc_bbs))
    {
      El_form_basic_blocks(f);
      El_confirm_BB_tiling(f,proc_bbs);
    }
  
  int edge_count=0;
  
  //read in the bb numbers
  static char outfile[128] = "BB_PROFILE_RATIO_STATS";
  ofstream  oFile(outfile,ios::app);//open the file in append mode all subsequent times
  
  if (!oFile){cerr << "could not open" << outfile <<endl;exit(-1);}
  
  El_Loop_Graph loops(f);
  for(Hash_set_iterator<Basicblock*> bb_iter(proc_bbs); bb_iter != 0; bb_iter++)
    {
      Basicblock* bb=*bb_iter;
      
      edge_count=0;
      Edge *alt0_edge=NULL;
      Edge *other_edge=NULL;
      
      //don't bother with loop backedges and exit edges
      bool is_bad_bb=false;
      for(El_Loop_Graph_Post_DFS l_iter(loops);l_iter!=0;l_iter++)
	{
	  El_Loop* loop=*l_iter;
	  if(loop->exit_blocks.is_member(bb)||
	     loop->back_edge_blocks.is_member(bb))
	    is_bad_bb=true;	     
	}
      if(is_bad_bb)
	continue;
      
      
      //find the exit edges
      for(Region_exit_edges eiter(bb);eiter!=0;eiter++,edge_count++)
	{
	  Edge* edge=*eiter;
	  if(edge->src_alt()==0)
	    alt0_edge=edge;
	  else
	    other_edge=edge;
	}
      
        
      //right now, we only gather stats for two-outedge bbs
      if(edge_count==2)
	{
	  
	  Basicblock* a0_succ=(Basicblock*)alt0_edge->dest()->parent();
	  Basicblock* other_succ=(Basicblock*)other_edge->dest()->parent();
	  
	  int a0_height=bb_heights.value(a0_succ);
	  int other_height=bb_heights.value(other_succ);
	  
	  int a0_ops=bb_ops.value(a0_succ);
	  int other_ops=bb_ops.value(other_succ);
	  
	  int a0_jsrs=bb_jsrs.value(a0_succ);
	  int other_jsrs=bb_jsrs.value(other_succ);
	  
	  Control_flow_freq *cfreq = get_control_flow_freq(alt0_edge);
	  double a0_freq= cfreq->freq;    
	  cfreq = get_control_flow_freq(other_edge);
	  double other_freq= cfreq->freq;
	  
	  double freq_ratio,ops_ratio,height_ratio,jsrs_ratio;
	  int numerator_ops=0;
	  int numerator_height=0;
	  if(a0_freq>other_freq)
	    {
	      numerator_ops=a0_ops;
	      numerator_height=a0_height;
	      freq_ratio=(other_freq==0) ? (double)a0_freq : ((double)a0_freq/other_freq);
	      ops_ratio=(other_ops==0) ? (double)a0_ops : ((double)a0_ops/other_ops);
	      height_ratio=(other_height==0) ? (double)a0_height : ((double)a0_height/other_height);
	      jsrs_ratio=(other_jsrs==0) ? (double)a0_jsrs : ((double)a0_jsrs/other_jsrs);
	    }
	  else
	    {	      
	      numerator_ops=other_ops;
	      numerator_height=other_height;
	      freq_ratio=(other_freq==0) ? (double)a0_freq : ((double)a0_freq/other_freq);
	      freq_ratio=((double)a0_freq==0) ? other_freq : (other_freq/(double)a0_freq);
	      ops_ratio=((double)a0_ops==0) ? other_ops : (other_ops/(double)a0_ops);
	      height_ratio=((double)a0_height==0) ? other_height : (other_height/(double)a0_height);
	      jsrs_ratio=((double)a0_jsrs==0) ? other_jsrs : (other_jsrs/(double)a0_jsrs);
	    }
	  
	  oFile << bb->id() << " " << bb->weight << " " << freq_ratio << " " << height_ratio << "(" << numerator_height << ") " << ops_ratio << "(" << numerator_ops << ") " << jsrs_ratio << endl;
	  bb_height_ratios.bind(bb,height_ratio);
	  bb_num_op_ratios.bind(bb,ops_ratio);
	  bb_num_jsrs_ratios.bind(bb,jsrs_ratio);
	  bb_freq_ratios.bind(bb,freq_ratio);
	}

    }
  
  return;
}    
