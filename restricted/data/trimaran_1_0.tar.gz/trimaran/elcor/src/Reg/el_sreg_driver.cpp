/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1996 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

///////////////////////////////////////////////////////////////////////////
//
//      File:           el_sreg_driver.cpp
//      Author:         Scott A. Mahlke
//      Created:        October 1996
//      Description:    Driver for the scalar register allocator
//
///////////////////////////////////////////////////////////////////////////

#include "region.h"
#include "el_extern.h"
#include "el_main.h"
#include "el_io.h"
#include "el_sreg_driver.h"
#include "el_sreg_impact.h"
#include "el_loop_tools.h"
#include "el_control.h"
#include "pred_analysis.h"
#include "region_purge.h"
#include "regtochar.h"
#include "el_stats_init.h"
#include "el_clock.h"


/*===========================================================================*/
/*
 *	Global vars to describe the target register file
 */
/*===========================================================================*/


int El_num_rotating_gpr = 0;
int El_num_static_gpr = 0;
int El_num_static_gpr_resv = 0;
int El_num_static_gpr_callee = 0;
int El_num_static_gpr_caller = 0;

int El_num_rotating_fpr = 0;
int El_num_static_fpr = 0;
int El_num_static_fpr_resv = 0;
int El_num_static_fpr_callee = 0;
int El_num_static_fpr_caller = 0;

int El_num_rotating_pr = 0;
int El_num_static_pr = 0;
int El_num_static_pr_resv = 0;
int El_num_static_pr_callee = 0;
int El_num_static_pr_caller = 0;

int El_num_static_btr = 0;
int El_num_static_btr_resv = 0;
int El_num_static_btr_callee = 0;
int El_num_static_btr_caller = 0;

int El_num_static_cr = 0;
int El_num_static_cr_resv = 0;


/*===========================================================================*/
/*
 *	Register file configuration functions.
 */
/*===========================================================================*/


/*
 *	Reserved Registers for Macros - Whats currently assumed
 *	GPR (11):
 *		INT_PARAM_1
 *		INT_PARAM_2
 *		INT_PARAM_3
 *		INT_PARAM_4
 *		INT_RETURN
 *		SP
 *		FP
 *		AP  (argument pointer, not used, for the future) 
 *		GP  (global pointer for data, not used, for the future)
 *		INT_ZERO
 *		SPILL_TEMPREG
 *
 *	FPR (7):
 *		FLT_PARAM_1, DBL_PARAM_1
 * 		FLT_PARAM_2, DBL_PARAM_2
 * 		FLT_PARAM_3,
 * 		FLT_PARAM_4,
 *		FLT_RETURN, DBL_RETURN
 *		FLT_ZERO, DBL_ZERO
 *		FLT_ONE, DBL_ONE
 *
 *	PR (2):
 *		PRED_false
 *		PRED_true
 *
 *	BTR (1):
 *		RETURN_ADDR
 *
 *	CR (0):
 *
 */
int El_reserved_registers_for_macros(Reg_file rfile)
{
    switch (rfile) {
	case GPR:
	    return (11);
	case FPR:
	    return (7);
	case PR:
	    return (2);
	case BTR:
	    return (1);
	case CR:
	    return (0);
	default:
	    return (0);
    }
}

/*
 *	Ensure that the specified configuration makes sense given the
 *	current set of assumptions.
 */
void El_check_register_file_config(void)
{
    int num;


    /* static gpr */
    num = El_num_static_gpr_callee + El_num_static_gpr_caller;
    if (num < EL_SREG_MIN_STATIC_GPR)
	El_punt("El_check_register_file_config: too few static GPRs specified: \n\
		%d (%d reserved / %d allocatable)",
		El_num_static_gpr, El_num_static_gpr_resv, num);

    /* static fpr */
    num = El_num_static_fpr_callee + El_num_static_fpr_caller;
    if (num < EL_SREG_MIN_STATIC_FPR)
	El_punt("El_check_register_file_config: too few static FPRs specified: \n\
		%d (%d reserved / %d allocatable)",
		El_num_static_fpr, El_num_static_fpr_resv, num);

    /* static pr */
    num = El_num_static_pr_callee + El_num_static_pr_caller;
    if (num < EL_SREG_MIN_STATIC_PR)
	El_punt("El_check_register_file_config: too few static PRs specified: \n\
		%d (%d reserved / %d allocatable)",
		El_num_static_pr, El_num_static_pr_resv, num);

    /* static btr */
    num = El_num_static_btr_callee + El_num_static_btr_caller;
    if (num < EL_SREG_MIN_STATIC_BTR)
	El_punt("El_check_register_file_config: too few static BTRs specified: \n\
		%d (%d reserved / %d allocatable)",
		El_num_static_btr, El_num_static_btr_resv, num);

    /* static cr */
    num = El_num_static_cr;
    if (num < EL_SREG_MIN_STATIC_CR)
	El_punt("El_check_register_file_config: too few static CRs specified: \n\
		%d (%d reserved / %d allocatable)",
		El_num_static_cr, El_num_static_cr_resv, num);
}

/*
 *	Setup register file configuration (global vars).  Assume macros are
 *	allocated to physical regs [0..k-1], where k is the number of macros
 *	per file given by El_reserved_registers_for_macros().
 */
void El_setup_register_file_config(void)
{
    int t1;

    El_num_rotating_gpr = MDES_reg_rotating_size(regfile_to_char(GPR));
    El_num_rotating_fpr = MDES_reg_rotating_size(regfile_to_char(FPR));
    El_num_rotating_pr = MDES_reg_rotating_size(regfile_to_char(PR));

    El_num_static_gpr = MDES_reg_static_size(regfile_to_char(GPR));
    El_num_static_fpr = MDES_reg_static_size(regfile_to_char(FPR));
    El_num_static_pr = MDES_reg_static_size(regfile_to_char(PR));
    El_num_static_btr = MDES_reg_static_size(regfile_to_char(BTR));
    El_num_static_cr = MDES_reg_static_size(regfile_to_char(CR));

    El_num_static_gpr_resv = El_reserved_registers_for_macros(GPR);
    El_num_static_fpr_resv = El_reserved_registers_for_macros(FPR);
    El_num_static_pr_resv = El_reserved_registers_for_macros(PR);
    El_num_static_btr_resv = El_reserved_registers_for_macros(BTR);
    El_num_static_cr_resv = El_reserved_registers_for_macros(CR);

    /*** HACK, SAM 9-97, let the user specify no FPRs, but interally pretend
	they are there so don't need to add special case code everywhere ***/
    if (El_num_static_fpr == 0) {
	El_num_static_fpr = El_num_static_fpr_resv + EL_SREG_MIN_STATIC_FPR;
    }
	
    /* Partition the non-reserved registers into equal groups of caller/callee */
    t1 = El_num_static_gpr - El_num_static_gpr_resv;
    El_num_static_gpr_callee = t1 / 2;
    El_num_static_gpr_caller = t1 / 2;
    El_num_static_gpr_caller += (t1 % 2);

    t1 = El_num_static_fpr - El_num_static_fpr_resv;
    El_num_static_fpr_callee = t1 / 2;
    El_num_static_fpr_caller = t1 / 2;
    El_num_static_fpr_caller += (t1 % 2);

    t1 = El_num_static_btr - El_num_static_btr_resv;
    El_num_static_btr_callee = t1 / 2;
    El_num_static_btr_caller = t1 / 2;
    El_num_static_btr_caller += (t1 % 2);

    /* Predicates are a special case, all non-reserved predicates are callee */
    t1 = El_num_static_pr - El_num_static_pr_resv;
    El_num_static_pr_callee = t1;
    El_num_static_pr_caller = 0;

    /* Control registers, no partitioning into caller/callee */

    /* Ensure the config is a valid one */
    El_check_register_file_config();
}


/*===========================================================================*/
/*
 *	Scalar register allocator driver routines
 */
/*===========================================================================*/

/*
 *	1. Convert the Elcor procedure to an Lcode procedure as is done in
 *	   el_main.cpp in main().
 *	2. Do the allocation
 *	3. Rebuild the Procedure
 */
Procedure *El_scalar_regalloc(Procedure *f)
{
    L_Func *fn;
    Procedure *new_f;
    int old_flag_val;

    if (El_do_run_time)
        El_clock1.start();

    /*** Step 0: prepare the Elcor proc for conversion ***/
    El_remove_all_loop_regions(f);
    El_fix_all_pbr_info(f, true);
    delete_local_analysis_info_for_all_hbs_bbs(f);

    /*** Step 1: convert Elcor proc to Lcode fn ***/
    fn = El_elcor_to_lcode_func(f, false);
    El_setup_lcode_for_impact(fn);

    L_clear_src_flow(fn);
    L_rebuild_src_flow(fn);
    L_check_func(fn);

    region_purge (f);

    /*** Step 2: call the Impact allocator ***/
    if (El_do_run_time)
	El_clock2.start();
    El_setup_register_file_config();
    O_register_init();
    /* Temporary hack so that its less likely to get spills in swp loops,
       need to modify regalloc to increase priority for LRs in swp loops */
    old_flag_val = R_Utilize_Profile_Info;
    if (fn->weight <= 0.0) {
	R_Utilize_Profile_Info = 0;
    }
    O_register_allocation(fn, L_command_line_macro_list);
    R_Utilize_Profile_Info = old_flag_val;
    if (El_do_run_time) {
	El_clock2.stop();
        El_stopwatch_print_time("Impact_regalloc", El_clock2.last_elapsed());
    }

    /*** Step 3: rebuild the Elcor procedure from the Lcode fn ***/
    El_setup_lcode_for_elcor(fn);
    /* Currently memory dependences are not xlated from elcor->impact, so
       on the 2nd path back into elcor, all the memory deps are gone so must
       assume sequential arcs */
    El_memvr_setup_mode = EL_MEMVR_SETUP_MODE_SEQUENTIAL;
    new_f = El_lcode_to_elcor_func(fn);
    L_delete_func(fn);

    if (El_do_run_time) {
        El_clock1.stop();
        El_stopwatch_print_time("El_scalar_regalloc", El_clock1.last_elapsed());
    }

    return (new_f);
}
