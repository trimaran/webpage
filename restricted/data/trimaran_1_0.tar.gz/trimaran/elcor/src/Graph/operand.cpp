/******************************************************************************

                    SOFTWARE LICENSE AGREEMENT NOTICE
                   -----------------------------------

IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM THE FILE
OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE OR DERIVATIVE
WORKS. 
___________________________________________________

Copyright Notices/Identification of Licensor(s) of Original Software 
in the File 

Copyright (C) 1994 Hewlett-Packard Company

All rights reserved by the foregoing, respectively.
___________________________________________________

Copyright Notices/Identification of Subsequent Licensor(s)/Contributors of 
Derivative Works

Copyright <Year> <Owner>
<Optional: For Commercial license rights, contact:_______________>

All rights reserved by the foregoing, respectively.
___________________________________________________

The code contained in this file, including both binary and source [if released
by the owner(s)] (hereafter, Software) is subject to copyright by the
respective Licensor(s) and ownership remains with such Licensor(s).  The
Licensor(s) of the original Software remain free to license their respective
proprietary Software for other purposes that are independent and separate from
this file, without obligation to any party. 

Licensor(s) grant(s) you (hereafter, Licensee) a license to use the Software
for academic, research and internal business purposes only, without a fee.
"Internal business purposes" means that Licensee may install, use and execute
the Software for the purpose of designing and evaluating products.  Licensee
may submit proposals for research support, and receive funding from private
and Government sponsors for continued development, support and maintenance of
the Software for the purposes permitted herein. 

Licensee may also disclose results obtained by executing the Software, as well
as algorithms embodied therein.  Licensee may redistribute the Software to
third parties provided that the copyright notices and this License Agreement
Notice statement are reproduced on all copies and that no charge is associated
with such copies. No patent or other intellectual property license is granted
or implied by this Agreement, and this Agreement does not license any acts
except those expressly recited. 

Licensee may modify the Software to make derivative works (as defined in
Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works), as
necessary for its own academic, research and internal business purposes.
Title to copyrights and other proprietary rights in Derivative Works created
by Licensee shall be owned by Licensee subject, however, to the underlying
ownership interest(s) of the Licensor(s) in the copyrights and other
proprietary rights in the original Software.  All the same rights and licenses
granted herein and all other terms and conditions contained in this Agreement
pertaining to the Software shall continue to apply to any parts of the
Software included in Derivative Works.  Licensee's Derivative Work should
clearly notify users that it is a modified version and not the original
Software distributed by the Licensor(s). 

If Licensee wants to make its Derivative Works available to other parties,
such distribution will be governed by the terms and conditions of this License
Agreement.  Licensee shall not modify this License Agreement, except that
Licensee shall clearly identify the contribution of its Derivative Work to
this file by adding an additional copyright notice to the other copyright
notices listed above, to be added below the line "Copyright
Notices/Identification of Subsequent Licensor(s)/Contributors of Derivative
Works."  A party who is not an owner of such Derivative Work within the
meaning of U.S. Copyright Law (i.e., the original author, or the employer of
the author if "work of hire") shall not modify this License Agreement or add
such party's name to the copyright notices above. 

Each party who contributes Software or makes a Derivative Work to this file
(hereafter, Contributed Code) represents to each Licensor and to other
Licensees for its own Contributed Code that: 

(a)  Such Contributed Code does not violate (or cause the Software to
violate) the laws of the United States, including the export control laws of
the United States, or the laws of any other jurisdiction. 

(b)  The contributing party has all legal right and authority to make such
Contributed Code available and to grant the rights and licenses contained in
this License Agreement without violation or conflict with any law. 

(c)  To the best of the contributing party's knowledge and belief, the
Contributed Code does not infringe upon any proprietary rights or intellectual
property rights of any third party. 

LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SOFTWARE
OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" 	WITHOUT
EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE MERCHANTABILITY,
USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY WARRANTY AGAINST
INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.  LICENSOR(S) SHALL NOT BE
LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THE SOFTWARE OR DERIVATIVE
WORKS. 

Any Licensee wishing to make commercial use of the Software or Derivative
Works should contact each and every Licensor to negotiate an appropriate
license for such commercial use, and written permission of all Licensors will
be required for such a commercial license.  Commercial use includes (1)
integration of all or part of the source code into a product for sale by or on
behalf of Licensee to third parties, or (2) distribution of the Software or
Derivative Works to third parties that need it to utilize a commercial product
sold or licensed by or on behalf of Licensee. 

By using or copying this Contributed Code, Licensee agrees to abide by the
copyright law and all other applicable laws of the U.S., and the terms of this
License Agreement.  Any individual Licensor shall have the right to terminate
this license immediately by written notice upon Licensee's breach of, or
non-compliance with, any of its terms.  Licensee may be held legally
responsible for any copyright infringement that is caused or encouraged by
Licensee's failure to abide by the terms of this License Agreement. 

******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//
//      File:           operand.cpp
//      Authors:        Vinod Kathail, Sadun Anik, Richard Johnson,
//                      Santosh Abraham, Scott Mahlke, Dave August,
//                      Joel Jones, Greg Snider, Shail Aditya
//      Created:        December 1994
//      Description:    Operand class declaration 
//
/////////////////////////////////////////////////////////////////////////////

#include "operand.h"
#include <strstream.h>
#include <string.h>
#include <stdlib.h>
#include "hash_map.h"
#include "hash_functions.h"
#include "string_class.h"
#include "intf.h"
#include "regtochar.h"

/* Initialize virtual register number */
int virtual_register_number = 1;

void adjust_vr_num(int number) {
  if (virtual_register_number <= number) 
    virtual_register_number = number + 1;
}

eString gpr_string("GPR") ;
eString fpr_string("FPR") ;
eString pr_string("PR") ;
eString btr_string("BTR") ;
eString cr_string("CR") ;
eString empty_string("") ;


/* For converting register files to textual representation */
eString reg_file_to_text (Reg_file file_type) {
   switch (file_type) {
    case GPR: return gpr_string;
    case FPR: return fpr_string;
    case PR:  return pr_string;
    case BTR: return btr_string;
    case CR:  return cr_string;
    default:  return empty_string;
    }
    return empty_string; // should never occur mss 12-17-94
}

eString data_type_to_text (Data_type d)
{
   switch(d) {
      case EL_DT_VOID:		return ("V");
      case EL_DT_bool:		return ("BO");
      case EL_DT_CHAR:		return ("C");
      case EL_DT_UCHAR:		return ("UC");
      case EL_DT_SHORT:		return ("S");
      case EL_DT_USHORT:	return ("US");
      case EL_DT_INT:		return ("I");
      case EL_DT_UINT:		return ("UI");
      case EL_DT_LONG:		return ("L");
      case EL_DT_ULONG:		return ("UL");
      case EL_DT_LLONG:		return ("LL");
      case EL_DT_ULLONG:	return ("ULL");
      case EL_DT_LLLONG:	return ("LLL");
      case EL_DT_ULLLONG:	return ("ULLL");
      case EL_DT_POINTER:	return ("PTR");
      case EL_DT_FLOAT:		return ("F");
      case EL_DT_DOUBLE:	return ("D");
      case EL_DT_BRANCH:	return ("BR");
      case EL_DT_PREDICATE:	return ("P");
      case EL_DT_LOCAL_ABS:	return ("L_ABS");
      case EL_DT_LOCAL_GP:	return ("L_GP");
      case EL_DT_GLOBAL_ABS:	return ("G_ABS");
      case EL_DT_GLOBAL_GP:	return ("G_GP");
      default:			return ("");
   }
}

Reg_file data_type_to_file (Data_type d)
{
   switch(d) {
      case EL_DT_VOID:		return (GPR);
      case EL_DT_bool:		return (GPR);
      case EL_DT_CHAR:		return (GPR);
      case EL_DT_UCHAR:		return (GPR);
      case EL_DT_SHORT:		return (GPR);
      case EL_DT_USHORT:	return (GPR);
      case EL_DT_INT:		return (GPR);
      case EL_DT_UINT:		return (GPR);
      case EL_DT_LONG:		return (GPR);
      case EL_DT_ULONG:		return (GPR);
      case EL_DT_LLONG:		return (GPR);
      case EL_DT_ULLONG:	return (GPR);
      case EL_DT_LLLONG:	return (GPR);
      case EL_DT_ULLLONG:	return (GPR);
      case EL_DT_POINTER:	return (GPR);
      case EL_DT_FLOAT:		return (FPR);
      case EL_DT_DOUBLE:	return (FPR);
      case EL_DT_BRANCH:	return (BTR);
      case EL_DT_PREDICATE:	return (PR);
      case EL_DT_LOCAL_ABS:     return (GPR);
      case EL_DT_LOCAL_GP:      return (GPR);
      case EL_DT_GLOBAL_ABS:    return (GPR);
      case EL_DT_GLOBAL_GP:     return (GPR);
      default:		assert(0); return (GPR);
   }
}

////////////////////////////////////////////////////////////////////////////
//  Symboltable_entry class  :  An envelope for Base_operand for symbol table
////////////////////////////////////////////////////////////////////////////

Symboltable_entry::Symboltable_entry()
{}
Symboltable_entry::~Symboltable_entry() // Do not delete base_operand
{}

Symboltable_entry::Symboltable_entry(Base_operand * ptr)
   : operand_ptr(ptr)
{}

Symboltable_entry::Symboltable_entry(const Symboltable_entry& op)
   : operand_ptr(op.operand_ptr)
{}

Symboltable_entry& Symboltable_entry::operator=(const Symboltable_entry& op)
{
   operand_ptr = op.operand_ptr ;
   return (*this) ;
} 
bool Symboltable_entry::operator==(const Symboltable_entry& op) const
{
   return (operand_ptr->is_identical(*op.operand_ptr)) ;
}

bool Symboltable_entry::operator!=(const Symboltable_entry& op) const
{
   return (operand_ptr->operator!=(*op.operand_ptr)) ;
} 

bool Symboltable_entry::operator<(const Symboltable_entry& oprnd) const
{
   char o1[64], o2[64] ;
   ostrstream ost1(o1,64), ost2(o2,64)  ;
   ost1 << *this << '\0';
   ost2 << oprnd << '\0';   
   if (strcmp(o1,o2) < 0) return true ;
   else return false ;
}



/* ------------ Base_operand Class */

Base_operand::Base_operand() {}
Base_operand::Base_operand(const Base_operand& bop) {}
Base_operand::~Base_operand() {}

Base_operand& Base_operand::operator=(const Base_operand& bop) 
{
  return *this;
}

bool Base_operand::operator!=(const Base_operand& operand) const{
   return !operator==(operand);
}

bool Base_operand::same_operand_class(const Base_operand& oprnd) const
{ assert(0) ; return false ;}

bool Base_operand::is_undefined() const {return false;}
bool Base_operand::is_reg() const {return false;}
bool Base_operand::is_vr_name() const {return false;}
bool Base_operand::is_mem_vr() const {return false;}
bool Base_operand::is_macro_reg() const {return false;}
bool Base_operand::is_lit() const {return false;}
bool Base_operand::is_int() const {return false;}
bool Base_operand::is_float() const {return false;}
bool Base_operand::is_double() const {return false;}
bool Base_operand::is_string() const {return false;}
bool Base_operand::is_label() const {return false;}
bool Base_operand::is_predicate() const {return false;}
bool Base_operand::is_predicate_true() const {return false;}
bool Base_operand::is_predicate_false() const {return false;}
bool Base_operand::is_cb() const {return false;}
bool Base_operand::assigned_to_file() const {return true;} 
bool Base_operand::allocated() const {return true;} 

int  Base_operand::omega() const { return (0); }
void  Base_operand::set_omega(int) { assert(0); }

Data_type Base_operand::data_type() const { assert(0); return(EL_DT_INT); }
void Base_operand::set_data_type(Data_type t) {assert(0); }

// Override for Reg, Macro, VR_name and Undefined
Reg_file Base_operand::file_type() const { assert(0); return(GPR); }

// override for Reg, Int_lit, Float_lit, Double_lit
eString Base_operand::physical_file_type() const {assert(0);return(eString)"";}
void Base_operand::bind_physical_file(eString phys_file) { assert(0); }
void Base_operand::unbind_physical_file() { assert(0); }

ostream& operator<<(ostream& os, const Base_operand& operand){
  operand.print(os);
  return os;
}

/* -------------  Reg  class */
Reg::Reg(Data_type data_type)
  :d_type(data_type), file(data_type_to_file(data_type)), physical_file("")
{
   vr_rep = virtual_register_number++;
   omega_num = 0;
   history = vr_rep;
   assigned = true;
   alloc = false;
   sr = STATIC ;
   mc_rep = 0 ;
}

Reg::Reg(Data_type data_type, int vr_number, int omega)
  :d_type(data_type), file(data_type_to_file(data_type)), physical_file(""),
   vr_rep(vr_number), omega_num(omega)
{
   history = vr_rep;
   assigned = true;
   alloc = false;
   sr = STATIC ;
   mc_rep = 0 ;
   ::adjust_vr_num(vr_rep);
}

Reg::Reg(Data_type data_type, Reg_file r_file, int vr_number)
   :d_type(data_type), file(r_file), physical_file(""), vr_rep(vr_number)
{
   omega_num = 0 ;
   history = vr_rep;
   assigned = true;
   alloc = false;
   sr = STATIC ;
   mc_rep = 0 ;
   ::adjust_vr_num(vr_rep);
}
   

Reg::Reg(const Reg& reg)
  :d_type(reg.d_type), file(reg.file), 
   physical_file(reg.physical_file),
   vr_rep(reg.vr_rep), omega_num(reg.omega_num), 
   history(reg.history), assigned(reg.assigned), 
   alloc(reg.alloc), sr(reg.sr), mc_rep(reg.mc_rep)
{}

Reg::Reg(const Operand& r)
{
  assert (r.is_reg() || r.is_vr_name());

  d_type = r.data_type();
  file = data_type_to_file(r.data_type());
  vr_rep = r.vr_num();
  if (r.is_reg()) {
     Reg& reg = *((Reg*)((Operand&)r).get_ptr()) ;
     omega_num = reg.omega_num;
     physical_file = reg.physical_file;
     history = reg.history;
     assigned = reg.assigned;
     alloc = reg.alloc;
     sr = reg.sr ;
     mc_rep = reg.mc_rep ;
 }
  else {
     omega_num = 0 ;
     physical_file = "";
     history = vr_rep ;
     assigned = true ;
     alloc = false ;
     sr = STATIC ;
     mc_rep = 0 ;
  }
}

Base_operand* Reg::clone() const{
   return (new Reg(*this));
}

Reg::~Reg() 
{}

Reg& Reg::operator=(const Reg& reg){
  d_type = reg.d_type;
  vr_rep = reg.vr_rep;
  omega_num = reg.omega_num;
  history = reg.history;
  assigned = reg.assigned;
  alloc = reg.alloc;
  file = reg.file;
  physical_file = reg.physical_file;
  sr = reg.sr;
  mc_rep = reg.mc_rep;
  return *this;
}

bool Reg::operator==(const Base_operand& operand) const {
   if (operand.is_reg()) {
      Reg& temp = (Reg&)operand;
      if (alloc && temp.alloc) {
         return (equal_mc(operand)) ;
      }
      else {
         return (equal_vr(operand));
      }
   }
   else {
      return false ;
   }
}

bool Reg::is_identical(const Base_operand& operand) const {
   if (operand.is_reg()) {
      Reg& r = (Reg&)operand ;
      if ((d_type == r.d_type) && (file == r.file) && 
	  (physical_file == r.physical_file) && 
	  (vr_rep == r.vr_rep) && (omega_num == r.omega_num) && 
	  (history == r.history) && (assigned == r.assigned) && 
	  (alloc == r.alloc) && (sr == r.sr) && 
	  (mc_rep == r.mc_rep)) {
	 return true ;
      }
   }
   return false ;
}

bool Reg::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_reg()) ;
}

bool Reg::is_reg() const {return true;}

bool Reg::assigned_to_file() const {
  return (assigned ? true : false);
}

bool Reg::allocated() const {
  return (alloc ? true : false);
}

bool Reg::equal_vr(const Base_operand& operand) const {
  if (operand.is_reg()) {
    Reg& temp = (Reg&)operand;
    if ((d_type == temp.d_type) && (vr_rep == temp.vr_rep) &&
	(omega_num == temp.omega_num))
      return true;
    else return false;
  }
  else return false;
}
	
bool Reg::equal_mc(const Base_operand& operand) const {
  if (operand.is_reg()) {
    Reg& temp = (Reg&)operand;
    if (alloc && temp.alloc)
      if ((file == temp.file) && (sr == temp.sr) && (mc_rep == temp.mc_rep))
	return true;
      else return false;
    else return false;
  }
  else return false;
}

void Reg::set_data_type(Data_type t) { d_type = t ; } 
Data_type Reg::data_type() const {return d_type;}
int Reg::vr_num() const {return vr_rep;}
int Reg::omega() const {return omega_num;}
Reg_file Reg::file_type() const {return file;}

bool Reg::is_static() const {
  if (assigned && sr == STATIC) return true;
  else return false;
}

bool Reg::is_rotating() const {
  if (assigned && sr == ROTATING) return true;
  else return false;
}

int Reg::mc_num() const {return mc_rep;}

Reg& Reg::rename() {
  vr_rep = virtual_register_number++;
  return *this;
}

Reg& Reg::rename(int new_vr_rep) {
  vr_rep = new_vr_rep;
  return *this;
}

Reg& Reg::incr_omega(int incr) {
  omega_num += incr;
  return *this;
}

Reg& Reg::bind_file(Reg_file reg_file, Reg_sr s_or_r) {
  assigned = true;
  file = reg_file;
  sr = s_or_r;
  return *this;
}

Reg& Reg::bind_reg(int mc_number) {
  if (!assigned) assert(0);
  alloc = true;
  mc_rep = mc_number;
  return *this;
}

Reg& Reg::unbind_reg() {
  alloc = false;
  return *this;
}

void Reg::set_vr_num(int new_val)
{
   vr_rep = new_val;
}

void Reg::set_omega(int new_val)
{
   omega_num = new_val;
}

void Reg::bind_physical_file(eString phys_file)
{
  if(physical_file != (eString)"")
    El_punt("Reg: already bound!");

  physical_file = phys_file;
}

void Reg::unbind_physical_file()
{
  physical_file = "";
}

eString Reg::physical_file_type() const
{
  return physical_file;
}

bool Reg::assigned_to_physical_file() const
{
  if(physical_file != "")
    return true;
  return false;
}

// This is used for symbol table hashing and has nothing to do with equality
int Reg::hash() const
{
  // return (vr_rep + omega_num) ; Original code, changed SAM 1-98

  if (alloc) {
    return (mc_rep); 
  }
  else {
    return (ELCOR_INT_ABS(vr_rep + omega_num));
  }
}

//
// Warning !!! Warning !!! Warning !!!
// the operator<< is used for hashing Operands. Since if two operands
// are equal in the operator== sense, they should have the same value,
// operands which are equal in the operator== sense must generate the
// same output string
//

void Reg::print(ostream& os) const {
    if (alloc) {
      os << ::reg_file_to_text(file);
      if (sr == STATIC) os << mc_rep;
      else if (sr == ROTATING) os << "[" << mc_rep << "]";
      else assert(0);
    }
    else {
      os << "vr" << vr_rep;
      if (omega_num != 0) os << "[" << omega_num << "]";
      if (assigned) {
        os << ":" << ::reg_file_to_text(file);
        if (sr == STATIC) os << ".s";
        else if (sr == ROTATING) os << ".r";
      }
      os << ":" << ::data_type_to_text(d_type);
    }
}


////////////////////////////////////////////////////////////////////////////
//
//  VR_name 
//
////////////////////////////////////////////////////////////////////////////

VR_name::VR_name(const Reg evr)
   : d_type(evr.data_type()), vr_rep(evr.vr_num()) 
{}

VR_name::VR_name(const Operand opr)
{
  assert(opr.is_reg());
  d_type = opr.data_type();
  vr_rep = opr.vr_num();
}

VR_name::VR_name(Data_type data_type, int vr_number)
  :d_type(data_type), vr_rep(vr_number)
{
}

Base_operand* VR_name::clone() const {
   return (new VR_name(*this));
}

VR_name::~VR_name() {}

bool VR_name::operator==(const Base_operand& bo) const {
   if (bo.is_vr_name()) {
      VR_name& tmp_bo = (VR_name&) bo ;
      if (vr_rep == tmp_bo.vr_rep) {
	 return true ;
      }
      else {
	 return false ;
      }
   }
   else {
      return false ;
   }
}

bool VR_name::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_vr_name()) ;
}

bool VR_name::is_identical(const Base_operand& operand) const {
   if (operand.is_vr_name()) {
      VR_name& r = (VR_name&)operand ;
      if ((d_type == r.d_type) && (vr_rep == r.vr_rep)) {
	 return true ;
      }
   }
   return false ;
}

bool VR_name::is_vr_name() const { return true ; }

bool VR_name::same_name(const Base_operand& bo) const
{
   if (bo.is_reg()) {
      Reg& tmp_bo = (Reg&) bo ;
      if (vr_rep == tmp_bo.vr_num()) {
	 return true ;
      }
      else {
	 return false ;
      }
      
   }
   else if (bo.is_vr_name()){
      return (operator==(bo)) ;
   }
   else {
      return false ;
   }
}

Data_type VR_name::data_type() const { return d_type ;}

void VR_name::set_data_type(Data_type t) {d_type = t; }

int VR_name::vr_num() const {return vr_rep ; }

VR_name& VR_name::rename(const Reg& evr)
{
   vr_rep = evr.vr_num() ;
   return (*this) ;
}

void VR_name::set_vr_num(int new_val)
{
   vr_rep = new_val;
}

int VR_name::hash() const { return (vr_rep) ;}

void VR_name::print(ostream& os) const {
  os << "EVR_name" << vr_rep;
}

////////////////////////////////////////////////////////////////////////////


/* -------------  Mem_vr  class */

Mem_vr::Mem_vr(){
  vr_rep = virtual_register_number++;
  history = vr_rep;
  omega_num = 0;
}
  
Mem_vr::Mem_vr(int vr_number, int omega)
  :vr_rep(vr_number), omega_num(omega)
{
  history = vr_rep;
  ::adjust_vr_num(vr_rep);
}

Mem_vr::Mem_vr(const Mem_vr& reg)
  :vr_rep(reg.vr_rep), omega_num(reg.omega_num), history(reg.history) {}

Base_operand* Mem_vr::clone() const{
  return (new Mem_vr(*this));
}

Mem_vr::~Mem_vr() {}

Mem_vr& Mem_vr::operator=(const Mem_vr& reg){
  vr_rep = reg.vr_rep;
  history = reg.history;
  omega_num = reg.omega_num;
  return *this;
}

bool Mem_vr::operator==(const Base_operand& operand) const {
  if (operand.is_mem_vr())
    return ((vr_rep == ((Mem_vr&)operand).vr_rep) &&
	    (omega_num == ((Mem_vr&)operand).omega_num));
  else return false;
}

bool Mem_vr::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_mem_vr()) ;
}

bool Mem_vr::is_identical(const Base_operand& operand) const {
   if (operand.is_mem_vr()) {
      Mem_vr& r = (Mem_vr&)operand ;
      if ((vr_rep == r.vr_rep) && (omega_num == r.omega_num) &&
	  (history == r.history)) {
	 return true ;
      }
   }
   return false ;
}

bool Mem_vr::is_mem_vr() const {return true;}

int Mem_vr::vr_num() const {return vr_rep;}
int Mem_vr::omega() const {return omega_num;}

Mem_vr& Mem_vr::rename() {
  vr_rep = virtual_register_number++;
  return *this;
}

Mem_vr& Mem_vr::rename(int newnum) {
  vr_rep = newnum;
  return *this;
}

Mem_vr& Mem_vr::incr_omega(int incr) {
  omega_num += incr;
  return *this;
}

void Mem_vr::set_vr_num(int new_val)
{
   vr_rep = new_val;
}

void Mem_vr::set_omega(int new_val)
{
   omega_num = new_val;
}

int Mem_vr::hash() const { return (vr_rep + omega_num) ;} 

void Mem_vr::print(ostream& os) const {
  os << "vr" << vr_rep;
  if (omega_num != 0) os << "[" << omega_num << "]";
}
  
/* ------------- Macro registers */

Macro_reg::Macro_reg()
{
  name_rep = UNDEFINED;
}

Macro_reg::Macro_reg(const Macro_reg& mr)
   :d_type(mr.d_type), file(mr.file), physical_file(""),
    name_rep(mr.name_rep) {}

Macro_reg::Macro_reg(Macro_name new_name)
  : physical_file("")
{
  name_rep = new_name;
  
  switch(name_rep)
    {
    case UNDEFINED:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case LOCAL:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case PARAM:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case SWAP:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case INT_RETURN_TYPE:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case FLT_RETURN_TYPE:
      d_type = EL_DT_FLOAT;
      file = FPR;
      break;
    case DBL_RETURN_TYPE:
      d_type = EL_DT_DOUBLE;
      file = FPR;
      break;
    case INT_RETURN:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case INT_PARAM_1:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case INT_PARAM_2:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case INT_PARAM_3:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case INT_PARAM_4:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case FLT_RETURN:
      d_type = EL_DT_FLOAT;
      file = FPR;
      break;
    case FLT_PARAM_1:
      d_type = EL_DT_FLOAT;
      file = FPR;
      break;
    case FLT_PARAM_2:
      d_type = EL_DT_FLOAT;
      file = FPR;
      break;
    case FLT_PARAM_3:
      d_type = EL_DT_FLOAT;
      file = FPR;
      break;
    case FLT_PARAM_4:
      d_type = EL_DT_FLOAT;
      file = FPR;
      break;
    case DBL_RETURN:
      d_type = EL_DT_DOUBLE;
      file = FPR;
      break;
    case DBL_PARAM_1:
      d_type = EL_DT_DOUBLE;
      file = FPR;
      break;
    case DBL_PARAM_2:
      d_type = EL_DT_DOUBLE;
      file = FPR;
      break;
    case INT_TM_TYPE:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case FLT_TM_TYPE:
      d_type = EL_DT_FLOAT;
      file = FPR;
      break;
    case DBL_TM_TYPE:
      d_type = EL_DT_DOUBLE;
      file = FPR;
      break;
    case SP_REG:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case FP_REG:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case IP_REG:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case OP_REG:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case LV_REG:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case RGS_REG:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case LC_REG:
      d_type = EL_DT_INT;
      file = CR;
      break;
    case ESC_REG:
      d_type = EL_DT_INT;
      file = CR;
      break;
    case ALL_PRED:
      d_type = EL_DT_PREDICATE;
      file = PR;
      break;
    case ALL_ROT_PRED:
      d_type = EL_DT_PREDICATE;
      file = PR;
      break;
    case ALL_STATIC_PRED:
      d_type = EL_DT_PREDICATE;
      file = PR;
      break;
    case RRB:
      d_type = EL_DT_INT;
      file = CR;
      break;
    case RETURN_ADDR:
      d_type = EL_DT_BRANCH;
      file = BTR;
      break;
    case FLT_ZERO:
      d_type = EL_DT_FLOAT;
      file = FPR;
      break;
    case FLT_ONE:
      d_type = EL_DT_FLOAT;
      file = FPR;
      break;
    case DBL_ZERO:
      d_type = EL_DT_DOUBLE;
      file = FPR;
      break;
    case DBL_ONE:
      d_type = EL_DT_DOUBLE;
      file = FPR;
      break;
    case INT_ZERO:
      d_type = EL_DT_INT;
      file = FPR;
      break;
    case PRED_FALSE:
      d_type = EL_DT_PREDICATE;
      file = PR;
      break;
    case PRED_TRUE:
      d_type = EL_DT_PREDICATE;
      file = PR;
      break;
    case SPILL_TEMPREG:
      d_type = EL_DT_INT;
      file = GPR;
      break;
    case PV_0:
      d_type = EL_DT_PREDICATE;
      file = CR;
      break;
    case PV_1:
      d_type = EL_DT_PREDICATE;
      file = CR;
      break;
    case PV_2:
      d_type = EL_DT_PREDICATE;
      file = CR;
      break;
    case PV_3:
      d_type = EL_DT_PREDICATE;
      file = CR;
      break;
    case PV_4:
      d_type = EL_DT_PREDICATE;
      file = CR;
      break;
    case PV_5:
      d_type = EL_DT_PREDICATE;
      file = CR;
      break;
    case PV_6:
      d_type = EL_DT_PREDICATE;
      file = CR;
      break;
    case PV_7:
      d_type = EL_DT_PREDICATE;
      file = CR;
      break;

    default:
	El_punt("Macro_reg::Macro_reg(): unknown macro");
    }
}

Base_operand* Macro_reg::clone() const 
{
   return (new Macro_reg(*this));
}
   
Macro_reg::~Macro_reg() {} 

Macro_reg& Macro_reg::operator=(const Macro_reg& mr) 
{
   name_rep = mr.name_rep ;
   d_type = mr.d_type ;
   file = mr.file ;
   physical_file = mr.physical_file;
   return(*this) ;
}

bool Macro_reg::operator==(const Base_operand& operand) const
{
   if (operand.is_macro_reg())
     return (name_rep == ((Macro_reg&)operand).name_rep);
   else return(false) ;
}

bool Macro_reg::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_macro_reg()) ;
}

bool Macro_reg::is_identical(const Base_operand& operand) const {
   if (operand.is_macro_reg()) {
      Macro_reg& r = (Macro_reg&)operand ;
      if ((d_type == r.d_type) && (file == r.file) &&
	  (name_rep == r.name_rep)) {
	 return true ;
      }
   }
   return false ;
}

bool Macro_reg::is_fragile_macro() const
{
  if(name_rep == INT_ZERO) return false;
  if(name_rep == FLT_ZERO) return false;
  if(name_rep == FLT_ONE) return false;
  if(name_rep == DBL_ZERO) return false;
  if(name_rep == DBL_ONE) return false;
  if(name_rep == SP_REG) return false;
  if(name_rep == FP_REG) return false;
  if(name_rep == LV_REG) return false;
  if(name_rep == RGS_REG) return false;
  if(name_rep == IP_REG) return false;
  if(name_rep == OP_REG) return false;
  if(name_rep == LOCAL) return false;
  if(name_rep == PARAM) return false;
  if(name_rep == SWAP) return false;
  if(name_rep == PRED_FALSE) return false;
  if(name_rep == PRED_TRUE) return false;

  return true;
}

bool Macro_reg::is_predicate_true() const
{
  return name_rep == PRED_TRUE;
}

bool Macro_reg::is_predicate_false() const
{
  return name_rep == PRED_FALSE;
}

bool Macro_reg::is_macro_reg() const { return true;}
Macro_name Macro_reg::name() const { return name_rep;}

Data_type Macro_reg::data_type() const {return d_type;}
void Macro_reg::set_data_type(Data_type t) {d_type = t;}

Reg_file Macro_reg::file_type() const {return file;}

void Macro_reg::set_name(Macro_name new_name)
{
   name_rep = new_name;
}

static eString macro_reg_to_text (Macro_name macro)
{
    switch (macro) {
	case UNDEFINED:			return "?";
	case LOCAL:			return "LOCAL";
	case PARAM:			return "PARAM";
	case SWAP:			return "SWAP";
	case INT_RETURN_TYPE:		return "IRETURN_TYPE";
	case FLT_RETURN_TYPE:		return "FRETURN_TYPE";
	case DBL_RETURN_TYPE:		return "DRETURN_TYPE";
	case INT_RETURN:		return "IRETURN";
	case INT_PARAM_1:		return "IPARAM1";
	case INT_PARAM_2:		return "IPARAM2";
	case INT_PARAM_3:		return "IPARAM3";
	case INT_PARAM_4:		return "IPARAM4";
	case FLT_RETURN:		return "FRETURN";
	case FLT_PARAM_1:		return "FPARAM1";
	case FLT_PARAM_2:		return "FPARAM2";
	case FLT_PARAM_3:		return "FPARAM3";
	case FLT_PARAM_4:		return "FPARAM4";
	case DBL_RETURN:		return "DRETURN";
	case DBL_PARAM_1:		return "DPARAM1";
	case DBL_PARAM_2:		return "DPARAM2";
	case INT_TM_TYPE:		return "ITM_TYPE";
	case FLT_TM_TYPE:		return "FTM_TYPE";
	case DBL_TM_TYPE:		return "DTM_TYPE";
	case SP_REG:			return "SP";
	case FP_REG:			return "FP";
	case IP_REG:			return "IP";
	case OP_REG:			return "OP";
	case LV_REG:			return "LV";
	case RGS_REG:			return "RGS";
	case LC_REG:			return "LC";
	case ESC_REG:			return "ESC";
	case ALL_PRED:			return "ALL_PRED";
	case ALL_ROT_PRED:		return "ALL_ROT_PRED";
	case ALL_STATIC_PRED:		return "ALL_STATIC_PRED";
	case RRB:			return "RRB";
	case RETURN_ADDR:		return "RETURN_ADDR";
	case FLT_ZERO:			return "FZERO";
	case FLT_ONE:			return "FONE";
	case DBL_ZERO:			return "DZERO";
	case DBL_ONE:			return "DONE";
	case INT_ZERO:			return "IZERO";
	case PRED_FALSE:		return "PZERO";
	case PRED_TRUE:			return "PONE";
	case SPILL_TEMPREG:		return "TEMPREG";
	default:
	    El_punt("macro_reg_to_text: unknown macro");
	    return "?";
    }
}

void Macro_reg::bind_physical_file(eString phys_file)
{
  if(physical_file != (eString)"")
    El_punt("Macro_reg: already bound!");

  physical_file = phys_file;
}

void Macro_reg::unbind_physical_file()
{
  physical_file = "";
}

eString Macro_reg::physical_file_type() const
{
  return physical_file;
}

bool Macro_reg::assigned_to_physical_file() const
{
  if(physical_file != "")
    return true;
  return false;
}

int Macro_reg::hash() const { return ((int) name_rep) ; }

void Macro_reg::print(ostream& os) const {
   os << "mr" << ":" << macro_reg_to_text(name_rep) << ":" << ::reg_file_to_text(file);
   os << ":" << ::data_type_to_text(d_type);
}

/* ------------- Integer literals */

Int_lit::Int_lit(int value, Data_type data_type)
  :rep(value), d_type(data_type), physical_file("") {}

Int_lit::Int_lit(const Int_lit& literal)
  :rep(literal.rep), d_type(literal.d_type), physical_file("") {} 

Base_operand* Int_lit::clone() const{
  return (new Int_lit(*this));
}

Int_lit::~Int_lit() {
  unbind_physical_file();
}

Int_lit& Int_lit::operator=(const Int_lit& literal) {
  rep = literal.rep;
  d_type = literal.d_type;
  physical_file = literal.physical_file;
  return *this;
}

bool Int_lit::operator==(const Base_operand& operand) const{
  if (operand.is_int()) 
    return ((((Int_lit&)operand).rep == rep) &&
	    (physical_file == ((Int_lit&)operand).physical_file));
  return false;
}

bool Int_lit::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_int()) ;
}

bool Int_lit::is_identical(const Base_operand& operand) const {
   if (operand.is_int()) {
     Int_lit& r = (Int_lit&)operand ;
     if (rep == r.rep &&
	 d_type == r.d_type &&
	 physical_file == r.physical_file)
       return true ;
   }
   return false ;
}

bool Int_lit::is_lit() const {return true;}
bool Int_lit::is_int() const {return true;}
int Int_lit::value() const {return rep;}
int Int_lit::int_value() const {return rep;}

void Int_lit::set_value(int new_val)
{
   rep = new_val;
}

Data_type Int_lit::data_type() const {return d_type;}
void Int_lit::set_data_type(Data_type t) {d_type = t;}

void Int_lit::bind_physical_file(eString phys_file)
{
  if(physical_file != (eString)"")
    El_punt("Int_lit: already bound!");

  physical_file = phys_file;
}

void Int_lit::unbind_physical_file()
{
  physical_file = "";
}

eString Int_lit::physical_file_type() const
{
  return physical_file;
}

bool Int_lit::assigned_to_physical_file() const
{
  if(physical_file != "")
    return true;
  return false;
}

int Int_lit::hash() const {return rep;}

void Int_lit::print(ostream& os) const {
  os << "I:" << rep;
}

/* ------------- Predicate literals */

Pred_lit::Pred_lit(bool value, Data_type data_type) 
   :rep(value), d_type(data_type) {}
   
Pred_lit::Pred_lit(const Pred_lit& plit)   
   :rep(plit.rep), d_type(plit.d_type) {} 
   
   Base_operand* Pred_lit::clone() const
{
   return(new Pred_lit(*this)) ;
}

Pred_lit::~Pred_lit(){} ;

Pred_lit& Pred_lit::operator=(const Pred_lit& plit)
{
   rep = plit.rep ;
   d_type = plit.d_type;
   return(*this) ;
}

bool Pred_lit::operator==(const Base_operand& operand) const { 
  if (operand.is_predicate()) 
    return (((Pred_lit&)operand).rep == rep);
  else return false;
}

bool Pred_lit::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_predicate()) ;
}

bool Pred_lit::is_identical(const Base_operand& operand) const {
   if (operand.is_predicate()) {
      Pred_lit& r = (Pred_lit&)operand ;
      if ((rep == r.rep) && (d_type == r.d_type)) {
	 return true ;
      }
   }
   return false ;
}

bool Pred_lit::is_lit() const { return true;}
bool Pred_lit::is_predicate() const { return true;}
bool Pred_lit::is_predicate_true() const { return rep == true;}
bool Pred_lit::is_predicate_false() const { return rep == false;}

bool Pred_lit::value() const {return rep;}

void Pred_lit::set_value(bool new_val)
{
   rep = new_val;
}

Data_type Pred_lit::data_type() const {return d_type;}
void Pred_lit::set_data_type(Data_type t) {d_type = t;}

int Pred_lit::hash() const { return (rep) ; }

void Pred_lit::print(ostream& os) const {
  os << "P:" << rep;
}

/* ----------------- Floating-point literals */

Float_lit::Float_lit(float value, Data_type data_type)
  :rep(value), d_type(data_type), physical_file("") {}

Float_lit::Float_lit(const Float_lit& literal)
  :rep(literal.rep), d_type(literal.d_type), physical_file("") {} 

  Base_operand* Float_lit::clone() const{
  return (new Float_lit(*this));
}

Float_lit::~Float_lit() {};

Float_lit& Float_lit::operator=(const Float_lit& literal){
  rep = literal.rep;
  d_type = literal.d_type;
  physical_file = literal.physical_file;
  return *this;
}

bool Float_lit::operator==(const Base_operand& operand) const{
 if (operand.is_float()) 
    return ((((Float_lit&)operand).rep == rep) &&
	    (physical_file == ((Float_lit&)operand).physical_file));
 else return false;
}

bool Float_lit::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_float()) ;
}

bool Float_lit::is_identical(const Base_operand& operand) const {
   if (operand.is_float()) {
     Float_lit& r = (Float_lit&)operand ;
     if ((rep == r.rep) && (d_type == r.d_type) &&
	 (physical_file == r.physical_file))
       return true ;
   }
   return false ;
}

bool Float_lit::is_lit() const {return true;}
bool Float_lit::is_float() const {return true;}
float Float_lit::value() const {return rep;}

void Float_lit::set_value(float new_val)
{
   rep = new_val;
}

Data_type Float_lit::data_type() const {return d_type;}
void Float_lit::set_data_type(Data_type t) {d_type = t;}

void Float_lit::bind_physical_file(eString phys_file)
{
  if(physical_file != (eString)"")
    El_punt("Float_lit: already bound!");

  physical_file = phys_file;
}

void Float_lit::unbind_physical_file()
{
  physical_file = "";
}

eString Float_lit::physical_file_type() const
{
  return physical_file;
}

bool Float_lit::assigned_to_physical_file() const
{
  if(physical_file != "")
    return true;
  return false;
}

int Float_lit::hash() const {return ((int) rep);}

void Float_lit::print(ostream& os) const {
  os << "F:" << rep;
}



/* ---------------- Double floating-point literals */

Double_lit::Double_lit(double value, Data_type data_type)
  :rep(value), d_type(data_type), physical_file("") {}

Double_lit::Double_lit(const Double_lit& literal)
  :rep(literal.rep), d_type(literal.d_type), physical_file("") {} 

  Base_operand* Double_lit::clone() const{
  return (new Double_lit(*this));
}

Double_lit::~Double_lit(){};

Double_lit& Double_lit::operator=(const Double_lit& literal){
  rep = literal.rep;
  d_type = literal.d_type;
  physical_file = literal.physical_file;
  return *this;
}

bool Double_lit::operator==(const Base_operand& operand) const{
  if (operand.is_double()) 
    return ((((Double_lit&)operand).rep == rep) &&
	    (physical_file == ((Double_lit&)operand).physical_file));
  else return false;
}

bool Double_lit::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_double()) ;
}

bool Double_lit::is_identical(const Base_operand& operand) const {
   if (operand.is_double()) {
     Double_lit& r = (Double_lit&)operand ;
     if ((rep == r.rep) && (d_type == r.d_type) &&
	 (physical_file == r.physical_file))
       return true ;
   }
   return false ;
}

bool Double_lit::is_lit() const {return true;}
bool Double_lit::is_double() const {return true;}
double Double_lit::value() const {return rep;}

void Double_lit::set_value(double new_val)
{
   rep = new_val;
}

Data_type Double_lit::data_type() const {return d_type;}
void Double_lit::set_data_type(Data_type t) {d_type = t;}

void Double_lit::bind_physical_file(eString phys_file)
{
  if(physical_file != (eString)"")
    El_punt("Double_lit: already bound!");

  physical_file = phys_file;
}

void Double_lit::unbind_physical_file()
{
  physical_file = "";
}

eString Double_lit::physical_file_type() const
{
  return physical_file;
}

bool Double_lit::assigned_to_physical_file() const
{
  if(physical_file != "")
    return true;
  return false;
}

int Double_lit::hash() const {return ((int) rep);}

void Double_lit::print(ostream& os) const {
  os << "D:" << rep;
}

/* ----------------- String literal class */

String_lit::String_lit(const eString& value, Data_type data_type)
  :rep(value), d_type(data_type), physical_file("") {}

String_lit::String_lit(const String_lit& literal)
  :rep(literal.rep), d_type(literal.d_type), physical_file("") {} 

  Base_operand* String_lit::clone() const{
  return (new String_lit(*this));
}

String_lit::~String_lit(){};

String_lit& String_lit::operator=(const String_lit& literal){
  rep = literal.rep;
  d_type = literal.d_type;
  physical_file = literal.physical_file;
  return *this;
}

bool String_lit::operator==(const Base_operand& operand) const{
  if (operand.is_string()) 
    return (((String_lit&)operand).rep == rep);
  else return false;
}

bool String_lit::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_string()) ;
}

bool String_lit::is_identical(const Base_operand& operand) const {
   if (operand.is_string()) {
      String_lit& r = (String_lit&)operand ;
      if ((rep == r.rep) && (d_type == r.d_type) &&
	  physical_file == r.physical_file) {
	 return true ;
      }
   }
   return false ;
}

bool String_lit::is_lit() const {return true;}
bool String_lit::is_string() const {return true;}
eString String_lit::value() const {return rep;}

void String_lit::bind_physical_file(eString phys_file)
{
  if(physical_file != (eString)"")
    El_punt("String_lit: already bound!");

  physical_file = phys_file;
}

void String_lit::unbind_physical_file()
{
  physical_file = "";
}

eString String_lit::physical_file_type() const
{
  return physical_file;
}

bool String_lit::assigned_to_physical_file() const
{
  if(physical_file != "")
    return true;
  return false;
}

int String_lit::hash() const { return (hash_estring((eString&)rep)) ; }

void String_lit::set_value(eString new_val)
{
   rep = new_val;
}

Data_type String_lit::data_type() const {return d_type;}
void String_lit::set_data_type(Data_type t) {d_type = t;}

void String_lit::print(ostream& os) const {
 os << "S:" << "\""<< rep << "\"";
}


/* ---------------- Label literal class */

Label_lit::Label_lit(const eString& value, Data_type data_type)
  :rep(value), d_type(data_type), physical_file("") {}

Label_lit::Label_lit(const Label_lit& literal)
  :rep(literal.rep), d_type(literal.d_type), physical_file("") {} 

Base_operand* Label_lit::clone() const {
  return (new Label_lit(*this));
}

Label_lit::~Label_lit(){};

Label_lit& Label_lit::operator=(const Label_lit& literal){
  rep = literal.rep;
  d_type = literal.d_type;
  physical_file = literal.physical_file;
  return *this;
}


bool Label_lit::operator==(const Base_operand& operand) const{
  if (operand.is_label())
    return (((Label_lit&)operand).rep == rep);
  else return false;
}

bool Label_lit::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_label()) ;
}

bool Label_lit::is_identical(const Base_operand& operand) const {
   if (operand.is_label()) {
      Label_lit& r = (Label_lit&)operand ;
      if ((rep == r.rep) && (d_type == r.d_type) &&
	  physical_file == r.physical_file) {
	 return true ;
      }
   }
   return false ;
}

bool Label_lit::is_lit() const {return true;}
bool Label_lit::is_label() const {return true;}
eString Label_lit::value() const {return rep;}

void Label_lit::bind_physical_file(eString phys_file)
{
  if(physical_file != (eString)"")
    El_punt("Label_lit: already bound!");

  physical_file = phys_file;
}

void Label_lit::unbind_physical_file()
{
  physical_file = "";
}

eString Label_lit::physical_file_type() const
{
  return physical_file;
}

bool Label_lit::assigned_to_physical_file() const
{
  if(physical_file != "")
    return true;
  return false;
}

int Label_lit::hash() const {return (hash_estring((eString&)rep)); }

void Label_lit::set_value(eString new_val)
{
   rep = new_val;
}

Data_type Label_lit::data_type() const {return d_type;}
void Label_lit::set_data_type(Data_type t) {d_type = t;}

void Label_lit::print(ostream& os) const {
 os << "L:" << rep;
}

/* ----------- Control Block class */

Cb_operand::Cb_operand(int i, Data_type data_type)
   :id_rep(i), d_type(data_type), physical_file("") {}
   
Cb_operand::Cb_operand(const Cb_operand& cb)
   :id_rep(cb.id_rep), d_type(cb.d_type), physical_file("") {}
   
Base_operand* Cb_operand::clone() const
{
   return(new Cb_operand(*this)) ;
}

Cb_operand::~Cb_operand(){}

Cb_operand& Cb_operand::operator=(const Cb_operand& cb) 
{
   id_rep = cb.id_rep ;
   d_type = cb.d_type ;
   physical_file = cb.physical_file;
   return *this ;
}

bool Cb_operand::operator==(const Base_operand& operand) const {
  if (operand.is_cb())
    return (id_rep == ((Cb_operand&)operand).id_rep);
  else return false;
}

bool Cb_operand::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_cb()) ;
}

bool Cb_operand::is_identical(const Base_operand& operand) const {
   if (operand.is_cb()) {
      Cb_operand& r = (Cb_operand&)operand ;
      if ((id_rep == r.id_rep) && (d_type == r.d_type) &&
	  physical_file == r.physical_file) {
	 return true ;
      }
   }
   return false ;
}

bool Cb_operand::is_lit() const { return true;}
bool Cb_operand::is_cb() const { return true;}

int Cb_operand::id() const { return id_rep;}

void Cb_operand::set_id(int new_id)
{
   id_rep = new_id;
}

Data_type Cb_operand::data_type() const {return d_type;}
void Cb_operand::set_data_type(Data_type t) {d_type = t;}

void Cb_operand::bind_physical_file(eString phys_file)
{
  if(physical_file != (eString)"")
    El_punt("Cb_operand: already bound!");

  physical_file = phys_file;
}

void Cb_operand::unbind_physical_file()
{
  physical_file = "";
}

eString Cb_operand::physical_file_type() const
{
  return physical_file;
}

bool Cb_operand::assigned_to_physical_file() const
{
  if(physical_file != "")
    return true;
  return false;
}

int Cb_operand::hash() const { return id_rep ; }

void Cb_operand::print(ostream& os) const
{
    os << "CB:" << id_rep;
}


/* ---------- Undefined class */

Undefined::Undefined() {}
Undefined::Undefined(const Undefined&) {}

Base_operand* Undefined::clone() const{
  return (new Undefined(*this));
}

Undefined::~Undefined() {}

Undefined& Undefined::operator=(const Undefined&) { return *this;}

bool Undefined::operator==(const Base_operand& operand) const {
  return (operand.is_undefined() ? true : false);
}

bool Undefined::same_operand_class(const Base_operand& oprnd) const
{
   return(oprnd.is_undefined()) ;
}

bool Undefined::is_undefined() const {return true;}

bool Undefined::is_identical(const Base_operand& operand) const {
   return(operand.is_undefined()) ;
}

int Undefined::hash() const { return (1) ;} 

void Undefined::print(ostream& os) const {
  os << "undefined?";
}

////////////////////////////////////////////////////////////////////////////
//  Operand class  :  An envelope for Base_operand
////////////////////////////////////////////////////////////////////////////

Operand::Operand()
{
   if (undefined_base == NULL) {
      Undefined* tmpu = new Undefined ;
      Symboltable_entry* undefined_op = new Symboltable_entry(tmpu) ;
      global_symbol_table.bind(*undefined_op, tmpu) ;
      undefined_base = &global_symbol_table.value(*undefined_op) ; 
   }
   
   sptr = undefined_base ;
}
Operand::~Operand() 
{
}

Operand::Operand(Base_operand * ptr) // WARNING WARNING WARNING
{
   validate_and_point_to(ptr) ;
}

Operand::Operand(const Operand& op)
   : sptr(op.sptr)
{}

Operand& Operand::operator=(const Operand& op)
{
   sptr = op.sptr ;
   return (*this) ;
} 

// WARNING: This checks only the logical equality of Base_operands
//          For deep structural equality, you must compare the embedded
//          Symboltable_entrys as done for the symbol table.
bool Operand::operator==(const Operand& op) const
{
   Base_operand* bo1 = sptr->optr ;
   Base_operand* bo2 = op.sptr->optr ;
   if (bo1->is_reg() && bo2->is_reg() &&
       (((Reg*)bo1)->allocated() || ((Reg*)bo2)->allocated() ||
	((Reg*)bo1)->is_rotating() || ((Reg*)bo2)->is_rotating())) {
      if (*bo1 == *bo2) return true ;
      else return false ;
   }
   else {
      if (bo1 == bo2) return true ;
      else return false ;
   }
}

bool Operand::operator!=(const Operand& op) const
{
   if (*this == op) return false ;
   else return true ;
} 

bool Operand::operator<(const Operand& oprnd) const
{
   if (sptr < oprnd.sptr) return true ;
   else return false ;
}

bool Operand::same_operand_class(const Operand& oprnd) const
{
   return(sptr->optr->same_operand_class(*(oprnd.sptr->optr))) ;
}
   
bool Operand::is_identical(const Operand& op) const
{
   return(sptr == op.sptr) ;
}
bool Operand::is_undefined() const
{
   return(sptr->optr->is_undefined()) ;
} 
bool Operand::is_reg() const
{
   return(sptr->optr->is_reg()) ;
} 
bool Operand::is_vr_name() const
{
   return(sptr->optr->is_vr_name()) ;
} 
bool Operand::is_mem_vr() const
{
   return(sptr->optr->is_mem_vr()) ;
} 
bool Operand::is_macro_reg() const
{
   return(sptr->optr->is_macro_reg()) ;
} 
bool Operand::is_lit() const
{
   return(sptr->optr->is_lit()) ;
} 
bool Operand::is_int() const
{
   return(sptr->optr->is_int()) ;
} 
bool Operand::is_predicate() const
{
   return(sptr->optr->is_predicate()) ;
} 
bool Operand::is_predicate_true() const
{
   return(sptr->optr->is_predicate_true()) ;
} 
bool Operand::is_predicate_false() const
{
   return(sptr->optr->is_predicate_false()) ;
} 
bool Operand::is_float() const
{
   return(sptr->optr->is_float()) ;
} 
bool Operand::is_double() const
{
   return(sptr->optr->is_double()) ;
} 
bool Operand::is_string() const
{
   return(sptr->optr->is_string()) ;
} 
bool Operand::is_label() const
{
   return(sptr->optr->is_label()) ;
} 
bool Operand::is_cb() const
{
   return(sptr->optr->is_cb()) ;
} 
bool Operand::assigned_to_file() const
{
   return(sptr->optr->assigned_to_file()) ;
} 
bool Operand::allocated() const
{
   return(sptr->optr->allocated()) ;
}
Data_type Operand::data_type() const
{
   return (sptr->optr->data_type()) ;
}
Reg_file Operand::file_type() const
{
   return (sptr->optr->file_type()) ;
}

void Operand::set_data_type(Data_type t)  // 
{
   if (sptr->optr->is_reg()) {
      Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
      new_reg->set_data_type(t) ;
      validate_and_point_to(new_reg) ;
   }
   else if (sptr->optr->is_vr_name()) {
      VR_name* new_vr_name = (VR_name*) ((VR_name*)sptr->optr)->clone() ;
      new_vr_name->set_data_type(t) ;
      validate_and_point_to(new_vr_name) ;
   }
   else if (sptr->optr->is_mem_vr()) {
      assert(0);
   }
   else if (sptr->optr->is_int()) {
      Int_lit* new_int_lit = (Int_lit*) ((Int_lit*)sptr->optr)->clone() ;
      new_int_lit->set_data_type(t) ;
      validate_and_point_to(new_int_lit) ;
   }
   else if (sptr->optr->is_predicate()) {
      Pred_lit* new_pred = (Pred_lit*) ((Pred_lit*)sptr->optr)->clone() ;
      new_pred->set_data_type(t) ;
      validate_and_point_to(new_pred) ;
   }
   else if (sptr->optr->is_float()) {
      Float_lit* new_float = (Float_lit*) ((Float_lit*)sptr->optr)->clone() ;
      new_float->set_data_type(t) ;
      validate_and_point_to(new_float) ;
   }
   else if (sptr->optr->is_double()) {
      Double_lit* new_double = (Double_lit*) ((Double_lit*)sptr->optr)->clone() ;
      new_double->set_data_type(t) ;
      validate_and_point_to(new_double) ;
   }
   else if (sptr->optr->is_string()) {
      String_lit* new_string = (String_lit*) ((String_lit*)sptr->optr)->clone() ;
      new_string->set_data_type(t) ;
      validate_and_point_to(new_string) ;
   }
   else if (sptr->optr->is_label()) {
      Label_lit* new_label = (Label_lit*) ((Label_lit*)sptr->optr)->clone() ;
      new_label->set_data_type(t) ;
      validate_and_point_to(new_label) ;
   }
   else if (sptr->optr->is_cb()) {
      Cb_operand* new_cb = (Cb_operand*) ((Cb_operand*)sptr->optr)->clone() ;
      new_cb->set_data_type(t) ;
      validate_and_point_to(new_cb) ;
   }
   else {
      assert(0);
   }
}


/// Class specific Operand methods

// Reg class

bool Operand::equal_vr(const Operand& op) const
{
   return(((Reg*)sptr->optr)->equal_vr(*op.sptr->optr)) ;
}
bool Operand::equal_mc(const Operand& op) const
{
   return(((Reg*)sptr->optr)->equal_mc(*op.sptr->optr)) ;
}
bool Operand::is_static() const
{
   return(((Reg*)sptr->optr)->is_static()) ;
}
bool Operand::is_rotating() const
{
   return(((Reg*)sptr->optr)->is_rotating()) ;
}
int Operand::mc_num() const
{
   return(((Reg*)sptr->optr)->mc_num()) ;
}
Operand& Operand::bind_file(Reg_file rf, Reg_sr rs) // WARNING WARNING WARNING
{
   Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
   new_reg->bind_file(rf,rs) ;
   validate_and_point_to(new_reg) ;
   return (*this) ;
}
Operand& Operand::bind_reg(int x)  //
{
   Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
   new_reg->bind_reg(x) ;
   validate_and_point_to(new_reg) ;
   return(*this) ;
}
Operand& Operand::unbind_reg() // 
{
   Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
   new_reg->unbind_reg() ;
   validate_and_point_to(new_reg) ;
   return(*this) ;
}

// Reg and Mem_vr class

int Operand::vr_num() const
{
   if(sptr->optr->is_reg()) {
      return(((Reg*)sptr->optr)->vr_num()) ;
   } else if (sptr->optr->is_vr_name()) {
      return(((VR_name*)sptr->optr)->vr_num()) ;
   } else if (sptr->optr->is_mem_vr()) {
      return(((Mem_vr*)sptr->optr)->vr_num()) ;
   } else {
      El_punt("This operand type is not supported for this method") ;
   }
   return (0) ;
}

int Operand::omega() const
{
   if(!(sptr->optr->is_reg() || sptr->optr->is_mem_vr())) {
      El_punt("This operand type is not supported for this method") ;
   }
   return(sptr->optr->omega());
}

int Operand::min_omega() const
{
   if(!(sptr->optr->is_reg() ||
	sptr->optr->is_vr_name() ||
	sptr->optr->is_mem_vr())) {
      El_punt("This operand type is not supported for this method") ;
   }
   if (sptr->optr->is_vr_name()) {
      Operand oprnd(new Reg(*this)) ;
      return(oprnd.min_omega()) ;
   }
   if (omega() == 0) {
      return(sptr->min_omega) ;
   }
   else {
      Operand oprnd(*this) ;
      oprnd.set_omega(0) ;
      return(oprnd.sptr->min_omega) ;
   }
}

int Operand::max_omega() const
{
   if(!(sptr->optr->is_reg() ||
	sptr->optr->is_vr_name() ||
	sptr->optr->is_mem_vr())) {
      El_punt("This operand type is not supported for this method") ;
   }
   if (sptr->optr->is_vr_name()) {
      Operand oprnd(new Reg(*this)) ;
      return(oprnd.max_omega()) ;
   }
   if (omega() == 0) {
      return(sptr->max_omega) ;
   }
   else {
      Operand oprnd(*this) ;
      oprnd.set_omega(0) ;
      return(oprnd.sptr->max_omega) ;
   }
}

Operand& Operand::rename() // WARNING WARNING WARNING
{
   if(sptr->optr->is_reg()) {
      Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
      new_reg->rename() ;
      validate_and_point_to(new_reg) ;
   } else if (sptr->optr->is_mem_vr()) {
      Mem_vr* new_memvr = (Mem_vr*) ((Mem_vr*)sptr->optr)->clone() ;
      new_memvr->rename() ;
      validate_and_point_to(new_memvr) ;
   } else {
      El_punt("This operand type is not supported for this method") ;
   }
   return(*this) ;
}

// added by Sumedh (what are these warnings for?)
Operand& Operand::rename(int newnum) // WARNING WARNING WARNING
{
   if(sptr->optr->is_reg()) {
      Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
      new_reg->rename(newnum) ;
      validate_and_point_to(new_reg) ;
   } else if (sptr->optr->is_mem_vr()) {
      Mem_vr* new_memvr = (Mem_vr*) ((Mem_vr*)sptr->optr)->clone() ;
      new_memvr->rename(newnum) ;
      validate_and_point_to(new_memvr) ;
   } else {
      El_punt("This operand type is not supported for this method") ;
   }
   return(*this) ;
}

Operand& Operand::incr_omega (int incr) // WARNING WARNING WARNING 
{
   if(sptr->optr->is_reg()) {
      Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
      new_reg->incr_omega(incr) ;
      validate_and_point_to(new_reg) ;
   } else if (sptr->optr->is_mem_vr()) {
      Mem_vr* new_memvr = (Mem_vr*) ((Mem_vr*)sptr->optr)->clone() ;
      new_memvr->incr_omega(incr) ;
      validate_and_point_to(new_memvr) ;
   } else {
      El_punt("This operand type is not supported for this method") ;
   }
   return(*this) ;
}
void Operand::set_vr_num(int new_val) // WARNING WARNING WARNING
{
   if(sptr->optr->is_reg()) {
      Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
      new_reg->set_vr_num(new_val) ;
      validate_and_point_to(new_reg) ;
   } else if (sptr->optr->is_mem_vr()) {
      Mem_vr* new_memvr = (Mem_vr*) ((Mem_vr*)sptr->optr)->clone() ;
      new_memvr->set_vr_num(new_val) ;
      validate_and_point_to(new_memvr) ;
   } else if (sptr->optr->is_vr_name()) {
      VR_name* new_vr_name = (VR_name*) ((VR_name*)sptr->optr)->clone() ;
      new_vr_name->set_vr_num(new_val) ;
      validate_and_point_to(new_vr_name) ;
   } else {
      El_punt("This operand type is not supported for this method") ;
   }
}
void Operand::set_omega(int new_val) // WARNING WARNING WARNING 
{
   if(sptr->optr->is_reg()) {
      Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
      new_reg->set_omega(new_val) ;
      validate_and_point_to(new_reg) ;
   } else if (sptr->optr->is_mem_vr()) {
      Mem_vr* new_memvr = (Mem_vr*) ((Mem_vr*)sptr->optr)->clone() ;
      new_memvr->set_omega(new_val) ;
      validate_and_point_to(new_memvr) ;
   } else {
      El_punt("This operand type is not supported for this method") ;
   }
}


bool Operand::is_same_name(const Operand& op) const
{
   if(sptr->optr->is_vr_name()) {
      return (((VR_name*) sptr->optr)->same_name(*op.sptr->optr)) ;
   }
   else {
      El_punt("This operand type is not supported for this method") ;
      return false ;
   }
}

// Macro_reg class functions

Macro_name Operand::name() const
{
   if (!sptr->optr->is_macro_reg()) {
      El_punt("This operand type is not supported for this method") ;
   }
   return(((Macro_reg*)sptr->optr)->name()) ;
}

void Operand::set_name(Macro_name new_val)
{
   if (!sptr->optr->is_macro_reg()) {
      El_punt("This operand type is not supported for this method") ;
   }
   ((Macro_reg*)sptr->optr)->set_name(new_val);
}

bool Operand::is_fragile_macro()
{
   if (!sptr->optr->is_macro_reg()) {
      El_punt("This operand type is not supported for this method") ;
   }
   return(((Macro_reg*)sptr->optr)->is_fragile_macro()) ;
}


int Operand::id() const
{
   if (!sptr->optr->is_cb()) {
      El_punt("This operand type is not supported for this method") ;
   }
   return(((Cb_operand*)sptr->optr)->id()) ;
}

void Operand::set_id(int new_val) // WARNING WARNING WARNING 
{
   if (!sptr->optr->is_cb()) {
      El_punt("This operand type is not supported for this method") ;
   }
   Cb_operand* new_cb = ( Cb_operand*) (( Cb_operand*)sptr->optr)->clone() ;
   new_cb->set_id(new_val) ;
   validate_and_point_to(new_cb) ;
}

// value methods for literal classes

bool Operand::pred_value()
{
   if (!sptr->optr->is_predicate()) {
      El_punt("This operand type is not supported for this method") ;
   }
   return((Pred_lit*)sptr->optr)->value() ;
}

void Operand::set_pred_value(bool new_val) // WARNING WARNING WARNING 
{
   if (!sptr->optr->is_predicate()) {
      El_punt("This operand type is not supported for this method") ;
   }
   Pred_lit* new_lit = (Pred_lit*) ((Pred_lit*)sptr->optr)->clone() ;
   new_lit->set_value(new_val) ;
   validate_and_point_to(new_lit) ;
}

int  Operand::int_value()
{
   return((Int_lit*)sptr->optr)->value() ;
}

void Operand::set_int_value(int new_val) // WARNING WARNING WARNING 
{
   Int_lit* new_lit = (Int_lit*) ((Int_lit*)sptr->optr)->clone() ;
   new_lit->set_value(new_val) ;
   validate_and_point_to(new_lit) ;
}

double Operand::float_value()
{
   return((Float_lit*)sptr->optr)->value() ;
}

void Operand::set_float_value(double new_val) // WARNING WARNING WARNING 
{
   Float_lit* new_lit = (Float_lit*) ((Float_lit*)sptr->optr)->clone() ;
   new_lit->set_value((float)new_val) ;
   validate_and_point_to(new_lit) ;
}

double Operand::double_value()
{
   return((Double_lit*)sptr->optr)->value() ;
}

void Operand::set_double_value(double new_val) // WARNING WARNING WARNING 
{
   Double_lit* new_lit = (Double_lit*) ((Double_lit*)sptr->optr)->clone() ;
   new_lit->set_value(new_val) ;
   validate_and_point_to(new_lit) ;
}

eString Operand::string_value()
{
   return((String_lit*)sptr->optr)->value() ;
}

void Operand::set_string_value(eString new_val) // WARNING WARNING WARNING 
{
   String_lit* new_lit = (String_lit*) ((String_lit*)sptr->optr)->clone() ;
   new_lit->set_value(new_val) ;
   validate_and_point_to(new_lit) ;
}

eString Operand::label_value()
{
   return((Label_lit*)sptr->optr)->value() ;
}

void Operand::set_label_value(eString new_val) // WARNING WARNING WARNING 
{
   Label_lit* new_lit = (Label_lit*) ((Label_lit*)sptr->optr)->clone() ;
   new_lit->set_value(new_val) ;
   validate_and_point_to(new_lit) ;
}

eString Operand::physical_file_type() const
{
  // this is a pure temporary hack -- VK, RCJ, SAG 10/28/97
  // we return a physical file even if the operand is not bound to one.
  if(is_lit()) {
      if (!assigned_to_physical_file()) 
	return MDES_translate_vreg("L");
      if(is_int())
	return ((Int_lit*)sptr->optr)->physical_file_type();
      if(is_float())
	return ((Float_lit*)sptr->optr)->physical_file_type();
      if(is_double())
	return ((Double_lit*)sptr->optr)->physical_file_type();
      if(is_string())
	return ((String_lit*)sptr->optr)->physical_file_type();
      if(is_label())
	return ((Label_lit*)sptr->optr)->physical_file_type();
      if(is_cb())
	return ((Cb_operand*)sptr->optr)->physical_file_type();
    }
  else // !is_lit()
    if (is_reg() || is_macro_reg()) {
      // this is a pure temporary hack -- VK, RCJ, SAG 10/28/97
      // we return a physical file even if the operand is not bound to one.
      if (!assigned_to_physical_file()) {
	return regfile_to_char(file_type());
      } else {
      if (is_reg()) 
	return ((Reg*)sptr->optr)->physical_file_type();
      if (is_macro_reg())
	return ((Macro_reg*)sptr->optr)->physical_file_type();
      }
    }
    else if (is_undefined())
      return MDES_translate_vreg("U");

  // El_punt("Attempt to read physical binding of operand failed.\n");
  return NULL; 
}

void Operand::bind_physical_file(eString phys_file)
{
  if(is_lit())
    {
      if(is_int())
	{
	  Int_lit* new_lit = (Int_lit*) ((Int_lit*)sptr->optr)->clone() ;
	  new_lit->bind_physical_file(phys_file);
	  validate_and_point_to(new_lit);
	  return;
	}
      if(is_float())
	{
	  Float_lit* new_lit = (Float_lit*) ((Float_lit*)sptr->optr)->clone() ;
	  new_lit->bind_physical_file(phys_file);
	  validate_and_point_to(new_lit);
	  return;
	}
      if(is_double())
	{
	  Double_lit* new_lit = (Double_lit*) ((Double_lit*)sptr->optr)->clone() ;
	  new_lit->bind_physical_file(phys_file);
	  validate_and_point_to(new_lit);
	  return;
	}
      if(is_string())
	{
	  String_lit* new_lit =
	    (String_lit*) ((String_lit*)sptr->optr)->clone() ;
	  new_lit->bind_physical_file(phys_file);
	  validate_and_point_to(new_lit);
	  return;
	}
      if(is_label())
	{
	  Label_lit* new_lit =
	    (Label_lit*) ((Label_lit*)sptr->optr)->clone() ;
	  new_lit->bind_physical_file(phys_file);
	  validate_and_point_to(new_lit);
	  return;
	}
      if(is_cb())
	{
	  Cb_operand* new_lit =
	    (Cb_operand*) ((Cb_operand*)sptr->optr)->clone() ;
	  new_lit->bind_physical_file(phys_file);
	  validate_and_point_to(new_lit);
	  return;
	}
    }
  else // !is_lit()
    if(is_reg())
      {
	Reg* new_reg = (Reg*) ((Reg*)sptr->optr)->clone() ;
	new_reg->bind_physical_file(phys_file);
	validate_and_point_to(new_reg);
	return;
      }

  El_punt("Attempt to physically bind operand failed.\n");
}


void Operand::unbind_physical_file()
{
  sptr->optr->unbind_physical_file();
}

bool Operand::assigned_to_physical_file() const
{
  if(is_lit())
    {
      if(is_int())
	return ((Int_lit*)sptr->optr)->assigned_to_physical_file();
      if(is_float())
	return ((Float_lit*)sptr->optr)->assigned_to_physical_file();
      if(is_double())
	return ((Double_lit*)sptr->optr)->assigned_to_physical_file();
      if(is_string())
	return ((String_lit*)sptr->optr)->assigned_to_physical_file();
      if(is_label())
	return ((Label_lit*)sptr->optr)->assigned_to_physical_file();
      if(is_cb())
	return ((Cb_operand*)sptr->optr)->assigned_to_physical_file();
    }
  else // !is_lit()
    if(is_reg())
      return ((Reg*)sptr->optr)->assigned_to_physical_file();

  return false;
}

void Operand::validate_and_point_to(Base_operand* base_ptr)
{
   // Make sure the Symboltable_entry version of base_ptr is in
   // Symbol table. If it is, base_ptr is deleted. Otherwise, it
   // is permanently insered in the global symbol table.

   if (base_ptr == NULL) {
      // first make sure undefined_base was initialized
      if (undefined_base == NULL) {
	 Operand dummy ;
      }
      assert (undefined_base != NULL) ;
      sptr = undefined_base ;
      return ;
   }
   Symboltable_entry oprnd(base_ptr) ;  
   if (!global_symbol_table.is_bound(oprnd)) {
      // New operand in the symbol table. 
      global_symbol_table.bind(oprnd,oprnd.operand_ptr) ;
      sptr = &(global_symbol_table.value(oprnd)) ;

      // Fix min_omega and max_omega
      int new_omega = sptr->optr->omega() ;
      if ( new_omega != 0) {
	 Symboltable_entry dummy0(oprnd) ;

	 // Save the omega so that we restore it right away
	 int old_omega = dummy0.operand_ptr->omega() ;
	 dummy0.operand_ptr->set_omega(0) ;
	 if (!global_symbol_table.is_bound(dummy0)) {
	    Base_operand* entry_base = oprnd.operand_ptr->clone() ;
	    Symboltable_entry entry_operand(entry_base) ;
	    global_symbol_table.bind(entry_operand,entry_operand.operand_ptr) ;
	 }
	 Symbol_table_info& si =  global_symbol_table.value(dummy0) ;
	 if (si.min_omega > new_omega) si.min_omega = new_omega ;
	 if (si.max_omega < new_omega) si.max_omega = new_omega ;

	 // restore the omega IMPORTANT
	 dummy0.operand_ptr->set_omega(old_omega) ;
      }	 
   }
   else {
      sptr = &(global_symbol_table.value(oprnd)) ;
      delete (oprnd.operand_ptr) ;
   }
   return ;
}


Hash_map<Symboltable_entry,Symbol_table_info>
        Operand::global_symbol_table(hash_symboltable_entry,100017) ;

Symbol_table_info* Operand::undefined_base = NULL ;

void Operand::init_global_symbol_table()
{
  //   undefined_base = new Undefined ;
  //   Symboltable_entry* undefined_op = new Symboltable_entry(undefined_base) ;
  //   global_symbol_table.bind(*undefined_op, undefined_base) ;
}

void Operand::clear_global_symbol_table()
{
  // First delete all base operands pointed from the table
  // Shail Aditya, Vinod Kathail 08/10/98
  for (Hash_map_iterator<Symboltable_entry,Symbol_table_info> 
	 iter(global_symbol_table); iter!=0; iter++) {
    Symbol_table_info si = (*iter).second;
    delete si.optr;
  }
  global_symbol_table.clear();
  undefined_base = NULL;
}

///////  Output method

//
// Warning !!! Warning !!! Warning !!!
// the operator<< is used for hashing Operands. Since if two operands
// are equal in the operator== sense, they should have the same value,
// operands which are equal in the operator== sense must generate the
// same output string
//


ostream& operator<<(ostream& os, const Operand& operand){
  if (operand.sptr->optr)
    operator<<(os, *operand.sptr->optr);
  else os << "??";
  return os;
}

ostream& operator<<(ostream& os, const Symboltable_entry& operand){
  if (operand.operand_ptr)
    operator<<(os, *operand.operand_ptr);
  else os << "??";
  return os;
}

///////////////////////////////////////////////////////////////////

unsigned hash_operand(Operand& oprnd)
{
   if (oprnd.is_reg()) {
      if (oprnd.allocated()) {
	 return (oprnd.mc_num()) ;
      }
      else {
	 return (ELCOR_INT_ABS(oprnd.vr_num() + oprnd.omega())) ;
      }
   }
   else {
      return (ELCOR_INT_HASH(oprnd.get_ptr())) ;
   }
//      char p[16384] ;
//      ostrstream ost(p,16384) ;
//      ost << oprnd << '\0';
//      char* tmp_c = &(p[0]) ;
//      return (hash_char_ptr(tmp_c)) ;
}

///////////////////////////////////////////////////////////////////

unsigned hash_symboltable_entry(Symboltable_entry& oprnd)
{
   return (ELCOR_INT_HASH(oprnd.operand_ptr->hash())) ;
//   ostrstream ost(p,16384) ;
//   ost << oprnd << '\0';
//   char* tmp_c = &(p[0]) ;
//   return (hash_char_ptr(tmp_c)) ;
}

// Debug parameters

Operand* oper1 = NULL ;
Operand* oper2 = NULL ;
Operand* oper3 = NULL ;

// end of operand.cpp
