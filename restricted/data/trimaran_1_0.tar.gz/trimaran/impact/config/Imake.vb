/*
 *	Imake.tmpl
 */

/*
 *	Vendor files provide a way to automate the assignment of
 *	variables which are platform-specific.  By placing each 
 *	platforms' variable assignments in its own file, the template
 *	must only name the correct file in order to set all of a 
 *	platform's variables properly.
 *
 *	The problem then becomes how to name the proper vendor file.
 *	This is accomplished by checking for a defined symbol 
 *	characteristic of the given platform.  Based on that defined
 *	symbol, which is usually defined by the preprocessor, the 
 *	name of the vendor file can be set.
 *
 *	Below are the vendor blocks which define which vendor file to 
 *	use.  We also take the opportunity here, while we have 
 *	determined the platform, to define (and undefine) several 
 *	other variables to ensure proper execution throughout other
 *	portions of the build process.
 *
 *	We undefine all of the preprocessor-defined, platform-
 *	specific variables (hpux, hppa, sun, sparc, linux, etc.) so
 *	that the appearance of these tokens (for example, in file
 *	names) will not produce unexpected, difficult-to-track 
 *	results.  We define one of the symbols HPArchitecture, 
 *	SunArchitecture, LinuxArchitecture, or OtherArchitecture so 
 *	that we may record the type of machine with which we are 
 *	working even as we may create makefiles for other platforms 
 *	or need the more traditional symbols (like hpux, hppa, 
 *	or sun) for other uses.
 */

/*	NEW_ARCHITECTURE--add a block following other examples  
 *	(The first symbol is a system-unique symbol, usually defined
 *	by the preprocessor, by which the architecture type can be
 *	determined.  Then undef any symbols which might cause a problem
 *	by being used later on.  And define a make variable to refer 
 *	to later.  
 */
#if defined(hpux)
#   define VendorFile <hp.cf>
#   undef hpux
#   undef hppa
#   undef sun
#   undef sparc
#   undef linux
#   undef WIN32
#elif defined(sun)
#   define VendorFile <sun.cf>
#   undef hpux
#   undef hppa
#   undef sun
#   undef sparc
#   undef linux
#   undef WIN32
#elif defined(linux)
#   define VendorFile <linux.cf>
#   undef hpux
#   undef hppa
#   undef sun
#   undef sparc
#   undef linux
#   undef WIN32
#elif defined(WIN32)
#   define VendorFile <win32.cf>
#   undef hpux
#   undef hppa
#   undef sun
#   undef sparc
#   undef linux
#   undef WIN32
#else
#   define VendorFile <other.cf>
#   undef hpux
#   undef hppa
#   undef sun
#   undef sparc
#   undef linux
#   undef WIN32
#endif
