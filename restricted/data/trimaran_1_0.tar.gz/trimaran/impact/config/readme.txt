MYVPATH:
If you wish to add your own, user-specific directories to the search path, define MYVPATH in your environment to be a space separated list of those directories which you wish to have added.  MYVPATH is inserted into VPATH by the following line which can be found in Imake.params:
VPATH = $(LLIB_DIR) $(OBJ_DIR) $(OBJVPATH) $(MYVPATH) $(IMPACT_LIB_PATH)
Order is important within VPATH.  Directories are searched in the order listed.

IMPACT_ROOT:
The variable IMPACT_ROOT should be defined in your environment.  It is used to locate directories like the install directories, $(IMPACT_ROOT)/bin or $(IMPACT_ROOT)/lib, and include directories, $(IMPACT_ROOT)/include.  If it is not defined in your environment, the build environment will attempt to deduce it value.  It does so by examining your current path.  It traces back along that path until it finds the first occurence of the token 'impact' at the end of a directory name.  It then discards every after that token and assigns it to IMPACT_ROOT.  If your current directory contains no such occurence of 'impact,' IMPACT_ROOT will be null and compilation will fail.
Examples of the default conversion (if variable is not defined in environment):
/home/impact/release/ --> /home/impact/release
/home/impact/release/impact/ --> /home/impact/release/impact
/home/impact/release/impact.old/ --> /home/impact
/home/impact/release/old.impact/ --> /home/impact/release/old.impact
/home/impact.old/release/ --> <null>

CC:
CC, the variable which provides preferred compiler and options, is taken from the user's current environment settings.  If it is not defined in the environment, it defaults to a value of 'gcc -Wall.'




