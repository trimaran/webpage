/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/*****************************************************************************\
 *      File:   dd_data-dep.h
 *      Author: Grant Haab and Wen-mei Hwu
\*****************************************************************************/


#ifndef DD_DATA_DEP_H
#define DD_DATA_DEP_H

#include <Pcode/impact_global.h>
#include <Pcode/pcode.h>
#include <Pcode/dd_portable.h>
#include <Pcode/dd_affine.h>
#include <Pcode/dd_dir.h>
#include <Pcode/dd_extra.h>
#include <Pcode/flow.h>
#include <library/graph.h>

/* #define DEBUG_DD_DATA-DEP */

/* define the maximum length of a data dependence vector */

#define maxCommonNest 6 /* (32 bits - 6 used in dd_dir.h) / 4 bits per dd */

/******************************************************************************
 Data Structures and Function Declarations used internally by Dep. Analysis.
 ******************************************************************************/

/* global vars and funcs */
extern char *ddtypename[];
extern struct ddnode *NewDDNode();

typedef struct {
    uint nest;
    bool distanceKnown[maxCommonNest+1];
    int  distance[maxCommonNest+1];
} dist_info;

/* all info about dependence, as used by findDirectionVector,
   and read by noteDependence */

typedef struct {
    dddirection  direction;
    dddirection  restraint;
    dist_info *dist;
} dir_and_dist_info;

typedef void *if_context;               /* Not implemented */

/* This should be attached to the extension field of the ParLoop Stmt */
typedef struct _loop_context {
        Stmt loop_stmt;                 /* Pcode loop statement */
        affine_expr *init_affexpr;      /* Initial affine expression */
        affine_expr *final_affexpr;     /* Final affine expression */
} _loop_context, *loop_context;

typedef _loop_context _DDParLoopStmtExt;
typedef loop_context DDParLoopStmtExt;


/******************************************************************************
 Data Structures used to access the dependence graph using the variable access
 table. (Some fields used internally by Dep. Analysis.)
 ******************************************************************************/

/* array of distances of length ddnest+1 (defined below) */
typedef sint *DDdistance;  

/* 
 * these types must be in the same order as the corresponding type names in
 * the declaration of ddtypename in the .c file 
 */

typedef enum ddnature {
    ddnone,
    ddflow,
    ddanti,
    ddoutput,
    ddinput
} ddnature;

#define get_ddtype_name(ddnature)	(ddtypename[(uint)(ddnature)])

/*
 * Contains information for a single dependence in the dependence graph.
 * See dd_dir.h for information about the direction vector and access macros.
 * Each ddnode is attached to a predecessor and successor a_access node.
 */
typedef struct ddnode {
    ddnature ddtype;    	/* flow, anti, output, input, etc. */

    struct _a_access *ddpred, *ddsucc;	/* Predecessor and Successor accesses */
					/* in the dependence graph */

    struct ddnode *ddnextpred; 	/* Dependence node with next predecessor */
				/* access and same successor access */

    struct ddnode *ddnextsucc;  /* Dependence node with next successor access */
				/* and same predecessor access */

    struct ddnode *ddlink;      /* chain of saved dependence arcs (internal) */

    uint ddnest;		/* number of common loops for dependence = */
				/* length of dddir and dddist vectors */

    dddirection ddrestraint;    /* restraint vector 3/29/92 davew@cs.umd.edu */
				/* used internally by Omega */

    dddirection dddir;	/* direction vector, (see dd_dir.h) */

    DDdistance dddist;	/* array of dependence distances (iteration variable  */
			/* differences, not in terms of loop iterations!)     */
			/* size of array is ddnest+1, first element not used. */
			/* value is ddunknown if distance is not constant or  */
			/* cannot be determined exactly. 		      */

    uint32 ddextra;	/* used for tagging dependences for transformations,  */
			/* (see dd_extra.h) 				      */

    uint32 ddthreshold;	/* dependence distance in LOOP ITERATIONS for the     */
			/* loop which carries the dependence.  Value is       */			/* ddunknown if corresponding element in dddist       */
			/* vector is ddunknown.  Value is zero if dependence  */
			/* is not loop carried.				      */
} ddnode;


/******************************************************************************
  Utility Functions (for debugging and other modules) 
*******************************************************************************/

#include <Pcode/dd_acc-tbl.h>
#include <Pcode/depend.h>

/* used internally! */
extern void RemoveDDGraph(FuncDepend fd);

/* Print Dependence information for single dependence to output file */
extern void DD_Print_Single_Dependence(FILE *file, ddnode *ddn);

/* Print Dependence information for given variable to output file */
extern void DD_Print_Var_Dependences(FILE *file, DDSymEntry sym_entry);

/* Print all Dependence information for the given function to output file */
extern void DD_Print_All_Dependences(FILE *file, FuncDcl func);

/* Check whether function name is a Min function */
extern bool Is_Min_Func_Name(char *func_name);

/* Check whether function name is a Max function */
extern bool Is_Max_Func_Name(char *func_name);

/* Check whether function name is a Min or Max function */
extern bool Is_MinMax_Func_Name(char *func_name);

/* Check whether function call is a Min or Max function */
extern bool Is_MinMax_Func_Call(Expr call_expr);

/* Check whether access a1 precedes access a2 without iterating their common
   parloop */
extern bool DD_Access_Precedes_Within_Common_Loop(a_access a1, a_access a2,
						  ddnature dt);


/******************************************************************************
  External Functions (for transformations and optimizations) 
*******************************************************************************/

/* Build Dependence Analysis for all function-level loopnests */
/* THIS IS NO LONGER SUPPORTED, MUST CALC DEPENDENCE INFO FOR ENTIRE FUNCTION */
/*extern void DD_Build_LoopNests( FuncDcl func ); */

/* 
 * Build Dependence Analysis graph for a function:
 *
 * Calculates all flow, output, and anit-dependences for scalars and arrays.  
 * Includes dependences between possibly aliased variables including globals 
 * and function call variable names.  Currently does not create dependences
 * between function parameters since the Fortran spec prohibits aliasing
 * of formal parameters.
 *
 * CURRENTLY, ONLY FUNCTIONS THAT ARE GENERATED USING F2C ARE SUPPORTED! <----
 * Two checks are made before calculating data dependence.  First, a check
 * is made to see if f2c.h has been included in the current file.  If not,
 * this function returns the value FALSE.  The access table is unusable in 
 * this case.  Similarly, if a pragma with specifier "FN not f2c" is present 
 * for the function, then FALSE is returned.  This allows one to skip 
 * dependence analysis of C functions added to the end of a file generated 
 * by f2c.  
 *
 * IF YOU RUN DATA DEPENDENCE ON A C FUNCTION, THE COMPILER WILL MOST LIKELY
 * PUNT.  IF IT DOES NOT, THE RESULTS WILL ALMOST CERTAINLY BE INVALID.
 *
 * Currently, inter-loopnest and top-level dependences are not supported.
 * Please come and talk to me if you want them for some reason.
 * 
 * Returns whether or not the access table and dependence graph could be 
 * generated.
 * If data dependence could not be calculated due to unsupported input,
 * returns value of FALSE, which indicates no access table was created.
 *
 * This function creates an access table if it is not already present
 * and stores index of the table in the depend field of a FuncDcl structure.
 * The access table contains entries of type DDSymEntry, one for each
 * distinct variable in the program.   
 *
 * WHENEVER ACCESSES ARE MODIFIED ANYWHERE IN THE FUNCTION BY A TRANSFORMATION,
 * ONE OF TWO THINGS MUST BE DONE TO LEAVE THE DEPENDENCE INFORMATION IN A 
 * CONSISTENT STATE:
 * 
 * 1) After program modification, DD_Free_Access_Table() can be called to
 *    free the invalid data dependence information and access table.
 *
 * 2) After program modification, call DD_Free_Access_Table() followed by
 *    DD_Build_Data_Dependence_Func() in order to rebuild the dependence
 *    information.
 *
 * Option 1) is recommended since the philosophy I've chosen for transformation
 * code which uses dependence info is:  Build the info that you need, and 
 * destroy anything that is inconsistent before exit.
 *
 * An example calling code for dependence analysis for a transformation that 
 * is to be applied to a function is as follows:
 *
 *   if (!DD_Function_Has_Data_Dependence(func) &&
 *      (!DD_Build_Data_Dependence_Func(func))) {
 *
 *        if (debug_yes || verbose_yes) {
 *            fprintf(Flog,
 *                    "___ NOT performed on fn (%s) due to lack of datadep info.\n",
 *                    func->name);
 *        }
 *        return;  / * exit transformation * /
 *    }
 *
 * Note that the transformation writer needs to check whether the dependence
 * analysis failed (because of Non-F2c code) and print the appropriate error
 * message (substitute transformation name for "___").
 *
 * Dependences (_ddnode structures) are connected to _a_access structures which  * are connected to _DDSymType structures which are in turn connected to 
 * _DDSymEntry structures, which are found in the access table.
 *
 * Use C_forall() in library/libc/c_symbol.h along with the access 
 * table index in func->depend->acc_tbl to iterate through all the variables
 * in the access table.  
 *
 * There are pointers both from accesses in the access table to pcode var
 * expressions (var_expr field in a_access structure) and from the var 
 * expressions back to the accesses (acc field of Expr structure).
 *
 * See Build_Statement_Dependence_Graph and Copy_Dependences_To_Stmt_Graph in
 * Ploop/distribution.c for an example of use of the dependence graph.
 *
 * The Pcode parameter do_dependence=yes will run the data dependence analysis
 * once per function even if no transformations are specified.  This should
 * be used mainly to test the dependence analysis.
 */

extern bool DD_Build_Data_Dependence_Func(FuncDcl func);

/*
 * Returns whether or not scalar and array data dependence information is
 * present for function.  Use this before calling
 * DD_Build_Data_Dependence_Func() to make sure redundant computation is
 * avoided.
 */
extern bool DD_Function_Has_Data_Dependence(FuncDcl func);

/* 
 * Expand Min and Max macros for entire function: 
 *
 * Should be called before Hcode generation to convert min() or max() functions
 * to equivalent expressions.  F2c.h has been modified so that it does not
 * define macros to expand these functions during preprocessing.  This 
 * function expands them after the Pcode transformations are complete.
 */

extern void DD_Expand_MinMax_Func(FuncDcl func);
extern void DD_generate_sync_arcs(FuncDcl func);

#endif
