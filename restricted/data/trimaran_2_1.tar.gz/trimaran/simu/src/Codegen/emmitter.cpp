/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:     emmitter.cpp
// Author:   Marc Saint
// Modified: Rodric M. Rabbah
///////////////////////////////////////////////////////////////////////////////

#include "emmitter.h"

static const char LEFT_BRACE  = '{';
static const char RIGHT_BRACE = '}';
static const char COMMA       = ',';
static const char SEMICOLON   = ';';


inline char* mprint(const eString& str) 
{
  if (str != null_string) {
    return (char*) str;
  }
  else return "0x0";
}

inline char* mprintr(const eString& str) 
{
  static char output_buffer[100];

  if (str != null_string) {
    sprintf(output_buffer, "(unsigned int*) &%s", (char*) str);

    return output_buffer;
  }
  else return "0x0";
}


// Prints one table entry in the format of an
// initializer for a struct PD_OP that is part
// the initialization of an array of PD_OP.
void print_elaborate(const OpEntry& op, streamBuffer* out)
{
  static int i;

  /* open op brace */
  (* out) << TAB << LEFT_BRACE << endl;

  /* op id */
  (* out) << TAB << SPACE << SPACE 
	  << "/* initializing op id, type and misc fields */" << endl;
    
  (* out) << TAB   << SPACE << SPACE 
	  << op.id << COMMA << endl;
    
  /* op implementation */
  (* out) << endl
	  << TAB << SPACE << SPACE 
	  << "/* operation implementation ports */" << endl;

  (* out) << TAB << SPACE << SPACE << mprint(op.op) 
	  << COMMA << endl;
  
  /* sources */
  (* out) << endl
	  << TAB << SPACE << SPACE 
	  << "/* initializing source ports */" << SPACE << LEFT_BRACE << endl
	  << TAB;
  
  for (i = 0; i < MAX_SRC; i++) {
    (* out) << SPACE << LEFT_BRACE
	    << mprint(op.src[i].file) << COMMA
	    << op.src[i].num          << COMMA
	    << mprintr(op.src[i].rot) << COMMA
	    << op.src[i].is_reg
	    << RIGHT_BRACE;
    
    if (i < MAX_SRC-1) (* out) << COMMA << endl << TAB;
  }
  
  (* out) << endl << TAB << SPACE << SPACE << RIGHT_BRACE << COMMA << endl;
  
  /* destinations */
  (* out) << endl
	  << TAB << SPACE << SPACE 
	  << "/* initializing destination ports */" << SPACE << LEFT_BRACE 
	  << endl << TAB;
  
  for (i = 0; i < MAX_DEST; i++) {
    (* out) << SPACE << LEFT_BRACE
	    << mprint(op.dest[i].file) << COMMA
	    << op.dest[i].num          << COMMA
	    << mprintr(op.dest[i].rot) << COMMA
	    << op.dest[i].is_reg
	    << RIGHT_BRACE;
    
    if (i < MAX_DEST-1) (* out) << COMMA << endl << TAB;
  }

  (* out) << endl << TAB << SPACE << SPACE << RIGHT_BRACE << COMMA << endl;
  
  /* predicate */
  (* out) << endl
	  << TAB << SPACE << SPACE 
	  << "/* initializing predicate port */" << endl;
  
  (* out) << TAB << SPACE << SPACE 
	  << LEFT_BRACE 
	  << mprint(op.pred.file)  << COMMA 
	  << op.pred.num           << COMMA 
	  << mprintr(op.pred.rot)  << COMMA
	  << op.pred.is_reg    
	  << RIGHT_BRACE          
	  << COMMA << endl;
  
  /* latencies */
  (* out) << endl
	  << TAB << SPACE << SPACE 
	  << "/* initializing op latencies */" << endl;
  
  (* out) << TAB << SPACE << SPACE << LEFT_BRACE;
  
  for (i = 0; i < MAX_DEST; i++) {
    (* out) << op.lat[i];
    
    if (i < MAX_DEST-1) (* out) << COMMA;
  }

  (* out) << RIGHT_BRACE << COMMA << endl;

  /* print type, and others */
  (* out) << endl
	  << TAB << SPACE << SPACE 
	  << "/* initializing type and misc fields */" << endl;

  (* out) << TAB << SPACE << SPACE
	  << mprint(op.type) << COMMA << SPACE 
	  << op.predicated   << COMMA << SPACE
	  << op.speculative  << COMMA << SPACE
	  << op.mask
	  << endl;

  /* close op brace */
  (* out) << TAB << RIGHT_BRACE;
}


// Prints one table entry in the format of an
// initializer for a struct PD_OP that is part
// the initialization of an array of PD_OP.
void print(const OpEntry& op, streamBuffer* out)
{
  static int i;

  /* open op brace */
  (* out) << TAB << LEFT_BRACE;

  /* op id */
  (* out) << op.id << COMMA << SPACE;

  /* op implementation */
  (* out) << mprint(op.op) << COMMA << SPACE;

  /* sources */
  (* out) << LEFT_BRACE;

  for (i = 0; i < MAX_SRC; i++) {
    (* out) << SPACE << LEFT_BRACE
	    << mprint(op.src[i].file) << COMMA
	    << op.src[i].num          << COMMA
	    << mprintr(op.src[i].rot) << COMMA
	    << op.src[i].is_reg
	    << RIGHT_BRACE;

    if (i < MAX_SRC-1) (* out) << COMMA;
  }

  (* out) << SPACE << RIGHT_BRACE << COMMA;

  /* destinations */
  (* out) << LEFT_BRACE;
    
  for (i = 0; i < MAX_DEST; i++) {
    (* out) << SPACE << LEFT_BRACE
	    << mprint(op.dest[i].file) << COMMA
	    << op.dest[i].num          << COMMA
	    << mprintr(op.dest[i].rot) << COMMA
	    << op.dest[i].is_reg
	    << RIGHT_BRACE;

    if (i < MAX_DEST-1) (* out) << COMMA;
  }
    
  (* out) << SPACE << RIGHT_BRACE << COMMA;
       
  /* predicate */
  (* out) << LEFT_BRACE 
	  << mprint(op.pred.file) << COMMA 
	  << op.pred.num          << COMMA 
	  << mprintr(op.pred.rot) << COMMA 
	  << op.pred.is_reg
	  << RIGHT_BRACE  
	  << COMMA;

  /* latencies */
  (* out) << LEFT_BRACE;

  for (i = 0; i < MAX_DEST-1; i++) {
    (* out) << op.lat[i] << COMMA;
  }
  (* out) << op.lat[i];

  (* out) << RIGHT_BRACE << COMMA;

  /* print type, and others */
  (* out) << mprint(op.type) 
	  << COMMA << op.predicated 
	  << COMMA << op.speculative
	  << COMMA << op.mask;

  /* close op brace */
  (* out) << RIGHT_BRACE;
}


// Prints the entire contents of the current table
// to outf in the format of a an initializer of a global
// array of struct PD_OP.
void print_table(const Vector<OpEntry*>& table, int count, streamBuffer* out)
{
  int i;
    
  eString tbl_name = table[0]->attribute;

  (* out) << endl << endl 
	  << "__PD_OP __PD_tbl" << tbl_name << "[" << count << "] " 
	  << EQUALS << endl;
    
  (* out) << LEFT_BRACE << endl;

  for (i = 0; i < count-1; i++) {
    print(*table[i], out);
    // print_elaborate(*table[i], out);

    (* out) << COMMA << endl;
  }
  print(*table[i], out);

  (* out) << endl << RIGHT_BRACE << SEMICOLON << endl << endl;
}
