/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   simu_el_processor.cpp
// Author: Rodric M. Rabbah, Amit Nene
///////////////////////////////////////////////////////////////////////////////

#include "simu.h"
#include "simu_el_processor.h"
#include "streamBuffer.h"

#include <unistd.h>
#include "ir_reader.h"
#include "mdes.h"
#include "intf.h"

#include "el_io.h"
#include "el_data.h"
#include "region_purge.h"
#include "attributes.h"
#include "ir_attribute.h"

#include "op.h"
#include "iterators.h"
#include "regtochar.h"


static const int INITIAL_OP_COUNT    = 50000;
static const int INITIAL_LABEL_COUNT = 100;
static const int SIZE = 1000;

static const char* PD_START_PROCEDURE_STRING = "__PD_start_procedure";
static const char* PD_START_COMPOUND_STRING  = "__PD_start_compound";
static const char* PD_PSEUDO = "__PD_pseudo";
static const char* PD_ACLOCK_STRING = "__PD_aclock";
static const char* PD_PRED_TRUE_STRING = "__PD_PRED_T";
static const char* PD_EPILOGUE_STRING = " __PD_epilogue";
static const char* PD_PROLOGUE_STRING = " __PD_prologue";
static const char* PD_BLACK_HOLE_STRING = "__PD_BLACK_HOLE";
static const char* ADDRESS_OF_LABEL_STRING = "(__PD_REG *)&";
static const char* PD_REG_PTR_STRING = "(__PD_REG *)";
static const char* GCC_VARARG_WORKAROUND = "__PD_VAR";
static const char* SL_WORKAROUND  = "__PD_SL_";
static const char* SETJMP_STRING  = "setjmp";
static const char* LONGJMP_STRING = "longjmp";
static const char* ROTATING_REGISTER_FILE_STRING = "_ROT";
static const char* ROTATING_REGISTER_FILE_SIZE_STRING = "_R_SIZE";

static const char LEFT_BRACE  = '{';
static const char RIGHT_BRACE = '}';
static const char COMMA       = ',';
static const char SEMICOLON   = ';';


// Set of simulator parameters used
extern int El_nual_equals;
extern int El_unscheduled;
extern int El_virtual_regs;
extern int El_performance_monitoring;

// writes out external variables
extern void write_externals(streamBuffer*, const Hash_table<eString>&, 
			   enum EXTERN_TYPE);

// write out function prototypes
extern void  gen_prototypes(streamBuffer*);

extern void parse_info_string(char *raw_info_string, hc_aggregate& fn);
extern void extract_struct_or_union_info(char* raw_call_info);

// normalize the input file name and converts it to a sequencing id
// used for creating a unique function that initializes global data
extern void normalize(eString& src, eString& dest);

// List of all global_data_labels collected during data section processing
// the members of this list will be declared as externs for program 
// initialization
extern Hash_table<eString> global_data_labels;

// List of all function prototypes encountered in the file being processed
Hash_map<eString, hc_aggregate*> prototypes_table(hash_estring, SIZE);

// binds the call_info string to a aggrefate function declaration entry
// currently its information is not used, instead, encountered_call_info
// has replaced its functionality
Hash_map<eString, hc_aggregate*> stored_call_info(hash_estring, SIZE);
Hash_table<eString> encountered_call_info(hash_estring, SIZE);

// binds the call_info string to a integer value
Hash_map<eString, int> call_info_map(hash_estring, SIZE);

// binds the op id of the entry operation to the offset index in the 
// emulation table
Hash_map<int, int> jump_table_map(hash_int, SIZE);

// List of wrapper function candidates
// Wrappers generated for all functions implemented in Rebel file
Hash_table<eString> wrappers(hash_estring, SIZE);

// List of vector function candidates
// Vectors generated for all functions called from Rebel file
Hash_table<eString> vectors(hash_estring, SIZE);

// list of all labels encountered in the current file
Hash_table<eString> extern_functions(hash_estring, SIZE);
Hash_table<eString> extern_data_labels(hash_estring, SIZE);

// list of all structs/unions encountered in the current file
Hash_table<eString> extern_struct_or_union_defs_table(hash_estring, SIZE);
Hash_table<eString> global_struct_or_union_defs_table(hash_estring, SIZE);


// set up streams
el_Buffer::el_Buffer(eString& el_file_name,
		     ofstream& tbls_outbuf, ofstream& inc_outbuf)
{
  // initialize member fields
  Rebel_path_name = el_file_name;   // store the file name

  normalize(el_file_name, sequencing_id);

  // constant null emulation table entry
  NULL_OpEntry = (OpEntry*) NULL;

  // procedure emmitter counters
  cur_proc = NULL;
  opcount = subregion_count = cbl_count = 0;

  // jump table emmitter flag, statistics buffer and register infromation
  // buffer initializer flags
  print_jump_tables = false;
  print_stats_buffer = false;
  print_register_information = false;

  // global data initialization emmitter flag
  initialize_global_data = false;

  // create all the streams used by this class
    
  // used to write out data, goes into header file
  data_outbuf        = new streamBuffer(inc_outbuf);

  datajmptbls_outbuf = new streamBuffer(inc_outbuf);
  datastats_outbuf   = new streamBuffer(inc_outbuf);
  datareg_outbuf     = new streamBuffer(inc_outbuf);

  // used to write out global data initialization
  datainit_outbuf    = new streamBuffer(inc_outbuf);

  // Per procedure you require the following streams
  emulation_tables_outbuf  = new streamBuffer(tbls_outbuf);

  // initialize the emulation table
  emulation_table.reshape(INITIAL_OP_COUNT, NULL_OpEntry);
  emulation_table[0] = new OpEntry;

  control_block_label.reshape(INITIAL_LABEL_COUNT);
}


// Top level driver
bool el_Buffer::gen_code(eString& id, Host_Info& host_info) 
{
  S_log("Writing simulation tables...");

  EL_IN_STREAM = new IR_instream(Rebel_path_name);
   
  // Right now one region(data / _proc) is read, processed and written out in
  // low-level C form
  while (ir_read(*EL_IN_STREAM) != EL_INPUT_EOF) {
    process_input();
  }

  // commit global data declaration
  data_outbuf->commit();

  // write out "extern" global data
  // this call has to be called once the Rebel data sections have
  // been processed
  sprintf(output_buffer, "\n\n%s\n%s\n%s\n\n", 
	  "/*******************************************************/",
	  "/************ External Varaiable Encountered ***********/",
	  "/*******************************************************/");    
  (*data_outbuf) << output_buffer;

  write_externals(data_outbuf, extern_data_labels, IS_DATA);
  write_externals(data_outbuf, extern_struct_or_union_defs_table, IS_SU);

  // write vector/wrapper prototypes to avoid forward references in tables
  // also mark ellipsis functions as a side task
  gen_prototypes(data_outbuf);

  if (print_register_information) {
    sprintf(output_buffer, "\n\n%s\n%s\n%s\n\n", 
	    "/*******************************************************/",
	    "/**************** Register Information *****************/",
	    "/*******************************************************/");
    (*data_outbuf) << output_buffer;

    data_outbuf->commit();
    datareg_outbuf->commit();
  }

  if (print_jump_tables) {
    sprintf(output_buffer, "\n\n%s\n%s\n%s\n\n", 
	    "/*******************************************************/",
	    "/*************** Jump Table Declarations ***************/",
	    "/*******************************************************/");
    (*data_outbuf) << output_buffer;

    data_outbuf->commit();
    datajmptbls_outbuf->commit();
  }

  if (El_performance_monitoring && print_stats_buffer) {
    sprintf(output_buffer, "\n\n%s\n%s\n%s\n\n", 
	    "/*******************************************************/",
	    "/************ Statistic Tracking Structures ************/",
	    "/*******************************************************/");
    (*data_outbuf) << output_buffer;

    data_outbuf->commit();
    datastats_outbuf->commit();
  }

  // commit data initialization buffer
  if (initialize_global_data) {
    sprintf(output_buffer, "\n\n%s\n%s\n%s\n\n",
	    "/*******************************************************/",
	    "/************* Global Data Inititalization *************/",
	    "/*******************************************************/");    
    (*data_outbuf) << output_buffer;

    id = sequencing_id;
    sprintf(output_buffer, "void __PD_initialize_%s_global_data()\n",
	    (char*) sequencing_id);

    (*data_outbuf) << output_buffer << LEFT_BRACE << endl;

    // print out the header and function declaration
    data_outbuf->commit();

    // commit the data initialization code
    datainit_outbuf->commit();

    // terminate the function
    (*data_outbuf) << endl << RIGHT_BRACE << endl;

    // print to the file
    data_outbuf->commit();
  }

  delete EL_IN_STREAM;

  host_info.platform = host_platform_info.platform;
  return initialize_global_data;
}


// Process one DATA or CODE region at a time
void el_Buffer::process_input(void)
{
  switch (El_input_type) {
  case EL_INPUT_EOF:  // No more input
    break;

  case EL_INPUT_DATA: { // Data token
    El_datalist *D;
	
    // Read data declaration information
    D = (El_datalist *) El_input;
    write_data(D);
	
    // Deallocate the Elcor data 
    delete D;
  } break;
	
  case EL_INPUT_CODE: { // Function text token
    Procedure *R ;
	
    // Read a Rebel procedure
    R = (Procedure *) El_input;
    write_region(R);     
      
    // Deallocate the Elcor procedure
    region_purge(R);
  } break;
	
  default:
    S_punt("process_input: illegal token");
  }
}


// routes a call to the correct region handler
// Not used for the time being
void el_Buffer::write_region(Region *region)
{
  char *str;
  
  if(region->is_op())
    write_op(region);
  
  else if(region->is_bb())
    write_bb(region);

  else if(region->is_procedure())
    write_procedure(region);

  else if(region->is_hb())
    write_hb(region);
  
  else if(region->is_loopbody())
    write_loopbody(region);
  
  else if(region->is_loop()) {
    str = (char*)"loop";
    S_warn("Cannot handle %s %d yet", str, region->id());
    return;
  }

  else if(region->is_tree()) {
    str = (char*)"tree";
    S_warn("Cannot handle %s %d yet", str, region->id());
    return;
  }
}


// Writes the code part of the simulator assembly file
// The function does the following:
// - Renames the fuction back to its original name if defined as static
// - Marks the function for wrapper generation
// - Writes out a statistics operation for this procedure
// - Writes out its subregions
void el_Buffer::write_procedure(Region* region)
{
  char* procedure;

  if (region == NULL) 
    return;

  // holds stats related params
  // reset the stats field
  stats.reset();

  // regfile holds register file params
  // reset the register field
  regfile.reset();
    
  // reset opcounts
  clear_emulation_table();
  subregion_count = opcount = cbl_count = 0;
  
  eString procname = ((Procedure *) region)->get_name();

  // the the global current procedure pointer name to the procedure
  // being processed
  cur_proc  = (char*) procname;
  procedure = (char*) procname;

  emulation_table[opcount]->attribute = procname;

  // ignore leading underscore
  if (*procedure == '_') ++procedure;
  procname  = procedure;
  
  S_log("Adding %s to wrappers list!", procedure);
  
  static eString call_info;   // function parameter information from IMPACT
  static hc_aggregate* entry; // new type entry will be added for procedure 
  
  entry = new hc_aggregate;
  get_call_info(region, call_info);
  create_prototype(*entry, procname, call_info);
  append_parameter_attributes(region, *entry);
  
  if (prototypes_table.is_bound(entry->name)) {
    S_punt("procedure %s defined twice in file!", procedure);
  }
  prototypes_table.bind(entry->name, entry);
  wrappers.add_head(prototypes_table.key(procname));

  // will generate an extern declaration for this function for program
  // data initialization
  if (!extern_functions.is_member(procname))
    extern_functions.add_head(procname);

  // reserve the next operation as the stats operation
  int tmp_count;
  if (El_performance_monitoring) {
    tmp_count = opcount;
    opcount++; 
    resize_emulation_table_if_necessary();
    
    // write out the stats data structure
    print_stats_buffer = true;

    (*datastats_outbuf)
      << "struct __PD_stats " << "__PD_stats" << cur_proc
      << "[] = {" << endl;
	
    // write out the PROBE operation (region entry marker)
    write_start_compound(region, tmp_count);
  }
	
  // Next, process all the subregions
  Region *subregion_ptr;
  Compound_region *proc = (Compound_region*) region;
  
  for(subregion_ptr = proc->first_subregion();
      subregion_ptr !=0; 
      subregion_ptr = proc->successor_in_subregion_list(subregion_ptr) ) {  
    // writes out one subregion at a time
    write_region(subregion_ptr);
  }
    
  // write out the elcor jump tables
  if (El_proc_has_jump_tables((Procedure *)region)) {
    print_jump_tables = true;
    write_all_jump_tables((Procedure*) region);
  }
  jump_table_map.clear();
    
  // last entry in the stats field indicating no more region
  // used by emulation library before dumping out DYN_STATS
  if (El_performance_monitoring) {
    sprintf(output_buffer, ",{0}\n}; /* end __PD_stats%s */\n\n", cur_proc);
    (*datastats_outbuf) << output_buffer;
  }
    
  // Write out control block labels
  for (int i = 0; i < cbl_count; i++) {
    (*emulation_tables_outbuf) << control_block_label[i];
  }

  // Write out the stats operations and procedure operations
  print_table(emulation_table, opcount, emulation_tables_outbuf);
  emulation_tables_outbuf->commit();

  // Set the register file size bounds
  // Always choose physical machine set for rotating registers
  get_rotating_physical_regs(regfile);

  print_register_information = true;
  if (!El_virtual_regs) {
    // Physical register parameters need to be written out only once
    static int written = 0;
    if (!written) {
      get_static_physical_regs(regfile);
      
      // write out physcial register info 
      sprintf(output_buffer, "%s[] = {%d,%d,%d,%d,%d,%d,%d,%d,%d};\n\n",
	      "static struct __PD_regfile __PD_reginfo",
	      regfile.gpr_stat_size, regfile.gpr_rot_size, 
	      regfile.fpr_stat_size, regfile.fpr_rot_size,
	      regfile.btr_stat_size,
	      regfile.pr_stat_size,  regfile.pr_rot_size,
	      regfile.cr_stat_size,  regfile.cr_rot_size);
      
      (*datareg_outbuf) << output_buffer;
      
      written = 1;
    }
  }
  
  // if virtual register emulation, write out an entry per procedure
  else {
    // sizes of static regfile is set to one more than the largest register
    // number accessed
    regfile.increment();
    
    sprintf(output_buffer, "%s%s[] = {%d,%d,%d,%d,%d,%d,%d,%d,%d};\n\n",
	    "static struct __PD_regfile __PD_reginfo", cur_proc,
	    regfile.gpr_stat_size, regfile.gpr_rot_size, 
	    regfile.fpr_stat_size, regfile.fpr_rot_size,
	    regfile.btr_stat_size,
	    regfile.pr_stat_size,  regfile.pr_rot_size,
	    regfile.cr_stat_size,  regfile.cr_rot_size);
    
    (*datareg_outbuf) << output_buffer;
  }
}


// Write out the PROBE / Marker operation
void el_Buffer::write_start_compound(Region *region, int &count)
{
  char id[200];
    
  if (region->is_procedure()) {
    sprintf(id,  "%s (%s)", cur_proc, (char *) Rebel_path_name);
  }
  
  else if (region->is_bb()) {
    sprintf(id, "bb %d", region->id());
  }
  
  else if (region->is_hb()) {
    sprintf(id, "hb %d", region->id());
  }
    
  // set the stats struct
  if (subregion_count != 0) (*datastats_outbuf) << ",";
    
  (*datastats_outbuf)
    << "{" 
    << "\"" << id << "\""
    << ","  << stats.sched_len
    << ","  << stats.Static_branch
    << ","  << stats.Static_load
    << ","  << stats.Static_store
    << ","  << stats.Static_ialu
    << ","  << stats.Static_falu
    << ","  << stats.Static_cmpp
    << ","  << stats.Static_pbr
    << ","  << stats.Static_caller_spill
    << ","  << stats.Static_callee_spill
    << ","  << stats.Static_ops
    << ",0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0"
    << "}"  << endl;
  
  if(region->is_procedure()) {
    emulation_table[count]->op   = PD_START_PROCEDURE_STRING;
    sprintf(output_buffer, "%s \"%s\"", PD_REG_PTR_STRING, cur_proc);
    emulation_table[count]->src[0].file = output_buffer;
  }
  
  else {
    emulation_table[count]->op = PD_START_COMPOUND_STRING;
  }

  emulation_table[count]->id   = region->id();  
  emulation_table[count]->type = PD_PSEUDO; 

  if (!El_virtual_regs) {
    emulation_table[count]->mask = true;
  }

  // set the PD_stats field
  sprintf(output_buffer, "%s &__PD_stats%s[%d]", 
	  PD_REG_PTR_STRING, cur_proc, subregion_count);
  emulation_table[count]->src[1].file = output_buffer;
  
  count++;
  resize_emulation_table_if_necessary();
  subregion_count++;
}


// Extracts MDES specific static register file related parameters
void el_Buffer::get_static_physical_regs(PD_regfile& regs)
{
  char *file;
   
  file = regfile_to_char(GPR);
  regs.gpr_stat_size = MDES_reg_static_size(file);
   
  file = regfile_to_char(FPR);
  regs.fpr_stat_size = MDES_reg_static_size(file);

  file = regfile_to_char(PR);
  regs.pr_stat_size = MDES_reg_static_size(file);
   
  file = regfile_to_char(CR);
  regs.cr_stat_size = MDES_reg_static_size(file);
   
  file = regfile_to_char(BTR);
  regs.btr_stat_size = MDES_reg_static_size(file);
}


// Extracts MDES specific rotating register file related parameters
void el_Buffer::get_rotating_physical_regs(PD_regfile& regs)
{
  char *file;
   
  file = regfile_to_char(GPR);
  regs.gpr_rot_size  = MDES_reg_rotating_size(file);
   
  file = regfile_to_char(FPR);
  regs.fpr_rot_size  = MDES_reg_rotating_size(file);

  file = regfile_to_char(PR);
  regs.pr_rot_size  = MDES_reg_rotating_size(file);
   
  file = regfile_to_char(CR);
  regs.cr_rot_size  = MDES_reg_static_size(file);
}


// write out all jump tables defined for a given procedure
void el_Buffer::write_all_jump_tables(Procedure* proc)
{
  El_jumptbl*       tbl;
  El_jumptbl_info*  tbl_info;
  List<El_jumptbl*> tbl_list;
  
  tbl_info = proc->get_jumptbl_info();

  // sanity check
  assert(tbl_info->get_num_tables() >= 0);

  (*datajmptbls_outbuf) 
    << endl << "/** Jump Table for procedure " << cur_proc << " **/" << endl
    << "extern __PD_OP __PD_tbl" << cur_proc << "[];" << endl
    << endl;

  // iterate through the list of jump tables and print them out
  tbl_list = tbl_info->get_tbl_list();
  for (List_iterator<El_jumptbl*> li(tbl_list); li != 0; li++) {
    tbl = *li;
    write_jump_table(*tbl);
    (*datajmptbls_outbuf) << endl;
  }
}


// write out a sing jump table
void el_Buffer::write_jump_table(El_jumptbl &tbl)
{
  int   n_entries, align, reserve, addr;
  char* name;

  n_entries = tbl.get_n_entries();  // number of entries in a table
  align     = tbl.get_align();      // alignment information for table elements
  reserve   = tbl.get_reserve();    // total size of table
  name = (char *) tbl.get_name();   // table name

  assert(align == sizeof(int));     // sanity check, validate assumption

  if(!strncmp(name, "_$_", 3)) name += 3;     

  // declare the tables
  (*datajmptbls_outbuf) << "int " << name << "[" << n_entries << "] = {";
    
  // initialize the table - now defined as an array
  static Op* op;
  for (int i = 0; i < n_entries; i++) {
    addr = i * align;

    op = tbl.get_op_target(i);

    (*datajmptbls_outbuf) << "(int) (&__PD_tbl" << cur_proc << "[" 
			  << jump_table_map.value(op->parent()->id()) << "])";
      
    if (i != n_entries-1) (*datajmptbls_outbuf) << ",";
  }
  (*datajmptbls_outbuf) << "};" << endl;
}


// This function carries out the following:
// - If the control block is marked prolog then, a pseudo operation
//   PD_prologue is written. The operation is supposed to build the
//   activation record on entry into the function.
// - Invokes a call to Simu_write_op per non-pseudo operation in the block.
// - Writes out the special PD_aclock operations on detecting change in
//   scheduling times of operations.
void el_Buffer::write_bb(Region* region)
{
  static char buf[MAX_BUF_SIZE];
  int  region_id = region->id();

  stats.reset();
    
  // bind a label to the block id
  if (cbl_count+1 == control_block_label.dim()) {
    control_block_label.resize(cbl_count*2); // binary expansion
  }

  sprintf(buf, "#define __PD_cb_%s_%d %d\n", cur_proc, region_id, opcount);
  control_block_label[cbl_count++] = buf;

  if (jump_table_map.is_bound(region_id)) {
    S_punt("Block %d doubly encountered in current procedure %s!",
	   region_id, cur_proc);
  }
  else {
    jump_table_map.bind(region_id, opcount);
  }

  // reserve the first operation for stats operation
  int tmp_count;
  if (El_performance_monitoring) {
    tmp_count = opcount;
    opcount++;
    resize_emulation_table_if_necessary();
  }
    
  // Insert special pseudo operations PD_PROLOGUE and PD_EPILOGUE
  // to build the stack frame.
    
  // insert the prologue hack operation
  // epilogue is added before RTS
  if (region->flag(EL_REGION_HAS_PROLOGUE_OP)) {
    el_flag = EL_REGION_HAS_PROLOGUE_OP;

    calc_framesize(region);
    write_prologue();
  }

  else if (region->flag(EL_REGION_HAS_EPILOGUE_OP)) {
    el_flag = EL_REGION_HAS_EPILOGUE_OP;
  }

  else {
    el_flag = EL_REGION_LAST_FLAG;
  }

  // Driver that traverses through all operations in a control block
  int cycle = 0;     
  int time  = 1;
  int flow  = 0;

  for (Region_ops_C0_order iter((Compound_region *) region); *iter; iter++) {
    Region* R = (Region *) *iter;
    Op* op    = (Op *) R;
	
    // if emulating scheduled code add ACLOCKS on changes in scheduling time
    if (!El_unscheduled) {
      time = op->sched_time();
      if (time > cycle) {
	write_aclock(time - cycle);
	cycle = time;
      }

      write_op(R);
    }

    // if emulating unscheduled code write ACLOCKS after every operation
    // clock length = max(latencies of destination operands)
    else {
      write_op(R);

      if (!op->is_pseudo_op()) {
	// compute the max latency
	for(int i = 0, port = int(op->first_dest());
	    port <= int(op->last_dest()); port++, i++) {
	  flow = op->flow_time(DEST, port, IN);
	  if (flow > time) {
	    time = flow;
	  }
	}	  

	write_aclock(time);
	cycle += time;
      }
    }
  }
    
  // one final aclock is required for emulation with scheduling
  if (!El_unscheduled) {
    cycle++;
    write_aclock(1);
  }
    
  // update sched_len field
  // cycle holds the current cycle within a basic block
  stats.sched_len = cycle;
    
  // now write out the basic block entry marker operation
  if (El_performance_monitoring) {
    write_start_compound(region, tmp_count);
  }
}


void el_Buffer::write_loopbody(Region* region)
{
  Compound_region* cregion = (Compound_region *) region;

  // write out subregions
  Region* subregion_ptr = cregion->first_subregion();
  
  while (subregion_ptr != 0) {
    // write the current region
    write_region(subregion_ptr);
    
    // go to the next region
    subregion_ptr = cregion->successor_in_subregion_list(subregion_ptr);
  }
}


void el_Buffer::write_hb(Region* region)
{
  // A Hyperblock is  identical to a basic block in structure(a collection
  // of operations). However, it is a multiple-exit block, but that is not 
  // relevant here
  write_bb(region);
}


// fake operation marking instruction boundaries ACLOCKS appears as
// PD_aclock in the assembly code where src[0]=1,2,3,etc. represents the
// number of clocks that are provided by this operation
void el_Buffer::write_aclock(int clocks)
{
  static int aclock_count = 1;

  emulation_table[opcount]->op   = PD_ACLOCK_STRING;
  emulation_table[opcount]->type = PD_PSEUDO; 
  
  sprintf(output_buffer, "%s %d", PD_REG_PTR_STRING, clocks);
  emulation_table[opcount]->src[0].file = output_buffer;

  sprintf(output_buffer, "%s %d", PD_REG_PTR_STRING, aclock_count);
  emulation_table[opcount]->src[1].file = output_buffer;

  aclock_count++;
  opcount++;
  resize_emulation_table_if_necessary();
}


// Write one HPL-PD operation
// The sequence of actions executed by the function are as follows:
// - Static Information of the operation is collected. That is, it is
//   determined if the operation is a branch, or an ialu, or falu, etc
// - If the operation is an RTS a special PD_epilogue operation to destroy
//   the current activation record is written out
// - Writes all the destination operands
// - The output latencies per operand are also written out
// - Writes all the source operands.
// - Writes the Rebel ID.
// - Writes out the operation name.
void el_Buffer::write_op(Region* region)
{       
  Op *op = (Op *) region;
  
  if (op->is_pseudo_op()) 
    return;

  // update stats
  collect_op_stats(op);
  
  // Prologue/Epilogue operations
  if (op->opcode() == RTS) {
    write_epilogue();
  }
  
  //construct prefix of operation
  eString opname("__PD_");
  opname.cat(el_opcode_to_string_map.value(op->opcode()));
  
  // write the destination operands and their latencies
  write_dest_operands(op);

  // write the source operands
  write_src_operands(op, opname);

  // if this is a BRL operation (function call), then generate a routing
  // vector for the function call
  eString vector_type;
  if ((op->opcode() == BRL) && get_vector_key(op, vector_type)) {
    sprintf(output_buffer, "%s &__PD_vec_%s", 
	    PD_REG_PTR_STRING, (char*) vector_type);

    emulation_table[opcount]->src[2].file = output_buffer;
    
    // will generate a prototype for the vector in the codegen generated
    // header file
    if (!vectors.is_member(vector_type)) {
      vectors.add_head(prototypes_table.key(vector_type));
    }

    opname.cat("_lit");
  }
  
  // write out the guarded predicate
  int predicated = (int) write_pred_operand(op, opname);

  // true when the operation has a guarding predicate
  emulation_table[opcount]->predicated = predicated;
  
  // see if this operation is speculated
  emulation_table[opcount]->speculative = op->is_speculative();
  emulation_table[opcount]->mask = region->flag(EL_OPER_MASK_PE);

  // write out the Rebel id
  emulation_table[opcount]->id = op->id();
   
  // Finally write the operation name
  emulation_table[opcount]->op = opname;
  
  // Increment the index in simulation table
  opcount++;
  resize_emulation_table_if_necessary();
}


// writes out destination operands
void el_Buffer::write_dest_operands(Op *op)
{
  int port, i;
   
  // iterate thru Dest operands
  for (i = 0, port = int(op->first_dest()); port <= int(op->last_dest()); 
       port++, i++) {
    
    Operand& d = (op->dest(Port_num(port)));
    
    // write out the destination operand latency
    // if equals model, latency = latency of operation
    if (El_nual_equals) {
      emulation_table[opcount]->lat[i] = (op->flow_time(DEST, port, IN) -1);
    }
    else {
      // if lte model, latency = 0 (means end of current cycle)
      emulation_table[opcount]->lat[i] = 0; 
    }

    // now write out the operand
    eString iopat("dest");
    write_operand(d, iopat, i);
  }
  
  // If the operation is a branch then use latency of the first unused
  // destination port as the "PC" change latency / Branch latency
  if (is_brl(op) || is_branch(op)) {
    emulation_table[opcount]->lat[i] = 
      MDES_branch_latency(el_opcode_to_string_map.value(op->opcode()))-1;
  }
}


// writes out source operands
void el_Buffer::write_src_operands(Op *op, eString& opname)
{
  int port, i; 

  // if this is a pbrr operation, then any data labels in the
  // source operands should be marked as functions
  static const eString branch_operation_string = "__PD_PBRR";
  bool is_branch_op = false;

  if (opname == branch_operation_string) {
    is_branch_op = true;
  }

  for (i = 0, port = int(op->first_src()); 
       port <= int(op->last_src()); port++, i++) {

    Operand& s = (op->src(Port_num(port)));
    eString iopat("src");
   
    write_operand(s, iopat, i, is_branch_op);
    opname.cat(iopat);
  }
}


// write out guarded predicate operand
bool el_Buffer::write_pred_operand(Op *op, eString& opname)
{
  bool cmpp = false;       // detect comparison instructions for special handle
  bool predicated = false;

  eString iopat("pred");
       
  Operand& operand = (op->src(op->pred()));
  
  // Special case for CMPP where the predicate needs
  // to be written out even when its p<t>
  if (!strncmp((char *)opname, "__PD_CMPP",  9) ||
      !strncmp((char *)opname, "__PD_FCMPP", 10)) {
    // set cmpp flag
    cmpp = true;
          
    if (operand.is_predicate_true()) {
      sprintf(output_buffer, "%s %s", PD_REG_PTR_STRING, PD_PRED_TRUE_STRING);
      emulation_table[opcount]->pred.file = output_buffer;
      iopat = null_string;
    }
  }
    
  write_operand(operand, iopat, 0);

  // the _pred version of CMPP operations is invalid
  if (cmpp) iopat = null_string;
    
  // iopat is set to "" if the guarded predicate was a p<t>
  // dont append _pred to function name if guarded predicate is p<t>
  if (iopat != null_string) {
    iopat = "_pred";
    predicated = true;
  }

  opname.cat(iopat);
  return predicated;
}


// update static statistics
void el_Buffer::collect_op_stats(Op *op)
{
  eString op_type;
  
  // First gather some info about the ops
  if (is_brl(op) || is_branch(op)) {
    op_type = "__PD_branch";
    ++stats.Static_branch;
  }

  else if (is_load(op)) {
    op_type = "__PD_load";
    ++stats.Static_load;
  }

  else if (is_store(op)) {
    op_type = "__PD_store";
    ++stats.Static_store;
  }

  else if (is_ialu(op)) {
    op_type = "__PD_ialu";
    ++stats.Static_ialu;
  }

  else if (is_falu(op)) {
    op_type = "__PD_falu";
    ++stats.Static_falu;
  }

  else if (is_cmpp(op)) {
    op_type = "__PD_cmpp";
    ++stats.Static_cmpp;
  }

  else if (is_pbr(op)) {
    op_type = "__PD_pbr";
    ++stats.Static_pbr;
  }

  else op_type = "__PD_pseudo";

  if (op->flag(EL_OPER_SPILL_CODE)) {
    // "callee save" protocol
    if ((el_flag == EL_REGION_HAS_PROLOGUE_OP) || 
	(el_flag == EL_REGION_HAS_EPILOGUE_OP)) {
      op_type.cat(" | __PD_caller_spill");
      ++stats.Static_caller_spill;
    }

    // "caller save" protocol
    else {
      op_type.cat(" | __PD_callee_spill");
      ++stats.Static_callee_spill;
    }
  }

  ++stats.Static_ops;

  emulation_table[opcount]->type = op_type;
}


// Writes an operand - called from write_op
// It handles the operands as follows:
// - If register, use the assembler notation and write it out,
//   e.g. __PD_REGISTERS[__PD_REGISTER_FILE_][register number]
// - Macro registers are written directly in their string form,
//   - m<sp> would appear as __PD_REGISTERS[__PD_SP]
//   - "Black holes" (scratch data holders) are attached if bit buckets appear
//     in destination ports
// - Integer Literal written out in the form  PD_SET_LIT(tbl[0].src[0], IVAL)
//   - IVAL is the integer value
// - Label is written out in the form PD_SET_LIT(tbl[0].src[0], &lab)
//   - lab is the label
//   - Static variable references are changed back to their original names
// - String is written out in the form PD_SET_LIT(tbl[0].src[0], "str")
// - Control Block is written out in the form 
//   PD_SET_LIT(tbl[0].src[0], &tbl[cb_8])
//   - cb_8 is an index to the start of control block 8
// - Predicate Literal is ignored
// - Float and Double Literals are currently UNIMPLEMENTED
// - Undefined - A black hole is written out
void el_Buffer::write_operand(Operand& oprnd, eString &iopat, int oprnd_num,
			      bool is_branch_op)
{  
  eString port_type = iopat;
  static char* register_file;
  static Port* op_entry;

  // what type of operand
  if (oprnd.is_reg()) { // Regular register
    if (port_type == "dest") {
      op_entry = &(emulation_table[opcount]->dest[oprnd_num]);
    }
    else if (port_type == "src") {
      op_entry = &(emulation_table[opcount]->src[oprnd_num]);
    }
    else {
      assert (port_type == "pred");
      op_entry = &(emulation_table[opcount]->pred);
    }
    
    register_file  = reg_file_to_string(oprnd.file_type());
    sprintf(output_buffer, "%s %s", PD_REG_PTR_STRING, register_file);
    op_entry->file = output_buffer;

    if (oprnd.is_rotating()) {
      op_entry->file.cat(ROTATING_REGISTER_FILE_STRING);

      op_entry->rot = register_file;
      op_entry->rot.cat(ROTATING_REGISTER_FILE_SIZE_STRING);
    }

    // If virtual register emulation turned on
    // Note : Currently the prepass scheduler of elcor does 
    // rotating register allocation, so we choose always take
    // physical regs for rotating regs
    if (oprnd.is_static() && El_virtual_regs) {
      Reg_file reg_file = oprnd.file_type();
      int n = oprnd.vr_num();
      op_entry->num = n;
	    
      // goal is to figure out width of reg files
      // set the file size to the max reg num encountered untill now
      switch (reg_file) {
      case GPR:
	if (regfile.gpr_stat_size < n) regfile.gpr_stat_size = n;
	break;
      case FPR:
	if (regfile.fpr_stat_size < n) regfile.fpr_stat_size = n;
	break;
      case BTR:
	if (regfile.btr_stat_size < n) regfile.btr_stat_size = n;
	break;
      case PR:
	if (regfile.pr_stat_size < n) regfile.pr_stat_size = n;
	break;
      case CR:
	if (regfile.cr_stat_size < n) regfile.cr_stat_size = n;
	break;
      default:
	break;
      }
    }

    // just write out the physical register
    else {
      op_entry->num = oprnd.mc_num();
    }
	
    op_entry->is_reg = true;
    iopat = "_reg";
  } 

  else if (oprnd.is_macro_reg()) { // macro register
    Macro_name mname = oprnd.name();

    switch (mname) {       
    case INT_ZERO: 
    case FLT_ZERO: case FLT_ONE:  
    case DBL_ZERO: case DBL_ONE:
    case PRED_FALSE: case PRED_TRUE:
      // All writes to bit buckets at the destination ports
      // substituted by black holes
      if (port_type == "dest") {
	S_warn("Macro register encountered as destination operand in %s",
	       cur_proc); assert (0);

	// though is not anticipated, it is supported just in case, although
	// currently, assert (0) is enforced
	sprintf(output_buffer, "%s %s", 
		PD_REG_PTR_STRING, PD_BLACK_HOLE_STRING);
	emulation_table[opcount]->dest[oprnd_num].file = output_buffer;
	break;
      }
      // fall thru on other port_types

    default: 
      sprintf(output_buffer, "%s %s", 
	      PD_REG_PTR_STRING, macro_to_string(mname));

      // macros assigned to hard-wired variables
      if (port_type == "pred") {
	emulation_table[opcount]->pred.file   = output_buffer;
	emulation_table[opcount]->pred.is_reg = true;
      }
      else if (port_type == "src") {
	emulation_table[opcount]->src[oprnd_num].file   = output_buffer;
	emulation_table[opcount]->src[oprnd_num].is_reg = true;
      }
      else {
	assert (port_type == "dest"); 
	emulation_table[opcount]->dest[oprnd_num].file   = output_buffer;
	emulation_table[opcount]->dest[oprnd_num].is_reg = true;
      }
    }
       
    iopat = "_reg";
  }
   
  else if (oprnd.is_int()) { // integer literal
    assert (port_type == "src");

    sprintf(output_buffer, "%s %d", PD_REG_PTR_STRING, oprnd.int_value());
    emulation_table[opcount]->src[oprnd_num].file = output_buffer;

    iopat = "_lit";
  }

  else if (oprnd.is_label()) { // label literal
    assert (port_type == "src");

    bool  is_function   = false;
    bool  is_data_label = false;
    char* label = (char *) oprnd.label_value();
    
    emulation_table[opcount]->src[oprnd_num].file = ADDRESS_OF_LABEL_STRING;
    
    if (!strncmp(label, "_$_",   3)) {
      label += 3;     
    }
    else if (!strncmp(label, "_$fn",  4)) {
      is_function = true;
      label += 4;
    }
    else if (!strncmp(label, "_$$$_", 5)) {
      label += 5;
      // emulation_table[opcount]->src[oprnd_num].file.cat("__PD_");
    }
    else is_data_label = true;

    if (*label == '_') ++label;
    
    // HP-GCC vararg solution: use a wrapped to the builtin functions
    eString name(label); 
    if ((name == "__builtin_next_arg") || (name == "__builtin_saveregs")) {
      is_function   = false;
      is_data_label = false;
      emulation_table[opcount]->src[oprnd_num].file.cat(GCC_VARARG_WORKAROUND);
    }
    else if ((name == "setjmp") || (name == "__sigsetjmp")) {
      // ignore 'sigsetjmp' which is used on linux platforms
      label         = (char*) SETJMP_STRING;
      is_function   = false;
      is_data_label = false;
      emulation_table[opcount]->src[oprnd_num].file.cat(SL_WORKAROUND);
    }
    else if ((name == "longjmp") || (name == "__siglongjmp")) {
      // ignore 'siglongjmp' which is used on linux platforms
      label         = (char*) LONGJMP_STRING;
      is_function   = false;
      is_data_label = false;
      emulation_table[opcount]->src[oprnd_num].file.cat(SL_WORKAROUND);
    }

    emulation_table[opcount]->src[oprnd_num].file.cat(label);

    // if this is a function, then add it to the list for extern declaration
    if (is_function || is_branch_op) {
      if (!extern_functions.is_member(name))
	extern_functions.add_head(name);
    }
    // if this is a data label, then add it to the list for extern data
    // declaration
    else if (is_data_label) {
      if (!extern_data_labels.is_member(name))
	extern_data_labels.add_head(name);
    }

    iopat = "_lit";
  }

  else if (oprnd.is_string()) { // literal is a string(char *)
    assert (port_type == "src");

    sprintf(output_buffer, "%s %s", 
	    PD_REG_PTR_STRING, (char*) oprnd.string_value());
    emulation_table[opcount]->src[oprnd_num].file = output_buffer;

    iopat = "_lit";
  }

  else if (oprnd.is_cb()) {  // literal is a control block label
    assert (port_type == "src");
    
    // Write out the control block label
    sprintf(output_buffer, "%s &__PD_tbl%s[__PD_cb_%s_%d]", 
	    PD_REG_PTR_STRING, cur_proc, cur_proc, oprnd.id());
    
    emulation_table[opcount]->src[oprnd_num].file = output_buffer;

    iopat = "_lit";
  }
  
  else if (oprnd.is_predicate_true()) { // literal is p<t> from Rebel
    // set iopat to "" indicating it was a p<t> used by 
    // write_pred_operand method
    iopat = null_string;
  }
  
  else if (oprnd.is_predicate_false()) { // literal is p<f> from Rebel
    // No reason why one would have a pred_false as a guarded predicate
    assert (0);
  }
  
  else if (oprnd.is_float()) { // literal is a float 
    // quite unlikely that it will appear in a risc processor
    S_punt("float literal unimplemented - encounterd in procedure %s",
	   cur_proc);
  }
  
  else if (oprnd.is_double()) { // literal is a double
    // quite unlikely that it will appear in a risc processor
    S_punt("double literal unimplemented - encounterd in procedure %s",
	   cur_proc);
  }
  
  else if (oprnd.is_undefined()) {
    sprintf(output_buffer, "%s %s", PD_REG_PTR_STRING, PD_BLACK_HOLE_STRING);

    // write out a dummy place holder (black hole!) as an undefined reg
    // All undefined destination andsource ports are substituted by black holes
    // Definition of a black hole : Simulator term for a bit bucket which
    // is actually not part of the PD register set. 
    if (port_type == "src") {
      emulation_table[opcount]->src[oprnd_num].file   = output_buffer;
      emulation_table[opcount]->src[oprnd_num].is_reg = true;

      iopat = "_reg";
    }
    
    else if (port_type == "dest") {
      emulation_table[opcount]->dest[oprnd_num].file = output_buffer;
    }
    
    else iopat = null_string; // ignore undefined predicate ports
  }
	
  else {
    S_punt("unknown operand type encountered in procedure %s", cur_proc);
  }
}


// Write an operation that builds the Activation record / stack frame
void el_Buffer::write_prologue()
{
  Macro_name stackvar; // not made use of currently. gets SP back.
  int        stackoffset;
	
  // src[0] holds the total stack frame size
  emulation_table[opcount]->op   = PD_PROLOGUE_STRING;
  
  sprintf(output_buffer, "%s %d", PD_REG_PTR_STRING, frame.size);
  emulation_table[opcount]->src[0].file = output_buffer;
  
  // get the offset to be added to OP on function entry
  map_macros_to_stack(OP_REG, stackvar, stackoffset);
  sprintf(output_buffer, "%s %d", PD_REG_PTR_STRING, stackoffset);
  emulation_table[opcount]->src[1].file = output_buffer;
  
  // get the offset to be added to LV on function entry
  map_macros_to_stack(LV_REG, stackvar, stackoffset);
  sprintf(output_buffer, "%s %d", PD_REG_PTR_STRING, stackoffset);
  emulation_table[opcount]->src[2].file = output_buffer;
  
  // get the offset to be added to IP on function entry
  map_macros_to_stack(IP_REG, stackvar, stackoffset);
  sprintf(output_buffer, "%s %d", PD_REG_PTR_STRING, stackoffset);
  emulation_table[opcount]->src[3].file = output_buffer;

  if (!El_virtual_regs) {
    emulation_table[opcount]->mask = true;
  }

  opcount++;
  resize_emulation_table_if_necessary();
}


// Write out the pseudo operation to destroy an activation record
void el_Buffer::write_epilogue()
{
  // src[0] holds the stack frame size
  emulation_table[opcount]->op   = PD_EPILOGUE_STRING;

  sprintf(output_buffer, "%s %d", PD_REG_PTR_STRING, frame.size);
  emulation_table[opcount]->src[0].file = output_buffer;

  if (!El_virtual_regs) {
    emulation_table[opcount]->mask = true;
  }

  opcount++;
  resize_emulation_table_if_necessary();
}


// Utility to double word align an offset
// Assures there are no bus errors at run-time due to incorrect address
// alignment - example reading a dword from a non dword aligned addr.
void el_Buffer::dword_align(int& mval)
{
  if ((mval % sizeof(double)) > 0)
    mval += (sizeof(double) - (mval % sizeof(double))); 
}


// Computes the offsets within the stackframe required by the
// PD_prolog and PD_epilog operations
void el_Buffer::map_macros_to_stack(Macro_name mname, Macro_name &stackvar,
				    int &stackoffset)
{   
  // for now its just PA style SP addressing
  stackvar = SP_REG;
   
  // now assign offsets, assume that ALLOCA is not called!
  // i.e. the stack size can be determined statically
  
  //Frame looks like this currently 
  //-------------------------------
  //                    Outgoing parameters (incoming to the next frame)
  //Frame 1(previous)   ------------------
  //                    Frame marker
  //                    ===================
  //Frame 2(new)        Register save area
  //                   -------------------
  //                    Local variables
  //                    ------------------
  //                    Outgoing parameters
  //                    ------------------
  //                    Frame marker
  //                   ===================  
  //                                        <---- SP
   
  // offsets are relative to SP of the new frame
  switch(mname) {
  case OP_REG: 
    stackoffset = -frame.fma; 
    break;

  case LV_REG: 
    stackoffset = -(frame.fma + frame.param); 
    break;

  case SP_REG: 
    stackoffset = -(frame.fma + frame.param + frame.local); 
    break;

    // Impact allocator wrongly uses SP to access register save area
  case RGS_REG: 
    stackoffset = -(frame.fma + frame.param + frame.local); 
    break;

    // NYU regestir allocator uses RGS
  case IP_REG: 
    stackoffset = 
      -(frame.fma + frame.param + frame.local + frame.swap + frame.fma);
    break;

  default:
    break;
  }
}


// search for a particular macro register in a DEFINE operation
// if found, return its value, used to calculate the frame size
void el_Buffer::check_component(Op *op, Macro_name mname, char *mstring, 
				int &mval) 
{
  Port_num dport = int(op->first_dest());
  Port_num sport = int(op->first_src());
   
  Operand doprnd = op->dest(dport);
  Operand soprnd = op->src(sport);
  
  if (doprnd.is_macro_reg()) {
    if (doprnd.name() == mname) {
      if (soprnd.is_int()) {
	mval = soprnd.int_value();
	dword_align(mval); // dword align it!
      }
      
      else {
	S_warn("%s size undefined.", mstring);
      }
    }
  }
}


// Reads the prologue and returns the framesize
void el_Buffer::calc_framesize(Region *region)
{   
  frame.local = -1;
  frame.param = -1;
  frame.swap  = -1;
  frame.fma   = 32;
   
  // Traverse through all operations in the prologue basic block
  // and search for DEFINE operations
  for (Region_ops_C0_order iter((Compound_region *) region); *iter; iter++) {
    Region* R = (Region *) *iter;
    Op* op    = (Op *) R;
   
    // pick up only the "DEFINE" pseudo operations
    if (op->is_pseudo_op() &&  op->opcode() == DEFINE) {
      // get the sizes of the diff. components in a stack frame
      check_component(op, LOCAL, "m<local>", frame.local);
      check_component(op, PARAM, "m<param>", frame.param);
      check_component(op, SWAP,  "m<swap>",  frame.swap);
    }
  }
   
  if (frame.local == -1) {
    frame.local = 0;
  }
  
  if (frame.param == -1) {
    // HPL-PD ABI says this should be atleast 16 bytes, 
    // *aka* fixed arg. area
    S_warn("m<param> not defined, assuming 16.");
    frame.param = 16;  
  }
   
  if (frame.swap == -1) {
    S_warn("m<swap> not defined, assuming 0.");
    frame.swap = 0;
  }
   
  // compute total size
  frame.size = frame.local + frame.param + frame.swap + frame.fma;
}


// binds a call_info string to a vector (called a template)
// if the call_info string was not encountered in the past, a new
// vector is generated and stored for future reference
int el_Buffer::get_vector_key(Op* op, eString& vector_type)
{
  eString call_info;
  static  hc_aggregate* entry;

  get_call_info(op, call_info); 

  int key = assign_key(call_info);
       
  vector_type  = "template_";
  vector_type.cat(int_to_str(key));
  vector_type |= '_';

  eString fname = vector_type;

  if (!prototypes_table.is_bound(fname)) {
    entry = new hc_aggregate;
    create_prototype(*entry, fname, call_info);
    append_parameter_attributes(op, *entry);
    
    prototypes_table.bind(entry->name, entry);
    
    entry->vec_temp = vector_type.length();
  }

  return true;
}


// given an operation, return the call_info attribute
int el_Buffer::get_call_info(Region *reg, eString& info)
{
  Lcode_attribute_map *map = get_lcode_attributes(reg);
  
  if (map && !map->is_empty()) {
    // iterate over the attributes, until call_info is encoutered
    for (Map_iterator<eString, List<Operand> > mptr(*map); mptr != 0; mptr++) {
      // recover operand list
      Pair<eString, List<Operand> > entry = *mptr;
      
      // only interested in call_info attribute
      if (entry.first == "call_info") {
	// iterate through and recover parameter string
	for (List_iterator<Operand> optr(entry.second);  optr != 0;  optr++) {
	  Base_operand& op = *(*optr).get_ptr();
	  
	  if(op.is_string()) {
	    info = ((const String_lit&)op).value();

	    // check to see if the current call_info field has been processed
	    // for external structures or unions extraction, if it hasn't
	    // process it and mark is as processed
	    if (!encountered_call_info.is_member(info)) {
	      encountered_call_info.add_head(info);
	      extract_struct_or_union_info(info);
	    }

	    return true;
	  }
	}
      }
    }
    
    S_warn("call_info attribute not found for operation %d of procedure %s",
	   reg->id(), cur_proc);
  }
  
  return false;
}


// append offset information to the parameter list of a given function
// or function call
int el_Buffer::append_parameter_attributes(Region *reg, hc_aggregate& func)
{
  bool tr_encountered   = false;
  bool tmo_encountered  = false;
  bool tmso_encountered = false;

  bool append_gcc_ellipsis = false;
  bool kandrc = false;

  int  current_parameter_number = 1;


  Lcode_attribute_map *map = get_lcode_attributes(reg);
  List<Operand> tmso_list;

  if (map && !map->is_empty()) {
    // iterate over the attributes, until the tr && tmo is encoutered
    for (Map_iterator<eString, List<Operand> > mptr(*map); mptr != 0; mptr++) {
      // recover operand list
      Pair<eString, List<Operand> > entry = *mptr;
      
      // this is the list of "through-register" parameters,
      // attribute the information to the entry
      // offset information is ignored, since is should be done properly
      // in IMPACT and ELCOR.  
      // May wish to use that information for error checking!
      if (entry.first == "tr") {
	// so that the function may return when finished
	tr_encountered = true;

	// iterate through and recover parameter string
	for (List_iterator<Operand> optr(entry.second);  optr != 0;  optr++) {
	  Base_operand& op = *(*optr).get_ptr();
	  
	  if(!op.is_macro_reg()) {
	    S_warn("%s: expected macro register for current operation %d!",
		   "append_parameter_attributes", reg->id());
	    assert(0);
	  }

	  Macro_name macro = ((const Macro_reg&) op).name();

	  if (current_parameter_number == func.params.dim()) {
	    S_warn("%s: extra register parameters at operation %d of %s",
		   "append_parameter_attributes", reg->id(), cur_proc);
	  }
	  else {
	    func.params[current_parameter_number].macro_reg  = true;
	    func.params[current_parameter_number].macro_name = macro;
	    current_parameter_number++;
	  }
	}
      }

      // These are parameters passed on the stack, the simulator
      // will use OP pointer + offset to access these parameters
      else if (entry.first == "tmo") {
	// so that the function may return when finished
	tmo_encountered = true;

	// iterate through and recover parameter string
	for (List_iterator<Operand> optr(entry.second);  optr != 0;  optr++) {
	  Base_operand& op = *(*optr).get_ptr();
	  
	  if(!op.is_int()) {
	    S_punt("%s: expected integer value for op offset at operation %d!",
		   "append_parameter_attributes", reg->id());
	  }

	  int offset = ((const Int_lit&) op).int_value();
	  func.params[current_parameter_number].offset = offset;
	  current_parameter_number++;
	}
      }
      
      else if (entry.first == "host_info") {
	for (List_iterator<Operand> optr(entry.second);  optr != 0;  optr++) {
	  Base_operand& op = *(*optr).get_ptr();
	
	  assert (op.is_string());
	  eString platform = ((const String_lit&) op).value();
	  
	  if (platform == "\"hp\"") {
	    host_platform_info.platform = HP;
	  }
	  else if (platform == "\"x86lin\"") {
	    host_platform_info.platform = X86LIN;
	  }
	  else if (platform == "\"sunos\"") {
	    host_platform_info.platform = SUNOS;
	  }
	  else if (platform == "\"sunsol\"") {
	    host_platform_info.platform = SUNOS;
	  }
	  else S_punt("unsupported <%s> host platform", (char*) platform);
	  break;
	}
      }

      else if (entry.first == "tmso") {
	tmso_encountered = true;
	tmso_list = entry.second;
      }

      else if (entry.first == "append_gcc_ellipsis") {
	append_gcc_ellipsis = true;
	func.isVararg = true;
      }

      else if (entry.first == "VARARG") {
	func.isVararg = true;
      }

      else if (entry.first == "preprocess_info") {
        for (List_iterator<Operand> optr(entry.second);  optr != 0;  optr++) {
          Base_operand& op = *(*optr).get_ptr();

	  // sometimes the "old_style_param" flag is missing, 
	  // the "K&R-C" flag should be more reliable
          if (op.is_string()) {
	    eString info = ((const String_lit&) op).value();
	    
	    if (info == "\"K&R-C\"") {
	      kandrc = true;
	      func.isKANDRC = true;
	    }
	  }
	}
      }

      else if (entry.first == "old_style_param") {
	kandrc = true;
	func.isKANDRC = true;
      }
    }
  }
  
  // add the structure location on the stack to the corresponding 
  // parameter entry
  if (tmso_encountered) {
    // expecting the tmso to be for a parameter, not the return type
    assert (func.params.dim() > 1);
    
    // the first node in the list is the return type
    int last_struct_param = 1; 
    
    // iterate through the list and retrieve the memory offsets for 
    // any structure that are encountered
    for (List_iterator<Operand> optr(tmso_list); optr != 0; optr++) {
      Base_operand& op = *(*optr).get_ptr();

      // if the parameter is not a structure, I don't expect to see
      // a through-memory-structure-offset value
      if ((func.params[last_struct_param].type != STRUCT) &&
	  (func.params[last_struct_param].type != UNION)) {
	assert (op.is_undefined());
      }
      
      // if the parameter is a structure, then I only expect to see
      // a through-memory-structure-offset value if it passed by value
      else if (func.params[last_struct_param].desc != NIL){
	assert (op.is_undefined());
      }
      
      else {
	if(!op.is_int()) {
	  S_warn("%s: expected integer value for %s offset at operation %d!",
		 "append_parameter_attributes", "struct", reg->id());
	  assert(0);
	}
	
	else if (last_struct_param > func.params.dim()-1) {
	  S_punt("%s: corresponding struct parameter for \"tmso\" of %s %d %s",
		 "append_parameter_attributes", "operation", reg->id(), 
		 "not found");
	}
	
	int soffset = ((const Int_lit&) op).int_value();
	func.params[last_struct_param].has_soffset = true;
	func.params[last_struct_param].soffset = soffset;
      }
      
      last_struct_param++;
    }
  }

  // sanity check
  if (append_gcc_ellipsis) {
    if (!kandrc) {
      S_punt("expected \"%s\" %s for operation %d of %s\n%s %s",
		"old_style_param", "lcode attribute", reg->id(), cur_proc, 
		"You may wish to manually add the attribute to",
		(char*) Rebel_path_name);
    }
  }
  
  return true;
}


// return a unique key for a given call_info strings
int el_Buffer::assign_key(eString& call_info)
{
  static int key = 1;
  
  // if the call_info field was encountered before, then return that key
  if (call_info_map.is_bound(call_info))
    return call_info_map.value(call_info);

  // otherwise create a new key
  call_info_map.bind(call_info, key);
  return key++;
}


// given a call_info string, generate a function attribute
// this function is no longer necessary, and will be removed eventually
// its functionality has been replaced by the impact attributes
void el_Buffer::create_prototype(hc_aggregate& entry, eString& fname, 
				 eString& call_info)
{
  // if call_info was encountered already, make a copy of the generated
  // function attribute
  if (stored_call_info.is_bound(call_info)) {
    entry = *stored_call_info.value(call_info);
  }

  else { // create a new attribute
    static hc_aggregate* info_entry;

    // call_info string format:
    // parameters are seperated by '%'
    // first field is the return type
    // arrays and pointers are preceded by '+'
    // pointers == 'P', arrays == 'A' (and size)

    info_entry = new hc_aggregate;
    // save call_info, will be used in later processing (packager, vectorizer)
    info_entry->call_info = call_info; 
  
    // parse call_info string and generate a function entry
    parse_info_string((char*)(call_info), *info_entry);

    // bind the call_info field to a history map to avoid reprocessing
    stored_call_info.bind(call_info, info_entry);

    // make a copy and return
    entry = *info_entry;
  }
  
  entry.name = fname;
}
