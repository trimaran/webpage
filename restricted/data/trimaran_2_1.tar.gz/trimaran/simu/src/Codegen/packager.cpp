/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   packager.cpp
// Author: Rodric M. Rabbah, Amit Nene
///////////////////////////////////////////////////////////////////////////////

#include "simu.h"
#include "streamBuffer.h"

// name of the global functio which initializes all benchmark data
extern const char* SIMU_GLOBAL_DATA_INIT_FUNCTION;

// list of wrapper candidates
extern Hash_table<eString> wrappers;

// list of all functions with their parameter info
extern Hash_map<eString, hc_aggregate*> prototypes_table;

// simulator parameters
extern int El_nual_equals;
extern int El_virtual_regs;
extern int El_performance_monitoring;
extern int El_binary_trace_format;
extern int El_control_flow_trace;
extern int El_address_trace;
extern int El_dynamic_stats;

// function declarations
void gen_wrappers(ofstream &outf, const Host_Info&);
static void write_wrapper(streamBuffer &, hc_aggregate&, const Host_Info&);

static char* print_cast(const hc_param& param);
char* promote_param(const hc_param& params);

// extern function declarations
extern bool  pass_SU_by_value(hc_param& p);
extern char* print(Macro_name& macro);
extern char* typecast(hc_param&);
extern void  print_KRC_vararg_function_dec(streamBuffer&, hc_aggregate&);
extern void  print_function_declaration(streamBuffer&, hc_aggregate&);


// Write out wrapper functions for all function declarations
// encountered in the current file
void gen_wrappers(ofstream &outf, const Host_Info& host_info)
{
  streamBuffer out(outf);
  S_log("Writing Wrappers...");
  
  // write the header part
  out << endl << endl
      << "/**********************************************************/" << endl
      << "/******************** Wrapper Functions *******************/" << endl
      << "/**********************************************************/" << endl
      << endl << endl;

  for (Hash_table_iterator<eString> iter(wrappers); iter!=0 ; iter++) {
    eString e = *iter;
    hc_aggregate& func = *prototypes_table.value(e);
    
    write_wrapper(out, func, host_info);
  }

  out.commit();
}


// packaging routine
static void write_wrapper(streamBuffer &out_defs, hc_aggregate& func, 
			  const Host_Info& host_info)
{
  static char output_buffer[MAX_BUF_SIZE];
  char *name = (char *) func.name;
  int  last_param_count = -1;

  // old style vararg function declaration
  if (func.isVararg && func.isKANDRC) {    
    print_KRC_vararg_function_dec(out_defs, func); 
    out_defs << "; ...";
  }
  else {
    print_function_declaration(out_defs, func);
  }
  // begin function body
  out_defs << endl << "{" << endl;

  // Write out function specific information 
  out_defs 
    << STAB << "static int __PD_is_init = 0;"  << endl 
    << endl
    << STAB << "int    __tmp_edge           = __PD_edge;" << endl
    << STAB << "struct __PD_REG __PD_tmp_sp = __PD_sp;" << endl
    << STAB << "struct __PD_REG __PD_tmp_op;" << endl
    << STAB << "int    __sp_align;" << endl
    << endl
    << STAB << "struct __PD_stats*  __PD_tmp_stats = __PD_cur_stats;" << endl
    << STAB << "struct __PD_params* __tmp_params   = __PD_params_vals;" << endl
    << STAB << "struct __PD_params  __params_val   = {"
    << El_nual_equals  << ", "
    << El_binary_trace_format << ", "
    << El_address_trace << ", "
    << El_control_flow_trace << ", "	    
    << El_dynamic_stats 
    << "};" << endl 
    << endl;
  
  if (El_virtual_regs) {
    out_defs 
      << STAB << "struct __PD_REG*     __tmp_regs    = __PD_regs;" << endl
      << STAB << "struct __PD_regfile* __tmp_reginfo = __PD_cur_reginfo;"
      << endl << endl;
  }
    
  out_defs << STAB << "int __native_call = !__PD_lookup(&" << func.name << ");"
    	   << endl << endl
	   << STAB << "__PD_params_vals = &__params_val;" << endl;

  if (El_virtual_regs) {
    sprintf(output_buffer, "%s__PD_set_regfile(__PD_reginfo_%s, NULL, 0 , 0);",
	    STAB, name);
    out_defs << output_buffer << endl << endl;
  }
  
  // init tells whether the simulation table has been loaded or not
  out_defs << endl << STAB << "if (!__PD_is_init) {" << endl;

  // must initialize global data upon first entry to any function
  out_defs << STAB << STAB << SIMU_GLOBAL_DATA_INIT_FUNCTION << ";" << endl;

  // must initialize the PD emulation table 
  out_defs << STAB << STAB << "__PD_init();" << endl;
  
  if (!El_virtual_regs) {
    sprintf(output_buffer, "%s%s__PD_set_regfile(__PD_reginfo, NULL, 1, 0);", 
	    STAB, STAB); 

    out_defs << output_buffer << endl;
  }

  if (El_dynamic_stats) {
    sprintf(output_buffer, "%s%s__PD_chain(__PD_stats_%s);", STAB, STAB, name);
    out_defs << output_buffer << endl;
  }
  
  out_defs << endl
	   << STAB << STAB << "__PD_is_init = 1;" << endl
	   << STAB << "}" << endl;
  
  // Start analyzing the parameters
  if (func.count > 1) {
    out_defs << endl << STAB << "if (__native_call) {" << endl;
  
    // if native_call is true, then allocate a fake activation record
    // then execute current function
    // the size of the fake frame is the equivalent to the max parameter
    // offset, + 32 (for the frame marker).  
    int extra = max(16, abs(func.params[func.params.dim()-1].offset));
    for (int i = 1; i < func.params.dim(); i++) {
      if (func.params[i].has_soffset) {
	extra = max(abs(func.params[i].soffset), extra);
      }
    }
    assert (!(extra % 4));

    // force the stack pointer to be double aligned
    // assumes sizeof(double) == 8
    out_defs 
      << STAB << STAB << "__sp_align = " << extra << ";" << endl
      << STAB << STAB << "/* assumes sizeof(double) == 8 */" << endl
      << STAB << STAB << "if (__sp_align & 7) {" << endl
      << STAB << STAB << STAB << "__sp_align += 8 - (" << extra << " & 7);"
      << endl 
      << STAB << STAB << "}" << endl
      << STAB << STAB << "__PD_sp.reg.cr    += 32 + __sp_align;" << endl
      << STAB << STAB << "__PD_tmp_op.reg.cr = __PD_sp.reg.cr - 32;" << endl 
      << endl;
  }

  for (int index = 1; index < func.params.dim(); index++) {
    hc_param& param = func.params[index];

    // ignore the vararg parameter
    if (param.type == ELLIPSIS) {
      last_param_count = index - 1;
      assert (index == func.params.dim()-1);
      break;
    }

    if (pass_SU_by_value(param)) {
      if (param.macro_reg) {
	// when a structure is passed by value, and it is being passed
	// through a register, a pointer to the actual structure is passed
	// in the register, and the actual structure resides somewhere in
	// OP, and the structure offset must be present - otherwise, something
	// is wrong
	assert (param.has_soffset);
	
	// set the macro registers to contain the address of the location
	// where the actual structure will be copied
	out_defs << STAB << STAB << print(param.macro_name) 
		 << " = __PD_tmp_op.reg.cr + " <<  param.soffset << ";"  
		 << endl;  
	
	// copy the struct to the fake stack
	out_defs << STAB << STAB << "*((" << typecast(param) << "*) ("
		 << print(param.macro_name) << ")) = p" << index << ";"  
		 << endl;	  
      } // structure passed in register
      
      else {
	if (param.has_soffset) {
	  // this is an indirect structure passed by value, set offset to 
	  // contain the address of the location where the actual 
	  // structure will be copied
	  out_defs << STAB << STAB << "*((int *) (__PD_tmp_op.reg.cr + " 
		   << param.offset << ")) = __PD_tmp_op.reg.cr + " 
		   <<  param.soffset << ";"
		   << endl;

	  // copy the struct to the fake stack
	  out_defs << STAB << STAB << "*((" << typecast(param) << "*) ("
		   << "__PD_tmp_op.reg.cr + " << param.soffset << ")) = p" 
		   << index << ";"  << endl;

	} // indirect structure pass by value

	else {
	  out_defs << STAB << STAB << "*((" << typecast(param) << "*) ("
		   << "__PD_tmp_op.reg.cr + " << param.offset << ")) = p" 
		   << index << ";"  << endl;
	}
      } // structure passed in memory
    } // special structure handling
      
    else {
      if (param.macro_reg) {
	out_defs << STAB << STAB << print(param.macro_name)   << " = " 
		 << print_cast(param) << " p" << index << ";" << endl;
      }
      
      else {
	eString type = promote_param(param);
	
	out_defs << STAB << STAB << "*((" << type << "*) "
		 << "(__PD_tmp_op.reg.cr + " << param.offset
		 << ")) = ((" << type << ") p" << index << ");" << endl;
      }
    }
  }
  
  // end outgoing parameter stack initialization
  if (func.count > 1)
    out_defs << STAB << "}" << endl;
  
  // special handle for vararg functions
  if (func.isVararg) {
    out_defs << endl;

    switch (host_info.platform) {
    case SUNOS:
    case HP: {
      if (func.isKANDRC) {
	S_warn("varargs may not be accurately simulated!");

	if (func.count != 2) {
	  S_punt("[%s] expected to specify a %s and exactly %s!", 
		 name, "return type", "one parameter");
	}
      
	out_defs 
	  << STAB 
	  << "__PD_VAR_ap_list_start.reg.gpr = (int) __builtin_saveregs();"
	  << endl << endl;
      }
      else {
	// sanity check
	assert (last_param_count == func.count - 2);

	out_defs 
	  << STAB << "__builtin_next_arg(p" << last_param_count << ");"
	  << endl
	  << STAB 
	  << "__PD_VAR_ap_list_start.reg.gpr = (int) __builtin_saveregs();"
	  << endl << endl;
      }
    } break;
    case X86LIN: {
      if (func.isKANDRC) {
	/* S_punt("varargs on linux not supported!"); */
	S_warn("varargs may not be accurately simulated!");
	
	if (func.count != 2) {
	  S_punt("[%s] expected to specify a %s and exactly %s!", 
		 name, "return type", "one parameter");
	}

	out_defs 
	  << STAB 
	  << "__PD_VAR_ap_list_start.reg.gpr = (int) __builtin_next_arg("
	  << "p1);" << endl 
	  << endl;
      }
      
      else {
	// sanity check
	assert (last_param_count == func.count - 2);
	
	out_defs 
	  << STAB 
	  << "__PD_VAR_ap_list_start.reg.gpr = (int) __builtin_next_arg(p"
	  << last_param_count << ");" << endl 
	  << endl;
      }
    } break;

    default: S_punt("Unsupported Host Platform!");
    }
  }

  // Write out the call to simulator
  sprintf(output_buffer, "%s__PD_simulate(__PD_tbl_%s);", STAB, name);
  out_defs << endl << output_buffer << endl << endl;
  
  // restore the original stack ptr
  out_defs << STAB << "if (__native_call) {" << endl
	   << STAB << STAB << "__PD_sp = __PD_tmp_sp;" << endl
	   << STAB << "}"
	   << endl << endl
	   << STAB << "__PD_params_vals = __tmp_params;"   << endl
	   << STAB << "__PD_cur_stats   = __PD_tmp_stats;" << endl
	   << STAB << "__PD_edge        = __tmp_edge;"     << endl;
    
  // restore caller's register settings
  if (El_virtual_regs) {
    sprintf(output_buffer, 
	    "%s__PD_set_regfile(__tmp_reginfo, __tmp_regs, 0, 1);", STAB);
    out_defs << output_buffer << endl;
  }
  
  out_defs << endl;
  
  // Lastly Analyze the return type
  switch (func.params[0].desc) {
  case DATA_POINTER:
  case CODE_POINTER:
    out_defs << STAB << "return (" << typecast(func.params[0]) << ")" << endl
	     << STAB << STAB << "__PD_int_ret.reg.gpr;" << endl;
    break;
    
  default:
    switch (func.params[0].type) {
    case STRUCT:
    case UNION:
      // again force return by value using the pattern *((struct *) )
      out_defs << STAB << "return *((" << typecast(func.params[0]) << "*)" 
	       << endl << STAB << STAB << "__PD_int_ret.reg.gpr);" << endl;
      break;
      
    default:
      if (func.params[0].type != VOID) {
	out_defs << STAB << "return (" << typecast(func.params[0])  << ")"
		 << endl;
	
	switch(func.params[0].type) {
	case CHAR:
	case SHORT:
	case LONG:
	case INT:
	  out_defs << STAB << STAB << "__PD_int_ret.reg.gpr;" << endl;
	  break;
		    
	case FLOAT:
	  out_defs << STAB << STAB << "__PD_flt_ret.reg.fpr_S;" << endl;
	  break;
		    
	case DOUBLE:
	  out_defs << STAB << STAB << "__PD_dbl_ret.reg.fpr_D;" << endl;
	  break;
	  
	default:
	  break;
	}
      }
    }
  }
  
  out_defs << "}" << endl << endl;
}


static char* print_cast(const hc_param& param)
{
  switch(param.desc) {
  case CODE_POINTER:  case DATA_POINTER:  return "(long)";
  default:
    switch(param.type) {
    case CHAR: case SHORT: case LONG: case INT:  return "(long)";
    case FLOAT:  return "(float)";
    case DOUBLE: return "(double)";
    case STRUCT: case UNION: return "(long)&";
    default: return "";
    }
  }
}


char* promote_param(const hc_param& param)
{
  switch(param.desc) {
  case CODE_POINTER: case DATA_POINTER: return "long";
  default:
    switch(param.type) {
    case CHAR: case SHORT: case LONG: case INT: return "long";
    case FLOAT:  return "float";
    case DOUBLE: return "double";

    case STRUCT: case UNION:
      // structure and unions passed by value are handled
      // by a special case in the wrapper writer
      assert(0);
    default:
      return "";
    }
  }
}
