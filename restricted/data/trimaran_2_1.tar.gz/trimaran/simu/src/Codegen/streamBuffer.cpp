/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   streamBuffer.cpp
// Author: Amit Nene, Rodric M. Rabbah
///////////////////////////////////////////////////////////////////////////////

#include "simu.h"
#include "streamBuffer.h"

#include "ir_operand.h"
#include "IR_symbol.h"

const char* STAB = "   ";

// extern function prototypes
extern void sprint_C_prototype(char *output, char *name, char *info);
extern void sprint_KRC_prototype(char* output, char *name, char *info);


// function declarations
void print_function_declaration(streamBuffer& out, hc_aggregate& aggr);
void print_KRC_vararg_function_dec(streamBuffer&, hc_aggregate&);



// constructor
streamBuffer::streamBuffer(void)
{
  out = NULL;
}


// constructor
streamBuffer::streamBuffer(ofstream& out_file)
{
  out = &out_file;
}


// concatenate two buffers
streamBuffer& operator<<(streamBuffer& t, streamBuffer& s)
{
  if (s.buffer != NULL) {
    t.buffer += s.buffer;
  }
  return t;
}


streamBuffer& streamBuffer::operator<<(int i)
{
  char str[50];
  sprintf(str, "%d", i);
  buffer += str;
  return *this;
}


streamBuffer& streamBuffer::operator<<(unsigned int i)
{
  char str[50];
  sprintf(str, "%u", i);
  buffer += str;
  return *this;
}


streamBuffer& streamBuffer::operator<<(long l)
{
  char str[50];
  sprintf(str, "%ld", l);
  buffer += str;
  return *this;
}


streamBuffer& streamBuffer::operator<<(char c)
{
  char str[5];
  str[0] = c;
  str[1] = 0;
  buffer += str;
  return *this;
}


streamBuffer& streamBuffer::operator<<(const char* str)
{
  buffer += str;
  return *this;
}


streamBuffer& streamBuffer::operator<<(const eString& estr)
{
  buffer += ((char *) ((eString&) estr));
  return *this;
}


streamBuffer& streamBuffer::operator<<(float f)
{
  char str[50];
  // match the precision in the elcor IR_oustream
  sprintf(str, "%.8g", f);
  buffer += str;
  return *this;
}


streamBuffer& streamBuffer::operator<<(double d)
{
  char str[50];
  // match the precision in the elcor IR_oustream
  sprintf(str, "%.16g", d);
  buffer += str;
  return *this;
}


streamBuffer& streamBuffer::operator<<(const void *ptr)
{
  char str[50];
  sprintf(str, "%p", ptr);
  buffer += str;
  return *this;
}


streamBuffer& streamBuffer::operator<<(const Reg_file& reg_file)
{
  // Write out a register file type;
  switch (reg_file) {
  case GPR: (*this) << "__PD_GPR_FILE"; break;
  case FPR: (*this) << "__PD_FPR_FILE"; break;
  case PR:  (*this) << "__PD_PR_FILE";  break;
  case BTR: (*this) << "__PD_BTR_FILE"; break;
  case CR:  (*this) << "__PD_CR_FILE";  break;

  default:  
    S_punt("Unkown Reg_file type!");
  }

  return *this;
}


char* reg_file_to_string(const Reg_file& reg_file)
{
  switch (reg_file) {
  case GPR: return "__PD_GPR_FILE";
  case FPR: return "__PD_FPR_FILE";
  case PR:  return "__PD_PR_FILE"; 
  case BTR: return "__PD_BTR_FILE";
  case CR:  return "__PD_CR_FILE"; 
    
  default:  
    S_punt("Unkown Reg_file type!"); 
    return NULL;
  }
}


char* macro_to_string(const Macro_name& name)
{
  switch (name) {
  case UNDEFINED: return "__PD_undef";
  case LOCAL:     return "__PD_local";
  case PARAM:	  return "__PD_param";
  case SWAP:	  return "__PD_swap"; 

  case RETURN_ADDR:     return "__PD_RET_ADDR";     
  case INT_RETURN_TYPE: return "__PD_int_ret_type"; 
  case FLT_RETURN_TYPE: return "__PD_flt_ret_type"; 
  case DBL_RETURN_TYPE: return "__PD_dbl_ret_type"; 

  case INT_RETURN:  return "__PD_INT_RET";
  case INT_PARAM_1: return "__PD_INT_P1"; 
  case INT_PARAM_2: return "__PD_INT_P2"; 
  case INT_PARAM_3: return "__PD_INT_P3"; 
  case INT_PARAM_4: return "__PD_INT_P4"; 
  case FLT_RETURN:  return "__PD_FLT_RET";
  case FLT_PARAM_1: return "__PD_FLT_P1"; 
  case FLT_PARAM_2: return "__PD_FLT_P2"; 
  case FLT_PARAM_3: return "__PD_FLT_P3"; 
  case FLT_PARAM_4: return "__PD_FLT_P4"; 
  case DBL_RETURN:  return "__PD_DBL_RET";
  case DBL_PARAM_1: return "__PD_DBL_P1"; 
  case DBL_PARAM_2: return "__PD_DBL_P2"; 
  case INT_TM_TYPE: return "__PD_INT_TM"; 
  case FLT_TM_TYPE: return "__PD_FLT_TM"; 
  case DBL_TM_TYPE: return "__PD_DBL_TM"; 

  // SP should be interpreted as RS
  case SP_REG:	return "__PD_RS"; 
  case FP_REG:	return "__PD_FP"; 
  case IP_REG:	return "__PD_IP"; 
  case OP_REG:	return "__PD_OPS";
  case LV_REG:	return "__PD_LV"; 
  case LC_REG:	return "__PD_LC"; 
  case ESC_REG:	return "__PD_ESC";

  case RRB:             return "__PD_RRB";            
  case ALL_PRED:	return "__PD_ALL_PRED";       
  case ALL_ROT_PRED:    return "__PD_ALL_ROT_PRED";   
  case ALL_STATIC_PRED: return "__PD_ALL_STATIC_PRED";


  case FLT_ZERO: return "__PD_FLT_ZERO";
  case FLT_ONE:	 return "__PD_FLT_ONE"; 
  case DBL_ZERO: return "__PD_DBL_ZERO";
  case DBL_ONE:	 return "__PD_DBL_ONE"; 
  case INT_ZERO: return "__PD_INT_ZERO";

  case PRED_FALSE: return "__PD_PRED_F";
  case PRED_TRUE:  return "__PD_PRED_T";

  case SPILL_TEMPREG: return "__PD_TEMP_REG";

  case PV_0: return "__PD_PV_0";
  case PV_1: return "__PD_PV_1";
  case PV_2: return "__PD_PV_2";
  case PV_3: return "__PD_PV_3";
  case PV_4: return "__PD_PV_4";
  case PV_5: return "__PD_PV_5";
  case PV_6: return "__PD_PV_6";
  case PV_7: return "__PD_PV_7";

  default:
    S_punt("Unkown macro name!");
    break;
  }
  return NULL;
}


streamBuffer& streamBuffer::operator<<(const Macro_name& name)
{
  // Write out a macro name;

  switch (name) {
  case UNDEFINED: (*this) << "__PD_undef"; break;
  case LOCAL:     (*this) << "__PD_local"; break;
  case PARAM:	  (*this) << "__PD_param"; break;
  case SWAP:	  (*this) << "__PD_swap";  break;

  case RETURN_ADDR:     (*this) << "__PD_RET_ADDR";      break;
  case INT_RETURN_TYPE: (*this) << "__PD_int_ret_type";  break;
  case FLT_RETURN_TYPE: (*this) << "__PD_flt_ret_type";  break;
  case DBL_RETURN_TYPE: (*this) << "__PD_dbl_ret_type";  break;

  case INT_RETURN:  (*this) << "__PD_INT_RET"; break;
  case INT_PARAM_1: (*this) << "__PD_INT_P1";  break;
  case INT_PARAM_2: (*this) << "__PD_INT_P2";  break;
  case INT_PARAM_3: (*this) << "__PD_INT_P3";  break;
  case INT_PARAM_4: (*this) << "__PD_INT_P4";  break;
  case FLT_RETURN:  (*this) << "__PD_FLT_RET"; break;
  case FLT_PARAM_1: (*this) << "__PD_FLT_P1";  break;
  case FLT_PARAM_2: (*this) << "__PD_FLT_P2";  break;
  case FLT_PARAM_3: (*this) << "__PD_FLT_P3";  break;
  case FLT_PARAM_4: (*this) << "__PD_FLT_P4";  break;
  case DBL_RETURN:  (*this) << "__PD_DBL_RET"; break;
  case DBL_PARAM_1: (*this) << "__PD_DBL_P1";  break;
  case DBL_PARAM_2: (*this) << "__PD_DBL_P2";  break;
  case INT_TM_TYPE: (*this) << "__PD_INT_TM";  break;
  case FLT_TM_TYPE: (*this) << "__PD_FLT_TM";  break;
  case DBL_TM_TYPE: (*this) << "__PD_DBL_TM";  break;

  // SP should be interpreted as RS
  case SP_REG:	(*this) << "__PD_RS";  break;
  case FP_REG:	(*this) << "__PD_FP";  break;
  case IP_REG:	(*this) << "__PD_IP";  break;
  case OP_REG:	(*this) << "__PD_OPS"; break;
  case LV_REG:	(*this) << "__PD_LV";  break;
  case LC_REG:	(*this) << "__PD_LC";  break;
  case ESC_REG:	(*this) << "__PD_ESC"; break;

  case RRB:             (*this) << "__PD_RRB";             break;
  case ALL_PRED:	(*this) << "__PD_ALL_PRED";        break;
  case ALL_ROT_PRED:    (*this) << "__PD_ALL_ROT_PRED";    break;
  case ALL_STATIC_PRED: (*this) << "__PD_ALL_STATIC_PRED"; break;


  case FLT_ZERO: (*this) << "__PD_FLT_ZERO"; break;
  case FLT_ONE:	 (*this) << "__PD_FLT_ONE";  break;
  case DBL_ZERO: (*this) << "__PD_DBL_ZERO"; break;
  case DBL_ONE:	 (*this) << "__PD_DBL_ONE";  break;
  case INT_ZERO: (*this) << "__PD_INT_ZERO"; break;

  case PRED_FALSE: (*this) << "__PD_PRED_F"; break;
  case PRED_TRUE:  (*this) << "__PD_PRED_T"; break;

  case SPILL_TEMPREG: (*this) << "__PD_TEMP_REG"; break;

  case PV_0: (*this) << "__PD_PV_0"; break;
  case PV_1: (*this) << "__PD_PV_1"; break;
  case PV_2: (*this) << "__PD_PV_2"; break;
  case PV_3: (*this) << "__PD_PV_3"; break;
  case PV_4: (*this) << "__PD_PV_4"; break;
  case PV_5: (*this) << "__PD_PV_5"; break;
  case PV_6: (*this) << "__PD_PV_6"; break;
  case PV_7: (*this) << "__PD_PV_7"; break;

  default:
    S_punt("Unkown macro name!");
    break;
  }
  return *this;
}


void streamBuffer::commit()
{
  char* b = (char *) buffer;
  if (b != NULL) {
    if (out == NULL) {
      S_punt("Attempting to dump stream to a null file pointer!");
    }
    
    (*out) << b;
  }

  out->flush();
  buffer.reset();
}


void streamBuffer::clear()
{
  buffer.reset();
}


void print_function_declaration(streamBuffer& out, hc_aggregate& aggr)
{
  char  out_buf[MAX_BUF_SIZE];
  char* call_info = aggr.call_info.strdup();

  sprint_C_prototype(out_buf, (char*)aggr.name, call_info);
  delete call_info;
  out << out_buf;
}


void print_KRC_vararg_function_dec(streamBuffer& out, hc_aggregate& func)
{
  char  out_buf[MAX_BUF_SIZE];
  char* call_info = func.call_info.strdup();

  sprint_KRC_prototype(out_buf, (char*)func.name, call_info);
  delete call_info;
  out << out_buf;
}
