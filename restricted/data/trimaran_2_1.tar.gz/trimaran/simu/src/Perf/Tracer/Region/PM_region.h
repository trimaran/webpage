/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File: PM_region.h
// Author: Rodric M. Rabbah
//
// The ReaCT-ILP Research Group may be contacted at react-ilp@cs.nyu.edu
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Description: The data structure for the tracer_window
///////////////////////////////////////////////////////////////////////////////

#ifndef PM_region_H
#define PM_region_H

#include "PM_Id.h"
#include "PM_hash_utilities.h"

#include "edge.h"

// elcor modules, for Rebel output
#include "ir_writer.h"
#include "el_data.h"

class PM_region; // forward class declaration
typedef Hash_map<PM_Id, PM_region*> regionList; 
typedef Hash_map_iterator<PM_Id, PM_region*> regionListIterator;
typedef Hash_map<int, Edge*> edgeList;

//////////////////////////////////////////////////////////////////
//  region class, rebel tree
//////////////////////////////////////////////////////////////////
enum regnDesc {_ABSTRACT, _FILE, _SUBFILE, _PROC, _DATA, _BB, _HB, _LOOP, _OP};

// converts a regnDesc to its string equivalent
ostream& operator << (ostream&, regnDesc); 

class PM_region
{
public:
    PM_region();
    virtual ~PM_region();

    PM_region& operator = (const PM_region&);

    //////////////////////////////////////////////////////////////////////
    // simple interface functions, provide access to private members
    //////////////////////////////////////////////////////////////////////
    inline void setType(regnDesc);
    inline void setAllRegion(bool);
    inline void setValidBit(bool);
    inline void setKey(PM_Id&);
    inline void setKey(int);
    
    inline regnDesc getType();
    inline bool     getAllBit();
    inline bool     getValidBit();
    inline PM_Id&   getKey();
    
    virtual inline  Region* getRebelRegion() { return NULL; }

    void bind(PM_region*);           // bind object to tree
    void addToValidMap(PM_region*);  // bind object to flatmap 
                                     //   (valid nodes list)

    bool isBound(PM_Id&);     // returns true if object is present in tree, 
                              //   otherwise false
    PM_region* value(PM_Id&); // returns the object if object is present 
                              //   in tree

    // returns true if object is present in tree and is valid, 
    // else false
    bool isValidAndBound(PM_Id&); 

    // returns the object if object is present in tree and is valid
    // else NULL
    PM_region* valid(PM_Id&);      

    // propagates a boolean value from a parent to all its 
    // children _validRegion field
    void propagate(bool);  

    // output the object's contents, use this to print
    // Elcor regions (to file when specified, else
    // prints to ostream)
    void print(ostream& = cout, IR_outstream* = NULL); 

    // Must be used on the tree root, to delete all allocated nodes
    // * deleting the nodes through the destructor is not
    // * safe, since the assignment operator does not allocate
    // * new nodes when copying regions.  When the root is no longer
    // * needed, deleteTree should be called to delete all related
    // * allocated memory.
    void deleteTree();

    friend ostream& operator<<(ostream&, PM_region&);

public:
    edgeList* fallEdges;    // list of all edges used to reach region
    edgeList* nonFallEdges; // list of all fall edges used to reach region

protected:
    regnDesc _regionType;
    bool     _allRegion;
    bool     _validRegion;
    PM_Id    _regionKey;    // hash key
  
    regionList* _regionMap; // all children of current node
    regionList* _flatMap;   // all valid children of current node

    virtual void printElcor(IR_outstream*, ostream&);

    friend class PM_region_iterator;         // iterator base class
    friend class PM_subRegion_iterator;      // iterate through _regionMap
    friend class PM_validSubRegion_iterator; // iterate through _flatMap
}; // end PM_region class


//////////////////////////////////////////////////////////////////////
//  Procedure, BB, HB, Loop_Body
//  User derrived classes should derive from this class
//////////////////////////////////////////////////////////////////////
class PM_CodeRegion : public PM_region
{
public:
    inline  PM_CodeRegion():_regionCode(NULL){};
    inline ~PM_CodeRegion(){};

    inline void setRebelPtr(Region* region) { _regionCode = region; }
    inline Region* getRebelRegion() { return _regionCode; }

protected:
    virtual void printElcor(IR_outstream*, ostream&);
    Region* _regionCode;  // pointer to Rebel Code Region
}; // end PM_CodeRegion

//////////////////////////////////////////////////////////////////////
//  Elcor Data section
//////////////////////////////////////////////////////////////////////
class PM_DataRegion : public PM_region
{
public:
    inline  PM_DataRegion():_regionData(NULL){};
    inline ~PM_DataRegion(){};

    inline void setRebelPtr(El_datalist* region) { _regionData = region; }

protected:
    virtual void printElcor(IR_outstream*, ostream&);
    El_datalist* _regionData; // pointer to Rebel Data Region
}; // end PM_DataRegion


//////////////////////////////////////////////////////////////////////
//  PM_region Iterators
//////////////////////////////////////////////////////////////////////
// base class iterator
class PM_region_iterator  
{
public:
    PM_region_iterator();
    PM_region_iterator(const regionList& list);

    void operator()(const regionList& list);

    ~PM_region_iterator();
  
    void operator++();
    void operator++(int);

    PM_region* operator*() { return subRegion; }

    bool operator == (int);
    bool operator != (int);

protected:
    regionList* list_ptr;
    regionListIterator iter;
    PM_region*  subRegion;
}; // end PM_region_iterator

// iterate through all children
class PM_subRegion_iterator : public PM_region_iterator
{
public:
    PM_subRegion_iterator();
    PM_subRegion_iterator(const PM_region& node);

    void operator()(const PM_region& node);

    ~PM_subRegion_iterator();
}; // end PM_subRegion_iterator

// iterate through all valid children
class PM_validSubRegion_iterator : public PM_region_iterator
{
public:
    PM_validSubRegion_iterator();
    PM_validSubRegion_iterator(const PM_region& node);

    void operator()(const PM_region& node);

    ~PM_validSubRegion_iterator();
}; // end PM_validSubRegion_iterator


//////////////////////////////////////////////////////////////////////
//  inline function implementation
//////////////////////////////////////////////////////////////////////
inline void PM_region::setType(regnDesc type) { _regionType = type; }
inline void PM_region::setAllRegion(bool bit) { _allRegion   = bit; }
inline void PM_region::setValidBit(bool bit)  { _validRegion = bit; }
inline void PM_region::setKey(PM_Id& id)      { _regionKey = id;    }
inline void PM_region::setKey(int id)         { _regionKey = id;    }

inline regnDesc PM_region::getType()      { return _regionType;  }
inline bool     PM_region::getAllBit()    { return _allRegion;   }
inline bool     PM_region::getValidBit()  { return _validRegion; }
inline PM_Id&   PM_region::getKey()       { return _regionKey;   }

#endif
