/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File: PM_filterator.cpp
// Author: Rodric M. Rabbah
//
// The ReaCT-ILP Research Group may be contacted at react-ilp@cs.nyu.edu
///////////////////////////////////////////////////////////////////////////////

#include "PM_filterator.h"
#include "PM_txtLexan.h"
#include "PM_binLexan.h"
#include "PM_assert.h"
#include "edge_utilities.h"
#include "PM_Id.h"

// flag indicating whether elcor environment has been setup
// for reading and writing
extern int PM_elcor_init;

template<class T> PM_filterator<T>::
PM_filterator(const traceFilter* filter, 
	      const bool verbose):
    filter_ptr(filter),
    currentProc(NULL), currentRegion(NULL), 
    stack(NULL), event(NULL)
{ 
    window = new PM_window<T>();

    if ( El_binary_trace_format ) 
	in = new PM_binLexan;
    else 
	in = new PM_txtLexan;

    initializeFilterator(0);
}

// T must be derived from PM_CodeRegion when filterConfigFile
// is specified
template<class T> PM_filterator<T>::
PM_filterator(char* filterConfigFile, 
	      const traceFilter* filter, 
	      const bool verbose):
    filter_ptr(filter),
    currentProc(NULL), currentRegion(NULL), 
    stack(NULL), event(NULL)
{ 
    window = new PM_window<T>(filterConfigFile, verbose);

    if ( El_binary_trace_format ) 
	in = new PM_binLexan;
    else 
	in = new PM_txtLexan;

    initializeFilterator(filterConfigFile != NULL);
}

template<class T> PM_filterator<T>::
PM_filterator(char* filterConfigFile, 
	      char* inputStream, 
	      const traceFilter* filter, 
	      const bool verbose):
    filter_ptr(filter),
    currentProc(NULL), currentRegion(NULL), 
    stack(NULL), event(NULL)
{
    window = new PM_window<T>(filterConfigFile, verbose);
    
    if ( El_binary_trace_format )
	in = new PM_binLexan(inputStream);
    else
	in = new PM_txtLexan(inputStream);

    initializeFilterator(filterConfigFile != NULL);
}

template<class T> void PM_filterator<T>::
operator()(const traceFilter* filter, 
	   const bool verbose)
{
    filter_ptr = filter;
    currentProc = currentRegion = NULL; event = NULL;

    delete window;
    window = new PM_window<T>();

    delete in;
    if ( El_binary_trace_format )
	in = new PM_binLexan;
    else
	in = new PM_txtLexan;

    initializeFilterator(0);
}

template<class T> void PM_filterator<T>::
operator()(char* filterConfigFile, 
	   const traceFilter* filter, 
	   const bool verbose)
{
    filter_ptr = filter;
    currentProc = currentRegion = NULL; event = NULL;

    delete window;
    window = new PM_window<T>(filterConfigFile, verbose);

    delete in;
    if ( El_binary_trace_format )
	in = new PM_binLexan;
    else
	in = new PM_txtLexan;

    initializeFilterator(filterConfigFile != NULL);
}

template<class T> void PM_filterator<T>::
operator()(char* filterConfigFile, 
	   char* inputStream, 
	   const traceFilter* filter, 
	   const bool verbose)
{
    filter_ptr = filter;
    currentProc = currentRegion = NULL; event = NULL;

    delete window;
    window = new PM_window<T>(filterConfigFile, verbose);

    delete in;
    if ( El_binary_trace_format )
	in = new PM_binLexan(inputStream);
    else
	in = new PM_txtLexan(inputStream);

    initializeFilterator(filterConfigFile != NULL);
}

template<class T>
PM_filterator<T>::~PM_filterator(void)
{
    // delete the event parser
    delete in;

    // delete the viewing window 
    delete window;

    // delete all remaining elements in the stack
    for (int i = 0; i < stack->size(); i++) {
	delete (stack->pop());
    }

    // now delete the stack
    delete stack;
}

template<class T>
void PM_filterator<T>::operator++(int)
{
    PM_filterator<T>::operator++();
}

template<class T>
void PM_filterator<T>::operator++(void)
{
    do {
	getNextEvent();
    } while 
	  (( PM_filterator<T>::operator!=(0) ) && 
	   ( ! filter_ptr->filter(*event) ) 
	  );
}

template<class T>
PM_event& PM_filterator<T>::operator*(void)
{
    return (*event);
}

template<class T>
bool PM_filterator<T>::operator==(int i)
{
    if ( i == 0 ) 
	return end_simulation;
    else
	return !end_simulation;
}

template<class T>
bool PM_filterator<T>::operator!=(int i)
{
    if ( i == 0 )
	return !end_simulation;
    else
	return end_simulation;
}

template<class T>
int PM_filterator<T>::initializeFilterator(const int windowInitialized)
{
    exitOP = 0;
    end_simulation = false;

    windowInit = windowInitialized;

    // initialize the stack with a "main" event
    // guards against popping an empty stack
    static stackElement* traceInitEntry = new stackElement;

    if (stack != NULL)
	delete stack;
    stack = new PM_stack<stackElement*>;
    stack->push(traceInitEntry);

    // precautionary measure
    if ( filter_ptr == NULL ) {
	if ( !windowInit ) filter_ptr = (traceFilter*) &defaultFilter;
	else filter_ptr = (traceFilter*) &defaultWindowFilter;
    }

    PM_filterator<T>::operator++();

    return true;
}

template<class T>
Region* PM_filterator<T>::get_Rebel_PROC(const eString& procName) const
{
    if ( windowInit )
	return ( window->get_Rebel_PROC(procName) );
    else return NULL;
}

template<class T>
Region* PM_filterator<T>::get_Rebel_CB(const eString& procName, const int blockId) const
{
    if ( windowInit )
	return ( window->get_Rebel_CB(procName, blockId) );
    else return NULL;
}

template<class T>
Region* PM_filterator<T>::get_Rebel_OP(const eString& procName, 
				       const int blockId, const int opId) const
{
    if ( windowInit )
	return ( window->get_Rebel_OP(procName, blockId, opId) );
    else return NULL;
}

template<class T>
void PM_filterator<T>::set_OP_Rebel_pointer(PM_event* current, int opId)
{
    // only interested in regions flagged as valid (part of viewing window)
    if ( currentRegion != NULL ) {
	current->node = currentRegion->valid(current->key);

        // if entry doesn't exist for valid block, create one
	// if the entire block is part of the viewing window
	if (current->node == NULL) {
	    if ( currentRegion->getAllBit() ) {
		current->node = new T;
	    
		current->node->setType(_OP);
		current->node->setAllRegion(true);
		current->node->setValidBit(true);
		current->node->setKey(opId);
	    
		eString procName = currentProc->getKey().stringVal();
		int     cbId     = currentRegion->getKey().idVal();
	    
		((PM_CodeRegion*) current->node)->setRebelPtr
		    ( get_Rebel_OP(procName, cbId, opId) );
	    
		// bind this entry to the valid map for possible
		// future lookups
		currentRegion->addToValidMap(current->node);
	    }
	}

	// if the rebel code pointer hasn't been set, then
	// set it for regions that are part of the viewing window.
        // this is done since the viewing window does not set the
        // rebel code pointers for operations specified by the 
	// configuration file
	else if ( (current->node->getRebelRegion() == NULL) ) {
	    eString procName = currentProc->getKey().stringVal();
	    int     cbId     = currentRegion->getKey().idVal();
	    
	    ((PM_CodeRegion*) current->node)->setRebelPtr
		( get_Rebel_OP(procName, cbId, opId) );
	}
    }
    
    else current->node = NULL;
}

template<class T>
Region* PM_filterator<T>::get_currentRebel_Region(void) const
{
    if ( event->node == NULL) 
	return NULL;
    
    return ( event->node->getRebelRegion() );
}

template<class T>
void PM_filterator<T>::dumpWindow(void)
{
    if ( windowInit )
	window->writeProfiledFiles();
}
  
template<class T>
int PM_filterator<T>::lastControlBlockVisited(void)
{
    return ( stack->top()->lastControlBlock.idVal() );
}

template<class T>
int PM_filterator<T>::lastValidControlBlockVisited(void)
{
    return ( stack->top()->lastValidControlBlock.idVal() );
}

template<class T>
Edge* PM_filterator<T>::findEdgeTaken(Region* child)
{
    if ( exitOP == FALL_THROUGH_OP ) {
	// procedure entry
	if ( lastControlBlockVisited() == PM_UNDEF_BLOCK_NUMBER )
	    return NULL;

	// if this has been encountered before, look it up in table
	else if ( currentProc->fallEdges->is_bound(child->id()) )
	    return currentProc->fallEdges->value(child->id());

	// otherwise, iterate through edges and and find edge taken
	else {
	    List<Edge*> childInEdges  = child->inedges();
	    List_iterator<Edge*> iter(childInEdges);
	    for ( ; iter != 0; iter++ )	{
		if ( is_fall_through(*iter) ) {
		    currentProc->fallEdges->bind(child->id(), *iter);
		    return (*iter);
		}
	    }

	    // no inedge found for corresponding fall through operation!
	    // Dynamic Trace error, Elcor error, or possibly a Profiler 
	    // error
	    cerr << "BB: " << child->id() << " OP: " << exitOP << endl;
	    PM_assert(0); 
	    return NULL; // to please the compiler, PM_assert exits
	}
    }

    else { // ( exitOP != FALL_THROUGH_OP )
	if ( currentProc->nonFallEdges->is_bound(exitOP) )
	    return currentProc->nonFallEdges->value(exitOP);

	else {
	    List<Edge*> childInEdges  = child->inedges();
	    List_iterator<Edge*> iter(childInEdges);
	    for ( ; iter != 0; iter++ )	{
		if ( (*iter)->src()->id() == exitOP ) {
		    currentProc->nonFallEdges->bind(exitOP, *iter);
		    return (*iter);
		}
	    }
		    
	    // no inedge found for corresponding exit operation!
	    // Dynamic Trace error, Elcor error, or possibly a Profiler 
	    // error
	    cerr << "BB: " << child->id() << " OP: " << exitOP << endl;
	    PM_assert(0); 
	    return NULL; // to please the compiler, PM_assert exits
	}
    }
} 

template<class T>
int PM_filterator<T>::getNextEvent(void)
{
    static PM_event_PE PEevent;  // procedure entry
    static PM_event_RT RTevent;  // procedure return

    static PM_event_BE BEevent;  // control block entry
    static PM_event_OE OEevent;  // operation entry
    static PM_event_ON ONevent;  // operation nullification

    static PM_event_LOAD  LDevent;  // load
    static PM_event_STORE STevent;  // store
    static PM_event_RW RWevent;  // register write

    static PM_event_ES ESevent;  // end of simulation 
    static PM_event_ES UKevent;  UKevent.type = _UK;// unknown event

    static int      lookAhead;

    lookAhead = in->getToken();
    switch ( lookAhead ) {
    case _PE : event = &PEevent; process( (PM_event_PE*) event ); break;
    case _RT : event = &RTevent; process( (PM_event_RT*) event ); break;

    case _BE : event = &BEevent; process( (PM_event_BE*) event ); break;
    case _OE : event = &OEevent; process( (PM_event_OE*) event ); break;
    case _ON : event = &ONevent; process( (PM_event_ON*) event ); break;

    case _LB : case _LH : case _LW : case _LS : case _LD :
	event = &LDevent; process( (PM_event_LOAD*) event, (eventType) lookAhead ); 
	break;

    case _SB : case _SH : case _SW : case _SS : case _SD :
	event = &STevent; process( (PM_event_STORE*) event, (eventType) lookAhead );
	break;

    case _RW : event = &RWevent; process( (PM_event_RW*) event ); break;

    case _ES : case _pmEOF : 
	event = &ESevent; process( (PM_event_ES*) event ); break;

    default  : event = &UKevent; break;
    }
  
    return true;
} // end 


/////////////////////////////////////////////////////////////////////////
// Handle a procedure entry event:
//    - recover PM_region node is present
//    - store info on stack to preserve current execution state
/////////////////////////////////////////////////////////////////////////
template<class T>
void PM_filterator<T>::process(PM_event_PE* current)
{
    current->type = _PE;
    (*in) >> (current->procName);
    current->key  = PM_Id::bindId(_PROCMAP, current->procName);

    // update stack with current event
    stackElement* newEvent = new stackElement;

    if ( windowInit )
	currentProc = window->validProcedure(current->key);
    else currentProc = NULL;

    newEvent->node = currentProc;
    newEvent->subRegion = currentProc;

    current->node  = currentProc;
    currentRegion  = currentProc;

    stack->push(newEvent);
    exitOP = 0;
}


/////////////////////////////////////////////////////////////////////////
// Handle a procedure return event:
//    - adjust stack to preserve current execution state
/////////////////////////////////////////////////////////////////////////
template<class T>
void PM_filterator<T>::process(PM_event_RT* current)
{
    current->type = _RT;

    // pop last procedure entry off stack
    delete (stack->pop());

    stackElement& prev = *(stack->top());
    currentProc   = prev.node;
    currentRegion = prev.subRegion;
    // currentRegion = currentProc;
}

/////////////////////////////////////////////////////////////////////////
// Sets End of Simulation flag
/////////////////////////////////////////////////////////////////////////
template<class T>
void PM_filterator<T>::process(PM_event_ES* current)
{
    current->type  = _ES;
    end_simulation = true;
}

/////////////////////////////////////////////////////////////////////////
// If this block is part of the viewing window, make it visible
// to the user, otherwise ignore it
/////////////////////////////////////////////////////////////////////////
template<class T>
void PM_filterator<T>::process(PM_event_BE* current)
{
    current->type = _BE;
    (*in) >> (current->id);
    (*in) >> exitOP;

    current->key = current->id;

    // only interested in regions flagged as valid (part of viewing window)
    // (note: when window has not been loaded, currentProc == NULL)
    if ( currentProc != NULL ) {
	static stackElement* previousProcedure;
	previousProcedure = stack->top();

	if ( (currentRegion = currentProc->valid(current->key)) != NULL ) {
	    previousProcedure->lastValidControlBlock = 
		previousProcedure->currentValidControlBlock; 
	    previousProcedure->currentValidControlBlock = current->id;
	}	  

	current->node = currentRegion;

	previousProcedure->subRegion = currentRegion;
	previousProcedure->lastControlBlock = 
	    previousProcedure->currentControlBlock; 
	previousProcedure->currentControlBlock = current->id;
    }

    else current->node = NULL;
}


/////////////////////////////////////////////////////////////////////////
// Operation Entry, this event is not generated by the simulator
/////////////////////////////////////////////////////////////////////////
template<class T>
void PM_filterator<T>::process(PM_event_OE* current)
{
    current->type = _OE;
    (*in) >> (current->id);

    current->key = current->id;
    set_OP_Rebel_pointer(current, current->id);
}

/////////////////////////////////////////////////////////////////////////
// When an Operation is Nullified, recover the node from the current
// block and set the rebel pointer.
// 
// If an entry doesn't exist in the tree, then is the event is to be
// captured (valid block), then create an entry for the current op
//
// This isn't done during window loading for efficiency
//
/////////////////////////////////////////////////////////////////////////
template<class T>
void PM_filterator<T>::process(PM_event_ON* current)
{
    current->type = _ON;
    (*in) >> (current->id);

    current->key = current->id;
    set_OP_Rebel_pointer(current, current->id);
}

/////////////////////////////////////////////////////////////////////////
// Miscelaneuos Memory tracking events
/////////////////////////////////////////////////////////////////////////
template<class T>
void PM_filterator<T>::process(PM_event_LOAD* current, eventType event)
{
    current->type = event;
    (*in) >> (current->id);
    (*in) >> (current->address);
    (*in) >> (current->time);

    current->key = current->id;
    set_OP_Rebel_pointer(current, current->id);
}

template<class T>
void PM_filterator<T>::process(PM_event_STORE* current, eventType event)
{
    current->type = event;
    (*in) >> (current->id);
    (*in) >> (current->address);
    (*in) >> (current->time);

    current->key = current->id;
    set_OP_Rebel_pointer(current, current->id);
}

template<class T>
void PM_filterator<T>::process(PM_event_RW* current)
{
    current->type = _RW;
    (*in) >> (current->regFile);
    (*in) >> (current->regNum);
  
    static int i; (*in) >> i; 
    current->regType = (PM_event_RW::reg) i;

    (*in) >> (current->val); 
    
    // this event is not yet generated by the simulator
}


/////////////////////////////////////////////////////////////////////
// prints usefull information when true or 
// operates silently when false
/////////////////////////////////////////////////////////////////////
template<class T>
void PM_filterator<T>::setVerboseMode(const bool option)
{
    window->setVerboseMode(option);
}

