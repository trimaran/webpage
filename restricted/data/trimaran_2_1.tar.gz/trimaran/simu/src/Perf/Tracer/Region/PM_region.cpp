/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File: PM_region.cpp
// Author: Rodric M. Rabbah
//
// The ReaCT-ILP Research Group may be contacted at react-ilp@cs.nyu.edu
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////
// provides I/O for PM_region and derived classes
///////////////////////////////////////////////////////////////////////////

#include "PM_region.h"
#include "PM_assert.h"

#include "IR_instream.h"

// null constructor
PM_region::PM_region(void): 
    _regionType(_ABSTRACT), _allRegion(true), _validRegion(false)
{
    _regionMap  = new Hash_map<PM_Id, PM_region*>(hash_Id,MAX); 
    _flatMap    = new Hash_map<PM_Id, PM_region*>(hash_Id,MAX);

    fallEdges    = new Hash_map<int, Edge*>(hash_int, MAX);
    nonFallEdges = new Hash_map<int, Edge*>(hash_int, MAX);
}
  
// destructor
PM_region::~PM_region(void)
{ 

    delete _regionMap; 
    delete _flatMap;

    delete fallEdges;
    delete nonFallEdges;
}

// assign region to this
PM_region& PM_region::operator = (const PM_region& region)
{
    if (this == &region) 
	return (*this);

    delete _regionMap;
    delete _flatMap;
    delete fallEdges;
    delete nonFallEdges;

    _regionType  = region._regionType;
    _allRegion   = region._allRegion;
    _validRegion = region._validRegion;
    _regionKey   = region._regionKey;

    // This isn't a safe copy routine of the hash_maps. 
    // New regions are not allocated, since the cost may be too 
    // expensive - rather addresses are copied.  
    // Use deleteTree() to free allocated memory when a root 
    // node is no longer needed
    _regionMap  = new Hash_map<PM_Id, PM_region*>(*(region._regionMap)); 
    _flatMap    = new Hash_map<PM_Id, PM_region*>(*(region._flatMap));
    
    fallEdges    = new Hash_map<int, Edge*>(*(region.fallEdges));
    nonFallEdges = new Hash_map<int, Edge*>(*(region.nonFallEdges));

    return (*this);
}

///////////////////////////////////////////////////////////////
// binds PM_region* to hashMap, with PM_Id as the
// hashing key
///////////////////////////////////////////////////////////////
void PM_region::bind(PM_region* region)
{ 
    _regionMap->bind(region->_regionKey, region); 
}

void PM_region::addToValidMap(PM_region* region)
{ 
    _flatMap->bind(region->_regionKey, region); 
}

///////////////////////////////////////////////////////////////
// if the object bound by PM_Id& is found in
// _regionMap, then a pointer to that object
// is returned, otherwise NULL is returned
///////////////////////////////////////////////////////////////
PM_region* PM_region::value(PM_Id& key) 
{
    if ( _regionMap->is_bound(key) )
	return _regionMap->value(key);
  
    else return NULL;
}

///////////////////////////////////////////////////////////////
// Must be used on the tree root, to delete all allocated nodes
// Deleting the nodes through the destructor is not
// safe, since the assignment operator does not allocate
// new nodes when copying regions.  When the root is no longer
// needed, deleteTree should be called to delete all related
// allocated memory.
///////////////////////////////////////////////////////////////
void PM_region::deleteTree(void)
{
    // iterate through the _regionMap and delete the respective
    // nodes - since the _flatMap is a subset of the addresses
    // bound in the _regionMap, iterating through the _flatMap
    // is not necessary
    Hash_map_iterator<PM_Id, PM_region*> child(*_regionMap); 
    for ( ; child != 0; child++ ) {
	 PM_region* node = (*child).second;

	 node->deleteTree();
	 delete node;
    }
}

///////////////////////////////////////////////////////////////
// if the object bound by PM_Id& is found in current object's
// _flatMap, then a pointer to that object
// is returned, otherwise NULL is returned
///////////////////////////////////////////////////////////////
PM_region* PM_region::valid(PM_Id& key) 
{
    if ( _flatMap->is_bound(key) )
	return _flatMap->value(key);
  
    else return NULL;
}

///////////////////////////////////////////////////////////////
// propagate bit to all of current parent's children
///////////////////////////////////////////////////////////////
void PM_region::propagate(bool bit)
{
    PM_region* tmp_ptr;
    Hash_map_iterator<PM_Id, PM_region*> child(*_regionMap); 

    for ( ; child != 0; child++ ) {
	tmp_ptr = (*child).second;

	switch ( tmp_ptr->_regionType ) {
        // currently ignoring data regions	    
	case _DATA: break; 

	case _BB: case _HB: tmp_ptr->_validRegion = bit;
	    break; // current implementation ensures that
	    // these are the leafs of the tree
	    
	case _SUBFILE: case _PROC: case _LOOP:
	    tmp_ptr->_validRegion = bit;
	    tmp_ptr->propagate(bit);
	    break;
	    
	default: PM_assert(0);
	}
    }
} // end propagate


//////////////////////////////////////////////////////////////////////
// I/O routines
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// converts the region descriptor to its string equivalent
//////////////////////////////////////////////////////////////////////
ostream& operator << (ostream& os, regnDesc x)
{
    switch ( x ) {
    case _FILE:    os << "FILE";      break;
    case _SUBFILE: os << "SUBFILE";   break;
    case _PROC:    os << "PROC";      break;
    case _BB:      os << "BB";        break;
    case _HB:      os << "HB";        break;
    case _LOOP:    os << "Loop_Body"; break;
    case _OP:      os << "OP";        break;
    case _DATA:    os << "DATA";      break;
    default:       os << "UNKNOWN";   break;
    }

    return os;
}


//////////////////////////////////////////////////////////////////////
// invokes the ir_writer to output the regionCode to 
// profile_El_OUT_STREAM
//////////////////////////////////////////////////////////////////////
void PM_CodeRegion::printElcor(IR_outstream* profile_El_OUT_STREAM,
			       ostream& os)
{
    if (_regionCode == NULL) return;
    else if ( profile_El_OUT_STREAM == NULL )
	os << *_regionCode;
    else ir_write(*profile_El_OUT_STREAM, _regionCode);
}


//////////////////////////////////////////////////////////////////////
// invokes the ir_writer to output the regionCode to 
// profile_El_OUT_STREAM
//////////////////////////////////////////////////////////////////////
void PM_DataRegion::printElcor(IR_outstream* profile_El_OUT_STREAM, 
			       ostream& os)
{
    if (_regionData == NULL) return;
    else if ( profile_El_OUT_STREAM == NULL )
	os << "Rebel Data Regions are only printed to file!" 
	   << endl;
    else ir_write(*profile_El_OUT_STREAM, _regionData);
}

//////////////////////////////////////////////////////////////////////
// base class printElcor 
//////////////////////////////////////////////////////////////////////
void PM_region::printElcor(IR_outstream* profile_El_OUT_STREAM, ostream& os)
{
    // to please the compiler
    if ( (profile_El_OUT_STREAM == NULL) || (&os == NULL) )
	return;
}

//////////////////////////////////////////////////////////////////////
// output the region members
//////////////////////////////////////////////////////////////////////
void PM_region::print(ostream& os, IR_outstream* profile_El_OUT_STREAM)
{
    if (profile_El_OUT_STREAM == NULL)
	os << "Printing Rebel for " << _regionType << " " << _regionKey 
	   << endl;

    (*this).printElcor(profile_El_OUT_STREAM, os);
}

ostream& operator << (ostream& os, PM_region& region)
{
    region.print(os);
    return os;
}

//////////////////////////////////////////////////////////////////////
//  iterators
//////////////////////////////////////////////////////////////////////
PM_region_iterator::PM_region_iterator(void): 
    list_ptr(NULL), subRegion(NULL)
{
    // NULL;
}

PM_region_iterator::PM_region_iterator(const regionList& list):
    list_ptr( (regionList*) &list)
{
    iter.operator()(list);
    if ( iter != 0 ) subRegion = iter.operator*().second;
    else subRegion = NULL;
}

void PM_region_iterator::operator()(const regionList& list)
{
    list_ptr = (regionList*) &list;
    iter.operator()(list);
    if ( iter != 0 ) subRegion = iter.operator*().second;
    else subRegion = NULL;
}


PM_region_iterator::~PM_region_iterator(void)
{
    // NULL
}

void PM_region_iterator::operator++(void)
{
    iter++;
    if ( iter != 0 ) subRegion = iter.operator*().second;
    else subRegion = NULL;
}


void PM_region_iterator::operator++(int) 
{
    operator++();
}

bool PM_region_iterator::operator==(int)
{
    return ( iter == 1 );
}

bool PM_region_iterator::operator!=(int)
{
    return ( iter != 0 );
}


//////////////////////////////////////////////////////////////////////
//  subRegion iterator
//////////////////////////////////////////////////////////////////////
PM_subRegion_iterator::PM_subRegion_iterator(void){}
PM_subRegion_iterator::~PM_subRegion_iterator(void){}

PM_subRegion_iterator::PM_subRegion_iterator(const PM_region& node):
    PM_region_iterator(*(node._regionMap)){}

void PM_subRegion_iterator::operator()(const PM_region& node)
{
    PM_region_iterator(*(node._regionMap));
}

//////////////////////////////////////////////////////////////////////
//  valid subRegion iterator
//////////////////////////////////////////////////////////////////////
PM_validSubRegion_iterator::PM_validSubRegion_iterator(void){}
PM_validSubRegion_iterator::~PM_validSubRegion_iterator(void){}

PM_validSubRegion_iterator::PM_validSubRegion_iterator(const PM_region& node):
    PM_region_iterator(*(node._flatMap)){}

void PM_validSubRegion_iterator::operator()(const PM_region& node)
{
    PM_region_iterator(*(node._flatMap));
}




