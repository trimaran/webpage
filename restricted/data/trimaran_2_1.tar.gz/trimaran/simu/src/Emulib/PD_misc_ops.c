/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/******************************************************************************
 * File:    PD_misc_ops.c
 * Authors: Rodric M. Rabbah, Amit Nene
 *****************************************************************************/

/*************************************************************************/
/*      Description: Miscellaneous operations                            */
/*      Note:        Tracing and Statistics related operations           */
/*************************************************************************/

#include "PD.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <stdarg.h>

enum __PD_event
{
  __PD_proc_entry = 1,
  __PD_proc_ret = 2,
  __PD_end = 3,
  __PD_cb_entry = 4,
  __PD_load_B = 5,
  __PD_load_H = 6,
  __PD_load_W = 7,
  __PD_load_S = 8,
  __PD_load_D = 9,
  __PD_store_B = 10,
  __PD_store_H = 11,
  __PD_store_W = 12,
  __PD_store_S = 13,
  __PD_store_D = 14,
  __PD_op_entry   = 15,
  __PD_op_nullify = 16,
  __PD_longjmp_entry = 17
};

#define push(v)               *__PD_hack_stack++ = v
#define pop()                 *(--__PD_hack_stack)

/* this is the linked list of tables for statistic tracking */
static struct __PD_table_list *__PD_stats_head_node = NULL;


#ifdef _FULL_SPECULATION_SUPPORT_
# define _SPECULATION_SUPPORT_
#endif /* _FULL_SPECULATION_SUPPORT_ */

#ifdef _SPECULATION_SUPPORT_
  enum __PD_SECULATIVE_TAG_HANDLE { __PD_SAVE, __PD_RESTORE, __PD_RESET };
  void __PD_preserve_speculative_bits(enum __PD_SECULATIVE_TAG_HANDLE);
#endif /* _SPECULATION_SUPPORT_ */

/* error handling routine */
void __PD_error(char*, ...);


/* No operation 
 */
void __PD_NO_OP(__PD_OP *op)
{
}

/* set current stats ptr 
 */
void __PD_set_stat_ptr(struct __PD_OP *op)
{
  __PD_cur_stats = (struct __PD_stats *) LIT(op->src[1]);
  __PD_cur_stats->freq++;
}

/* PM event generator for procedure entry 
 */
void __PD_start_procedure(__PD_OP *op)
{
  __PD_current_function = (char *) LIT(op->src[0]);

  if (__PD_params_vals->control_flow_trace)
    __PD_trace_proc(op);
  
  if (__PD_params_vals->dynamic_stats)
    __PD_set_stat_ptr(op);
}

/* PM event generator for all other compound region entries 
 */
void __PD_start_compound(__PD_OP *op) 
{
  if (__PD_params_vals->control_flow_trace) {
    __PD_trace_cb(op);
    __PD_edge = 0;
  }
  
  if (__PD_params_vals->dynamic_stats)
    __PD_set_stat_ptr(op);
}

/* hack: function entry code 
 * All sources are literal values - size of the stack to allocate
 */
void __PD_prologue(__PD_OP *op) 
{
  unsigned long current_sp;

#ifdef _SETJMP_LONGJMP_SUPPORT_
  __PD_SL_increment_longjump_depth_count();
#endif /* _SETJMP_LONGJMP_SUPPORT_ */

  /* save the current base pointer into the internal data stack */
  push((unsigned long) __PD_hack_stack_base);
  
  /* update the base data stack pointer */
  __PD_hack_stack_base = __PD_hack_stack;

  /* so that the stack's integrity can be verified, push the
   * base pointer again, later will check that the popped value
   * is the same as the current base pointer
   */
  push((unsigned long) __PD_hack_stack_base);

  /* save the current function name */
  push((unsigned long) __PD_current_function);

  push(__PD_REGISTERS[__PD_LV ]->reg.cr);
  push(__PD_REGISTERS[__PD_OPS]->reg.cr);
  push(__PD_REGISTERS[__PD_RS ]->reg.cr);
  push(__PD_REGISTERS[__PD_IP ]->reg.cr);

  push(__PD_REGISTERS[__PD_LC ]->reg.cr);
  push(__PD_REGISTERS[__PD_ESC]->reg.cr);
  push(__PD_REGISTERS[__PD_RRB]->reg.cr);

  /* vararg hack, must save the ap_start address on function calls 
   * since the address holder is not really part of the simulation
   * ennvironemnt
   */
  push(__PD_VAR_ap_list_start.reg.cr);

#ifdef _SPECULATION_SUPPORT_
  push(__PD_exception_raised);
#endif /* _SPECULATION_SUPPORT_ */

  current_sp = __PD_REGISTERS[__PD_SP]->reg.cr;

  __PD_REGISTERS[__PD_RS ]->reg.cr = current_sp;
  __PD_REGISTERS[__PD_SP ]->reg.cr = current_sp + LIT(op->src[0]);

  current_sp = __PD_REGISTERS[__PD_SP]->reg.cr;

  if (current_sp >= __PD_STACK_LIMIT) {
    __PD_error("STACK overflow");
  }

  __PD_REGISTERS[__PD_OPS]->reg.cr = current_sp + LIT(op->src[1]);
  __PD_REGISTERS[__PD_LV ]->reg.cr = current_sp + LIT(op->src[2]);
  __PD_REGISTERS[__PD_IP ]->reg.cr = current_sp + LIT(op->src[3]);

#ifdef _SPECULATION_SUPPORT_
  /* need to save the speculative bits on all registers */
  if (op->Mask) {
    __PD_preserve_speculative_bits(__PD_SAVE);
  }
#endif /* _SPECULATION_SUPPORT_ */
}

/* hack: function exit code
 * source is a literal value - size of the stack to pop
 */
void __PD_epilogue(__PD_OP *op) {
  unsigned long* tmp_base_ptr;

#ifdef _SETJMP_LONGJMP_SUPPORT_
  __PD_SL_decrement_longjump_depth_count();
#endif /* _SETJMP_LONGJMP_SUPPORT_ */

#ifdef _SPECULATION_SUPPORT_
  /* need to restore the speculative bits on all registers */
  if (op->Mask) {
    __PD_preserve_speculative_bits(__PD_RESTORE);
  }
  __PD_exception_raised             = pop();
#endif /* _SPECULATION_SUPPORT_ */

  __PD_VAR_ap_list_start.reg.cr     = pop();
  __PD_REGISTERS[__PD_RRB]->reg.cr  = pop();
  __PD_REGISTERS[__PD_ESC]->reg.cr  = pop();
  __PD_REGISTERS[__PD_LC ]->reg.cr  = pop();
  
  __PD_REGISTERS[__PD_IP ]->reg.cr  = pop();
  __PD_REGISTERS[__PD_RS ]->reg.cr  = pop();
  __PD_REGISTERS[__PD_OPS]->reg.cr  = pop();
  __PD_REGISTERS[__PD_LV ]->reg.cr  = pop();

  __PD_REGISTERS[__PD_SP ]->reg.cr -= LIT(op->src[0]);

  /* restore the current function name */
  __PD_current_function = (char*) pop();

  /* verify internal stack integrity */
  tmp_base_ptr = (unsigned long*) pop();
  if (tmp_base_ptr != __PD_hack_stack_base) {
    __PD_error("Internal Stack Integrity compremised!");
  }
  else {
    __PD_hack_stack_base = (unsigned long*) pop();
  }
}

#ifdef _SPECULATION_SUPPORT_
void __PD_preserve_speculative_bits(enum __PD_SECULATIVE_TAG_HANDLE method)
{
  int  i, tr, total_regs;
  int* spill_buf = NULL;

  /* compute the total number of registers */
  tr = __PD_GPR_NUM + __PD_FPR_NUM + __PD_BTR_NUM + __PD_PR_NUM  + __PD_CR_NUM;
  total_regs = tr;

  switch (method) {
  case __PD_SAVE: {
    spill_buf  = (int*) malloc(sizeof(int) * total_regs);
    
    if (spill_buf == NULL) {
      __PD_error("Could not allocate memory to save Speculative Tags!");
    }

    for (i = 0; i < total_regs; i++) {
      /* save the tag bit */
      spill_buf[i] = __PD_REGISTERS[0][i].speculative_tag;
      
      /* reset the tag bit */
      __PD_REGISTERS[0][i].speculative_tag = 0;
    }
    
    /* if spilling the tags, push the address of the buffer to the stack */
    push((unsigned long) spill_buf);
  } break;
  
  case __PD_RESTORE: {
    spill_buf = (int*) pop();
    
    if (spill_buf == NULL) {
      __PD_error("received a NULL pointer while restoring Speculative Tags!");
    }

    for (i = 0; i < total_regs; i++) {
      /* restore the tag bit */
      __PD_REGISTERS[0][i].speculative_tag = spill_buf[i];
    }
    
    /* free the allocated memory */
    free (spill_buf);
  } break;

  case __PD_RESET: {
    for (i = 0; i < total_regs; i++) {
      /* reset the tag bit */
      __PD_REGISTERS[0][i].speculative_tag = 0;
    }
  } break;
  
  default: __PD_error("Unrecognized Speculative Tag handle method!");
  }
}
#endif /* _SPECULATION_SUPPORT_ */


/*** Trace generators ****/

/* procedure entry router 
 */
void __PD_trace_proc(__PD_OP *op)
{
  int packet;
  
  if (!__PD_params_vals->binary_trace_format) {
    fprintf((FILE *) __PD_trace_file, "p %s\n", (char *) LIT(op->src[0]));
  }
  else {
    packet = __PD_proc_entry;
    fwrite(&packet, sizeof(int), 1, (FILE *) __PD_trace_file);
    fprintf((FILE *) __PD_trace_file, "%s ", (char *) LIT(op->src[0]));
  }
}

/* procedure return router 
 */
void __PD_trace_ret(__PD_OP *op)
{
  int packet;

  if (!__PD_params_vals->binary_trace_format) 
    fprintf((FILE *) __PD_trace_file, "^\n");
  else {
    packet = __PD_proc_ret;
    fwrite(&packet, sizeof(int), 1, (FILE *) __PD_trace_file);
  }
}

/* end of simulation 
 */
void __PD_trace_endsim(__PD_OP *op)
{
  static int abort = 0;
  int packet;

  if (abort) {
    __PD_error("end of simulation encountered twice");
  }

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, ".\n");
  else {
    packet = __PD_end;
    fwrite(&packet, sizeof(int), 1, (FILE *) __PD_trace_file);
  }
  
  abort = 1;
}

/* control block entry router 
 */
void __PD_trace_cb(__PD_OP *op)
{
  int packet[3];

  /* note : __PD_edge holds the last exit edge taken */
  if (!__PD_params_vals->binary_trace_format) {
    fprintf((FILE *) __PD_trace_file, "c %d %d\n", op->Rebel_id, __PD_edge);
  }
  else {
    packet[0] = __PD_cb_entry;
    packet[1] = op->Rebel_id;
    packet[2] = __PD_edge;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
  }
}

#ifdef _SPECULATION_SUPPORT_
void __PD_trace_longjmp(__PD_OP *op)
{
  int packet;

  if (!__PD_params_vals->binary_trace_format) {
    fprintf((FILE *) __PD_trace_file, "j %s %d\n", __PD_current_function, op->Rebel_id);
  }
  else {
    packet = __PD_longjmp_entry;
    fwrite(&packet, sizeof(int), 1, (FILE *) __PD_trace_file);
    fprintf((FILE *) __PD_trace_file, "%s ", __PD_current_function);
    packet = op->Rebel_id;
    fwrite(&packet, sizeof(int), 1, (FILE *) __PD_trace_file);
  }
}
#endif /* _SPECULATION_SUPPORT_ */

/* operation entry : currently unused 
 */
void __PD_trace_op(__PD_OP *op)
{
  int packet[2];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "o %d\n", op->Rebel_id);
  else {
    packet[0] = __PD_op_entry;
    packet[1] = op->Rebel_id;
    fwrite(&packet[0], sizeof(int), 2, (FILE *) __PD_trace_file);
  }
}

/* operation nullification event 
 */
void __PD_trace_op_null(__PD_OP *op)
{
  int packet[2];
  
  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "! %d\n", op->Rebel_id);
  else {
    packet[0] = __PD_op_nullify;
    packet[1] = op->Rebel_id;
    fwrite(&packet[0], sizeof(int), 2, (FILE *) __PD_trace_file);
  }
}

/* load byte 
 */
void __PD_trace_load_B(__PD_OP *op)
{
  int packet[3];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "LB %u %x %.2f\n", op->Rebel_id,
	    (unsigned int) REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_load_B;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, (FILE *) __PD_trace_file);
  }
}

/* load half word 
 */
void __PD_trace_load_H(__PD_OP *op)
{
  int packet[3];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "LH %u %x %.2f\n", op->Rebel_id,
	    (unsigned int) REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_load_H;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, 
	   (FILE *) __PD_trace_file);
  }
}

/* load word 
 */
void __PD_trace_load_W(__PD_OP *op)
{
  int packet[3];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "LW %u %x %.2f\n", op->Rebel_id,
	    (unsigned int) REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_load_W;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, 
	   (FILE *) __PD_trace_file);
  }
}

/* load float 
 */
void __PD_trace_load_S(__PD_OP *op)
{
  int packet[3];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "LS %u %x %.2f\n", op->Rebel_id,
	    (unsigned int) REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_load_S;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, 
	   (FILE *) __PD_trace_file);
  }
}

/* load double 
 */
void __PD_trace_load_D(__PD_OP *op)
{
  int packet[3];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "LD %u %x %.2f\n", op->Rebel_id,
	   (unsigned int)  REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_load_D;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, 
	   (FILE *) __PD_trace_file);
  }
}

/* store byte 
 */
void __PD_trace_store_B(__PD_OP *op)
{
  int packet[3];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "SB %u %x %.2f\n", op->Rebel_id,
	    (unsigned int) REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_store_B;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, 
	   (FILE *) __PD_trace_file);
  }
}

/* store half word 
 */
void __PD_trace_store_H(__PD_OP *op)
{
  int packet[3];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "SH %u %x %.2f\n", op->Rebel_id,
	    (unsigned int) REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_store_H;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, 
	   (FILE *) __PD_trace_file);
  }
}

/* store word 
 */
void __PD_trace_store_W(__PD_OP *op)
{
  int packet[3];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "SW %u %x %.2f\n", op->Rebel_id,
	    (unsigned int) REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_store_W;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, 
	   (FILE *) __PD_trace_file);
  }
}

/* store float 
 */
void __PD_trace_store_S(__PD_OP *op)
{
  int packet[3];
  
  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "SS %u %x %.2f\n", op->Rebel_id,
	    (unsigned int) REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_store_S;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, 
	   (FILE *) __PD_trace_file);
  }
}

/* store double 
 */
void __PD_trace_store_D(__PD_OP *op)
{
  int packet[3];

  if (!__PD_params_vals->binary_trace_format)
    fprintf((FILE *) __PD_trace_file, "SD %u %x %.2f\n", op->Rebel_id,
	    (unsigned int) REG(op->src[0])->reg.gpr, __PD_GLOBAL_CLOCK);
  else {
    packet[0] = __PD_store_D;
    packet[1] = op->Rebel_id;
    packet[2] = REG(op->src[0])->reg.gpr;
    fwrite(&packet[0], sizeof(int), 3, (FILE *) __PD_trace_file);
    fwrite(&__PD_GLOBAL_CLOCK, sizeof(__PD_GLOBAL_CLOCK), 1, 
	   (FILE *) __PD_trace_file);
   }
}

/*** Statistics related functions ***/

/* actions to be taken on operation nullification 
 */
void __PD_op_null_action(__PD_OP *op)
{
  if (__PD_params_vals->control_flow_trace)
    __PD_trace_op_null(op);

  if (__PD_params_vals->dynamic_stats)
    __PD_cur_stats->nullified++;
}


/* update statistics while executing  
 * NOTE that predicate spill operations such as RESTORE, SAVE 
 * are accounted for in the calculated statistics but are not
 * part of the generated trace. 
 * Trace instructions can be added to the predicate operations
 * in ops.list 
 */
void __PD_update_stats(__PD_OP *op)
{
  enum __PD_op_type type;
  
  type = op->type & __PD_mask;
  if (type == __PD_pseudo) return;

  switch(type) {
  case __PD_branch:
    __PD_cur_stats->branch++;
    break;
  case __PD_load:
    __PD_cur_stats->load++;
    break;
  case __PD_store:
    __PD_cur_stats->store++;
    break;
  case __PD_ialu:
    __PD_cur_stats->ialu++;
    break;
  case __PD_falu:
    __PD_cur_stats->falu++;
    break;
  case __PD_cmpp:
    __PD_cur_stats->cmpp++;
    break;
  case __PD_pbr:
    __PD_cur_stats->pbr++;
    break;
  default:
    break;
  }
  
  if (op->type & __PD_caller_spill)       __PD_cur_stats->caller_spill++;
  else if (op->type & __PD_callee_spill)  __PD_cur_stats->callee_spill++;
  
  __PD_cur_stats->ops++;
}


/* chains all the tables initialized
 */
void __PD_chain(struct __PD_stats *link)
{
  struct __PD_table_list* temp;
  struct __PD_table_list* ptr;

  /* this should be a hash function! */
  for (ptr = __PD_stats_head_node; ptr != 0 ; ptr = ptr->next) {
    /* already bound */
    if (ptr->link == link) return;
  }
  
  /* new procedure, bind entry */
  temp = (struct __PD_table_list *) malloc(sizeof(struct __PD_table_list));
  temp->link = link;
  temp->next = __PD_stats_head_node;
  __PD_stats_head_node = temp;
}


/* adding utility 
 */
static void sumup(struct __PD_stats* proc_stats, struct __PD_stats* stats)
{
  /* the dynamic part */
  proc_stats->branch    += stats->branch;
  proc_stats->load      += stats->load;
  proc_stats->store     += stats->store;
  proc_stats->ialu      += stats->ialu;
  proc_stats->falu      += stats->falu;
  proc_stats->cmpp      += stats->cmpp;
  proc_stats->pbr       += stats->pbr;
  proc_stats->nullified += stats->nullified;
  proc_stats->ops       += stats->ops;
  proc_stats->caller_spill += stats->caller_spill;
  proc_stats->callee_spill += stats->callee_spill;
  proc_stats->dyn_cyc      += stats->dyn_cyc;

  /* the static part */
  proc_stats->Static_branch += stats->Static_branch;
  proc_stats->Static_load   += stats->Static_load;
  proc_stats->Static_store  += stats->Static_store;
  proc_stats->Static_ialu   += stats->Static_ialu;
  proc_stats->Static_falu   += stats->Static_falu;
  proc_stats->Static_cmpp   += stats->Static_cmpp;
  proc_stats->Static_pbr    += stats->Static_pbr;
  proc_stats->Static_ops    += stats->Static_ops;
  proc_stats->Static_caller_spill += stats->Static_caller_spill;
  proc_stats->Static_callee_spill += stats->Static_callee_spill;
}


/* print statistics to file 
 */
static void print_summary(struct __PD_stats *stats, bool is_proc)
{
  double sum;
  FILE*  outbuf = (FILE*) __PD_stats_file;

  if (!is_proc) {
    fprintf(outbuf, "\t\t%s", stats->id);
    fprintf(outbuf, "\tdyn cyc:\t%.2f\tsched len:\t%d\n",
	    stats->dyn_cyc, stats->sched_len);
  }

  if (!is_proc) return; 
  
  fprintf(outbuf, "\tDynamic_total_cycles:\t%.2f\n", 
	  stats->dyn_cyc);
  fprintf(outbuf, "\t\tDynamic_total_compute_cycles:\t%.2f\n",
	  stats->dyn_cyc);
  fprintf(outbuf, "\t\tDynamic_scalar_compute_cycles:\t0.00 (0.00)\n");
  fprintf(outbuf, "\t\tDynamic_loop_compute_cycles:\t0.00 (0.00)\n");
  
  /* Dynamic instruction mix */
  fprintf(outbuf, "\tDynamic_total_operations:\t%.2f\n", stats->ops);

  /* avoid div by zero */
  if (stats->ops < 0.5) stats->ops = 1.0; 

  fprintf(outbuf, "\t\tDynamic_branch:\t%.2f\t(%.2f)\n",
	  stats->branch,100 * stats->branch / stats->ops);
  fprintf(outbuf, "\t\tDynamic_load:\t%.2f\t(%.2f)\n",
	  stats->load,  100 * stats->load   / stats->ops);
  fprintf(outbuf, "\t\tDynamic_store:\t%.2f\t(%.2f)\n",
	  stats->store, 100 * stats->store  / stats->ops);
  fprintf(outbuf, "\t\tDynamic_ialu:\t%.2f\t(%.2f)\n",
	  stats->ialu, 100 * stats->ialu / stats->ops);
  fprintf(outbuf, "\t\tDynamic_falu:\t%.2f\t(%.2f)\n",
	  stats->falu, 100 * stats->falu / stats->ops);
  fprintf(outbuf, "\t\tDynamic_cmpp:\t%.2f\t(%.2f)\n",
	  stats->cmpp, 100 * stats->cmpp / stats->ops);
  fprintf(outbuf, "\t\tDynamic_pbr:\t%.2f\t(%.2f)\n",
	  stats->pbr, 100 * stats->pbr / stats->ops);
  
  /* other dynamic */
  /* avoid div by zero */
  if (stats->dyn_cyc < 0.5) stats->dyn_cyc = 1.0; 
  fprintf(outbuf, "\tDynamic_average_issued_ops/cycle:\t%.2f\n",
	  stats->ops / stats->dyn_cyc);
  
  /* Static instruction Mix */
  fprintf(outbuf, "\tStatic_total_operations:  %.2f\n", stats->Static_ops);
  /* avoid div by zero */
  if (stats->Static_ops < 0.5) stats->Static_ops = 1.0; 
  fprintf(outbuf, "\t\tStatic_branch:\t%.2f\t(%.2f)\n",
	  stats->Static_branch, 100 * stats->Static_branch/stats->Static_ops);
  fprintf(outbuf, "\t\tStatic_load:\t%.2f\t(%.2f)\n",
	  stats->Static_load,  100 * stats->Static_load/stats->Static_ops);
  fprintf(outbuf, "\t\tStatic_store:\t%.2f\t(%.2f)\n",
	  stats->Static_store, 100 * stats->Static_store/stats->Static_ops);
  fprintf(outbuf, "\t\tStatic_ialu:\t%.2f\t(%.2f)\n",
	  stats->Static_ialu, 100 * stats->Static_ialu/stats->Static_ops);
  fprintf(outbuf, "\t\tStatic_falu:\t%.2f\t(%.2f)\n",
	  stats->Static_falu, 100 * stats->Static_falu/stats->Static_ops);
  fprintf(outbuf, "\t\tStatic_cmpp:\t%.2f\t(%.2f)\n",
	  stats->Static_cmpp, 100 * stats->Static_cmpp/stats->Static_ops);
  fprintf(outbuf, "\t\tStatic_pbr:\t%.2f\t(%.2f)\n",
	  stats->Static_pbr, 100 * stats->Static_pbr/stats->Static_ops);
    
  sum = stats->caller_spill + stats->callee_spill;
  fprintf(outbuf, "\tDynamic_regalloc_op_overhead:\t%.2f\t(%.2f)\n",
	  sum, 100 * sum / stats->ops);
  fprintf(outbuf, "\t\tDynamic_spill_code:\t%.2f\t(%.2f)\n",
	  sum, 100 * sum / stats->ops);
  /* again avoid div by 0 */
  if (sum < 0.5) sum = 1.0; 
  fprintf(outbuf, "\t\tDynamic_caller_save:\t%.2f\t(%.2f)\n",
	  stats->caller_spill, 100 * stats->caller_spill / sum);
  fprintf(outbuf, "\t\tDynamic_callee_save:\t%.2f\t(%.2f)\n",
	  stats->callee_spill, 100 * stats->callee_spill / sum);

  sum = stats->Static_caller_spill + stats->Static_callee_spill;
  fprintf(outbuf, "\tStatic_regalloc_op_overhead:\t%.2f\t(%.2f)\n",
	  sum, 100 * sum / stats->Static_ops);
  fprintf(outbuf, "\t\tStatic_spill_code:\t%.2f\t(%.2f)\n",
	  sum, 100 * sum / stats->Static_ops);
  /* again avoid div by 0 */
  if (sum < 0.5) sum = 1.0; 
  fprintf(outbuf, "\t\tStatic_caller_save:\t%.2f\t(%.2f)\n",
	  stats->Static_caller_spill, 100 * stats->Static_caller_spill / sum);
  fprintf(outbuf, "\t\tStatic_callee_save:\t%.2f\t(%.2f)\n",
	  stats->Static_callee_spill, 100 * stats->Static_callee_spill / sum);
}


/* collect statistics per control block */
static void collect_subregion_stats(struct __PD_stats* proc_stats)
{
  struct __PD_stats* stats;
  
  for (stats=proc_stats+1; stats->id != 0 ; stats++) {   
    sumup(proc_stats, stats); /* proc_stats += stats */
    print_summary(stats, 0);
  }
}


/* dump run-time statistics 
 */
void __PD_stats_dump()
{
  struct __PD_table_list* ptr;
  struct __PD_stats *proc_stats;
  
  /* one iteration per function */
  for (ptr = __PD_stats_head_node; ptr != 0 ; ptr = ptr->next) {
    proc_stats = ptr->link;
    fprintf((FILE *) __PD_stats_file, "Function %s\n", proc_stats->id);
    /*collect subregion statistics*/
    collect_subregion_stats(proc_stats);
    print_summary(proc_stats, 1);
    fprintf((FILE *) __PD_stats_file, "\n");
  }/* end for */

#ifdef HPUX
  __PD_cleanup(_SIGQUIT);
#else /* LINUX OR SUNOS */
  __PD_cleanup(SIGQUIT);
#endif
}


/* print error message to stderr 
 */
void __PD_error(char* fmt, ...)
{
  va_list args;
  
  fprintf(stderr, "Simulator Error: ");
  va_start(args, fmt);
  vfprintf (stderr, fmt, args);
  va_end(args);
  fprintf (stderr,"\n");
  
  abort();
}

#ifdef _DEBUG_

/* utility function to easily print an instruction 
 * port during debugging  
 */
__PD_REG* get_reg(__PD_PORT* src)
{
  return 
    &__PD_REGISTERS[(unsigned int) src->file]
    [src->rot? /* rotating register?  if so, offset using RRB */
     ( (src->num + __PD_REGISTERS[__PD_RRB]->reg.cr) % *src->rot ) :
     src->num  /* else use the physical register number */
    ];
}

/*** static register files ***/

void print_gpr(int num)
{
  __PD_REG* reg = &__PD_REGISTERS[__PD_GPR_FILE][num];
  printf(">> GPR Register %d:\t %lu\n", 
	 num, reg->reg.gpr);
}

void print_fpr(int num)
{
  __PD_REG* reg = &__PD_REGISTERS[__PD_FPR_FILE][num];
  printf(">> FPR Register %d:\t (%f,%f) single/double precision\n", 
	 num, reg->reg.fpr_S, reg->reg.fpr_D);
}

void print_btr(int num)
{
  __PD_REG* reg = &__PD_REGISTERS[__PD_BTR_FILE][num];
  printf(">> BTR Register %d:\t Addr=%lu Pred=%ld\n",
	 num, reg->reg.btr.addr, reg->reg.btr.pred);
}

void print_pr(int num)
{
  __PD_REG* reg = &__PD_REGISTERS[__PD_PR_FILE][num];
  printf(">> PR Register %d:\t %ld\n", 
	 num, reg->reg.pr);
}

void print_cr(int num)
{
  __PD_REG* reg = &__PD_REGISTERS[__PD_CR_FILE][num];
  printf(">> CR Register %d:\t %lu\n", 
	 num, reg->reg.cr);
}


/*** rotating register files ***/

void print_gprr(int num)
{
  __PD_REG* reg = &__PD_REGISTERS[__PD_GPR_FILE_ROT][num];
  printf(">> GPR Rotating Register %d:\t %lu\n", 
	 num, reg->reg.gpr);
}

void print_fprr(int num)
{
  __PD_REG* reg = &__PD_REGISTERS[__PD_FPR_FILE_ROT][num];
  printf(">> FPR Rotating Register %d:\t (%f,%f) single/double precision\n", 
	 num, reg->reg.fpr_S, reg->reg.fpr_D);
}

void print_prr(int num)
{
  __PD_REG* reg = &__PD_REGISTERS[__PD_PR_FILE_ROT][num];
  printf(">> PR Rotating Register %d:\t %ld\n", 
	 num, reg->reg.pr);
}

void print_crr(int num)
{
  __PD_REG* reg = &__PD_REGISTERS[__PD_CR_FILE_ROT][num];
  printf(">> CR Rotating Register %d:\t %lu\n", 
	 num, reg->reg.cr);
}

#endif /* _DEBUG_ */






