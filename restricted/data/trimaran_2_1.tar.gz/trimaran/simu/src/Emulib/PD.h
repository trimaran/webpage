/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/******************************************************************************
 * File:    PD.h
 * Authors: Igor Pechtchanski, Amit Nene, Rodric M. Rabbah
 *****************************************************************************/

/*****************************************************************************/
/*      Description:    Header file for the Simulator                        */
/*****************************************************************************/

#ifndef __PD_H
#define __PD_H

#include "PD_globals.h"
#include "PD_reg.h"

/* 
   WARNING : To avoid redeclaration conflicts with simulation files,
   all rich data types used there SHOULD NOT be used.
   Eg. Notice the use of void * in place of FILE * in PD_dump
*/

#define PD_R    __PD_REGISTERS

#define ROT(r)  *(r)

#define REG(p)  (&PD_R[(unsigned int) p.file][p.rot? ((p.num + PD_R[__PD_RRB]->reg.cr) % ROT(p.rot)) : p.num])

#define LIT(p)  ((unsigned long) p.file)


typedef struct __PD_OP     __PD_OP;
typedef void (*__PD_IMPL) (__PD_OP *);
typedef bool (*__PD_DEBUG)(__PD_OP *);


/* These values are used as indeces in the register file pointer table */
enum __PD_REAL_REGISTERS
{
    __PD_GPR_FILE = 0,
    __PD_FPR_FILE = 1,
    __PD_BTR_FILE = 2,
    
    __PD_CR_FILE = 3,
    __PD_PR_FILE = 4,

    __PD_GPR_FILE_ROT = 5,
    __PD_FPR_FILE_ROT = 6,

    __PD_CR_FILE_ROT = 7,
    __PD_PR_FILE_ROT = 8,
}; /* __PD_REAL_REGISTERS */

enum __PD_MACRO_REGISTERS
{
      __PD_UNDEF = 9, __PD_LOCAL = 10, __PD_PARAM = 11, __PD_SWAP = 12,

      __PD_INT_RET_TYPE = 13, __PD_FLT_RET_TYPE = 14, __PD_DBL_RET_TYPE = 15,
      __PD_INT_RET      = 16, __PD_FLT_RET      = 17, __PD_DBL_RET      = 18, 

      __PD_INT_P1 = 19, __PD_INT_P2 = 20, __PD_INT_P3 = 21, __PD_INT_P4 = 22,
      __PD_FLT_P1 = 23, __PD_FLT_P2 = 24, __PD_FLT_P3 = 25, __PD_FLT_P4 = 26,
      __PD_DBL_P1 = 27, __PD_DBL_P2 = 28,

      __PD_INT_TM = 29,  __PD_FLT_TM = 30, __PD_DBL_TM = 31,

      __PD_RS = 32,  __PD_FP = 33,  __PD_IP  = 34,  __PD_OPS = 35,  
      __PD_LV = 36,  __PD_LC = 37,  __PD_ESC = 38,  __PD_RRB = 39, 
      __PD_RET_ADDR = 40,

      __PD_ALL_PRED = 41, __PD_ALL_ROT_PRED = 42, __PD_ALL_STATIC_PRED = 43,

      __PD_FLT_ZERO = 44, __PD_FLT_ONE = 45,
      __PD_DBL_ZERO = 46, __PD_DBL_ONE = 47,
      __PD_INT_ZERO = 48,

      __PD_PRED_F = 49, __PD_PRED_T = 50,

      __PD_BLACK_HOLE = 51, __PD_TEMP_REG = 52,

      __PD_PV_0 = 53, __PD_PV_1 = 54, __PD_PV_2 = 55, __PD_PV_3 = 56,
      __PD_PV_4 = 57, __PD_PV_5 = 58, __PD_PV_6 = 59, __PD_PV_7 = 60,

      __PD_SP = 61, __PD_PC = 62
}; /* __PD_MACRO_REGISTERS */

/* used to allocate a table of register pointers 
 * and is equal to REAL_REGISTER_NUM + MACRO_REGISTER_NUM 
 */
#define __PD_TOTAL_REG_NUM 63


/* Set of Emulatable Operation Types */
enum __PD_op_type
{
    __PD_branch = 1,
    __PD_load   = 2,
    __PD_store  = 3,
    __PD_ialu   = 4,
    __PD_falu   = 5,
    __PD_cmpp   = 6,
    __PD_pbr    = 7,
    __PD_pseudo = 8,

    /* flags start here */
    __PD_mask          = 0x0FF,
    __PD_caller_spill  = 0x100,
    __PD_callee_spill  = 0x200
}; /* __PD_op_type */


/* The OPeration Structure */
struct __PD_OP {
    unsigned int    Rebel_id;            /* Rebel op id */

    __PD_IMPL       op;                  /* implementation */
    __PD_PORT       src [__PD_MAX_SRC];  /* source ports */
    __PD_PORT       dest[__PD_MAX_DEST]; /* destination ports */
    __PD_PORT       pred;                /* predicate port */
    unsigned int    lat [__PD_MAX_DEST]; /* output latencies */
    
    /* debugging and statistics */
    enum __PD_op_type  type;            /* type of operation */
    unsigned int       Predicated;      /* Set to 1 when Predicated  Op */
    unsigned int       Speculated;      /* Set to 1 when Speculative Op */
    unsigned int       Mask;            /* Set to 1 when Mask Op */
}; /* __PD_op */


/* Record of Control Block Statistics */
struct __PD_stats
{
    char*  id;               /* id of this stat block */
    unsigned int sched_len;  /* Scheduling length */
    
    /* Static Instruction Mix */
    double Static_branch;
    double Static_load;
    double Static_store;
    double Static_ialu;
    double Static_falu;
    double Static_cmpp;
    double Static_pbr;
    double Static_caller_spill;
    double Static_callee_spill;
    double Static_ops;   /* Static total number of operations */ 
  
    /* Dynamic Instruction Mix */
    double branch;
    double load;
    double store;
    double ialu;
    double falu;
    double cmpp;
    double pbr;
    double ops;        /* Total number of operations */     

    /* other dynamic info gathered */
    double nullified;  /* Total number of operations nullified */
    /* register allocation overhead */  
    double caller_spill;
    double callee_spill;
    double dyn_cyc;    /* Number of cycles */
    double freq;       /* Number of visits */
}; /* __PD_stats */


/* Simulator Performance Monitoring Tools Parameters */
struct __PD_params
{
    int nual_equals;         /* the NUAL latency model */
    int binary_trace_format; /* true => format of trace is binary else text */
    int address_trace;       /* address trace */
    int control_flow_trace;  /* control flow trace */
    int dynamic_stats;       /* dynamic statistics enable */
}; /* __PD_params */


/* Linked list of simulation tables, used for profiling */
struct __PD_table_list
{
    struct __PD_stats      *link;
    struct __PD_table_list *next;
};


/* register file related parameters */
struct __PD_regfile
{
    int gpr_stat_size;
    int gpr_rot_size;
    int fpr_stat_size;
    int fpr_rot_size;
    int btr_stat_size;
    int pr_stat_size;
    int pr_rot_size;
    int cr_stat_size;
    int cr_rot_size;
    int total;
};

/* register files */
extern __PD_REG*  __PD_regs;
extern __PD_REG*  __PD_REGISTERS[__PD_TOTAL_REG_NUM];
extern __PD_REG   __PD_PV[__PD_PV_NUM];

extern unsigned long __PD_GPR_FILE_S_SIZE;
extern unsigned long __PD_GPR_FILE_R_SIZE;
extern unsigned long __PD_GPR_NUM;

extern unsigned long __PD_FPR_FILE_S_SIZE;
extern unsigned long __PD_FPR_FILE_R_SIZE;
extern unsigned long __PD_FPR_NUM;

extern unsigned long __PD_BTR_FILE_S_SIZE;
extern unsigned long __PD_BTR_NUM;

extern unsigned long __PD_PR_FILE_S_SIZE;
extern unsigned long __PD_PR_FILE_R_SIZE;
extern unsigned long __PD_PR_NUM;

extern unsigned long __PD_CR_FILE_S_SIZE;
extern unsigned long __PD_CR_FILE_R_SIZE;
extern unsigned long __PD_CR_NUM;

/* GPR macro registers */
extern __PD_REG __PD_int_p1;
extern __PD_REG __PD_int_p2;
extern __PD_REG __PD_int_p3;
extern __PD_REG __PD_int_p4;
extern __PD_REG __PD_int_ret;

/* FPR Single Precision macro registers */
extern __PD_REG __PD_flt_p1;
extern __PD_REG __PD_flt_p2;
extern __PD_REG __PD_flt_p3;
extern __PD_REG __PD_flt_p4;
extern __PD_REG __PD_flt_ret;

/* FPR Double Precision macro registers */
extern __PD_REG __PD_dbl_p1;
extern __PD_REG __PD_dbl_p2;
extern __PD_REG __PD_dbl_ret;

/* Stack Related Pointer registers */
extern __PD_REG __PD_sp;
extern __PD_REG __PD_op;
extern __PD_REG __PD_ip;
extern __PD_REG __PD_pc;    

/* vararg hack register */
extern __PD_REG __PD_VAR_ap_list_start;

/* global variables */
extern double __PD_GLOBAL_CLOCK;
extern int    __PD_exception_raised;
extern char*  __PD_current_function;

extern int    __PD_zero;
extern bool   __PD_done;
extern int    __PD_edge;

extern struct __PD_stats*   __PD_cur_stats;
extern struct __PD_regfile* __PD_cur_reginfo;
extern struct __PD_params*  __PD_params_vals;

extern void*  __PD_trace_file;
extern void*  __PD_stats_file;

extern void  __PD_error(char*, ...);             /* error function */

extern void __PD_init();                         /* initialize simulator */
extern void __PD_initLDS();                      /* LDS hash table init  */
extern void __PD_simulate(struct __PD_OP *);     /* simulator main loop */
extern void __PD_cleanup(int);                   /* cleanup after execution */
extern void __PD_endsim(unsigned int);           /* end simulation */
extern void __PD_update_stats(struct __PD_OP *); /* stats update */
extern void __PD_chain(struct __PD_stats *);     /* chain tables for 
						  * profiling purposes */
/* sets up register parameters */
extern void __PD_set_regfile(struct __PD_regfile*, struct __PD_REG*, int, int);
extern void __PD_stats_dump();                   /* To dump a stat file */
extern void __PD_op_null_action(struct __PD_OP *op);

/* hack functions to deal with varargs */
extern int __PD_VAR__builtin_next_arg(char* p0);
extern int __PD_VAR__builtin_saveregs();

/* hack functions to deal with setjmp/longjmp */
extern int  __PD_SL_setjmp(double*);
extern void __PD_SL_longjmp(double*, int);
extern void __PD_SL_decrement_longjump_depth_count();
extern void __PD_SL_increment_longjump_depth_count();

/* miscellaneous functions */
extern void __PD_prologue(struct __PD_OP *op);
extern void __PD_epilogue(struct __PD_OP *op);
extern void __PD_aclock(struct __PD_OP *op);
extern void __PD_start_compound(struct __PD_OP *op);
extern void __PD_start_procedure(struct __PD_OP *op);
extern void __PD_set_stat_ptr(struct __PD_OP *op);

/* trace generators that invoke other format-specific trace generators */
extern void __PD_trace_proc(struct __PD_OP *op);
extern void __PD_trace_ret(struct __PD_OP *op);
extern void __PD_trace_endsim(struct __PD_OP *op);
extern void __PD_trace_cb(struct __PD_OP *op);
extern void __PD_trace_longjmp(__PD_OP *op);
extern void __PD_trace_load_B(struct __PD_OP *op);
extern void __PD_trace_load_H(struct __PD_OP *op);
extern void __PD_trace_load_W(struct __PD_OP *op);
extern void __PD_trace_load_S(struct __PD_OP *op);
extern void __PD_trace_load_D(struct __PD_OP *op);
extern void __PD_trace_store_B(struct __PD_OP *op);
extern void __PD_trace_store_H(struct __PD_OP *op);
extern void __PD_trace_store_W(struct __PD_OP *op);
extern void __PD_trace_store_S(struct __PD_OP *op);
extern void __PD_trace_store_D(struct __PD_OP *op);
extern void __PD_trace_op(struct __PD_OP *op);
extern void __PD_trace_op_null(struct __PD_OP *op);

/* Warning: temporary hack -- will be thrown out */
extern unsigned long *__PD_hack_stack;
extern unsigned long *__PD_hack_stack_base;
extern unsigned long  __PD_STACK_LIMIT;

/* Activation Stack Record, used to infer source of last
 * function call 
 */
typedef struct {
  long address;
  int  is_valid;
} __PD_call_info;

extern __PD_call_info __PD_last_call;

#include "PD_queue.h"
#endif /* __PD_H */


