/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

/******************************************************************************
 * File:    PD_longjmp.c
 * Authors: Rodric M. Rabbah
 *****************************************************************************/

#ifdef _SETJMP_LONGJMP_SUPPORT_

#include "PD.h"
#include "PD_sl.h"

extern bool __PD_SL_longjmp_executed;
extern int* __PD_SL_longjmp_depth;

extern __PD_SL_jmp_buf_node* __PD_SL_jmp_buf_list;
extern __PD_SL_jmp_buf_node* __PD_SL_in_list(double* key_ptr);


void __PD_SL_longjmp(double* buffer_key, int val)
{
  int gpr_offset, gpr_r_offset;
  int fpr_offset, fpr_r_offset;
  int btr_offset;
  int pr_offset, pr_r_offset;
  int cr_offset, cr_r_offset;
  int i, total;

  __PD_SL_jmp_buf_node* jump_buffer = __PD_SL_in_list(buffer_key);

  if (jump_buffer == NULL) {
    __PD_error("jump_buffer not expected to be null!");
  }

  /* restore vararg related information */
  __PD_VAR_ap_list_start.reg.cr  = jump_buffer->buffer.VAR_ap_list_start;

  /* restore register file information */
  __PD_cur_reginfo = jump_buffer->buffer.reginfo;

  /* restore frame pointers */
  __PD_REGISTERS[__PD_RRB]->reg.cr  = jump_buffer->buffer.RRB;
  __PD_REGISTERS[__PD_ESC]->reg.cr  = jump_buffer->buffer.ESC;
  __PD_REGISTERS[__PD_LC ]->reg.cr  = jump_buffer->buffer.LC;

  __PD_REGISTERS[__PD_IP ]->reg.cr  = jump_buffer->buffer.IP;
  __PD_REGISTERS[__PD_RS ]->reg.cr  = jump_buffer->buffer.RS;
  __PD_REGISTERS[__PD_OPS]->reg.cr  = jump_buffer->buffer.OPS;
  __PD_REGISTERS[__PD_LV ]->reg.cr  = jump_buffer->buffer.LV;

  __PD_REGISTERS[__PD_SP ]->reg.cr  = jump_buffer->buffer.SP;

  __PD_hack_stack      = jump_buffer->buffer.hack_stack;
  __PD_hack_stack_base = jump_buffer->buffer.hack_stack_base;

  /* re-align register file pointers */
  __PD_GPR_FILE_S_SIZE = jump_buffer->buffer.reginfo->gpr_stat_size;
  __PD_GPR_FILE_R_SIZE = jump_buffer->buffer.reginfo->gpr_rot_size;
  __PD_GPR_NUM      = __PD_GPR_FILE_S_SIZE + __PD_GPR_FILE_R_SIZE ;

  __PD_FPR_FILE_S_SIZE = jump_buffer->buffer.reginfo->fpr_stat_size;
  __PD_FPR_FILE_R_SIZE = jump_buffer->buffer.reginfo->fpr_rot_size;
  __PD_FPR_NUM      = __PD_FPR_FILE_S_SIZE + __PD_FPR_FILE_R_SIZE ;

  __PD_BTR_FILE_S_SIZE = jump_buffer->buffer.reginfo->btr_stat_size;
  __PD_BTR_NUM      = __PD_BTR_FILE_S_SIZE;

  __PD_PR_FILE_S_SIZE  = jump_buffer->buffer.reginfo->pr_stat_size;
  __PD_PR_FILE_R_SIZE  = jump_buffer->buffer.reginfo->pr_rot_size;
  __PD_PR_NUM       = __PD_PR_FILE_R_SIZE  + __PD_PR_FILE_S_SIZE;

  __PD_CR_FILE_S_SIZE  = jump_buffer->buffer.reginfo->cr_stat_size;
  __PD_CR_FILE_R_SIZE  = jump_buffer->buffer.reginfo->cr_rot_size;
  __PD_CR_NUM       = __PD_CR_FILE_R_SIZE  + __PD_CR_FILE_S_SIZE;

  total = __PD_GPR_NUM + __PD_FPR_NUM + __PD_BTR_NUM +
          __PD_PR_NUM  + __PD_CR_NUM;

  /* this is not correct - must deal with virtual registers, 
   * and memory leaks 
   */
  free (__PD_regs);
  __PD_regs = (struct __PD_REG *) malloc(total * sizeof(struct __PD_REG));

  if (__PD_regs == NULL) {
    __PD_error("Could not allocate memory to restore Registers for longjmp!");
  }

  for (i = 0; i < total; i++) {
    __PD_regs[i] = jump_buffer->buffer.regs[i];
  }

  gpr_offset   = 0;
  gpr_r_offset = gpr_offset   + __PD_GPR_FILE_S_SIZE;
  fpr_offset   = gpr_r_offset + __PD_GPR_FILE_R_SIZE;
  fpr_r_offset = fpr_offset   + __PD_FPR_FILE_S_SIZE;
  btr_offset   = fpr_r_offset + __PD_FPR_FILE_R_SIZE;
  pr_offset    = btr_offset   + __PD_BTR_FILE_S_SIZE;
  pr_r_offset  = pr_offset    + __PD_PR_FILE_S_SIZE;
  cr_offset    = pr_r_offset  + __PD_PR_FILE_R_SIZE;
  cr_r_offset  = cr_offset    + __PD_CR_FILE_S_SIZE;

  __PD_REGISTERS[__PD_GPR_FILE] = &__PD_regs[gpr_offset];
  __PD_REGISTERS[__PD_FPR_FILE] = &__PD_regs[fpr_offset];
  __PD_REGISTERS[__PD_BTR_FILE] = &__PD_regs[btr_offset];

  __PD_REGISTERS[__PD_PR_FILE] = &__PD_regs[pr_offset];;
  __PD_REGISTERS[__PD_CR_FILE] = &__PD_regs[cr_offset];

  __PD_REGISTERS[__PD_GPR_FILE_ROT] = &__PD_regs[gpr_r_offset];
  __PD_REGISTERS[__PD_FPR_FILE_ROT] = &__PD_regs[fpr_r_offset];

  __PD_REGISTERS[__PD_PR_FILE_ROT] = &__PD_regs[pr_r_offset];
  __PD_REGISTERS[__PD_CR_FILE_ROT] = &__PD_regs[cr_r_offset];

  /* restore program counter */
  __PD_pc.reg.cr = jump_buffer->buffer.pc;

  /* flag this operation, so that the program counter in preserved */
  __PD_SL_longjmp_executed = 1;
  __PD_SL_longjmp_depth    = &jump_buffer->depth;
  
  /* emmitt trace operation if necessary */
  __PD_current_function = (char*) (*(__PD_hack_stack_base + 1));
  
  jump_buffer->buffer.trace_longjmp_op.src[0].file
    = (__PD_REG*) __PD_current_function;

  __PD_edge = jump_buffer->buffer.edge;
  __PD_params_vals = jump_buffer->buffer.params;

  if (__PD_params_vals->control_flow_trace) {
    __PD_trace_longjmp(&jump_buffer->buffer.trace_longjmp_op);
  }

  /* update statistics pointer */
  if (__PD_params_vals->dynamic_stats) {
    __PD_set_stat_ptr(&jump_buffer->buffer.trace_longjmp_op);
  }

  /* this is the value that setjmp would normally return */
  __PD_int_ret.reg.gpr = val;
}

#endif /* _SETJMP_LONGJMP_SUPPORT_ */









