/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.20  */
/* IMPACT Trimaran Release (www.trimaran.org)                  May 17, 1999  */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   merge_prof.c
 *      Author: Le-Chun Wu and Wen-mei Hwu
 * Modified By: Andrew Trick and John C. Gyllenhaal -4/99
\*****************************************************************************/
       

#include <stdio.h>
#include <sys/types.h>

#define BUFFER_SZ 1024

/* how to merge the multiple prof data files */
#define AVERAGE   1
#define SUMMATION 2
#define MAXIMUM   3

struct file_list {
  char *name;
  struct file_list *next;
};

void process_prof_files(struct file_list *prof_flst, int probe_num, 
			char *dest_file_name, int merge_type)
{
  struct file_list *flst_ptr;
  double *final_probe_array, *tmp_probe_array;
  FILE *Fin, *Fout;
  int valid_prof_file_no = 0;
  double prof_weight;
  int result_is_valid = 0, error_occured;
  int probe_count = 0;
  int i;

  /* temp array stores values until entire file is considered valid */
  tmp_probe_array = (double *)malloc(sizeof(double)*probe_num);
  final_probe_array = (double *)malloc(sizeof(double)*probe_num);
  /* initialize final_probe_array */
  for (i = 0; i < probe_num; i++)
      final_probe_array[i] = 0;

  /* process each profile data file */
  for (flst_ptr = prof_flst; flst_ptr != NULL; flst_ptr = flst_ptr->next) {
      probe_count = 0;
      error_occured = 0;
      
      /* Open input file */
      if ((Fin = fopen(flst_ptr->name, "r")) == NULL) {
	 fprintf(stderr, "Pmerge_prof warning: cannot open %s.\n", 
		 flst_ptr->name);
	 continue;
      }
      /* Read each probe value form the input file */
      while (fscanf(Fin, "%lf", &prof_weight) != EOF) {
	 if (probe_count >= probe_num) {
	    fprintf(stderr, "Pmerge_prof warning: %s has too many lines.\n", 
		 flst_ptr->name);
	    error_occured = 1;
	    break;
	 }
	 tmp_probe_array[probe_count++] = prof_weight;
      }
      if (error_occured)
	 continue;
      if (probe_count < probe_num) {
	 fprintf(stderr, "Pmerge_prof warning: %s has too few lines.\n", 
		 flst_ptr->name);
	 continue;
      }

      /* control reaching here means the profile data file is valid */
      result_is_valid = 1;
      valid_prof_file_no ++;
      for (i = 0; i < probe_num; i++) {
	 switch(merge_type) {
	   case AVERAGE:
	   case SUMMATION:
	     final_probe_array[i] += tmp_probe_array[i];
	     break;
	   case MAXIMUM:
	     if (tmp_probe_array[i] > final_probe_array[i])
	        final_probe_array[i] = tmp_probe_array[i];
	     break;
	   default:
	     fprintf(stderr, "Pmerge_prof error: invalid merge type.\n"); 
	     exit(-1);
	     break;
	 }
      }
  }
  
  if (result_is_valid) {
     /* take the average when the merge type is AVERAGE */
     if (merge_type == AVERAGE) {
        for (i = 0; i < probe_num; i++)
	    final_probe_array[i] = final_probe_array[i] / valid_prof_file_no;
     }
     if ((Fout = fopen(dest_file_name, "w")) != NULL)
        for (i = 0; i < probe_num; i++)
	    fprintf(Fout, "\t%f\n", final_probe_array[i]);
     else {
        fprintf(stderr, "Pmerge_prof error: cannot open %s.\n", 
		dest_file_name);
	exit(-1);
     }
  }
  else {
     fprintf(stderr, "Pmerge_prof error: no valid profile data files.\n"); 
     exit(-1);
  }
}

void copyFile (char *in_name, char *out_name) {
  FILE *Fin, *Fout;
  char buffer[BUFFER_SZ];
  int num_read;

  if ((Fin = fopen (in_name, "r")) == NULL) {
    fprintf (stderr, "Pmerge_prof error: cannot open %s\n", in_name);
    exit (-1);
  }
  if ((Fout = fopen (out_name, "w")) == NULL) {
    fprintf (stderr, "Pmerge_prof error: cannot open %s\n", out_name);
    exit (-1);
  }
  
  while (!feof (Fin)) {
    num_read = fread (buffer, sizeof( char ), BUFFER_SZ, Fin); 
    if (ferror (Fin)) {
      fprintf(stderr, "Pmerge_prof error reading input file %s.\n", in_name); 
      exit(-1);
    }
    fwrite (buffer, sizeof( char ), num_read, Fout);
    if (ferror (Fout)) {
      fprintf(stderr, "Pmerge_prof error writing output file %s.\n", out_name); 
      exit(-1);
    }
  }
  fclose (Fin);    
  fclose (Fout);    
}

void printUsage() {
  fprintf(stderr, "Usage: Pmerge_prof profile_dat.* [options]\n\n");
  fprintf(stderr, " Generates profile.dat (merged profile data).\n\n");
  fprintf(stderr, " One of the following options may be specified:\n");
  fprintf(stderr, "   -a\taverage profile values (default)\n");
  fprintf(stderr, "   -s\t    sum profile values\n");
  fprintf(stderr, "   -m\tuse max profile value\n\n");
  fprintf(stderr, "   -numprobes {val}\tnumber of probe values (greater than 0)\n");
  fprintf(stderr, "     by default, read from ./impact_probe.tmp\n\n");
  fprintf(stderr, " \"profile_data.*\" is a list of input files to merge\n");
}

main(int argc, char **argv)
{
  int cmd_line_err = 0;

  char *dir_name, *dest_file_name;
  char *probe_tmp_name = "impact_probe.tmp";
  struct file_list *prof_flst = NULL, *flst_ptr = NULL, *new_file;
  int num_probes = 0;
  int merge_type = AVERAGE;
  int i;

  if (argc < 2) {
     printUsage();
     exit(-1);
  }

  dir_name = ".";
  for (i = 1; i < argc; i++) {
     if (argv[i][0] == '-') {
        switch(argv[i][1]) {
	  case 'a':
	    merge_type = AVERAGE;
	    break;
	  case 's':
	    merge_type = SUMMATION;
	    break;
	  case 'm':
	    merge_type = MAXIMUM;
	    break;
	  case 'n':
	    if (!strncmp (argv[i], "-numprobes", 10) && argc > ++i) {
	      probe_tmp_name = NULL;
	      num_probes = atoi (argv[i]);
              break;
	    }
	  default:
	    printUsage();
	    exit(-1);
	}
     }
     else {
       /* Add a new profile file name */
       new_file = (struct file_list *)malloc(sizeof(struct file_list));
       new_file->next = NULL;
       new_file->name = argv[i];
       if (prof_flst == NULL)
	   prof_flst = flst_ptr = new_file;
       else {
	 flst_ptr->next = new_file;
	 flst_ptr = new_file;
       }
     }
  }

  if (prof_flst == NULL) {
    printUsage();
    fprintf (stderr, "\nPmerge_prof error: At least one input file must be specified.\n");
    exit(-1);
  }

  /* Read num probes from temp file */
  if (probe_tmp_name != NULL) {
    char *tmp_name;
    FILE *probe_tmp_file;
    tmp_name = (char *)malloc(strlen(dir_name) + strlen(probe_tmp_name) + 2);
    sprintf (tmp_name, "%s/%s", dir_name, probe_tmp_name);
    if ((probe_tmp_file = fopen(tmp_name, "r")) != NULL) {
      fscanf (probe_tmp_file, "%d", &num_probes);
      fclose (probe_tmp_file);
    }
    else {
      fprintf (stderr, "Pmerge_prof error: cannot open %s\n", tmp_name);
      exit (-1);
    }
  }

  dest_file_name = (char *)malloc(strlen(dir_name) + 14);
  sprintf(dest_file_name, "%s/profile.dat", dir_name);

  /* If only one input file exists, simply copy it */
  if (prof_flst->next == NULL) {
    copyFile (prof_flst->name, dest_file_name);
  }
  else
    process_prof_files (prof_flst, num_probes, dest_file_name, merge_type);

  exit(0);
}
