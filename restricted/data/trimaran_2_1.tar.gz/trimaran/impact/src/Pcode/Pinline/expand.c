/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   expand.c
 *      Author: Ben-Chung Cheng, Wen-mei Hwu
\*****************************************************************************/


#include <stdio.h>
#include <library/list.h>
#include <malloc.h>
#include <Pcode/read_pcode.h>
#include "inline.h"

static Expand_Call_Stmts(Stmt, int);
static Expand_Call_Expr(Stmt, int);
int max_label;

static void ReadinFunc(expr, filepath)
Expr expr;
char *filepath;
{
    int flag;

    flag = (lexOpen(filepath, 0) == 0);
    if (flag) Punt("cannot open include file");
#if 0
    for (;;) {
	LIST node;
	node = GetNode();
	if (node == 0) break;
	if (NodeType(node) == T_EOF) break;
	    ProcessList(node);
	node = DisposeNode(node);
    }
#endif
    /* BCC - for new Pcode - 8/25/96 */
    while (P_get_input() != P_INPUT_EOF) {
	process_input();
    }

    lexClose(filepath);
}

int IsVarargCallee(fn)
FuncDcl fn;
{
    VarList param;

    param = fn->param;
    while (param) {
	char buffer[256];
	char *ptr;

	/* In ANSI-C, "..." is a vararg parameter */
	if (!strcmp(param->name, "...")) return 1;

	/* suppose name is "P___builtin_va_alist___xxx", then copy from 'b' */
	ptr = param->name+4;
	sprintf(buffer, "%s", ptr);
	ptr = buffer;
	while (*ptr) {
	    if (ptr[0] == '_' && ptr[1] == '_' && ptr[2] == '_' && 
		isdigit(ptr[3]) ) {
		ptr[0] = ptr[1] = 0;	/* chop off the trailing "___number" */
		if (!strcmp(buffer, "builtin_va_alist")) return 1;
	    }
	    ptr++;	/* next character */
	}
	param = param->next;
    }
    return 0;
}

static int IsEqualParameters(expr, formal)
Expr expr;
int formal;
{
    int actual;

    actual = 0;

    while (expr) {
	actual++;
	expr = expr->next;
    }

    return (formal == actual);
}

static void Param2Lvar(fn, first_param)
FuncDcl fn;
VarList *first_param;
{
    VarList param, lvar, temp;

    param = *first_param = fn->param;
    temp = lvar = fn->stmt->stmtstruct.compound->var_list;
    if (temp) {
	while (temp->next) temp = temp->next;
	temp->next = param;
    }
    else fn->stmt->stmtstruct.compound->var_list = param;

    /* Since a local variable can't be an array with unknown dimension, but a
       parameter can. So if a parameter is of type array, it should be changed
       to pointer type to make it legal as a local variable. */

    while (param) {
	Type type;
	Dcltr dcltr;

	dcltr = param->var->type->dcltr;
	if (dcltr && dcltr->method == D_ARRY) {
	    dcltr->method = D_PTR;
	    dcltr->index = 0;
	}
	param = param->next;
    }
}

static void ActualParam2FormalParam(call_stmt, stmt, actual_param, formal_param)
Stmt call_stmt;
Stmt stmt;
Expr actual_param;
VarList formal_param;
{
    Stmt first_stmt, new_stmt;
    Type ty;
    Expr expr, op1, op2;

    while (actual_param) {
	if (formal_param == 0) 
	    Punt("ActualParam2FormalParam : numbers of parameters don't match");
	ty = CopyType(formal_param->var->type);
	expr = NewInstExpr(OP_assign, ty);
	op1 = NewVarExpr(formal_param->var->new_name, CopyType(ty));
	op2 = CopyExpr(actual_param);
	/* to save memory, don't copy 
	op2 = actual_param; */
	AddOperand(expr, op1);
	AddOperand(expr, op2);

	new_stmt = NewStmt();
	new_stmt->type = ST_EXPR;
	new_stmt->stmtstruct.expr = expr;

        /* TLJ 7/15/96 */
        new_stmt->profile = CopyProfST(call_stmt->profile);

	first_stmt = stmt->stmtstruct.compound->stmt_list;
	/* The current compound statement might be null. In this case, using
	   Insert_stmt_Before() may cause error when it calls 
	   Create_Encl_Compd_IfNeeded(). */
	if (first_stmt == 0) {
	    stmt->stmtstruct.compound->stmt_list = new_stmt;
	    new_stmt->parent = stmt;
	}
	else Insert_Stmt_Before(first_stmt, new_stmt);

	actual_param = actual_param->next;
	formal_param = formal_param->next;
	/* since actual_param has been advanced, the next field of op2 can be
	   cleared 
	op2->next = 0; */
    }
    if (formal_param != 0) 
	Punt("ActualParam2FormalParam : numbers of parameters don't match (2)");
}

static void Return2Goto(stmts, lvar, label_name)
Stmt stmts;
Expr lvar;
char *label_name;
{
    SerLoop serloop;
    ParLoop parloop;
    Stmt assign, goto_stmt;

    while (stmts != NIL) {
        switch (stmts->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
            case ST_EXPR:
                break;
            case ST_RETURN:
                if (stmts->stmtstruct.ret != NIL) {	
		    /* with something to return, the return expression is */
		    /* replaced by an assignment or expr followed by a goto */
		    stmts->type = ST_EXPR;
		    if (lvar != 0) {
			Expr rvar, expr, op1, op2;
			Type ty;

			op2 = stmts->stmtstruct.ret;
			ty = CopyType(lvar->type);
			expr = NewInstExpr(OP_assign, ty);
			op1 = CopyExpr(lvar);
			op2 = stmts->stmtstruct.ret;
			AddOperand(expr, op1);
			AddOperand(expr, op2);
			stmts->stmtstruct.expr = expr;
		    };
		    goto_stmt = NewStmt();
		    goto_stmt->type = ST_GOTO;
		    goto_stmt->stmtstruct.label = strdup(label_name);
		    /* BCC - 2/28/97
		     * Copy profile weight from the original return stmt.
		     */
		    goto_stmt->profile = CopyProfST(stmts->profile);
		    Insert_Stmt_After(stmts, goto_stmt);
		}
		else {
		    /* with nothing to return, replaced by a goto */
		    stmts->type = ST_GOTO;
		    stmts->stmtstruct.label = strdup(label_name);
		}
                break;
            case ST_COMPOUND:
                Return2Goto(stmts->stmtstruct.compound->stmt_list, lvar, 
			    label_name);
                break;
            case ST_IF:
                Return2Goto(stmts->stmtstruct.ifstmt->then_block, lvar, 
			    label_name);
                if (stmts->stmtstruct.ifstmt->else_block != NIL)
                    Return2Goto(stmts->stmtstruct.ifstmt->else_block, lvar, 
				label_name);
                break;
            case ST_SWITCH:
                Return2Goto(stmts->stmtstruct.switchstmt->switchbody, lvar, 
			    label_name) ;
                break;
            case ST_PSTMT:
                Return2Goto(stmts->stmtstruct.pstmt->stmt, lvar, label_name);
                break;
            case ST_MUTEX:
                Return2Goto(stmts->stmtstruct.mutex->statement, lvar, 
			    label_name);
                break;
            case ST_COBEGIN:
                Return2Goto(stmts->stmtstruct.cobegin->statements, lvar, 
			    label_name);
                break;
            case ST_SERLOOP:
                serloop = stmts->stmtstruct.serloop;
                Return2Goto(serloop->loop_body, lvar, label_name);
                break;
            case ST_PARLOOP:
                parloop = stmts->stmtstruct.parloop;
                Return2Goto(Parloop_Stmts_Prologue_Stmt(stmts), lvar, 
			    label_name);
                break;
            case ST_BODY:
                Return2Goto(stmts->stmtstruct.bodystmt->statement, lvar, 
			    label_name);
                break;
            case ST_EPILOGUE:
                Return2Goto(stmts->stmtstruct.epiloguestmt->statement, lvar, 
			    label_name);
                break;
            default:
                Punt("Return2Goto: Invalid statement type", stmts);
        }
        stmts = stmts->lex_next;
    }
}

static int Expand_Callee(stmt, expr, func_name, lvar, no_weight)
Stmt stmt;
Expr expr;
char *func_name;
Expr lvar;
int no_weight;
{
    char *filepath;
    char str[256];
    int dummy;
    Stmt new_stmt, last_stmt, goto_stmt;
    VarList first_param;
    CG_Node callee_node;
    CG_Arc ptr;
    double real_weight;
    int self_recursion;
    double new_first_op_weight, scale_down, scale_up;
    static total_inline_count;

    if (C_find(mapping_table_ID,func_name,0,&dummy,(Pointer *) &callee_node)) {
	if (callee_node->vararg) {
	    if (print_inline_stats)
		fprintf(Flog, "  X Didn't inline %s to %s (vararg)\n", 
			func_name, currentFuncDcl->name);
	    return;
	}
	if (!IsEqualParameters(expr->operands->sibling,callee_node->num_parms)){
	    if (print_inline_stats)
		fprintf(Flog,"  X Didn't inline %s to %s (parameter numbers)\n",
			func_name, currentFuncDcl->name);
	    return;
	}
	if (no_weight == 0) {
	    if (!RECURSIVE(ActiveCG_Arc)) {
		if ( ActiveCG_Node->bodysize + callee_node->bodysize > 
		     max_function_size) {
		    if (print_inline_stats)
			fprintf(Flog, "  X Didn't inline because the bodysize will exceed the maximum size\n");
		    return;
		}
		if ( ActiveCG_Node->stacksize + callee_node->stacksize > 
		     max_sf_size_limit) {
		    if (print_inline_stats)
			fprintf(Flog, "  X Didn't inline because the stacksize will exceed the maximum size\n");
		    return;
		}
		self_recursion = 0;
		filepath = callee_node->newpath ? 
			   callee_node->newpath : callee_node->path;
		if (callee_node->weight)
		    in_fraction = ActiveCG_Arc->weight / callee_node->weight;
		else
		    in_fraction = 0.0;
		if (ActiveCG_Node->weight > 0.0)
		    out_fraction = 1.0 - 
				ActiveCG_Node->discount/ ActiveCG_Node->weight;
		else
		    out_fraction = 0.0;
	    }
	    /* self-recursion */
	    else {
		if ( ActiveCG_Node->bodysize + callee_node->bodysize2 > 
		     max_function_size) {
		    if (print_inline_stats)
			fprintf(Flog, "  X Didn't inline because the bodysize will exceed the maximum size\n");
		    return;
		}
		if ( ActiveCG_Node->stacksize + callee_node->stacksize2 > 
		     max_sf_size_limit) {
		    if (print_inline_stats)
			fprintf(Flog, "  X Didn't inline because the stacksize will exceed the maximum size\n");
		    return;
		}
		self_recursion = 1;
		filepath = callee_node->scalepath;
		ActiveCG_Node->myself += ActiveCG_Arc->fraction;
		new_first_op_weight = ActiveCG_Node->first_op_weight /
				      ActiveCG_Node->myself;
		scale_down = ActiveCG_Arc->fraction;
		scale_up = ActiveCG_Node->weight / new_first_op_weight;
		in_fraction = new_first_op_weight * scale_down * scale_up;
		out_fraction = 1/scale_up;
	    }
	}

	else {	/* no_weight == 1 */
	    if (ActiveCG_Arc->callsite == callee_node) {
		if (print_inline_stats)
		    fprintf(Flog, "  X Didn't inline indirect self-recursions\n");
		return;
	    }
	    if ( ActiveCG_Node->bodysize + callee_node->bodysize > 
		 max_function_size) {
		if (print_inline_stats)
		    fprintf(Flog, "  X Didn't inline because the bodysize will exceed the maximum size\n");
		return;
	    }
	    if ( ActiveCG_Node->stacksize + callee_node->stacksize > 
		 max_sf_size_limit) {
		if (print_inline_stats)
		    fprintf(Flog, "  X Didn't inline because the stacksize will exceed the maximum size\n");
		return;
	    }
	    self_recursion = 0;
	    filepath = callee_node->newpath ? 
		       callee_node->newpath : callee_node->path;
	    if (callee_node->weight > 0.0)
		in_fraction = ActiveCG_Arc->weight / callee_node->weight;
	    else
		in_fraction = 0.0;
	    if (ActiveCG_Node->weight > 0.0)
		out_fraction = 1.0 - 
			       ActiveCG_Node->discount/ ActiveCG_Node->weight;
	    else
		out_fraction = 0.0;
	}
	if (size_only == 1) {
	    in_fraction = 1.0;
	    out_fraction = 1.0;
	}
	inlining = 1;
	ReadinFunc(expr, filepath);
	in_fraction = 1.0;
	inlining = 0;
    }
    else return;

    /* grab the compound stmt of the callee function */
    new_stmt = calleeFuncDcl->stmt;

    /* the callee is inlinable */
    if (size_only == 0) {
	if (no_weight == 0) {
	    if (print_inline_stats) {
		fprintf(Flog, 
			"%03d  %c Inlined %s to %s\n", total_inline_count++,
			(lvar) ? '=' : ' ', func_name, currentFuncDcl->name);
	    }
	}
	else {
	    if (print_inline_stats) {
		fprintf(Flog, "%03d  %c Inlined %s to %s (%f)\n", 
		    total_inline_count++, (lvar) ? '=' : ' ', func_name, 
		    currentFuncDcl->name,
		    callee_node->weight-callee_node->discount);
	    }
	}
    }
    else {
	if (print_inline_stats) {
	    fprintf(Flog, 
		    "%03d  %c Inlined %s to %s\n", total_inline_count++,
		    (lvar) ? '=' : ' ', func_name, currentFuncDcl->name);
	}
    }

    /* insert absorbed call arcs from the callee to the heap */
    PreprocessFunc(calleeFuncDcl, no_weight);

    if (self_recursion == 0) {
	real_weight = ActiveCG_Arc->weight - ActiveCG_Arc->discount;
	/* Don't change the weight of indr callees */
	if (no_weight == 0) {	
	    callee_node->discount += real_weight;
	    callee_node->first_op_weight -= real_weight * callee_node->myself;
	}
    }
    if (size_only == 0 && callee_node->discount > callee_node->weight) {
	if (fabs(callee_node->discount - callee_node->weight) > 0.001) {
	    if (print_inline_stats) {
		fprintf(Flog, "Warning: function %s is over inlined\n", 
			func_name);
	    }
	}
	callee_node->discount = callee_node->weight;
    }

    /* 
     * if ( !self_recursion), modify the weight of every call arc in the callee 
     * by decreasing real_weight*ptr->fraction.
     */
    if (self_recursion == 0) {
	ActiveCG_Node->stacksize += callee_node->stacksize;
	ActiveCG_Node->bodysize += callee_node->bodysize;
	TotalBodySize += callee_node->bodysize;
	if (print_inline_stats)
	    fprintf(Flog, "%f %f\n", TotalBodySize, MaxBodySize);
	if (size_only == 0 && no_weight == 0) {
	    ptr = callee_node->first;
	    while (ptr) {
		ptr->discount += real_weight * ptr->fraction;
		if (ptr->discount > ptr->weight) {
		    if ( fabs(ptr->discount - ptr->weight) > 0.001 ) {
			if (print_inline_stats) {
			    fprintf(Flog, "Warning: arc %s is wrong\n", 
				    ptr->callsite->funcname);
			}
		    }
		    ptr->discount = ptr->weight;
		}
		ptr = ptr->next;
	    }
	}
    }
    /*
     * else if (self_recursion), modify the weight of every call in the already
     * expanded callsite by decreasing arc->weight * (1 - out_fraction)
     */
    else {
	ActiveCG_Node->stacksize += callee_node->stacksize2;
	ActiveCG_Node->bodysize += callee_node->bodysize2;
	TotalBodySize += callee_node->bodysize2;
	if (print_inline_stats)
	    fprintf(Flog, "%f %f\n", TotalBodySize, MaxBodySize);
	ActiveCG_Node->weight /= scale_up;
	ActiveCG_Node->discount = 0.0;
	ptr = ActiveCG_Node->first;
	while (ptr) {
	    ptr->weight /= scale_up;
	    ptr->discount = 0.0;
	    ptr = ptr->next;
	}
    }

    if (no_weight == 0) {
	/* take out the just expanded call arc */
	if (ActiveCG_Arc->prev)
	    ActiveCG_Arc->prev->next = ActiveCG_Arc->next;
	if (ActiveCG_Arc->next)
	    ActiveCG_Arc->next->prev = ActiveCG_Arc->prev;
	if (ActiveCG_Arc->callsite->first == ActiveCG_Arc) 
	    ActiveCG_Arc->callsite->first = ActiveCG_Arc->next;
	if (ActiveCG_Arc->callsite->last == ActiveCG_Arc) 
	    ActiveCG_Arc->callsite->last = ActiveCG_Arc->prev;

	RemoveCG_Arc(ActiveCG_Arc);
	ActiveCG_Arc = 0;
    }

    /* move parameters to local variables */
    Param2Lvar(calleeFuncDcl, &first_param);

    /* TLJ 7/15/96 - pass in the Call stmt to get the profile weight from */
    /* assign actual parameters to formal parameters 
       expr->operand(->next....) holds the actual parameters
       new_stmt is the compound statement of the callee function
       stmt is the CALL stmt
       first_param points to the formal parameters list
    */
    ActualParam2FormalParam(stmt, new_stmt, expr->operands->sibling, 
							first_param);

    /************************************
     * outdated by the following comment 
     ************************************
     * BCC - 3/2/96
     * We used the following to determine the new label name:
     *   sprintf(str, "P_%s_L___%d", func_name, max_scope);
     * But it introduced a problem in self-recursive cases: two labels differ
     * only in their scope numbers. Say, P_foo1_L_1 and P_foo1_L_2. When this
     * function is inlined to another function, they become the same name. 
     * For example:
     * 	foo1()
     * 	{
     *	    int P_i_1;
     *	    {
     *		int P_i_2;
     *		    :
     *		    :
     *		P_foo1_L_10:
     *	    }
     *		    :
     *		    :
     *	    P_foo1_L_10:
     *  }
     * The reason that P_foo1_L_n got messed up but P_i_n not is because that
     * labels are renamed by the current maximum scope numbers. So if all the
     * labels are put near the end of its corresponding compound stmt, they 
     * will all end up using the last scope number, and become the same label
     * name.
     */

#if 0
    sprintf(str, "P_%s_%d_L___%d", func_name, max_label++, max_scope);
#endif
    /* 
     * label_scope_index+1 points to the scope number of the outmost compound
     * statement in the callee
     */
    /*
     * BCC - 4/20/96
     * In the new method, the scope number is enough to distinguish labels
     * with the same prefix. I added a stack called label_scope_stack which
     * stores the current and enclosing compound statements' scope number. 
     * Whenever a "{" is seen, the label_scope_stack is advanced by one, and 
     * store the last scope number to the stack. Whenever a "}" is seen, the
     * last one's corresponding scope number is popped out and used for labels
     * seen later. The reason why it needs such a stack is that a label can 
     * be used without declaration, not like the local variables. For local
     * variables, they got renamed before parsing any enclosed compound 
     * statements, so we don't need a stack to store the current or past scope
     * numbers. But for labels, after parsing nested compound statements the
     * current scope number is gone. 
     */
    sprintf(str, "P_%s_L___%d", func_name, 
	    label_scope_stack[label_scope_index+1]);
#if 0
    label_name = (char *) malloc (strlen(str)+1);
    sprintf(label_name, "%s", str);
#endif

    /* replace every return in the callee with goto */
    Return2Goto(new_stmt, lvar, str);

    /* add a label to the very end of the compound stmt */
    last_stmt = new_stmt->stmtstruct.compound->stmt_list;
    if (last_stmt) {
	Label label;

	while (last_stmt->lex_next) 
	    last_stmt = last_stmt->lex_next;
	goto_stmt = NewStmt();
	goto_stmt->type = ST_NOOP;
	/* TLJ 6/3/96 */
	goto_stmt->profile = CopyProfST(stmt->profile);
	label = NewLabel();
	label->type = LB_LABEL;
	label->val = strdup(str);
	AddStmtLabel(goto_stmt, label);
        Insert_Stmt_After(last_stmt, goto_stmt);
    }

    /* then free the current statement expression */
    RemoveExpr(stmt->stmtstruct.expr);

    /* then change the current statement to the inlined compound statement */
    stmt->type = ST_COMPOUND;
    stmt->stmtstruct.compound = new_stmt->stmtstruct.compound;

    /* param has been moved to compound statement as lvars.
       stmt has been moved to caller. So set them to zero in order not to be
       freed twice.							   */
    calleeFuncDcl->param = 0;
    calleeFuncDcl->stmt->stmtstruct.compound = 0;
#if 0
    /* Since the callee function is not entered to the symbol table, the
       type field could be freed , see the comment of RemoveFuncDcl(),
       which is in Pcode/struct.c */
    RemoveType(calleeFuncDcl->type);
#endif
    RemoveFuncDcl(calleeFuncDcl);
}

bool IsSameFunctionType(Type t1, char *name)
{
    VarDcl var;

    var = FindVarNoScopeId(name);
    if (var) return SameType(t1, var->type, 1);
    else return 0;
}

/* 
 * Original code : (*func)(i,j,k); and func could be foo1 or foo2
 * Transformed code :
 *	if (func == foo1) 
 *		foo1(i,j,k);
 *	else if (func == foo2)
 *		foo2(i,j,k);
 *	else (*func)(i,j,k);
 */
Call2If(stmt, call)
Stmt stmt;
Expr call;
{
    IfStmt new_if;
    Expr indr, expr, new_call, op;
    Expr cond, assign, this_expr;
    Stmt init, last_if, new_stmt, true;
    Pragma pragma, this_pragma;
    Pragma_List PL, pl1, pl2;
    Type ty;
    ProfST ptr;
    int i;
    int max_expansions;
    double ratio;
    int reason;

    init = last_if = 0;
    expr = stmt->stmtstruct.expr;	/* OP_call || OP_assign */
    indr = call->operands;		/* OP_indr */		
    if (expr->opcode == OP_call) {
	this_expr = expr;
	pragma = this_expr->pragma;		/* OP_call */
    } 
    else {
	this_expr = GetOperand(expr, 2);
	pragma = this_expr->pragma;		/* OP_assign */
    }

    if (pragma == 0) {
	if (print_inline_stats)
	    fprintf(Flog, "Warning: indirect call has no pragma with it\n");
	return;
    }

    PL = 0;
    i = 1;
    while (pragma) {
	int dummy;
	CG_Node cg_node;
	char *str;

        /* if pragma is not CALL pragma, skip it */
        if (strcmp(pragma->specifier, "\"CALLNAME\"")) {
            pragma = pragma->next;
            continue;
        }
	/* BCC - in 132.ijpeg, we get different function types between the 
	 *       function pointer and the actual callee. Generating the 
	 *	 assignment blindly produces syntax errors in the HtoC 
	 *	 translation. e.g. void * = void. See jcsample.c/
	 *	 jinit_downsampler.
	 */
	str = DQString2String(pragma->expr->value.string);
	reason = 0;
	if (C_find(mapping_table_ID, str, 0, &dummy, (Pointer *) &cg_node) &&
	    cg_node->indir_weight > min_expansion_weight) {
	    if ( (cg_node == ActiveCG_Node ? reason = 1 : 0) ||
		 (ActiveCG_Node->bodysize+cg_node->bodysize > max_function_size
		  ? reason = 2 : 0) ||
		 (ActiveCG_Node->stacksize+cg_node->stacksize>max_sf_size_limit 
		  ? reason = 3 : 0) ||
		 (cg_node->vararg ? reason = 4 : 0) || 
		 (
		(!IsEqualParameters(call->operands->sibling,cg_node->num_parms))
		  ? reason = 5 : 0) ||
		 ((!IsSameFunctionType(call->operands->type, cg_node->funcname))
		  ? reason = 6 : 0)) {

		char *msg[] = {
		    "this message shouldn't appear",
		    " is self-recursive",
		    "'s code size is too large",
		    "'s stack size is too large",
		    " is a vararg function",
		    " has different parm number",
		    " has different return type"
		};

		this_pragma = pragma;
		pragma = pragma->next;
		RemoveExprPragma(this_expr, this_pragma);
		free(str);
		str = 0;
		if (print_inline_stats) 
		    fprintf(Flog, "\"%s\"%s\n", cg_node->funcname, msg[reason]);
		continue;
            }
	    i++;
	    pl1 = (Pragma_List) malloc (sizeof(_Pragma_List));
	    strcpy(pl1->funcname, pragma->expr->value.string);
	    /* BCC - now use indir_weight as measurements - 10/23/96 */
#if 0
	    pl1->weight = cg_node->weight - cg_node->discount;
#endif
	    pl1->weight = cg_node->indir_weight;
	    pl1->next = PL;
	    PL = pl1;
	    while (pl1) {
		if (pl1->next && pl1->weight < pl1->next->weight) {
		    char temp[1024];
		    double wtemp;

		    strcpy(temp, pl1->funcname);
		    wtemp = pl1->weight;
		    strcpy(pl1->funcname, pl1->next->funcname);
		    pl1->weight = pl1->next->weight;
		    strcpy(pl1->next->funcname, temp);
		    pl1->next->weight = wtemp;
		}
		pl1 = pl1->next;
	    }
	}
	else {
	    if (!C_find(mapping_table_ID,str,0,&dummy, (Pointer *) &cg_node)) {
		if (print_inline_stats)
		    fprintf(Flog, "  Indirect function %s is a library call\n", 
			pragma->expr->value.string);
	    }
	    else {
		if (print_inline_stats)
		    fprintf(Flog, "%s's indirect weight is %f\n", 
			    pragma->expr->value.string, cg_node->indir_weight);
	    }
	}
	if (str) free(str);
	str = 0;
	this_pragma = pragma;
	pragma = pragma->next;
	RemoveExprPragma(this_expr, this_pragma);
    }

    /* Distribute the weight to all possible callees */
    ActiveCG_Arc->weight /= i;
    ActiveCG_Arc->discount /= i;


#if 0
    ptr = stmt->profile;
    while (ptr != NIL) {
	ptr->count *= 1.0/i;
	ptr = ptr->next;
    }
    Scale_Expr_Weight(expr, 1.0/i);
#endif

    pl1 = PL;
    max_expansions = 0;
    if (print_inline_stats)
	fprintf(Flog, "Total possible callees %d\n", i-1);
    while (pl1) {
	/* BCC - only expand when there is 1 alias - 10/24/96 */
#if 0
	if (max_expansions < 3) {
#endif
	if (i == 2) {
	    char *str;

	    new_stmt = NewStmt();
	    new_stmt->type = ST_IF;
	    /* TLJ 6/11/96 Copy the scaled profile weight here 
	     * (this needs to be fixed to the correct scaled value for
	     * the entire if statement)
	     */
	    new_stmt->profile = CopyProfST(stmt->profile);
	    if (init == 0) init = new_stmt;
	    if (last_if != 0) last_if->stmtstruct.ifstmt->else_block = new_stmt;
	    new_if = NewIfStmt();
	    cond = NewExpr(OP_eq);
	    ty = CopyType(indr->type);
	    AddOperand(cond, CopyExpr(indr->operands));

	    /* BCC -garbage collection - 8/25/96 */
	    str = DQString2String(pl1->funcname);
	    AddOperand(cond, NewVarExpr(FindString(str), ty));
	    free(str);

	    CastExpr(cond);
	    new_if->cond_expr = cond;
	    /*
	     * True part
	     */
	    true = NewStmt();
	    true->type = ST_EXPR;
	    /* TLJ 6/11/96 Copy the scaled profile weight here */
	    true->profile = CopyProfST(stmt->profile);
	    new_call = NewExpr(OP_call);
	    ty = CopyType(ty);

	    /* BCC -garbage collection - 8/25/96 */
	    str = DQString2String(pl1->funcname);
	    AddOperand(new_call, NewVarExpr(FindString(str), ty));
	    free(str);

	    for (i=2; (op=GetOperand(call, i)) != 0; i++) {
		AddOperand(new_call, CopyExprList(op));
	    }
	    if (expr->opcode == OP_call) assign = new_call;
	    else {
		assign = NewExpr(OP_assign);
		AddOperand(assign, CopyExpr(GetOperand(expr, 1)));
		AddOperand(assign, new_call);
	    }
	    CastExpr(assign);
	    true->stmtstruct.expr = assign;
	    new_if->then_block = true;
	    new_stmt->stmtstruct.ifstmt = new_if;
	    last_if = new_stmt;
	    max_expansions++;
	}
	pl2 = pl1;
	pl1 = pl1->next;
	free(pl2);
    }
    /*
     * The call has been expanded or checked, put a DONTINLINE pragma to it 
     */
    if (FindExprPragma(call, "\"DONTINLINE\"") == 0) {
	Expr exp;

	exp = NewIntExpr(0);
	AddExprPragma(call, "\"DONTINLINE\"", exp);
	RemoveExpr(exp);
    }
    /* 
     * safe guard, final else
     */
    if (last_if == NIL) return 0;	/* No if stmt created, just return */
    new_stmt = NewStmt();
    new_stmt->type = ST_EXPR;
    new_stmt->stmtstruct.expr = expr;
    /* TLJ 6/11/96 Copy the scaled profile weight here */
    new_stmt->profile = CopyProfST(stmt->profile);
    last_if->stmtstruct.ifstmt->else_block = new_stmt;

    /* BCC - 7/12/96 - recycle the first stmt structure */
    stmt->type = ST_IF;
    stmt->stmtstruct.ifstmt = init->stmtstruct.ifstmt;

    /* BCC - garbage collection - 8/25/96 */
    init->stmtstruct.ifstmt = 0;
    RemoveStmt(init);

    LinkStmtsRt(stmt->stmtstruct.ifstmt->then_block, stmt, 0);
    LinkStmtsRt(stmt->stmtstruct.ifstmt->else_block, stmt, 0);
    LinkExpr(stmt->stmtstruct.ifstmt->cond_expr, stmt, 0, 0);

    init = stmt;

    /* BCC - adjust the scaled weight in the nested IF stmts - 6/13/96 */
    ratio = 1.0 / (max_expansions + 1);
    for (i = 0; i <= max_expansions; i++) {
	if (i != max_expansions) {
	    /* BCC - 7/12/96
	     * ST_IF need two profile weight : one for the cond and one for
	     * the else part
	     */
	    ProfST new_prof;

	    ptr = init->profile;
	    while (ptr != NIL) {
		ptr->count *= 1.0 - ratio*i;
		ptr = ptr->next;
	    }
	    Scale_Expr_Weight(init->stmtstruct.ifstmt->cond_expr, 1.0-ratio*i);
	    Scale_Stmt_Weight(init->stmtstruct.ifstmt->then_block, ratio);
	    new_prof = NewProfST(init->profile->count - 
		       init->stmtstruct.ifstmt->then_block->profile->count);
	    assert(init->profile->next == NULL);
	    init->profile->next = new_prof;
	    init = init->stmtstruct.ifstmt->else_block;
	}
	else 
	    Scale_Stmt_Weight(init, ratio);
    }

    Expand_Call_Stmts(stmt->stmtstruct.ifstmt->then_block, 1);
    Expand_Call_Stmts(stmt->stmtstruct.ifstmt->else_block, 1);

    /* After expanding all the possible callees, then remove the call arc */
    /* take out the just expanded call arc */
    if (ActiveCG_Arc->prev)
	ActiveCG_Arc->prev->next = ActiveCG_Arc->next;
    if (ActiveCG_Arc->next)
	ActiveCG_Arc->next->prev = ActiveCG_Arc->prev;
    if (ActiveCG_Arc->callsite->first == ActiveCG_Arc)
	ActiveCG_Arc->callsite->first = ActiveCG_Arc->next;
    if (ActiveCG_Arc->callsite->last == ActiveCG_Arc)
	ActiveCG_Arc->callsite->last = ActiveCG_Arc->prev;

    RemoveCG_Arc(ActiveCG_Arc);
    ActiveCG_Arc = 0;

    return 1;
}

/* return 1: found the matching call expr. return 0: keep searching */
static Expand_Call_Expr(stmt, no_pragma)
Stmt stmt;
int no_pragma;
{
    char *func_name;
    Expr expr = stmt->stmtstruct.expr;
    Pragma pragma;
    Expr op1, op2;

    if (expr->next != NIL) return 0;   /* expr list "a(),b()" won't be inlined */
    switch (expr->opcode) {
	case OP_call:	/* inlining a() */
	    if (no_pragma == 0) {	/* natural function calls */
		pragma = FindExprPragma(expr, "\"ARC_ID\"");
		if (!pragma || 
		    pragma->expr->value.scalar != ActiveCG_Arc->arc_id)
		    return 0;
		else
		    RemoveExprPragma(expr, pragma);
		/* call through pointer */
		if (expr->operands->opcode == OP_indr) {
		    /* Single-callname indirect call has been replaced by
		       direct calls
		    if (inline_function_pointers) 
			Call2If(stmt, expr);
		    */
		    return 1;
		}
		func_name = expr->operands->value.var_name;
		assert(func_name != NIL); 
		Expand_Callee(stmt, expr, func_name, 0, 0);
		break;
	    }
	    else {			/* introduced by Call2If */
		/* final safe guard */
		if (expr->operands->opcode == OP_indr) return 0;

		func_name = expr->operands->value.var_name;
		assert(func_name != NIL); 
		Expand_Callee(stmt, expr, func_name, 0, 1);
		return 0;	/* return 0 to inline subsquent calls */
	    }
	case OP_assign:	/* inlining b = a(); */

	    op1 = GetOperand(expr, 1);
	    op2 = GetOperand(expr, 2);
	    if (op2->opcode != OP_call) return 0;

	    if (no_pragma == 0) {	/* natural function calls */
		pragma = FindExprPragma(op2, "\"ARC_ID\"");
		if (!pragma || pragma->expr->value.scalar!=ActiveCG_Arc->arc_id)
		    return 0;
		else
		    RemoveExprPragma(op2, pragma);
		/* call through pointer */
		if (op2->operands->opcode == OP_indr) {
		    /* Single-callname indirect call has been replaced by
		       direct calls
		    if (inline_function_pointers) 
			Call2If(stmt, op2);
		    */
		    return 1;
		}
		func_name = op2->operands->value.var_name;
		assert(func_name != NIL); 
		Expand_Callee(stmt, op2, func_name, op1, 0);
		break;
	    }
	    else {			/* introduced by Call2If */
		/* final safe guard */
		if (op2->operands->opcode == OP_indr) return 0;

		func_name = op2->operands->value.var_name;
		assert(func_name != NIL); 
		Expand_Callee(stmt, op2, func_name, op1, 1);
		return 0;
	    }
	default : 
	    return 0;
    }
    return 1;
}

static Expand_Call_Stmts(stmts, no_pragma)
Stmt stmts;
int no_pragma;
{
    SerLoop serloop;
    ParLoop parloop;

    while (stmts != NIL) {
        switch (stmts->type) {
            case ST_NOOP:
            case ST_CONT:
            case ST_BREAK:
            case ST_GOTO:
            case ST_ADVANCE:
            case ST_AWAIT:
            case ST_RETURN:
                break;
            case ST_COMPOUND:
                if (Expand_Call_Stmts(stmts->stmtstruct.compound->stmt_list,
				      no_pragma)) 
		    return 1;
                break;
            case ST_IF:
                if (Expand_Call_Stmts(stmts->stmtstruct.ifstmt->then_block,
				      no_pragma))
		    return 1;
                if (stmts->stmtstruct.ifstmt->else_block != NIL &&
                    Expand_Call_Stmts(stmts->stmtstruct.ifstmt->else_block,
		                      no_pragma))
			return 1;
                break;
            case ST_SWITCH:
                if (Expand_Call_Stmts(stmts->stmtstruct.switchstmt->switchbody,
				      no_pragma))
		    return 1;
                break;
            case ST_EXPR:
                if (Expand_Call_Expr(stmts, no_pragma) == 1) { 
		    /* BCC - 8/29/96
		     * need to update the parent-stmt pointers because the old 
		     * one has been freed or CF_Stmt() will access the old one
		     */
		    LinkStmts(currentFuncDcl);
		    LinkLoops(currentFuncDcl);
		    return 1;
		}
                break;
            case ST_PSTMT:
                if (Expand_Call_Stmts(stmts->stmtstruct.pstmt->stmt, no_pragma))
		    return 1;
		break;
            case ST_MUTEX:
                if (Expand_Call_Stmts(stmts->stmtstruct.mutex->statement,
				      no_pragma))
		    return 1;
                break;
            case ST_COBEGIN:
                if (Expand_Call_Stmts(stmts->stmtstruct.cobegin->statements,
				      no_pragma))
		    return 1;
                break;
            case ST_SERLOOP:
                serloop = stmts->stmtstruct.serloop;
                if (Expand_Call_Stmts(serloop->loop_body, no_pragma))
		    return 1;
                break;
            case ST_PARLOOP:
                parloop = stmts->stmtstruct.parloop;
                if (Expand_Call_Stmts(Parloop_Stmts_Prologue_Stmt(stmts),
				      no_pragma))
		    return 1;
                break;
            case ST_BODY:
                if (Expand_Call_Stmts(stmts->stmtstruct.bodystmt->statement,
				      no_pragma))
		    return 1;
                break;
            case ST_EPILOGUE:
                if (Expand_Call_Stmts(stmts->stmtstruct.epiloguestmt->statement
				      , no_pragma))
		    return 1;
                break;
            default:
                Punt("Expand_Call_Stmt: Invalid statement type", stmts);
        }
        stmts = stmts->lex_next;
    }
    return 0;
}

void InlineCalleeFunction(func)
FuncDcl func;
{
    int i;

    assert(func != NIL);
    /*=======================================================================
       This function is called to find out the INLINABLE function call stmts
       in the call site. Before flattening, only a() and b = c(); can be
       inlined.
      =======================================================================*/
    /* Expansion issued here needs to matching the pragma */
    Expand_Call_Stmts(func->stmt, 0);
}
