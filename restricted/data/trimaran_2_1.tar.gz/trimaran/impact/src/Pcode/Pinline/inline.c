/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.20  */
/* IMPACT Trimaran Release (www.trimaran.org)                  May 17, 1999  */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   inline.c
 *      Author: Ben-Chung Cheng, Wen-mei Hwu
\*****************************************************************************/


#include <stdio.h>
#include <library/list.h>
#include <library/l_parms.h>
#include <library/c_symbol.h>
#include <Pcode/parms.h>
#include <Pcode/pcode.h>
#include <Pcode/read_pcode.h>
#include <Pcode/symtree.h>
#include <math.h>
#include "inline.h"

#define	MAX_FILES	10000
#define MAX_CHARS	2048

static struct {
    char *file_name;
    char *func_name;
    CG_Node node;	/* node in the call graph */
} files[MAX_FILES];

int mapping_table_ID;
static int fc = 0;
static char *data_file;
static char *extern_file;
static char *struct_file;
int KEY_DIFFERENCE = 1.0;
double MaxBodySize;
double TotalBodySize;
double TouchedBodySize;
double TotalStackSize;
int print_inline_stats;
char *il_log_name;
int max_sf_size_limit;
double max_expansion_ratio;
int max_function_size;
double min_expansion_weight;
double min_expansion_key;
char *sp_output_spec;
char *il_output_dir_string;
int inline_function_pointers;
int regroup = 0;
int regroup_only = 0;
double assumed_body_size = 1.0;
/* BCC - added for Brian's experiment - 9/9/97 */
int size_only = 0;
/* BCC - new parameters - 1/9/98 */
int favor_small_functions = 1;
int use_touched_body_size = 1;
/* JCG - new parameter 6/26/98, to allow backward compatibility for NYU*/
int use_new_regroup_algorithm = 0;

CG_Node NextCG_Node, ActiveCG_Node;
CG_Arc NextCG_Arc, ActiveCG_Arc;

Heap *arc_heap;

int find_indirect_weight;
char split_file_path[1024];

/* BCC - used for Pinling.log - 5/9/96 */
FILE *Flog;

/*	Copy one file to the other
 *	Need this stupid function because system("mv f1.c f2.c"); fails on HP
 */
StupidCopy(fptr1, fptr2)
FILE *fptr1, *fptr2;
{
    char line[MAX_CHARS];
    while (fgets(line, MAX_CHARS, fptr1)) {
	fputs(line, fptr2);
    }
}

void P_read_parm_Pinline(ppi)
Parm_Parse_Info *ppi;
{
    L_read_parm_b(ppi, "print_inline_stats", &print_inline_stats);
    L_read_parm_s(ppi, "il_log_name", &il_log_name);
    L_read_parm_i(ppi, "max_sf_size_limit", &max_sf_size_limit);
    L_read_parm_lf(ppi, "max_expansion_ratio", &max_expansion_ratio);
    L_read_parm_i(ppi, "max_function_size", &max_function_size);
    L_read_parm_lf(ppi, "min_expansion_weight", &min_expansion_weight);
    L_read_parm_lf(ppi, "min_expansion_key", &min_expansion_key);
    L_read_parm_s(ppi, "sp_output_spec", &sp_output_spec);
    L_read_parm_s(ppi, "il_dir", &il_output_dir_string);
    L_read_parm_b(ppi, "inline_function_pointers", &inline_function_pointers);
    L_read_parm_b(ppi, "regroup", &regroup);
    L_read_parm_b(ppi, "regroup_only", &regroup_only);
    L_read_parm_b(ppi, "size_only", &size_only);
    L_read_parm_b(ppi, "favor_small_functions", &favor_small_functions);
    L_read_parm_b(ppi, "use_touched_body_size", &use_touched_body_size);
    L_read_parm_b(ppi, "?use_new_regroup_algorithm", 
		  &use_new_regroup_algorithm);
#if 0
    if (min_expansion_weight <= 0.001) min_expansion_weight = 0.001;
#endif
    if (regroup_only) regroup = regroup_only;
}

/*
 *      Read in parameters
 */
ReadParms(argc, argv, envp)
int argc;
char** argv;
char** envp;
{
    char *prog_name;                /* program name */
    char *P_parm_file;

    /* get program arguments */
    prog_name = *argv;

    P_parm_file = L_get_std_parm_name(argv, envp, "STD_PARMS_FILE",
                                      "./STD_PARMS");

    L_load_parameters(P_parm_file,
                      L_create_external_macro_list(argv, envp),
                      "(Pcode", P_read_parm_Pcode);

    L_load_parameters(P_parm_file,
                      L_create_external_macro_list(argv, envp),
                      "(Pinline", P_read_parm_Pinline);

    /* BCC/ITI - 2/10/99 */
    if (resolve_machine_dependent_information) 
    {
	/*
	 * BCC - 4/2/96
	 * In order to invode Mspec, so needs to know $arch and $model
	 */
	/* Renamed 'architecture' to 'Larchitecture' -JCG 5/26/98 */
	L_load_parameters_aliased (P_parm_file,
				   L_create_external_macro_list(argv, envp),
				   "(Larchitecture", "(architecture", 
				   P_read_parm_arch);
	
	/*
	 * BCC - 4/2/96
	 * Now set the machine related information
	 */
	M_set_machine(P_arch, P_model);
	
	/*
	 * BCC - 4/2/96
	 * Then get the size of each integer type
	 */
	P_GetIntegerSize(); 
    }

    output_form = OUTPUT_PCODE;
    do_inline = 1;
}

/*
 *      Add a new file (to be processed) to the system.                       
 */
static AddFile(filename, funcname, node)
char *filename;
char *funcname;
CG_Node node;
{
    int i;
    if (fc >= MAX_FILES) Punt("too many input files");
    for (i=0; i<fc; i++) {
        if (! strcmp(files[i].file_name, filename)) {
	    if (print_inline_stats)
		fprintf(Flog, "# file name (%s) has been used more than once\n",
			filename);
            Punt("sorry");
        }
    }
    files[fc].file_name = C_findstr(filename);
    files[fc].func_name = C_findstr(funcname);
    files[fc].node = node;
    fc ++;
    return (fc - 1);
}

CalleeInfo NewCalleeInfo()
{
    CalleeInfo new;

    new = ALLOCATE(_CalleeInfo);
    new->name = 0;
    new->next = 0;
    return new;
}

AliasInfo NewAliasInfo()
{
    AliasInfo new;

    new = ALLOCATE(_AliasInfo);
    new->name = 0;
    new->callee = 0;
    new->next = 0;
    return new;
}

CG_Node NewCG_Node()
{
    CG_Node new;

    new = ALLOCATE(_CG_Node);
    new->id = 0;
    new->num_parms = 0;
    new->vararg = 0;
    new->bodysize = 0;
    new->stacksize = 0;
    new->bodysize2 = 0;
    new->stacksize2 = 0;
    new->weight = 0.0;
    new->indir_weight = 0.0;
    new->first_op_weight = 0.0;
    new->myself = 1.0;
    new->weight = 0.0;
    new->discount = 0.0;
    new->path = 0;
    new->newpath = 0;
    new->scalepath = 0;
    new->funcname = 0;
    new->noninlinable = 0;
    new->first = 0;
    new->last = 0;
    new->alias = 0;
    return new;
}

CG_Arc NewCG_Arc()
{
    CG_Arc new;

    new = ALLOCATE(_CG_Arc);
    new->status = 0;
    new->arc_id = 0;
    new->callsite = 0;
    new->callee = 0;
    new->weight = 0.0;
    new->discount = 0.0;
    new->fraction = 0.0;
    new->ratio = 0.0;
    new->next = 0;
    new->prev = 0;
    return new;
}

void RemoveCG_Arc(arc)
CG_Arc arc;
{
    arc->callsite = 0;
    arc->callee = 0;
    arc->next = 0;
    arc->prev = 0;
    DISPOSE(arc);
}

static void Dump_CG_Node(n)
CG_Node n;
{
    if (print_inline_stats) {
	fprintf(Flog, "id = %d\n", n->id);
	fprintf(Flog, "num_parms = %d\n", n->num_parms);
	fprintf(Flog, "vararg = %d\n", n->vararg);
	fprintf(Flog, "bodysize = %d\n", n->bodysize);
	fprintf(Flog, "stacksize = %d\n", n->stacksize);
	fprintf(Flog, "bodysize2 = %d\n", n->bodysize2);
	fprintf(Flog, "stacksize2 = %d\n", n->stacksize2);
	fprintf(Flog, "weight = %f\n", n->weight);
	fprintf(Flog, "indir weight = %f\n", n->indir_weight);
	fprintf(Flog, "first op weight = %f\n", n->first_op_weight);
	fprintf(Flog, "myself = %f\n", n->myself);
	fprintf(Flog, "discount = %f\n", n->discount);
	fprintf(Flog, "path = %s\n", n->path);
	fprintf(Flog, "newpath = %s\n", n->newpath);
	fprintf(Flog, "scalepath = %s\n", n->scalepath);
	fprintf(Flog, "funcname = %s\n", n->funcname);
    }
}

static void Dump_CG_Arc(c)
CG_Arc c;
{
    if (print_inline_stats) {
	if (size_only == 0) {
	    fprintf(Flog, "arc_id      = %d\n", c->arc_id);
	    fprintf(Flog, "callsite    = %s\n", c->callsite->funcname);
	    if (c->callee) 
		fprintf(Flog, "callee      = %s\n", c->callee->funcname);
	    else 
		fprintf(Flog, "callee is a function pointer\n");
	    fprintf(Flog, "bodysize = %d\n", c->callsite->bodysize);
	    fprintf(Flog, "stacksize = %d\n", c->callsite->stacksize);
	    fprintf(Flog, "bodysize2 = %d\n", c->callsite->bodysize2);
	    fprintf(Flog, "stacksize2 = %d\n", c->callsite->stacksize2);
	    fprintf(Flog, "weight      = %f\n", c->weight);
	    fprintf(Flog, "discount    = %f\n", c->discount);
	}
	else {
	    fprintf(Flog, "arc_id      = %d\n", c->arc_id);
	    fprintf(Flog, "callsite    = %s\n", c->callsite->funcname);
	    if (c->callee) 
		fprintf(Flog, "callee      = %s\n", c->callee->funcname);
	    else 
		fprintf(Flog, "callee is a function pointer\n");
	    fprintf(Flog, "bodysize = %d\n", c->callsite->bodysize);
	    fprintf(Flog, "stacksize = %d\n", c->callsite->stacksize);
	}
    }
}

/*
 *	Read in the mapping file
 */
static ReadFunctionMap(filename)
char *filename;
{
    LIST list, opcode;
    char *op;
    char *oldname, *newname, *funcname;
    LIST ptr1, ptr2;
    int want2inline;

    if (lexOpen(filename, 0)==0)
        Punt("cannot open the inline_spec file");
    /* 
     *	Allocate a name mapping table
     */
    mapping_table_ID = C_open_name_table(MAX_FILES);

/* mapping file format : (map (pcode/file.c foo) to (impact_dir1/f_0.pc foo)) */
    for (; (list=GetNode())!=0; DisposeNode(list)) {
        if (NodeType(list)==T_EOF) {
	    DisposeNode(list);
	    break;
	}
        if (NodeType(list)!=T_LIST) 
	    Punt("illegal mapping file : Parenthesis needed");
	opcode = ChildOf(list);
	op = StringOf(opcode);
	if (! strcmp(op, "map")) {
	    CG_Node cg_node;
	    char buffer[256];

	/* BCC - added one more field about inlinability in the map - 7/9/96 */
            want2inline = IntegerOf(SiblingOf(opcode));
	    ptr1 = SiblingOf(SiblingOf(opcode));
	    ptr2 = SiblingOf(SiblingOf(SiblingOf(SiblingOf(opcode))));
	    funcname = StringOf(SiblingOf(ChildOf(ptr2)));
	    oldname = StringOf(SiblingOf(ChildOf(ptr1)));
	    newname = StringOf(ChildOf(ptr2));
	    oldname = C_findstr(oldname);
	    newname = C_findstr(newname);
	    sprintf(buffer, "%s", newname);
	    strcpy(split_file_path, newname);
	    strrchr(split_file_path, '/')[0] = 0;
	    /* create a new node struct */
	    cg_node = NewCG_Node();
	    cg_node->id = fc;
	    if (regroup_only)
		cg_node->path = C_findstr(buffer);
	    else
		cg_node->path = C_findstr(strcat(buffer,".temp"));
	    cg_node->funcname = C_findstr(funcname);
	    cg_node->noninlinable = !want2inline;
	    C_update(mapping_table_ID, oldname, 0, 0, cg_node);
	    AddFile(newname, funcname, cg_node);
	} else if (! strcmp(op, "data")) {
	    data_file = C_findstr(StringOf(SiblingOf(opcode)));
	} else if (! strcmp(op, "extern")) {
	    extern_file = C_findstr(StringOf(SiblingOf(opcode)));
	} else if (! strcmp(op, "struct")) {
	    struct_file = C_findstr(StringOf(SiblingOf(opcode)));
	}
    }
    lexClose(filename);
}

/*
 *      Create the working directory.
 */
static MakeImpactDirectory() {
    if (print_inline_stats)
	fprintf(Flog, "Removing output directory : %s\n", il_output_dir_string);
    Rmdir(il_output_dir_string);
    Mkdir(il_output_dir_string);
}

/*
 *      Process a file
 */
static ProcessFile(file_name)
char *file_name;
{
    LIST list;

#if 0
    imp_print_alloc();
#endif 
    if (lexOpen(file_name, 0)==0)
        Punt("cannot open input file");
#if 0
    for (; (list=GetNode())!=0; DisposeNode(list)) {
        if (NodeType(list)==T_EOF) {
	    DisposeNode(list);
            break;
	}
        ProcessList(list);      /* ccode */
    }
#endif
    /* BCC - for new Pcode - 5/9/96 */
    while (P_get_input() != P_INPUT_EOF) {
	process_input();
    }

    lexClose(file_name);

    if (do_inline == 0) {
	/* housekeeping stuff */
	Pinline_GarbageCollection();
#if 0
	ClearSymTbl(SymbolTable[TBT_FUNC]);
	ClearSymTbl(SymbolTable[TBT_TYPEDEF]);
	ResetSymbolTables();
#endif
	scope = 0;
    }

#ifdef DEBUG
    fprintf(Flog, "Max Scope = %d\n", max_scope);
#endif
}

/*
 * Purpose of this phase :
 *      1) Annotate the call-through-pointer functions 
 *	2) Find out the weight of each function
 *
 * How it works :
 *	1) Using the variable do_annotate_function as a flag
 *	2) In SetupInlineHandler() the function pointer is set
 *	3) In Pcode/process.c/ProcessFuncDcl() the handler is actually called
 */

static Preprocess()
{
    int i;
    int dummy;
    char f_name[256];
    char command[256];
    char *func_name;
    CG_Arc arc_ptr;

    do_inline = 0;
    do_annotate_function = 1;
    if (Fout != 0 && Fout != stdout) {
	fclose(Fout);
	Fout = 0;
    }

    arc_heap = Heap_Create(HEAP_MAX);

    /* 
     * .temp  : all the call arcs inside the file are assigned a specific ID
     * .scale : all the weight in the file are scaled to the first_op. This is
     *		for handling self-recursion
     */
    if (print_inline_stats)
	fprintf(Flog, "Annotating function calls\n");
    for (i=0; i<fc; i++) {
	func_name = files[i].func_name;
	C_find(mapping_table_ID, func_name, 0, &dummy, 
	       (Pointer *) &ActiveCG_Node);
	sprintf(f_name, "%s.temp", files[i].file_name);
	Fout = fopen(f_name, "wt");
	if (Fout == 0) Punt("Can't open output file");
	if (print_inline_stats)
	    fprintf(Flog, "Process input file : %s\n", files[i].file_name);
	ProcessFile(files[i].file_name);
	fclose(Fout);
	Fout = 0;

	/* BCC - use touched body size to determine the max body size */
	if (size_only) {
	    TouchedBodySize += ActiveCG_Node->bodysize;
	}
	else {
	    if (ActiveCG_Node->weight)
		TouchedBodySize += ActiveCG_Node->bodysize;
	}

	if (print_inline_stats)
	    fprintf(Flog, "Node weight = %f\n", ActiveCG_Node->weight);

	/* Make a scaled copy for the natural-born self-recursive function */
	for (arc_ptr = ActiveCG_Node->first; arc_ptr; arc_ptr = arc_ptr->next) {
	    if ( (size_only == 0) && RECURSIVE(arc_ptr) ) {
		char scale_path[512];
		if (print_inline_stats)
		    fprintf(Flog, "Natural self-recursion found in %s\n", 
			    arc_ptr->callsite->funcname);
		ActiveCG_Node->first_op_weight = ActiveCG_Node->weight;
		sprintf(scale_path, "%s.scale", files[i].file_name);
		ActiveCG_Node->scalepath = C_findstr(scale_path);
                Fout = fopen(scale_path, "wt");
		if (Fout == 0) Punt("Can't open output file");
		do_annotate_function = 0;
		if (ActiveCG_Node->weight > 0.0) 
		    out_fraction = 1.0 / ActiveCG_Node->weight;
		else
		    out_fraction = 0.0;
		ProcessFile(files[i].file_name);
		do_annotate_function = 1;
		out_fraction = 1.0;
		fclose(Fout);
		Fout = 0;
		
		/* 
		 * scale copy has the same body/stack size as the original copy
		 */
		ActiveCG_Node->bodysize2 = ActiveCG_Node->bodysize;
		ActiveCG_Node->stacksize2 = ActiveCG_Node->stacksize;

		break;
	    }
	}
    }
    if (print_inline_stats)
	fprintf(Flog, "Done\n\n");
    do_inline = 1;
    do_annotate_function = 0;

    dummy = 0;
    if (print_inline_stats)
	fprintf(Flog, "-------------- INDIR CALL WEIGHTS --------------\n");
    for (i=0; i<fc; i++) {
	files[i].node->indir_weight = files[i].node->weight - 
				      files[i].node->indir_weight;
	if (print_inline_stats && files[i].node->indir_weight > 0.0) {
		fprintf(Flog, "%-20s %f\n", 
		    files[i].node->funcname, files[i].node->indir_weight);
	    dummy++;
	    assumed_body_size += files[i].node->bodysize;
	}
    }
    assumed_body_size /= dummy;
    if (print_inline_stats) {
	fprintf(Flog, "%-18s= %f\n", "assumed_body_size", assumed_body_size);
	fprintf(Flog, "--------------         END        --------------\n");
    }
}

double keyof(arc)
CG_Arc arc;
{
    double weight;
    double size;

    if (!INDIRECT(arc))
	size = arc->callee->bodysize;
    else
	size = assumed_body_size;
    if (size_only == 0) {
	weight = arc->weight - arc->discount;
	if (RECURSIVE(arc) || INDIRECT(arc))
	    weight *= 0.8;
	if (weight > 0.0 && !RECURSIVE(arc) && !INDIRECT(arc) && 
	    size <= SMALL_FUNCTION && favor_small_functions) 
	    return weight > HUGE_KEY ? weight : HUGE_KEY;
	else { 
	    if (size != 0)
		return weight/sqrt((double)size);
	    else
		/* In the where foo1() calls foo2() and foo1() is preprocessed
		 * by Pinline earlier than foo2(), the size of foo2() will be
		 * 0 at this moment. If we return 0 instead of the estimated
		 * key by assuming the size is 1, later on when the size is
		 * resolved, the key will increase which will violate the 
		 * assumption that the key can only decrease because of the
		 * size of the callee can only increase
		 */
		/*
		return 0;
		*/
		return weight;
	}
    }
    else {
	if ((favor_small_functions && size <= SMALL_FUNCTION) || (size == 0))
	    return HUGE_KEY;
	else
	    return 10000.0 / sqrt((double)size);
    }
}

InlineFunction()
{
    double *dp, key, newkey;
    char f_name[256];
    char new_name[256];
    char *call_site;
    char command[256];
    int self_recursion;
    CG_Arc ptr;
    FILE *fptr1, *fptr2;

    if (Fout != 0 && Fout != stdout) {
        fclose(Fout);
        Fout = 0;
    }

    sprintf(f_name, "%s/struct.pch", il_output_dir_string);
    if (strcmp(struct_file, f_name)) {
	sprintf(command, "cp %s %s", struct_file, f_name);
	if (system(command)) {
	    fptr1 = fopen(struct_file, "rt");
	    fptr2 = fopen(f_name, "wt");
	    StupidCopy(fptr1, fptr2);
	    fclose(fptr1);
	    fclose(fptr2);
	}
    }

    sprintf(f_name, "%s/extern.pch", il_output_dir_string);
    if (strcmp(extern_file, f_name)) {
	sprintf(command, "cp %s %s", extern_file, f_name);
	if (system(command)) {
	    fptr1 = fopen(extern_file, "rt");
	    fptr2 = fopen(f_name, "wt");
	    StupidCopy(fptr1, fptr2);
	    fclose(fptr1);
	    fclose(fptr2);
	}
    }

    if (regroup_only)
	return;

    while ((dp = Heap_TopWeight(arc_heap))) {
	key = *dp;
	NextCG_Arc = (CG_Arc) Heap_ExtractTop(arc_heap);
	NextCG_Node = NextCG_Arc->callsite;
	if (print_inline_stats)
	    fprintf(Flog, "key = %f\n", key);
	Dump_CG_Arc(NextCG_Arc);
	/* BCC - use w/sqr(s) as the key - 10/24/96 */
#if 0
	newkey = KEYOF(NextCG_Arc);
	if (RECURSIVE(NextCG_Arc) || INDIRECT(NextCG_Arc)) newkey *= 0.8;
#endif
	newkey = keyof(NextCG_Arc);

	if ((size_only == 1) && RECURSIVE(NextCG_Arc)) {
	    /* take out the call arc */
	    if (NextCG_Arc->prev)
		NextCG_Arc->prev->next = NextCG_Arc->next;
	    if (NextCG_Arc->next)
		NextCG_Arc->next->prev = NextCG_Arc->prev;
	    if (NextCG_Arc->callsite->first == NextCG_Arc)
		NextCG_Arc->callsite->first = NextCG_Arc->next;
	    if (NextCG_Arc->callsite->last == NextCG_Arc)
		NextCG_Arc->callsite->last = NextCG_Arc->prev;
	    RemoveCG_Arc(NextCG_Arc);

	    if (print_inline_stats) {
		fprintf(Flog, "Recursive arc is ignored\n");
		fprintf(Flog, 
		    "---------------------------------------------------\n");
	    }
	    continue;
	}

	if (newkey < 0) {
	    /* take out the call arc */
	    if (NextCG_Arc->prev)
		NextCG_Arc->prev->next = NextCG_Arc->next;
	    if (NextCG_Arc->next)
		NextCG_Arc->next->prev = NextCG_Arc->prev;
	    if (NextCG_Arc->callsite->first == NextCG_Arc)
		NextCG_Arc->callsite->first = NextCG_Arc->next;
	    if (NextCG_Arc->callsite->last == NextCG_Arc)
		NextCG_Arc->callsite->last = NextCG_Arc->prev;
	    RemoveCG_Arc(NextCG_Arc);

	    if (print_inline_stats) {
		fprintf(Flog, "Warning : key is negtive\n");
		fprintf(Flog, 
		    "---------------------------------------------------\n");
	    }
	    continue;
	}

	if (newkey < min_expansion_key) {
	    /* take out the call arc */
	    if (NextCG_Arc->prev)
		NextCG_Arc->prev->next = NextCG_Arc->next;
	    if (NextCG_Arc->next)
		NextCG_Arc->next->prev = NextCG_Arc->prev;
	    if (NextCG_Arc->callsite->first == NextCG_Arc)
		NextCG_Arc->callsite->first = NextCG_Arc->next;
	    if (NextCG_Arc->callsite->last == NextCG_Arc)
		NextCG_Arc->callsite->last = NextCG_Arc->prev;
	    RemoveCG_Arc(NextCG_Arc);

	    if (print_inline_stats) {
		fprintf(Flog, "Newkey is small enough to be ignored\n");
		fprintf(Flog, 
		    "---------------------------------------------------\n");
	    }
	    continue;
	}

	if (TotalBodySize > MaxBodySize) {
	    /* take out the call arc */
	    if (NextCG_Arc->prev)
		NextCG_Arc->prev->next = NextCG_Arc->next;
	    if (NextCG_Arc->next)
		NextCG_Arc->next->prev = NextCG_Arc->prev;
	    if (NextCG_Arc->callsite->first == NextCG_Arc)
		NextCG_Arc->callsite->first = NextCG_Arc->next;
	    if (NextCG_Arc->callsite->last == NextCG_Arc)
		NextCG_Arc->callsite->last = NextCG_Arc->prev;
	    RemoveCG_Arc(NextCG_Arc);

	    if (print_inline_stats) {
		fprintf(Flog, "Exceeding code expanding ratio\n");
		fprintf(Flog, 
		    "---------------------------------------------------\n");
	    }
	    continue;
	}

	if (fabs(key - newkey) > KEY_DIFFERENCE) {
	    if (print_inline_stats)
		fprintf(Flog, "Adjusted key from %f to %f\n", key, newkey);
	    Heap_Insert(arc_heap, NextCG_Arc, newkey);
	    if (newkey > key) {
		if (print_inline_stats)
		    fprintf(Flog, "Warning : newkey is larger\n");
		exit(1);
	    }
	    if (print_inline_stats)
		fprintf(Flog, 
		    "---------------------------------------------------\n");
	    continue;
	}
	if ( NextCG_Node->myself > 1.0 && !RECURSIVE(NextCG_Arc) ) {
	    /* take out the call arc */
	    if (NextCG_Arc->prev)
		NextCG_Arc->prev->next = NextCG_Arc->next;
	    if (NextCG_Arc->next)
		NextCG_Arc->next->prev = NextCG_Arc->prev;
	    if (NextCG_Arc->callsite->first == NextCG_Arc)
		NextCG_Arc->callsite->first = NextCG_Arc->next;
	    if (NextCG_Arc->callsite->last == NextCG_Arc)
		NextCG_Arc->callsite->last = NextCG_Arc->prev;
	    RemoveCG_Arc(NextCG_Arc);

	    if (print_inline_stats) {
		fprintf(Flog, 
		    "Ignored the inlining of other functions after inlining ");
		fprintf(Flog, "self-recursion\n");
		fprintf(Flog, 
	            "---------------------------------------------------\n");
	    }
	    continue;
	}
	/* Begin inlining the next arc */
	/* The current func is the same as the previous one */
	if ( currentFuncDcl && 
	     !strcmp(ActiveCG_Node->funcname, NextCG_Node->funcname) ) {

	    ActiveCG_Arc = NextCG_Arc;
	    InlineCalleeFunction(currentFuncDcl);
	    if (size_only == 0)
		Scale_Func_Weight(currentFuncDcl, out_fraction);
	}
	else {
	    if (currentFuncDcl) {
		/* update the previous func to disk */
		ProcessFuncDcl(currentFuncDcl);
		assert(Fout);
		fclose(Fout);
		Fout = 0;

		/* housekeeping stuff */
		RemoveFuncDcl(currentFuncDcl);
	        currentFuncDcl = 0;
		scope = 0;
		Pinline_GarbageCollection();
#if 0
		ClearSymTbl(SymbolTable[TBT_FUNC]);
		ClearSymTbl(SymbolTable[TBT_TYPEDEF]);
		ResetSymbolTables();
#endif

                /* BCC - name the file after inlining as .pci - 5/4/96 */
		sprintf(new_name, "%s/f_%d.pci",il_output_dir_string, 
			ActiveCG_Node->id);
		if (ActiveCG_Node->newpath == NIL) 
		    ActiveCG_Node->newpath = C_findstr(new_name);
		sprintf(command, "mv %s %s", f_name, new_name);
		if (system(command)) {
		    fptr1 = fopen(f_name, "rt");
		    fptr2 = fopen(new_name, "wt");
		    StupidCopy(fptr1, fptr2);
		    fclose(fptr1);
		    fclose(fptr2);
		    sprintf(command, "rm %s", f_name);
		    system(command);
		}
	    }
	    sprintf(f_name, "%s/f_%d.pc.temp.e", il_output_dir_string, 
		    NextCG_Node->id);
	    Fout = fopen(f_name, "wt");
	    if (Fout == 0) Punt("Can't open output file");
	    /* Always use the newest version of the call site body */
	    call_site = NextCG_Node->newpath ? 
			NextCG_Node->newpath : NextCG_Node->path;
	    ActiveCG_Node = NextCG_Node;
	    ActiveCG_Arc = NextCG_Arc;
	    ProcessFile(call_site);
	}
	if (size_only == 0) {
	    out_fraction = 1.0;
	    ActiveCG_Node->weight = ActiveCG_Node->weight - 
				    ActiveCG_Node->discount;
	    if (ActiveCG_Node->weight < 0.0) 
		ActiveCG_Node->weight = 0.0;
	    ActiveCG_Node->discount = 0.0;
	    self_recursion = 0;
	    ptr = ActiveCG_Node->first;
	    while (ptr) {
		ptr->weight -= ptr->discount;
		ptr->discount = 0;
		if (RECURSIVE(ptr)) 
		    self_recursion = 1;
		ptr = ptr->next;
	    }
	    if (self_recursion == 1 && ActiveCG_Node->myself == 1.0) {
		FILE *F_buffer;
		char scale_path[512];

		sprintf(scale_path, "%s.scale", 
			files[ActiveCG_Node->id].file_name);
		if (ActiveCG_Node->scalepath == 0) {
		    if (print_inline_stats)
			fprintf(Flog, "Artificial self-recursion found in %s\n",
			       ActiveCG_Node->funcname);
		    ActiveCG_Node->first_op_weight = ActiveCG_Node->weight;
		    ActiveCG_Node->scalepath = C_findstr(scale_path);
		}
		F_buffer = Fout;
		Fout = fopen(scale_path, "wt");
		if (Fout == 0) Punt("Can't open output file");
		if (ActiveCG_Node->weight > 0.0)
		    out_fraction = 1.0 / ActiveCG_Node->weight;
		else 
		    out_fraction = 0.0;
		do_inline = 0;
		/*
		ProcessFile(ActiveCG_Node->newpath ? 
			    ActiveCG_Node->newpath : ActiveCG_Node->path);
		*/
		ProcessFuncDcl(currentFuncDcl);
		do_inline = 1;
		out_fraction = 1.0;
		fclose(Fout);
		Fout = F_buffer;

		ActiveCG_Node->stacksize2 = ActiveCG_Node->stacksize; 
		ActiveCG_Node->bodysize2 = ActiveCG_Node->bodysize; 
	    }
	}
	if (print_inline_stats)
	    fprintf(Flog, 
		    "---------------------------------------------------\n");
    }
    if (currentFuncDcl) {
	/* update the previous func to disk */
	ProcessFuncDcl(currentFuncDcl);
	assert(Fout);
	fclose(Fout);
	Fout = 0;

	/* housekeeping stuff */
	RemoveFuncDcl(currentFuncDcl);
	currentFuncDcl = 0;
	scope = 0;
	Pinline_GarbageCollection();
#if 0
	ClearSymTbl(SymbolTable[TBT_FUNC]);
	ClearSymTbl(SymbolTable[TBT_TYPEDEF]);
	ResetSymbolTables();
#endif

	/* BCC - name the file after inlining as .pci - 5/4/96 */
	sprintf(new_name,"%s/f_%d.pci",il_output_dir_string, ActiveCG_Node->id);
	if (ActiveCG_Node->newpath == NIL) 
	    ActiveCG_Node->newpath = C_findstr(new_name);
	sprintf(command, "mv %s %s", f_name, new_name);
	if (system(command)) {
	    fptr1 = fopen(f_name, "rt");
	    fptr2 = fopen(new_name, "wt");
	    StupidCopy(fptr1, fptr2);
	    fclose(fptr1);
	    fclose(fptr2);
	    sprintf(command, "rm %s", f_name);
	    system(command);
	}
    }
}

Postprocess()
{
    int i, file_count;
    int dummy;
    char f_name[1024];
    char f_name1[1024];
    char f_name2[1024];
    char command[8192];
    char *func_name;
    FILE *fptr1, *fptr2;
    LIST list;
    FILE *Ffilelist, *Ffile;

    do_inline = 0;

    if (data_file) {
	/* BCC - name the file after inlining as .pci - 5/4/96 */
	sprintf(f_name, "%s/data.pci", il_output_dir_string);
	sprintf(command, "cp %s %s", data_file, f_name);
	if (system(command)) {
	    fptr1 = fopen(data_file, "rt");
	    fptr2 = fopen(f_name, "wt");
	    StupidCopy(fptr1, fptr2);
	    fclose(fptr1);
	    fclose(fptr2);
	}
    }

    if (print_inline_stats)
	fprintf(Flog, "Updating profile information\n");
    for (i=0; i<fc && !regroup_only; i++) {
        func_name = files[i].func_name;
        C_find(mapping_table_ID, func_name, 0, &dummy,
               (Pointer *) &ActiveCG_Node);
	if (ActiveCG_Node->discount == 0.0 && 	/* not inlined by other */
	    ActiveCG_Node->newpath) { 		/* and has been in the il_dir */

	    sprintf(command, "rm -f %s/f_%d.*temp* %s/f_%d.*scale", 
		    split_file_path, ActiveCG_Node->id,
		    split_file_path, ActiveCG_Node->id);
	    system(command);
	    continue;
	}
	if (ActiveCG_Node->newpath == 0 && ActiveCG_Node->discount == 0.0) {
	    /* BCC - name the file after inlining as .pci - 5/4/96 */
	    sprintf(f_name, "%s/f_%d.pci", il_output_dir_string, 
		    ActiveCG_Node->id);
	    sprintf(command, "cp %s %s", ActiveCG_Node->path, f_name);
	    if (system(command)) {
		fptr1 = fopen(ActiveCG_Node->path, "rt");
		fptr2 = fopen(f_name, "wt");
		StupidCopy(fptr1, fptr2);
		fclose(fptr1);
		fclose(fptr2);
	    }
	}
	else {
	    func_name = ActiveCG_Node->newpath ? ActiveCG_Node->newpath :
						  ActiveCG_Node->path;
	    sprintf(f_name, "%s/f_%d.pc.temp.e", il_output_dir_string, 
		    ActiveCG_Node->id);
	    if (size_only == 0) {
		/* BCC - avoid dividing by zero - 10/23/96 */
		if (ActiveCG_Node->weight > 0.0)
		    out_fraction = 1.0 - 
			       ActiveCG_Node->discount / ActiveCG_Node->weight;
		else
		    out_fraction = 0.0;
		if (out_fraction < 0.0) {
		    Dump_CG_Node(ActiveCG_Node);
		    ActiveCG_Node->discount = ActiveCG_Node->weight = 0.0;
		    out_fraction = 0.0;
		}
	    }
	    else
		out_fraction = 1.0;
	    Fout = fopen(f_name, "wt");
	    if (Fout == 0) Punt("Can't open output file");
	    ProcessFile(func_name);
	    out_fraction = 1.0;
	    fclose(Fout);
	    Fout = 0;
	    if (ActiveCG_Node->newpath) {
		sprintf(command, "rm %s", ActiveCG_Node->newpath);
		system(command);
		sprintf(command, "mv %s %s", f_name, ActiveCG_Node->newpath);
		if (system(command)) {
		    fptr1 = fopen(f_name, "rt");
		    fptr2 = fopen(ActiveCG_Node->newpath, "wt");
		    StupidCopy(fptr1, fptr2);
		    fclose(fptr1);
		    fclose(fptr2);
		    sprintf(command, "rm %s", f_name);
		    system(command);
		}
	    }
	    else {
	        /* BCC - name the file after inlining as .pci - 5/4/96 */
		sprintf(f_name2, "%s/f_%d.pci", il_output_dir_string, 
			ActiveCG_Node->id);
	        /* BCC - name the file after inlining as .pci - 5/4/96 */
		sprintf(command, "mv %s %s/f_%d.pci", f_name, 
			il_output_dir_string, ActiveCG_Node->id);
		if (system(command)) {
		    fptr1 = fopen(f_name, "rt");
		    fptr2 = fopen(f_name2, "wt");
		    StupidCopy(fptr1, fptr2);
		    fclose(fptr1);
		    fclose(fptr2);
		    sprintf(command, "rm %s", f_name);
		    system(command);
		}
	    }
	}

	/* clean up temp files */
	sprintf(command, "rm -f %s/f_%d.*temp* %s/f_%d.*scale", 
		split_file_path, ActiveCG_Node->id,
		split_file_path, ActiveCG_Node->id);
	system(command);
    }

    if (!regroup && !regroup_only) {
	if (print_inline_stats)
	    fprintf(Flog, "Done\n\n");
	do_inline = 1;
	return;
    }

    if (lexOpen(sp_output_spec, 0) == 0)
        Punt("cannot open the inline_spec file");

    file_count = 0;

    for (; (list=GetNode())!=0; DisposeNode(list)) {
	/* BCC - merge files together - 9/16/96 */
	LIST opcode, ptr1, ptr2;
	char old_filename[1024], new_filename[1024], last_filename[1024];
	char split_inline_file_name[1024];
	char *funcname, *op;
	char buffer1[256], buffer2[256];
	char files[8192];

        if (NodeType(list)==T_EOF) {
            DisposeNode(list);
            break;
        }

        if (NodeType(list)!=T_LIST)
            Punt("illegal mapping file : Parenthesis needed");

        opcode = ChildOf(list);
        op = StringOf(opcode);

        if (! strcmp(op, "map")) {
            ptr1 = SiblingOf(SiblingOf(opcode));
            ptr2 = SiblingOf(SiblingOf(SiblingOf(SiblingOf(opcode))));
            funcname = StringOf(SiblingOf(ChildOf(ptr2)));
	    strcpy(old_filename, strrchr(StringOf(ChildOf(ptr1)), '/')+1);
	    strstr(old_filename, ".pc")[0] = 0;
	    strcpy(new_filename, strrchr(StringOf(ChildOf(ptr2)), '/')+1);
	    strstr(new_filename, ".pc")[0] = 0;
            if (file_count == 0) {
	        strcpy(last_filename, old_filename);
	    }
            if (!strcmp(last_filename, old_filename)) {
		if (file_count == 0) {
		    if (regroup_only) {
			sprintf(command, "sh -c \"rm -f %s/%s.pci; cat %s/%s.pcs > %s/%s.pci;\"", 
				il_output_dir_string, old_filename, 
				split_file_path, new_filename,
				il_output_dir_string, old_filename);
		    }
		    else {
			sprintf(command, "sh -c \"rm -f %s/%s.pci; cat %s/%s.pci > %s/%s.pci; rm -f %s/%s.pci\"", 
				il_output_dir_string, old_filename, 
				il_output_dir_string, new_filename,
				il_output_dir_string, old_filename,
				il_output_dir_string, new_filename);
		    }
		}
		else {
		    if (regroup_only) {
			sprintf(command, "sh -c \"cat %s/%s.pcs >> %s/%s.pci;\"", 
				split_file_path, new_filename,
				il_output_dir_string, old_filename);
		    }
		    else {
			sprintf(command, "sh -c \"cat %s/%s.pci >> %s/%s.pci; rm -f %s/%s.pci\"", 
				il_output_dir_string, new_filename,
				il_output_dir_string, old_filename,
				il_output_dir_string, new_filename);
		    }
		}
		if (print_inline_stats)
		    fprintf(Flog, "%s\n", command);
		system(command);
		file_count++;
            }
	    else {
	        strcpy(last_filename, old_filename);
		if (regroup_only) {
		    sprintf(command, "sh -c \"rm -f %s/%s.pci; cat %s/%s.pcs > %s/%s.pci;\"", 
			    il_output_dir_string, old_filename, 
			    split_file_path, new_filename,
			    il_output_dir_string, old_filename);
		}
		else {
		    sprintf(command, "sh -c \"rm -f %s/%s.pci; cat %s/%s.pci > %s/%s.pci; rm -f %s/%s.pci\"", 
			    il_output_dir_string, old_filename, 
			    il_output_dir_string, new_filename,
			    il_output_dir_string, old_filename,
			    il_output_dir_string, new_filename);
		}
		if (print_inline_stats)
		    fprintf(Flog, "%s\n", command);
		system(command);
		file_count = 1;
	    }
        }
    }

    lexClose(sp_output_spec);

    /* BCC - creating function-less files if the existed before splitting */
    Ffilelist = fopen("impact_filelist", "rt");
    if (Ffilelist && use_new_regroup_algorithm) {
	i = 0;
	while (1) {
	    if (fscanf(Ffilelist, "%s", f_name) == EOF) break;
	    sprintf(f_name1, "%s/%s", il_output_dir_string, f_name);
	    Ffile = fopen(f_name1, "rt");
	    /* file doesn't exist */
	    if (Ffile == 0) {
		Ffile = fopen(f_name1, "wt");
		fprintf(Ffile, "( INCLUDE \"extern.pch\")\n");
		fclose(Ffile);
	    }
	    else
		fclose(Ffile);
	    sprintf(f_name2, "%s/data_%d.pcs", split_file_path, i);
	    Ffile = fopen(f_name2, "rt");
	    if (Ffile) {
		fclose(Ffile);
		sprintf(command, "sh -c \"cat %s >> %s;\"", f_name2, f_name1);
		if (print_inline_stats)
		    fprintf(Flog, "%s\n", command);
		system(command);
	    }
	    /* file is the first one */
	    if (i == 0) {
		if (regroup_only) {
		    sprintf(f_name2, "%s/data.pcs", split_file_path);
		    Ffile = fopen(f_name2, "rt");

		    /* and data.pci exists */
		    if (Ffile) {
			fclose(Ffile);
			sprintf(command, "sh -c \"cat %s >> %s/%s;\"",
				f_name2, il_output_dir_string, f_name);
			if (print_inline_stats)
			    fprintf(Flog, "%s\n", command);
			system(command);
		    }
		}
		else {
		    sprintf(f_name2, "%s/data.pci", il_output_dir_string);
		    Ffile = fopen(f_name2, "rt");

		    /* and data.pci exists */
		    if (Ffile) {
			fclose(Ffile);
			sprintf(command, "sh -c \"cat %s >> %s/%s; rm -f %s\"",
				f_name2, il_output_dir_string, f_name, f_name2);
			if (print_inline_stats)
			    fprintf(Flog, "%s\n", command);
			system(command);
		    }
		}
	    }
	    i++;
	}
	fclose(Ffilelist);
    }

    if (print_inline_stats)
	fprintf(Flog, "Done\n\n");
    do_inline = 1;
}

SetupInlineHandler()
{
    void extern InlineCalleeFunction(FuncDcl);
    void extern PreprocessFunc(FuncDcl, int);

    ExpandCalleeFunction = InlineCalleeFunction;
    PreprocessFunction = PreprocessFunc;
}


main(argc, argv, envp)
int argc;
char **argv;
char **envp;
{
    char *str;
    int val;

    /*
     *  Read parms
     */
    ReadParms(argc, argv, envp);
    if (strcmp(il_log_name, "stdout"))
	Flog = fopen(il_log_name, "wt");
    else
	Flog = stdout;
    if (print_inline_stats) {
	fprintf(Flog, "--------------     DUMP PARMS     --------------\n");
	fprintf(Flog, "print_inline_stats       = %s\n", 
		print_inline_stats ? "yes" : "no");
	fprintf(Flog, "il_log_name              = %s\n", il_log_name);
	fprintf(Flog, "max_sf_size_limit        = %ld\n", max_sf_size_limit);
	fprintf(Flog, "max_expansion_ratio      = %f\n", max_expansion_ratio);
	fprintf(Flog, "max_function_size        = %ld\n", max_function_size);
	fprintf(Flog, "min_expansion_weight     = %f\n", min_expansion_weight);
	fprintf(Flog, "min_expansion_key        = %f\n", min_expansion_key);
	fprintf(Flog, "sp_output_spec           = %s\n", sp_output_spec);
	fprintf(Flog, "il_dir                   = %s\n", il_output_dir_string);
	fprintf(Flog, "inline_function_pointers = %s\n", 
		inline_function_pointers ? "yes" : "no");
	fprintf(Flog, "regroup                  = %s\n", 
		regroup ? "yes" : "no");
	fprintf(Flog, "regroup_only             = %s\n", 
		regroup_only ? "yes" : "no");
	fprintf(Flog, "size_only                = %s\n", 
		size_only ? "yes" : "no");
	fprintf(Flog, "favor_small_functions    = %s\n", 
		favor_small_functions ? "yes" : "no");
	fprintf(Flog, "use_touched_body_size    = %s\n", 
		use_touched_body_size ? "yes" : "no");
	fprintf(Flog, "--------------         END        --------------\n");
    }

    /*
     *  Setup entry point from Pcode to Pinline
     */
    SetupInlineHandler();

    /*  
     *  Read function map file - In general, sp_output_spec is "impact_mapping1"
     */
    ReadFunctionMap(sp_output_spec);

#if 0
    /*  
     *  Read call-through-pointer information
     */
    ReadCallGraph("impact.pc.ip");
#endif

    /*  
     *  Assign each function call with a distinct arc id
     */
    find_indirect_weight = 1;
    fast_mode = 1;
    if (regroup_only == 0)
	Preprocess();
    find_indirect_weight = 0;
    if (!use_touched_body_size)
	MaxBodySize = max_expansion_ratio * TotalBodySize;
    else
	MaxBodySize = (max_expansion_ratio-1) * TouchedBodySize + TotalBodySize;
    if (print_inline_stats) {
	fprintf(Flog, "--------------        SIZES       --------------\n");
	fprintf(Flog, "TotalBodySize    = %f\n", TotalBodySize);
	fprintf(Flog, "TouchedBodySize  = %f\n", TouchedBodySize);
	fprintf(Flog, "MaxBodySize      = %f\n", MaxBodySize);
	fprintf(Flog, "--------------         END        --------------\n");
    }

/* BCC - files are put under the same directory - 5/4/96 */
#if 0
    /*
     *  Open output files
     */
    MakeImpactDirectory();
#endif

    /*
     *  Begin Inline
     */
    InlineFunction();

    /*
     *  Print :
     *	1) unlined functions
     *	2) inlining other functions then inlined by other functions
     */
    Postprocess();

    if (strcmp(il_log_name, "stdout"))
	fclose(Flog);
    FreeDeadList();

    /* 
     *  Let the makefile quiet 
     */
    return 0;
}
