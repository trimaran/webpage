/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/

/*****************************************************************************\
 *	File:	flow.c
 *	Author:	Grant Haab and Wen-mei Hwu
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <library/llist.h>
#include <Pcode/flow.h>
#include <Pcode/pcode.h>
#include <Pcode/struct.h>

/* This array must be parallel to the _NodeType enumeration defined in flow.h */
char *NodeTypeNames[NUM_NODE_TYPES] = {
        "FuncEntry",
        "FuncExit",
        "ParloopInitCond",
        "ParloopIterCond",
        "ParloopExit",
        "ParloopBody",
        "ParloopMainEpilogue",
        "ParloopAuxEpilogue",
        "PStmtCompEntry",
        "PStmtCompExit",
	"SerloopEntry",
        "SerloopInitCond",
	"SerloopCond",
        "SerloopIterCond",
        "SerloopExit",
        "CobeginEntry",
        "CobeginExit",
        "MutexEntry",
        "MutexExit",
        "Advance",
        "Await",
        "PStmtEntry",
        "PStmtExit",
        "SwitchCond",
        "SwitchExit",
        "IfCond",
        "IfExit",
        "CompoundEntry",
        "CompoundExit",
        "Break",
        "Continue",
        "Goto",
        "Return",
        "Expr",
        "Null"
};
	
/* BCC - moved from scattered places in CF and DF to here - 3/23/97 */
BBGraph bb_graph;
FlowGraph flow_graph;

BBGraph NewBBGraph(func)
FuncDcl func;
{
    BBGraph new;

    assert(func != NIL);
    new = ALLOCATE(_BBGraph);
    new->first_node = NIL;
    new->last_node = NIL;
    new->num_nodes = 0;
    new->bb_node = NIL;
    new->num_lbbs = 0;
    new->loop_bbs = NIL;
    new->entry_node = NIL;
    new->exit_node = NIL;
    new->func = func;
    new->loop_summ = NIL;
    new->num_loops = 0;
    new->has_doms = FALSE;
    new->has_post_doms = FALSE;
    new->has_rbbs = FALSE;
    new->has_loops = FALSE;
    new->has_lvs = FALSE;
    new->has_ads = FALSE;
    new->has_aus = FALSE;
    new->has_rds = FALSE;
    new->has_rus = FALSE;
    new->has_lcrds = FALSE;
    new->has_lcrus = FALSE;
    return new;
}

static void RemoveBBNode(bbn)
BBNode bbn;
{
    int l;

    assert(bbn != NIL);
    bbn->pred = FreeLptr(bbn->pred);
    bbn->succ = FreeLptr(bbn->succ);
    bbn->flows = FreeLptr(bbn->flows);
    bbn->index = 0;
    bbn->next = NIL;
    bbn->flags = 0;
    RemoveProfBB(bbn->profile);  /* LCW - remove BB profile - 5/16/96 */
    bbn->profile = NIL;
    bbn->dominators = Set_dispose(bbn->dominators);
    bbn->post_dominators = Set_dispose(bbn->post_dominators);
    if (bbn->rbbs4loop != NIL) {
	for (l = 0; l <= bbn->loop_depth; l++) Set_dispose(bbn->rbbs4loop[l]); 
	free(bbn->rbbs4loop);
    } 
    bbn->rbbs4loop = NIL;
    bbn->d_gen = Set_dispose(bbn->d_gen);
    bbn->d_kill = Set_dispose(bbn->d_kill);
    bbn->u_gen = Set_dispose(bbn->u_gen);
    bbn->u_kill = Set_dispose(bbn->u_kill);
    bbn->lv_in = Set_dispose(bbn->lv_in);
    bbn->lv_out = Set_dispose(bbn->lv_out);
    bbn->ad_in = Set_dispose(bbn->ad_in);
    bbn->ad_out = Set_dispose(bbn->ad_out);
    bbn->au_in = Set_dispose(bbn->au_in);
    bbn->au_out = Set_dispose(bbn->au_out);
    bbn->rd_in = Set_dispose(bbn->rd_in);
    bbn->rd_out = Set_dispose(bbn->rd_out);
    bbn->ru_in = Set_dispose(bbn->ru_in);
    bbn->ru_out = Set_dispose(bbn->ru_out);
    bbn->lcrd_in = Set_dispose(bbn->lcrd_in);
    bbn->lcrd_out = Set_dispose(bbn->lcrd_out);
    bbn->lcru_in = Set_dispose(bbn->lcru_in);
    bbn->lcru_out = Set_dispose(bbn->lcru_out);
    bbn->loop_depth = 0;
    DISPOSE(bbn);
}

void RemoveBBGraph(bbg)
BBGraph bbg;
{
    BBNode cur_node, next_node;

    assert(bbg != NIL);
    if (bbg->num_nodes != 0) {
	assert(bbg->first_node != NIL);
	if (bbg->num_nodes == 1) { 
	    assert(bbg->last_node == bbg->first_node);
	    RemoveBBNode(bbg->first_node);
	}
	else {
	    assert(bbg->last_node != NIL && bbg->first_node != bbg->last_node);
	    for (cur_node = bbg->first_node, next_node = bbg->first_node->next;
		 next_node != NIL;
		 cur_node = next_node, next_node = next_node->next) {

		RemoveBBNode(cur_node);
	    }
	    RemoveBBNode(cur_node);
	}
    }
    bbg->first_node = NIL;
    bbg->last_node = NIL;
    bbg->num_nodes = 0;
    if (bbg->bb_node != NIL) {
	free(bbg->bb_node);
	bbg->bb_node = NIL;
    }
    bbg->num_lbbs = 0;
    if (bbg->loop_bbs != NIL) {
        free(bbg->loop_bbs);
        bbg->loop_bbs = NIL;
    }
    bbg->entry_node = NIL;
    bbg->exit_node = NIL;
    bbg->func = NIL;
    if (bbg->has_loops) {
	free(bbg->loop_summ);
	bbg->loop_summ = NIL;
    }
    bbg->num_loops = 0;
    bbg->has_doms = FALSE;
    bbg->has_post_doms = FALSE;
    bbg->has_rbbs = FALSE;
    bbg->has_loops = FALSE;
    bbg->has_lvs = FALSE;
    bbg->has_ads = FALSE;
    bbg->has_aus = FALSE;
    bbg->has_rds = FALSE;
    bbg->has_rus = FALSE;
    bbg->has_lcrds = FALSE;
    bbg->has_lcrus = FALSE;
    DISPOSE(bbg);
}

BBNode NewBBNode(bbg)
BBGraph bbg;
{
    BBNode new;

    assert(bbg != NIL);
    new = ALLOCATE(_BBNode);
    new->pred = NIL;
    new->succ = NIL;
    new->flows = NIL;
    new->index = 0;
    new->next = NIL;
    new->flags = 0;
    new->profile = NIL;  /* LCW - add a new field for profile - 12/23/95 */
    new->dominators = NIL;
    new->post_dominators = NIL;
    new->loop_depth = 0;
    new->rbbs4loop = NIL;
    new->d_gen = NIL;
    new->d_kill = NIL;
    new->u_gen = NIL;
    new->u_kill = NIL;
    new->lv_in = NIL;
    new->lv_out = NIL;
    new->ad_in = NIL;
    new->ad_out = NIL;
    new->au_in = NIL;
    new->au_out = NIL;
    new->rd_in = NIL;
    new->rd_out = NIL;
    new->ru_in = NIL;
    new->ru_out = NIL;
    new->lcrd_in = NIL;
    new->lcrd_out = NIL;
    new->lcru_in = NIL;
    new->lcru_out = NIL;
    if (bbg->num_nodes == 0) {
	assert(bbg->first_node == NIL && bbg->last_node == NIL);
	bbg->first_node = new;
	bbg->last_node = new;
    }
    else {
	assert(bbg->last_node->next == NIL);
	bbg->last_node->next = new;
	bbg->last_node = new;
    }
    bbg->num_nodes++;
    return new;
}

int IsPredBBNode(pred, node)
BBNode pred, node;
{
    Lptr l;
    assert(pred != NIL && node != NIL);

    for (l = node->pred; l != NIL; l=l->next) {
	if ((BBNode)l->ptr == pred) {
	    return TRUE;
	}
    }
    return FALSE;
}

int IsSuccBBNode(succ, node)
BBNode succ, node;
{
    Lptr l;
    assert(succ != NIL && node != NIL);

    for (l = node->succ; l != NIL; l=l->next) {
	if ((BBNode)l->ptr == succ) {
	    return TRUE;
	}
    }
    return FALSE;
}

void ResetBBGraphFlags(bbg, flags)
BBGraph bbg;
int flags;
{
    BBNode bbn;
    assert(bbg != NIL && flags != 0);

    for (bbn = bbg->first_node; bbn != NIL; bbn = bbn->next) {
	RESET_BB_NODE_FLAGS(bbn, flags);
    }
}

void ConnectBBNodes(pred, succ)
BBNode pred, succ;
{
    Lptr new_pred, new_succ;

    assert(pred != NIL && succ != NIL);
    if (IsPredBBNode(pred, succ)) {		/* already connected */
	assert(IsSuccBBNode(succ, pred));	/* consistency check */
	return;
    }
    new_pred = NewLptr((Void *) pred);
    new_succ = NewLptr((Void *) succ);
    pred->succ = AppendLptr(new_succ, pred->succ);
    succ->pred = AppendLptr(new_pred, succ->pred);
}

FlowGraph NewFlowGraph(func)
FuncDcl func;
{
    FlowGraph new;

    assert(func != NIL);
    new = ALLOCATE(_FlowGraph);
    new->first_node = NIL;
    new->last_node = NIL;
    new->num_nodes = 0;
    new->func = func;
    new->bb_graph = NIL;
    new->num_acc = 0;
    new->access = NIL;
    new->num_var = 0;
    new->var = NIL;
    new->has_bbs = FALSE;
    new->has_defuse = FALSE;
    new->has_lvs = FALSE;
    new->has_ads = FALSE;
    new->has_aus = FALSE;
    new->has_rds = FALSE;
    new->has_rus = FALSE;
    new->has_lcrds = FALSE;
    new->has_lcrus = FALSE;
    return new;
}

static void RemoveFlowNode(fn)
FlowNode fn;
{
    assert(fn != NIL);
    fn->pred = FreeLptr(fn->pred);
    fn->succ = FreeLptr(fn->succ);
    fn->pcode_ptr.stmt = NIL;
    fn->bb = NIL;
    fn->order = 0;
    fn->must_def = Set_dispose(fn->must_def);
    fn->may_def = Set_dispose(fn->may_def);
    fn->may_use = Set_dispose(fn->may_use);
    fn->must_def_var = Set_dispose(fn->must_def_var);
    fn->may_def_var = Set_dispose(fn->may_def_var);
    fn->may_use_var = Set_dispose(fn->may_use_var);
    fn->d_gen = Set_dispose(fn->d_gen);
    fn->d_kill = Set_dispose(fn->d_kill);
    fn->u_gen = Set_dispose(fn->u_gen);
    fn->u_kill = Set_dispose(fn->u_kill);
    fn->l_in = Set_dispose(fn->l_in);
    fn->l_out = Set_dispose(fn->l_out);
    fn->a_defs = Set_dispose(fn->a_defs);
    fn->a_uses = Set_dispose(fn->a_uses);
    fn->r_defs = Set_dispose(fn->r_defs);
    fn->r_uses = Set_dispose(fn->r_uses);
    fn->lcr_defs = Set_dispose(fn->lcr_defs);
    fn->lcr_uses = Set_dispose(fn->lcr_uses);
    fn->type = 0;
    fn->next = NIL;
    DISPOSE(fn);
}

void RemoveFlowGraph(fg)
FlowGraph fg;
{
    FlowNode cur_node, next_node;

    assert(fg != NIL);
    if (fg->num_nodes != 0) {
	assert(fg->first_node != NIL);
	if (fg->num_nodes == 1) { 
	    assert(fg->last_node == fg->first_node);
	    RemoveFlowNode(fg->first_node);
	}
	else {
	    assert(fg->last_node != NIL && fg->first_node != fg->last_node);
	    for (cur_node = fg->first_node, next_node = fg->first_node->next;
		 next_node != NIL;
		 cur_node = next_node, next_node = next_node->next) {

		RemoveFlowNode(cur_node);
	    }
	    RemoveFlowNode(cur_node);
	}
    }
    fg->first_node = NIL;
    fg->last_node = NIL;
    fg->num_nodes = 0;
    if (fg->has_bbs) RemoveBBGraph(fg->bb_graph);
    fg->bb_graph = NIL;
    fg->has_bbs = FALSE;
    if (fg->num_acc != 0) free(fg->access);
    fg->num_acc = 0;
    if (fg->num_var != 0) free(fg->var);
    fg->num_var = 0;
    fg->access = NIL;
    fg->has_defuse = FALSE;
    fg->has_lvs = FALSE;
    fg->has_ads = FALSE;
    fg->has_aus = FALSE;
    fg->has_rds = FALSE;
    fg->has_rus = FALSE;
    fg->has_lcrds = FALSE;
    fg->has_lcrus = FALSE;
    fg->func = NIL;
    DISPOSE(fg);
}

FlowNode NewFlowNode(node_type, fg)
_NodeType node_type;
FlowGraph fg;
{
    FlowNode new;

    assert(fg != NIL);
    new = ALLOCATE(_FlowNode);
    new->pred = NIL;
    new->succ = NIL;
    new->pcode_ptr.stmt = NIL;
    new->bb = NIL;
    new->order = -1;
    new->must_def = NIL;
    new->may_def = NIL;
    new->may_use = NIL;
    new->must_def_var = NIL;
    new->may_def_var = NIL;
    new->may_use_var = NIL;
    new->d_gen = NIL;
    new->d_kill = NIL;
    new->u_gen = NIL;
    new->u_kill = NIL;
    new->l_in = NIL;
    new->l_out = NIL;
    new->a_defs = NIL;
    new->a_uses = NIL;
    new->r_defs = NIL;
    new->r_uses = NIL;
    new->lcr_defs = NIL;
    new->lcr_uses = NIL;
    new->type = node_type;
    new->next = NIL;
    if (fg->num_nodes == 0) {
	assert(fg->first_node == NIL && fg->last_node == NIL);
	fg->first_node = new;
	fg->last_node = new;
    }
    else {
	assert(fg->last_node->next == NIL);
	fg->last_node->next = new;
	fg->last_node = new;
    }
    fg->num_nodes++;
    return new;
}

int IsPredFlowNode(pred, node)
FlowNode pred, node;
{
    Lptr l;
    assert(pred != NIL && node != NIL);

    for (l = node->pred; l != NIL; l=l->next) {
	if ((FlowNode)l->ptr == pred) {
	    return TRUE;
	}
    }
    return FALSE;
}

int IsSuccFlowNode(succ, node)
FlowNode succ, node;
{
    Lptr l;
    assert(succ != NIL && node != NIL);

    for (l = node->succ; l != NIL; l=l->next) {
	if ((FlowNode)l->ptr == succ) {
	    return TRUE;
	}
    }
    return FALSE;
}

FlowNode FindFlowNodeInList(type, list)
_NodeType type; 
Lptr list;
{
    Lptr l;
    FlowNode fn;

    for (l = list; l != NIL; l=l->next) {
	fn = (FlowNode)l->ptr;
	if (fn->type == type) return fn;
    }
    return NIL;
}

uint FindFlowNodeDepth(fn)
FlowNode fn;
{
    Stmt stmt;
    uint depth;

    switch(fn->type) {
        case NT_ParloopIterCond:
            return(fn->pcode_ptr.stmt->stmtstruct.parloop->depth);
        case NT_FuncEntry:
        case NT_FuncExit:
            return(0);
        default:
            stmt = fn->pcode_ptr.stmt;
            while (stmt != NIL && stmt->type != ST_BODY) {
                stmt = stmt->parent;
            }
            if (stmt != NIL) {
                assert(stmt->parent->parent->type == ST_PARLOOP);
                return(stmt->parent->parent->stmtstruct.parloop->depth);
            }
            /* flow node not within Parloop*/
            else return(0);
    }
}

void ConnectFlowNodes(pred, succ)
FlowNode pred, succ;
{
    Lptr new_pred, new_succ;

    assert(pred != NIL && succ != NIL);
    if (IsPredFlowNode(pred, succ)) {		/* already connected */
	assert(IsSuccFlowNode(succ, pred));	/* consistency check */
	return;
    }
    new_pred = NewLptr((Void *) pred);
    new_succ = NewLptr((Void *) succ);
    pred->succ = AppendLptr(new_succ, pred->succ);
    succ->pred = AppendLptr(new_pred, succ->pred);
}

void RemoveFuncFlow(ff)
FuncFlow ff;
{
    if (ff != NIL) {
	ff->entry_flow_node = NIL;
	ff->exit_flow_node = NIL;
	if (ff->flow_graph != NIL) RemoveFlowGraph(ff->flow_graph);
	ff->flow_graph = NIL;
	DISPOSE(ff);
    }
}

FuncFlow NewFuncFlow(old)
FuncFlow old;
{
    FuncFlow new;

    if (old != NIL) RemoveFuncFlow(old);
    new = ALLOCATE(_FuncFlow);
    new->entry_flow_node = NIL;
    new->exit_flow_node = NIL;
    new->flow_graph = NIL;
    return new;
}

void RemoveStmtFlow(sf)
StmtFlow sf;
{
    if (sf != NIL) {
	sf->flow_node_list = FreeLptr(sf->flow_node_list);
	sf->entry_flow_node = NIL;
	DISPOSE(sf);
    }
}

StmtFlow NewStmtFlow(old)
StmtFlow old;
{
    StmtFlow new;

    if (old != NIL) RemoveStmtFlow(old);
    new = ALLOCATE(_StmtFlow);
    new->flow_node_list = NIL;
    new->entry_flow_node = NIL;
    return new;
}

