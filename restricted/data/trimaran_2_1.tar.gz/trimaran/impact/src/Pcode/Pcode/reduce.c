/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	reduce.c
 *	Authors: David August, Po-hua Chang, Grant Haab, Krishna Subramanian,
 *               Nancy Warter and Wen-mei Hwu
 \*****************************************************************************/


#include <Pcode/impact_global.h>
#include <Pcode/struct.h>
#include <Pcode/cast.h>
#include <Pcode/reduce.h>
#include <Pcode/parms.h>
/* BCC - need the definition of struct _M_Type */
#include <machine/m_spec.h>

#undef DEBUG_REDUCE

/* BCC - used for reducing cast - 6/8/95 */
/* Initialize to bad values to detect uninitialized use -ITI (JCG) 2/99 */
int P_CHAR_SIZE = -10000;
int P_SHORT_SIZE = -10000;
int P_INT_SIZE = -10000;
int P_LONG_SIZE = -10000;

unsigned long P_UNSIGNED_CHAR_MASK = 0;
unsigned long P_UNSIGNED_SHORT_MASK = 0;
unsigned long P_UNSIGNED_INT_MASK = 0;

int init_mspec = 0;  /* Initialize to 0, so can use properly -ITI (JCT) 2/99 */

static Punt(mesg)
     char *mesg;
{
  fprintf(Ferr, "ReduceExpr: %s\n", mesg);
  exit(-1);
}
/*---------------------------------------------------------------------------*/
/* NJW from flatten.c */
/*
 *      copy only one node (do not care about operands)
 */
Expr CopyNode(expr)
     Expr expr;
{
  Expr sibling, operand, new;
  if (expr==0) return 0;
  sibling = expr->sibling;  /* GEH - this is really unnecessary */
  operand = expr->operands;
  expr->sibling = 0;
  expr->operands = 0;
  new = CopyExpr(expr);
  expr->sibling = sibling;  /* GEH - this is really unnecessary */
  expr->operands = operand;
  return new;
}

Expr CopyNodeWithAcc(expr)
     Expr expr;
{
  Expr sibling, operand, new;
  if (expr==0) return 0;
  sibling = expr->sibling;  /* GEH - this is really unnecessary */
  operand = expr->operands;
  expr->sibling = 0;
  expr->operands = 0;
  new = CopyExprWithAcc(expr);
  expr->sibling = sibling;  /* GEH - this is really unnecessary */
  expr->operands = operand;
  return new;
}

/*---------------------------------------------------------------------------*/
/*
 *	Bring the type up-to-date.
 *	Assume type is always more powerful than expr->type.
 */
static Expr Cast(expr, type)
     Expr expr;
     Type type;
{
  Type type1 = expr->type;
  /* DIA - 5/6/94: Handle pointer arithmetic */
  if (!type1->dcltr) 
    if (! EqualStrength(type, type1))
      expr = UpgradeType(expr, type, NIL);
  return expr;
}

/*
 *	Compare against zero.
 *	If zero, returns 0.
 *	If not-zero, the resultant expression should return 1.
 */
static Expr NotZero(expr)
     Expr expr;
{
  Expr new;
  if (expr==0) Punt("NotZero: expr is nil");
  if (IsBooleanExpr(expr)) {
    return expr;
  } else {
    new = NewInstExpr(OP_ne, IntType());
    AddOperand(new, expr);
    AddOperand(new, NewIntExpr(0));
    return new;
  }
}

/* BCC - added a function to get the size of each integer type - 6/12/95 */
P_GetIntegerSize()
{
    _M_Type mtype;
    int i;

    init_mspec = 1;
    M_char(&mtype, 0);
    P_CHAR_SIZE = mtype.size;
    M_short(&mtype, 0);
    P_SHORT_SIZE = mtype.size;
    M_int(&mtype, 0);
    P_INT_SIZE = mtype.size;
    M_long(&mtype, 0);
    P_LONG_SIZE = mtype.size;

    for (i=1, P_UNSIGNED_CHAR_MASK=1; i < P_CHAR_SIZE; i++)
        P_UNSIGNED_CHAR_MASK = (P_UNSIGNED_CHAR_MASK << 1) + 1;
    for (i=1, P_UNSIGNED_SHORT_MASK=1; i < P_SHORT_SIZE; i++)
        P_UNSIGNED_SHORT_MASK = (P_UNSIGNED_SHORT_MASK << 1) + 1;
    for (i=1, P_UNSIGNED_INT_MASK=1; i < P_INT_SIZE; i++)
        P_UNSIGNED_INT_MASK = (P_UNSIGNED_INT_MASK << 1) + 1;
}

/*
 *	Apply constant folding.
 *	Apply algebraic operations to reduce the expression.
 *	OP_type_size and OP_expr_size nodes can only be reduced
 *	during RTL generation phase. Otherwise, ignore optimizing
 *	OP_type_size and OP_expr_size nodes (assume not reducible)
 *	+++ better garbage collection of nodes is necessary in the future.
 *      GEH - ^^^^^^^^^^^^ no kidding!  Hopefully, it's all taken care of now.
 */
Expr ReduceExpr(expr)
     Expr expr;
{
  Expr new, temp_expr;
  int i, j;
  int IsFloatExprOp1, IsFloatExprOp2;
  Expr op1, op2, op3, op_temp, op11, op12, op21, op22;
  Type type;
  double d1, d2;
  long l1, l2;
  short scalar;
#ifdef DEBUG_REDUCE
  char expr_string[1024];
  int pos = 0;
  Expr2String(expr_string, &pos, expr, TRUE);
  if (pos > 1024) 
      Punt("Error: increase length of expr_string in ReduceExpr()\n");
  fprintf(Flog, "....Reducing Expression:%s\n", expr_string);
#endif

  /*
   *	Basic cases: leaf-level nodes. 
   */
  if (expr==0) 
    return 0;

  /* BCC - 10/30/96 */
  if (fast_mode == 1) return CopyExpr(expr);
  switch (expr->opcode) {
  case OP_var:

/* BCC - return integer value for enum_field - 11/3/95 */
    if (expr->enum_flag == 0) return CopyExpr(expr);
    else {
      EnumField enf;
      enf = enum_expr_to_enum_field(expr);
      assert(enf != NIL && enf->value != NIL);
      assert (enf->value->opcode == OP_int);
      return CopyExpr(enf->value);
    }
/* BCC - end of modification - 11/3/95 */

  case OP_char:
  case OP_string:
  case OP_real:
  /* BCC - added - 8/3/96 */
  case OP_float:
  /* BCC - added - 8/3/96 */
  case OP_double:
  case OP_int:
  case OP_type_size:
  case OP_expr_size:
    return CopyExpr(expr);
  default:
    break;
  }
  /* 
   *	Compress all operands first.
   */
  /* DIA - 4/31/94: Added traversal of next fields which were getting stripped */
  new = CopyNode(expr);	/* copy the root node only */
  for (i=1; (op1=GetOperand(expr, i))!=0; i++) {
    AddOperand(new, ReduceExpr(op1));
    for(j=1; (op2=GetNextOperand(op1, j))!=0; j++)
       AddNextOperand(GetOperand(new, i), ReduceExpr(op2));
  }
#ifdef DEBUG_REDUCE
  pos = 0;
  Expr2String(expr_string, &pos, new, TRUE);
  if (pos > 1024) 
      Punt("Error: increase length of expr_string in ReduceExpr()\n");
  fprintf(Flog, "....Reduced Expression:%s\n", expr_string);
#endif
  /* 
   *	Obtain the first three operands.
   *	Not all operations use these many, 
   *	but it is easier this way. 
   */
  /* also handle comma expressions - don't have to worry about OP_compexpr
   * or OP_index - but included them anyhow.  (NJW)
   * DIA - Sorry NJW, but we do have to worry about OP_compexpr!
   */
  if(new->opcode == OP_compexpr) {
    op_temp = ExprOperand(1, new);
    op1 = GetLastOperand(op_temp);
  } else
    op1 = ExprOperand(1, new);
  if((new->opcode == OP_index) || (new->opcode == OP_quest)) {
    op_temp = ExprOperand(2, new);
    op2 = GetLastOperand(op_temp);
  } else
    op2 = ExprOperand(2, new);
  op3 = ExprOperand(3, new);
  /* 
   *	Apply constant folding on the current node.
   */
  switch (new->opcode) {

 case OP_compexpr:
   /* 
   ** DIA - 5/9/94: Want to convert (5) => 5
   ** ( num )    =>     num
   */

    /* 
     * BCC - 	bug fix - 1/29/96 
     *		Consider (foo(), 1);
     *		In this case we can't just return 1. So we have to check if 
     *		OP_compexpr contains a list of exprs or just one simple expr
     */
    if (op_temp != op1) return new;
    /* BCC - end of change - 1/29/96 */

    if (IsConstNumber(op1))
     {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1))
       {
	d1 = op1->value.real;
	/* BCC - 8/4/96 
	return NewRealExpr(d1);
	*/
	if (IsFloatExpr(op1)) {
	  RemoveExpr(new);
	  /* BCC - memory bug fix. Forgot to return - 11/10/96 */
	  return NewFloatExpr(d1);
	}
	else {
	  RemoveExpr(new);
	  /* BCC - memory bug fix. Forgot to return - 11/10/96 */
	  return NewDoubleExpr(d1);
	}
       }
      else
       if (IsIntegralExpr(op1))
	{
	 l1 = IntegralExprValue(op1);
	 if (op1->type->type & TY_UNSIGNED)
	  {
	   RemoveExpr(new);
	   new = NewIntExpr((unsigned) l1);
	   new->type->type |= TY_UNSIGNED;
	   return new;
	  }
	 else
	  {
	   RemoveExpr(new);
	   return NewIntExpr(l1);
	  }
	}
       else Punt("OP_compexpr 1");
     }
    return new;
  /* DIA - End of additional code */


  case OP_quest :
    /*	1) true ? A : B 	=> A
     *	2) false ? A : B	=> B
     */
    if (IsConstZero(op1)){
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op3, type);
      RemoveExpr(new);
      op_temp->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }
    if (IsConstNonZero(op1)){ 
      type = new->type;
      new->operands = NIL;
      Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      op_temp->sibling = NIL;
      RemoveExpr(op3);
      return op_temp; 
    }
    return new;

  case OP_disj :
    /*	1) true || B		=> true
     *	2) false || B		=> (B!=0)
     *	3) A || true		=> true  (if A is side-effect free)
     *	4) A || false		=> (A!=0)
     */
    if (IsConstNonZero(op1)){
      RemoveExpr(new); 
      return NewIntExpr(1);	/* true */
    }
    if (IsConstZero(op1)){
      new->operands = NIL;
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return NotZero(op2);	/* B!=0 */
    }
    if (IsConstNonZero(op2)) {
      if (IsSideEffectFree(op1)){
        /* no need to execute A */
	RemoveExpr(new);
	return NewIntExpr(1);	/* true */
      }
      return new;			/* (A || true) */
    } 
    if (IsConstZero(op2)){
      new->operands = NIL;
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op2);
      return NotZero(op1);
    }
    return new;

  case OP_conj :
    /*	1) false && B		=> false
     *	2) true && B		=> (B!=0)
     *	3) A && true		=> (A!=0)
     *	4) A && false		=> false  (if A is side-effect free)
     */
    if (IsConstZero(op1)){
      RemoveExpr(new);
      return NewIntExpr(0);	/* false */
    }
    if (IsConstNonZero(op1)){
      new->operands = NIL;
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return NotZero(op2);	/* B!=0 */
    }
    if (IsConstNonZero(op2)){
      new->operands = NIL;
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op2);
      return NotZero(op1);	/* A!=0 */
    }
    if (IsConstZero(op2)) {
      if (IsSideEffectFree(op1)){
	/* no need to execute A */
	RemoveExpr(new);
	return NewIntExpr(0);	/* false */
      }
      return new;		/* A && false */
    }
    return new;

  case OP_or :
    /*	1) 0 or B		=> B
     *	2) A or 0		=> A
     *	3) N1 or N2		=> <N1 or N2>   (N1, N2 integer constants)
     */
    if (IsConstZero(op1)){
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }
    if (IsConstZero(op2)){
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);	
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }
    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)){
      temp_expr = NewIntExpr(IntegralExprValue(op1) | IntegralExprValue(op2));
      RemoveExpr(new);
      return temp_expr;
    }
    return new;

  case OP_xor :
    /*	1) 0 xor B		=> B
     *	2) A xor 0		=> A
     *	3) N1 xor N2		=> <N1 xor N2>   (N1, N2 integers consts)
     */
    if (IsConstZero(op1)){
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }
    if (IsConstZero(op2)){
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }
    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)){
      temp_expr = NewIntExpr(IntegralExprValue(op1) ^ IntegralExprValue(op2));
      RemoveExpr(new);
      return temp_expr;
    }
    return new;

  case OP_and :
    /*
     *	1) N1 and N2	=> <N1 and N2>	   (N1, N2 integer consts)
     */
    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
      temp_expr = NewIntExpr(IntegralExprValue(op1) & IntegralExprValue(op2));
      RemoveExpr(new);
      return temp_expr;
    }
    return new;

  case OP_eq :
  case OP_ne :
  case OP_lt :
  case OP_le :
  case OP_ge :
  case OP_gt :
    /*
     *	1) N1 == N2  	=>  <N1 == N2>	(N1, N2 constant)
     *	2) N1 != N2  	=>  <N1 != N2>	(N1, N2 constant)
     *	3) N1 < N2  	=>  <N1 < N2>	(N1, N2 constant)
     *	4) N1 <= N2  	=>  <N1 <= N2>	(N1, N2 constant)
     *	5) N1 >= N2  	=>  <N1 >= N2>	(N1, N2 constant)
     *	6> N1 > N2  	=>  <N1 > N2>	(N1, N2 constant)
     */
    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1))
	d1 = op1->value.real;
      else if (IsIntegralExpr(op1))
	d1 = (double) IntegralExprValue(op1);
      else Punt("OP_compare 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2))
	d2 = op2->value.real;
      else if (IsIntegralExpr(op2))
	d2 = (double) IntegralExprValue(op2);
      else Punt("OP_compare 2");
      switch (new->opcode) {
	case OP_eq : RemoveExpr(new); return NewIntExpr(d1==d2);
	case OP_ne : RemoveExpr(new); return NewIntExpr(d1!=d2);
	case OP_lt : RemoveExpr(new); return NewIntExpr(d1<d2);
	case OP_le : RemoveExpr(new); return NewIntExpr(d1<=d2);
	case OP_ge : RemoveExpr(new); return NewIntExpr(d1>=d2);
	case OP_gt : RemoveExpr(new); return NewIntExpr(d1>d2);
      }
      Punt("OP_compare 3");
    }
    return new;

  case OP_rshft :
  case OP_lshft :
    /* 	1) A >> 0	=> A
     *	2) A << 0	=> A
     *	3) N1 >> N2	=> <N1 >> N2> 	(N1, N2 integer constants)
     *	4) N1 << N2	=> <N1 << N2> 	(N1, N2 integer constants)
     */
    if (IsConstZero(op2)){
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }
    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
      int unsigned_A;
      unsigned_A = (op1->type->type & TY_UNSIGNED);
      l1 = IntegralExprValue(op1);
      l2 = IntegralExprValue(op2);
      if (new->opcode==OP_rshft) {
	if (unsigned_A) {
	  RemoveExpr(new);
	  new = NewIntExpr( ((unsigned) l1) >> l2 );
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else {
	  RemoveExpr(new);
	  return NewIntExpr(l1 >> l2);
	}
      }
      if (new->opcode==OP_lshft) {
	if (unsigned_A) {
	  RemoveExpr(new);
	  new = NewIntExpr( ((unsigned) l1) << l2 );
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else {
	  RemoveExpr(new);
	  return NewIntExpr(l1 << l2);
	}
      }
      Punt("OP_shift : 1");
    }
    return new;

  case OP_add :
    /* 	1) A + 0	=> A
     *	2) 0 + B	=> B
     *  3) N1 + N2 	=> <N1 + N2>	(N1, N2 integer consts)
     *
     *	GEH - added the following cases to aid delinearization - 8/23/93
     *  4) A + <-N1>	=> A - N1
     *	5) (A +/- N1) + N2  => A + <N2 +/- N1>	(A integer; N1, N2 int consts)
     *  6) (N1 +/- A) + N2  => <N1 + N2> +/- A	(A integer; N1, N2 int consts)
     *	7) N1 + (A +/- N2)  => A + <N1 +/- N2>	(A integer; N1, N2 int consts)
     *  8) N1 + (N2 +/- A)  => <N1 + N2> +/- A	(A integer; N1, N2 int consts)
     */
    if (IsConstZero(op1)){
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }
    if (IsConstZero(op2)){
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    } 

    scalar = 1;	/* expect all integral values. */
    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	scalar = 0;
	d1 = op1->value.real;
      } else
	if (IsIntegralExpr(op1)) {
	  l1 = IntegralExprValue(op1);
	  d1 = (double) l1;
	} else
	  Punt("OP_arithmetic 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2)) {
	scalar = 0;
	d2 = op2->value.real;
      } else
	if (IsIntegralExpr(op2)) {
	  l2 = IntegralExprValue(op2);
	  d2 = (double) l2;
	} else
	  Punt("OP_arithmetic 2");
      if (scalar) {
	if ((op1->type->type & TY_UNSIGNED) ||
	    (op2->type->type & TY_UNSIGNED)) {
	  RemoveExpr(new);
	  new = NewIntExpr((unsigned) l1 + (unsigned) l2);
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else{
	  RemoveExpr(new);
	  return NewIntExpr(l1 + l2);
	}
      } else{
	/* BCC - fix memory bugs - 11/10/96 */
	IsFloatExprOp1 = IsFloatExpr(op1);
	IsFloatExprOp2 = IsFloatExpr(op2);
	RemoveExpr(new);
	/* BCC - 8/4/96
	return NewRealExpr(d1 + d2);
	*/
	return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(d1+d2) :
						    NewDoubleExpr(d1+d2);
      }
    }

    /* 4) */ 
    if (IsConstNumber(op2) && IsConstNegative(op2)) {
      if (IsIntegralExpr(op2)){
	op2->value.scalar = -op2->value.scalar;
      }
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      else if (IsRealExpr(op2)){
	op2->value.real = -op2->value.real;
      }
      else Punt("constant folding : OP_add");
      new->opcode = OP_sub;
      return new;
    }

    if ((op1->opcode == OP_add || op1->opcode == OP_sub) &&
	op2->opcode == OP_int) {

	if ((op12 = GetOperand(op1, 2))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op11 = GetOperand(op1, 1))->type->type))) {

    /* 5) (A +/- N1) + N2  => A + <N2 +/- N1> (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->operands = op2;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op2->type->type & TY_UNSIGNED) ||
		(op12->type->type & TY_UNSIGNED)) {

		op12->value.scalar = (op1->opcode == OP_add) ? 
		    (unsigned)op2->value.scalar + (unsigned)op12->value.scalar:
		    (unsigned)op2->value.scalar - (unsigned)op12->value.scalar;

		op12->type->type |= TY_UNSIGNED;
	    }
	    else {
		op12->value.scalar = (op1->opcode == OP_add) ? 
				       op2->value.scalar + op12->value.scalar :
				       op2->value.scalar - op12->value.scalar;
	    }
	    op1->opcode = OP_add;
	    RemoveExpr(new);  /* removes op2 */
	    return ReduceExpr(op1);
	}

	else if ((op11 = GetOperand(op1, 1))->opcode == OP_int &&
		 (TYPE_INTEGRAL((op12 = GetOperand(op1, 2))->type->type))) {

    /* 6) (N1 +/- A) + N2  => <N1 + N2> +/- A  (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->operands = op2;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op11->type->type & TY_UNSIGNED) ||
		(op2->type->type & TY_UNSIGNED)) {

		op11->value.scalar = 
		     (unsigned)op11->value.scalar + (unsigned)op2->value.scalar;
		op11->type->type |= TY_UNSIGNED;
	    }
	    else op11->value.scalar = op11->value.scalar + op2->value.scalar;

	    RemoveExpr(new);
	    return ReduceExpr(op1);
	}
    }

    if ((op2->opcode == OP_add || op1->opcode == OP_sub) &&
	op1->opcode == OP_int) {

	if ((op22 = GetOperand(op2, 2))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op21 = GetOperand(op2, 1))->type->type))) {

    /* 7) N1 + (A +/- N2)  => A + <N1 +/- N2>  (A integer; N1, N2 int consts) */
	    
	    op1->sibling = NIL;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op1->type->type & TY_UNSIGNED) ||
		(op22->type->type & TY_UNSIGNED)) {

		op22->value.scalar = (op2->opcode == OP_add) ? 
		    (unsigned)op1->value.scalar + (unsigned)op22->value.scalar:
		    (unsigned)op1->value.scalar - (unsigned)op22->value.scalar;

		op22->type->type |= TY_UNSIGNED;
	    }
	    else {
		op22->value.scalar = (op2->opcode == OP_add) ? 
					op1->value.scalar + op22->value.scalar:
					op1->value.scalar - op22->value.scalar;
	    }

	    op2->opcode = OP_add;
	    RemoveExpr(new);
	    return ReduceExpr(op2);
	}

	if ((op21 = GetOperand(op2, 1))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op22 = GetOperand(op2, 2))->type->type))) {

    /* 8) N1 + (N2 +/- A)  => <N1 + N2> +/- A  (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op1->type->type & TY_UNSIGNED) ||
		(op21->type->type & TY_UNSIGNED)) {

		op21->value.scalar = 
		    (unsigned)op1->value.scalar + (unsigned)op21->value.scalar;

		op21->type->type |= TY_UNSIGNED;
	    }
	    else op21->value.scalar = op1->value.scalar + op21->value.scalar;

	    RemoveExpr(new);
	    return ReduceExpr(op2);
	}
    }
    return new;

  case OP_sub :
    /*	1) A - 0	=> A
     *  2) N1 - N2 	=> <N1 - N2> 	(N1, N2 integer consts)
     *
     *	GEH - added the following cases to aid delinearization - 8/23/93
     *  3) A - <-N1>        => A + N1
     *	4) (A +/- N1) - N2  => A + <-N2 +/- N1>	(A integer; N1, N2 int consts)
     *  5) (N1 +/- A) - N2  => <N1 - N2> +/- A	(A integer; N1, N2 int consts)
     *	6) N1 - (A +/- N2)  => <N1 -/+ N2> - A	(A integer; N1, N2 int consts)
     *  7) N1 - (N2 +/- A)  => <N1 - N2> -/+ A	(A integer; N1, N2 int consts)
     */
    if (IsConstZero(op2)){
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }
    scalar = 1;	/* expect all integral values. */
    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	scalar = 0;
	d1 = op1->value.real;
      } else
	if (IsIntegralExpr(op1)) {
	  l1 = IntegralExprValue(op1);
	  d1 = (double) l1;
	} else
	  Punt("OP_arithmetic 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2)) {
	scalar = 0;
	d2 = op2->value.real;
      } else
	if (IsIntegralExpr(op2)) {
	  l2 = IntegralExprValue(op2);
	  d2 = (double) l2;
	} else
	  Punt("OP_arithmetic 2");
      if (scalar) {
	if ((op1->type->type & TY_UNSIGNED) ||
	    (op2->type->type & TY_UNSIGNED)) {
	  RemoveExpr(new);
	  new = NewIntExpr((unsigned) l1 - (unsigned) l2);
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else{
	  RemoveExpr(new);
	  return NewIntExpr(l1 - l2);
	}
      } else{
        /* BCC - fix memory bugs - 11/10/96 */
        IsFloatExprOp1 = IsFloatExpr(op1);
        IsFloatExprOp2 = IsFloatExpr(op2);
	RemoveExpr(new);
	/* BCC - 8/4/96
	return NewRealExpr(d1 - d2);
	*/
	return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(d1-d2) :
						    NewDoubleExpr(d1-d2);
      }
    }

    /* 3) */ 
    if (IsConstNumber(op2) && IsConstNegative(op2)) {
      if (IsIntegralExpr(op2)){
	op2->value.scalar = -op2->value.scalar;
      }
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      else if (IsRealExpr(op2)){
	op2->value.real = -op2->value.real;
      }
      else Punt("constant folding : OP_sub");
      new->opcode = OP_add;
      return new;
    }

    if ((op1->opcode == OP_add || op1->opcode == OP_sub) &&
	op2->opcode == OP_int) {

	if ((op12 = GetOperand(op1, 2))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op11 = GetOperand(op1, 1))->type->type))) {

    /* 4) (A +/- N1) - N2  => A + <-N2 +/- N1>  (A integer; N1, N2 int consts)*/
	    op1->sibling = NIL;
	    new->operands = op2;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op2->type->type & TY_UNSIGNED) ||
		(op12->type->type & TY_UNSIGNED)) {

		op12->value.scalar = (op1->opcode == OP_add) ? 
		    -(unsigned)op2->value.scalar + (unsigned)op12->value.scalar:
		    -(unsigned)op2->value.scalar - (unsigned)op12->value.scalar;

		op12->type->type |= TY_UNSIGNED;
	    }
	    else {
		op12->value.scalar = (op1->opcode == OP_add) ? 
				      -op2->value.scalar + op12->value.scalar :
				      -op2->value.scalar - op12->value.scalar;
	    }
	    op1->opcode = OP_add;
	    RemoveExpr(new);  /* removes op1 and op12 */
	    return ReduceExpr(op1);
	}

	else if ((op11 = GetOperand(op1, 1))->opcode == OP_int &&
		 (TYPE_INTEGRAL((op12 = GetOperand(op1, 2))->type->type))) {

    /* 5) (N1 +/- A) - N2  => <N1 - N2> +/- A  (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->operands = op2;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op11->type->type & TY_UNSIGNED) ||
		(op2->type->type & TY_UNSIGNED)) {

		op11->value.scalar = 
		     (unsigned)op11->value.scalar - (unsigned)op2->value.scalar;
		op11->type->type |= TY_UNSIGNED;
	    }
	    else op11->value.scalar = op11->value.scalar - op2->value.scalar;

	    RemoveExpr(new);
	    return ReduceExpr(op1);
	}
    }

    if ((op2->opcode == OP_add || op1->opcode == OP_sub) &&
	op1->opcode == OP_int) {

	if ((op22 = GetOperand(op2, 2))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op21 = GetOperand(op2, 1))->type->type))) {

    /* 6) N1 - (A +/- N2)  => <N1 -/+ N2> - A (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op1->type->type & TY_UNSIGNED) ||
		(op22->type->type & TY_UNSIGNED)) {

		op22->value.scalar = (op2->opcode == OP_add) ? 
		    (unsigned)op1->value.scalar - (unsigned)op22->value.scalar:
		    (unsigned)op1->value.scalar + (unsigned)op22->value.scalar;

		op22->type->type |= TY_UNSIGNED;
	    }
	    else {
		op22->value.scalar = (op2->opcode == OP_add) ? 
					op1->value.scalar - op22->value.scalar:
					op1->value.scalar + op22->value.scalar;
	    }

	    op2->opcode = OP_sub;
	    op2->operands = op22;
	    op22->sibling = op21;
	    op21->sibling = NIL;
	    RemoveExpr(new);
	    return ReduceExpr(op2);
	}

	if ((op21 = GetOperand(op2, 1))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op22 = GetOperand(op2, 2))->type->type))) {

    /* 7) N1 - (N2 +/- A)  => <N1 - N2> -/+ A (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op1->type->type & TY_UNSIGNED) ||
		(op21->type->type & TY_UNSIGNED)) {

		op21->value.scalar = 
		    (unsigned)op1->value.scalar - (unsigned)op21->value.scalar;

		op21->type->type |= TY_UNSIGNED;
	    }
	    else op21->value.scalar = op1->value.scalar - op21->value.scalar;

	    op2->opcode = (op2->opcode == OP_add) ? OP_sub : OP_add;
	    RemoveExpr(new);
	    return ReduceExpr(op2);
	}
    }

    return new;

  case OP_mul :
    /*	1) A * 0	=> 0  (if A is side-effect free)
     *	2) 0 * B	=> 0  (if B is side-effect free)
     *	3) A * 1	=> A
     *	4) 1 * B	=> B
     *	5) N1 * N2	=> <N1 * N2>  (N1, N2 constants)
     */
    if (IsConstZero(op2)) {
      if (IsSideEffectFree(op1)) {		/* 0 */
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
	if (IsRealExpr(new)) {
          /* BCC - fix memory bugs - 11/10/96 */
          IsFloatExprOp1 = IsFloatExpr(op1);
          IsFloatExprOp2 = IsFloatExpr(op2);
	  RemoveExpr(new);
	  /* BCC - 8/4/96
	  return NewRealExpr(0.0);
	  */
	  return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(0.0) :
						      NewDoubleExpr(0.0);
	}
	else {
	  RemoveExpr(new);
	  return NewIntExpr(0);
	}
      }
      return new;
    }
    if (IsConstZero(op1)) {
      if (IsSideEffectFree(op2)) {		/* 0 */
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
	if (IsRealExpr(new)) {
          /* BCC - fix memory bugs - 11/10/96 */
          IsFloatExprOp1 = IsFloatExpr(op1);
          IsFloatExprOp2 = IsFloatExpr(op2);
	  RemoveExpr(new);
	  /* BCC - 8/4/96
	  return NewRealExpr(0.0);
	  */
	  return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(0.0) :
						      NewDoubleExpr(0.0);
	}
	else {
	  RemoveExpr(new);
	  return NewIntExpr(0);
	}
      }
      return new;
    }
    if (IsConstOne(op2)){				/* A */
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }
    if (IsConstOne(op1)){				/* B */
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }
    scalar = 1;	/* expect all integral values. */
    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	scalar = 0;
	d1 = op1->value.real;
      } else
	if (IsIntegralExpr(op1)) {
	  l1 = IntegralExprValue(op1);
	  d1 = (double) l1;
	} else
	  Punt("OP_arithmetic 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2)) {
	scalar = 0;
	d2 = op2->value.real;
      } else
	if (IsIntegralExpr(op2)) {
	  l2 = IntegralExprValue(op2);
	  d2 = (double) l2;
	} else
	  Punt("OP_arithmetic 2");
      if (scalar) {
	if ((op1->type->type & TY_UNSIGNED) ||
	    (op2->type->type & TY_UNSIGNED)) {
	  RemoveExpr(new);
	  new = NewIntExpr((unsigned) l1 * (unsigned) l2);
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else
	  RemoveExpr(new);
	  return NewIntExpr(l1 * l2);
      } else
        /* BCC - fix memory bugs - 11/10/96 */
        IsFloatExprOp1 = IsFloatExpr(op1);
        IsFloatExprOp2 = IsFloatExpr(op2);
	RemoveExpr(new);
	/* BCC - 8/4/96
	return NewRealExpr(d1 * d2);
	*/
	return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(d1 * d2) :
						    NewDoubleExpr(d1 * d2);
    }
    return new;

  case OP_div :
    /*	1) A / 1	=> A
     *	2) A / 0	=> report error
     *	3) N1 / N2	=> <N1 / N2>   	(N1, N2 constants)
     */
    if (IsConstOne(op2)){
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }
    if (IsConstZero(op2)) 
      Punt("constant folding : division by zero found");
    scalar = 1;	/* expect all integral values. */
    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	scalar = 0;
	d1 = op1->value.real;
      } else
	if (IsIntegralExpr(op1)) {
	  l1 = IntegralExprValue(op1);
	  d1 = (double) l1;
	} else
	  Punt("OP_arithmetic 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2)) {
	scalar = 0;
	d2 = op2->value.real;
      } else
	if (IsIntegralExpr(op2)) {
	  l2 = IntegralExprValue(op2);
	  d2 = (double) l2;
	} else
	  Punt("OP_arithmetic 2");
      if (scalar) {
	if ((op1->type->type & TY_UNSIGNED) ||
	    (op2->type->type & TY_UNSIGNED)) {
	  RemoveExpr(new);
	  new = NewIntExpr((unsigned) l1 / (unsigned) l2);
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else{
	  RemoveExpr(new);
	  return NewIntExpr(l1 / l2);
	}
      } else{
        /* BCC - fix memory bugs - 11/10/96 */
        IsFloatExprOp1 = IsFloatExpr(op1);
        IsFloatExprOp2 = IsFloatExpr(op2);
	RemoveExpr(new);
	/* BCC - 8/4/96
	return NewRealExpr(d1 / d2);
	*/
	return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(d1 / d2) :
						    NewDoubleExpr(d1 / d2);
      }
    }
    return new;

  case OP_mod :
    /*	1) A % 0	=> report error
     *	2) 0 % B	=> 0
     *	3) N1 % N2	=> <N1 % N2>    (N1, N2 integer constants)
     */
    if (IsConstZero(op2))
      Punt("constant folding : mod by zero found");
    if (IsConstZero(op1)){
      RemoveExpr(new);
      return NewIntExpr(0);
    }
    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
      l1 = IntegralExprValue(op1);
      l2 = IntegralExprValue(op2);
      RemoveExpr(new);
      return NewIntExpr(l1 % l2);
    }
    return new;

  case OP_neg :
    /* 1) -(N1)	=> <-N1>	(N1 const)
     */
    if (IsConstNumber(op1)) {
      if (IsIntegralExpr(op1)){
        temp_expr = NewIntExpr(- IntegralExprValue(op1));
/* BCC - if the new type should be exactly the same as the old one - 6/29/95*/
	temp_expr->type->type = op1->type->type;
	RemoveExpr(new);
	return temp_expr;
      }
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)){
	/* BCC - 8/4/96 
	temp_expr = NewRealExpr(- op1->value.real);
	*/
	temp_expr = IsFloatExpr(op1) ? NewFloatExpr(- op1->value.real) :
				       NewDoubleExpr(- op1->value.real);
/* BCC - if the new type should be exactly the same as the old one - 6/29/95*/
	temp_expr->type->type = op1->type->type;
	RemoveExpr(new);
	return temp_expr;
      }
      Punt("constant folding : OP_neg");
    }
    return new;

  case OP_not :
    /* 1) !(N1) => <!N1>	(N1 const)
     */
    if (IsConstNumber(op1)) {
      if (IsIntegralExpr(op1)){
	temp_expr = NewIntExpr(! IntegralExprValue(op1));
/* BCC - if the new type should be exactly the same as the old one - 6/29/95*/
	temp_expr->type->type = op1->type->type;
	RemoveExpr(new);
	return temp_expr;
      }
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)){
	temp_expr = NewIntExpr(! op1->value.real);
/* BCC - if the new type should be exactly the same as the old one - 6/29/95*/
	temp_expr->type->type = op1->type->type;
	RemoveExpr(new);
	return temp_expr;
      }
      Punt("constant folding : OP_not");
    }
    return new;

  case OP_inv :
    /* 1) ~(N1) => <~N1> 	(N1 const)
     */
    if (IsIntegralExpr(op1)){
      temp_expr = NewIntExpr(~ IntegralExprValue(op1));
/* BCC - if the new type should be exactly the same as the old one - 6/29/95*/
      temp_expr->type->type = op1->type->type;
      RemoveExpr(new);
      return temp_expr;
    }
    return new;

  case OP_cast : {
    /*
     *	Do not optimize for non-scalars (including pointers).
     *	But during the RTL generation phase, we can convert
     *	all pointers to 0 to (int) 0
     */
    Dcltr dcltr  = new->type->dcltr;
    if (IsConstNumber(op1) && (new->type->dcltr==0)) {
      int t;
      t = new->type->type & TY_TYPE;
      /*
       *	We can optimize (int)->(double)
       *	and (double)->(int) conversions.
       */
      if (IsIntegralExpr(op1)) {	/* int->double */
	l1 = IntegralExprValue(op1);
	if (TYPE_REAL(t)) {	/* int->double */
	  if (IsFloatType(expr->type)) {
	    /* int -> float */
	    Expr ppc;
	    /* BCC - 8/4/96
	    ppc = NewRealExpr((double) l1);
	    */
	    ppc = NewFloatExpr((double) l1);
	    RemoveExpr(new);
	    new = ppc;
	    new->type->type &= ~TY_DOUBLE;
	    new->type->type |= TY_FLOAT;
	  /* GEH - 6/29/93 
	    new->value.real = (double) ((float) new->value.real);
	  */
	    new->value.real = (double) new->value.real;
	  } else {
	    /* int -> double */
	    Expr ppc;
	    /* BCC - 8/4/96
	    ppc = NewRealExpr((double) l1);
	    */
	    ppc = NewDoubleExpr((double) l1);
	    RemoveExpr(new);
	    new = ppc;
	  }
	} else 
/* BCC - We can't ignore the type conversion among int types - 6/12/95 */
#if 0
	  if (t & (TY_SHORT|TY_INT|TY_LONG)) {	/* int->int */
	    /*
	     *	This case might happen when the operand
	     *	of casting has just been reduced.
	     *	e.g. (int) (- 'a')
	     */
	    new->operands = NIL;
	    RemoveExpr(new);
	    op1->sibling = NIL;
	    RemoveExpr(op2);
	    new = op1;
	  }
#endif
/* BCC - here is what we should do - 6/11/95 */
	if (init_mspec == 1) {
	  int source,dest;
	  Expr ppc;
	  long value;

	  dest = new->type->type & TY_TYPE;
	  source = op1->type->type & TY_TYPE;

	  /* original value */
	  switch (op1->opcode) {
	    case OP_int :
	      value = op1->value.scalar;
	      break;
	    case OP_char:
	      value = C_str2char(op1->value.string);
	      break;
	    case OP_var:	/* BCC - will be reduced in Hcode */
	      /* BCC - bug fix for enum var - 1/25/96 */
	      if (op1->enum_flag == 1)
		value = l1;	/* BCC - reduced earlier 1/25/96 */
	      else 
		return new;
	  }

/* The following code extends the sign bit from the source operand */
/* don't have to care about long because it's the longest type     */
	  if (dest & TY_INT) {
	    if (P_LONG_SIZE != P_INT_SIZE) {
	      value <<= P_LONG_SIZE - P_INT_SIZE;
	      value >>= P_LONG_SIZE - P_INT_SIZE;
	    };
	  }
	  else if (dest & TY_SHORT) {
	    value <<= P_LONG_SIZE - P_SHORT_SIZE;
	    value >>= P_LONG_SIZE - P_SHORT_SIZE;
	  }
	  else if (dest & TY_CHAR) {
	    value <<= P_LONG_SIZE - P_CHAR_SIZE;
	    value >>= P_LONG_SIZE - P_CHAR_SIZE;
	  };

/* Now handle the signed-unsigned destination operand, don't care long type */
	  if (dest & TY_UNSIGNED) {
	    if (dest & TY_INT)
	      value &= P_UNSIGNED_INT_MASK;
	    else if (dest & TY_SHORT)
	      value &= P_UNSIGNED_SHORT_MASK;
	    else if (dest & TY_CHAR)
	      value &= P_UNSIGNED_CHAR_MASK;
	  };

	  /* BCC - bug fix for (void) 0 - 10/23/96 */
	  if (dest & (TY_LONG | TY_INT | TY_SHORT | TY_CHAR)) {
	      /* Now build a new expression */
	      ppc = NewIntExpr((int) value);
	      RemoveExpr(new);
	      new = ppc;
	  }
	  else
	      return new;

	  /* Now set type */
	  if (dest & TY_LONG)
	    new->type->type = TY_LONG | TY_CONST;
	  else if (dest & TY_INT)
	    new->type->type = TY_INT | TY_CONST;
	  else if (dest & TY_SHORT)
	    new->type->type = TY_SHORT | TY_CONST;
	  else if (dest & TY_CHAR)
	    new->type->type = TY_CHAR | TY_CONST;

	  if (dest & TY_UNSIGNED)
	    new->type->type |= TY_UNSIGNED;
	  else
	    new->type->type |= TY_SIGNED;
	}
      } else
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
	if (IsRealExpr(op1)) {	/* double->int */
	  d1 = op1->value.real;
	  if (t & (TY_SHORT|TY_INT|TY_LONG)) {
	    Expr ppc;
	    ppc = NewIntExpr((int) d1);
	    RemoveExpr(new);
	    new = ppc;
	    if (t & TY_UNSIGNED)
	      new->type->type |= TY_UNSIGNED;
	  } else
	    if (TYPE_REAL(t)) {	
	      if (IsFloatType(op1->type) && IsDoubleType(expr->type)) {
		/* float -> double */
		new->operands = NIL;
		RemoveExpr(new);
		op1->sibling = NIL;
		RemoveExpr(op2);
		new = op1;
		new->type->type &= ~TY_FLOAT;
		new->type->type |= TY_DOUBLE;
		/* BCC - 8/5/96 */
		new->opcode = OP_double;
	      } else
		if (IsFloatType(expr->type) && IsDoubleType(op1->type)) {
		  /* double -> float */
		  new->operands = NIL;
		  RemoveExpr(new);
		  op1->sibling = NIL;
		  RemoveExpr(op2);
		  new = op1;
		  new->type->type &= ~TY_DOUBLE;
		  new->type->type |= TY_FLOAT;
	      /* GEH - 6/29/93
		  new->value.real = (double) ((float) new->value.real);
	      */
		  new->value.real = (double) new->value.real;
		  /* BCC - 8/5/96 */
		  new->opcode = OP_float;
		} else {
		  new->operands = NIL;
		  RemoveExpr(new);
		  op1->sibling = NIL;
		  RemoveExpr(op2);
		  new = op1;
		}
	    } 
	}
    }
    return new;
  }
    default :
      /* no compression */
      return new;
  }
}
/*--------------------------------------------------------------------------*/
/*
 *  NJW:  Don't do constant folding here.
 *
 *  In hcode (reduce.c):
 *	Apply constant folding on all expressions.
 *	This function destroys all profile information and
 *	profile database.
 */
/*--------------------------------------------------------------------------*/

/* 
 * GEH - added to be able to reduce expressions with access pointers without
 * losing the accesses.  Also, no OP_vars are reduced away in order to prevent
 * problems with the access table pointing to deallocated expressions. (5/20/93)
 */

Expr ReduceExprWithAcc(expr)
     Expr expr;
{
  Expr new;
  int i,j;
  int IsFloatExprOp1, IsFloatExprOp2;
  Expr temp, temp_expr;
  Expr op1, op2, op3, op_temp, op11, op12, op21, op22;
  Type type;
  double d1, d2;
  long l1, l2;
  short scalar;
  /*
   *	Basic cases: leaf-level nodes. 
   */
  if (expr==0) 
    return 0;

  switch (expr->opcode) {
  case OP_var:
  case OP_char:
  case OP_string:
  case OP_real:
  /* BCC - added - 8/3/96 */
  case OP_float:
  /* BCC - added - 8/3/96 */
  case OP_double:
  case OP_int:
  case OP_type_size:
  case OP_expr_size:
    return CopyExprWithAcc(expr);

  default:
    break;
  }

  /* 
   *	Compress all operands first.
   */
  /* DIA - 4/31/94: Added traversal of next fields which were getting stripped */
  new = CopyNodeWithAcc(expr);	/* copy the root node only */
  for (i=1; (op1=GetOperand(expr, i))!=0; i++) {
    AddOperand(new, ReduceExprWithAcc(op1));
    for(j=1; (op2=GetNextOperand(op1, j))!=0; j++)
       AddNextOperand(GetOperand(new, i), ReduceExprWithAcc(op2));
  }

  /* 
   *	Obtain the first three operands.
   *	Not all operations use these many, 
   *	but it is easier this way. 
   */

  /* also handle comma expressions - don't have to worry about OP_compexpr
   * or OP_index - but included them anyhow.  (NJW) 
   * DIA - Sorry NJW, but we do have to worry about OP_compexpr!
   */

  if(new->opcode == OP_compexpr) {
    op_temp = ExprOperand(1, new);
    op1 = GetLastOperand(op_temp);
  } else
    op1 = ExprOperand(1, new);

  if((new->opcode == OP_index) || (new->opcode == OP_quest)) {
    op_temp = ExprOperand(2, new);
    op2 = GetLastOperand(op_temp);
  } else
    op2 = ExprOperand(2, new);

  op3 = ExprOperand(3, new);

  /* 
   *	Apply constant folding on the current node.
   */
  switch (new->opcode) {

  case OP_compexpr:
   /* 
   ** DIA - 5/9/94: Want to convert (5) => 5
   ** ( num )    =>     num
   */

    if (IsConstNumber(op1))
     {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1))
       {
	d1 = op1->value.real;
        /* BCC - fix memory bugs - 11/10/96 */
        IsFloatExprOp1 = IsFloatExpr(op1);
	RemoveExpr(new);
	/* BCC - 8/4/96
	return NewRealExpr(d1);
	*/
	return IsFloatExprOp1 ? NewFloatExpr(d1) : NewDoubleExpr(d1);
       }
      else
       if (IsIntegralExpr(op1))
	{
	 l1 = IntegralExprValue(op1);
	 if (op1->type->type & TY_UNSIGNED)
	  {
	   RemoveExpr(new);
	   new = NewIntExpr((unsigned) l1);
	   new->type->type |= TY_UNSIGNED;
	   return new;
	  }
	 else
	  {
	   RemoveExpr(new);
	   return NewIntExpr(l1);
	  }
	}
       else Punt("OP_compexpr 1");
     }
    return new;
  /* DIA - End of additional code */

  case OP_quest :
    /*	1) true ? A : B 	=> A
     *	2) false ? A : B	=> B
     */
    if (IsConstZero(op1)) {
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op3, type);
      RemoveExpr(new);
      op_temp->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }
    if (IsConstNonZero(op1)) {
      type = new->type;
      new->operands = NIL;
      Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      op_temp->sibling = NIL;
      RemoveExpr(op3);
      return op_temp;
    }
    return new;

  case OP_disj :
    /*	1) true || B		=> true || B  no change since can't remove B
     *	2) false || B		=> (B!=0)
     *	3) A || true		=> A || true  no change since can't remove A
     *	4) A || false		=> (A!=0)
     */

    if (IsConstZero(op1)) {
      new->operands = NIL;
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return NotZero(op2);	/* B!=0 */
    }

    if (IsConstZero(op2)) {
      new->operands = NIL;
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op2);
      return NotZero(op1);	/* A!=0 */
    }

    return new;

  case OP_conj :
    /*	1) false && B		=> false && B  no change, can't remove B 
     *	2) true && B		=> (B!=0)
     *	3) A && true		=> (A!=0)
     *	4) A && false		=> A && false  no change, can't remove A 
     */

    if (IsConstNonZero(op1)) {
      new->operands = NIL;
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return NotZero(op2);	/* B!=0 */
    }

    if (IsConstNonZero(op2)) {
      new->operands = NIL;
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op2);
      return NotZero(op1);	/* A!=0 */
    }

    return new;

  case OP_or :
    /*	1) 0 or B		=> B
     *	2) A or 0		=> A
     *	3) N1 or N2		=> <N1 or N2>   (N1, N2 integer constants)
     */

    if (IsConstZero(op1)) {
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }

    if (IsConstZero(op2)) {
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);	
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }

    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
      temp = NewIntExpr(IntegralExprValue(op1) | IntegralExprValue(op2));
      RemoveExpr(new);
      return temp;
    }

    return new;

  case OP_xor :
    /*	1) 0 xor B		=> B
     *	2) A xor 0		=> A
     *	3) N1 xor N2 		=> <N1 xor N2>   (N1, N2 integer constants)
     */

    if (IsConstZero(op1)) {
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }

    if (IsConstZero(op2)) {
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);	
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }

    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
      temp = NewIntExpr(IntegralExprValue(op1) ^ IntegralExprValue(op2));
      RemoveExpr(new);
      return temp;
    }

    return new;

  case OP_and :
    /*
     *	1) N1 and N2 	=> <N1 and N2> 		(N1, N2 integer consts)
     */

    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
      temp = NewIntExpr(IntegralExprValue(op1) & IntegralExprValue(op2));
      RemoveExpr(new);
      return temp;
    }

    return new;

  case OP_eq :
  case OP_ne :
  case OP_lt :
  case OP_le :
  case OP_ge :
  case OP_gt :
    /*
     *	1) N1 == N2  	=>  <N1 == N2>	(N1, N2 constant)
     *	2) N1 != N2  	=>  <N1 != N2>	(N1, N2 constant)
     *	3) N1 < N2  	=>  <N1 < N2>	(N1, N2 constant)
     *	4) N1 <= N2  	=>  <N1 <= N2>	(N1, N2 constant)
     *	5) N1 >= N2  	=>  <N1 >= N2>	(N1, N2 constant)
     *	6> N1 > N2  	=>  <N1 > N2>	(N1, N2 constant)
     */

    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1))
	d1 = op1->value.real;
      else if (IsIntegralExpr(op1))
	d1 = (double) IntegralExprValue(op1);
      else Punt("OP_compare 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2))
	d2 = op2->value.real;
      else if (IsIntegralExpr(op2))
	d2 = (double) IntegralExprValue(op2);
      else Punt("OP_compare 2");
      switch (new->opcode) {
        case OP_eq : RemoveExpr(new); return NewIntExpr(d1==d2);
        case OP_ne : RemoveExpr(new); return NewIntExpr(d1!=d2);
        case OP_lt : RemoveExpr(new); return NewIntExpr(d1<d2);
        case OP_le : RemoveExpr(new); return NewIntExpr(d1<=d2);
        case OP_ge : RemoveExpr(new); return NewIntExpr(d1>=d2);
        case OP_gt : RemoveExpr(new); return NewIntExpr(d1>d2);
      }
      Punt("OP_compare 3");
    }
    return new;

  case OP_rshft :
  case OP_lshft :
    /* 	1) A >> 0	=> A
     *	2) A << 0	=> A
     *	3) N1 >> N2	=> <N1 >> N2> 	(N1, N2 integer constants)
     *	4) N1 << N2	=> <N1 << N2> 	(N1, N2 integer constants)
     */

    if (IsConstZero(op2)) {
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }

    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
      int unsigned_A;
      unsigned_A = (op1->type->type & TY_UNSIGNED);
      l1 = IntegralExprValue(op1);
      l2 = IntegralExprValue(op2);
      if (new->opcode==OP_rshft) {
	if (unsigned_A) {
	  RemoveExpr(new);
	  new = NewIntExpr( ((unsigned) l1) >> l2 );
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else {
	  RemoveExpr(new);
	  return NewIntExpr(l1 >> l2);
	}
      }
      if (new->opcode==OP_lshft) {
	if (unsigned_A) {
	  RemoveExpr(new);
	  new = NewIntExpr( ((unsigned) l1) << l2 );
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else {
	  RemoveExpr(new);
	  return NewIntExpr(l1 << l2);
	}
      }
      Punt("OP_shift : 1");
    }
    return new;

  case OP_add :
    /* 	1) A + 0	=> A
     *	2) 0 + B	=> B
     *  3) N1 + N2 	=> <N1 + N2>	(N1, N2 integer consts)
     *
     *	GEH - added the following cases to aid delinearization - 8/23/93
     *  4) A + <-N1>	=> A - N1
     *	5) (A +/- N1) + N2  => A + <N2 +/- N1>	(A integer; N1, N2 int consts)
     *  6) (N1 +/- A) + N2  => <N1 + N2> +/- A	(A integer; N1, N2 int consts)
     *	7) N1 + (A +/- N2)  => A + <N1 +/- N2>	(A integer; N1, N2 int consts)
     *  8) N1 + (N2 +/- A)  => <N1 + N2> +/- A	(A integer; N1, N2 int consts)
     */

    if (IsConstZero(op1)) {
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }

    if (IsConstZero(op2)) {
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }

    scalar = 1;	/* expect all integral values. */

    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	scalar = 0;
	d1 = op1->value.real;
      } else
	if (IsIntegralExpr(op1)) {
	  l1 = IntegralExprValue(op1);
	  d1 = (double) l1;
	} else
	  Punt("OP_arithmetic 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2)) {
	scalar = 0;
	d2 = op2->value.real;
      } else
	if (IsIntegralExpr(op2)) {
	  l2 = IntegralExprValue(op2);
	  d2 = (double) l2;
	} else
	  Punt("OP_arithmetic 2");
      if (scalar) {
	if ((op1->type->type & TY_UNSIGNED) ||
	    (op2->type->type & TY_UNSIGNED)) {
	  RemoveExpr(new);
	  new = NewIntExpr((unsigned) l1 + (unsigned) l2);
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else {
	  RemoveExpr(new);
	  return NewIntExpr(l1 + l2);
	}
      } else {
        /* BCC - fix memory bugs - 11/10/96 */
        IsFloatExprOp1 = IsFloatExpr(op1);
        IsFloatExprOp2 = IsFloatExpr(op2);
	RemoveExpr(new);
	/* BCC - 8/4/96
	return NewRealExpr(d1 + d2);
	*/
	return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(d1+d2) :
						    NewDoubleExpr(d1+d2);
      }
    }

    /* 4) */ 
    if (IsConstNumber(op2) && IsConstNegative(op2)) {
      if (IsIntegralExpr(op2)){
	op2->value.scalar = -op2->value.scalar;
      }
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      else if (IsRealExpr(op2)){
	op2->value.real = -op2->value.real;
      }
      else Punt("constant folding : OP_add");
      new->opcode = OP_sub;
      return new;
    }

    if ((op1->opcode == OP_add || op1->opcode == OP_sub) &&
	op2->opcode == OP_int) {

	if ((op12 = GetOperand(op1, 2))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op11 = GetOperand(op1, 1))->type->type))) {

    /* 5) (A +/- N1) + N2  => A + <N2 +/- N1> (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->operands = op2;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op2->type->type & TY_UNSIGNED) ||
		(op12->type->type & TY_UNSIGNED)) {

		op12->value.scalar = (op1->opcode == OP_add) ? 
		    (unsigned)op2->value.scalar + (unsigned)op12->value.scalar:
		    (unsigned)op2->value.scalar - (unsigned)op12->value.scalar;

		op12->type->type |= TY_UNSIGNED;
	    }
	    else {
		op12->value.scalar = (op1->opcode == OP_add) ? 
				       op2->value.scalar + op12->value.scalar :
				       op2->value.scalar - op12->value.scalar;
	    }
	    op1->opcode = OP_add;
	    RemoveExpr(new);  /* removes op1 and op12 */
	    return ReduceExprWithAcc(op1);
	}

	else if ((op11 = GetOperand(op1, 1))->opcode == OP_int &&
		 (TYPE_INTEGRAL((op12 = GetOperand(op1, 2))->type->type))) {

    /* 6) (N1 +/- A) + N2  => <N1 + N2> +/- A  (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->operands = op2;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op11->type->type & TY_UNSIGNED) ||
		(op2->type->type & TY_UNSIGNED)) {

		op11->value.scalar = 
		     (unsigned)op11->value.scalar + (unsigned)op2->value.scalar;
		op11->type->type |= TY_UNSIGNED;
	    }
	    else op11->value.scalar = op11->value.scalar + op2->value.scalar;

	    RemoveExpr(new);
	    return ReduceExprWithAcc(op1);
	}
    }

    if ((op2->opcode == OP_add || op1->opcode == OP_sub) &&
	op1->opcode == OP_int) {

	if ((op22 = GetOperand(op2, 2))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op21 = GetOperand(op2, 1))->type->type))) {

    /* 7) N1 + (A +/- N2)  => A + <N1 +/- N2>  (A integer; N1, N2 int consts) */
	    
	    op1->sibling = NIL;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op1->type->type & TY_UNSIGNED) ||
		(op22->type->type & TY_UNSIGNED)) {

		op22->value.scalar = (op2->opcode == OP_add) ? 
		    (unsigned)op1->value.scalar + (unsigned)op22->value.scalar:
		    (unsigned)op1->value.scalar - (unsigned)op22->value.scalar;

		op22->type->type |= TY_UNSIGNED;
	    }
	    else {
		op22->value.scalar = (op2->opcode == OP_add) ? 
					op1->value.scalar + op22->value.scalar:
					op1->value.scalar - op22->value.scalar;
	    }

	    op2->opcode = OP_add;
	    RemoveExpr(new);
	    return ReduceExprWithAcc(op2);
	}

	if ((op21 = GetOperand(op2, 1))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op22 = GetOperand(op2, 2))->type->type))) {

    /* 8) N1 + (N2 +/- A)  => <N1 + N2> +/- A  (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op1->type->type & TY_UNSIGNED) ||
		(op21->type->type & TY_UNSIGNED)) {

		op21->value.scalar = 
		    (unsigned)op1->value.scalar + (unsigned)op21->value.scalar;

		op21->type->type |= TY_UNSIGNED;
	    }
	    else op21->value.scalar = op1->value.scalar + op21->value.scalar;

	    RemoveExpr(new);
	    return ReduceExprWithAcc(op2);
	}
    }

    return new;

  case OP_sub :
    /*	1) A - 0	=> A	
     *  2) N1 - N2 	=> <N1 - N2> 	(N1, N2 integer consts)
     *
     *	GEH - added the following cases to aid delinearization - 8/23/93
     *  3) A - <-N1> 	=>  A + N1
     *	4) (A +/- N1) - N2  => A + <-N2 +/- N1>	(A integer; N1, N2 int consts)
     *  5) (N1 +/- A) - N2  => <N1 - N2> +/- A	(A integer; N1, N2 int consts)
     *	6) N1 - (A +/- N2)  => <N1 -/+ N2> - A	(A integer; N1, N2 int consts)
     *  7) N1 - (N2 +/- A)  => <N1 - N2> -/+ A	(A integer; N1, N2 int consts)
     */

    if (IsConstZero(op2)) {
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }

    scalar = 1;	/* expect all integral values. */

    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	scalar = 0;
	d1 = op1->value.real;
      } else
	if (IsIntegralExpr(op1)) {
	  l1 = IntegralExprValue(op1);
	  d1 = (double) l1;
	} else
	  Punt("OP_arithmetic 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2)) {
	scalar = 0;
	d2 = op2->value.real;
      } else
	if (IsIntegralExpr(op2)) {
	  l2 = IntegralExprValue(op2);
	  d2 = (double) l2;
	} else
	  Punt("OP_arithmetic 2");
      if (scalar) {
	if ((op1->type->type & TY_UNSIGNED) ||
	    (op2->type->type & TY_UNSIGNED)) {
	  RemoveExpr(new);
	  new = NewIntExpr((unsigned) l1 - (unsigned) l2);
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else {
	  RemoveExpr(new);
	  return NewIntExpr(l1 - l2);
	}
      } else {
        /* BCC - fix memory bugs - 11/10/96 */
        IsFloatExprOp1 = IsFloatExpr(op1);
        IsFloatExprOp2 = IsFloatExpr(op2);
	RemoveExpr(new);
	/* BCC - 8/4/96
	return NewRealExpr(d1 - d2);
	*/
	return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(d1-d2) :
						    NewDoubleExpr(d1-d2);
      }
    }

    /* 3) */ 
    if (IsConstNumber(op2) && IsConstNegative(op2)) {
      if (IsIntegralExpr(op2)){
	op2->value.scalar = -op2->value.scalar;
      }
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      else if (IsRealExpr(op2)){
	op2->value.real = -op2->value.real;
      }
      else Punt("constant folding : OP_sub");
      new->opcode = OP_add;
      return new;
    }

    if ((op1->opcode == OP_add || op1->opcode == OP_sub) &&
	op2->opcode == OP_int) {

	if ((op12 = GetOperand(op1, 2))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op11 = GetOperand(op1, 1))->type->type))) {

    /* 4) (A +/- N1) - N2  => A + <-N2 +/- N1>  (A integer; N1, N2 int consts)*/
	    op1->sibling = NIL;
	    new->operands = op2;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op2->type->type & TY_UNSIGNED) ||
		(op12->type->type & TY_UNSIGNED)) {

		op12->value.scalar = (op1->opcode == OP_add) ? 
		    -(unsigned)op2->value.scalar + (unsigned)op12->value.scalar:
		    -(unsigned)op2->value.scalar - (unsigned)op12->value.scalar;

		op12->type->type |= TY_UNSIGNED;
	    }
	    else {
		op12->value.scalar = (op1->opcode == OP_add) ? 
				      -op2->value.scalar + op12->value.scalar :
				      -op2->value.scalar - op12->value.scalar;
	    }
	    op1->opcode = OP_add;
	    RemoveExpr(new);  /* removes op1 and op12 */
	    return ReduceExprWithAcc(op1);
	}

	else if ((op11 = GetOperand(op1, 1))->opcode == OP_int &&
		 (TYPE_INTEGRAL((op12 = GetOperand(op1, 2))->type->type))) {

    /* 5) (N1 +/- A) - N2  => <N1 - N2> +/- A  (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->operands = op2;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op11->type->type & TY_UNSIGNED) ||
		(op2->type->type & TY_UNSIGNED)) {

		op11->value.scalar = 
		     (unsigned)op11->value.scalar - (unsigned)op2->value.scalar;
		op11->type->type |= TY_UNSIGNED;
	    }
	    else op11->value.scalar = op11->value.scalar - op2->value.scalar;

	    RemoveExpr(new);
	    return ReduceExprWithAcc(op1);
	}
    }

    if ((op2->opcode == OP_add || op1->opcode == OP_sub) &&
	op1->opcode == OP_int) {

	if ((op22 = GetOperand(op2, 2))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op21 = GetOperand(op2, 1))->type->type))) {

    /* 6) N1 - (A +/- N2)  => <N1 -/+ N2> - A (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op1->type->type & TY_UNSIGNED) ||
		(op22->type->type & TY_UNSIGNED)) {

		op22->value.scalar = (op2->opcode == OP_add) ? 
		    (unsigned)op1->value.scalar - (unsigned)op22->value.scalar:
		    (unsigned)op1->value.scalar + (unsigned)op22->value.scalar;

		op22->type->type |= TY_UNSIGNED;
	    }
	    else {
		op22->value.scalar = (op2->opcode == OP_add) ? 
					op1->value.scalar - op22->value.scalar:
					op1->value.scalar + op22->value.scalar;
	    }

	    op2->opcode = OP_sub;
	    op2->operands = op22;
	    op22->sibling = op21;
	    op21->sibling = NIL;
	    RemoveExpr(new);
	    return ReduceExprWithAcc(op2);
	}

	if ((op21 = GetOperand(op2, 1))->opcode == OP_int &&
	    (TYPE_INTEGRAL((op22 = GetOperand(op2, 2))->type->type))) {

    /* 7) N1 - (N2 +/- A)  => <N1 - N2> -/+ A (A integer; N1, N2 int consts) */
	    op1->sibling = NIL;
	    new->sibling = NIL;
	    new->next = NIL;

	    if ((op1->type->type & TY_UNSIGNED) ||
		(op21->type->type & TY_UNSIGNED)) {

		op21->value.scalar = 
		    (unsigned)op1->value.scalar - (unsigned)op21->value.scalar;

		op21->type->type |= TY_UNSIGNED;
	    }
	    else op21->value.scalar = op1->value.scalar - op21->value.scalar;

	    op2->opcode = (op2->opcode == OP_add) ? OP_sub : OP_add;
	    RemoveExpr(new);
	    return ReduceExprWithAcc(op2);
	}
    }
    return new;

  case OP_mul :
    /*	1) A * 0	=> A * 0 	 don't reduce, can't remove A 
     *	2) 0 * B	=> 0 * B	 don't reduce, can't remove B 
     *	3) A * 1	=> A
     *	4) 1 * B	=> B
     *	5) N1 * N2	=> <N1 * N2>	(N1, N2 consts)
     */

    if (IsConstOne(op2)) {				/* A */
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }

    if (IsConstOne(op1)) {				/* B */
      type = new->type;
      new->operands = NIL;
      temp_expr = Cast(op2, type);
      RemoveExpr(new);
      op1->sibling = NIL;
      RemoveExpr(op1);
      return temp_expr;
    }

    scalar = 1;	/* expect all integral values. */

    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	scalar = 0;
	d1 = op1->value.real;
      } else
	if (IsIntegralExpr(op1)) {
	  l1 = IntegralExprValue(op1);
	  d1 = (double) l1;
	} else
	  Punt("OP_arithmetic 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2)) {
	scalar = 0;
	d2 = op2->value.real;
      } else
	if (IsIntegralExpr(op2)) {
	  l2 = IntegralExprValue(op2);
	  d2 = (double) l2;
	} else
	  Punt("OP_arithmetic 2");
      if (scalar) {
	if ((op1->type->type & TY_UNSIGNED) ||
	    (op2->type->type & TY_UNSIGNED)) {
	  RemoveExpr(new);
	  new = NewIntExpr((unsigned) l1 * (unsigned) l2);
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else {
	  RemoveExpr(new);
	  return NewIntExpr(l1 * l2);
	}
      } else {
        /* BCC - fix memory bugs - 11/10/96 */
        IsFloatExprOp1 = IsFloatExpr(op1);
        IsFloatExprOp2 = IsFloatExpr(op2);
	RemoveExpr(new);
	/* BCC - 8/4/96
	return NewRealExpr(d1 * d2);
	*/
	return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(d1*d2) :
						    NewDoubleExpr(d1*d2);
      }
    }
    return new;

  case OP_div :
    /*	1) A / 1	=> A
     *	2) A / 0	=> report error
     *	3) N1 / N2 	=> <N1 / N2>	(N1, N2 consts)
     */

    if (IsConstOne(op2)) {
      type = new->type;
      new->operands = NIL;
      op1->sibling = NIL;
      temp_expr = Cast(op1, type);
      RemoveExpr(new);
      RemoveExpr(op2);
      return temp_expr;
    }

    if (IsConstZero(op2)) 
      Punt("constant folding : division by zero found");

    scalar = 1;	/* expect all integral values. */

    if (IsConstNumber(op1) && IsConstNumber(op2)) {
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	scalar = 0;
	d1 = op1->value.real;
      } else
	if (IsIntegralExpr(op1)) {
	  l1 = IntegralExprValue(op1);
	  d1 = (double) l1;
	} else
	  Punt("OP_arithmetic 1");
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op2)) {
	scalar = 0;
	d2 = op2->value.real;
      } else
	if (IsIntegralExpr(op2)) {
	  l2 = IntegralExprValue(op2);
	  d2 = (double) l2;
	} else
	  Punt("OP_arithmetic 2");
      if (scalar) {
	if ((op1->type->type & TY_UNSIGNED) ||
	    (op2->type->type & TY_UNSIGNED)) {
	  RemoveExpr(new);
	  new = NewIntExpr((unsigned) l1 / (unsigned) l2);
	  new->type->type |= TY_UNSIGNED;
	  return new;
	} else {
	  RemoveExpr(new);
	  return NewIntExpr(l1 / l2);
	}
      } else {
        /* BCC - fix memory bugs - 11/10/96 */
        IsFloatExprOp1 = IsFloatExpr(op1);
        IsFloatExprOp2 = IsFloatExpr(op2);
	RemoveExpr(new);
	/* BCC - 8/4/96
	return NewRealExpr(d1 / d2);
	*/
	return (IsFloatExprOp1 && IsFloatExprOp2) ? NewFloatExpr(d1/d2) :
						    NewDoubleExpr(d1/d2);
      }
    }
    return new;

  case OP_mod :
    /*	1) A % 0	=> report error
     *	2) 0 % B	=> 0
     *	3) N1 % N2	=> <N1 % N2>	(N1, N2 integer consts)
     */
    if (IsConstZero(op2))
      Punt("constant folding : mod by zero found");

    if (IsConstZero(op1)) {
      RemoveExpr(new);
      return NewIntExpr(0);
    }

    if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
      l1 = IntegralExprValue(op1);
      l2 = IntegralExprValue(op2);
      RemoveExpr(new);
      return NewIntExpr(l1 % l2);
    }
    return new;

  case OP_neg :
    /* 1) -(N1)	=> <-N1>	(N1 const)
     */

    if (IsConstNumber(op1)) {
      if (IsIntegralExpr(op1)) {
	temp = NewIntExpr(- IntegralExprValue(op1));
	RemoveExpr(new);
	return temp;
      }
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	/* BCC - 8/4/96
	temp = NewRealExpr(- op1->value.real);
	*/
	temp = IsFloatExpr(op1) ? NewFloatExpr(- op1->value.real) :
				  NewDoubleExpr(- op1->value.real);
	RemoveExpr(new);
	return temp;
      }
      Punt("constant folding : OP_neg");
    }
    return new;

  case OP_not :
    /* 1) !(N1) => <!N1>	(N1 const)
     */
    if (IsConstNumber(op1)) {
      if (IsIntegralExpr(op1)) {
	temp = NewIntExpr(! IntegralExprValue(op1));
	RemoveExpr(new);
	return temp;
      }
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
      if (IsRealExpr(op1)) {
	temp = NewIntExpr(! op1->value.real);
	RemoveExpr(new);
	return temp;
      }
      Punt("constant folding : OP_not");
    }
    return new;

  case OP_inv :
    /* 1) ~(N1) => <~N1> 	(N1 const)
     */
    if (IsIntegralExpr(op1)) {
      temp = NewIntExpr(~ IntegralExprValue(op1));
      RemoveExpr(new);
      return temp;
    }
    return new;

  case OP_cast : {
    /*
     *	Do not optimize for non-scalars (including pointers).
     *	But during the RTL generation phase, we can convert
     *	all pointers to 0 to (int) 0
     */

    Dcltr  dcltr = new->type->dcltr;
    if (IsConstNumber(op1) && (new->type->dcltr==0)) {
      int t;
      t = new->type->type & TY_TYPE;
      /*
       *	We can optimize (int)->(double)
       *	and (double)->(int) conversions.
       */
      if (IsIntegralExpr(op1)) {	/* int->double */
	l1 = IntegralExprValue(op1);
	if (TYPE_REAL(t)) {	/* int->double */
	  if (IsFloatType(expr->type)) {
	    /* int -> float */
	    Expr ppc;
	    /* BCC - 8/4/96
	    ppc = NewRealExpr((double) l1);
	    */
	    ppc = NewFloatExpr((double) l1);
	    RemoveExpr(new);
	    new = ppc;
	    new->type->type &= ~TY_DOUBLE;
	    new->type->type |= TY_FLOAT;
	  /* GEH - 6/29/93  
	    new->value.real = (double) ((float) new->value.real);
	  */
	    new->value.real = (double) new->value.real;
	  } else {
	    /* int -> double */
	    Expr ppc;
	    /* BCC - 8/4/96
	    ppc = NewRealExpr((double) l1);
	    */
	    ppc = NewDoubleExpr((double) l1);
	    RemoveExpr(new);
	    new = ppc;
	  }
	} else 
	  if (t & (TY_SHORT|TY_INT|TY_LONG)) {	/* int->int */
	    /*
	     *	This case might happen when the operand
	     *	of casting has just been reduced.
	     *	e.g. (int) (- 'a')
	     */
	    new->operands = NIL;
	    RemoveExpr(new);
	    op1->sibling = NIL;
	    RemoveExpr(op2);
	    new = op1;
	  }
      } else
      /* BCC - use IsRealExpr to compare both OP_double and OP_float - 8/4/96 */
	if (IsRealExpr(op1)) {	/* double->int */
	  d1 = op1->value.real;
	  if (t & (TY_SHORT|TY_INT|TY_LONG)) {
	    Expr ppc;
	    ppc = NewIntExpr((int) d1);
	    RemoveExpr(new);
	    new = ppc;
	    if (t & TY_UNSIGNED)
	      new->type->type |= TY_UNSIGNED;
	  } else
	    if (TYPE_REAL(t)) {	
	      if (IsFloatType(op1->type) && IsDoubleType(expr->type)) {
		/* float -> double */
		new->operands = NIL;
		RemoveExpr(new);
		op1->sibling = NIL;
		RemoveExpr(op2);
		new = op1;
		new->type->type &= ~TY_FLOAT;
		new->type->type |= TY_DOUBLE;
	      } else
		if (IsFloatType(expr->type) && IsDoubleType(op1->type)) {
		  /* double -> float */
		  new->operands = NIL;
		  RemoveExpr(new);
		  op1->sibling = NIL;
		  RemoveExpr(op2);
		  new = op1;
		  new->type->type &= ~TY_DOUBLE;
		  new->type->type |= TY_FLOAT;
		/* GEH - 6/29/93
		  new->value.real = (double) ((float) new->value.real);
		*/
		  new->value.real = (double) new->value.real;
		} else {
		  new->operands = NIL;
		  RemoveExpr(new);
		  op1->sibling = NIL;
		  RemoveExpr(op2);
		  new = op1;
		}
	    }
	}
    }
    return new;
  }

    default :
      /* no compression */
      return new;
  }
}
