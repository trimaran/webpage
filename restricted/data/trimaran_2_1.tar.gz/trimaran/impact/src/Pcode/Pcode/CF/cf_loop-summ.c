/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	cf_loop-summ.c
 *	Author: Grant Haab and Wen-mei Hwu
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <library/set.h>
#include <library/llist.h>
#include <Pcode/flow.h>
#include <Pcode/cf_loop-summ.h>
#include <Pcode/cf_dominator.h>
#include <Pcode/cf_basic-block.h>
#include <Pcode/dd_data-dep.h>	/* only for maxCommonNest */
#include <Pcode/pcode.h>
#include <Pcode/struct.h>
#include <Pcode/parms.h>

static Punt(mesg, stmt)
char *mesg;
Stmt stmt;
{
    if (stmt != NIL) {
	fprintf(Ferr, "# cf_loop-summ: %s in file %s on line %u\n", mesg,
		stmt->filename, stmt->lineno);
    }
    else {
	fprintf(Ferr, "# cf_loop-summ: %s\n", mesg);
    }
    exit(-1);
}

/*
 * Finds loop nesting depth of basic block given as input.  All loop types
 * are included in nesting depth
 */
int CF_Find_Loop_Nest_Depth_For_BB(FuncDcl func, BBNode bb)
{
    LoopSumm ls;
    int li, depth = 0;

    assert(func != NIL && bb != NIL);

    assert(func->flow != NIL);
    flow_graph = func->flow->flow_graph;
    assert(flow_graph != NIL);

    assert(flow_graph->has_bbs);
    bb_graph = flow_graph->bb_graph;
    assert(bb_graph != NIL);

    assert(bb_graph->has_loops);
    ls = bb_graph->loop_summ;

    for (li = 0; li < bb_graph->num_loops; li++) {
	if (Set_in(ls[li].loop_bbs, bb->index) && ls[li].nesting_level > depth)
	    depth = ls[li].nesting_level;
    }
    return depth;
}

/*
 * Find index of loop of specified type in summary data corresponding to 
 * specified pcode stmt.  
 *
 * Returns index into LoopSumm array stored in basic block graph if successful,
 * -1 otherwise.
 *
 * The following statement should be passed for the following loop types:
 * 
 * 	LT_IMPL_LOOP:	loop header stmt
 *	LT_SERLOOP:	stmt of type ST_SERLOOP
 *	LT_PARLOOP:	stmt of type ST_PARLOOP
 */

int CF_Find_Loop_Summ_For_Stmt(loop_type, stmt, func)
_LoopType loop_type;
Stmt stmt;
FuncDcl func;
{
    LoopSumm ls;
    int li;

    assert(func != NIL && stmt != NIL);

    assert(func->flow != NIL);
    flow_graph = func->flow->flow_graph;
    assert(flow_graph != NIL);

    assert(flow_graph->has_bbs);
    bb_graph = flow_graph->bb_graph;
    assert(bb_graph != NIL);

    assert(bb_graph->has_loops);
    ls = bb_graph->loop_summ;
     
    switch (loop_type) {
	case LT_PARLOOP:
	    assert(stmt->type == ST_PARLOOP);
	    stmt = Parloop_Stmts_Body_Stmt(stmt);
	    break;
	
	case LT_SERLOOP:
	    assert(stmt->type == ST_SERLOOP);
	    break;
    }

    for (li = 0; li < bb_graph->num_loops; li++) {
	if (ls[li].loop_type == loop_type &&
	    ls[li].pcode_hdr == stmt) 

	    return li;
    }
    return -1;
}


/* 
 * Determine if loop with index li1 is nested within loop with
 * li2 using loop summary information.
 */

bool CF_Is_Loop_Nested_Within_Loop(li1, li2, loop_summ)
int li1, li2;
LoopSumm loop_summ;
{
    assert(li1 >= 0 && li2 >= 0 && loop_summ != NIL);
    if (loop_summ[li1].nesting_level <= loop_summ[li2].nesting_level) 
	return FALSE;
    if (Set_in(loop_summ[li2].nested_loops, li1)) 
	return TRUE;
    else return FALSE;
}


/*
 * Determine if any loops that are not parloops are nested between the
 * given parloops.  
 *
 * If the given inner_parloop is not nested within the outer_parloop, 
 * return FALSE.  Otherwise, return TRUE if there are any loops nested 
 * between the two parloops, FALSE otherwise.
 *
 * 04/9/95 TLJ: Modified so outer_parloop can be NULL.
 *
 * 01/10/96 TLJ: Modified so inner_parloop can be NULL.
 */

bool CF_Is_NonParloop_Between_Parloops(outer_parloop, inner_parloop, func)
Stmt outer_parloop, inner_parloop;
FuncDcl func;
{
    LoopSumm ls;
    int lo, li, l;		/* outer, inner, and current loop indices */

    assert(func != NIL);

    assert(func->flow != NIL);
    flow_graph = func->flow->flow_graph;
    assert(flow_graph != NIL);

    assert(flow_graph->has_bbs);
    bb_graph = flow_graph->bb_graph;
    assert(bb_graph != NIL);

    assert(bb_graph->has_loops);
    ls = bb_graph->loop_summ;
     
    if (outer_parloop) assert(outer_parloop->type == ST_PARLOOP);
    if (inner_parloop) assert(inner_parloop->type == ST_PARLOOP);

    if (inner_parloop)
    {
    	li = CF_Find_Loop_Summ_For_Stmt(LT_PARLOOP, inner_parloop, func);
    	assert(li >= 0);
    }

    if (outer_parloop)
    {
	lo = CF_Find_Loop_Summ_For_Stmt(LT_PARLOOP, outer_parloop, func);
	assert(lo >= 0);

	if (inner_parloop)
	    if (!CF_Is_Loop_Nested_Within_Loop(li, lo, ls)) return FALSE;
    }

    /* 
     * Could make this more efficient by taking set difference of loops nested
     * within lo and loops nested within li.  Then check to see if any 
     * non-parloops in the resulting set contain li.
     */
    if (inner_parloop)
    {
      for (l = 0; l < bb_graph->num_loops; l++) {
	if (ls[l].loop_type != LT_PARLOOP &&
			CF_Is_Loop_Nested_Within_Loop(li, l, ls))
	{
	    if (!outer_parloop || (outer_parloop && 
			CF_Is_Loop_Nested_Within_Loop(l, lo, ls)))
	    	return TRUE;
	}
      }
    }
    else if (outer_parloop)
    {
      for (l = 0; l < bb_graph->num_loops; l++) {
	if (ls[l].loop_type != LT_PARLOOP &&
			CF_Is_Loop_Nested_Within_Loop(l, lo, ls))
	{
	    return TRUE;
	}
      }
    }
    return FALSE;
}


/*
 * Print the Loop Summary information for ALL loops in function.
 */

void CF_Print_Loop_Summ(file, func)
FILE *file;
FuncDcl func;
{
    LoopSumm loop_summ;
    int li;

    assert(func != NIL && func->flow != NIL);
    flow_graph = func->flow->flow_graph;
    assert(flow_graph->has_bbs);
    bb_graph = flow_graph->bb_graph;
    assert(bb_graph->has_loops);
    loop_summ = bb_graph->loop_summ;

    fprintf(file, "....Printing Loop Summary information for func (%s)\n",
	    func->name);
    
    for (li = 0; li < bb_graph->num_loops; li++) {
	fprintf(file, "\tnumber         %d\n", li);
	fprintf(file, "\tlineno         %d\n", loop_summ[li].pcode_hdr->lineno);
	fprintf(file, "\tlooptype       %s\n", 
		(loop_summ[li].loop_type != LT_IMPL_LOOP) ? 
		 ((loop_summ[li].loop_type == LT_SERLOOP) ? "LT_SERLOOP" 
		 : "LT_PARLOOP") 
		 : "LT_IMPL_LOOP");
	fprintf(file, "\theader bb      %d\n", loop_summ[li].header_bb);
	fprintf(file, "\tnesting level  %d\n", loop_summ[li].nesting_level);
	fprintf(file, "\t");
	Set_print(file, "loop bbs", loop_summ[li].loop_bbs);
	fprintf(file, "\t");
	Set_print(file, "back edge bbs", loop_summ[li].back_edge_bbs);
	fprintf(file, "\t");
	Set_print(file, "exit bbs", loop_summ[li].exit_bbs);
	fprintf(file, "\t");
	Set_print(file, "out bbs", loop_summ[li].out_bbs);
	fprintf(file, "\t");
	Set_print(file, "nested loops", loop_summ[li].nested_loops);
	fprintf(file, "\n");
    }
}


static void CF_Set_Pcode_Hdr_And_Loop_Type(loop_summ, be_head_bb, be_tail_bb)
LoopSumm loop_summ;
BBNode be_head_bb, be_tail_bb;  /* backedge head and tail basic blocks */
{
    FlowNode be_head_fn, be_tail_fn; 	/* backedge head and tail flow nodes */
    Lptr l;

    assert(loop_summ != NIL && be_head_bb != NIL && be_tail_bb != NIL);
    be_tail_fn = (FlowNode) be_tail_bb->flows->ptr;

    l = be_head_bb->flows;
    assert(l != NIL);
    while (l->next != NIL) l = l->next;
    be_head_fn = (FlowNode) l->ptr;

    /* GEH - modified for new for-while loops */
    if (be_head_fn->type == NT_SerloopIterCond || 
	be_head_fn->type == NT_SerloopCond) { /* Serloop */

	loop_summ->loop_type = LT_SERLOOP;
	loop_summ->pcode_hdr = be_head_fn->pcode_ptr.stmt;
    }

    else if (be_tail_fn->type == NT_ParloopBody && 
	     be_head_fn->type == NT_ParloopIterCond) { /* Parloop */

	loop_summ->loop_type = LT_PARLOOP;
	loop_summ->pcode_hdr = be_tail_fn->pcode_ptr.stmt;
    }

    else { /* Implicit loop */

	loop_summ->loop_type = LT_IMPL_LOOP;
	loop_summ->pcode_hdr = be_tail_fn->pcode_ptr.stmt;
    }
}

static void CF_Add_BBs_To_Loop(loop_summ, bb, header_bb)
LoopSumm loop_summ;
int bb, header_bb;
{
    BBNode bbn, pred_bbn;
    Lptr pred;

    assert(loop_summ != NIL && bb_graph->bb_node[bb] != NIL && 
	   bb_graph->bb_node[header_bb] != NIL);

    bbn = bb_graph->bb_node[bb];
    for (pred = bbn->pred; pred != NIL; pred = pred->next) {
	pred_bbn = (BBNode)pred->ptr;
	if (pred_bbn->index == header_bb || 
	    IS_BB_NODE_FLAG_SET(pred_bbn, BBNODE_VISITED)) 
	    continue;
	SET_BB_NODE_FLAGS(pred_bbn, BBNODE_VISITED);
	loop_summ->loop_bbs = Set_add(loop_summ->loop_bbs, pred_bbn->index);
	CF_Add_BBs_To_Loop(loop_summ, pred_bbn->index, header_bb);
    }
}

static void CF_Find_BBs_In_Loop(loop_summ)
LoopSumm loop_summ;
{
    int be_bb[1];

    assert(loop_summ != NIL);

    if (Set_size(loop_summ->back_edge_bbs) != 1) 
	Punt("Number of backedges in loop not equal to one", NIL);

    Set_2array(loop_summ->back_edge_bbs, be_bb);
    loop_summ->loop_bbs = Set_add(loop_summ->loop_bbs, loop_summ->header_bb);
    if (be_bb[0] != loop_summ->header_bb) {
	loop_summ->loop_bbs = Set_add(loop_summ->loop_bbs, be_bb[0]);
	ResetBBGraphFlags(bb_graph, BBNODE_VISITED);
	CF_Add_BBs_To_Loop(loop_summ, be_bb[0], loop_summ->header_bb);
    }
}

static void CF_Find_Exit_Blocks_In_Loops()
{
    int *loop_bbs, li, bbi, num_bbs, succ_bbi;
    BBNode bbn;
    Lptr succ;
    LoopSumm loop_summ;

    loop_summ = bb_graph->loop_summ;
    loop_bbs = (int *) malloc(bb_graph->num_nodes * sizeof(int));

    for (li = 0; li < bb_graph->num_loops; li++) {

	if (loop_summ[li].exit_bbs != NIL)
	    loop_summ[li].exit_bbs = Set_dispose(loop_summ[li].exit_bbs);
	if (loop_summ[li].out_bbs != NIL)
	    loop_summ[li].out_bbs = Set_dispose(loop_summ[li].out_bbs);
	num_bbs = Set_2array(loop_summ[li].loop_bbs, loop_bbs);

	for (bbi = 0; bbi < num_bbs; bbi++) {
	    bbn = bb_graph->bb_node[loop_bbs[bbi]];

	    for (succ = bbn->succ; succ != NIL; succ = succ->next) {
		succ_bbi = ((BBNode)succ->ptr)->index;
		if (Set_in(loop_summ[li].loop_bbs, succ_bbi))
		    continue;

		loop_summ[li].exit_bbs = Set_add(loop_summ[li].exit_bbs, 
						 loop_bbs[bbi]);
		loop_summ[li].out_bbs = Set_add(loop_summ[li].out_bbs,succ_bbi);
	    }
	}
    }
    free(loop_bbs);
}

static void CF_Merge_Loops()
{
    int l1, l2, l3;
    LoopSumm loop_summ;

    loop_summ = bb_graph->loop_summ;

    for (l1 = 0; l1 < bb_graph->num_loops; l1++) {
	for (l2 = l1+1; l2 < bb_graph->num_loops; l2++) {
	    if (loop_summ[l1].header_bb != loop_summ[l2].header_bb) 
		continue;

	    assert(loop_summ[l1].loop_type == LT_IMPL_LOOP ||
		   loop_summ[l2].loop_type == LT_IMPL_LOOP); 

	    /* Keep structured loop type when present */
	    if (loop_summ[l1].loop_type == LT_IMPL_LOOP)
		loop_summ[l1].loop_type = loop_summ[l2].loop_type;

	    loop_summ[l1].loop_bbs = Set_union_acc(loop_summ[l1].loop_bbs, 
						loop_summ[l2].loop_bbs);

	    loop_summ[l1].back_edge_bbs = 
				    Set_union_acc(loop_summ[l1].back_edge_bbs,
						  loop_summ[l2].back_edge_bbs);

	    for (l3 = l2; l3 < bb_graph->num_loops - 1; l3++) {
		loop_summ[l3] = loop_summ[l3+1];
	    }
	    bb_graph->num_loops--;
	}
    }
}

static void CF_Verify_Header_Dominance()
{
    LoopSumm loop_summ;
    int *loop_bbs, num_bbs, bbi, li;

    loop_summ = bb_graph->loop_summ;

    loop_bbs = (int *) malloc(bb_graph->num_nodes * sizeof(int));
    for (li = 0; li < bb_graph->num_loops; li++) {
	num_bbs = Set_2array(loop_summ[li].loop_bbs, loop_bbs);

	for (bbi = 0; bbi < num_bbs; bbi++) {
	    if (!Dominates(bb_graph->bb_node[loop_summ[li].header_bb],
	     		   bb_graph->bb_node[loop_bbs[bbi]])) {

		Punt("Side entrances encountered in loop", 
		     loop_summ[li].pcode_hdr);
	    }
	}
    }
    free(loop_bbs);
}

static void CF_Find_Loop_Nesting_Level()
{
    LoopSumm loop_summ;
    int l1, l2;

    loop_summ = bb_graph->loop_summ;

    for (l1 = 0; l1 < bb_graph->num_loops; l1++) {
	loop_summ[l1].nesting_level = 1;
    }
    for (l1 = 0; l1 < bb_graph->num_loops; l1++) {
	for (l2 = 0; l2 < bb_graph->num_loops; l2++) {

	    if (l1 == l2) continue;

	    if (Set_subtract_empty(loop_summ[l2].loop_bbs, 
				    loop_summ[l1].loop_bbs)) {
		loop_summ[l2].nesting_level += 1;
		loop_summ[l1].nested_loops = 
					Set_add(loop_summ[l1].nested_loops, l2);
	    }
	}
    }
}


/*
 * Generate loop summary information for ALL loops in a function.
 */
static void CF_Loop_Summ()
{
    int bbi, li;
    Lptr succ;
    BBNode be_head, be_tail; /* backedge head and tail basic blocks */
    LoopSumm loop_summ;

    /* Find out maximum number of loops in function */
    bb_graph->num_loops = 0;
    for (bbi = 0; bbi < bb_graph->num_nodes; bbi++) {
        be_head = bb_graph->bb_node[bbi];

        for (succ = be_head->succ; succ != NIL; succ = succ->next) {
            be_tail = (BBNode) succ->ptr;

            if (Dominates(be_tail, be_head)) bb_graph->num_loops++;
	}
    }

    loop_summ = bb_graph->loop_summ = 
		    (LoopSumm) malloc(bb_graph->num_loops * sizeof(_LoopSumm));

    /* Initialize loop summaries for all loops */
    li = 0;
    for (bbi = 0; bbi < bb_graph->num_nodes; bbi++) {
        be_head = bb_graph->bb_node[bbi];

        for (succ = be_head->succ; succ != NIL; succ = succ->next) {
            be_tail = (BBNode) succ->ptr;

            if (Dominates(be_tail, be_head)) {
		CF_Set_Pcode_Hdr_And_Loop_Type(&loop_summ[li], be_head,be_tail);
		loop_summ[li].header_bb = be_tail->index;
		loop_summ[li].nesting_level = 0;
		loop_summ[li].loop_bbs = NIL;
		loop_summ[li].back_edge_bbs = Set_add(NIL, be_head->index);
		loop_summ[li].exit_bbs = NIL;
		loop_summ[li].out_bbs = NIL;
		loop_summ[li].nested_loops = NIL;
		CF_Find_BBs_In_Loop(&loop_summ[li]);
		li++;
	    }
	}
    }

    /* calculate the loop summary info */
    CF_Find_Exit_Blocks_In_Loops();
    CF_Merge_Loops();
    CF_Find_Exit_Blocks_In_Loops();
    CF_Verify_Header_Dominance();
    CF_Find_Loop_Nesting_Level();

    bb_graph->has_loops = TRUE;
}

/*
 * Check to see if function has loop summary information calculated.
 * Return TRUE if loop summary info present, FALSE otherwise.
 */

bool CF_Function_Has_Loop_Summ(func)
FuncDcl func;
{
    if (func->flow == NIL || func->flow->flow_graph == NIL)
        Punt("control flow graph not available for function", NIL);
    flow_graph = func->flow->flow_graph;

    if (!flow_graph->has_bbs) return FALSE;
    bb_graph = flow_graph->bb_graph;

    return bb_graph->has_loops;
}


/*
 * Dispose of Loop Summary information for ALL loops in function.
 */

void CF_Dispose_Loop_Summ(func)
FuncDcl func;
{
    assert(func != NIL);
    flow_graph = func->flow->flow_graph;
    assert(flow_graph != NIL && flow_graph->has_bbs);
    bb_graph = flow_graph->bb_graph;
    assert(bb_graph != NIL && bb_graph->has_loops);

    cfree(bb_graph->loop_summ);
    bb_graph->loop_summ = NIL;
    bb_graph->has_loops = FALSE;
}


/* 
 * Calculate Loop Summary information for ALL loops in function.
 */

void CF_Build_Loop_Summ_Function(func)
FuncDcl func;
{
    if (debug_yes || verbose_yes) {
	fprintf(Flog, "..Loop Summary Analysis beginning on fn (%s)\n",
		func->name);
    }

    if (func->flow == NIL || func->flow->flow_graph == NIL) 
	Punt("control flow graph not available for function", NIL);
    flow_graph = func->flow->flow_graph;

    if (!flow_graph->has_bbs) CF_Build_BBG_Function(func);
    bb_graph = flow_graph->bb_graph;
    if (!bb_graph->has_doms) CF_Build_BB_Dominators_Function(func);
    if (bb_graph->has_loops) CF_Dispose_Loop_Summ(func);

    CF_Loop_Summ();

    if (debug_yes || verbose_yes) {
	fprintf(Flog, "..Loop Summary Analysis complete for fn (%s)\n",
		func->name);
    }
    if (debug_yes) {
	fprintf(Flog, "....Number of Loops Analyzed: %d\n", 
		bb_graph->num_loops);
    }
}
