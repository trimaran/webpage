/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.30  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 14, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	gen_pcode.c
 *	Author: Krishna Subramanian  and Wen-mei Hwu
 *	Code Modified from code written by Nancy Warter
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <Pcode/struct.h>
#include <Pcode/parms.h>
#include <Pcode/pcode.h>
#include <Pcode/gen_pcode.h>
#include <Pcode/print_pcode.h>
#include <Pcode/cast.h>

static int do_output = 1;
#define OUTPUT		do_output
#define DO_OUTPUT(x)	(do_output = x)
/* TLJ 2/25/96 - Change this to check level of include file nesting */
#define BLOCK_OUTPUT	(include_nesting != 0)
#if 0
#define BLOCK_OUTPUT	(do_output == 0)
#endif

static FILE *F = NULL;  /* THIS MUST REMAIN STATIC.  DO NOT MAKE IT VISIBLE
			    TO OTHER SOURCE FILES.  - GEH */

static int last_stmt_return;
static int last_stmt_break;
static int in_case;
static int in_default;
static int scope_count = 1;
static int in_switch;
static int default_yes;
static int pretty_print = 0;



/* EXPORT FUNCTION :
 *	Gen_PCODE_LinePos(F, n, file) int n; char *file;
 *	Gen_PCODE_Struct(F, st) Struct st;
 *	Gen_PCODE_Union(F, un) Union un;
 *	Gen_PCODE_Enum(F, en) Enum en;
 *	Gen_PCODE_Var(F, var) VarDcl var;
 *	Gen_PCODE_Func(F, fn) FuncDcl fn;
 *	BCC - 5/26/95
 *	Gen_PCODE_Include(F, file) char *file;
 */
/*========================================================================*/

/*========================================================================*/

/* forward decls */
static GenExprList();
static GenExpr();
static GenDoStmtHead();
static GenDoPStmt();
static GenStmts();
static GenPragma();
static GenExprPragma();
static GenFunctPrmDecl();
static GenLocalDecls();
static GenLocalDataDcl();
static GenExprProfile();  /* LCW */


/* Debugging Functions */

static GEN_PCODE_SUBPROC_ENTER(mesg,pos)
     char *mesg, *pos;
{
    if (DEBUG_GEN_PCODE) {
      if (pos != 0)
	fprintf(Flog, "..Entering: Gen%s for %s \n",mesg,pos);
      else
	fprintf(Flog,"..Entering: Gen%s \n",mesg);
    }
}

static GEN_PCODE_SUBPROC_EXIT(mesg,pos)
     char *mesg,*pos;
{
    if (DEBUG_GEN_PCODE) {
      if (pos != 0)
	fprintf(Flog, "..Exiting: Gen%s for %s \n",mesg,pos);
      else
	fprintf(Flog,"..Exiting: Gen%s \n",mesg);
    }
}

/* Verbose Output */

static GEN_PCODE_PROC_ENTER(mesg,pos)
     char *mesg, *pos;
{
  
    if (!DEMO_OUTPUT) {
      if (debug_yes || verbose_yes) {
	if (pos != 0) 
	  fprintf(Flog, "..Entering: Gen%s for %s \n",mesg,pos);
	else
	  fprintf(Flog,"..Entering: Gen%s \n",mesg);    
      }
    }
}

static GEN_PCODE_PROC_EXIT(mesg,pos)
     char *mesg,*pos;
{
    if (!DEMO_OUTPUT) {
      if (debug_yes || verbose_yes){
	if (pos != 0) 
	  fprintf(Flog, "..Exiting: Gen%s for %s \n",mesg,pos);
	else
	  fprintf(Flog,"..Exiting: Gen%s \n", mesg);
      }
    }
}


static Punt(mesg)
     char *mesg;
{
  fprintf(Ferr, "#gen_pcode: %s\n", mesg);
  exit(-1);
}
/*========================================================================*/

/* print type information. */

/******************************************************************************
  GenType():
  Write out a Pcode $TcSpec nonterm.
  
  Pcode grammar: $TcSpec =
  CONST                |
  VOLATILE             |
  AUTO                 |
  STATIC               |
  EXTERN               |
  REGISTER             |
  (TYPEDEF $TypeID?)   |
  (TYPEID $TypeID)     |
  CHAR                 |
  FLOAT                |
  DOUBLE               |
  INT                  |
  SHORT                |
  LONG                 |
  SIGNED               |
  UNSIGNED             |
  VOID                 |
  SYNC                 |
  $EnumSpec            |
  $StructSpec
  
  Parameters: TypeSpec: A pointer to a type specifier
  TypeID: A type identifier (for typedefs only)
  
  Returns: Nothing
  
  Calls:  pcode_VarID()
  pcode_EnumSpec()
  extern put_token()
  ******************************************************************************/
static GenType(type)
     Type type;
{
  int t;
  GEN_PCODE_SUBPROC_ENTER("TypeSpec",0);
  t = type->type;
  if (t==0) {
    Punt("ILLEGAL TYPE SPECIFICATION: NULL");
    return;
  }
  /* storage class */
  if (t & TY_REGISTER) put_token(F, IDENT_TOKEN, REGISTER_PCODE); 
/* BCC - since all static variables have been renamed, don't print static
  if (t & TY_STATIC) put_token(F, IDENT_TOKEN, STATIC_PCODE); - 6/13/95 */
  if (t & TY_EXTERN) put_token(F, IDENT_TOKEN, EXTERN_PCODE); 
  if (t & TY_AUTO)  put_token(F, IDENT_TOKEN, AUTO_PCODE);
  /* qualifier */
  if (t & TY_CONST)  put_token(F, IDENT_TOKEN, CONST_PCODE); 
  if (t & TY_VOLATILE)  put_token(F, IDENT_TOKEN, VOLATILE_PCODE); 
  /* at present, won't gen noalias from pcode */
  /*
    if (t & TY_NOALIAS) put_token(F, IDENT_TOKEN, " NO ALIAS "); 
    */
  if (t & TY_SYNC) put_token(F, IDENT_TOKEN, SYNC_PCODE); 
  /* type */ 
  if (t & TY_SIGNED)  put_token(F, IDENT_TOKEN, SIGNED_PCODE); 
  if (t & TY_UNSIGNED)  put_token(F, IDENT_TOKEN, UNSIGNED_PCODE); 
  if (t & TY_VOID)   put_token(F, IDENT_TOKEN, VOID_PCODE);
  if (t & TY_SHORT) put_token(F, IDENT_TOKEN, SHORT_PCODE); 
  if (t & TY_LONG) put_token(F, IDENT_TOKEN, LONG_PCODE); 
  if (t & TY_CHAR) put_token(F, IDENT_TOKEN, CHAR_PCODE); 
  if (t & TY_INT) put_token(F, IDENT_TOKEN, INT_PCODE); 
  if (t & TY_FLOAT)  put_token(F, IDENT_TOKEN, FLOAT_PCODE); 
  if (t & TY_DOUBLE) put_token(F, IDENT_TOKEN, DOUBLE_PCODE); 
  if (t & TY_VARARG) put_token(F, IDENT_TOKEN, VARARG_PCODE); /* BCC 1/24/96 */
  if (t & TY_STRUCT) {
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, TY_STRUCT_PCODE);
    /* BCC - 7/26/96
     * if update_st_un_name is TRUE, use the newest name. Useful for local vars
     */
    if (update_st_un_name == 1) {
      int i;

      for (i=0; i<max_struct_union_pool; i++) {
        if ( !strcmp(type->struct_name, StructUnion_Pool[i].name) ||
	    (!strncmp(type->struct_name, StructUnion_Pool[i].name, 
		     strlen(StructUnion_Pool[i].name)) &&
	     !strncmp(type->struct_name+strlen(StructUnion_Pool[i].name), 
		     "_impact", 7)) )
	break;
      }

      /* this struct is not in the renaming pool */
      if ( i == max_struct_union_pool )
        put_token(F, IDENT_TOKEN, type->struct_name);
      else
        put_token(F, IDENT_TOKEN, StructUnion_Pool[i].new_name);
    }
    else
	put_token(F, IDENT_TOKEN, type->struct_name);
    put_token(F, RIGHT_PAREN_TOKEN, NULL); 
  } 
  if (t & TY_UNION) {
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, TY_UNION_PCODE); 
    /* BCC - 10/30/96
     * if update_st_un_name is TRUE, use the newest name. Useful for local vars
     */
    if (update_st_un_name == 1) {
      int i;

      for (i=0; i<max_struct_union_pool; i++) {
        if ( !strcmp(type->struct_name, StructUnion_Pool[i].name) ||
	    (!strncmp(type->struct_name, StructUnion_Pool[i].name, 
		     strlen(StructUnion_Pool[i].name)) &&
	     !strncmp(type->struct_name+strlen(StructUnion_Pool[i].name), 
		     "_impact", 7)) )
	break;
      }

      /* this struct is not in the renaming pool */
      if ( i == max_struct_union_pool )
        put_token(F, IDENT_TOKEN, type->struct_name);
      else
        put_token(F, IDENT_TOKEN, StructUnion_Pool[i].new_name);
    }
    else
	put_token(F, IDENT_TOKEN, type->struct_name);
    put_token(F, RIGHT_PAREN_TOKEN, NULL); 
  } 
/* BCC - if doint spliting, treat enum as int - 7/3/95 */
  if (t & TY_ENUM) { 
    if (split == 0) {
      put_token(F, LEFT_PAREN_TOKEN, NULL);
      put_token(F, IDENT_TOKEN, TY_ENUM_PCODE);
      put_token(F, IDENT_TOKEN, type->struct_name); 
      put_token(F, RIGHT_PAREN_TOKEN, NULL); 
    }
    else put_token(F, IDENT_TOKEN, INT_PCODE);
  } 
  GEN_PCODE_SUBPROC_EXIT("TypeSpec",0);
}

/* BCC - 1/21/96 */
static GenDcltr(Dcltr, int);

/* BCC - 1/21/96 */
static GenParamTypeList(param)
     Param param;
{
  while (param) {
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, PROTOTYPE_DECL_PCODE);
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    GenType(param->type);
    GenDcltr(param->type->dcltr, 0);
    put_token(F, RIGHT_PAREN_TOKEN, NULL); 
    put_token(F, RIGHT_PAREN_TOKEN, NULL); 
    param = param->next;
  }
}

/* NOTE:  Don't know if we need this yet SK 
 *  type:
 *  0:  no restrictions
 *  1:  don't print function declarator "F"
 */
static GenDcltr(dcltr, type)
     Dcltr dcltr;
     int type;
{
  GEN_PCODE_SUBPROC_ENTER("Dcltr",0);
  
  while (dcltr!=0) {
    switch (dcltr->method) {
    case D_ARRY:
      if (dcltr->index != 0) put_token(F, LEFT_PAREN_TOKEN, NULL);

      put_token(F, IDENT_TOKEN, ARRAY_PCODE);
      if (dcltr->index != 0) GenExprList(dcltr->index);

      if (dcltr->index != 0) put_token(F, RIGHT_PAREN_TOKEN, NULL);
      break;

    case D_PTR:
      if (dcltr->qualifier != 0) put_token(F, LEFT_PAREN_TOKEN, NULL);

      put_token(F, IDENT_TOKEN, POINTER_PCODE);
      if (dcltr->qualifier & DQ_CONST) put_token(F, IDENT_TOKEN, CONST_PCODE);
      if (dcltr->qualifier & DQ_VOLATILE) 
				      put_token(F, IDENT_TOKEN, VOLATILE_PCODE);

      if (dcltr->qualifier != 0) put_token(F, RIGHT_PAREN_TOKEN, NULL);
      break;

    case D_FUNC:
      if(type != 1) {
	/* BCC - modify the format for F to include parameter types - 1/21/96 */
	put_token(F, LEFT_PAREN_TOKEN, NULL);
	put_token(F, IDENT_TOKEN, FUNCTION_PCODE);

        if (dcltr->qualifier & DQ_CDECL) 
	  put_token(F, IDENT_TOKEN, CDECL_PCODE);
        if (dcltr->qualifier & DQ_STDCALL) 
	  put_token(F, IDENT_TOKEN, STDCALL_PCODE);
        if (dcltr->qualifier & DQ_FASTCALL) 
	  put_token(F, IDENT_TOKEN, FASTCALL_PCODE);

	if (dcltr->param) {
	  put_token(F, LEFT_PAREN_TOKEN, NULL);
	  if (dcltr->param != 0) {
	    GenParamTypeList(dcltr->param);
	  }
	  put_token(F, RIGHT_PAREN_TOKEN, NULL);
	}
	put_token(F, RIGHT_PAREN_TOKEN, NULL);

      }
      break;

    default:
      Punt("illegal dcltr");
    }
    dcltr = dcltr->next;
  }
  GEN_PCODE_SUBPROC_EXIT("Dcltr",0);
  
}
/*========================================================================*/

/******************************************************************************
  GenVarId():
  Write out a Pcode $VarID nonterm.
  
  Pcode grammar: $VarID = a standard C identifier
  
  Parameters: VarID: An identifier
  
  Returns: Nothing
  
  Calls:  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenVarId(temp)
     char *temp;
{
  GEN_PCODE_SUBPROC_ENTER("VarID", temp);
  
  put_token(F, IDENT_TOKEN, temp);
  
  GEN_PCODE_SUBPROC_EXIT("VarID",temp);
}



/******************************************************************************
  GenExprList():
  Write out a Pcode $ExprList nonterm.
  
  Pcode grammar: $ExprList =
  $Expr+
  
  Parameters: ExprList: A pointer to a list of expressions
  
  Returns: Nothing
  
  Calls:  GenExpr()
  Punt
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/


static GenExprList(exprlist)
     Expr exprlist;
{
  GEN_PCODE_SUBPROC_ENTER("ExprList",0);
  
  if (exprlist == NULL) {
    Punt("GenExprList: Expr missing");
  }
  
  else while (exprlist != NULL) {
    GenExpr(exprlist);
    exprlist = exprlist->next;
  }
  
  GEN_PCODE_SUBPROC_EXIT("ExprList",0);
}

/******************************************************************************
  GenIntVal():
  Write out a Pcode $IntVal nonterm.

  Pcode grammar: $IntVal = a standard C integer constant

  Parameters: IntVal: An integer number

  Returns: Nothing

  Calls:  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
 ******************************************************************************/

static GenIntVal(IntVal)
     long IntVal;
{
  char ident[1024];

  sprintf(ident, "%d", IntVal);
  GEN_PCODE_SUBPROC_ENTER("IntVal",ident);
  put_token(F, IDENT_TOKEN, ident);

  GEN_PCODE_SUBPROC_EXIT("IntVal",ident);
}

/******************************************************************************
  GenVarExpr():
  Write out a Pcode variable expression.
  
  Pcode grammar: $Expr =
  (VAR $VarID)
  
  Parameters: VarID: A variable identifier
  
  Returns: Nothing
  
  Calls:  GenVarId()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenVarExpr(expr)
	Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("VarExpr",expr->value.var_name);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  /* BCC - if it's doing spliting, generate the corresponding int - 7/1/95 */
  if (expr->enum_flag && split == 1) 
    {
      EnumField enf;
      enf = enum_expr_to_enum_field(expr);
      assert(enf != NIL && enf->value != NIL);
      assert (enf->value->opcode == OP_int);
      put_token(F, IDENT_TOKEN, INT_EXPR_PCODE);
      GenIntVal(enf->value->value.scalar);
    }
  /* GEH - this code is incorrect.  ENUM expr opcode used in Hcode, not Pcode */
  /*  else
      put_token(F, IDENT_TOKEN, ENUM_EXPR_PCODE);
  }
  */
  else
    put_token(F, IDENT_TOKEN, VAR_EXPR_PCODE);
  
  /* BCC - if it's a var or a enum_field but not spliting - 7/1/95 */
  if ( !(expr->enum_flag && split) )
    GenVarId(expr->value.var_name);

  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("VarExpr",expr->value.var_name);
}


/******************************************************************************
  GenIntExpr():
  Write out a Pcode integer number expression.
  
  Pcode grammar: $Expr =
  (INT $IntVal)
  
  Parameters: IntVal: An integer value
  
  Returns: Nothing
  
  Calls:  GenIntVal()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenIntExpr(expr)
	Expr expr;
{
  char ident[1024];
  Pragma prag;
  
  sprintf(ident, "%d", expr->value.scalar);
  
  GEN_PCODE_SUBPROC_ENTER("IntExpr",ident );
  
  /* BCC - we need to represent (unsigned int) -1 - 10/31/96 */
  if (expr->type && (expr->type->type & TY_UNSIGNED)) {
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, CAST_EXPR_PCODE);
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, UNSIGNED_PCODE);
    put_token(F, IDENT_TOKEN, INT_PCODE);
    put_token(F, RIGHT_PAREN_TOKEN, NULL);
  }
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, INT_EXPR_PCODE);
  
  GenIntVal(expr->value.scalar);

  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);

  /* BCC - we need to represent (unsigned int) -1 - 10/31/96 */
  if (expr->type && (expr->type->type & TY_UNSIGNED)) 
      put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("IntExpr", ident);
  
}

/******************************************************************************
  GenRealVal():
  Write out a Pcode $RealVal nonterm.
  
  Pcode grammar: $RealVal = a standard C floating-point constant
  
  Parameters: RealVal: A real number
  
  Returns: Nothing
  
  Calls:  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenRealVal(RealVal)
	double RealVal;
{
  char ident[1024];

  /* GEH - changed FP format to match rest of compiler - 4/27/95 */
  sprintf(ident, "%1.16e", RealVal);
  GEN_PCODE_SUBPROC_ENTER("RealVal",ident);
  put_token(F, IDENT_TOKEN, ident);
  GEN_PCODE_SUBPROC_EXIT("RealVal",ident);
}


/******************************************************************************
  GenRealExpr():
  Write out a Pcode real number expression.
  
  Pcode grammar: $Expr =
  (REAL $RealVal)
  
  Parameters: RealVal: A real value
  
  Returns: Nothing
  
  Calls:  GenRealVal()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenRealExpr(expr)
	Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("RealExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, REAL_EXPR_PCODE);
  
  GenRealVal(expr->value.real);

  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("RealExpr",0);
}

/******************************************************************************
  GenFloatExpr():
  Write out a Pcode real number expression.
  
  Pcode grammar: $Expr =
  (FLOAT $RealVal)
  
  Parameters: RealVal: A real value
  
  Returns: Nothing
  
  Calls:  GenFloatVal()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenFloatExpr(expr)
	Expr expr;
{
  Pragma prag;
  char number[80];

  GEN_PCODE_SUBPROC_ENTER("FloatExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, FLOAT_EXPR_PCODE);
  
#if 0
  GenRealVal(expr->value.real);
#endif
  
  /* BCC - use 8 digits for float constants - 8/22/96 */
  sprintf(number, "%1.8e", (float)expr->value.real);
  put_token(F, IDENT_TOKEN, number);

  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("FloatExpr",0);
}

/******************************************************************************
  GenDoubleExpr():
  Write out a Pcode real number expression.
  
  Pcode grammar: $Expr =
  (DOUBLE $RealVal)
  
  Parameters: RealVal: A real value
  
  Returns: Nothing
  
  Calls:  GenDoubleVal()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenDoubleExpr(expr)
	Expr expr;
{
  Pragma prag;
  char number[80];

  GEN_PCODE_SUBPROC_ENTER("DoubleExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOUBLE_EXPR_PCODE);
  
#if 0
  GenRealVal(expr->value.real);
#endif
  
  /* BCC - use 16 digits for double constants - 8/22/96 */
  sprintf(number, "%1.16e", expr->value.real);
  put_token(F, IDENT_TOKEN, number);

  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("DoubleExpr",0);
}

/******************************************************************************
  GenCharVal():
  Write out a Pcode $CharVal nonterm.
  
  Pcode grammar: $CharVal = a standard C character constant
  
  Parameters: CharVal: A character constant
  
  Returns: Nothing
  
  Calls:  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenCharVal(CharVal)
     char *CharVal;
{
  GEN_PCODE_SUBPROC_ENTER("CharVal",CharVal);
  
  if ((CharVal[0] != '\'') ||
      (CharVal[strlen(CharVal) - 1] != '\'')) {
    Punt("GenCharVal: missing single quote");
  }
  else put_token(F, IDENT_TOKEN, CharVal);
  
  GEN_PCODE_SUBPROC_EXIT("CharVal",CharVal);
}


/******************************************************************************
  GenCharExpr():
  Write out a Pcode character constant expression.
  
  Pcode grammar: $Expr =
  (CHAR $CharVal)
  
  Parameters: CharVal: A character constant
  
  Returns: Nothing
  
  Calls:  GenCharVal()
  GenExprPragma()
  extern put_token()
  GENPCODEDEBUG_ENTER()
  GENPCODEDEBUG_EXIT()
  ******************************************************************************/

static GenCharExpr(expr)
	Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("CharExpr",0);
  
  /* BCC - we need to represent (unsigned char) -1 - 10/31/96 */
  if (expr->type && (expr->type->type & TY_UNSIGNED)) {
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, CAST_EXPR_PCODE);
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, UNSIGNED_PCODE);
    put_token(F, IDENT_TOKEN, INT_PCODE);
    put_token(F, RIGHT_PAREN_TOKEN, NULL);
  }

  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, CHAR_EXPR_PCODE);
  
  GenCharVal(expr->value.string);

  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  /* BCC - we need to represent (unsigned char) -1 - 10/31/96 */
  if (expr->type && (expr->type->type & TY_UNSIGNED)) 
      put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("CharExpr",0);
}


/******************************************************************************
  GenString():
  Write out a Pcode $String nonterm.
  
  Pcode grammar: $String = a standard C double-quoted string
  
  Parameters: String: A string constant
  
  Returns: Nothing
  
  Calls:  extern put_token()
  extern ERR()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenString(String)
     char *String;
{
  GEN_PCODE_SUBPROC_ENTER("String",String);
  
  if ((String[0] != '\"') ||
      (String[strlen(String) - 1] != '\"')) {
    fprintf(Ferr, "#gen_pcode: GenString: string %s\n", String);
    Punt("GenString: missing double quotes");
  }
  else put_token(F, IDENT_TOKEN, String);
  
  GEN_PCODE_SUBPROC_EXIT("String",String);
}


/******************************************************************************
  GenStringExpr():
  Write out a Pcode string constant expression.
  
  Pcode grammar: $Expr =
  (STRING $String)
  
  Parameters: String: A string constant
  
  Returns: Nothing
  
  Calls:  GenString()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenStringExpr(expr)
	Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("StringExpr",expr->value.string);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, STRING_EXPR_PCODE);
  
  GenString(expr->value.string);

  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("StringExpr",expr->value.string);
}

/******************************************************************************
  GenCastExpr():
  Write out a Pcode cast expression.
  
  Pcode grammar: $Expr =
  (CAST $DeclSpec $Expr)
  
  Parameters: CastExpr: A pointer to the cast operands
  
  Returns: Nothing
  
  Calls:  GenDeclSpec()
  GenExpr()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenCastExpr(expr)
     Expr expr;
{
  Type ptr;
  Pragma prag;
  GEN_PCODE_SUBPROC_ENTER("CastExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, CAST_EXPR_PCODE);
  
  /* DECLSPEC */
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  ptr = expr->type;
  if (ptr == 0){
    fprintf(Ferr,"DeclSpec:TcSpec missing for castexpr \n");        
    return;
  }
  GenType(ptr);
  
  GenDcltr(expr->type->dcltr, 0);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);        
  
  
  GenExpr(ExprOperand(1, expr));

  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("CastExpr",0);
}



/******************************************************************************
  GenTypeSizeExpr():
  Write out a Pcode type size expression.
  
  Pcode grammar: $Expr =
  (TYPESIZE $DeclSpec)
  
  Parameters: TypeSizeExpr: A pointer to the type size operands
  
  Returns: Nothing
  
  Calls:  GenDeclSpec()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenTypeSizeExpr(expr)
     Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("TypeSizeExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, TYPE_SIZE_EXPR_PCODE);
  
  /* Decl Spec */
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (expr->type == 0){
    fprintf(Ferr,"DeclSpec:TcSpec missing for TypesizeExpr \n");
    return;
  }
  
  GenType(expr->value.type);
  GenDcltr(expr->value.type->dcltr, 0);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("TypeSizeExpr",0);
}



/******************************************************************************
  GenExprSizeExpr():
  Write out a Pcode expression size expression.
  
  Pcode grammar: $Expr =
  (EXPRSIZE $Expr)
  
  Parameters: ExprSizeExpr: A pointer to the expression size operand
  
  Returns: Nothing
  
  Calls:  GenExpr()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenExprSizeExpr(expr)
     Expr expr;
{
  Expr arg;
  Pragma prag;
  
  GEN_PCODE_SUBPROC_ENTER("ExprSizeExpr",0);
  arg = ExprOperand(1, expr);
  if (arg==0) Punt("GenExpr : sizeof missing argument");
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, EXPR_SIZE_EXPR_PCODE);
  GenExpr(arg);
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("ExprSizeExpr",0);
}


/******************************************************************************
  GenQuestExpr():
  Write out a Pcode conditional expression.
  
  Pcode grammar: $Expr =
  (QUEST $Expr ($ExprList) $Expr)
  
  Parameters: QuestExpr: A pointer to the conditional expression operands
  
  Returns: Nothing
  
  Calls:  GenExpr()
  GenExprList()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenQuestExpr(expr)
     Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("QuestExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, QUEST_EXPR_PCODE);
  
  GenExpr(ExprOperand(1, expr));
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenExprList(ExprOperand(2, expr));
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GenExpr(ExprOperand(3, expr));
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("QuestExpr",0);
}


/******************************************************************************
  GenCallExpr():
  Write out a Pcode function call expression.
  
  Pcode grammar: $Expr =
  (CALL $Expr ($ExprList?))
  
  Parameters: CallExpr: A pointer to the function call operands
  
  Returns: Nothing
  
  Calls:  GenExpr()
  GenExprList()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenCallExpr(expr)
     Expr expr;
{
  Expr arg;
  Pragma prag;
  Expr op1;
  
  GEN_PCODE_SUBPROC_ENTER("CallExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, CALL_EXPR_PCODE);
  
  /* 
   * BCC - added OP_indr before function pointers. Without this PIP or Pinline
   * could fail. - 4/18/96 
   */
  if (IsPointerType(expr->operands->type)) {
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, INDR_EXPR_PCODE); 
    GenExpr(ExprOperand(1, expr));
    put_token(F, RIGHT_PAREN_TOKEN, NULL);
  }
  else
    GenExpr(ExprOperand(1, expr));
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  arg = ExprOperand(2, expr);
  if (arg != NULL) GenExprList(arg);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("CallExpr",0);
}


/******************************************************************************
  GenIndexExpr():
  Write out a Pcode index expression.
  
  Pcode grammar: $Expr =
  (INDEX $Expr ($ExprList))
  
  Parameters: IndexExpr: A pointer to the index operands
  
  Returns: Nothing
  
  Calls:  GenExpr()
  GenExprList()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenIndexExpr(expr)
     Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("IndexExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, INDEX_EXPR_PCODE);
  
  GenExpr(ExprOperand(1, expr));
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenExprList(ExprOperand(2, expr));
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("IndexExpr",0);
}

/******************************************************************************
  GenDualOpExpr():
  Write out a Pcode dual operand expression.
  
  Pcode grammar: $Expr =
  (ASSIGN $Expr $Expr)                   |
  (A_ADD $Expr $Expr)                    |
  (A_SUB $Expr $Expr)                    |
  (A_MUL $Expr $Expr)                    |
  (A_DIV $Expr $Expr)                    |
  (A_MOD $Expr $Expr)                    |
  (A_RSHFT $Expr $Expr)                  |
  (A_LSHFT $Expr $Expr)                  |
  (A_AND $Expr $Expr)                    |
  (A_OR $Expr $Expr)                     |
  (A_XOR $Expr $Expr)                    |
  (DISJ $Expr $Expr)                     |
  (CONJ $Expr $Expr)                     |
  (OR $Expr $Expr)                       |
  (XOR $Expr $Expr)                      |
  (AND $Expr $Expr)                      |
  (EQ $Expr $Expr)                       |
  (NE $Expr $Expr)                       |
  (LT $Expr $Expr)                       |
  (LE $Expr $Expr)                       |
  (GT $Expr $Expr)                       |
  (GE $Expr $Expr)                       |
  (RSHFT $Expr $Expr)                    |
  (LSHFT $Expr $Expr)                    |
  (ADD $Expr $Expr)                      |
  (SUB $Expr $Expr)                      |
  (MUL $Expr $Expr)                      |
  (DIV $Expr $Expr)                      |
  (MOD $Expr $Expr)                      |
  
  Parameters: DualExpr: a pointer to a pair of expressions.
  ExprTag: a tag indicating the type of expression operator
  
  Returns: Nothing
  
  Calls:  GenExpr()
  GenExprPragma()
  Punt()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenDualOpExpr(expr, opcode)
     Expr expr;
     int  opcode;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("DualOpExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  /* Generate the correct Opcode */
  switch (opcode) {
  case OP_disj : put_token(F, IDENT_TOKEN, DISJ_EXPR_PCODE); break;
  case OP_conj : put_token(F, IDENT_TOKEN, CONJ_EXPR_PCODE); break;		
  case OP_assign : put_token(F, IDENT_TOKEN, ASSIGN_EXPR_PCODE); break;
  case OP_or : put_token(F, IDENT_TOKEN, OR_EXPR_PCODE); break;		
  case OP_xor : put_token(F, IDENT_TOKEN, XOR_EXPR_PCODE); break;		
  case OP_and : put_token(F, IDENT_TOKEN, AND_EXPR_PCODE); break;		
  case OP_eq :  put_token(F, IDENT_TOKEN, EQ_EXPR_PCODE); break;		
  case OP_ne :  put_token(F, IDENT_TOKEN, NE_EXPR_PCODE); break;		
  case OP_lt :  put_token(F, IDENT_TOKEN, LT_EXPR_PCODE); break; 
  case OP_le :  put_token(F, IDENT_TOKEN, LE_EXPR_PCODE); break;	
  case OP_ge :  put_token(F, IDENT_TOKEN, GE_EXPR_PCODE); break;		
  case OP_gt :  put_token(F, IDENT_TOKEN, GT_EXPR_PCODE); break;		
  case OP_rshft : put_token(F, IDENT_TOKEN, RSHFT_EXPR_PCODE); break;	
  case OP_lshft : put_token(F, IDENT_TOKEN, LSHFT_EXPR_PCODE); break;
  case OP_add :  put_token(F, IDENT_TOKEN, ADD_EXPR_PCODE); break;		
  case OP_sub :   put_token(F, IDENT_TOKEN, SUB_EXPR_PCODE); break;
  case OP_mul : put_token(F, IDENT_TOKEN, MUL_EXPR_PCODE); break;
  case OP_div : put_token(F, IDENT_TOKEN, DIV_EXPR_PCODE); break;
  case OP_mod : put_token(F, IDENT_TOKEN, MOD_EXPR_PCODE); break;
  case OP_Aadd : put_token(F, IDENT_TOKEN, ADDR_ADD_EXPR_PCODE);break;
  case OP_Asub : put_token(F, IDENT_TOKEN, ADDR_SUB_EXPR_PCODE);break;	
  case OP_Amul : put_token(F, IDENT_TOKEN, ADDR_MUL_EXPR_PCODE);break;
  case OP_Adiv : put_token(F, IDENT_TOKEN, ADDR_DIV_EXPR_PCODE);break;	
  case OP_Amod : put_token(F, IDENT_TOKEN, ADDR_MOD_EXPR_PCODE);break;
  case OP_Arshft : put_token(F, IDENT_TOKEN, ADDR_RSHFT_EXPR_PCODE); break;
  case OP_Alshft :  put_token(F, IDENT_TOKEN, ADDR_LSHFT_EXPR_PCODE);
    break;
  case OP_Aand :  put_token(F, IDENT_TOKEN, ADDR_AND_EXPR_PCODE);break;	
  case OP_Aor : put_token(F, IDENT_TOKEN, ADDR_OR_EXPR_PCODE); break;	
  case OP_Axor : put_token(F, IDENT_TOKEN, ADDR_XOR_EXPR_PCODE);break;
    default :
      Punt("GenDualOpcode : illegal opcode");
  }
  
  
  GenExpr(ExprOperand(1, expr));
  GenExpr(ExprOperand(2, expr));
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  GEN_PCODE_SUBPROC_EXIT("DualOpExpr",0);
}


/******************************************************************************
  GenDotExpr():
  Write out a Pcode dot expression.
  
  Pcode grammar: $Expr =
  (DOT $Expr $FieldID)
  
  Parameters: DotExpr: A pointer to the dot operands
  
  Returns: Nothing
  
  Calls:  GenExpr()
  GenVarId()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenDotExpr(expr)
     Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("DotExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOT_EXPR_PCODE);
  
  GenExpr(ExprOperand(1, expr));
  
  GenVarId(expr->value.string);
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("DotExpr",0);
}


/******************************************************************************
  GenArrowExpr():
  Write out a Pcode arrow expression.
  
  Pcode grammar: $Expr =
  (ARROW $Expr $FieldID)
  
  Parameters: ArrowExpr: A pointer to the arrow operands
  
  Returns: Nothing
  
  Calls:  GenExpr()
  GenVarId()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenArrowExpr(expr)
     Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("ArrowExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, ARROW_EXPR_PCODE);
  
  GenExpr(ExprOperand(1, expr));
  
  GenVarId(expr->value.string);
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  
  GEN_PCODE_SUBPROC_EXIT("ArrowExpr",0);
}

/******************************************************************************
  GenSingleOpExpr():
  Write out a Pcode single operand expression.
  
  Pcode grammar: $Expr =
  (PREINC $Expr)                         |
  (PREDEC $Expr)                         |
  (POSTINC $Expr)                        |
  (POSTDEC $Expr)                        |
  (INDR $Expr)                           |
  (ADDR $Expr)                           |
  (NEG $Expr)                            |
  (NOT $Expr)                            |
  (INV $Expr)                            |
  
  Parameters: SingleExpr: a pointer to a single expression.
  ExprTag: a tag indicating the type of expression operator
  
  Returns: Nothing
  
  Calls:  GenExpr()
  GenExprPragma()
  extern put_token()
  extern ERR()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenSingleOpExpr(expr, opcode)
     Expr expr;
     int opcode;
     
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("SingleOpExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  switch (opcode) {
  case OP_neg : put_token(F, IDENT_TOKEN, NEG_EXPR_PCODE); break;
  case OP_not : put_token(F, IDENT_TOKEN, NOT_EXPR_PCODE); break;
  case OP_inv : put_token(F, IDENT_TOKEN, INV_EXPR_PCODE); break;
  case OP_preinc : put_token(F, IDENT_TOKEN, PRE_INC_EXPR_PCODE); break;
  case OP_predec : put_token(F, IDENT_TOKEN, PRE_DEC_EXPR_PCODE); break;
  case OP_indr : put_token(F, IDENT_TOKEN, INDR_EXPR_PCODE); break;
  case OP_addr : put_token(F, IDENT_TOKEN, ADDR_EXPR_PCODE); break;
  case OP_postinc :  put_token(F, IDENT_TOKEN, POST_INC_EXPR_PCODE);break;
  case OP_postdec :  put_token(F, IDENT_TOKEN, POST_DEC_EXPR_PCODE);break;
  default:
    Punt("GenSingleOpExpr: unknown Expr tag");
  }
  
  GenExpr(ExprOperand(1, expr));
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  GEN_PCODE_SUBPROC_EXIT("SingleOpExpr",0);
}


/******************************************************************************
  GenCompoundExpr():
  Write out a Pcode compound expression.
  
  Pcode grammar: $Expr =
  (COMPEXPR ($ExprList))
  
  Parameters: CompoundExpr: A pointer to a list of expressions
  
  Returns: Nothing
  
  Calls:  GenExprList()
  GenExprPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenCompoundExpr(expr)
     Expr expr;
{
  Pragma prag;

  GEN_PCODE_SUBPROC_ENTER("CompoundExpr",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, COMPOUND_EXPR_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenExprList(ExprOperand(1, expr));
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  /* TLJ - Add support for ExprPragma's */  
  prag = expr->pragma;
  while (prag)
  {
    GenExprPragma(prag);
    prag = prag->next;
  }

  /* LCW - generate expression profile info - 10/30/95 */
  GenExprProfile(expr->profile);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("CompoundExpr",0);
}



/* generate expression. */
/******************************************************************************
    GenExpr():
    Write out a Pcode $Expr nonterm.
    
    Pcode grammar: $Expr =
    (ASSIGN $Expr $Expr $ExprPragma*)                   |
    (A_ADD $Expr $Expr $ExprPragma*)                    |
    (A_SUB $Expr $Expr $ExprPragma*)                    |
    (A_MUL $Expr $Expr $ExprPragma*)                    |
    (A_DIV $Expr $Expr $ExprPragma*)                    |
    (A_MOD $Expr $Expr $ExprPragma*)                    |
    (A_RSHFT $Expr $Expr $ExprPragma*)                  |
    (A_LSHFT $Expr $Expr $ExprPragma*)                  |
    (A_AND $Expr $Expr $ExprPragma*)                    |
    (A_OR $Expr $Expr $ExprPragma*)                     |
    (A_XOR $Expr $Expr $ExprPragma*)                    |
    (DISJ $Expr $Expr $ExprPragma*)                     |
    (CONJ $Expr $Expr $ExprPragma*)                     |
    (OR $Expr $Expr $ExprPragma*)                       |
    (XOR $Expr $Expr $ExprPragma*)                      |
    (AND $Expr $Expr $ExprPragma*)                      |
    (EQ $Expr $Expr $ExprPragma*)                       |
    (NE $Expr $Expr $ExprPragma*)                       |
    (LT $Expr $Expr $ExprPragma*)                       |
    (LE $Expr $Expr $ExprPragma*)                       |
    (GT $Expr $Expr $ExprPragma*)                       |
    (GE $Expr $Expr $ExprPragma*)                       |
    (RSHFT $Expr $Expr $ExprPragma*)                    |
    (LSHFT $Expr $Expr $ExprPragma*)                    |
    (ADD $Expr $Expr $ExprPragma*)                      |
    (SUB $Expr $Expr $ExprPragma*)                      |
    (MUL $Expr $Expr $ExprPragma*)                      |
    (DIV $Expr $Expr $ExprPragma*)                      |
    (MOD $Expr $Expr $ExprPragma*)                      |
    (PREINC $Expr $ExprPragma*)                         |
    (PREDEC $Expr $ExprPragma*)                         |
    (POSTINC $Expr $ExprPragma*)                        |
    (POSTDEC $Expr $ExprPragma*)                        |
    (INDR $Expr $ExprPragma*)                           |
    (ADDR $Expr $ExprPragma*)                           |
    (NEG $Expr $ExprPragma*)                            |
    (NOT $Expr $ExprPragma*)                            |
    (INV $Expr $ExprPragma*)                            |
    (VAR $VarID $ExprPragma*)                           |
    (INT $IntVal $ExprPragma*)                          |
    (REAL $RealVal $ExprPragma*)                        |
    (FLOAT $RealVal $ExprPragma*)                       |     
    (DOUBLE $RealVal $ExprPragma*)                      |    
    (CHAR $CharVal $ExprPragma*)                        |
    (STRING $String $ExprPragma*)                       |
    (INDEX $Expr ($ExprList) $ExprPragma*)              |
    (CALL $Expr ($ExprList?) $ExprPragma*)              |
    (DOT $Expr $FieldID $ExprPragma*)                   |
    (ARROW $Expr $FieldID $ExprPragma*)                 |
    (COMPEXPR ($ExprList) $ExprPragma*)                 |
    (TYPESIZE $DeclSpec $ExprPragma*)                   |
    (EXPRSIZE $Expr $ExprPragma*)                       |
    (CAST $DeclSpec $Expr $ExprPragma*)                 |
    (QUEST $Expr ($ExprList) $Expr $ExprPragma*)        |
    (ERROR $ExprPragma*)

    Parameters: Expr: A pointer to an expression
    
    Returns: Nothing
    
    Calls: 
    GenDualOpExpr()
    GenSingleOpExpr()
    GenVarExpr()
    GenIntExpr()
    GenRealExpr()
    GenCharExpr()
    GenStringExpr()
    GenIndexExpr()
    GenCallExpr()
    GenDotExpr()
    GenArrowExpr()
    GenCompoundExpr()
    GenTypeSizeExpr()
    GenExprSizeExpr()
    GenCastExpr()
    GenQuestExpr()
    GenExprPragma()
    Punt()
    GEN_PCODE_SUBPROC_ENTER()
    GEN_PCODE_SUBPROC_EXIT()
******************************************************************************/
  
  
  

static GenExpr(expr)
Expr expr;
{
  int opcode;
  Pragma prag;
  Expr op;
  
  GEN_PCODE_SUBPROC_ENTER("Expr", 0);
  if (expr==0) Punt("GenExpr : nil expr");
  /*
   *	print expressions.
   */
  switch (opcode=expr->opcode) {
  case OP_var :
    GenVarExpr(expr); break;
  case OP_int :
    GenIntExpr(expr); break;
  case OP_real :
    GenRealExpr(expr); break;
  /* BCC - new - 8/3/96 */
  case OP_float :
    GenFloatExpr(expr); break;
  /* BCC - new - 8/3/96 */
  case OP_double :
    GenDoubleExpr(expr); break;
  case OP_char :
    GenCharExpr(expr); break;
  case OP_string :
    GenStringExpr(expr); break;
  case OP_cast :
    GenCastExpr(expr); break;
  case OP_type_size :
    GenTypeSizeExpr(expr); break;
  case OP_expr_size :
    GenExprSizeExpr(expr); break;
  case OP_quest :
    GenQuestExpr(expr); break;
  case OP_call :
    GenCallExpr(expr); num_total_func_call++; break;
  case OP_index :
    GenIndexExpr(expr); break;
    /* binary */
  case OP_disj :
  case OP_conj :
  case OP_or :
  case OP_xor :
  case OP_and :
  case OP_eq :
  case OP_ne :
  case OP_lt :
  case OP_le :
  case OP_ge :
  case OP_gt :
  case OP_rshft :
  case OP_lshft :
  case OP_add :
  case OP_sub :
  case OP_mul :
  case OP_div :
  case OP_mod :
  case OP_Aadd :
  case OP_Asub :
  case OP_Amul :
  case OP_Adiv :
  case OP_Amod :
  case OP_Arshft :
  case OP_Alshft :
  case OP_Aand :
  case OP_Aor :
  case OP_Axor :
    GenDualOpExpr(expr, opcode); break;
  case OP_assign :
    if (IsUselessVar(expr->operands, NULL))
      GenExpr(expr->operands->sibling);
    else {
	Expr op1, op2;

        op1 = GetOperand(expr, 1);
        op2 = GetOperand(expr, 2);

        if ((op1->opcode == OP_var) &&
            (strstr(op1->value.string, "@arg") ||
            strstr(op1->value.string, "@return"))) {
	        GenExpr(op2);
        }
        else if ((op2->opcode == OP_var) &&
                 strstr(op2->value.string, "@param")) {
	        GenExpr(op1);
        }
        else {
	    GenDualOpExpr(expr, opcode); break;
        }
    }
    break;
    /* the second operand is in value.string */
  case OP_dot :
    GenDotExpr(expr); break;
  case OP_arrow :
    GenArrowExpr(expr); break;
    /* unary */
  case OP_neg :
  case OP_not :
  case OP_inv :
  case OP_preinc :
  case OP_predec :
  case OP_indr :
  case OP_postinc :
  case OP_postdec :
    GenSingleOpExpr(expr, opcode); break;
  case OP_addr :
    /* since array and func are already addresses, it makes no sense to
     * take the address of them
     */
    for (op = expr->operands; op->opcode == OP_compexpr; op = op->operands);
    /* BCC - in fast mode type information is not complete - 6/3/98 */
    if (fast_mode == 0 && op->opcode == OP_var && op->type->dcltr &&
	(op->type->dcltr->method == D_ARRY || 
	 op->type->dcltr->method == D_FUNC))
      GenExpr(expr->operands);
    else
      GenSingleOpExpr(expr, opcode); break;
    break;
  case OP_compexpr:
    GenCompoundExpr(expr); break;
  case OP_error :
    /*      Pcode grammar: $Expr = (ERROR) */
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, ERROR_EXPR_PCODE);
    /* TLJ - Add support for ExprPragma's */  
    prag = expr->pragma;
    while (prag)
    {
      GenExprPragma(prag);
      prag = prag->next;
    }

    /* LCW - generate expression profile info - 10/30/95 */
    GenExprProfile(expr->profile);

    put_token(F, RIGHT_PAREN_TOKEN, NULL);
    break;
    default :
      Punt("GenExpr : illegal expression");
  }
  GEN_PCODE_SUBPROC_EXIT("Expr", 0);
}


/******************************************************************************
  GenCompoundStmt():
  Write out a Pcode $CompoundStmt nonterm.
  
  Pcode grammar: $CompoundStmt =
  (COMPSTMT  $ScopeID? ($LocalDecl*) ($Stmt*))
  
  Parameters: CompoundStmt: A pointer to a compound statement
  
  Returns: Nothing
  
  Calls:  GenLocalDecls()
  GenStmts()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenCompoundStmt(scope,CompoundStmt,Localdecl)
     int scope;     
     Stmt CompoundStmt;
     VarList Localdecl;
{
  GEN_PCODE_SUBPROC_ENTER("CompoundStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, COMPOUND_STMT_PCODE);
  
  /* NJW - print scope */
  GenIntVal(scope);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenLocalDecls(Localdecl);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenStmts(CompoundStmt);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("CompoundStmt",0);
}

/******************************************************************************
  GenExprStmt():
  Write out a Pcode $ExprStmt nonterm.
  
  Pcode grammar: $ExprStmt =
  (EXPR ($ExprList))
  
  Parameters: ExprStmt: A pointer to an expression statement
  
  Returns: Nothing
  
  Calls:  GenExprList()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenExprStmt(ExprStmt)
     Expr ExprStmt;
{
  GEN_PCODE_SUBPROC_ENTER("ExprStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, EXPR_STMT_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenExprList(ExprStmt);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("ExprStmt",0);
}

/******************************************************************************
  GenDoStmt():
  Write out a Pcode $DoStmt nonterm.
  
  Pcode grammar: $DoStmt =
  (DO $Stmt WHILE ($ExprList))
  
  Parameters: DoStmt: A pointer to a do statement
  
  Returns: Nothing
  
  Calls:  GenExprList()
  GenStmt()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenDoStmt(DoStmt)
     SerLoop DoStmt;
{
  GEN_PCODE_SUBPROC_ENTER("DoStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DO_STMT_PCODE);
  
  GenStmts(DoStmt->loop_body);
  
  put_token(F, IDENT_TOKEN, WHILE_STMT_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  GenExprList(DoStmt->cond_expr);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("DoStmt",0);
}

/******************************************************************************
  GenForStmt():
  Write out a Pcode $ForStmt nonterm.
  
  Pcode grammar: $ForStmt =
  (FOR ($ExprList?) ($ExprList?) ($ExprList?) DO $Stmt)
  
  Parameters: ForStmt: A pointer to a for statement
  
  Returns: Nothing
  
  Calls:  GenExprList()
  GenStmt()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenForStmt(ForStmt)
     SerLoop ForStmt;
{
  GEN_PCODE_SUBPROC_ENTER("ForStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, FOR_STMT_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (ForStmt->init_expr != NULL) GenExprList(ForStmt->init_expr);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (ForStmt->cond_expr != NULL) GenExprList(ForStmt->cond_expr);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (ForStmt->iter_expr != NULL) GenExprList(ForStmt->iter_expr);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, IDENT_TOKEN, DO_STMT_PCODE);
  
  GenStmts(ForStmt->loop_body);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("ForStmt",0);
}

/******************************************************************************
  GenWhileStmt():
  Write out a Pcode $WhileStmt nonterm.
  
  Pcode grammar: $WhileStmt =
  (WHILE ($ExprList) DO $Stmt)
  
  Parameters: WhileStmt: A pointer to a while statement
  
  Returns: Nothing
  
  Calls:  GenExprList()
  GenStmts()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenWhileStmt(WhileStmt)
     SerLoop WhileStmt;
{
  GEN_PCODE_SUBPROC_ENTER("WhileStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, WHILE_STMT_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenExprList(WhileStmt->cond_expr);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, IDENT_TOKEN, DO_STMT_PCODE);
  
  GenStmts(WhileStmt->loop_body);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("WhileStmt",0);
}


/******************************************************************************
  GenIfStmt():
  Write out a Pcode $IfStmt nonterm.
  
  Pcode grammar: $IfStmt =
  (IF ($ExprList) THEN $Stmt ELSE $Stmt)  |
  (IF ($ExprList) THEN $Stmt)
  
  Parameters: IfStmt: A pointer to an if statement
  
  Returns: Nothing
  
  Calls:  GenExprList()
  GenStmts()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenIfStmt(stmt)
     IfStmt stmt;
{
  GEN_PCODE_SUBPROC_ENTER("IfStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, IF_STMT_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenExprList(stmt->cond_expr);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, IDENT_TOKEN, THEN_STMT_PCODE);
  GenStmts(stmt->then_block);
  
  if (stmt->else_block != NULL) {
    put_token(F, IDENT_TOKEN, ELSE_STMT_PCODE);
    GenStmts(stmt->else_block);
  }
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("IfStmt",0);
}

/******************************************************************************
  GenSwitchStmt():
  Write out a Pcode $SwitchStmt nonterm.
  
  Pcode grammar: $SwitchStmt =
  (SWITCH ($ExprList) $Stmt)
  
  Parameters: SwitchStmt: A pointer to a switch statement
  
  Returns: Nothing
  
  Calls:  GenExprList()
  GenStmts()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenSwitchStmt(stmt)
     SwitchStmt stmt;
{
  GEN_PCODE_SUBPROC_ENTER("SwitchStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, SWITCH_STMT_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenExprList(stmt->expression);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GenStmts(stmt->switchbody);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("SwitchStmt",0);
}


/******************************************************************************
  GenBreakStmt():
  Write out a Pcode $BreakStmt nonterm.
  
  Pcode grammar: $BreakStmt =
  (BREAK)
  
  Parameters: BreakStmt: A pointer to static
  
  Returns: Nothing
  
  Calls:  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenBreakStmt()
{
  GEN_PCODE_SUBPROC_ENTER("BreakStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, BREAK_STMT_PCODE);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("BreakStmt",0);
}
/******************************************************************************
  GenContinueStmt():
  Write out a Pcode $ContinueStmt nonterm.
  
  Pcode grammar: $ContinueStmt =
  (CONTINUE)
  
  Parameters: ContinueStmt: A pointer to static
  
  Returns: Nothing
  
  Calls:  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenContinueStmt()
{
  GEN_PCODE_SUBPROC_ENTER("ContinueStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, CONTINUE_STMT_PCODE);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("ContinueStmt",0);
}

/******************************************************************************
  GenReturnStmt():
  Write out a Pcode $ReturnStmt nonterm.
  
  Pcode grammar: $ReturnStmt =
  (RETURN ($ExprList))  |
  (RETURN)
  
  Parameters: ReturnStmt: A pointer to a return statement
  
  Returns: Nothing
  
  Calls:  GenExprList()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenReturnStmt(ReturnStmt)
     Expr ReturnStmt;
{
  GEN_PCODE_SUBPROC_ENTER("ReturnStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, RETURN_STMT_PCODE);
  
  if (ReturnStmt != NULL) {
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    GenExprList(ReturnStmt);
    put_token(F, RIGHT_PAREN_TOKEN, NULL);
  }
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("ReturnStmt",0);
}



/******************************************************************************
  GenGotoStmt():
  Write out a Pcode $GotoStmt nonterm.
  
  Pcode grammar: $GotoStmt =
  (GOTO $LabelID)
  
  Parameters: GotoStmt: A pointer to a goto statement
  
  Returns: Nothing
  
  Calls:  GenVarId()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenGotoStmt(label)
     char *label;
{
  GEN_PCODE_SUBPROC_ENTER("GotoStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, GOTO_STMT_PCODE);
  
  GenVarId(label);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("GotoStmt",0);
}


/******************************************************************************
  GenNullStmt():
  Write out a Pcode $NullStmt nonterm.
  
  Pcode grammar: $NullStmt =
  (NULL)
  
  Parameters: NullStmt: A pointer to static
  
  Returns: Nothing
  
  Calls:  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenNullStmt()
{
  GEN_PCODE_SUBPROC_ENTER("NullStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, NULL_STMT_PCODE);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("NullStmt",0);
}


/******************************************************************************
  GenPStmt():
  Write out a Pcode $PStmt nonterm.
  
  Pcode grammar: $PStmt =
  (PSTMT $Stmt)
  
  Parameters: PStmt: A pointer to a P-statment
  
  Returns: Nothing
  
  Calls:  GenStmts()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenPStmt(stmt)
     Pstmt stmt;
{
  GEN_PCODE_SUBPROC_ENTER("PStmt",0);
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, P_STMT_PCODE);
  GenStmts(stmt);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("PStmt",0);
}

/******************************************************************************
  GenAdvanceStmt():
  Write out a Pcode $AdvanceStmt nonterm.
  
  Pcode grammar: $AdvanceStmt =
  (ADVANCE $IntVal)
  
  Parameters: AdvanceStmt: A pointer to an advance statement
  
  Returns: Nothing
  
  Calls:  GenIntVal()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenAdvanceStmt(stmt)
     Advance stmt;
{
  GEN_PCODE_SUBPROC_ENTER("AdvanceStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, ADVANCE_STMT_PCODE);
  
  GenIntVal(stmt->marker);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("AdvanceStmt",0);
}
/******************************************************************************
  GenAwaitStmt():
  Write out a Pcode $AwaitStmt nonterm.
  
  Pcode grammar: $AwaitStmt =
  (AWAIT $IntVal $IntVal)
  
  Parameters: AwaitStmt: A pointer to an await statement
  
  Returns: Nothing
  
  Calls:  GenIntVal()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenAwaitStmt(stmt)
     Await stmt;
{
  GEN_PCODE_SUBPROC_ENTER("AwaitStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, AWAIT_STMT_PCODE);
  
  GenIntVal(stmt->marker);
  
  GenIntVal(stmt->distance);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("AwaitStmt",0);
}

/******************************************************************************
  GenDoallStmt():
  Write out a Pcode $DoallStmt nonterm.
  
  Pcode grammar: $DoallStmt =
  (DOALL $DoStmtHead $DoPStmt)
  
  Parameters: DoallStmt: A pointer to an doall statement
  
  Returns: Nothing
  
  Calls:  GenDoStmtHead()
  GenDoPStmt()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenDoallStmt(DoallStmt)
     ParLoop DoallStmt;
{
  GEN_PCODE_SUBPROC_ENTER("DoallStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOALL_STMT_PCODE);
  
  GenDoStmtHead(DoallStmt);
  
  GenDoPStmt(DoallStmt->pstmt);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("DoallStmt",0);
}

/******************************************************************************
  GenDoacrossStmt():
  Write out a Pcode $DoacrossStmt nonterm.
  
  Pcode grammar: $DoacrossStmt =
  (DOACROSS $DoStmtHead $DoPStmt)
  
  Parameters: DoacrossStmt: A pointer to an doacross statement
  
  Returns: Nothing
  
  Calls:  GenDoStmtHead()
  GenDoPStmt()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenDoacrossStmt(DoacrossStmt)
     ParLoop DoacrossStmt ;
{
  GEN_PCODE_SUBPROC_ENTER("DoacrossStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOACROSS_STMT_PCODE);
  
  GenDoStmtHead(DoacrossStmt);
  
  GenDoPStmt(DoacrossStmt->pstmt);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("DoacrossStmt",0);
}

/******************************************************************************
  GenDosuperStmt():
  Write out a Pcode $DosuperStmt nonterm.
  
  Pcode grammar: $DosuperStmt =
  (DOSUPER $DoStmtHead $DoPStmt)
  
  Parameters: DosuperStmt: A pointer to an dosuper statement
  
  Returns: Nothing
  
  Calls:  GenDoStmtHead()
  GenDoPStmt()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenDosuperStmt(DosuperStmt)
     ParLoop DosuperStmt ;
{
  GEN_PCODE_SUBPROC_ENTER("DosuperStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOSUPER_STMT_PCODE);
  
  GenDoStmtHead(DosuperStmt);
  
  GenDoPStmt(DosuperStmt->pstmt);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("DosuperStmt",0);
}

/******************************************************************************
  GenDoserialStmt():
  Write out a Pcode $DoserialStmt nonterm.
  
  Pcode grammar: $DoserialStmt =
  (DOSERIAL $DoStmtHead $DoPStmt)
  
  Parameters: DoserialStmt: A pointer to an doserial statement
  
  Returns: Nothing
  
  Calls:  GenDoStmtHead()
  GenDoPStmt()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenDoserialStmt(DoserialStmt)
     ParLoop DoserialStmt;
{
  GEN_PCODE_SUBPROC_ENTER("DoserialStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOSERIAL_STMT_PCODE);
  
  GenDoStmtHead(DoserialStmt);
  
  GenDoPStmt(DoserialStmt->pstmt);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("DoserialStmt",0);
}


/******************************************************************************
  GenDoStmtHead():
  Write out a Pcode $DoStmtHead nonterm.
  
  Pcode grammar: $DoStmtHead =
  ((INDEX $VarID) (INIT $Expr) (FINAL $Expr) (INC $Expr))
  
  Parameters: DoStmtHead: A pointer to do statement index information
  
  Returns: Nothing
  
  Calls:  GenVarId()
  GenExpr()
  put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/


static GenDoStmtHead(DoStmtHead)
     ParLoop DoStmtHead;
{
  GEN_PCODE_SUBPROC_ENTER("DoStmtHead",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOHEAD_INDEX_PCODE);
  
  GenVarId(DoStmtHead->iteration_var->value.var_name);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOHEAD_INIT_PCODE);
  
  GenExpr(DoStmtHead->init_value);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOHEAD_FINAL_PCODE);
  
  GenExpr(DoStmtHead->final_value);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOHEAD_INC_PCODE);
  
  GenExpr(DoStmtHead->incr_value);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("DoStmtHead",0);
}


/******************************************************************************
  GenDoPStmt():
  Write out a Pcode $DoPStmt nonterm.
  
  Pcode grammar:
  $DoPStmt =
  (PSTMT (PROLOGUE (($Label*) $DoCompStmt ($StmtPragma*) $Pos?)) $Pos?)
  
  $DoCompStmt =
  (COMPSTMT $ScopeID? ($LocalDecl*) ($Stmt*
  (($Label*) $BodyStmt ($StmtPragma*) $Pos?)
  (($Label*) $EpilogueStmt (StmtPragma*) $Pos?)))
  
  Parameters: BodyStmt: A pointer to the loop body statement
  
  Returns: Nothing
  
  Calls:  GenStmts()
  GenPos()
  extern put_token()
  extern ERR()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/


static GenDoPStmt(body)
     Pstmt body;
{
  
  GEN_PCODE_SUBPROC_ENTER("DoPStmt",0);
  
  
  
  /* write pstmt */
  if (!pretty_print)
    put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, DOPSTMT_PCODE);
  
  /* write prologue */
  if (!pretty_print){
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, DOPSTMT_PROLOGUE_PCODE);
  }
  
  GenStmts(body->stmt);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  if (line_yes) 
    Gen_PCODE_LinePos(F, body->lineno, body->colno, body->filename);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  /* end write pstmt */
  
  GEN_PCODE_SUBPROC_EXIT("DoPStmt",0);
}

/******************************************************************************
  GenCobeginStmt():
  Write out a Pcode $CobeginStmt nonterm.
  
  Pcode grammar: $CobeginStmt =
  (COBEGIN $Stmt+)
  
  Parameters: CobeginStmt: A pointer to a cobegin statement
  
  Returns: Nothing
  
  Calls:  GenStmtss()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenCobeginStmt(stmt)
     Cobegin stmt;
{
  GEN_PCODE_SUBPROC_ENTER("CobeginStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, COBEGIN_STMT_PCODE);
  
  GenStmts(stmt);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("CobeginStmt",0);
}


/******************************************************************************
  GenMutexStmt():
  Write out a Pcode $MutexStmt nonterm.
  
  Pcode grammar: $MutexStmt =
  (MUTEX $Expr $Stmt)
  
  Parameters: MutexStmt: A pointer to a mutual exclusion statement
  
  Returns: Nothing
  
  Calls:  GenExpr()
  GenStmts()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenMutexStmt(MutexStmt)
     Mutex MutexStmt;
{
  GEN_PCODE_SUBPROC_ENTER("MutexStmt",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, MUTEX_STMT_PCODE);
  
  GenExpr(MutexStmt->expression);
  
  GenStmts(MutexStmt->statement);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("MutexStmt",0);
}



/******************************************************************************
  GenStmt2():
  Write out a Pcode $Stmt2 nonterm.
  modified by D. Lavery 8/11/93 to add DosuperStmt 
  
  Pcode grammar: $Stmt2 =
  $ExprStmt      |
  $CompoundStmt  |
  $DoStmt        |
  $WhileStmt     |
  $ForStmt       |
  $IfStmt        |
  $SwitchStmt    |
  $BreakStmt     |
  $ContinueStmt  |
  $ReturnStmt    |
  $GotoStmt      |
  $NullStmt      |
  $PStmt         |
  $AdvanceStmt   |
  $AwaitStmt     |
  $DoserialStmt  |
  $DoallStmt     |
  $DoacrossStmt  |
  $DosuperStmt   |
  $MutexStmt     |
  $CobeginStmt
  
  Parameters: Stmt2: A pointer to a statement
  Pos: A pointer to the statement position information
  
  Returns: Nothing
  
  Calls:
  GenExprStmt()
  GenCompoundStmt()
  GenDoStmt()
  GenWhileStmt()
  GenForStmt()
  GenIfStmt()
  GenSwitchStmt()
  GenBreakStmt()
  GenContinueStmt()
  GenReturnStmt()
  GenGotoStmt()
  GenNullStmt()
  GenPStmt()
  GenAdvanceStmt()
  GenAwaitStmt()
  GenDoserialStmt()
  GenDoallStmt()
  GenDoacrossStmt()
  GenDosuperStmt()
  GenMutexStmt()
  GenCobeginStmt()
  Punt()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/


static GenStmt2(stmt)
     Stmt stmt;
{
  int st_type;
  
  GEN_PCODE_SUBPROC_ENTER("Stmt2",0);
  
  switch (st_type = stmt->type) {
  case ST_EXPR: GenExprStmt(stmt->stmtstruct.expr); break;
  case ST_COMPOUND: GenCompoundStmt(stmt->stmtstruct.compound->scope,
				    stmt->stmtstruct.compound->stmt_list,
				    stmt->stmtstruct.compound->var_list);
    break;
  case ST_SERLOOP:
    { 
      int looptype;
      switch (looptype = stmt->stmtstruct.serloop->loop_type) {
      case LT_DO: GenDoStmt(stmt->stmtstruct.serloop); break;
      case LT_FOR: GenForStmt(stmt->stmtstruct.serloop); break;
      case LT_WHILE: GenWhileStmt(stmt->stmtstruct.serloop); break;
      default: Punt("GenStmt2: Invalid serial loop type");
      } 
      break;
    }
  case ST_IF: GenIfStmt(stmt->stmtstruct.ifstmt); break;
  case ST_SWITCH: GenSwitchStmt(stmt->stmtstruct.switchstmt); break;
  case ST_BREAK: GenBreakStmt(); break;
  case ST_CONT: GenContinueStmt(); break; 
  case ST_RETURN: GenReturnStmt(stmt->stmtstruct.ret); break;
  case ST_GOTO: GenGotoStmt(stmt->stmtstruct.label); break;
  case ST_NOOP: GenNullStmt(); break;
  case ST_PSTMT: GenPStmt(stmt->stmtstruct.pstmt); break;
  case ST_ADVANCE: GenAdvanceStmt(stmt->stmtstruct.advance); 
    break;
  case ST_AWAIT: GenAwaitStmt(stmt->stmtstruct.await); break;
  case ST_PARLOOP:
    {        
      int ploop;       
      switch (ploop = stmt->stmtstruct.parloop->loop_type) {   
      case LT_DOALL: GenDoallStmt(stmt->stmtstruct.parloop); break;   
      case LT_DOACROSS: GenDoacrossStmt(stmt->stmtstruct.parloop);    
	break;       
      case LT_DOSUPER: GenDosuperStmt(stmt->stmtstruct.parloop);    
	break;       
      case LT_DOSERIAL: GenDoserialStmt(stmt->stmtstruct.parloop);    
	break;
      default: Punt("GenStmt2: Invalid parallel loop type");  
	/* need to find out about DOSUPER */    
      }       
      break;
    }
  case ST_BODY: 
    {
      put_token(F, LEFT_PAREN_TOKEN, NULL);
      put_token(F, IDENT_TOKEN,DOPSTMT_BODY_PCODE);
      GenStmts(stmt->stmtstruct.bodystmt->statement);
      put_token(F, RIGHT_PAREN_TOKEN, NULL);
      break;
    }
  case ST_EPILOGUE:
    {
      if (!pretty_print){
	put_token(F, LEFT_PAREN_TOKEN, NULL);
	put_token(F, IDENT_TOKEN, DOPSTMT_EPILOGUE_PCODE);
	GenStmts(stmt->stmtstruct.epiloguestmt->statement);
	put_token(F, RIGHT_PAREN_TOKEN, NULL);
      }
      break;
    } 
    
  case ST_MUTEX: GenMutexStmt(stmt->stmtstruct.mutex); break;
  case ST_COBEGIN: GenCobeginStmt(stmt->stmtstruct.cobegin); break; 
  default:
    Punt("GenStmt2: unknown Stmt2 tag");
  }
  
  GEN_PCODE_SUBPROC_EXIT("Stmt2",0);
}

/******************************************************************************
  GenGotoLabel():
  Write out a Pcode $GotoLabel nonterm.
  
  Pcode grammar: $GotoLabel =
  (LABEL $LabelID)
  
  Parameters: GotoLabel: A pointer to a goto label
  
  Returns: Nothing
  
  Calls:  GenVarId()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenGotoLabel(GotoLabel)
     char *GotoLabel;
{
  GEN_PCODE_SUBPROC_ENTER("GotoLabel",GotoLabel);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, GOTO_LABEL_PCODE);
  
  GenVarId(GotoLabel);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("GotoLabel",GotoLabel);
}



/******************************************************************************
  GenCaseLabel():
  Write out a Pcode $CaseLabel nonterm.
  
  Pcode grammar: $CaseLabel =
  (CASE $Expr)
  
  Parameters: CaseLabel: A pointer to a case label
  
  Returns: Nothing
  
  Calls:  GenExpr()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

void GenCaseLabel(expr)
     Expr expr;
{
  GEN_PCODE_SUBPROC_ENTER("CaseLabel",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, CASE_LABEL_PCODE);
  
  GenExpr(expr);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("CaseLabel",0);
}


/******************************************************************************
  GenLabels():
  Write out a list of Pcode $Label nonterms.
  
  Pcode grammar: $Label =
  $CaseLabel    |
  $DefaultLabel |
  $GotoLabel
  
  Parameters: Labels: A pointer to a list of labels
  
  Returns: Nothing
  
  Calls:  GenGotoLabel()
  GenCaseLabel()
  Punt()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenLabels(labels)
     Label labels;
{
  GEN_PCODE_SUBPROC_ENTER("Labels",0);
  while (labels != 0){
    
    switch (labels->type){
    case LB_LABEL:
      GenGotoLabel(labels->val);
      break;
    case LB_CASE:
      GenCaseLabel(labels->expression);
      break;
    case LB_DEFAULT:
      put_token(F, LEFT_PAREN_TOKEN, NULL);
      put_token(F, IDENT_TOKEN, DEFAULT_LABEL_PCODE);
      put_token(F, RIGHT_PAREN_TOKEN, NULL);
      break;
    default:
      Punt("GenLabels: unknown Label tag");
    }
    labels = labels->next;
  }
  GEN_PCODE_SUBPROC_EXIT("Labels",0);
}

/******************************************************************************
  GenStmts():
  Write out a Pcode $Stmt nonterm.
  
  Pcode grammar: $Stmt =
  (($Label*) $Stmt2 ($Pragma*) $Pos?)
  
  Parameters: Stmt: A pointer to the statement and position information
  Pragmas: A pointer to a list of statement pragmas
  
  Returns: Nothing
  
  Calls:  GenStmt2()
  GenPragma()
  GenLabels()
  GenPos()
  extern put_token()
  extern ERR()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/


static GenStmts(stmt)
     Stmt stmt;
{
  Pragma cur_pragma;
  GEN_PCODE_SUBPROC_ENTER("Stmt",0 );
  
  while (stmt != 0) {
    
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    
    if ( (!pretty_print) || (stmt->labels != 0)){
      put_token(F, LEFT_PAREN_TOKEN, NULL);
      GenLabels(stmt->labels);
      put_token(F, RIGHT_PAREN_TOKEN, NULL);
    }
    
    GenStmt2(stmt);
    
    if ( (!pretty_print) || stmt->pragma != 0){
      put_token(F, LEFT_PAREN_TOKEN, NULL);
      cur_pragma = stmt->pragma;
      while (cur_pragma != NULL) {
	
	/* GEH - no longer needed (5/9/93)
	if (strncmp(cur_pragma->specifier, STMT_PRAGMA_PCODE,
		    strlen(STMT_PRAGMA_PCODE)) != 0) {
	  Punt("GenStmt: statement pragma expected");
	}
	else {
	*/
	  GenPragma(cur_pragma, stmt->filename);
	  cur_pragma = cur_pragma->next;
	/* } */
      }
      put_token(F, RIGHT_PAREN_TOKEN, NULL);
    }
    
    if (line_yes) 
      Gen_PCODE_LinePos(F, stmt->lineno, stmt->colno,  stmt->filename);
    
    /* LCW - generate profile information - 10/25/95 */
    Gen_PCODE_Stmt_Profile(F, stmt->profile);

    put_token(F, RIGHT_PAREN_TOKEN, NULL);
    
    stmt = stmt->lex_next;
  }
  GEN_PCODE_SUBPROC_EXIT("Stmt",0);
}



Gen_PCODE_Stmt(FL, stmt, print_option)
     FILE *FL;
     Stmt stmt;
     int print_option;
{
  Pragma cur_pragma;
  
  F = FL;
  
  GEN_PCODE_PROC_ENTER("_PCODE_Stmt", 0);
  
  pretty_print = print_option;
  
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  if ( (!pretty_print) || (stmt->labels != 0)){
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    GenLabels(stmt->labels);
    put_token(F, RIGHT_PAREN_TOKEN, NULL);
  }
  
  GenStmt2(stmt);
  
  if ( (!pretty_print) || stmt->pragma != 0){
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    cur_pragma = stmt->pragma;
    while (cur_pragma != NULL) {
      
      /* GEH - no longer needed 5/9/93
      if (strncmp(cur_pragma->specifier, STMT_PRAGMA_PCODE,
		  strlen(STMT_PRAGMA_PCODE)) != 0) {
	Punt("GenStmt: statement pragma expected");
      }
      else {
      */
	GenPragma(cur_pragma, stmt->filename);
	cur_pragma = cur_pragma->next;
      /* } */
    }
    put_token(F, RIGHT_PAREN_TOKEN, NULL);
  }
  
  if (line_yes) 
    Gen_PCODE_LinePos(F, stmt->lineno, stmt->colno,  stmt->filename);

  /* LCW - generate profile information - 10/25/95 */
  Gen_PCODE_Stmt_Profile(F, stmt->profile);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  pretty_print = NO_PRETTY_PRINT_PCODE;
  
  GEN_PCODE_PROC_EXIT("_PCODE_Stmt",0);
}


/******************************************************************************
  GenFunctHead():
  Write out a Pcode $FunctHead nonterm.
  
  Pcode grammar: $FunctHead =
  (BEGIN_FN $VarID $Pos?) $DeclSpec ($FunctPrmDecl*) ($Pragma*)
  
  Parameters: FunctID: A function variable identifier
  Pos: A pointer to the function position
  TypeSpec: A pointer to the function return type
  specifier
  Dcltr: A pointer to a list of  function return type modifier
  PrmDecls: A pointer to the list of function parameter
  declarations
  Pragmas: A pointer to the list of pragmas declared before
  the function definition
  FunctBody: A pointer to the function body which may
  contain more pragmas
  
  Returns: Nothing
  
  Calls:  GenVarId()
  GenPos()
  GenDeclSpec()
  GenFunctPrmDecl()
  GenPragma()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenFunctHead(FunctID, LPos, CPos, FName, TypeSpec, TDcltr, PrmDecls, Pragmas)
     char *FunctID;
     int  LPos, CPos;
     char *FName;
     Type TypeSpec;
     Dcltr TDcltr;
     VarList PrmDecls;
     Pragma Pragmas;
     
{
  GEN_PCODE_SUBPROC_ENTER("FunctHead",FunctID);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, BEGIN_FUNCT_DECL_PCODE);
  
  GenVarId(FunctID);
  if (line_yes) Gen_PCODE_LinePos(F,LPos, CPos, FName);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  /* Function Declaration Specification */
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (TypeSpec == 0){
    fprintf(Ferr,"DeclSpec: TcSpec  missing for func %s \n", FunctID);
    return;
  }
  GenType(TypeSpec);
  GenDcltr(TDcltr, 0);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  /* Function Parameter Declaration */
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  while(PrmDecls != NULL) {
    GenFunctPrmDecl(PrmDecls);
    PrmDecls = PrmDecls->next;
  }
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  
  /* Function Pragma Declaration */
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  /* process function pragmas declared before function definition */
  while(Pragmas != NULL) {
    
    /* GEH - no longer needed (5/9/93)
    if (strncmp(Pragmas->specifier, FUNCT_PRAGMA_PCODE,
                strlen(FUNCT_PRAGMA_PCODE)) != 0) {
      Punt("GenFunctHead: function pragma expected");
    }
    else */ GenPragma(Pragmas, FName);
    Pragmas = Pragmas->next;
  }
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("FunctHead",FunctID);
}

/******************************************************************************
  GenFunctTail():
  Write out a Pcode $FunctTail nonterm.
  
  Pcode grammar: $FunctTail =
  (END_FN $VarID)
  
  Parameters: FunctID: a function variable identifier
  
  Returns: Nothing
  
  Calls:  GenVarId()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenFunctTail(FunctID)
     char *FunctID;
{
  GEN_PCODE_SUBPROC_ENTER("FunctTail",FunctID);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, END_FUNCT_DECL_PCODE);
  
  GenVarId(FunctID);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("FunctTail",FunctID);
}



/* print function definition. */

/******************************************************************************
  GenFunction():
  Write out a Pcode $FunctDecl nonterm.
  
  Pcode grammar: $FunctDecl =
  ($FunctHead $FunctBody $FunctTail)
  $FunctBody =
  $CompoundStmt
  
  Parameters: FunctDecl: A pointer to the FunctDecl_t structure
  Pragmas: A pointer to the list of PragmaDecl_t structures
  
  Returns: Nothing
  
  Calls:  GenFunctHead()
  GenCompoundStmt()
  GenFunctTail()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenFunction(func)
     FuncDcl func;
{
  Pragma prof_fn;

  GEN_PCODE_SUBPROC_ENTER("FunctDecl",func->name);
  
  if (func==0) Punt("GenFunction : nil input");
  if (func->type==0) Punt("GenFunction : no return type");
  if (func->name==0) Punt("GenFunction : no name");
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  /* BCC - adjust function profile weight - 7/16/98 */
  prof_fn = FindFunctionPragma(func, "\"profile\"");
  if (prof_fn)
      prof_fn->expr->value.real *= out_fraction;

  GenFunctHead(func->name, func->lineno, func->colno, func->filename, 
	       func->type, func->type->dcltr, func->param, func->pragma);
  
  /* NJW - change to GenStmts since function has explicit compound stmt */
  GenCompoundStmt(func->stmt->stmtstruct.compound->scope,
		  func->stmt->stmtstruct.compound->stmt_list,
		  func->stmt->stmtstruct.compound->var_list);
  
  GenFunctTail(func->name);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("FunctDecl",func->name);
}


/*========================================================================*/


/******************************************************************************
  GenEnumItem():
  Write out a Pcode $EnumItem nonterm.
  
  Pcode grammar: $EnumItem =
  ($EnumID $Expr?)
  
  Parameters: EnumItem: A pointer to an enumeration item
  
  Returns: Nothing
  
  Calls:  GenVarId()
  GenExpr()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenEnumItem(item)
     EnumField item;
{
  char *name;
  if (item->new_name != 0) name = item->new_name;
  else name = item->name; 
  GEN_PCODE_SUBPROC_ENTER("EnumItem",name);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  GenVarId(name);
  
  if (item->value != NULL) GenExpr(item->value);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("EnumItem",name);
}


/* print enum type definition. */

/******************************************************************************
  GenEnumDcl():
  Write out a Pcode $EnumSpec nonterm.
  
  Pcode grammar: $EnumSpec =
  (ENUM $EnumID? $EnumItem*)
  
  Parameters: EnumSpec: A pointer to an enumeration specifier
  
  Returns: Nothing
  
  Calls:  GenVarId()
  GenEnumItem()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenEnumDcl(E)
     EnumDcl E;
{
  EnumField ptr;
  
  char *name;
  if (E->new_name != 0) name = E->new_name;
  else name = E->name; 
  
  GEN_PCODE_SUBPROC_ENTER("EnumSpec ",name);
  if (E==0) Punt("GenEnumDcl : nil E");
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, TYPE_DEFINITION_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, ENUM_PCODE);
  
  /* ONLY using NEWNAME for now, may have to change this later */
  if (name != NULL) GenVarId(name);
  
  ptr = E->fields;
  
  while (ptr != NULL) {
    GenEnumItem(ptr);
    ptr = ptr->next;
  }
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  if(line_yes) /* output position */
    if (E->filename != 0)
      Gen_PCODE_LinePos(F, E->lineno, E->colno, E->filename);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("EnumSpec",name);
}


/*========================================================================*/
/******************************************************************************
  
  GenStructField():
  Write out a Pcode struct or union $FieldDecl nonterm.
  
  Pcode grammar: $FieldDecl =
  ($VarID $DeclSpec $Expr?)   |
  ($DeclSpec $Expr)
  
  Parameters: Field: A pointer to a field declaration
  
  Returns: Nothing
  
  Calls:  GenVarId()
  _DeclSpec()
  pcode_Expr()
  extern put_token()
  extern ERR()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenStructField(field)
     Field field;
{
  
  GEN_PCODE_SUBPROC_ENTER("StructField",field->name);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (field->name != 0) 
    GenVarId(field->name);
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (field->type == 0){
    fprintf(Ferr,"DeclSpec: TcSpec  missing for field %s \n", field->name);         return;
  } 
  GenType(field->type);
  GenDcltr(field->type->dcltr, 0);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);        
  if  (field->bit_field != 0) {
    put_token(F, IDENT_TOKEN," ");
    GenExpr(field->bit_field); 
  }
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  
  GEN_PCODE_SUBPROC_EXIT("StructField", field->name);
}


/******************************************************************************
  GenStructDcl():
  Write out a Pcode structure nonterm.
  
  Pcode grammar: $StructSpec =
  (STRUCT $StructID? $FieldDecl*)   
  
  Parameters: S: A pointer to a  structure declarator
  
  Returns: Nothing
  
  Calls:  GenVarId()
  GenStructField()
  extern put_token()
  ******************************************************************************/

static GenStructDcl(S)
     StructDcl S;
{
  Field cur_field_decl = S->fields;
  char *name;
  
  if (S->new_name != 0) name = S->new_name;
  else name = S->name; 
  
  GEN_PCODE_SUBPROC_ENTER("StructDcl",name);
  
  if (S==0) Punt("GenStructDcl : nil S");
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  put_token(F, IDENT_TOKEN, TYPE_DEFINITION_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  put_token(F, IDENT_TOKEN, STRUCT_PCODE); 
  
  GenVarId(name);
  
  while (cur_field_decl != NULL) {
    GenStructField(cur_field_decl);
    cur_field_decl = cur_field_decl->next;
  }
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  if(line_yes)	/* output position */
    if(S->filename != 0)
      Gen_PCODE_LinePos(F, S->lineno, S->colno, S->filename);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("StructDcl",name);
  
}

/******************************************************************************
  GenUnionDcl():
  Write out a Pcode Union nonterm.
  
  Pcode grammar: $StructSpec =
  (UNION $StructID? $FieldDecl*)   
  
  Parameters: U: A pointer to a  union declarator
  
  Returns: Nothing
  
  Calls:  GenVarId()
  GenStructField()
  extern put_token()
  ******************************************************************************/

static GenUnionDcl(U)
     StructDcl U;
{
  Field cur_field_decl = U->fields;
  char *name;
  
  if (U->new_name != 0) name = U->new_name;
  else name = U->name;
  
  GEN_PCODE_SUBPROC_ENTER("UnionDcl",name);
  
  if (U==0) Punt("GenUnionDcl : nil S");
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  put_token(F, IDENT_TOKEN, TYPE_DEFINITION_PCODE);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  
  put_token(F, IDENT_TOKEN, UNION_PCODE); 
  
  
  GenVarId(name);
  
  while (cur_field_decl != NULL) {
    GenStructField(cur_field_decl);
    cur_field_decl = cur_field_decl->next;
  }
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  if(line_yes)	/* output position */
    if(U->filename != 0)
      Gen_PCODE_LinePos(F, U->lineno, U->colno,  U->filename);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("UnionDecl",name);
  
}

/*========================================================================*/
static GenInit(init)
     Init init;
{
  Init ptr;
  GEN_PCODE_SUBPROC_ENTER("Init",0);
  if (init == 0) return;
  if (init->expr != 0)
    GenExpr(init->expr);
  else 
    if (init->set != 0) {
      put_token(F, LEFT_PAREN_TOKEN, NULL);  
      ptr = init->set;
      while (ptr != 0) {
	GenInit(ptr);
	ptr = ptr->next;
      }       
      put_token(F, RIGHT_PAREN_TOKEN, NULL);
    } else
      Punt("GenInit: unknown data type");
  
  
  
  GEN_PCODE_SUBPROC_EXIT("Init", "");
}



/******************************************************************************
  GenPragma():
  Write out a Pcode $Pragma nonterm.
  
  Pcode grammar: $Pragma =
  (PRAGMA $PString $ExprList $Pos?)
  
  Parameters: PragmaStmt: A pointer to a pragma statement
  Pos: A pointer to a position indicator
  
  Returns: Nothing
  
  Calls:  GenString()
  GenExprList()
  Gen_PCODE_LinePos()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenPragma(pragma, filename)
     Pragma pragma; 
     char *filename;
{
  GEN_PCODE_SUBPROC_ENTER("Pragma",pragma->specifier);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, PRAGMA_PCODE);
  
  GenString(pragma->specifier);
  GenExprList(pragma->expr);
  
  /* BCC - 7/11/96
   * since the line number and column number are not set in most of the cases,
   * generating them may be misleading.
  if (line_yes) Gen_PCODE_LinePos(F, pragma->lineno, pragma->colno, filename);
   */
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("Pragma",pragma->specifier);
}

/******************************************************************************
  GenExprPragma():
  Write out a Pcode $ExprPragma nonterm.
  
  Pcode grammar: $ExprPragma =
  (PRAGMA $String $ExprList)
  
  Parameters: PragmaStmt: A pointer to a pragma statement
  
  Returns: Nothing
  
  Calls:  GenString()
  GenExprList()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenExprPragma(pragma)
     Pragma pragma; 
{
  GEN_PCODE_SUBPROC_ENTER("ExprPragma",pragma->specifier);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, PRAGMA_PCODE);
  
  GenString(pragma->specifier);
  GenExprList(pragma->expr);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("ExprPragma",pragma->specifier);
}


/* LCW - routine to generate expression profile information - 10/30/95 */
static GenExprProfile(profptr)
     struct _ProfEXPR *profptr;
{
  struct _ProfEXPR *ProfEXPRPtr;
  char weight[256];

  if ((ProfEXPRPtr = profptr) != NULL) {
     put_token(F, LEFT_PAREN_TOKEN, NULL);
     put_token(F, IDENT_TOKEN, PROFILE_PCODE);
     while (ProfEXPRPtr) {
     /* 
      * BCC - if some other functions inline this function, the profile weight
      *	      should be less - 12/19/95 
      */
	sprintf(weight, "%f", ProfEXPRPtr->count * out_fraction);
	put_token(F, IDENT_TOKEN, weight);
	ProfEXPRPtr = ProfEXPRPtr->next;
     }
     put_token(F, RIGHT_PAREN_TOKEN, NULL);
  }
}


/******************************************************************************
  GenTypeDef():
  Write out a Pcode $TypeDef nonterm.
  
  Pcode grammar: $TypeDef =
  (DEF $DeclSpec $Pos?)
  
  Parameters: TypeSpec: A pointer to a type specifier.
  Pos: A pointer to a position structure.
  Fname: name of the file.
  Returns: Nothing
  
  Calls:  GenDeclSpec()
  GenPos()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenTypeDef(TypeSpec,  LPos, CPos,  Fname)
     Type TypeSpec;
     int LPos, CPos;
     char Fname;
{
  GEN_PCODE_SUBPROC_ENTER("TypeDef",0);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, TYPE_DEFINITION_PCODE);
  
  
  /* DECLSPEC */
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (TypeSpec == 0){
    fprintf(Ferr,"DeclSpec:TcSpec missing for TypeDef\n");
    return;
  }
  GenType(TypeSpec);
  GenDcltr(TypeSpec->dcltr, 0);
  
  if(line_yes)    /* output position */
    if(Fname != 0)
      Gen_PCODE_LinePos(F, LPos, CPos, Fname);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("TypeDef",0);
}


/*========================================================================*/
/* print parameter definition. */

/******************************************************************************
  GenFunctPrmDecl():
  Write out a Pcode $FunctPrmDecl nonterm.
  
  Pcode grammar: $FunctPrmDecl =
  (PARAM $VarID $DeclSpec $Pos?)
  
  Parameters: FunctPrmDecl: A pointer to a function parameter declaration
  
  Returns: Nothing
  
  Calls:  GenVarId()
  GenType()
  GenDcltr
  GenPos()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

static GenFunctPrmDecl(param)
     VarList param;
{
  VarList cur_dcltr; 
  
  GEN_PCODE_SUBPROC_ENTER("FunctPrmDecl",0);
  
  cur_dcltr = param;
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, FUNCT_PRM_DECL_PCODE);
  
  if (cur_dcltr->var->new_name != 0)
    GenVarId(cur_dcltr->var->new_name);
  else
    GenVarId(cur_dcltr->var->name);
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (cur_dcltr->var->type == 0){
    fprintf(Ferr, "DeclSpec: TcSpec missing for parameter %s \n",
	    cur_dcltr->name);
    return;
  }
  GenType(cur_dcltr->var->type);
  GenDcltr(cur_dcltr->var->type->dcltr, 0);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  
  if(line_yes)	/* output position */
    if(cur_dcltr->var->filename != 0)
      Gen_PCODE_LinePos(F, cur_dcltr->var->lineno, cur_dcltr->var->colno, 
			cur_dcltr->var->filename);
  
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  GEN_PCODE_SUBPROC_EXIT("FunctPrmDecl",0);
}


/******************************************************************************
  GenLocalDecls():
  Write out a list of Pcode $LocalDecl nonterms.
  
  Pcode grammar: $LocalDecl =
  $TypeDef             |
  $LocalDataDecl
  
  Parameters: local: A pointer to a list of local declarations
  
  Returns: Nothing
  
  Calls:  GenTypeDef()
  GenLocalDataDcl()
  extern ERR()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  ******************************************************************************/

/*not at all sure of this one, need to check about the pragma stuff later */

static GenLocalDecls(local)
     VarList local;
{
  GEN_PCODE_SUBPROC_ENTER("LocalDecls ",0);
  while (local != 0) {
    
    /* check if it is a typedef */
    
    if (local->var->type->type & TY_TYPEDEF){
      GenTypeDef(local->var->type,local->var->lineno,
      		 local->var->colno, local->var->filename);
    } else  
      /* not a typedef, must be a local data declarator */
      GenLocalDataDcl(local->var); 
    
    local = local->next;
  }
  GEN_PCODE_SUBPROC_EXIT("LocalDecls ",0);
} 


static GenLocalDataDcl(V)
     VarDcl V;
{
  Pragma ptr;
  char *name;
  /*
   * (RVAR name%s DeclSpec Initializer)
   */
  if (V->new_name != 0) name = V->new_name;
  else name = V->name;
  
  /* BCC - don't print useless variables - 1/23/97 */
  if (IsUselessVar(NULL, name)) return;

  GEN_PCODE_SUBPROC_ENTER("LocalDataDecl", name);
  if (V==0) Punt("GenGlobalDataDcl : declarator missing");
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, LOCAL_DATA_DECL_PCODE);
  GenVarId(name);
  
  
  
  /* DECLSPEC */
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (V->type == 0){
    fprintf(Ferr,"DeclSpec:TcSpec missing for localdatadecl\n");        
    return;
  } 
  GenType(V->type);
  GenDcltr(V->type->dcltr, 0);
  put_token(F, RIGHT_PAREN_TOKEN, NULL); 
  
  
  /* INIT EXPR */
  /* need to find out abou this extern */       
  /*	if (! (V->type->type & TY_EXTERN)) { */
  if (V->init!=0) {
    GenInit(V->init);
  }else{
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, RIGHT_PAREN_TOKEN, NULL);
  }
  /* } */
  
  
  /* PRAGMA LIST */
  
  ptr = V->pragma;
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  while (ptr != NULL) {
    
    /* GEH - no longer needed (5/9/93)
    if (strncmp(ptr->specifier, LVAR_PRAGMA_PCODE,
		strlen(LVAR_PRAGMA_PCODE)) != 0) {
      Punt("GenLocalDataDcl: local variable pragma expected"); 
    } else */ GenPragma(ptr, V->filename);
    
    
    ptr = ptr->next;
  } 
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  if(line_yes)	/* output position */
    if(V->filename != 0)
      Gen_PCODE_LinePos(F, V->lineno, V->colno, V->filename);
  GEN_PCODE_SUBPROC_EXIT("LocalDataDecl",name);
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
}

/* print global variable definition. */
/* the type definition is what's recorded at that instance of the
 * global variable definition. If it is extern class, the initialization
 * section is not printed.
 */

/******************************************************************************
  GenGlobalDataDecl():
  Write out a Pcode $GlobalDataDecl nonterm.
  
  Pcode grammar: $GlobalDataDecl =
  (GVAR $VarID $DeclSpec $InitExpr ($Pragma*) $Pos?) |
  (GVAR $VarID $DeclSpec () ($Pragma*) $Pos?)
  
  Parameters: GlobalDataDecl: A pointer to a global data declaration
  Pragmas: A pointer to a list of pragmas
  
  Returns: Nothing
  
  Calls:  GenVarId()
  GenType
  GenDcltr()
  GenInit()
  GenPragma()
  Gen_PCODE_LinePos()
  extern put_token()
  GEN_PCODE_SUBPROC_ENTER()
  GEN_PCODE_SUBPROC_EXIT()
  Punt()
  ******************************************************************************/


static GenGlobalDataDcl(V, type, dcltr)
     VarDcl V;
     Type type;
     Dcltr dcltr;
{
  Pragma ptr;
  char *name; 
  /*
   * (GVAR name%s DeclSpec Initializer)
   */
  if (V->new_name != 0) name = V->new_name;
  else name = V->name;
  GEN_PCODE_SUBPROC_ENTER("GlobalDataDecl", name);
  if (V==0) Punt("GenGlobalDataDcl : declarator missing");
  
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  put_token(F, IDENT_TOKEN, GLOBAL_DATA_DECL_PCODE);
  GenVarId(name);
  
  
  
  /* DECLSPEC */
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  if (type == 0){
    fprintf(Ferr,"DeclSpec:TcSpec missing for globaldatadecl\n");        
    return;
  } 
  GenType(type);
  GenDcltr(dcltr, 0);
  put_token(F, RIGHT_PAREN_TOKEN, NULL); 
  
  
  /* INIT EXPR */
  /* need to find out abou this extern */
  if (! (type->type & TY_EXTERN)) {
    if (V->init!=0) 
      GenInit(V->init);
    else{ 
      put_token(F, LEFT_PAREN_TOKEN, NULL);
      put_token(F, RIGHT_PAREN_TOKEN, NULL);
    } 
    
  } else {
    put_token(F, LEFT_PAREN_TOKEN, NULL);       
    put_token(F, RIGHT_PAREN_TOKEN, NULL);
  }	
  
  
  /* PRAGMA LIST */
  
  ptr = V->pragma;
  put_token(F, LEFT_PAREN_TOKEN, NULL);
  while (ptr != NULL) {
    
    /* GEH - no longer needed (5/9/93)
    if (strncmp(ptr->specifier, GVAR_PRAGMA_PCODE,
		strlen(GVAR_PRAGMA_PCODE)) != 0) {
      Punt("GenGlobalDataDecl: global variable pragma expected"); 
    } else */ GenPragma(ptr, V->filename);
    
    
    ptr = ptr->next;
  } 
  put_token(F, RIGHT_PAREN_TOKEN, NULL);
  
  if(line_yes)	/* output position */
    if(V->filename != 0)
      Gen_PCODE_LinePos(F, V->lineno, V->colno, V->filename);

  put_token(F, RIGHT_PAREN_TOKEN, NULL);
}
/*========================================================================*/
Gen_PCODE_LinePos(F, lineno, colno, src_file)
     FILE *F;
     int lineno, colno;
     char *src_file;
{
  char ident1[1024], ident2[1024];
  if (src_file != 0){
    if (BLOCK_OUTPUT) return;
    sprintf(ident1,"%d",lineno);
    sprintf(ident2, "%d",colno);
    put_token(F, LEFT_PAREN_TOKEN, NULL);
    put_token(F, IDENT_TOKEN, POS_PCODE);
    put_token(F, IDENT_TOKEN, src_file);
    put_token(F, IDENT_TOKEN, ident1);
    put_token(F, IDENT_TOKEN, ident2);
    put_token(F, RIGHT_PAREN_TOKEN, NULL);	
  }
}
Gen_PCODE_Struct(FL, st)
     FILE *FL;
     StructDcl st;
{
  if (BLOCK_OUTPUT) return;
  GEN_PCODE_SUBPROC_ENTER("_PCODE_Struct",0);
  F = FL;
  GenStructDcl(st);
  GEN_PCODE_SUBPROC_EXIT("_PCODE_Struct",0);
  
}
Gen_PCODE_Union(FL, un) 
     FILE *FL;
     UnionDcl un;
{
  if (BLOCK_OUTPUT) return;
  GEN_PCODE_SUBPROC_ENTER("_PCODE_Union",0);
  F = FL;
  GenUnionDcl(un);
  GEN_PCODE_SUBPROC_EXIT("_PCODE_Union",0);
}
Gen_PCODE_Enum(FL, en) 
     FILE *FL;
     EnumDcl en;
{
  if (BLOCK_OUTPUT) return;
  /* BCC - if spliting, enum are replaced by int - 7/1/95 */
  if (split == 1) return;
  GEN_PCODE_SUBPROC_ENTER("_PCODE_Enum",0);
  F = FL;
  GenEnumDcl(en);
  GEN_PCODE_SUBPROC_EXIT("_PCODE_Enum",0);
}
Gen_PCODE_Var(FL, var) 
     FILE *FL;
     VarDcl var;
{
  if (BLOCK_OUTPUT) return;
  GEN_PCODE_SUBPROC_ENTER("_PCODE_Var",0);
  F = FL;
  GenGlobalDataDcl(var, var->type, var->type->dcltr);
  GEN_PCODE_SUBPROC_EXIT("_PCODE_Var",0);
}
Gen_PCODE_Func(FL, fn, print_option) 
     FILE *FL;
     FuncDcl fn;
     int print_option;
{
  if (BLOCK_OUTPUT) return;
  GEN_PCODE_PROC_ENTER("_PCODE_Func",fn->name);
  F = FL;
  pretty_print = print_option;
  GenFunction(fn);
  GEN_PCODE_PROC_EXIT("_PCODE_Func",fn->name);
}

/*========================================================================*/
/* 
 *	The following functions are provided for debugging purpose
 *	only and should not be used in normal operational mode.
 */
Gen_PCODE_Init(FL, init)
     FILE *FL;
     Init init;
{
  F = FL;
  GenInit(init);
}
/*========================================================================*/

/* BCC - generating INCLUDE directive - 5/26/95 */
Gen_PCODE_Include(FL, file)
     FILE *FL;
     char *file;
{
  int buf;
  char new_file[256];
  int length;
  /* BCC - only include the same file once in a compilation - 7/13/96 */
  int print;

#if 0
  static int level;
/* BCC - only put (INCLUDE "XXXX") in the first level inclusion - 3/7/96 */
  level++;
  if (level == 1 && inlining == 0) {
#endif
  /* TLJ 5/7/96 - change to check BLOCK_OUTPUT */
  if (!BLOCK_OUTPUT && inlining == 0) {
    sprintf(new_file, file);
    length = strlen(file)-1;
    while (length > 0) {
      if (new_file[length] == '.') {
        new_file[length] = 0;
        break;
      }
      length--;
    }
    strcat(new_file, ".pch\"");

    print = 1;
    if (!strcmp(new_file, "\"struct.pch\"")) {
	struct_count++;
	if (struct_count > 1) print = 0;
    }
    if (!strcmp(new_file, "\"extern.pch\"")) {
	extern_count++;
	if (extern_count > 1) print = 0;
    }
    if (print) {
        F = FL;
        put_token(F, LEFT_PAREN_TOKEN, NULL);
        put_token(F, IDENT_TOKEN, INCLUDE_PCODE);
        put_token(F, IDENT_TOKEN, new_file);
        put_token(F, RIGHT_PAREN_TOKEN, NULL);
    }
  }

/* Change BLOCK_OUTPUT to check if include_nesting != 0 */
#if 0
  buf = OUTPUT;
  DO_OUTPUT(0);
#endif
/* TLJ - change this to "SetupIncludeFile" and incr include flag */
  SetupIncludeFile(file);
#if 0
  ReadIncludeFile(file);
  DO_OUTPUT(buf);
  level--;
#endif
}


/* LCW - generate Pcode statement profiling information - 10/25/95 */
Gen_PCODE_Stmt_Profile(FL, profptr)
FILE *FL;
struct _ProfST *profptr;
{
   struct _ProfST *ProfStPtr;
   char weight[256];

   if ((ProfStPtr = profptr) != NULL) {
      F = FL;
      put_token(F, LEFT_PAREN_TOKEN, NULL);
      put_token(F, IDENT_TOKEN, PROFILE_PCODE);
      while (ProfStPtr) {
     /* 
      * BCC - if some other functions inline this function, the profile weight
      *	      should be less - 12/19/95 
      */
         sprintf(weight, "%f", ProfStPtr->count * out_fraction);
         put_token(F, IDENT_TOKEN, weight);
         ProfStPtr = ProfStPtr->next;
      }
      put_token(F, RIGHT_PAREN_TOKEN, NULL);
   }
}
