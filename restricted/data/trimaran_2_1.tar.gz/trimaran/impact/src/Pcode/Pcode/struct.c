/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************
 *	File:	struct.c
 *	Authors: David August, Nancy Warter, Grant Haab, Krishna Subramanian, 
 *               and Wen-mei Hwu
 *	Modified from code written by:	Po-hua Chang
 *			Krishna Subramanian, Po-hua Chang, Wen-mei Hwu
 *      License Agreement specifies the terms and conditions for 
 *      redistribution.
 *****************************************************************************/

/*==========================================================================
 *	In this file, we place all functions which operate on
 *	the internal PCODE data structure.
 *
 * There are 14 groups of functions:
 *   1. Memory Allocation Functions
 *   2. Functions for string manipulation (e.g., variable renaming, etc.)
 *   3. Functions for scope manipulation
 *   4. Functions to allocate new data structures
 *   5. Functions to remove data structures
 *   6. Copy functions
 *   7. Equivalence functions
 *   8. Symbol tree/table access functions
 *   9. Variable manipulation functions
 *  10. Declarator manipulation functions
 *  11. Expression manipulation functions
 *  12. Statement manipulating functions
 *  13. Parloop manipulation functions
 *  14. Pragma functions
 *==========================================================================*/

#include <Pcode/impact_global.h>
#include <Pcode/parms.h>
#include <library/c_basic.h>
#include <Pcode/struct.h>
#include <Pcode/symtree.h>
#include <Pcode/pcode.h>
#include <Pcode/cast.h>
#include <Pcode/flow.h>
#include <Pcode/depend.h>
#include <Pcode/links.h>
#ifdef WIN32
#include <string.h>
#define strdup _strdup
#endif

#undef FANCY_MEMORY_ALLOC
#undef DEBUG_MEMORY_ALLOC
#undef CHECK_MEMORY_ALLOC

#undef TEST_VARLIST

/*-------------------------------------------------------------*/
/* 1. Memory Allocation Functions                              */
/*-------------------------------------------------------------*/

static int total_alloc = 0;

imp_print_alloc() {
  fprintf(Ferr, "heap space management (%d)\n", total_alloc);
  fflush(Ferr);
}

#ifdef FANCY_MEMORY_ALLOC
static char *ialloc(size)
     int size;
{
  char *new;
  new = (char *) malloc (size);
  if (new==0) Punt("out of memory space");
  total_alloc += size;
  return new;
}

/* 
 * We will implement our own garbage collection.
 * This is extremely space inefficient. When I have
 * time, I will write a better heap management algorithm.
 */
typedef struct _Buf {
  char		*ptr;
  struct _Buf	*next;
} _Buf, *Buf;
typedef struct _Recycle {
  int		size;
  struct _Buf	*link;
  struct _Recycle *next;
} _Recycle, *Recycle;
static Buf buf_list = 0;	/* keep unused buf_list */
static Recycle live_list = 0;


char *imp_alloc(size)
     int size;
{
  char *new;
  Recycle ptr;
  Buf buf;
  /* search the live_list for a buffer of the same size */
  for (ptr=live_list; ptr!=0; ptr=ptr->next)
    if (ptr->size==size)
      break;
  /* if not found, allocate new space */
  if (ptr==0) {
    new = ialloc(size);
#ifdef DEBUG_MEMORY_ALLOC
    fprintf(Flog, "allocate (%d) (new)\n", size);
#endif
  } else {
    buf = ptr->link;
    if (buf==0) {	/* empty link, allocate new space */
      new = ialloc(size);
#ifdef DEBUG_MEMORY_ALLOC
      fprintf(Flog, "allocate (%d) (new)\n", size);
#endif
    } else {
      new = buf->ptr;		/* issue the requested space */
      buf->ptr = 0;
      /* release the buffer from the live_list */
      ptr->link = buf->next;	/* release the buffer */
      buf->next = buf_list;	/* put on the buf_list */
      buf_list = buf;
#ifdef DEBUG_MEMORY_ALLOC
      fprintf(Flog, "allocate (%d) (recycle)\n", size);
#endif
    }
  }
  return new;
}

imp_free(pointer, size)
     char *pointer;
     int size;
{
  Recycle ptr;
  Buf buf;
  /* search the live_list for a buffer of the same size */
  for (ptr=live_list; ptr!=0; ptr=ptr->next)
    if (ptr->size==size)
      break;
  /* if not found, allocate new recycle entry */
  if (ptr==0) {
    ptr = (Recycle) ialloc (sizeof(_Recycle));
    ptr->size = size;
    ptr->link = 0;
    ptr->next = live_list;
    live_list = ptr;
  }
#ifdef CHECK_MEMORY_ALLOC
  for (buf=ptr->link; buf!=0; buf=buf->next) {
    if (buf->ptr == pointer) {
      printf("address=0x%x, size=%d\n", pointer, size);
      Punt("imp_free: should not free an object twice");
    }
  }
#else
  /*
   *  Already in the garbage list. So do nothing now.
   *  ++++ But definitely need to fix this bug ASAP.
   */
  for (buf=ptr->link; buf!=0; buf=buf->next) {
    if (buf->ptr == pointer) {
      return 0;
    }
  }
#endif
  /* create a new buffer */
  if (buf_list!=0) {
    buf = buf_list;
    buf_list = buf_list->next;
  } else {
    buf = (Buf) ialloc (sizeof(_Buf));
  }
  buf->next = ptr->link;
  ptr->link = buf;
  buf->ptr = pointer;
#ifdef DEBUG_MEMORY_ALLOC
  fprintf(Flog, "free (%d)\n", size);
#endif
  return 0;
}
#else
char *imp_alloc(size)
     int size;
{
  char *new;
  new = (char *) malloc (size);
  if (new==0) Punt("out of memory space");
  total_alloc += size;
  return new;
}
imp_free(pointer, size)
     char *pointer;
     int size;
{
  total_alloc -= size;
  if (pointer!=0) free(pointer);
}
#endif

/*-------------------------------------------------------------*/
/* 2. Functions for string  manipulation/renaming              */
/*-------------------------------------------------------------*/

/* NewName - give a new name to a global var, struct, enum, union, or
 *           enumfield  to allow moving declarations to the global level
 *           without naming conflicts.
 *
 *  new_name = name_scopeid
 *
 *  (8/92) - global variables are never renamed (since they may be
 *           referenced by an external function).  Thus, all locals
 *           are renamed by using a P_ prefix to prevent aliasing between
 *           renamed locals and original globals names.  (Cannot use
 *           $ since this prohibits converting back to C).
 */
char *NewName(name, scopeid)
     char *name;
     int scopeid;
{
  
  char *new_name = (char *)malloc(strlen(name) + 14);
  /* GEH - changed since 9999999999 doesn't fit in an int (5-7-93) */
  if(scopeid < 0)    /* allow maximum size scopeid */
    Punt("NewName: scopeid overflow");
  sprintf(new_name, "P_%s___%d", name, scopeid);
  return new_name;
}

/* BCC - added this function to rename inlined variables - 11/10/95 */
char *NewNameIL(name, scopeid)
     char *name;
     int scopeid;
{
  char buffer[256];
  char s_scope[8];
  char *newscope;
  int index1, index2;

  sprintf(buffer, "%s", name);
  if (buffer[0] != 'P' || buffer[1] != '_')
    Punt("Old name has no scope with it");
  index1 = 2;
  index2 = strlen(buffer)-1;
  while (isdigit(buffer[index2])) index2--;
  buffer[index2+1] = 0;
  sprintf(s_scope, "%d", scopeid);
  newscope = (char *) malloc(strlen(buffer)+strlen(s_scope)+1);
  sprintf(newscope, "%s%s", buffer, s_scope);
  return newscope;
}

/* BCC - added this function to rename labels - 12/12/95 */
char *NewNameLabel(name, func_name, scopeid)
     char *name;
     char *func_name;
     int scopeid;
{
  char *new_name;

  new_name = (char *) malloc (strlen(name) + strlen(func_name) + 15);
  sprintf(new_name, "P_%s_%s___%d", name, func_name, scopeid);
  return new_name;
}

char *NewName2(name)
     char *name;
{
  char *new_name = (char *)malloc(strlen(name) + 1);
  strcpy(new_name, name);
  return new_name;
}

/* GEH,BCC  - added this function to rename local arrays to static in the
   same format as Chsemantic
*/

char *NewName3(var)
     VarDcl var;
{
  char *new_name = (char *)malloc(strlen(var->name) + 128);
  int i, j;

  sprintf(new_name, "P_");
  /* go back to just after last slash in file name */
  if (var->filename == 0) Punt("Null filename, cannot rename variable");
  for (i=strlen(var->filename)-1; var->filename[i] != '/' && i > 0; i--);
  /* copy filename to new_name without punctuation characters */
  for (i=i+1, j=2; var->filename[i] != '\0'; i++) {
     if (isalnum(var->filename[i])) new_name[j++] = var->filename[i];
  }
  /* add line number, column number, and old name */
  sprintf(&new_name[j], "_%d_%d_%s", var->lineno, var->colno, var->name);
  return new_name;
}

/* return TRUE if the prefix is found in the string.
 *  return FALSE if otherwise. 
 */
bool PrefixMatch(prefix, string)
     char *prefix, *string;
{
  while (*prefix!='\0') {
    if (*string=='\0') return FALSE;	/* string is shorter than prefix */
    if (*prefix!=*string) return FALSE;	/* no match */
    prefix++;
    string++;
  }
  return TRUE;
}

/*
 * Remove " " from "name", and returns the number of characters in " ". 
 * -1 is returned if str is not	of the form "name".
 */
int RemoveDQ(str, buf, N)
     char *str;
     char buf[];
     int N;
{
  int len = strlen(str);
  int i;
  if (len<2) return -1;
  if (str[0] != '"') return -1;
  if (str[len-1] != '"') return -1;
  if (N < len-1) Punt("RemoveDQ failed: buffer is not large enough");
  for (i=1; i<(len-1); i++) {
    buf[i-1] = str[i];
  }
  buf[len-2] = '\0';
  return (len-1);
}

/* 
 * Produce a copy of the given string without the double quotes. 
 */
char *DQString2String(str)
    char *str;
{
    char *new;
    int len;	

    if (str == NIL) Punt("DQString2String failed: null string pointer passed");
    len = strlen(str)-1;	/* minus two quotes plus '\0' */

    if ((new = (char *) malloc (sizeof(char) * len)) == NIL) 
	Punt("DQString2String failed: out of memory");

    if (RemoveDQ(str, new, len) < 0) 
	Punt("DQString2String failed: not double-quoted string");
    return new;
}

/*
 * Produce a copy of the given string, but change all characters which are
 * illegal in an identifier to the character "$".  This allows filenames
 * and the like to be converted to a string that can be used as an identifier.
 * An identifier is defined as follows:  [_,$,A-Z,a-z][_,$,A-Z,a-z,0-9]*
 */

char *String2Ident(str)
    char *str;
{
    char *ident;
    int i, len;

    if (str == NIL) Punt("String2Ident failed: null string pointer passed");
    len = strlen(str)+1;
    if ((ident = (char *) malloc (sizeof(char) * len)) == NIL)
	Punt("String2Ident failed: out of memory");

    if (str[0] == '\0') { ident[0] = '\0'; return ident; }

    ident[0] = (!isalpha(str[0]) && (str[0] != '_') && (str[0] != '$')) ?
	    	'$' : str[0];

    for (i=1; i<len-1; i++) {
	ident[i] = (!isalnum(str[i]) && (str[i] != '_') && (str[i] != '$')) ?
		   '$' : str[i];
    }
    ident[len-1] = '\0';
    return ident;
}

/*-------------------------------------------------------------*/
/* 3. Functions for scope manipulation                         */
/*-------------------------------------------------------------*/

int InitScopeId() {
  max_scope = 0;
  return max_scope;
}

int NewScopeId() {
  max_scope++;
  return max_scope;
}

/* Allocate space for a new scope identifier */
Scope NewScope(id) 
     int id;
{
  Scope new;
  new = ALLOCATE(_Scope);
  new->id = id;
  new->next = 0;
  new->prev = 0;
  return new;
}

/* Deallocate space for scope identifier */
void RemoveScope(s)
     Scope s;
{
  s->next = 0;
  s->prev = 0;
  DISPOSE(s);
}

ScopeList NewScopeList()
{
  ScopeList new;
  new = ALLOCATE(_ScopeList);
  new->scope = 0;
  new->next = 0;
  new->prev = 0;
  return new;
}

void RemoveScopeList(s)
     ScopeList s;
{
  s->next = 0;
  s->prev = 0;
  s->scope = 0;
  DISPOSE(s);
}

/* Find nearest declaration
 * 	search from back to forward of possible scopes for 
 *	nearest declaration of variable.
 */
VarDcl FindNearScopeVar(poss_scopes, var)
     Scope poss_scopes;
     char *var;
{
  Scope p;
  VarDcl v;
  p = poss_scopes;		/* global is always a poss scope */
  while(p->next!=0) p=p->next;	/* p is lowest scoping level */
  while((p!=0)&&((v=FindVar(var, p->id))==0)) p=p->prev;
  if(p==0)
    return 0;
  else
    return v;
}

/* Find nearest declaration
 * 	search from back to forward of possible scopes for 
 *	nearest declaration of structure
 */
StructDcl FindNearScopeSt(poss_scopes, st)
     Scope poss_scopes;
     char *st;
{
  Scope p;
  StructDcl s;
  p = poss_scopes;		/* global is always a poss scope */
  while(p->next!=0) p=p->next;	/* p is lowest scoping level */
  while((p!=0)&&((s=FindStruct(st, p->id))==0)) p=p->prev;
  if(p==0)
    return 0;
  else
    return s;
}

/* Find nearest declaration
 * 	search from back to forward of possible scopes for 
 *	nearest declaration of union
 */
UnionDcl FindNearScopeUn(poss_scopes, un)
     Scope poss_scopes;
     char *un;
{
  Scope p;
  UnionDcl u;
  p = poss_scopes;		/* global is always a poss scope */
  while(p->next!=0) p=p->next;	/* p is lowest scoping level */
  while((p!=0)&&((u=FindUnion(un, p->id))==0)) p=p->prev;
  if(p==0)
    return 0;
  else
    return u;
}

/* Find nearest declaration
 * 	search from back to forward of possible scopes for 
 *	nearest declaration of enum
 */
EnumDcl FindNearScopeEn(poss_scopes, en)
     Scope poss_scopes;
     char *en;
{
  Scope p;
  EnumDcl e;
  p = poss_scopes;		/* global is always a poss scope */
  while(p->next!=0) p=p->next;	/* p is lowest scoping level */
  while((p!=0)&&((e=FindEnum(en, p->id))==0)) p=p->prev;
  if(p==0)
    return 0;
  else
    return e;
}

/* Find nearest declaration
 * 	search from back to forward of possible scopes for 
 *	nearest declaration of enum field
 */
EnumDcl FindNearScopeEnF(poss_scopes, f)
     Scope poss_scopes;
     char *f;
{
  Scope p;
  EnumDcl en;
  p = poss_scopes;		/* global is always a poss scope */
  while(p->next!=0) p=p->next;	/* p is lowest scoping level */
  while((p!=0)&&((en=FindEnumField(f, p->id))==0)) p=p->prev;
  if(p==0)
    return 0;
  else
    return en;
}

/* Find closest scope between a var and enum field */
int ClosestScope(poss_scopes, name)
     Scope poss_scopes;
     char *name;
{
  Scope p;
  p = poss_scopes;
  while(p->next!=0) p=p->next;
  /* BCC - bug fix, changed the || in the second condition to && - 1/25/96 */
  while((p!=0)&&
	((FindEnumField(name, p->id)==0)&&(FindVar(name, p->id)==0)))
    p = p->prev;
  if(p==0)
    return -1;	/* shouldn't occur since assum called w/ both poss */
  else
    return p->id;
}

/* Add scope to poss_scopes */
void AddScope(poss_scopes, id)
     Scope poss_scopes;
     int id;
{
  Scope new, p;
  new = NewScope(id);
  p = poss_scopes;
  while(p->next!=0) p=p->next;
  p->next = new;
  new->prev = p;
}

/* Delete scope from poss_scopes */
void DeleteScope(poss_scopes)
     Scope poss_scopes;
{
  Scope p;
  p = poss_scopes;
  while(p->next!=0) p=p->next;
  p->prev->next = 0;
  RemoveScope(p);
}

/* Initialize poss_scopes, id = 0 (global) */
Scope InitScopes()
{
  Scope new;
  new = NewScope(0);
  return(new);
}

/* Add scope list to poss_list with first element global scope */
void AddScopeList(poss_list)
     ScopeList poss_list;
{
  ScopeList new, p;
  new = NewScopeList();
  new->scope = InitScopes();
  p = poss_list;
  while(p->next!=0) p=p->next;
  p->next = new;
  new->prev = p;
}

ScopeList FindScopeList(poss_list)
     ScopeList poss_list;
{
  ScopeList p;
  p = poss_list;
  while(p->next!=0) p=p->next;
  return p;
}

void DeleteScopeList(poss_list)
     ScopeList poss_list;
{
  ScopeList p;
  p = poss_list;
  while(p->next != 0) p = p->next;
  p->prev->next = 0;
  RemoveScopeList(p);
}

ScopeList InitScopeList()
{
  ScopeList new;
  new = NewScopeList();
  new->scope = InitScopes();
  return(new);
}

/* Update routines update the scopes for some of the pcode data-structures.  
 * Currently, these routines are being used by some of the loop-
 * transformations(e.g. distribution)  (SK)
 */
char *Update_Name(name, scopeid)
     char *name;
     int  scopeid;
{
  /* BCC - For Psplit, sometimes name is a null string - 6/30/95 */
  if (name == 0) return 0;
  return NewName(&name[1], scopeid);
}

/* Add the new_scope to the expr if it is a var. with orig_scope.*/  
void Update_Expr_Scope(expr, orig_scope, new_scope)
     Expr expr;
     int orig_scope, new_scope;
     
{
  Expr ptr;
  
  if (expr == 0) return;
  switch (expr->opcode) {
  case OP_var:
    if (FindVar(expr->value.var_name, orig_scope) != 0)
      expr->value.var_name = Update_Name(expr->value.var_name, new_scope);
    break;
  default:
    /* do nothing */
    break;
  }
  for (ptr=expr->operands; ptr!=0; ptr=ptr->sibling)
    Update_Expr_Scope(ptr, orig_scope, new_scope);
}

/* Update_ExprList_Scope calls Update_Expr_Scopefor each expr in the list */
void Update_ExprList_Scope(exprlist, orig_scope, new_scope)
     Expr exprlist;
     int orig_scope, new_scope;
{
  if (exprlist == 0) return ;
  Update_Expr_Scope(exprlist, orig_scope, new_scope);
  Update_ExprList_Scope(exprlist->next, orig_scope, new_scope);
}


void Update_Stmt_Scope(stmt, orig_scope, new_scope)
     Stmt stmt;
     int orig_scope, new_scope;
{
  if (stmt == 0) return;
  
  if (stmt->pragma != 0) 
    Update_ExprList_Scope(stmt->pragma->expr, orig_scope, new_scope); 
  
  if (stmt->labels != 0){
    if (stmt->labels->expression != 0)
      Update_Expr_Scope(stmt->labels->expression, orig_scope, new_scope); 
  } 
  
  switch (stmt->type) {
  case ST_EXPR:
    Update_ExprList_Scope(stmt->stmtstruct.expr, orig_scope, new_scope);
    break; 
  case ST_COMPOUND:
    {
      Stmt temp_stmt;
      temp_stmt = stmt->stmtstruct.compound->stmt_list;
      while (temp_stmt != 0){
	Update_Stmt_Scope(temp_stmt, orig_scope, new_scope);
	temp_stmt = temp_stmt->lex_next;
      }
    } 
    break;
  case ST_SERLOOP:
    {
      Update_Expr_Scope(stmt->stmtstruct.serloop->cond_expr, orig_scope, 
			new_scope);
      Update_Expr_Scope(stmt->stmtstruct.serloop->init_expr, orig_scope,
			new_scope);
      Update_Expr_Scope(stmt->stmtstruct.serloop->iter_expr, orig_scope,
			new_scope);
      Update_Stmt_Scope(stmt->stmtstruct.serloop->loop_body, orig_scope,
			new_scope);
    }
    break;
  case ST_IF:
    {
      Update_Expr_Scope(stmt->stmtstruct.ifstmt->cond_expr, orig_scope,
			new_scope);
      Update_Stmt_Scope(stmt->stmtstruct.ifstmt->then_block, orig_scope,
			new_scope);
      Update_Stmt_Scope(stmt->stmtstruct.ifstmt->else_block, orig_scope,
			new_scope);
    }
    break;
  case ST_SWITCH:
    {
      Update_Expr_Scope(stmt->stmtstruct.switchstmt->expression,
			orig_scope, new_scope);
      Update_Stmt_Scope(stmt->stmtstruct.switchstmt->switchbody,
			orig_scope, new_scope);
    }
    break;
  case ST_BREAK: 
  case ST_CONT: 
    break;
  case ST_RETURN:
    Update_Expr_Scope(stmt->stmtstruct.ret, orig_scope, new_scope);
    break;
  case ST_GOTO:
    break; 
  case ST_NOOP: 
    break;
  case ST_PSTMT: 
    Update_Stmt_Scope(stmt->stmtstruct.pstmt->stmt, orig_scope,    
		      new_scope);
    break;
  case ST_ADVANCE:
    break;
  case ST_AWAIT: 
    break;
  case ST_PARLOOP:
    {
      /* 1/19 - update iteration_var to expression */
      if (FindVar(stmt->stmtstruct.parloop->iteration_var->value.var_name,
		  orig_scope)!=0)
	stmt->stmtstruct.parloop->iteration_var->value.var_name =
	  Update_Name(stmt->stmtstruct.parloop->iteration_var->value.var_name, new_scope);
      
      
      Update_Expr_Scope(stmt->stmtstruct.parloop->init_value, orig_scope,
			new_scope);
      Update_Expr_Scope(stmt->stmtstruct.parloop->final_value, orig_scope,
			new_scope);
      Update_Expr_Scope(stmt->stmtstruct.parloop->incr_value, orig_scope,
			new_scope);
      Update_Stmt_Scope(stmt->stmtstruct.parloop->pstmt->stmt,
			orig_scope, new_scope);
    }
    break;
  case ST_BODY:
    Update_Stmt_Scope(stmt->stmtstruct.bodystmt->statement, orig_scope,
		      new_scope);
    break;
  case ST_EPILOGUE:
    Update_Stmt_Scope(stmt->stmtstruct.epiloguestmt->statement,
		      orig_scope, new_scope);
    break;
  case ST_MUTEX:
    {
      Update_Expr_Scope(stmt->stmtstruct.mutex->expression, orig_scope,
			new_scope);
      Update_Stmt_Scope(stmt->stmtstruct.mutex->statement, orig_scope,
			new_scope);
    } 
    break;
  case ST_COBEGIN:
    Update_Stmt_Scope(stmt->stmtstruct.cobegin->statements, orig_scope,
		      new_scope);
    break;
  default:
    Punt("Update_Stmt_Scope: unknown Stmt tag");
  }
  Update_Stmt_Scope(stmt->lex_next, orig_scope, new_scope); 
}


/*-------------------------------------------------------------*/
/* 4. Functions to Allocate New Data Structures                */
/*-------------------------------------------------------------*/

/* Allocate space for a new FuncDcl. */
FuncDcl	NewFuncDcl() {
  FuncDcl new;
  new = ALLOCATE(_FuncDcl);
  new->name = "???";
  new->type = 0;
  new->param = 0;
  new->pragma = 0;
  new->profile = 0;
  new->par_loop = 0;
  new->stmt = 0;
  new->lineno = 0;
  new->colno = 0;
  new->filename = 0;
  new->flow = 0;
  new->depend = NewFuncDepend();
  new->ext = 0;
  return new;
}

/* Allocate space for a new VarDcl. */
VarDcl NewVarDcl() {
  VarDcl new;
  new = ALLOCATE(_VarDcl);
  new->name = 0;
  new->new_name = 0;
  new->type = 0;
  new->init = 0;
  new->lineno = 0;
  new->colno = 0;
  new->filename = 0;
  new->pragma = 0;
  new->ext = 0;
  return new;
}

/* Allocate space for a new VarList. */
VarList NewVarList() {
  VarList new;
  new = ALLOCATE(_VarList);
  new->name = 0;
  new->var = 0;
  new->next = 0;
  return new;
}

/* Allocate space for a new EnumDcl. */
EnumDcl NewEnumDcl() {
  EnumDcl new = ALLOCATE(_EnumDcl);
  new->name = 0;
  new->new_name = 0;
  new->fields = 0;
  new->lineno = 0;
  new->colno = 0;
  new->filename = 0;
  return new;
}

/* Allocate space for a new EnumField. */
EnumField NewEnumField() {
  EnumField new = ALLOCATE(_EnumField);
  new->name = 0;
  new->new_name = 0;
  new->value = 0;
  new->next = 0;
  return new;
}

/* Allocate space for a new StructDcl. */
StructDcl NewStructDcl() {
  StructDcl new = ALLOCATE(_StructDcl);
  new->name = 0;
  new->new_name = 0;
  new->fields = 0;
  new->lineno = 0;
  new->colno = 0;
  new->filename = 0;
  new->ext = 0;
  /* BCC - 2/17/97 */
  new->size = 0;
  new->align = 0;
  return new;
}

/* Allocate space for a new UnionDcl. */
UnionDcl NewUnionDcl() {
  UnionDcl new = ALLOCATE(_UnionDcl);
  new->name = 0;
  new->new_name = 0;
  new->fields = 0;
  new->lineno = 0;
  new->colno = 0;
  new->filename = 0;
  new->ext = 0;
  /* BCC - 2/17/97 */
  new->size = 0;
  new->align = 0;
  return new;
}

/* Allocate space for a new Dcl */
Dcl NewDcl()
{
  Dcl new = ALLOCATE(_Dcl);
  /* since this is a union, sufficient to init one field to NULL */
  new->varDcl = 0;
  return new;
}

/* Allocate space for a new DclList */
DclList NewDclList()
{
  DclList new = ALLOCATE(_DclList);
  new->dcl = NewDcl();
  new->dcl_type = -1;
  new->next = 0;
  return new;
}

/* Allocate space for a new field. */
Field NewField() {
  Field new = ALLOCATE(_Field);
  new->name = 0;
  new->type = 0;
  new->bit_field = 0;
  new->next = 0;
  new->ext = 0;
  /* BCC - 2/17/97 */
  new->offset = 0;
  new->size = 0;
  return new;
}

/* Allocate space for a new type definition. */
TypeDcl NewTypeDcl() {
  TypeDcl new = ALLOCATE(_TypeDcl);
  new->name = 0;
  new->type = 0;
  new->lineno = 0;
  new->colno = 0;
  new->filename = 0;
  new->ext = 0;
  return new;
}

/* Allocate space for a new type. */
Type NewType() {
  Type new = ALLOCATE(_Type);
  new->type = 0;
  new->struct_name = 0;
  new->dcltr = 0;
  return new;
}

/* BCC - Allocate space for a new param. - 1/21/96 */
Param NewParam() {
  Param new = ALLOCATE(_Param);
  new->type = 0;
  new->next = 0;
  return new;
}

/* Allocate space for a new dcltr. */
Dcltr NewDcltr() {
  Dcltr new = ALLOCATE(_Dcltr);
  new->method = 0;
  new->index = 0;
  new->next = 0;
  /* BCC - added for function prototype parameters - 1/21/96 */
  new->param = 0;
  /* GEH - added for visual c++ code and ANSI C - 2/9/96 */
  new->qualifier = 0;
  return new;
}

/* Allocate space for a new Initializer. */
Init NewInit() {
  Init new = ALLOCATE(_Init);
  new->expr = 0;
  new->set = 0;
  new->next = 0;
  new->ext = 0;
  return new;
}

/* Allocate space for a new Stmt. */
Stmt NewStmt() {
  Stmt new = ALLOCATE(_Stmt);
  new->type = 0;
  new->status = 0;
  new->lineno = 0;
  new->colno = 0;
  new->filename = 0;
  new->profile = 0;
  new->pragma = 0;
  new->lex_prev = 0;
  new->lex_next = 0;
  new->labels = 0;
  new->stmtstruct.ret = 0;
  new->parent = 0;
  new->flow = 0;
  new->ext = 0;
  return new;
}

/* Allocate space for a new label */
Label NewLabel() {
  Label new = ALLOCATE(_Label);
  new->val = 0;
  new->type = 0;
  new->expression = 0;
  new->next = 0;
  new->prev = 0;
  return new;
}

/* Allocate space for a new Compound Statement */
Compound NewCompound() {
  Compound new = ALLOCATE(_Compound);
  new->stmt_list = 0;
  new->var_list = 0;
  return new;
}

/* Allocate space for a new If Statement */
IfStmt NewIfStmt() {
  IfStmt new = ALLOCATE(_IfStmt);
  new->cond_expr = 0;
  new->then_block = 0;
  new->else_block = 0;
  return new;
}

/* Allocate space for a new switch stmt */
SwitchStmt NewSwitchStmt() {
  SwitchStmt new = ALLOCATE(_SwitchStmt);
  new->expression = 0;
  new->switchbody = 0;
  return new;
}

/*  Allocate space for a new pstmt */
Pstmt NewPstmt() {
  Pstmt new = ALLOCATE(_Pstmt);
  new->stmt = 0;
  new->ext = 0;
  new->lineno = 0;
  new->colno = 0;
  new->filename = 0;
  return new;
}

/* Allocate space for a new advance stmt */
Advance NewAdvance() {
  Advance new = ALLOCATE(_Advance);
  new->marker = 0;
  return new;
}

/* Allocate space for a new await stmt */
Await NewAwait() {
  Await new = ALLOCATE(_Await);
  new->marker = 0;
  new->distance = 0;
  return new;
}

/*  Allocate space for a new mutex stmt */
Mutex NewMutex() {
  Mutex new = ALLOCATE(_Mutex);
  new->expression = 0;
  new->statement = 0;
  return new;
}

/* Allocate space for a new cobegin stmt */
Cobegin NewCobegin() {
  Cobegin new = ALLOCATE(_Cobegin);
  new->statements = 0;
  return new;
}

BodyStmt NewBodyStmt() {
  BodyStmt new = ALLOCATE(_BodyStmt);
  new->statement = 0;
  return new;
}
EpilogueStmt NewEpilogueStmt() {
  EpilogueStmt new = ALLOCATE(_EpilogueStmt);
  new->statement = 0;
  return new;
}

/* Allocate space for a new parloop stmt */
ParLoop NewParLoop() {
  ParLoop new = ALLOCATE(_ParLoop);
  new->loop_type = 0;
  new->pstmt = 0;
  new->iteration_var = 0;
  new->sibling = 0;
  new->init_value = 0;
  new->final_value = 0;
  new->incr_value = 0;
  new->child = 0;
  new->parent = 0;
  new->depth = 0;
  return new;
}

/* Allocate space for a new serloop stmt */
SerLoop NewSerLoop() {
  SerLoop new = ALLOCATE(_SerLoop);
  new->loop_type = 0;
  new->loop_body = 0;
  new->cond_expr = 0;
  new->init_expr = 0;
  new->iter_expr = 0;
  return new;
}

/* Allocate space for a new expression. */
Expr NewExpr(opcode)
     int opcode;
{
  Expr new = ALLOCATE(_Expr);
  new->opcode = opcode;
  new->status = 0;
  new->type = 0;
  new->enum_flag = 0;
  new->value.scalar = 0;
  new->sibling = 0;
  new->operands = 0;
  new->next = 0;
  new->previous = 0;
  new->pragma = 0;
  new->profile = 0;  /* LCW - add a profile field - 10/27/95 */
  new->ext = 0;
  new->ext2 = 0;
  new->acc = 0;
  new->acc2 = 0;
  new->parentstmt = 0;
  new->parentexpr = 0;
  return new;
}
/* Allocate space for a pragma. */
Pragma NewPragma(str, expr)
     char *str;
     Expr expr;
{
  Pragma new = ALLOCATE(__Pragma);
  new->specifier = str;
  new->expr = CopyExprList(expr);
  new->next = 0;
  new->filename = 0;
  return new;
}

/* Routine to create a new profile statement (SK) */

/* LCW - Allocate space for a function profile - 12/23/95 */
ProfFN NewProfFN() {
	ProfFN new = ALLOCATE(_ProfFN);
	new->fn_id = 0;
	new->count = 0.0;
	new->calls = 0;
	return new;
}

/* LCW - Allocate space for a basic block profile - 12/23/95 */
ProfBB NewProfBB() {
	ProfBB new = ALLOCATE(_ProfBB);
	new->weight = 0.0;
	new->destination = 0;
	return new;
}

/* LCW - copy the following routines from Hcode - 12/23/95 */
/*
 * Allocate space for a new call site.
 */
ProfCS NewProfCS() {
        ProfCS new = ALLOCATE(_ProfCS);
        new->call_site_id = 0;
        new->callee_id = 0;
        new->weight = 0.0;
        new->next = 0;
        return new;
}
/*
 * Allocate space for a new arc.
 */
ProfArc NewProfArc() {
        ProfArc new = ALLOCATE(_ProfArc);
        new->bb_id = 0;
        new->condition = 0;
        new->weight = 0;
        new->next = 0;
        return new;
}

/* LCW - modified for the new profile structure - 10/25/95 */
ProfST NewProfST(profinfo)
/*     int profinfo; */
     double profinfo;
{
  ProfST new = ALLOCATE(_ProfST);
/*  new->dummy = profinfo; */
  new->count = profinfo;
  new->next = NULL;
  return new;
}

/* LCW - Routine to create a new expression profile - 10/29/95 */
ProfEXPR NewProfEXPR(profinfo)
     double profinfo;
{
  ProfEXPR new = ALLOCATE(_ProfEXPR);
  new->count = profinfo;
  new->next = NULL;
  return new;
}

/* BCC - 7/3/96 */
StructUnionPoolElem NewStructUnionPoolElem(_TypeClassQual type)
{
  StructUnionPoolElem new = ALLOCATE(_StructUnionPoolElem);
  new->type = type;
  new->ptr.st = 0;
  new->ptr.un = 0;
  new->next = 0;
  return new;
}

/* Defines a basic type. */
Type NewBasicType(type)
     int type;
{
  Type new = NewType();
  new->type = type;
  return new;
}

/*-------------------------------------------------------------*/
/* 5. Functions to Remove Data Structures                      */
/*-------------------------------------------------------------*/

/* remove pragma - again will have to kludge with remove pragma
 * because of the fact that variables can be used before defined
 * in pragma expressions.
 */
static void RemovePragma(p)
     Pragma p;
{
  if (p==0) return;
  RemoveExpr(p->expr);
  p->expr = 0;
  if (p->next!=0) RemovePragma(p->next);
  p->next = 0;
  if (p->filename) free(p->filename);	/* BCC - 8/22/96 */
  DISPOSE(p);
}

/* if (pragma==0) remove all pragmas.
 * else only remove a single pragma if found.
 */
bool RemoveStmtPragma(stmt, pragma)
     Stmt stmt;
     Pragma pragma;
{
  Pragma ptr;
  if (pragma==0) {
    RemovePragma(stmt->pragma);
    stmt->pragma = 0;
    return TRUE;
  }
  for (ptr=stmt->pragma; ptr!=0; ptr=ptr->next)
    if (ptr==pragma)
      break;
  if (ptr==0) return FALSE;	/* not found */
  ptr = stmt->pragma;
  if (pragma==ptr) {
    stmt->pragma = pragma->next;
  } else {
    while (ptr->next!=pragma) ptr=ptr->next;
    ptr->next = pragma->next;
  }
  pragma->next = 0;
  RemovePragma(pragma);
  return TRUE;
}

/* BCC - remove param - 1/22/96 */
void RemoveParam(param)
     Param param;
{
  extern void RemoveType();	/* forward */
  if (param == 0) return;
  RemoveParam(param->next);
  RemoveType(param->type);
  param->next = 0;
  param->type = 0;
  DISPOSE(param);
}

/* BCC - remove Dcl - 8/18/96 */
void RemoveDcl(dcl)
     Dcl dcl;
{
  dcl->varDcl = 0;
  DISPOSE(dcl);
}

/* remove dcltr */
void RemoveDcltr(dcltr)
     Dcltr dcltr;
{
  extern void RemoveExpr();	/* forward */
  if (dcltr==0) return;
  RemoveDcltr(dcltr->next);
  RemoveExpr(dcltr->index);
  /* BCC - 1/22/96 */
  RemoveParam(dcltr->param);
  dcltr->index = 0;
  dcltr->method = 0;
  dcltr->qualifier = 0;
  DISPOSE(dcltr);
}

/* remove type */
void RemoveType(type)
     Type type;
{
  if (type==0) return;
  /* remove dcltr */
  RemoveDcltr(type->dcltr);
  type->dcltr = 0;
  DISPOSE(type);
}

/* remove type */
void RemoveTypeDcl(typedcl)
     TypeDcl typedcl;
{
  if (typedcl==0) return;
  /* remove dcltr */
  RemoveType(typedcl->type);
  typedcl->type = 0;
  free(typedcl->name);
  DISPOSE(typedcl);
}

/* define when use profile info */

/* LCW - routine to remove the function profile - 12/23/95 */
void RemoveProfFN(prof)
ProfFN prof;
{
  if (prof == 0) return;
  RemoveProfCS(prof->calls);
  prof->calls = 0;
  DISPOSE(prof);
}

/* LCW - routine to remove the basic block profile - 12/23/95 */
void RemoveProfBB(prof)
ProfBB prof;
{
  if (prof == 0) return;
  RemoveProfArc(prof->destination);
  prof->destination = 0;
  DISPOSE(prof);
}

/* LCW - routine to remove the call site - 12/23/95 */
void RemoveProfCS(prof)
ProfCS prof;
{
  if (prof == 0) return;
  RemoveProfCS(prof->next);
  prof->next = 0;
  DISPOSE(prof);
}

/* LCW - routine to remove the Arc - 12/23/95 */
void RemoveProfArc(prof)
ProfArc prof;
{
  if (prof == 0) return;
  RemoveProfArc(prof->next);
  prof->next = 0;
  DISPOSE(prof);
}

/* LCW - routine to remove the statement profile info - 10/27/95 */
void RemoveProfST(prof)
     ProfST prof;
{
  if (prof == 0) return;
  RemoveProfST(prof->next);
  prof->next = 0;
  DISPOSE(prof);
}

/* Needs to be defined later */
void RemoveProfile(profile)
     ProfFN profile;
{
}

/* LCW - routine to remove the expression profile info - 10/27/95 */
void RemoveProfEXPR(prof)
     ProfEXPR prof;
{
  if (prof == 0) return;
  RemoveProfEXPR(prof->next);
  prof->next = 0;
  DISPOSE(prof);
}

/* forward declaration */
static void RemoveExprs(Expr list);

/* remove the space allocated to an expression */
/* don't dispose of strings in value field, they are from symbol table */
/* REMOVES EXPRESSION AND ALL SIBLING, NEXT AND OPERAND EXPRESSIONS */
void RemoveExpr(expr)
     Expr expr;
{
  if (expr==0) return;
  expr->status = 0;
  /* BCC - garbage collection - 8/19/96 */
  if (expr->opcode == OP_type_size || expr->opcode == OP_expr_size)
    RemoveType(expr->value.type);
  expr->opcode = 0;
  expr->enum_flag = 0;
  /* remove type */
  if (expr->type!=0) RemoveType(expr->type);
  expr->type = 0;
  /* remove operands */
  if (expr->sibling!=0) RemoveExpr(expr->sibling);
  if (expr->operands!=0) RemoveExpr(expr->operands);
  if (expr->next!=0) RemoveExprs(expr->next);
  if (expr->pragma!=0) RemovePragma(expr->pragma);
  if (expr->profile!=0) RemoveProfEXPR(expr->profile); /* LCW */
  expr->sibling = 0;
  expr->operands = 0;
  expr->parentexpr = 0;
  expr->parentstmt = 0;
  expr->next = 0;
  expr->previous = 0;
  expr->pragma = 0;
  expr->profile = 0;   /* LCW */
  expr->ext = 0;
  expr->ext2 = 0;
  expr->acc = 0;
  expr->acc2 = 0;
  DISPOSE(expr);
}

static void RemoveExprs(list)
     Expr list;
{
  if (list==0) return;
  if (list->next!=0) RemoveExprs(list->next);
  list->next = 0;
  RemoveExpr(list);
}

void RemoveInit(init)
     Init init;
{
  if (init==0) return;
  if (init->set!=0) RemoveInit(init->set); 
  init->set = 0;
  if (init->next!=0) RemoveInit(init->next); 
  init->next = 0;
  if (init->expr!=0) RemoveExpr(init->expr);
  init->expr = 0;
  DISPOSE(init);
}

/* 4/92 - if external, then can be only dcltr of symtree.  since won't 
 * remove symtree entry (a global entry), don't remove the vardcl
 */
void RemoveVarDcl(var)
     VarDcl var;
{
  if (var==0) return;
  /* remove type */

  /* BCC, GEH - don't think this is necessary any more
  if(! (var->type->type & TY_EXTERN)) {
  */

    RemoveType(var->type);
    var->type = 0;
    /* remove init */
    if (var->init!=0) RemoveInit(var->init);
    var->init = 0;
    RemovePragma(var->pragma);

    /* BCC - free filename - 11/21/95 */
    if (var->filename) free(var->filename);
    var->filename = 0;

    /* BCC - garbage collection - 8/18/96 */
    if (var->new_name) free(var->new_name);
    var->new_name = 0;

    DISPOSE(var);
  /*
  }
  */
}

void RemoveVarList2(list)
     VarList list;
{
  if (list==0) return;
  RemoveVarList2(list->next);
  list->next = 0;
  RemoveVarDcl(list->var);
  list->var = 0;
  list->name = 0;  /* SK */
  DISPOSE(list);
}

void RemoveVarList(list)
     VarList list;
{
  if (list==0) return;
  RemoveVarList(list->next);
  list->next = 0;
  /** do not remove the VarDcl **/
  list->var = 0;
  list->name = 0;
  DISPOSE(list);
}

void RemoveLabel(label)
     Label label;
{
  if(label==0) return;
  RemoveExpr(label->expression);
  /* BCC - garbage collection - 8/20/96 */
  if (label->type == LB_LABEL)
    free(label->val);
  label->val = 0;
  label->next = 0;
  label->prev = 0;
  DISPOSE(label);
}

void RemoveLabels(list)
     Label list;
{
  if(list==0) return;
  if(list->next!=0) RemoveLabels(list->next);
  list->next = 0;
  RemoveLabel(list);
}

void RemoveCompound(stmt)
     Compound stmt;
{
  if (stmt==0) return;
  RemoveStmts(stmt->stmt_list);
  RemoveVarList(stmt->var_list);
  stmt->stmt_list = 0;
  stmt->var_list = 0;
  DISPOSE(stmt);
}

void RemoveIfStmt(stmt)
     IfStmt stmt;
{
  if (stmt==0) return;
  RemoveExpr(stmt->cond_expr);
  RemoveStmt(stmt->then_block);
  RemoveStmt(stmt->else_block);
  stmt->cond_expr = 0;
  stmt->then_block = 0;
  stmt->else_block = 0;
  DISPOSE(stmt);
}

void RemoveSwitchStmt(stmt)
     SwitchStmt stmt;
{
  if (stmt==0) return;
  RemoveExpr(stmt->expression);
  RemoveStmts(stmt->switchbody);
  stmt->expression = 0;
  stmt->switchbody = 0;
  DISPOSE(stmt);
}

void RemovePstmt(stmt)
     Pstmt stmt;
{
  if (stmt==0) return;
  RemoveStmts(stmt->stmt);
  stmt->stmt = 0;
  /* BCC - garbage collection - 8/24/96 */
  if (stmt->filename) {
    free(stmt->filename);
    stmt->filename = 0;
  }
  DISPOSE(stmt);
}

void RemoveBodyStmt(stmt)
     BodyStmt stmt;
{
  if (stmt==0) return;
  RemoveStmt(stmt->statement);
  stmt->statement = 0;
  DISPOSE(stmt);
}

void RemoveEpilogueStmt(stmt)
     EpilogueStmt stmt;
{
  if (stmt==0) return;
  RemoveStmt(stmt->statement);
  stmt->statement = 0;
  DISPOSE(stmt);
}

void RemoveAdvance(stmt)
     Advance stmt;
{
  if (stmt==0) return;
  DISPOSE(stmt);
}

void RemoveAwait(stmt)
     Await stmt;
{
  if (stmt==0) return;
  DISPOSE(stmt);
}

void RemoveMutex(stmt)
     Mutex stmt;
{
  if (stmt==0) return;
  RemoveExpr(stmt->expression);
  RemoveStmt(stmt->statement);
  stmt->expression = 0;
  stmt->statement = 0;
  DISPOSE(stmt);
}

void RemoveCobegin(stmt)
     Cobegin stmt;
{
  if (stmt==0) return;
  RemoveStmts(stmt->statements);
  stmt->statements = 0;
  DISPOSE(stmt);
}

void RemoveParLoop(stmt)
     ParLoop stmt;
{
  if (stmt==0) return;
  RemovePstmt(stmt->pstmt);
  RemoveExpr(stmt->init_value);
  RemoveExpr(stmt->final_value);
  RemoveExpr(stmt->incr_value);
  RemoveExpr(stmt->iteration_var);
  stmt->pstmt = 0;
  stmt->init_value = 0;
  stmt->final_value = 0;
  stmt->incr_value = 0;
  stmt->iteration_var = 0;
  stmt->sibling = 0;
  stmt->child = 0;
  stmt->parent = 0;
  stmt->depth = 0;
  DISPOSE(stmt);
}

void RemoveSerLoop(stmt)
     SerLoop stmt;
{
  if (stmt==0) return;
  RemoveStmt(stmt->loop_body);
  RemoveExpr(stmt->cond_expr);
  RemoveExpr(stmt->init_expr);
  RemoveExpr(stmt->iter_expr);
  stmt->loop_body = 0;
  stmt->cond_expr = 0;
  stmt->init_expr = 0;
  stmt->iter_expr = 0;
  DISPOSE(stmt);
}

void RemoveStmt(stmt)
     Stmt stmt;
{
  if (stmt==0) return;
  RemoveLabels(stmt->labels);
  switch(stmt->type) {
  case ST_NOOP:
  case ST_CONT:
  case ST_BREAK:
    break;
  case ST_GOTO:
    /* BCC - garbage collection - 8/20/96 */
    free(stmt->stmtstruct.label);
    break;
  case ST_COMPOUND:
    RemoveCompound(stmt->stmtstruct.compound);
    break;
  case ST_IF:
    RemoveIfStmt(stmt->stmtstruct.ifstmt);
    break;
  case ST_SWITCH:
    RemoveSwitchStmt(stmt->stmtstruct.switchstmt);
    break;
  case ST_PSTMT:
    RemovePstmt(stmt->stmtstruct.pstmt);
    break;
  case ST_ADVANCE:
    RemoveAdvance(stmt->stmtstruct.advance);
    break;
  case ST_AWAIT:
    RemoveAwait(stmt->stmtstruct.await);
    break;
  case ST_MUTEX:
    RemoveMutex(stmt->stmtstruct.mutex);
    break;
  case ST_COBEGIN:
    RemoveCobegin(stmt->stmtstruct.cobegin);
    break;
  case ST_PARLOOP:
    RemoveParLoop(stmt->stmtstruct.parloop);
    break;
  case ST_SERLOOP:
    RemoveSerLoop(stmt->stmtstruct.serloop);
    break;

  /* GEH - 4/26/93 added these two cases: */
  case ST_BODY:
    RemoveBodyStmt(stmt->stmtstruct.bodystmt);
    break;
  case ST_EPILOGUE:
    RemoveEpilogueStmt(stmt->stmtstruct.epiloguestmt);
    break;

  case ST_RETURN:
    RemoveExpr(stmt->stmtstruct.ret);
    break;
  case ST_EXPR:
    RemoveExpr(stmt->stmtstruct.expr);
    break;
  default:
    break;
  }
  if (stmt->profile!=0) RemoveProfST(stmt->profile);
  if (stmt->pragma!=0) RemovePragma(stmt->pragma);
  stmt->type = 0;
  stmt->status = 0;
  stmt->profile = 0;
  stmt->pragma = 0;
  stmt->lex_prev = 0;
  stmt->lex_next = 0;
  stmt->stmtstruct.ret = 0;
  stmt->parent = 0;
  stmt->labels = 0;
  RemoveStmtFlow(stmt->flow);
  stmt->flow = 0;

  /* BCC - free filename - 11/21/95 */
  if (stmt->filename) free(stmt->filename);
  stmt->filename = 0;

  DISPOSE(stmt);
}

void RemoveStmts(list)
     Stmt list;
{
  if (list==0) return;
  if (list->lex_next!=0) RemoveStmts(list->lex_next);
  list->lex_next = 0;
  RemoveStmt(list);
}

/*
 * First, dispose all internal structures.
 * Then, dispose itself.
 * !! The (type) field must not be destroyed. It is linked to
 *	the function symbol table, and will be used in the future.
 */
/* BCC - 8/25/96
 * now the type is duplicated for the symbol table and funcDcl, so we remove
 * it.
 */
FuncDcl RemoveFuncDcl(fn)
     FuncDcl fn;
{
  if (fn==0) return 0;
  /* remove parameter and local variable lists */
  RemoveVarList(fn->param); fn->param = 0;
  RemoveStmt(fn->stmt); fn->stmt = 0;
/*  RemoveProfile(fn->profile); */ /* LCW - use new routine - 12/23/95 */
  RemoveProfFN(fn->profile); fn->profile = 0;
  RemovePragma(fn->pragma); fn->pragma = 0;
  RemoveFuncFlow(fn->flow); fn->flow = 0;
  RemoveFuncDepend(fn->depend); fn->depend = 0;
  fn->par_loop = 0;		/* just remove the pointer to parloop */

  /* BCC - garbage collection - 8/25/96 */
  RemoveType(fn->type); fn->type = 0;
  /* BCC - free filename - 11/21/95 */
  if (fn->filename) free(fn->filename);
  fn->filename = 0;

  DISPOSE(fn);
  /* BCC - also need to reset bb_graph and flow_graph to NULL - 3/23/97 */
  bb_graph = NULL;
  flow_graph = NULL;
  return 0;
}

/*-------------------------------------------------------------*/
/* 6. Copy Functions                                           */
/*-------------------------------------------------------------*/

/* BCC - selectively copy the next pragma - 1/2/97 */
Pragma CopyPragma(pragma, next)
     Pragma pragma;
     int next;
{
  Pragma new;
  if (pragma==0) return 0;
  new = NewPragma(pragma->specifier, pragma->expr);
  new->lineno = pragma->lineno;
  new->colno  = pragma->colno;
  /* BCC - only copy the filename when there is one - 8/22/96 */
  if (pragma->filename) 
      new->filename = strdup(pragma->filename);
  if (next == 1)
    new->next = CopyPragma(pragma->next, 1);
  return new;
}

/* routine to copy profile st (SK) */
/*
ProfST CopyProfST(profST)
     ProfST profST;
{
  return NewProfST(profST->dummy);
}
*/

/* LCW - routine to copy function profile - 12/23/95 */
ProfFN CopyProfFN(prof)
ProfFN prof;
{
	ProfFN new;

	if (prof == 0) return 0;
	new = NewProfFN();
	new->fn_id = prof->fn_id;
	new->count = prof->count;
	new->calls = CopyProfCS(prof->calls);
	return new;
}

/* LCW - routine to copy basic block profile - 12/23/95 */
ProfBB CopyProfBB(prof)
ProfBB prof;
{
	ProfBB new;

	if (prof == 0) return 0;
        new = NewProfBB();
	new->weight = prof->weight;
	new->destination = CopyProfArc(prof->destination);
	return new;
}

/* LCW - copy the following routines from Hcode - 12/23/95 */
ProfCS CopyProfCS(cs)
ProfCS cs;
{
        ProfCS new;
        if (cs==0) return 0;
        new = NewProfCS();
        new->call_site_id = cs->call_site_id;
        new->callee_id = cs->callee_id;
        new->weight = cs->weight;
        new->next = CopyProfCS(cs->next);
        return cs;
}

ProfArc CopyProfArc(arc)
ProfArc arc;
{
        ProfArc new;
        if (arc==0) return 0;
        new = NewProfArc();
        new->bb_id = arc->bb_id;
        new->condition = arc->condition;
        new->weight = arc->weight;
        new->next = CopyProfArc(arc->next);
        return new;
}

/* LCW - new CopyProfST for the new profile structure - 10/25/95 */
ProfST CopyProfST(profST)
     ProfST profST;
{
  ProfST profPtr;

  if (profST == NULL) 
     return NULL;
  profPtr = NewProfST(profST->count);
  if (profST->next != NULL)
     profPtr->next = CopyProfST(profST->next);
  else
     profPtr->next = NULL;
  return profPtr;
}

/* LCW - copy the expression profile field - 10/29/95 */
ProfEXPR CopyProfEXPR(prof)
     ProfEXPR prof;
{
  ProfEXPR newprof;
  
  if (prof == NULL) 
     return NULL;
  newprof = NewProfEXPR(prof->count); 
  if (prof->next != NULL)
     newprof->next = CopyProfEXPR(prof->next);
  else
     newprof->next = NULL;
  return newprof;
}


/* Completely duplicate a Type. (all fields) */
Type CopyType(type)
     Type type;
{
  Type new;
  if (type==0) return 0;
  new = NewType();
  new->type = type->type;
  new->struct_name = type->struct_name;
  new->dcltr = CopyDcltr(type->dcltr);
  return new;
}

static Init CopyInit(i)
     Init i;
{
  Init new;
  if (i==0) return 0;
  new = NewInit();
  new->expr = CopyExpr(i->expr);
  new->set = CopyInit(i->set);
  new->next = CopyInit(i->next);
  return new;  
}

/* Completely duplicate an Expr. (all fields, except ext)  */
Expr CopyExpr(expr)
     Expr expr;
{
  Expr new, ptr;
  if (expr==0) return 0;
  new = NewExpr(expr->opcode);
  new->status = expr->status;
  new->enum_flag = expr->enum_flag;
  new->type = CopyType(expr->type);
  new->parentstmt = expr->parentstmt;
  new->parentexpr = expr->parentexpr;
  /* copy the pragma */
  /* BCC - added a new argument to CopyPragma() - 1/2/97 */
  new->pragma = CopyPragma(expr->pragma, 1);
  /* LCW - copy the expression profile - 10/29/95 */
  new->profile = CopyProfEXPR(expr->profile);
  switch (expr->opcode) {
  case OP_var:
    /* BCC - 8/28/96
     * in Psplit, the entry of a static local variable will be freed before
     * it is referenced by other expressions. So we have to make a separate
     * copy for the variable name.
     */
    if (split == 1)
      new->value.var_name = strdup(expr->value.var_name);
    else
      new->value.var_name = expr->value.var_name;
    break;
  case OP_int:
    new->value.scalar = expr->value.scalar;
    break;
  /* BCC - added 8/4/96 */
  case OP_float:
  case OP_double:
  case OP_real:
    new->value.real = expr->value.real;
    break;
  case OP_char:
  case OP_string:
  case OP_dot:
  case OP_arrow:
    new->value.string = expr->value.string;
    break;
  case OP_cast:
    new->value.type = new->type;
    break;
  case OP_type_size:
    new->value.type = CopyType(expr->value.type);
    break;
    /* GEH, 11/25/92, added the cases for OP_compexpr and OP_call */
    /* GEH, 4/23/92, added the cases for OP_quest and OP_index */
  case OP_compexpr:
    if (expr->operands != NIL) {
	AddOperand(new, CopyExprList(expr->operands));
    }
    return new;  /* necessary to avoid copying the operands again */
    break;
  case OP_call:
    if (expr->operands != NIL) {
	AddOperand(new, CopyExpr(expr->operands));
	AddOperand(new, CopyExprList(expr->operands->sibling));
    }
    return new;  /* necessary to avoid copying the operands again */
    break;
  case OP_quest:
    if (expr->operands != NIL) {
	AddOperand(new, CopyExpr(expr->operands));
	AddOperand(new, CopyExprList(expr->operands->sibling));
	AddOperand(new, CopyExpr(expr->operands->sibling->sibling));
    }
    return new;  /* necessary to avoid copying the operands again */
    break;
  case OP_index:
    if (expr->operands != NIL) {
	AddOperand(new, CopyExpr(expr->operands));
	AddOperand(new, CopyExprList(expr->operands->sibling));
    }
    return new;  /* necessary to avoid copying the operands again */
    break;
  default:
    /* do nothing */
    break;
  }
  /* copy the operands */
  for (ptr=expr->operands; ptr!=0; ptr=ptr->sibling)
    AddOperand(new, CopyExpr(ptr));
  return new;
}

/* CopyExprList which simply calls copyexpr repeatedly (SK) */
Expr CopyExprList(exprlist)
     Expr exprlist;
{
  Expr new_expr;
  if (exprlist == 0) return 0;
  new_expr = CopyExpr(exprlist);
  new_expr->next = CopyExprList(exprlist->next);
  /* added to set previous pointers - GEH */
  if (new_expr->next != NIL) new_expr->next->previous = new_expr;  
  return new_expr;
}

/*  (GEH) Added the following function which Completely duplicates an 
 *  expression as well as copying the access table pointers. 
 */
Expr CopyExprWithAcc(expr)
     Expr expr;
{
  Expr new, ptr;
  if (expr==0) return 0;
  new = NewExpr(expr->opcode);
  new->status = expr->status;
  new->enum_flag = expr->enum_flag;
  new->type = CopyType(expr->type);
  new->parentstmt = expr->parentstmt;
  new->parentexpr = expr->parentexpr;
  /* copy the pragma */
  /* BCC - added a new argument to CopyPragma() - 1/2/97 */
  new->pragma = CopyPragma(expr->pragma, 1);
  /* LCW - copy the expression profile - 10/29/95 */
  new->profile = CopyProfEXPR(expr->profile);
  /* copy the access pointers */
  new->acc = expr->acc;
  new->acc2 = expr->acc2;
  switch (expr->opcode) {
  case OP_var:
    new->value.var_name = expr->value.var_name;
    break;
  case OP_int:
    new->value.scalar = expr->value.scalar;
    break;
  /* BCC - added 8/4/96 */
  case OP_float:
  case OP_double:
  case OP_real:
    new->value.real = expr->value.real;
    break;
  case OP_char:
  case OP_string:
  case OP_dot:
  case OP_arrow:
    new->value.string = expr->value.string;
    break;
  case OP_cast:
    new->value.type = new->type;
    break;
  case OP_type_size:
    new->value.type = CopyType(expr->value.type);
    break;
  case OP_compexpr:
    if (expr->operands != NIL) {
	AddOperand(new, CopyExprListWithAcc(expr->operands));
    }
    return new;  /* necessary to avoid copying the operands again */
    break;
  case OP_call:
    if (expr->operands != NIL) {
	AddOperand(new, CopyExprWithAcc(expr->operands));
	if (expr->operands->sibling != NIL) 
	    AddOperand(new, CopyExprListWithAcc(expr->operands->sibling));
    }
    return new;  /* necessary to avoid copying the operands again */
    break;
    /* GEH, 4/23/92, added the cases for OP_quest and OP_index */
  case OP_quest:
    if (expr->operands != NIL) {
	AddOperand(new, CopyExprWithAcc(expr->operands));
	AddOperand(new, CopyExprListWithAcc(expr->operands->sibling));
	AddOperand(new, CopyExprWithAcc(expr->operands->sibling->sibling));
    }
    return new;  /* necessary to avoid copying the operands again */
    break;
  case OP_index:
    if (expr->operands != NIL) {
	AddOperand(new, CopyExprWithAcc(expr->operands));
	AddOperand(new, CopyExprListWithAcc(expr->operands->sibling));
    }
    return new;  /* necessary to avoid copying the operands again */
    break;
  default:
    /* do nothing */
    break;
  }
  /* copy the operands */
  for (ptr=expr->operands; ptr!=0; ptr=ptr->sibling)
    AddOperand(new, CopyExprWithAcc(ptr));
  return new;
}

/* (GEH) CopyExprListWithAcc which simply calls CopyExprWithAcc repeatedly */
Expr CopyExprListWithAcc(exprlist)
     Expr exprlist;
{
  
  Expr new_expr;
  
  if (exprlist == 0) return 0;
  new_expr = CopyExprWithAcc(exprlist);
  new_expr->next = CopyExprListWithAcc(exprlist->next);
  /* added to set previous pointers - GEH */
  if (new_expr->next != NIL) new_expr->next->previous = new_expr;  
  return new_expr;
}

/* (SK) Modifyied CopyVarDcl to append scope to the newname.  Also adding the 
 * new var. to the symbol table.
 */
VarDcl CopyVarDcl(var,scope)
     VarDcl var;
     int scope;
{
  VarDcl new;
  new = NewVarDcl();
  /* MTC - Bug fix to correct name field loss with copy functions 8/6/96 */
  new->name = NewName2(var->name);
  new->new_name = Update_Name(var->new_name,scope);
  AddVar(new->name,new->new_name,new,scope);
  new->type = CopyType(var->type);
  new->init = CopyInit(var->init);
  return new;
}

/* BCC - we need a new CopyVarDcl which won't affect the symbol table 6/30/95 */
VarDcl SP_CopyVarDcl(var)
     VarDcl var;
{
  VarDcl new;
  new = NewVarDcl();
  new->name = var->name;
  /* BCC - don't share new_name, make a separate copy - 8/28/96 */
  if (var->new_name)
    new->new_name = strdup(var->new_name);
  else
    new->new_name = 0;
  new->type = CopyType(var->type);
  new->init = CopyInit(var->init);
  return new;
}

/* (SK) Modifyied CopyVarList to append a new scope to the variables in the 
 * list. The scope should be passed in as a parameter 
 */
VarList CopyVarList(list,scope)
     VarList list;
     int scope;
{
  VarList new;
  if (list==0) return 0;
  new = NewVarList();
  /* MTC - Bug fix to correct name field loss with copy functions 8/6/96 */
  new->name = NewName2(list->name);
  new->var = CopyVarDcl(list->var,scope);
  new->next = CopyVarList(list->next,scope);
  return new;
}


/* (SK) CopyLabels to copy all the labels; the routine also
 * makes the next and the prev. pointers of the new list of labels
 * Parameters:  The label to be copied, the previous label copied, if any 
 */
Label CopyLabels(label,prev,st)
     Label label, prev;
     Stmt st;
{
  Label new_label; 
  
  if (label == 0) return 0;
  
  /* first create a new label*/
  new_label = NewLabel();
  
  /* now, set it's fields*/
  /* BCC - duplicate the val for LB_LABEL for garbage collection - 8/26/96 */
  if (label->type == LB_LABEL)
    new_label->val = strdup(label->val);
  else 
    new_label->val = label->val;
  new_label->type = label->type;
  if (label->expression != 0) 
    new_label->expression = CopyExpr(label->expression);
  LinkExpr(new_label->expression, st, 0, 0);
  new_label->prev = prev;
  new_label->next = CopyLabels(label->next,new_label,st);
  
  return new_label;
}

/* (SK) copy a serial loop*/
static SerLoop CopySerLoop(serloop,st)
     SerLoop serloop;
     Stmt st;
{
  SerLoop newloop;
  
  if (serloop == 0) return;
  newloop = NewSerLoop();
  
  newloop->loop_type = serloop->loop_type;
  
  /* copy the init, iter and cond. expr.*/
  
  if (serloop->cond_expr != 0){ 
    newloop->cond_expr = CopyExprList(serloop->cond_expr);
    LinkExpr(newloop->cond_expr, st, 0, 0);
  }  
  if (serloop->init_expr != 0) {
    newloop->init_expr = CopyExprList(serloop->init_expr);
    LinkExpr(newloop->init_expr, st, 0, 0);
  }
  if (serloop->iter_expr != 0) {
    newloop->iter_expr = CopyExprList(serloop->iter_expr);
    LinkExpr(newloop->iter_expr, st, 0, 0);
  } 
  /* copy the loop body*/
  newloop->loop_body = CopyStmt(serloop->loop_body,0,st);
  
  return newloop;
} 

/* (SK) Copy a compd stmt, create a new scope and copy varlist with this scope.
 * May need to modify the routine to change the var scopes in the stmt_list
 * also.  
 */
static Compound CopyCompound(compound, st)
     Compound compound;
     Stmt st;
{
  Compound newcomp;
  
  if (compound == 0) return;
  
  newcomp = NewCompound();
  newcomp->scope = NewScopeId();
  newcomp->stmt_list = CopyStmt(compound->stmt_list,0,st);
  newcomp->var_list  = CopyVarList(compound->var_list,0);
  newcomp->scope     = compound->scope;	
  return newcomp;
}

/* (SK)  Copy an if stmt*/
static IfStmt CopyIfStmt(ifstmt, st)
     IfStmt ifstmt;
     Stmt st;
{
  IfStmt newif; 
  
  if (ifstmt == 0) return;
  newif = NewIfStmt();
  
  newif->cond_expr = CopyExprList(ifstmt->cond_expr);
  if (newif->cond_expr != 0)
    LinkExpr(newif->cond_expr, st, 0, 0);
  newif->then_block = CopyStmt(ifstmt->then_block,0,st);
  if (ifstmt->else_block != 0)
    newif->else_block = CopyStmt(ifstmt->else_block,0,st);
  
  return newif;
}

/* (SK) Copy a switch stmt*/
static SwitchStmt CopySwitchStmt(switchstmt, st)
     SwitchStmt switchstmt;
     Stmt st;
{
  SwitchStmt newswitch;
  
  if (switchstmt == 0) return;
  newswitch = NewSwitchStmt();
  
  newswitch->expression = CopyExprList(switchstmt->expression);
  LinkExpr(newswitch->expression, st, 0, 0);  
  newswitch->switchbody = CopyStmt(switchstmt->switchbody,0,st);
  
  return newswitch;
}

/* (SK) */
static Pstmt CopyPstmt(pstmt, st)
     Pstmt pstmt;
     Stmt st;
{
  Pstmt newpstmt;
  
  if (pstmt == 0) return;
  newpstmt = NewPstmt();
  
  newpstmt->stmt = CopyStmt(pstmt->stmt,0,st);
  
  /* Note: the ext. field is not being copied currently*/
  
  return newpstmt;
}

/* (SK) */
static Advance CopyAdvance(advance)
     Advance advance;
{
  Advance newadv;
  
  if (advance == 0) return;
  newadv = NewAdvance();
  
  newadv->marker = advance->marker;
  
  return newadv;
}

static Await CopyAwait(await)
     Await await;
{
  Await newawait;
  
  if (await == 0) return;
  newawait = NewAwait();
  
  newawait->marker = await->marker;
  newawait->distance = await->distance;
  
  return newawait;
}

/* (SK)*/
static Mutex CopyMutex(mutex, st)
     Mutex mutex;
     Stmt st;
{
  Mutex newmutex;
  
  if (mutex == 0) return;
  newmutex = NewMutex();
  
  newmutex->expression = CopyExpr(mutex->expression);
  LinkExpr(newmutex->expression, st, 0, 0);
  newmutex->statement = CopyStmt(mutex->statement,0,st);
  
  return newmutex;
}

/* (SK)*/
static Cobegin CopyCobegin(cobegin, st)
     Cobegin cobegin;
     Stmt st;
{
  Cobegin newcobegin;
  
  if (cobegin == 0) return;
  newcobegin = NewCobegin();
  newcobegin->statements = CopyStmt(cobegin->statements,0,st);
  return newcobegin;
}

/* (SK)*/
static BodyStmt CopyBodyStmt(bodystmt,st)
     BodyStmt bodystmt;
     Stmt st;
{
  BodyStmt newbody;
  Stmt     new_stmt;
  Stmt temp;
  
  if (bodystmt == 0) return;
  
  newbody = NewBodyStmt();
  
  newbody->statement = CopyStmt(bodystmt->statement,0,st);
  
  return newbody;
}  

/* (SK) */
static EpilogueStmt CopyEpilogue(epilogue, st)
     EpilogueStmt epilogue;
     Stmt st;
{
  EpilogueStmt newepilogue;
  
  if (epilogue == 0) return;
  
  newepilogue = NewEpilogueStmt();
  
  if (epilogue->statement != 0)
    newepilogue->statement = CopyStmt(epilogue->statement,0,st);
  
  return newepilogue;
}

/* (SK) */
static ParLoop CopyParLoop(parloop,st)
     ParLoop parloop;
     Stmt st;
{
  ParLoop newloop;
  
  if (parloop == 0) return;
  
  newloop = NewParLoop();
  
  newloop->loop_type = parloop->loop_type;
  newloop->iteration_var = CopyExpr(parloop->iteration_var);
  
  /* not resetting the sibling ptr. here, as this is appl. dependent*/
  
  newloop->init_value = CopyExpr(parloop->init_value);
  LinkExpr(newloop->init_value, st, 0, 0);  
  newloop->incr_value = CopyExpr(parloop->incr_value);
  LinkExpr(newloop->incr_value, st, 0, 0);
  newloop->final_value = CopyExpr(parloop->final_value);
  LinkExpr(newloop->final_value, st, 0, 0);
  
  
  newloop->pstmt = NewPstmt(); 
  newloop->pstmt->lineno = parloop->pstmt->lineno;
  newloop->pstmt->colno  = parloop->pstmt->colno;
  newloop->pstmt->filename = strdup(parloop->pstmt->filename);
  
  /* not doing anything for the ext. field right now */
  
  newloop->pstmt->stmt = CopyStmt(parloop->pstmt->stmt, 0, st);
  
  return newloop;
} 

/* (SK) adding routine CopyStmt which makes a copy of the given stmt 
 *   Parameters: stmt is the stmt to be copied                       
 *               prev is the prev. stmt copied, if any
 *               parent is the parent copied, if any. 
 */
Stmt CopyStmt(stmt, prev, parent)
     Stmt stmt, prev, parent;
{
  Stmt new_stmt;
  int st_type;
  
  if (stmt == 0) return 0;
  
  /* First, create a new statement */
  new_stmt = NewStmt();
  
  /* Now, set the values of the various fields of the statement*/
  new_stmt->type = stmt->type;
  new_stmt->status = stmt->status;
  new_stmt->lineno = stmt->lineno;
  new_stmt->colno  = stmt->colno;
  if (stmt->filename)
    new_stmt->filename = strdup(stmt->filename);
  else
    new_stmt->filename = 0;
  
  /*Copying the profile info. also, this can be undone if not needed by
    re-setting dummy to 0*/
  /* LCW - modified for the new profile structure - 10/25/95 */
  if (stmt->profile != 0) {
    new_stmt->profile = NewProfST(stmt->profile->count);
    new_stmt->profile->next = stmt->profile->next;
  }
  
  /*Copy the pragmas of the original stmt*/
  /* BCC - added a new argument to CopyPragma() - 1/2/97 */
  new_stmt->pragma = CopyPragma(stmt->pragma, 1);
  
  /* Setting the lex_prev. pointer to the value passed in through prev.*/
  new_stmt->lex_prev = prev;
  
  /*Copy the labels also*/
  if (stmt->labels != 0)
    new_stmt->labels = CopyLabels(stmt->labels,0,new_stmt);
  
  
  /* Now, need to check the type of the stmt and then copy its stmtstruct*/
  
  switch (st_type = stmt->type) {
  case ST_EXPR:
    /* simply copy the exprlist of the stmt*/
    new_stmt->stmtstruct.expr = CopyExprList(stmt->stmtstruct.expr);
    break; 
  case ST_COMPOUND: 
    new_stmt->stmtstruct.compound = 
	      CopyCompound(stmt->stmtstruct.compound,new_stmt);
    break;
  case ST_SERLOOP:
    new_stmt->stmtstruct.serloop = 
	      CopySerLoop(stmt->stmtstruct.serloop,new_stmt);
    break;
  case ST_IF: 
    new_stmt->stmtstruct.ifstmt = 
	      CopyIfStmt(stmt->stmtstruct.ifstmt,new_stmt);
    break;
  case ST_SWITCH:
    new_stmt->stmtstruct.switchstmt = 
	      CopySwitchStmt(stmt->stmtstruct.switchstmt,new_stmt);
    break;
  case ST_BREAK: 
  case ST_CONT: 
    break;
  case ST_RETURN:
    if (stmt->stmtstruct.ret != 0) 
      new_stmt->stmtstruct.ret = CopyExprList(stmt->stmtstruct.ret);
    break;
  case ST_GOTO:
    new_stmt->stmtstruct.label = stmt->stmtstruct.label;
    break; 
  case ST_NOOP: 
    break;
  case ST_PSTMT: 
    new_stmt->stmtstruct.pstmt = 
	      CopyPstmt(stmt->stmtstruct.pstmt,new_stmt);
    break;
  case ST_ADVANCE:
    new_stmt->stmtstruct.advance = CopyAdvance(stmt->stmtstruct.advance);
    break;
  case ST_AWAIT: 
    new_stmt->stmtstruct.await = CopyAwait(stmt->stmtstruct.await); 
    break;
  case ST_PARLOOP:
    new_stmt->stmtstruct.parloop = 
	      CopyParLoop(stmt->stmtstruct.parloop, new_stmt);
    break;
  case ST_BODY:
    new_stmt->stmtstruct.bodystmt = 
      CopyBodyStmt(stmt->stmtstruct.bodystmt,  new_stmt);
    break;
  case ST_EPILOGUE:
    new_stmt->stmtstruct.epiloguestmt = 
	      CopyEpilogue(stmt->stmtstruct.epiloguestmt,new_stmt);
    break;
  case ST_MUTEX:
    new_stmt->stmtstruct.mutex = CopyMutex(stmt->stmtstruct.mutex,new_stmt);
    break; 
  case ST_COBEGIN:
    new_stmt->stmtstruct.cobegin = CopyCobegin(stmt->stmtstruct.cobegin,
					       new_stmt);
    break; 
  default:
    Punt("Copy_Stmt: unknown Stmt2 tag");
  }
  
  new_stmt->parent = parent;
  
  /* Don`t know what to do about the flow info. and ext yet*/
  
  new_stmt->lex_next = CopyStmt(stmt->lex_next, new_stmt, parent);
  return new_stmt;
} 

static Field CopyField(f)
     Field f;
{
  Field new;
  if (f==0) return 0;
  new = NewField();
  /* MTC - Bug fix to correct name field loss with copy functions 8/6/96 */
  new->name = NewName2(f->name);
  new->type = CopyType(f->type);
  new->bit_field = CopyExpr(f->bit_field);
  new->next = CopyField(f->next);
  return new;
}

static EnumField CopyEnumField(f)
     EnumField f;
{
  EnumField new;
  if (f==0) return 0;
  new = NewEnumField();
  /* MTC - Bug fix to correct name field loss with copy functions 8/6/96 */
  new->name = NewName2(f->name);
  new->new_name = f->new_name;
  new->value = CopyExpr(f->value);
  new->next = CopyEnumField(f->next);
  return new;
}

StructDcl CopyStructDcl(st)
     StructDcl st;
{
  StructDcl new;
  new = NewStructDcl();
  /* MTC - Bug fix to correct name field loss with copy functions 8/6/96 */
  new->name = NewName2(st->name);
  new->new_name = st->new_name;
  new->fields = CopyField(st->fields);
  /* BCC - 2/21/97 */
  new->size = st->size;
  new->align  = st->align ;
  return new;
}

UnionDcl CopyUnionDcl(un)
     UnionDcl un;
{
  UnionDcl new;
  new = NewUnionDcl();
  /* MTC - Bug fix to correct name field loss with copy functions 8/6/96 */
  new->name = NewName2(un->name);
  /* BCC - bug fix - 6/10/96 */
  new->new_name = un->new_name;
  new->fields = CopyField(un->fields);
  /* BCC - 2/21/97 */
  new->size = un->size;
  new->align  = un->align ;
  return new;
}

EnumDcl CopyEnumDcl(en)
     EnumDcl en;
{
  EnumDcl new;
  new = NewEnumDcl();
  /* MTC - Bug fix to correct name field loss with copy functions 8/6/96 */
  new->name = NewName2(en->name);
  new->name = en->new_name;
  new->fields = CopyEnumField(en->fields);
  return new;
}

/* (NJW) - fixed partially copy function dcl (fix totally if needed)
 * SK: Nancy, do you want a new scope for function declarators too? I have
 * the code inserted here, go ahead and remove it if you don't need it 
 */
FuncDcl CopyFuncDcl(fn)
     FuncDcl fn;
{
  FuncDcl new;
  new = NewFuncDcl();
  /* MTC - Bug fix to correct name field loss with copy functions 8/6/96 */
  new->name = NewName2(fn->name);
  new->type = CopyType(fn->type);
  new->param = CopyVarList(fn->param,0); /*3/93 - don't know scope, set to 0 */
  new->stmt = fn->stmt;
  new->par_loop = fn->par_loop;
  new->flow = 0;
  new->profile = CopyProfFN(fn->profile); /* LCW - 12/23/95 */
  new->ext = fn->ext;
  /* NJW - copy the statements too? */
  /* BCC - added a new argument to CopyPragma() - 1/2/97 */
  new->pragma = CopyPragma(fn->pragma, 1);
  /* NJW - copy pragma and profile too? */
  return new;
}

/*--------------------------------------------------------------------------*/
/* 7. Equivalence Functions                                                 */
/*--------------------------------------------------------------------------*/

/* Ignore the array dimension, pointer & func qualifiers. */
static bool SameDcltr(d1, d2)
     Dcltr d1, d2;
{
  if ((d1==0) && (d2==0)) return TRUE;
  if ((d1==0) || (d2==0)) return FALSE;
  if (d1->method != d2->method) return FALSE;
  return SameDcltr(d1->next, d2->next);
}

/* Ignore qualifier and class. */
bool SameType(t1, t2, name_matter)
     Type t1, t2;
     int name_matter;
{
  if ((t1==0) && (t2==0)) return TRUE;
  if ((t1==0) || (t2==0)) return FALSE;
  if ((t1->type & TY_TYPE) != (t2->type & TY_TYPE)) return FALSE;
  /* GEH - added check for structure name */
  /* BCC - 11/1/96
   * sometimes if the names are not the same, we still treat them as the same
   */
  if ((t1->type & (TY_STRUCT | TY_UNION | TY_ENUM | TY_TYPEDEF)) &&
      name_matter &&
      strcmp(t1->struct_name, t2->struct_name))
      return FALSE;
  else return SameDcltr(t1->dcltr, t2->dcltr);
}

bool SameExpr(Expr e1, Expr e2)
{
  int i;
  Expr op1, op2;
  if ((e1==0) && (e2==0)) return TRUE;
  if ((e1==0) || (e2==0)) return FALSE;
  if (e1->opcode != e2->opcode) return FALSE;
  switch (e1->opcode) {
  case OP_var:
    return (! strcmp(e1->value.var_name, e2->value.var_name));
  case OP_char:
  case OP_string:
    return (! strcmp(e1->value.string, e2->value.string));
  case OP_int:
    return (e1->value.scalar == e2->value.scalar);
  /* BCC - added 8/4/96 */
  case OP_float:
  case OP_double:
  case OP_real:
    return (e1->value.real == e2->value.real);
  default:		/* simply assume the others match */
    for (i=1; (op1=GetOperand(e1, i))!=0; i++) {
      op2 = GetOperand(e2, i);
      if (! SameExpr(op1, op2))
	return FALSE;
    }
    if ((op2=GetOperand(e2, i))!=0) return FALSE;
    return TRUE;
  }
}

static bool SameEnumField(f1, f2)
     EnumField f1, f2;
{
  if ((f1==0) && (f2==0)) return TRUE;
  if ((f1==0) || (f2==0)) return FALSE;
  if (strcmp(f1->name, f2->name)) return FALSE;
  if (! SameExpr(f1->value, f2->value)) return FALSE;
  return SameEnumField(f1->next, f2->next);
}

static bool SameField(f1, f2, name_matter)
     Field f1, f2;
     int name_matter;
{
  if ((f1==0) && (f2==0)) return TRUE;
  if ((f1==0) || (f2==0)) return FALSE;
  if (strcmp(f1->name, f2->name)) return FALSE;
  if (! SameType(f1->type, f2->type, name_matter)) return FALSE;
  if (! SameExpr(f1->bit_field, f2->bit_field)) return FALSE;
  return SameField(f1->next, f2->next, name_matter);
}

/* BCC - add options for matching names or not - 7/3/96 */
/* 1: name must match. and 2: structure must match. */
bool SameStructDcl(st1, st2, name_matter)
     StructDcl st1, st2;
     int name_matter;
{
  if (st1==st2) return TRUE;
  if (name_matter && strcmp(st1->name, st2->name)) return FALSE;
  return SameField(st1->fields, st2->fields, name_matter);
}

/* BCC - add options for matching names or not - 7/3/96 */
bool SameUnionDcl(un1, un2, name_matter)
     UnionDcl un1, un2;
     int name_matter;
{
  if (un1==un2) return TRUE;
  if (name_matter && strcmp(un1->name, un2->name)) return FALSE;
  return SameField(un1->fields, un2->fields, name_matter);
}

/* BCC - add options for matching names or not - 7/3/96 */
bool SameEnumDcl(en1, en2, name_matter)
     EnumDcl en1, en2;
     int name_matter;
{
  if (en1==en2) return TRUE;
  if (name_matter && strcmp(en1->name, en2->name)) return FALSE;
  return SameEnumField(en1->fields, en2->fields);
}

/* 
 * GEH - don't know what this is really for.  Consider using SameType
 * instead.  It makes more sense. 
 */
bool EqualType(t1, t2)
     Type t1, t2;
{
  int ty1, ty2;
  if ((t1==0) || (t2==0)) Punt("EqualType: nil formal parameter");
  if (! SameDcltr(t1->dcltr, t2->dcltr)) return FALSE;
  /*
   *	Also need to check the basic type.
   */
  ty1 = t1->type & TY_TYPE;
  ty2 = t2->type & TY_TYPE;
  if (ty1 & TY_VOID) {
    return ((ty2 & TY_VOID) != 0);
  } else
    if (ty1 & TY_CHAR) {
      return ((ty2 & TY_CHAR) != 0);
    } else
      if (ty1 & TY_SHORT) {
	return ((ty2 & TY_SHORT) != 0);
      } else
	if (ty1 & (TY_INT | TY_SIGNED | TY_UNSIGNED)) {
	  return ((ty2 & (TY_INT | TY_SIGNED | TY_UNSIGNED)) != 0);
	} else
	  if (ty1 & TY_LONG) {
	    return ((ty2 & TY_LONG) != 0);
	  } else
	    if (ty1 & TY_FLOAT) {
	      return ((ty2 & TY_FLOAT) != 0);
	    } else
	      if (ty1 & TY_DOUBLE) {
		return ((ty2 & TY_DOUBLE) != 0);
	      } else
		if (ty1 & (TY_STRUCT | TY_UNION | TY_ENUM | TY_TYPEDEF)) {
		  if (ty1 != ty2) return FALSE;
		  return (! strcmp(t1->struct_name, t2->struct_name));
		} else {
		  return (ty1==ty2);
		} 
}

/*-------------------------------------------------------------*/
/* 8. Symbol Tree/Table Access Functions                       */
/*-------------------------------------------------------------*/

/* Add/find a type definition in the symbol tree. */
void AddTypeDef(name, ty)
     char *name;
     TypeDcl ty;
{
  Symbol sym;
  sym = AddSym(SymbolTable[TBT_TYPEDEF], name, 0);
  sym->ptr = ty;
}

TypeDcl FindTypeDef(name)
     char *name;
{
  Symbol sym;
  sym = FindSym(SymbolTable[TBT_TYPEDEF], name, 0);
  if(sym==0)
    return 0;
  else
    return(sym->ptr);
}

/* Add/find a structure definition in the symbol tree. */
void AddStruct(name, rename, st, scope_id)
     char *name;
     char *rename;
     StructDcl st;
     int scope_id;
{
  SymTree sym;
  sym = AddSymT(name, scope_id, TT_STRUCT);
  sym->dcl.structDcl = st;
  sym->status = 1;      /* BCC - structDcl is exclusively pointed - 11/20/95 */
  if(rename != 0) {
  /*========================================================================*\
   * BCC - When inlining, the new name may be the same as the old name. In
   * this case we don't want the new name to screw up the old name. 11/22/95
  \*========================================================================*/
    if (!strcmp(name, rename)) return;
    sym = AddSymT(rename, scope_id, TT_STRUCT);
    sym->dcl.structDcl = st;
    sym->status = 0;    /* BCC - structDcl is shared - 11/20/95 */
  }
}

StructDcl FindStruct(name, scope_id)
     char *name;
     int scope_id;
{
  SymTree sym;
  int i;

  /* BCC - search through the pool first - 10/29/96 */
  for (i=0; i<max_struct_union_pool; i++) {
    if (!strcmp(name, StructUnion_Pool[i].name)) break;
  }
  if ( i != max_struct_union_pool )
    name = StructUnion_Pool[i].new_name;

  sym = FindSymT(name, scope_id, TT_STRUCT);
  if (sym==0) 
    return 0;
  else
    return (sym->dcl.structDcl);
}

/* after renaming, don't need scopeid  */
StructDcl FindStructNoScopeId(name)
     char *name;
{
  SymTree sym;
  int i;

  /* BCC - search through the pool first - 10/29/96 */
  for (i=0; i<max_struct_union_pool; i++) {
    if (!strcmp(name, StructUnion_Pool[i].name)) break;
  }
  if ( i != max_struct_union_pool )
    name = StructUnion_Pool[i].new_name;

  sym = FindSymT_NoScopeId(name, TT_STRUCT);
  if (sym==0) 
    return 0;
  else
    return (sym->dcl.structDcl);
}

void AddUnion(name, rename, un, scope_id)
     char *name;
     char *rename;
     UnionDcl un;
     int scope_id;
{
  SymTree sym;
  sym = AddSymT(name, scope_id, TT_UNION);
  sym->dcl.unionDcl = un;
  sym->status = 1;      /* BCC - unionDcl is exclusively pointed - 11/20/95 */
  if(rename != 0) {
  /*========================================================================*\
   * BCC - When inlining, the new name may be the same as the old name. In
   * this case we don't want the new name to screw up the old name. 11/22/95
  \*========================================================================*/
    if (!strcmp(name, rename)) return;
    sym = AddSymT(rename, scope_id, TT_UNION);
    sym->dcl.unionDcl = un;
    sym->status = 0;    /* BCC - unionDcl is shared - 11/20/95 */
  }
}

UnionDcl FindUnion(name, scope_id)
     char *name;
     int scope_id;
{
  SymTree sym;
  int i;

  /* BCC - search through the pool first - 10/29/96 */
  for (i=0; i<max_struct_union_pool; i++) {
    if (!strcmp(name, StructUnion_Pool[i].name)) break;
  }
  if ( i != max_struct_union_pool )
    name = StructUnion_Pool[i].new_name;

  sym = FindSymT(name, scope_id, TT_UNION);
  if (sym==0) 
    return 0;
  else
    return (sym->dcl.unionDcl);
}

UnionDcl FindUnionNoScopeId(name)
     char *name;
{
  SymTree sym;
  int i;

  /* BCC - search through the pool first - 10/29/96 */
  for (i=0; i<max_struct_union_pool; i++) {
    if (!strcmp(name, StructUnion_Pool[i].name)) break;
  }
  if ( i != max_struct_union_pool )
    name = StructUnion_Pool[i].new_name;

  sym = FindSymT_NoScopeId(name, TT_UNION);
  if (sym==0) 
    return 0;
  else
    return (sym->dcl.unionDcl);
}

Field FindStructField(st, name)
     StructDcl st;
     char *name;
{
  Field ptr;
  if (st==0) return 0;
  for (ptr=st->fields; ptr!=0; ptr=ptr->next) {
    if (! strcmp(ptr->name, name))
      break;
  }
  return ptr;
}

Field FindUnionField(un, name)
     UnionDcl un;
     char *name;
{
  Field ptr;
  if (un==0) return 0;
  for (ptr=un->fields; ptr!=0; ptr=ptr->next) {
    if (! strcmp(ptr->name, name))
      break;
  }
  return ptr;
}

void AddEnum(name, rename, en, scope_id)
     char *name;
     char *rename;
     EnumDcl en;
     int scope_id;
{
  SymTree sym;
  sym = AddSymT(name, scope_id, TT_ENUM);
  sym->dcl.enumDcl = en;
  sym->status = 1;      /* BCC - enumDcl is exclusively pointed - 11/20/95 */
  if(rename != 0) {
  /*========================================================================*\
   * BCC - When inlining, the new name may be the same as the old name. In
   * this case we don't want the new name to screw up the old name. 11/22/95
  \*========================================================================*/
    if (!strcmp(name, rename)) return;
    sym = AddSymT(rename, scope_id, TT_ENUM);
    sym->dcl.enumDcl = en;
    sym->status = 0;    /* BCC - enumDcl is shared - 11/20/95 */
  }
}

EnumDcl FindEnum(name, scope_id)
     char *name;
     int scope_id;
{
  SymTree sym;
  sym = FindSymT(name, scope_id, TT_ENUM);
  if (sym==0)
    return 0;
  else
    return sym->dcl.enumDcl;
}

EnumDcl FindEnumNoScopeId(name)
     char *name;
{
  SymTree sym;
  sym = FindSymT_NoScopeId(name, TT_ENUM);
  if (sym==0)
    return 0;
  else
    return sym->dcl.enumDcl;
}

/* This is used to add enumfields to a symbol tree which will
 * be checked for multiple definitions - since a variable name that
 * is the same name as an enum field is a redeclaration of a variable
 * the enumdcl is stored in the symbol tree but likely not needed (?)
 */
void AddEnumField(name, rename, en, scope_id)
     char *name;
     char *rename;
     EnumDcl en;
     int scope_id;
{
  SymTree sym;
  sym = AddSymT(name, scope_id, TT_ENUMFIELD);
  sym->dcl.enumDcl = en;
  sym->status = 1;      /* BCC - enumDcl is exclusively pointed - 11/20/95 */
  if(rename != 0) {
  /*========================================================================*\
   * BCC - When inlining, the new name may be the same as the old name. In
   * this case we don't want the new name to screw up the old name. 11/22/95
  \*========================================================================*/
    if (!strcmp(name, rename)) return;
    sym = AddSymT(rename, scope_id, TT_ENUMFIELD);
    sym->dcl.enumDcl = en;
    sym->status = 0;    /* BCC - enumDcl is shared - 11/20/95 */
  }
}

EnumDcl FindEnumField(name, scope_id)
     char *name;
     int scope_id;
{
  SymTree sym;
  sym = FindSymT(name, scope_id, TT_ENUMFIELD);
  if (sym==0)
    return 0;
  else
    return sym->dcl.enumDcl;
}

EnumDcl FindEnumFieldNoScopeId(name)
     char *name;
{
  SymTree sym;
  sym = FindSymT_NoScopeId(name, TT_ENUMFIELD);
  if (sym==0)
    return 0;
  else
    return sym->dcl.enumDcl;
}

EnumField FindEnumFieldInEnum(en, name)
     EnumDcl en;
     char *name;
{
  EnumField ptr;
  if (en==0) return 0;
  for (ptr=en->fields; ptr!=0; ptr=ptr->next) {
    /* DIA - Added shortcut in case ptr->new_name is NULL */
    if ((! strcmp(ptr->name, name)) || (ptr->new_name && !strcmp(ptr->new_name,
name)))
      break;
  }
  return ptr;
}

/* add variable to symbol tree using both its old and new names if it
 * has been renamed.  This allows for reading in the references to the
 * old name and converting them to the new name.  During transformations,
 * all references will be to the new name. 
*/
void AddVar(name, rename, var, scope_id)
     char *name;
     char *rename;
     VarDcl var;
     int scope_id;
{
  SymTree sym;
  sym = AddSymT(name, scope_id, TT_VAR);
  sym->dcl.varDcl = var;
  sym->status = 1;      /* BCC - varDcl is exclusively pointed - 11/20/95 */
  if(rename!=0) {
  /*========================================================================*\
   * BCC - When inlining, the new name may be the same as the old name. In
   * this case we don't want the new name to screw up the old name. 11/22/95
  \*========================================================================*/
    if (!strcmp(name, rename)) return;
    sym = AddSymT(rename, scope_id, TT_VAR);
    sym->dcl.varDcl = var;
    sym->status = 0;    /* BCC - varDcl is shared - 11/20/95 */
  }
}

void ReplaceVar(char *name, VarDcl var, int scope_id)
{
    SymTree sym;

    sym = FindSymT(name, scope_id, TT_VAR);

    if (sym != NIL) {
	RemoveVarDcl (sym->dcl.varDcl);
	sym->dcl.varDcl = var;
        /* BCC - This will be freed by ResetSymbolTables() - 11/21/95 */
        sym->status = 1;
    }
    else {
	sym = AddSymT(name, scope_id, TT_VAR);
	sym->dcl.varDcl = var;
        /* BCC - This will be freed by ResetSymbolTables() - 11/21/95 */
        sym->status = 1;
    }
}


VarDcl FindVar(name, scope_id)
     char *name;
     int scope_id;
{
  SymTree sym;
  sym = FindSymT(name, scope_id, TT_VAR);
  if (sym==0)
    return 0;
  else
    return sym->dcl.varDcl;
}

VarDcl FindVarNoScopeId(name)
     char *name;
{
  SymTree sym;
  sym = FindSymT_NoScopeId(name, TT_VAR);
  if (sym==0)
    return 0;
  else
    return sym->dcl.varDcl;
}

void AddFunction(name, return_type)
     char *name;
     Type return_type;
{
  Symbol sym;
  sym = AddSym(SymbolTable[TBT_FUNC], name, 0);
  sym->ptr = return_type;
}

Symbol FindFunction(name)
     char *name;
{
  Symbol sym;
  sym = FindSym(SymbolTable[TBT_FUNC], name, 0);
  if (sym==0)
    return 0;
  else
    return sym;
}

/* from dd_lang-interf.c (GEH) */

/* Return a pointer to the variable declaration structure in the symbol table
 * for the given variable name. 
 * Return a null pointer if variable not found in symbol table. 
 */
VarDcl var_name_to_var_dcl(var_name)
char *var_name;
{
    return FindVarNoScopeId(var_name);
}

/* Return a pointer to the variable declaration structure in the symbol table
 * for the given variable expression.
 * Return a null pointer if variable not found in symbol table. 
 */
VarDcl var_expr_to_var_dcl(var_expr)
Expr var_expr;
{
    char *scope_str;

    assert(var_expr->opcode == OP_var);
    assert(!var_expr->enum_flag);

    return var_name_to_var_dcl(var_expr->value.var_name);
}

/* Return a pointer to the enumeration field structure in the symbol
 * table for the given enumeration value expression. (opcode == OP_var.)
 * Return a null pointer if enumeration field not found in symbol table. 
 */
EnumField enum_expr_to_enum_field(enum_expr)
Expr enum_expr;
{
    EnumDcl enum_dcl;

    assert(enum_expr->opcode == OP_var);
    assert(enum_expr->enum_flag);

    if ((enum_dcl = FindEnumFieldNoScopeId(enum_expr->value.var_name)) == NIL)
        return NIL;
    else
        return FindEnumFieldInEnum(enum_dcl, enum_expr->value.var_name);
}

/*--------------------------------------------------------------------------*/
/* 9. Variable Manipulation Functions                                       */
/*--------------------------------------------------------------------------*/

VarDcl FindVarList(list, name)
     VarList list;
     char *name;
{
  register VarList l;
  if ((name==0) || (name[0]=='\0'))
    Punt("FindVarList: argument cannot be a NULL string"); /* 6-90 */
  for (l=list; l!=0; l=l->next) {
    char *nm = l->name;
    if ((nm==0) || (nm[0]=='\0')) {
      Punt("FindVarList: corrupted argument list"); /* 6-90 */
    }
    if (! strcmp(nm, name))
      return l->var;
  }
  return 0;
}

VarList AddVar2List(list, var)
     VarList list;
     VarDcl var;
{
  register VarList new, l;
#ifdef TEST_VARLIST
  {
    VarList l;  int n=0;
    printf("-------------------------------------------------\n");
    printf("### List (before) = (\n");
    for (l=list; l!=0; l=l->next) {
      printf("(0x%x) ", l);
      fflush(stdout);
      printf("%s, ", l->name);
      n++;
      if ((n%3)==0) printf("\n");
      fflush(stdout);
    }
    printf(")\n");
  }
#endif
  if (FindVarList(list, var->name) != 0)
    return list;
  new = NewVarList();
  /* MTC - Bug fix to correct name field loss with copy functions 8/6/96 */
  new->name = NewName2(var->name);
  new->var = var;
  if (list==0) {
    list = new;
  } else {
    l = list;
    while (l->next!=0)
      l = l->next;
    l->next = new;
  }
#ifdef TEST_VARLIST
  {
    VarList l; int n=0;
    printf("### AddVar2List(%s, 0x%x)\n", new->name, new);
    printf("### List (after) = (\n");
    for (l=list; l!=0; l=l->next) {
      printf("(0x%x) ", l);
      fflush(stdout);
      printf("%s, ", l->name);
      n++;
      if ((n%3)==0) printf("\n");
      fflush(stdout);
    }
    printf(")\n");
  }
#endif
  return list;
}

/* (SK) Adding routine MoveVarList which moves the variables from one varlist
 *  to another, updating the scopes along the way.  
 */
void MoveVarList(orig_varlist, new_varlist, orig_scope, new_scope)
     VarList orig_varlist, new_varlist;
     int orig_scope, new_scope;
{
  VarList temp;
  
  temp = new_varlist;
  while (temp->next != 0)
    temp = temp->next;
  temp->next = CopyVarList(orig_varlist, new_scope);
  RemoveVarList(orig_varlist);
  orig_varlist = 0;
}

/*
 * Find the nearest enclosing compound statement for the given statement, and
 * return  a POINTER to it's varlist.  
 * Also return the scope of the compound stmt. or function. through reference
 * parameter.
 * If there is no enclosing compound statement for the given statement, 
 * return NIL and set scope to zero.  (This should not happen if statement
 * is part of a valid function.)
 */
VarList *FindNearestEnclVarList(stmt, scope)
    Stmt stmt;
    int *scope;
{
    assert(stmt != NIL);
    stmt = stmt->parent;

    while (stmt != NIL && stmt->type != ST_COMPOUND) stmt = stmt->parent;
    if (stmt == NIL) { 
	*scope = 0; 
	return NIL; 
    }
    else {
	*scope = stmt->stmtstruct.compound->scope;
	return &(stmt->stmtstruct.compound->var_list);
    }
}


/* In order to rename variables during parsing, a symtree entry is
entered for both a var's name and it's new_name.  Upon exiting the each
compound statement during parsing, we invalidate the unrenamed symtree entry 
so the name does not conflict with other scope declarations of the same
name */

void InvalidateVarListSyms(VarList varlist, int scope)
{
    VarList vl;
    SymTree sym;
    
    if (varlist == NIL)
	return;

    for (vl = varlist; vl != NIL; vl = vl->next) {
	sym = FindSymT (vl->var->name, scope, TT_VAR);
/*
	assert (sym != NIL);
*/
	if (sym != NIL)
	    sym->scope_id = -1;
    }

}


/*
 * Check to see if a variable by the given name with the given type already
 * exists in the given VarList.  If so, simply return the variable, otherwise
 * if the variable is not already in the list with a different type, 
 * add the variable to both the VarList and the Symbol table and then return
 * the variable.  If the variable is already in the list with a different type,
 * return NIL.
 * Note that a pointer to the varlist should be passed to the
 * function since the varlist might have the variable added to it.
 */

VarDcl CreateLocalVar(var_name, scope, varlist_ptr, type)
    char *var_name;
    int scope;
    VarList *varlist_ptr;
    Type type;
{
    VarDcl new_var, match_var;

    if ((match_var = FindVarList(*varlist_ptr, var_name)) == 0) {
        /* if variable does not already exist */

        new_var = NewVarDcl();
        new_var->name = NewName2(var_name);
	new_var->new_name = NewName(var_name, scope);

        new_var->type = type;
        AddVar(new_var->name, new_var->new_name, new_var, scope);
        *varlist_ptr = AddVar2List(*varlist_ptr, new_var);

        return new_var;
    }
    if (SameType(match_var->type, type, 1)) return match_var;
    else return NIL;
}

/* 
 * Same as CreateLocalVar except uses basic type as argument.
 */
VarDcl CreateLocalVarBasicType(var_name, scope, varlist_ptr, basic_type)
    char *var_name;
    int scope;
    VarList *varlist_ptr;
    int basic_type;
{
    return CreateLocalVar(var_name, scope, varlist_ptr, NewBasicType(basic_type));
}

/* 
 * GEH -
 * Create a new global variable with specified name and type.
 * If a global variable with the same name and type exists, return its
 * vardcl and don't create a new one.
 * If a global variable with the same name and different type exists,
 * return null.
 * If no variable exists with the specified name, create a new one and
 * return its vardcl 
 */
VarDcl CreateGlobalVar(var_name, type)
    char *var_name;
    Type type;
{
    VarDcl v;
    if((v = FindVar(var_name, 0)) != 0) {
	if(SameType(v->type, type, 1)) 
	    return v;
	else 
 	    return 0;
    } else {
	if(FindVarNoScopeId(var_name) != 0)     
	    return 0;
	else {
	    v = NewVarDcl();
	    v->new_name = NewName2(var_name);
	    v->type = type;
	    AddVar(v->new_name, v->new_name, v, 0);     
	    return v;
	}
    }
}

/* Function to create function variables 
 * -- note that caller should set return_type, if function not static, 
 *    then should default to extern  
 *    (e.g. int F() --> return_type = TY_INT | TY_EXTERN)
 * -- caller should create the string for the fn_name;
 * -- when reading in pcode, cannot determine if a variable is a func name
 *    or not since it may be external and not explicitly declared in this file
 *    for such cases, it is placed in global scope without renaming and marked
 *    external.  the consequence here is that if we find a global variable 
 *    with the same name as the function name and the same type, we will 
 *    assume it is the desired function and return the vardcl.
 * -- function returns the new vardcl if func var is created, the existing
 *    vardcl if a valid one exists, or 0 indicating that the fn_name conflicts
 *    with another variable in the function. 
 */
VarDcl CreateFuncVar(fn_name, return_type)
     char *fn_name;
     int return_type;
{
  VarDcl v;
  Type type;
  if((v = FindVar(fn_name, 0)) != 0) {
    if((v->type->type & return_type) == 0) 
      return 0;
    else 
      return v;
  } else {
    if(FindVarNoScopeId(fn_name) != 0)     
      return 0;    
    else {
      v = NewVarDcl();
      v->name = fn_name;
      v->type = NewType();
      v->type->type = return_type;
      v->type->dcltr = NewDcltr();
      v->type->dcltr->method = D_FUNC;
      AddVar(fn_name, 0, v, 0);     
    }
  }
  return v;
}

/*-------------------------------------------------------------*/
/* 10. Dcltr Manipulation Functions                            */
/*-------------------------------------------------------------*/

/* BCC - Completely duplicate a Param - 1/21/96 */
Param CopyParam(param)
     Param param;
{
  Param new;
  if (param == 0) return 0;
  new = NewParam();
  new->type = CopyType(param->type);
  if (param->next!=0)
    new->next = CopyParam(param->next);
  return new;
}

/* Completely duplicate a Dcltr. */
Dcltr CopyDcltr(dcltr)
     Dcltr dcltr;
{
  Dcltr new;
  if (dcltr==0) return 0;
  new = NewDcltr();
  new->method = dcltr->method;
  if (dcltr->index!=0)
    new->index = CopyExpr(dcltr->index);
  new->qualifier = dcltr->qualifier;
  new->next = CopyDcltr(dcltr->next);
  /* BCC - 1/21/96 */
  if (dcltr->param!=0)
    new->param = CopyParam(dcltr->param);
  return new;
}

Dcltr ConcatDcltr(A, B)
     Dcltr A, B;
{
  Dcltr ptr;
  if (A==0) return B;
  if (B==0) return A;
  for (ptr=A; ptr->next!=0; ptr=ptr->next) ;
  ptr->next = B;
  return A;
}

Dcltr ReverseDcltr(A)
     Dcltr A;
{
  Dcltr ptr;
  if (A==0) return 0;
  ptr = A->next;
  A->next = 0;
  return (ConcatDcltr(ReverseDcltr(ptr), A));
}

/*-------------------------------------------------------------*/
/* 11. Expression Manipulating Functions                       */
/*-------------------------------------------------------------*/

/* Add operand to an expression.
 * !! The sibling field of expr2 must not be changed, so we
 *    can simulate adding several operands at once. 
 */
void AddOperand(expr1, expr2)
     Expr expr1, expr2;
{
  Expr ptr;
  if (expr1==0) Punt("AddOperand: expr1 is nil");
  /* GEH - added the following line:  (4/23/92) */
  if (expr2==0) return;
  ptr = expr1->operands;
  if (ptr==0) {
    expr1->operands = expr2;
    /* Set the parentexpr field of expr2 also SK */
    expr2->parentexpr = expr1;
  } else {
    while (ptr->sibling!=0) ptr = ptr->sibling;
    ptr->sibling = expr2;
    /* Set the parentexpr field of expr2 also SK */
    expr2->parentexpr = expr1;
  }
}

/* Add operand expr2 into next field of expr1.  this is how comma expressions
 *  within expressions are handled. 
 */
void AddNextOperand(expr1, expr2)
     Expr expr1, expr2;
{
  Expr ptr;
  if(expr1 == 0)
    Punt("AddNextOperand: expr1 is nil");
  ptr = expr1;
  while(ptr->next!=0) ptr = ptr->next;
  ptr->next = expr2;
}

/* Concatenate expression list expr2 onto the end of expression list expr1.  
 * and return a pointer to the whole list.   DML 1/27/96
 */
Expr ConcatNextExpr(expr1, expr2)
     Expr expr1, expr2;
{
  Expr ptr;

  if(expr1 == NULL)
      return (expr2);
  if(expr2 == NULL)
      return (expr1);
  if(expr2->previous != NULL)
    Punt("ConcatNextExpr: expr2 is not the beginning of an expression list");

  ptr = expr1;
  while(ptr->next!=0) ptr = ptr->next;
  ptr->next = expr2;
  expr2->previous = ptr;

  return (expr1);
}

/* Get last operand when have comma expression (as formed by AddNextOperand) */
Expr GetLastOperand(expr)
     Expr expr;
{
  while(expr->next!=0) expr = expr->next;
  return(expr);
}

/* 
 * Find the number of the operand of expr in which child_expr is found.  
 * If not found, or expr has no operands, return 0. (GEH)
 */
int FindOperandNumber(expr, child_expr)
    Expr expr, child_expr;
{
  int number = 1;
  Expr next_expr;

  expr = expr->operands;
  while (expr != NIL) {
    if (expr == child_expr) return number;
    next_expr = expr->next;
    while (next_expr != NIL) {
      if (next_expr == child_expr) return number;
      next_expr = next_expr->next;
    }
    expr = expr->sibling;
    number++;
  }
  return 0;
}

/* Get the Nth operand. 0 means itself. */
Expr GetOperand(expr, N)
     Expr expr;
     int N;
{
  if (N<=0) return expr;
  expr = expr->operands;
  while ((--N)!=0) {
    if (expr==0)	/* not found, return 0 */
      return 0;
    expr = expr->sibling;
  }
  return expr;
}

/* DIA - 4/31/94: Added this function. Traversal of next fields was needed. */
/* Get the Nth next operand. 0 means itself. */
Expr GetNextOperand(expr, N)
     Expr expr;
     int N;
{
  if (N<=0) return expr;
  expr = expr->next;
  while ((--N)!=0) {
    if (expr==0)        /* not found, return 0 */
      return 0;
    expr = expr->next;
  }
  return expr;
}

/* Change the Nth operand. do nothing if the Nth operand does not exist. */
void ChangeOperand(expr, N, operand)
     Expr expr; 
     int N;
     Expr operand;
{
  Expr ptr;
  if (N<=0) return;
  if (operand->sibling!=0)
    Punt("ChangeOperand: illegal operand");
  /** first find the operand **/
  ptr = expr->operands;
  while ((--N)!=0) {
    if (ptr==0)	/* not found, return */
      return;
    ptr = ptr->sibling;
  }
  /** replace the operand by the formal parameter **/
  operand->sibling = ptr->sibling;
  ptr->sibling = 0;
  if (ptr==expr->operands) {
    expr->operands = operand;
  } else {
    expr = expr->operands;
    while (expr->sibling!=ptr)
      expr = expr->sibling;
    expr->sibling = operand;
  }
}

/* 
 * Replace expr1 with expr2.  Expr2 plus all its next expressions replace expr1.
 * Only successful if expr1 has parentexpr.  Return whether or not successful.
 * Expr1 is not freed but just detached from the rest of the structure.
 * Parent pointers are also updated.
 */
bool ReplaceExprWithExprList(expr, exprlist)
     Expr expr, exprlist;
{
    Expr parent, first_expr, next_expr, last_expr;
    int op_num;

    if (expr->parentexpr == NIL) return FALSE;
    parent = expr->parentexpr;
    first_expr = GetOperand(parent, op_num = FindOperandNumber(parent, expr));
    if (first_expr == parent) return FALSE;

    if (first_expr == expr) {
	last_expr = GetLastOperand(exprlist);
	last_expr->next = expr->next;
	if (expr->next != NIL) expr->next->previous = last_expr;
	exprlist->previous = NIL;
	ChangeOperand(parent, op_num, exprlist);
    }
    else {
	last_expr = GetLastOperand(exprlist);
	last_expr->next = expr->next;
	if (expr->next != NIL) expr->next->previous = last_expr;
	exprlist->previous = expr->previous;
	if (expr->previous != NIL) expr->previous->next = exprlist;
    }

    expr->next = NIL;
    expr->previous = NIL;
    expr->sibling = NIL;
    LinkExpr(exprlist, parent->parentstmt, parent, exprlist->previous);
    return TRUE;
}


/* Create an arbitrary expression, whose type is known.
 * The actual parameter is absorbed. Therefore, the caller
 * must duplicate the formal parameter before calling this
 * function (or sharing will occur: which is an error).
 * The caller must fill in the (value) field.
 */
Expr NewInstExpr(opcode, type)
     int opcode;
     Type type;
{
  Expr new = NewExpr(opcode);
  new->type = type;
  return new;
}

/* Create PRIMITIVE expressions. */

/* Pointer to the variable name is copied. */
/* Type parameter is NOT copied, must pass in copy or new type */
Expr NewVarExpr(var_name, type)
     char *var_name;
     Type type;
{
  Expr new = NewExpr(OP_var);
  new->value.var_name = var_name;
  new->type = type;
  CastExpr(new);
  return new;
}

Expr NewIntExpr(value)
     int value;
{
  Expr new = NewExpr(OP_int);
  new->value.scalar = value;
  CastExpr(new); 
  return new;
}

Expr NewRealExpr(value)
     double value;
{
  Expr new = NewExpr(OP_real);
  new->value.real = value;
  CastExpr(new);
  return new;
}

/* BCC - added 8/4/96 */
Expr NewFloatExpr(value)
     double value;
{
  Expr new = NewExpr(OP_float);
  new->value.real = value;
  CastExpr(new);
  return new;
}

/* BCC - added 8/4/96 */
Expr NewDoubleExpr(value)
     double value;
{
  Expr new = NewExpr(OP_double);
  new->value.real = value;
  CastExpr(new);
  return new;
}

Expr NewCharExpr(ch)
     char *ch;
{
  Expr new = NewExpr(OP_char);
  new->value.string = ch;
  CastExpr(new);
  return new;
}

Expr NewStringExpr(str)
     char *str;
{
  Expr new = NewExpr(OP_string);
  new->value.string = str;
  CastExpr(new);
  return new;
}

/* (SK) NewDualOpExpr creates a new dual op expr of the given type with the 
 * given operands.  Note that new copies of the operands are NOT created; 
 * rather, they are pointed to by the structure. 
 */
Expr NewDualOpExpr(op_type, operand_1, operand_2)
     int op_type;
     Expr operand_1, operand_2;
{
  Expr new = NewExpr(op_type);
  AddOperand(new, operand_1);
  AddOperand(new, operand_2);
  new->type = NewType();
  CastExpr(new);
  return new;
}

Expr NewSingleOpExpr(op_type, operand)
     int op_type;
     Expr operand;
{
  Expr new = NewExpr(op_type);
  new->type = NewType();
  AddOperand(new, operand);
  CastExpr(new);
  return new;
}

bool IsPcodeTemp(expr)
Expr expr;
{
    char *s;

    if (expr->opcode != OP_var) return FALSE;
    s = expr->value.var_name;
    if (s[0] == 'P' && s[1] == '_' && isdigit(s[2])) return TRUE;
    else return FALSE;
}

/* (GEH) added function to determine if first expression is the ancestor of 
 * the second expression. 
 */
bool IsAncestorOfExpr(e1, e2)
     Expr e1, e2;
{
  while (e2 != 0) {
    if (e2 == e1) return TRUE;
    e2 = e2->parentexpr;
  }
  return FALSE;
}

/* 
 * (GEH) added function to determine if first expression is a descendent of 
 * the second expression, but not through the first (leftmost) operand. 
 */
bool IsRightDescendentOfExpr(e1, e2)
     Expr e1, e2;
{
  while (e1 != 0 && e2 != e1 && e1 != e2->operands) e1 = e1->parentexpr;
  if (e1 == 0 || e2 != e1) return FALSE;
  else return TRUE;
}

/*
 * (GEH) Returns TRUE if e1 precedes e2 in the same expression list.  
 * Otherwise, returns false.
 */
bool DoesExprPrecedeExprInExprList(e1, e2)
    Expr e1, e2;
{
    if (e1 == e2) return FALSE;
    while (e1 != NIL && e1 != e2) e1 = e1->next;
    return (e1 == e2);
}

/* 
 * (GEH) return the nearest ancestor of expression which is not a compound
 * expression.  If the expression given is not a compound expr, return it.
 * Otherwise, check the parent of the expr.  If no non-compound expression
 * ancestor exists, return NIL.
 */

Expr FindNonCompExprAncestor(expr)
    Expr expr;
{
  while (expr != NIL && expr->opcode == OP_compexpr) expr = expr->parentexpr;
  return expr;
}

/*
 * GEH - find the immediate child expr of the given ancestor which is also 
 * an ancestor of the given expression.  If given ancestor is not really an
 * ancestor of expression, return NIL.
 */
Expr FindChildOfAncestor(expr, ancestor)
    Expr expr, ancestor;
{
    while (expr != NIL && expr->parentexpr != ancestor) expr = expr->parentexpr;
    return expr;
}

/* Return a TRUE expression (1) */
Expr TrueExpr() {
  return NewIntExpr(1);
}

/* Return a FALSE expression (0) */
Expr FalseExpr() {
  return NewIntExpr(0);
}

/* Return a DEFAULT expression (DEFAULT) */
Expr DefaultExpr() {
  return NewIntExpr(DEFAULT_VALUE);
}

/* Query functions. */
bool IsTrueExpr(expr)
     Expr expr;
{
  if ((expr==0)||(expr->opcode!=OP_int)) return FALSE;
  return (expr->value.scalar == TRUE);
}

bool IsFalseExpr(expr)
     Expr expr;
{
  if ((expr==0)||(expr->opcode!=OP_int)) return FALSE;
  return (expr->value.scalar == FALSE);
}

bool IsDefaultExpr(expr)
     Expr expr;
{
  if ((expr==0)||(expr->opcode!=OP_int)) return FALSE;
  return (expr->value.scalar == DEFAULT_VALUE);
}

bool IsVarExpr(expr)
     Expr expr;
{
  if (expr==0) return FALSE;
  return (expr->opcode == OP_var && (! expr->enum_flag));
}

/* ignore OP_type_size and OP_expr_size. */
bool IsIntegralExpr(expr)
     Expr expr;
{
  int opcode;
  if (expr==0) return FALSE;
  opcode = expr->opcode;

  switch (opcode) {
    case OP_var:
      return (expr->enum_flag);
    case OP_int:
    case OP_char:
      return TRUE;
    default:
      return FALSE;
  }
}

int IntegralExprValue(expr)
     Expr expr;
{
  EnumField enf;
  int opcode;
/*
  if (expr==0) return 0;
*/
  if (expr==0) 
    Punt("IntegralExprValue: null expr");

  opcode = expr->opcode;
  switch (opcode) {
    case OP_var:
      if (expr->enum_flag) {
	enf = enum_expr_to_enum_field(expr);
        assert(enf != NIL && enf->value != NIL);
	assert (enf->value->opcode == OP_int);
        return enf->value->value.scalar;
      }
      else {
        Punt("IntegralExprValue: var expr not an enum");
      }
    case OP_int:
      return expr->value.scalar;
    case OP_char:
      return C_str2char(expr->value.string);
    default:
      Punt("IntegralExprValue: not an integral expression");
      return 0;
  }
}

bool IsFloatExpr(expr)
     Expr expr;
{
  if (expr==0) return FALSE;
  /* BCC - compare OP_float - 8/4/96 */
  return (expr->opcode == OP_float);
}

/* BCC - 8/4/96 */
bool IsDoubleExpr(expr)
     Expr expr;
{
  if (expr==0) return FALSE;
  return (expr->opcode == OP_double);
}

/* BCC - 8/4/96 */
bool IsRealExpr(expr)
     Expr expr;
{
  if (expr==0) return FALSE;
  return (expr->opcode == OP_real ||
	  expr->opcode == OP_double || 
	  expr->opcode == OP_float);
}

double FloatExprValue(expr)
     Expr expr;
{
  return expr->value.real;
}

bool IsConstNumber(expr)
     Expr expr;
{
  /* BCC - use IsRealExpr instead of IsFloatExpr - 8/4/96 */
  return (IsIntegralExpr(expr) || IsRealExpr(expr));
}

bool IsConstOne(expr)
     Expr expr;
{
  /* BCC - use IsRealExpr instead of IsFloatExpr - 8/4/96 */
  return ((IsIntegralExpr(expr) && (IntegralExprValue(expr)==1)) ||
	  (IsRealExpr(expr) && (FloatExprValue(expr)==1.0)));
}

bool IsConstZero(expr)
     Expr expr;
{
  /* BCC - use IsRealExpr instead of IsFloatExpr - 8/4/96 */
  return ((IsIntegralExpr(expr) && (IntegralExprValue(expr)==0)) ||
	  (IsRealExpr(expr) && (FloatExprValue(expr)==0.0)));
}

bool IsConstNonZero(expr)
     Expr expr;
{
  return ((IsIntegralExpr(expr) && (IntegralExprValue(expr)!=0)) ||
	  (IsFloatExpr(expr) && (FloatExprValue(expr)!=0.0)));
}

bool IsConstNegative(expr)
     Expr expr;
{
  /* BCC - use IsRealExpr instead of IsFloatExpr - 8/4/96 */
  return (!(expr->type->type & TY_UNSIGNED) &&
	  ((IsIntegralExpr(expr) && (IntegralExprValue(expr)<0)) ||
	   (IsRealExpr(expr) && (FloatExprValue(expr)<0.0))));
}


/* 
 *	Returns true if the expression tree is completely 
 *	side-effect-free. The following operators cause side-effect :
 * 	assign, preinc, predec, postinc, postdec,
 * 	Aadd, Asub, Amul, Adiv, Amod, Arshft,
 * 	Alshft, Aand, Aor, Axor, call.
 */
bool IsSideEffectFree(expr)
     Expr expr;
{
  int i;
  Expr op;
  if (expr==0) return TRUE;
  switch (expr->opcode) {
  case OP_assign :         case OP_preinc :         case OP_predec :
  case OP_postinc :        case OP_postdec :        case OP_Aadd :
  case OP_Asub :           case OP_Amul :           case OP_Adiv :
  case OP_Amod :           case OP_Arshft :         case OP_Alshft :
  case OP_Aand :           case OP_Aor :            case OP_Axor :
  case OP_call :
    return FALSE;
    default :
      for (i=1; (op=GetOperand(expr, i))!=0; i++)
	if (! IsSideEffectFree(op))
	  return FALSE;
    return TRUE;
  }
}

/* In many cases, when an expression is known to produce boolean result, 
 * the upper (!=0) operation can be eliminated. 
 */
bool IsBooleanExpr(expr)
     Expr expr;
{
  Expr op1, op2;
  if (expr==0) return FALSE;
  switch (expr->opcode) {
  case OP_eq:		case OP_ne:
  case OP_lt:		case OP_le:
  case OP_gt:		case OP_ge:
  case OP_conj:	case OP_disj:
    return TRUE;
  case OP_or:
  case OP_xor:
  case OP_and:
    op1 = GetOperand(expr, 1);
    op2 = GetOperand(expr, 2);
    return (IsBooleanExpr(op1) && IsBooleanExpr(op2));
  default:
    return FALSE;
  }
}

bool is_func_call (e)
     Expr e;
{
  if(e->parentexpr != 0) {
    if((e->parentexpr->opcode == OP_call) && (e->parentexpr->operands == e))
      return TRUE;
  }
  return FALSE;
}

/*-------------------------------------------------------------*/
/* 12.  Statement Manipulating Functions                       */
/*-------------------------------------------------------------*/

/*  check if Null statements (NOOP) only */
bool NullStmts(list)
     Stmt list;
{
  Stmt ptr;
  ptr = list;
  while((ptr!=0) && (ptr->type==ST_NOOP)) ptr = ptr->lex_next;
  if(ptr==0)
    return TRUE;
  else 
    return FALSE;
}

/* (SK)  The following stmt level accessing functions are provided to simplify
 * the accessing of Pcode data structures. 
 */
Stmt Stmt_Init(stmt)
     Stmt stmt;
{
  Stmt newstmt;
  
  /* First, create a new statement */
  newstmt = NewStmt();
  
  /* Now, set the values of the various fields of the statement*/
  newstmt->type = stmt->type;
  newstmt->lineno = stmt->lineno;
  newstmt->colno  = stmt->colno;
  if (stmt->filename)
    newstmt->filename = strdup(stmt->filename);
  else
    newstmt->filename = 0;
  
  /*Copying the profile info. also, this can be undone if not needed by
    re-setting dummy to 0*/
  /* LCW - modified for the new profile structure - 10/25/95 */
  if (stmt->profile != 0) {
    newstmt->profile = NewProfST(stmt->profile->count);
    newstmt->profile->next = stmt->profile->next;
  }
  
  /*Copy the pragmas of the original stmt*/
  /* BCC - added a new argument to CopyPragma() - 1/2/97 */
  newstmt->pragma = CopyPragma(stmt->pragma, 1);
  
  /*Copy the labels also*/
  if (stmt->labels != 0)
    newstmt->labels = CopyLabels(stmt->labels,0,newstmt);
  
  return newstmt;
}

/* (SK) Given a stmt, create a compound stmt around it if one doesn't already
 * exist.  This routine can be very useful when one has to add a new statement
 * before or after another statement, but the other statement may happen to
 * be the only statement within, say, a loop and hence may not have a compd. 
 * stmt enclosing it
 *  
 * return TRUE if the compound statement was actually needed, and FALSE if
 * no compd. needed to be created.   This return value need not be used,
 * it is provided simply as a check.  
 */
bool Create_Encl_Compd_IfNeeded(stmt)
     Stmt stmt;
{
  Stmt new_comp_stmt;
  
  /* if the stmt already has a compound stmt around it, then we are done*/
  if (stmt->parent->type == ST_COMPOUND)
    return FALSE;
  
  new_comp_stmt = Stmt_Init(stmt);
  /* BCC - the label of the original stmt has been propogated to the enclosing
           compound statement                                      - 12/10/95 */
  RemoveLabels(stmt->labels);
  stmt->labels = 0;
  /* End of change */
  new_comp_stmt->type = ST_COMPOUND;
  new_comp_stmt->stmtstruct.compound = NewCompound();
  new_comp_stmt->stmtstruct.compound->scope = NewScopeId();
  new_comp_stmt->stmtstruct.compound->stmt_list = stmt;
  
  new_comp_stmt->parent = stmt->parent;
  
  /* Now that the compd. stmt has been created, it should be set
     as the statement that stmt's parent  points to.
     Note that the parent of stmt. has to be of a type that can have 
     statement(s) within it, and it cannot be a compound stmt. since we 
     have already checked for this
     */
  
  switch (stmt->parent->type) {
  case ST_EXPR:
    Punt("Create_Encl_Compd_IfNeeded: Illegal compound stmt. structure");
    break;
  case ST_COMPOUND:
    Punt("Create_Encl_Compd_IfNeeded: Internal error, encl. compd. not needed");
    break;
  case ST_SERLOOP:
    stmt->parent->stmtstruct.serloop->loop_body = new_comp_stmt;
    break;
  case ST_IF:
    {
      /* if the parent is an if stmt, then, stmt could either be the
	 then or the else block, so need a check*/
      
      if (stmt->parent->stmtstruct.ifstmt->then_block == stmt)
	stmt->parent->stmtstruct.ifstmt->then_block = new_comp_stmt;
      else
	stmt->parent->stmtstruct.ifstmt->else_block = new_comp_stmt;
    }
    break;
  case ST_SWITCH:
    stmt->parent->stmtstruct.switchstmt->switchbody = new_comp_stmt;
    break;
  case ST_BREAK:
  case ST_CONT:
  case ST_RETURN:
  case ST_GOTO:
  case ST_NOOP:
    Punt("Create_Encl_Compd_IfNeeded: Illegal compound stmt. structure");
    break;
  case ST_PSTMT:
    stmt->parent->stmtstruct.pstmt->stmt = new_comp_stmt;
    break;
  case ST_ADVANCE:
  case ST_AWAIT:
  case ST_PARLOOP:
    Punt("Create_Encl_Compd_IfNeeded: Illegal compound stmt. structure");
    break;
  case ST_BODY:
    stmt->parent->stmtstruct.bodystmt->statement = new_comp_stmt;
    break;
  case ST_EPILOGUE:
    stmt->parent->stmtstruct.epiloguestmt->statement = new_comp_stmt;
    break;
  case ST_MUTEX:
    stmt->parent->stmtstruct.mutex->statement = new_comp_stmt;
    break;
  case ST_COBEGIN:
    stmt->parent->stmtstruct.cobegin->statements = new_comp_stmt;
    break;
  default:
    Punt("Create_Encl_Compd_IfNeeded: unknown Stmt tag");
  }
  
  
  stmt->parent = new_comp_stmt;
  
  
  return TRUE;
}

/* (SK) Routines Insert_Stmt_Before and Insert_Stmt_After are provided to 
 * insert the given stmt(param.2) before or after the stmt. passed as param.1 
 * respectively.  Note that these routines do NOT actually create the
 * stmt. to be inserted, this can be done using a call to Create_New_...
 * depending on the type of stmt. to be created.  These routines also
 * create a compound statement around the given statement if needed.  
 */
void Insert_Stmt_Before(orig_stmt, new_stmt)
     Stmt orig_stmt, new_stmt;
{
  
  Create_Encl_Compd_IfNeeded(orig_stmt);
  new_stmt->parent = orig_stmt->parent;
  new_stmt->lex_prev = orig_stmt->lex_prev;
  orig_stmt->lex_prev = new_stmt;
  new_stmt->lex_next = orig_stmt;

  /*SK: Adding code to set new_stmt's lex_prev's lex_next pointer*/

  if (new_stmt->lex_prev != 0)
    new_stmt->lex_prev->lex_next = new_stmt;
/* GEH - fixed ugly code below */
  else {
    assert(orig_stmt->parent->type == ST_COMPOUND);
    orig_stmt->parent->stmtstruct.compound->stmt_list = new_stmt;
  }
  
/* WYC */
  if ((orig_stmt->parent == 0) && (new_stmt->lex_prev == 0))
    currentFuncDcl->stmt = new_stmt;

/* GEH - not needed, handled above
  if (new_stmt->lex_prev == 0) {
    switch(orig_stmt->parent->type) {
    case ST_COMPOUND:
      orig_stmt->parent->stmtstruct.compound->stmt_list = new_stmt;
      break;
    }
  }
*/
/* CYW */
  
}

void Insert_Stmt_After(orig_stmt, new_stmt)
     Stmt orig_stmt, new_stmt;
{
  
  Create_Encl_Compd_IfNeeded(orig_stmt);
  new_stmt->parent = orig_stmt->parent;
  new_stmt->lex_next = orig_stmt->lex_next;
  orig_stmt->lex_next = new_stmt;
  new_stmt->lex_prev = orig_stmt;

  /*SK: Adding code to set new_stmt's lex_next's lex_prev. pointer*/

  if (new_stmt->lex_next != 0)
    new_stmt->lex_next->lex_prev = new_stmt;
  
}

/* 
 * GEH - find label name in statement label list.  Return pointer to label 
 * structure if found, NIL otherwise.
 */

Label FindStmtLabel(stmt, name)
Stmt stmt;
char *name;
{
    Label label;

    assert(stmt != NIL);
    label = stmt->labels;
    while (label != NIL) {
	if (label->type == LB_LABEL && !strcmp(label->val, name)) return label;
	label = label->next;
    }
    return NIL;
}

/* 
 * GEH - add label to statement label list.
 */

void AddStmtLabel(stmt, label)
Stmt stmt;
Label label;
{
    Label first;
    assert(stmt != NIL);

    first = stmt->labels;
    label->next = first;
    label->prev = NIL;
    if (first != NIL) first->prev = label;
    stmt->labels = label;
}

/*--------------------------------------------------------------------------*/
/* 13. Parloop Manipulation Functions                                       */
/*--------------------------------------------------------------------------*/

/* (SK) Adding the following procedures which should simplify accessing 
 *      ParLoops:
 *
 * (GH) Modified the procedures to use more efficient assertions and 
 *      intermediate values.  Also return a pointer to the body and epilogue 
 *      statements, not the statements contained by these.
 *
 * a) Parloop_Stmts_Prologue_Stmt
 * returns a pointer to the statement contained within the Prologue Pstmt.
 * this is always a compound statement.
 *
 * b) Parloop_Stmts_Body_Stmt
 * returns a pointer to the statement of type ST_BODY for the given
 * statement of type ST_PARLOOP.
 *
 * c) Parloop_Body_Stmt
 * returns a pointer to the statement of type ST_BODY for the given 
 * parloop structure.
 *  
 * d) Parloop_Stmts_First_Epilogue_Stmt
 * returns a pointer to the first statement of type ST_EPILOGUE for the given
 * statement of type ST_PARLOOP.
*/
Stmt Parloop_Stmts_Prologue_Stmt(parloop_stmt)
     Stmt parloop_stmt;
{
  ParLoop parloop;
  Pstmt pstmt;
  
  assert(parloop_stmt != 0);
  assert(parloop_stmt->type == ST_PARLOOP);
  
  parloop = parloop_stmt->stmtstruct.parloop;
  assert(parloop != 0);
  
  pstmt = parloop->pstmt;
  assert(pstmt != 0);
  
  return pstmt->stmt;
}

Stmt Parloop_Stmts_Body_Stmt(parloop_stmt)
     Stmt parloop_stmt;
{
  Stmt stmt;
  ParLoop parloop;
  Pstmt pstmt;
  Compound compound;
  BodyStmt bodystmt;
  
  assert(parloop_stmt != 0);
  assert(parloop_stmt->type == ST_PARLOOP);
  
  parloop = parloop_stmt->stmtstruct.parloop;
  assert(parloop != 0);
  
  pstmt = parloop->pstmt;
  assert(pstmt != 0);
  
  stmt = pstmt->stmt;
  assert(stmt != 0);
  assert(stmt->type == ST_COMPOUND);
  
  compound = stmt->stmtstruct.compound;
  assert(compound != 0);
  
  stmt = compound->stmt_list;
  assert(stmt != 0);
  
  while ((stmt != 0) && (stmt->type != ST_BODY))
    stmt = stmt->lex_next;
  
  assert(stmt != 0);
  return stmt;
}

Stmt Parloop_Body_Stmt(parloop)
     ParLoop parloop;
{
  Stmt stmt;
  Pstmt pstmt;
  Compound compound;
  BodyStmt bodystmt;
  
  assert(parloop != 0);
  
  pstmt = parloop->pstmt;
  assert(pstmt != 0);
  
  stmt = pstmt->stmt;
  assert(stmt != 0);
  assert(stmt->type == ST_COMPOUND);
  
  compound = stmt->stmtstruct.compound;
  assert(compound != 0);
  
  stmt = compound->stmt_list;
  assert(stmt != 0);
  
  while ((stmt != 0) && (stmt->type != ST_BODY))
    stmt = stmt->lex_next;
  
  assert(stmt !=0);
  return stmt;
}

Stmt Parloop_Stmts_First_Epilogue_Stmt(parloop_stmt)
     Stmt parloop_stmt;
{    
  Stmt stmt;
  ParLoop parloop;
  Pstmt pstmt;
  Compound compound;
  
  assert(parloop_stmt != 0);
  assert(parloop_stmt->type == ST_PARLOOP);
  
  parloop = parloop_stmt->stmtstruct.parloop;
  assert(parloop != 0);
  
  pstmt = parloop->pstmt;
  assert(pstmt != 0);
  
  stmt = pstmt->stmt;
  assert(stmt != 0);
  assert(stmt->type == ST_COMPOUND);
  
  compound = stmt->stmtstruct.compound;
  assert(compound != 0);
  
  stmt = compound->stmt_list;
  assert(stmt != 0);
  
  while ((stmt != 0) && (stmt->type != ST_EPILOGUE))
    stmt = stmt->lex_next;
  
  assert(stmt != 0);
  return stmt;
}

/*-------------------------------------------------------------*/
/* 14. Pragma Functions                                        */
/*-------------------------------------------------------------*/

/* There are 3 types of Pragma's - 
 *   Function, Statement, and Variable
 *   Need general functions for statement and variable once have better
 *   idea of their use
 */

void AddFunctionPragma(func, specifier, expr)
     FuncDcl func;
     char *specifier;
     Expr expr;
{
  Pragma new;
  new = NewPragma(specifier, expr);
  new->next = func->pragma;
  func->pragma = new;
}

Pragma FindFunctionPragma(func, prefix)
     FuncDcl func;
     char *prefix;
{
  Pragma ptr;
  for (ptr=func->pragma; ptr!=0; ptr=ptr->next)
    if (PrefixMatch(prefix, ptr->specifier))
      return ptr;
  return 0;
}

/* if (pragma==0) remove all pragmas. else only remove a single pragma 
 * if found.
 */
bool RemoveFunctionPragma(func, pragma)
     FuncDcl func;
     Pragma pragma;
{
  Pragma ptr;
  if (pragma==0) {
    RemovePragma(func->pragma);
    func->pragma = 0;
    return TRUE;
  }
  for (ptr=func->pragma; ptr!=0; ptr=ptr->next)
    if (ptr==pragma)
      break;
  if (ptr==0) return FALSE;	/* not found */
  ptr = func->pragma;
  if (pragma==ptr) {
    func->pragma = pragma->next;
  } else {
    while (ptr->next!=pragma) ptr=ptr->next;
    ptr->next = pragma->next;
  }
  pragma->next = 0;
  RemovePragma(pragma);
  return TRUE;
}

/* Expression pragmas are not in the pcode grammar but could possilby be used
 * to pass information about expressions from one pass of pcode to another.
 * currently supported by pcode.c but I not gen_pcode.c (it needed, they can
 * be).
 */
void AddExprPragma(expr, specifier, p_expr)
     Expr expr;
     char *specifier;
     Expr p_expr;
{
  Pragma new;
  new = NewPragma(specifier, p_expr);
  new->next = expr->pragma;
  expr->pragma = new;
}

Pragma FindExprPragma(expr, prefix)
     Expr expr;
     char *prefix;
{
  Pragma ptr;
  for (ptr=expr->pragma; ptr!=0; ptr=ptr->next)
    if (PrefixMatch(prefix, ptr->specifier))
      return ptr;
  return 0;
}

/* if (pragma==0) remove all pragmas.
 * else only remove a single pragma if found.
 */
bool RemoveExprPragma(expr, pragma)
     Expr expr;
     Pragma pragma;
{
  Pragma ptr;
  if (pragma==0) {
    RemovePragma(expr->pragma);
    expr->pragma = 0;
    return TRUE;
  }
  for (ptr=expr->pragma; ptr!=0; ptr=ptr->next)
    if (ptr==pragma)
      break;
  if (ptr==0) return FALSE;	/* not found */
  ptr = expr->pragma;
  if (pragma==ptr) {
    expr->pragma = pragma->next;
  } else {
    while (ptr->next!=pragma) ptr=ptr->next;
    ptr->next = pragma->next;
  }
  pragma->next = 0;
  RemovePragma(pragma);
  return TRUE;
}

/* BCC - 1/2/97 */
void AddPragmaToStatement(stmt, pragma)
     Stmt stmt;
     Pragma pragma;
{
  pragma->next = stmt->pragma;
  stmt->pragma = pragma;
}

void AddStatementPragma(stmt, specifier, expr)
     Stmt stmt;
     char *specifier;
     Expr expr;
{
  Pragma new;
  new = NewPragma(specifier, expr);
  new->next = stmt->pragma;
  stmt->pragma = new;
}

/* Search for pragma with prefix.  Return pragma if found, 0 otherwise
 * DML 1/27/96
 */
Pragma FindStmtPragma(stmt, prefix)
     Stmt stmt;
     char *prefix;
{
  Pragma ptr;
  for (ptr=stmt->pragma; ptr!=0; ptr=ptr->next)
    if (PrefixMatch(prefix, ptr->specifier))
      return ptr;
  return 0;
}

/* Concatenate pragma list pragma2 onto the end of pragma list pragma1.  
 * and return a pointer to the whole list.   DML 1/27/96
 */
Pragma ConcatPragma (pragma1, pragma2)
     Pragma pragma1, pragma2;
{
  Pragma ptr;

  if(pragma1 == NULL)
      return (pragma2);
  if(pragma2 == NULL)
      return (pragma1);

  ptr = pragma1;
  while(ptr->next!=0) ptr = ptr->next;
  ptr->next = pragma2;

  return (pragma1);
}


/* BCC - Added to free all the field definitions inside a struct - 11/21/95 */
void RemoveField(field)
     Field field;
{
  if (field==0) return;
  /* remove next field first */
  RemoveField(field->next);
  RemoveExpr(field->bit_field);
  RemoveType(field->type);
  field->next = 0;
  field->bit_field = 0;
  field->type = 0;
  DISPOSE(field);
}

/* BCC - Added to free all the enum field definitions - 11/21/95 */
void RemoveEnumField(field)
     EnumField field;
{
  if (field==0) return;
  /* remove next field first */
  RemoveEnumField(field->next);
  RemoveExpr(field->value);
  field->next = 0;
  field->value = 0;
  DISPOSE(field);
}

/* BCC - Added to free a struct definition - 11/21/95 */
void RemoveStructDcl(st)
     StructDcl st;
{
  if (st==0) return;
  /* remove fields */
  RemoveField(st->fields);
  st->fields = 0;

  /* BCC - free filename - 11/21/95 */
  if (st->filename) free(st->filename);
  st->filename = 0;

  DISPOSE(st);
}

/* BCC - Added to free an union definition - 11/21/95 */
void RemoveUnionDcl(un)
     UnionDcl un;
{
  if (un==0) return;
  /* remove fields */
  RemoveField(un->fields);
  un->fields = 0;

  /* BCC - free filename - 11/21/95 */
  if (un->filename) free(un->filename);
  un->filename = 0;

  DISPOSE(un);
}

/* BCC - Added to free an enum definition - 11/21/95 */
void RemoveEnumDcl(en)
     EnumDcl en;
{
  if (en==0) return;
  /* remove fields */
  RemoveEnumField(en->fields);
  en->fields = 0;

  /* BCC - free filename - 11/21/95 */
  if (en->filename) free(en->filename);
  en->filename = 0;

  DISPOSE(en);
}

/* BCC - Added to deallocate space for scope list */
void RemoveScopeChain(s)
     Scope s;
{
  if (s == 0) return;
  RemoveScopeChain(s->next);
  s->next = 0;
  s->prev = 0;
  DISPOSE(s);
}

/* BCC - Added to deallocate space for lists of scope list */
void RemoveScopeListChain(s)
     ScopeList s;
{
  if (s == 0) return;
  RemoveScopeListChain(s->next);
  s->next = 0;
  s->prev = 0;
  RemoveScopeChain(s->scope);
  DISPOSE(s);
}
