/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	cf_contr-flow.c
 *	Author: Grant Haab and Wen-mei Hwu
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <library/c_symbol.h>
#include <library/llist.h>
#include <Pcode/flow.h>
#include <Pcode/cf_contr-flow.h>
#include <Pcode/pcode.h>
#include <Pcode/struct.h>
#include <Pcode/parms.h>
#include <Pcode/links.h>
#include <Pcode/dd_evaluate.h>

/* array of names of functions which cause program termination */

/* BCC - added exit_thread ( found in Informix) - 4/13/96 */
char *ProgExitFunc[NUM_PROG_EXIT_FUNCS] = {
        "s_stop",
        "exit",
	"exit_thread"
};

static int goto_source_table;   /* hash table of goto stmt source flow nodes
			           hashed by label string. Entry in table 
				   points to list of flow nodes */

static int goto_dest_table;	/* hash table of goto stmt dest flow nodes
				   hashed by label string. Entry in table
				   is a pointer to a single flow node */

static int tables_allocated = FALSE; /* boolean value indicating whether tables 
			 	     have been allocated yet. */

extern FlowGraph flow_graph;

/* forward declarations */

static _CFInfo CF_Stmt();
static _CFInfo CF_Stmts();


static Punt(mesg, stmt)
char *mesg;
Stmt stmt;
{
    if (stmt != NIL) {
	fprintf(Ferr, "# cf_contr-flow: %s in file %s on line %u\n", mesg,
		stmt->filename, stmt->lineno);
    }
    else {
	fprintf(Ferr, "# cf_contr-flow: %s\n", mesg);
    }
    exit(-1);
}

void CF_Print_Flow_Nodes(FILE *file, FuncDcl func)
{

    FlowGraph flow_graph;
    FlowNode fn, pfn, sfn;
    Lptr pred, succ;

    assert(func != NIL);
    assert((flow_graph = func->flow->flow_graph) != NIL);

    fprintf(file, "....Printing Basic Blocks:\n");

    for (fn = flow_graph->first_node; fn != NIL; fn = fn->next) {

	if (fn->type == NT_FuncExit || fn->type == NT_FuncEntry) {
	    fprintf(file, "        (fn %s(%s)\n",
		    NodeTypeNames[fn->type], fn->pcode_ptr.func->name);
	}
	else{
	    fprintf(file, "        (fn %s(#%d)\n",
		    NodeTypeNames[fn->type], fn->pcode_ptr.stmt->lineno);
	}
	fprintf(file, "            (pred_fn");
	for (pred = fn->pred; pred != NIL; pred = pred->next) {
	    pfn = (FlowNode)pred->ptr;
	    if (pfn->type == NT_FuncExit || pfn->type == NT_FuncEntry) {
		fprintf(file, " (fn %s(%s))",
			NodeTypeNames[pfn->type], pfn->pcode_ptr.func->name);
	    }
	    else{
		fprintf(file, " (fn %s(#%d))",
			NodeTypeNames[pfn->type], pfn->pcode_ptr.stmt->lineno);
	    }
	}
	fprintf(file, ")\n");
        fprintf(file, "            (succ_fn");
	for (succ = fn->succ; succ != NIL; succ = succ->next) {
	    sfn = (FlowNode)succ->ptr;
	    if (sfn->type == NT_FuncExit || sfn->type == NT_FuncEntry) {
		fprintf(file, " (fn %s(%s))",
			NodeTypeNames[sfn->type], sfn->pcode_ptr.func->name);
	    }
	    else{
		fprintf(file, " (fn %s(#%d))",
			NodeTypeNames[sfn->type], sfn->pcode_ptr.stmt->lineno);
	    }
	}
	fprintf(file, ")\n        )\n");
    }
}

static void CF_Goto_Error(label_name, type, value, list_ptr)
char *label_name;
int type;
Integer value;
Lptr list_ptr;
{
    FlowNode flow_node;

    while (list_ptr != NIL) {
	flow_node = (FlowNode) list_ptr->ptr;

	fprintf(Ferr, "# cf_contr-flow: Label \"%s\" not found in file %s for goto on line %u\n",
	   label_name, flow_node->pcode_ptr.stmt->filename,
	   flow_node->pcode_ptr.stmt->lineno);

	list_ptr = list_ptr->next;
    }
}

static void InitCFInfo(cf_info, break_list, cont_list, return_list, switch_list,
		       exit_node) 
CFInfo cf_info;
Lptr break_list, cont_list, return_list, switch_list;
FlowNode exit_node;
{
    cf_info->break_list = break_list;
    cf_info->cont_list = cont_list;
    cf_info->return_list = return_list;
    cf_info->switch_list = switch_list;
    cf_info->exit_node = exit_node;
}

/* 
 * Build Control Flow graph for a noop statement.
 */

static _CFInfo CF_Noop_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode flow_node;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);

    flow_node = NewFlowNode(NT_Null, flow_graph);
    flow_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = flow_node;
    stmt->flow->flow_node_list = NewLptr((Void *) flow_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, flow_node);

    cf_info.exit_node = flow_node;
    return cf_info;
}

/* 
 * Build Control Flow graph for a continue statement.
 */

static _CFInfo CF_Cont_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode flow_node;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);

    flow_node = NewFlowNode(NT_Continue, flow_graph);
    flow_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = flow_node;
    stmt->flow->flow_node_list = NewLptr((Void *) flow_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, flow_node);

    cf_info.cont_list = NewLptr((Void *) flow_node);
    return cf_info;
}

/* 
 * Build Control Flow graph for a break statement.
 */

static _CFInfo CF_Break_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode flow_node;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);

    flow_node = NewFlowNode(NT_Break, flow_graph);
    flow_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = flow_node;
    stmt->flow->flow_node_list = NewLptr((Void *) flow_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, flow_node);

    cf_info.break_list = NewLptr((Void *) flow_node);
    return cf_info;
}

/* 
 * Build Control Flow graph for a return statement.
 */

static _CFInfo CF_Return_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode flow_node;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);

    flow_node = NewFlowNode(NT_Return, flow_graph);
    flow_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = flow_node;
    stmt->flow->flow_node_list = NewLptr((Void *) flow_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, flow_node);

    cf_info.return_list = NewLptr((Void *) flow_node);
    return cf_info;
}

/* 
 * Build Control Flow graph for a goto statement.
 */

static _CFInfo CF_Goto_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode flow_node, dest_node;
    Lptr source_node_list;
    Integer dummy;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);

    flow_node = NewFlowNode(NT_Goto, flow_graph);
    flow_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = flow_node;
    stmt->flow->flow_node_list = NewLptr((Void *) flow_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, flow_node);

    /* try to determine successor of goto flow node */
    if (C_find(goto_dest_table, stmt->stmtstruct.label, 0, &dummy, 
	       (Pointer *)  &dest_node)) {

	ConnectFlowNodes(flow_node, dest_node);
    }
    else {	/* destination of goto not yet encountered */
	if (C_find(goto_source_table, stmt->stmtstruct.label, 0, &dummy, 
		   (Pointer *) &source_node_list)) {
	    C_update(goto_source_table, stmt->stmtstruct.label, 0, 0, 
		     AppendLptr(NewLptr((Void *) flow_node), 
		     (Pointer) source_node_list));
	}
	else {
	    C_update(goto_source_table, stmt->stmtstruct.label, 0, 0, 
		     (Pointer) NewLptr((Void *) flow_node));
	}
    }

    return cf_info;
}

/* 
 * Build Control Flow graph for a compound statement.
 */

static _CFInfo CF_Compound_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode entry_node = NIL, exit_node = NIL;

    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = NIL;
    stmt->flow->flow_node_list = NIL;

/* GEH - don't produce compound entry unless there is a predecessor node 
	 or the statement is labeled */

    if (pred_node != NIL || stmt->labels != NIL) {
	entry_node = NewFlowNode(NT_CompoundEntry, flow_graph);
	entry_node->pcode_ptr.stmt = stmt;
	stmt->flow->entry_flow_node = entry_node;
	stmt->flow->flow_node_list = NewLptr((Void *) entry_node);

	if (pred_node != NIL) ConnectFlowNodes(pred_node, entry_node);
    }

    cf_info = CF_Stmts(stmt->stmtstruct.compound->stmt_list, entry_node, FALSE);

/* GEH - don't produce compound exit unless there is a predecessor node */

    if (cf_info.exit_node != NIL) {
	exit_node = NewFlowNode(NT_CompoundExit, flow_graph);
	exit_node->pcode_ptr.stmt = stmt;
	stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
					       NewLptr((Void *) exit_node));

	ConnectFlowNodes(cf_info.exit_node,exit_node);
	cf_info.exit_node = exit_node;
    }

    return cf_info;
}

/* 
 * Build Control Flow graph for an if statement.
 */

static _CFInfo CF_If_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info, temp;
    FlowNode cond_node, exit_node = NIL;

    cond_node = NewFlowNode(NT_IfCond, flow_graph);
    cond_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = cond_node;
    stmt->flow->flow_node_list = NewLptr((Void *) cond_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, cond_node);

    temp = CF_Stmt(stmt->stmtstruct.ifstmt->then_block, cond_node);
    
    /* construct control flow graph for else part if else stmt exists */
    if (stmt->stmtstruct.ifstmt->else_block != NIL) {
	cf_info = CF_Stmt(stmt->stmtstruct.ifstmt->else_block, cond_node);
    }
    else { /* create exit node since necessary */
	exit_node = NewFlowNode(NT_IfExit, flow_graph);
	exit_node->pcode_ptr.stmt = stmt;
	stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
					       NewLptr((Void *) exit_node));

	ConnectFlowNodes(cond_node, exit_node);
	InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);
    }

    if (cf_info.exit_node != NIL) {
	if (exit_node == NIL) { /* create exit node if none created yet */
	    exit_node = NewFlowNode(NT_IfExit, flow_graph);
	    exit_node->pcode_ptr.stmt = stmt;
	    stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
						   NewLptr((Void *) exit_node));
	}
	ConnectFlowNodes(cf_info.exit_node, exit_node);
    }
    if (temp.exit_node != NIL) {
	if (exit_node == NIL) { /* create exit node if none created yet */
	    exit_node = NewFlowNode(NT_IfExit, flow_graph);
	    exit_node->pcode_ptr.stmt = stmt;
	    stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
						   NewLptr((Void *) exit_node));
	}
	ConnectFlowNodes(temp.exit_node, exit_node);
    }

    cf_info.break_list = AppendLptr(temp.break_list, cf_info.break_list);
    cf_info.cont_list = AppendLptr(temp.cont_list, cf_info.cont_list);
    cf_info.return_list = AppendLptr(temp.return_list, cf_info.return_list);
    cf_info.switch_list = AppendLptr(temp.switch_list, cf_info.switch_list);

    cf_info.exit_node = exit_node;
    return cf_info;
}

/* 
 * Build Control Flow graph for a switch statement.
 */

static _CFInfo CF_Switch_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode cond_node, exit_node = NIL;
    Lptr cur_elmnt;
    Label cur_label;
    int default_present = FALSE;

    cond_node = NewFlowNode(NT_SwitchCond, flow_graph);
    cond_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = cond_node;
    stmt->flow->flow_node_list = NewLptr((Void *) cond_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, cond_node);

    /* GEH - don't send cond node as predecessor, creates superfluous arcs */
    cf_info = CF_Stmt(stmt->stmtstruct.switchstmt->switchbody, NIL);

    /* connect cond node to all nodes associated with case and default labels */
    cur_elmnt = cf_info.switch_list;
    while (cur_elmnt != NIL) {
	cur_label = ((FlowNode)cur_elmnt->ptr)->pcode_ptr.stmt->labels;
	while (cur_label != NIL) {
	    if (cur_label->type == LB_DEFAULT) default_present = TRUE;
	    cur_label = cur_label->next;
	}
	ConnectFlowNodes(cond_node, (FlowNode) cur_elmnt->ptr);
	cur_elmnt = cur_elmnt->next;
    }
    cf_info.switch_list = FreeLptr(cf_info.switch_list);

    /* don't create NT_SwitchExit node unless necessary */
    if (cf_info.exit_node != NIL) {
	exit_node = NewFlowNode(NT_SwitchExit, flow_graph);
	exit_node->pcode_ptr.stmt = stmt;
	stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
					       NewLptr((Void *) exit_node));

	ConnectFlowNodes(cf_info.exit_node, exit_node);
    }

    /* connect all nodes assoc. with break statements to exit node */
    cur_elmnt = cf_info.break_list;

    /* create NT_SwitchExit node only if necessary */
    if (cur_elmnt != NIL && exit_node == NIL) {
	exit_node = NewFlowNode(NT_SwitchExit, flow_graph);
	exit_node->pcode_ptr.stmt = stmt;
	stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
					       NewLptr((Void *) exit_node));
    }
    while (cur_elmnt != NIL) {
	ConnectFlowNodes((FlowNode) cur_elmnt->ptr, exit_node);
	cur_elmnt = cur_elmnt->next;
    }
    cf_info.break_list = FreeLptr(cf_info.break_list);

    if (!default_present) {
	if (exit_node == NIL) {
	    exit_node = NewFlowNode(NT_SwitchExit, flow_graph);
	    exit_node->pcode_ptr.stmt = stmt;
	    stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
						   NewLptr((Void *) exit_node));
	}
	ConnectFlowNodes(cond_node, exit_node);
    }

    cf_info.exit_node = exit_node;
    return cf_info;
}

/* 
 * Build Control Flow graph for a parameterized statement.
 */

static _CFInfo CF_P_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode entry_node, exit_node;

    entry_node = NewFlowNode(NT_PStmtEntry, flow_graph);
    entry_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = entry_node;
    stmt->flow->flow_node_list = NewLptr((Void *) entry_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, entry_node);

    cf_info = CF_Stmt(stmt->stmtstruct.pstmt->stmt, entry_node);

    exit_node = NewFlowNode(NT_PStmtExit, flow_graph);
    exit_node->pcode_ptr.stmt = stmt;
    stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
					   NewLptr((Void *) exit_node));

    if (cf_info.exit_node != NIL) ConnectFlowNodes(cf_info.exit_node,exit_node);
    cf_info.exit_node = exit_node;

    return cf_info;
}

/* 
 * Build Control Flow graph for an advance statement.
 */

static _CFInfo CF_Advance_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode flow_node;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);

    flow_node = NewFlowNode(NT_Advance, flow_graph);
    flow_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = flow_node;
    stmt->flow->flow_node_list = NewLptr((Void *) flow_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, flow_node);
    cf_info.exit_node = flow_node;
    return cf_info;
}

/* 
 * Build Control Flow graph for an await statement.
 */

static _CFInfo CF_Await_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode flow_node;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);

    flow_node = NewFlowNode(NT_Await, flow_graph);
    flow_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = flow_node;
    stmt->flow->flow_node_list = NewLptr((Void *) flow_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, flow_node);
    cf_info.exit_node = flow_node;
    return cf_info;
}

/* 
 * Build Control Flow graph for a mutex statement.
 */

static _CFInfo CF_Mutex_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode entry_node, exit_node;

    entry_node = NewFlowNode(NT_MutexEntry, flow_graph);
    entry_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = entry_node;
    stmt->flow->flow_node_list = NewLptr((Void *) entry_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, entry_node);

    cf_info = CF_Stmt(stmt->stmtstruct.mutex->statement, entry_node);

    exit_node = NewFlowNode(NT_MutexExit, flow_graph);
    exit_node->pcode_ptr.stmt = stmt;
    stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
					   NewLptr((Void *) exit_node));

    if (cf_info.exit_node != NIL) ConnectFlowNodes(cf_info.exit_node,exit_node);
    cf_info.exit_node = exit_node;

    return cf_info;
}

/* 
 * Build Control Flow graph for a cobegin statement.
 */

static _CFInfo CF_Cobegin_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    _CFInfo temp;
    FlowNode entry_node, exit_node;
    Stmt cur_stmt;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);

    entry_node = NewFlowNode(NT_CobeginEntry, flow_graph);
    entry_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = entry_node;
    stmt->flow->flow_node_list = NewLptr((Void *) entry_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, entry_node);

    exit_node = NewFlowNode(NT_CobeginExit, flow_graph);
    exit_node->pcode_ptr.stmt = stmt;
    stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list,
					   NewLptr((Void *) exit_node));

    cur_stmt = stmt->stmtstruct.cobegin->statements;
    if (cur_stmt == NIL) 
	Punt("CF_Cobegin_Stmt: Empty cobegin statement encountered", stmt);

    while (cur_stmt != NIL) {
	temp = CF_Stmt(cur_stmt, entry_node);

	cf_info.break_list = AppendLptr(temp.break_list, cf_info.break_list);
	cf_info.cont_list = AppendLptr(temp.cont_list, cf_info.cont_list);
	cf_info.return_list = AppendLptr(temp.return_list, cf_info.return_list);
	cf_info.switch_list = AppendLptr(temp.switch_list, cf_info.switch_list);

	if (temp.exit_node != NIL) ConnectFlowNodes(temp.exit_node, exit_node);
	cur_stmt = cur_stmt->lex_next;
    }

    cf_info.exit_node = exit_node;
    return cf_info;
}

static bool CF_ParloopIterates(Stmt stmt)
{
    ParLoop parloop;
    bool known = TRUE;
    sint init, final, incr;

    assert(stmt != NIL && stmt->type == ST_PARLOOP);

    parloop = stmt->stmtstruct.parloop;
    if (!known) return FALSE;

    if (!known) return FALSE;

    if (!known) return FALSE;

    if ((incr >= 0 && init <= final) || (incr < 0 && init >= final))
        return TRUE;
    else return FALSE;
}

/* 
 * Build Control Flow graph for a parallel loop statement.
 */

static _CFInfo CF_Parloop_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo prologue_info, body_info, epilogue_info, epilogue2_info, cf_info;
    FlowNode init_cond, iter_cond, loop_exit, loop_body, loop_epilogue;
    FlowNode loop_epilogue2, pstmt_comp_entry, pstmt_comp_exit;
    Stmt comp_stmt, body_stmt, epilogue_stmt;
    Lptr cur_elmnt;

    init_cond = NewFlowNode(NT_ParloopInitCond, flow_graph);
    init_cond->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = init_cond;
    stmt->flow->flow_node_list = NewLptr((Void *) init_cond);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, init_cond);

    comp_stmt = Parloop_Stmts_Prologue_Stmt(stmt);
    assert(comp_stmt != NIL && comp_stmt->type == ST_COMPOUND);

    pstmt_comp_entry = NewFlowNode(NT_PStmtCompEntry, flow_graph);
    pstmt_comp_entry->pcode_ptr.stmt = comp_stmt;
    comp_stmt->flow = NewStmtFlow(comp_stmt->flow);
    comp_stmt->flow->entry_flow_node = pstmt_comp_entry;
    comp_stmt->flow->flow_node_list = NewLptr((Void *) pstmt_comp_entry);

    ConnectFlowNodes(init_cond, pstmt_comp_entry);

    /* process prologue, but stop before body */
    prologue_info = 
	CF_Stmts(comp_stmt->stmtstruct.compound->stmt_list, pstmt_comp_entry,
		 TRUE);

    body_stmt = Parloop_Stmts_Body_Stmt(stmt);
    assert(body_stmt != NIL && body_stmt->type == ST_BODY);

    loop_body = NewFlowNode(NT_ParloopBody, flow_graph);
    loop_body->pcode_ptr.stmt = body_stmt;
    body_stmt->flow = NewStmtFlow(body_stmt->flow);
    body_stmt->flow->entry_flow_node = loop_body;
    body_stmt->flow->flow_node_list = NewLptr((Void *) loop_body);

    if (prologue_info.exit_node != NIL) 
	ConnectFlowNodes(prologue_info.exit_node, loop_body);
						
    body_info = CF_Stmt(body_stmt->stmtstruct.bodystmt->statement, loop_body);

    iter_cond = NewFlowNode(NT_ParloopIterCond, flow_graph);
    iter_cond->pcode_ptr.stmt = stmt;
    stmt->flow->flow_node_list = 
	    AppendLptr(stmt->flow->flow_node_list, NewLptr((Void *) iter_cond));

    ConnectFlowNodes(iter_cond, loop_body);
    if (body_info.exit_node != NIL) 
	ConnectFlowNodes(body_info.exit_node, iter_cond);

    cur_elmnt = body_info.cont_list;
    while (cur_elmnt != NIL) {
	ConnectFlowNodes((FlowNode) cur_elmnt->ptr, iter_cond); 
	cur_elmnt = cur_elmnt->next;
    }
    body_info.cont_list = FreeLptr(body_info.cont_list);

    epilogue_stmt = Parloop_Stmts_First_Epilogue_Stmt(stmt);
    assert(epilogue_stmt != NIL && epilogue_stmt->type == ST_EPILOGUE);

    loop_epilogue = NewFlowNode(NT_ParloopMainEpilogue, flow_graph);
    loop_epilogue->pcode_ptr.stmt = epilogue_stmt;
    epilogue_stmt->flow = NewStmtFlow(epilogue_stmt->flow);
    epilogue_stmt->flow->entry_flow_node = loop_epilogue;
    epilogue_stmt->flow->flow_node_list = NewLptr((Void *) loop_epilogue);

    ConnectFlowNodes(iter_cond, loop_epilogue);

    epilogue_info = CF_Stmt(epilogue_stmt->stmtstruct.epiloguestmt->statement, 
		      	    loop_epilogue);

    /* 
     * GEH - changed break successors to main epilogue, 
     * not pstmt_comp_exit 
     */
    cur_elmnt = body_info.break_list;
    while (cur_elmnt != NIL) {
	ConnectFlowNodes((FlowNode) cur_elmnt->ptr, loop_epilogue);
	cur_elmnt = cur_elmnt->next;
    }
    body_info.break_list = FreeLptr(body_info.break_list);

    pstmt_comp_exit = NewFlowNode(NT_PStmtCompExit, flow_graph);
    pstmt_comp_exit->pcode_ptr.stmt = comp_stmt;
    comp_stmt->flow->flow_node_list = 
			    AppendLptr(comp_stmt->flow->flow_node_list, 
				       NewLptr((Void *) pstmt_comp_exit));

    if (epilogue_info.exit_node != NIL) 
	ConnectFlowNodes(epilogue_info.exit_node, pstmt_comp_exit);

    /* Handle auxiliary epilogue statements */

    epilogue_stmt = epilogue_stmt->lex_next;
    while (epilogue_stmt != NIL) {
	assert(epilogue_stmt->type == ST_EPILOGUE);

	loop_epilogue2 = NewFlowNode(NT_ParloopAuxEpilogue, flow_graph);
	loop_epilogue2->pcode_ptr.stmt = epilogue_stmt;
	epilogue_stmt->flow = NewStmtFlow(epilogue_stmt->flow);
	epilogue_stmt->flow->entry_flow_node = loop_epilogue2;
	epilogue_stmt->flow->flow_node_list = NewLptr((Void *) loop_epilogue2);

	epilogue2_info = CF_Stmt(
			    epilogue_stmt->stmtstruct.epiloguestmt->statement,
			    loop_epilogue2);

	if (epilogue2_info.exit_node != NIL)
	    Punt("CF_Parloop_Stmt: Auxiliary Epilogue stmt must end with goto",
		 stmt);

	epilogue_info.break_list = 
		AppendLptr(epilogue_info.break_list, epilogue2_info.break_list);
	epilogue_info.cont_list = 
		AppendLptr(epilogue_info.cont_list, epilogue2_info.cont_list);
	epilogue_info.return_list = 
	       AppendLptr(epilogue_info.return_list,epilogue2_info.return_list);
	epilogue_info.switch_list = 
	       AppendLptr(epilogue_info.switch_list,epilogue2_info.switch_list);

	epilogue_stmt = epilogue_stmt->lex_next;
    }

    loop_exit = NewFlowNode(NT_ParloopExit, flow_graph);
    loop_exit->pcode_ptr.stmt = stmt;
    stmt->flow->flow_node_list = 
	    AppendLptr(stmt->flow->flow_node_list, NewLptr((Void *) loop_exit));

    ConnectFlowNodes(pstmt_comp_exit, loop_exit);
    /* GEH - remove short-circuit path if cannot occur - 4/17/95 */
    if (!CF_ParloopIterates(stmt)) ConnectFlowNodes(init_cond, loop_exit);

    cf_info.break_list = 
	AppendLptr(AppendLptr(prologue_info.break_list, body_info.break_list),
		   epilogue_info.break_list);

    cf_info.cont_list = 
	AppendLptr(AppendLptr(prologue_info.cont_list, body_info.cont_list),
		   epilogue_info.cont_list);

    cf_info.return_list = 
	AppendLptr(AppendLptr(prologue_info.return_list, body_info.return_list),
		   epilogue_info.return_list);

    cf_info.switch_list = 
	AppendLptr(AppendLptr(prologue_info.switch_list, body_info.switch_list),
		   epilogue_info.switch_list);

    cf_info.exit_node = loop_exit;
    return cf_info;
}

/* 
 * Build Control Flow graph for a serial loop statement.
 */

static _CFInfo CF_Serloop_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode for_initcond, for_itercond, for_exit;
    FlowNode do_entry, do_cond, do_exit;
    Lptr cur_elmnt;

    switch(stmt->stmtstruct.serloop->loop_type) {

	case LT_FOR:
	/* 
	 * even though while loop has no init or iter exprs, still use same
	 * CFG and node names as for loop 
	 */
	case LT_WHILE:

	    for_initcond = NewFlowNode(NT_SerloopInitCond, flow_graph);
	    for_initcond->pcode_ptr.stmt = stmt;
	    stmt->flow = NewStmtFlow(stmt->flow);
	    stmt->flow->entry_flow_node = for_initcond;
	    stmt->flow->flow_node_list = NewLptr((Void *) for_initcond);
	    if (pred_node != NIL) ConnectFlowNodes(pred_node, for_initcond);

	    cf_info = CF_Stmt(stmt->stmtstruct.serloop->loop_body,for_initcond);

	    for_itercond = NewFlowNode(NT_SerloopIterCond, flow_graph);
	    for_itercond->pcode_ptr.stmt = stmt;
	    stmt->flow->flow_node_list = 
		    AppendLptr(stmt->flow->flow_node_list, 
			       NewLptr((Void *) for_itercond));

	    if (cf_info.exit_node != NIL) 
		ConnectFlowNodes(cf_info.exit_node, for_itercond);
	    if (for_initcond->succ != NIL)
		ConnectFlowNodes(for_itercond,
				 (FlowNode)for_initcond->succ->ptr);

	    cur_elmnt = cf_info.cont_list;
	    while (cur_elmnt != NIL) {
		ConnectFlowNodes((FlowNode) cur_elmnt->ptr, for_itercond); 
		cur_elmnt = cur_elmnt->next;
	    }
	    cf_info.cont_list = FreeLptr(cf_info.cont_list);

	    for_exit = NewFlowNode(NT_SerloopExit, flow_graph);
	    for_exit->pcode_ptr.stmt = stmt;
	    stmt->flow->flow_node_list = 
		    AppendLptr(stmt->flow->flow_node_list,
			       NewLptr((Void *) for_exit));
	    ConnectFlowNodes(for_initcond, for_exit);
	    ConnectFlowNodes(for_itercond, for_exit);

	    cur_elmnt = cf_info.break_list;
	    while (cur_elmnt != NIL) {
		ConnectFlowNodes((FlowNode) cur_elmnt->ptr, for_exit);
		cur_elmnt = cur_elmnt->next;
	    }
	    cf_info.break_list = FreeLptr(cf_info.break_list);

	    cf_info.exit_node = for_exit;
	    break;

	case LT_DO:

	    do_entry = NewFlowNode(NT_SerloopEntry, flow_graph);
	    do_entry->pcode_ptr.stmt = stmt;
	    stmt->flow = NewStmtFlow(stmt->flow);
	    stmt->flow->entry_flow_node = do_entry;
	    stmt->flow->flow_node_list = NewLptr((Void *) do_entry);

	    if (pred_node != NIL) ConnectFlowNodes(pred_node, do_entry);
	    cf_info = CF_Stmt(stmt->stmtstruct.serloop->loop_body, do_entry);

	    do_cond = NewFlowNode(NT_SerloopCond, flow_graph);
	    do_cond->pcode_ptr.stmt = stmt;

	    stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list, 
						   NewLptr((Void *) do_cond));

	    if (cf_info.exit_node != NIL) 
		    ConnectFlowNodes(cf_info.exit_node, do_cond);
	    if (do_entry->succ != NIL)
		    ConnectFlowNodes(do_cond, (FlowNode)do_entry->succ->ptr);

	    cur_elmnt = cf_info.cont_list;
	    while (cur_elmnt != NIL) {
		ConnectFlowNodes((FlowNode) cur_elmnt->ptr, do_cond); 
		cur_elmnt = cur_elmnt->next;
	    }
	    cf_info.cont_list = FreeLptr(cf_info.cont_list);

	    do_exit = NewFlowNode(NT_SerloopExit, flow_graph);
	    do_exit->pcode_ptr.stmt = stmt;

	    stmt->flow->flow_node_list = AppendLptr(stmt->flow->flow_node_list, 
						   NewLptr((Void *) do_exit));

	    ConnectFlowNodes(do_cond, do_exit);

	    cur_elmnt = cf_info.break_list;
	    while (cur_elmnt != NIL) {
		ConnectFlowNodes((FlowNode) cur_elmnt->ptr, do_exit);
		cur_elmnt = cur_elmnt->next;
	    }
	    cf_info.break_list = FreeLptr(cf_info.break_list);

	    cf_info.exit_node = do_exit;
	    break;

	default:
	    Punt("CF_Serloop_Stmt: Invalid serial loop type", stmt);
	    break;
    }
    return cf_info;
}

/*
 * Check to see if expr is a call to exit function
 */

static int Is_Exit_Func_Call(expr)
Expr expr;
{
    int i;

    assert(expr != NIL);

    if (expr->opcode == OP_call) {
	assert(expr->operands->sibling == NIL ||
	       expr->operands->sibling->sibling == NIL);

	if (expr->operands->opcode == OP_var) {

	    for (i = 0; i < NUM_PROG_EXIT_FUNCS; i++) {

		if (!strcmp(ProgExitFunc[i], expr->operands->value.var_name)) {
		    return TRUE;
		}
	    }
	}
    }
    return FALSE;
}

/*
 * Check expr and all child and next expressions for exit call.
 */

static int CF_Expr_Contains_Exit_Call(expr)
Expr expr;
{
    Expr sib;

    while (expr != NIL) {

	if (Is_Exit_Func_Call(expr)) return TRUE;

        for (sib = expr->operands; sib != NIL; sib = sib->sibling) {
            if (CF_Expr_Contains_Exit_Call(sib)) return TRUE; 
        }
        expr = expr->next;
    }
    return FALSE;
}

/* 
 * Build Control Flow graph for an expression statement.
 */

static _CFInfo CF_Expr_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode flow_node;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);


    flow_node = NewFlowNode(NT_Expr, flow_graph);
    flow_node->pcode_ptr.stmt = stmt;
    stmt->flow = NewStmtFlow(stmt->flow);
    stmt->flow->entry_flow_node = flow_node;
    stmt->flow->flow_node_list = NewLptr((Void *) flow_node);

    if (pred_node != NIL) ConnectFlowNodes(pred_node, flow_node);

    if (CF_Expr_Contains_Exit_Call(stmt->stmtstruct.expr)) {
    	cf_info.return_list = NewLptr((Void *) flow_node);
    }
    else {
	cf_info.exit_node = flow_node;
    }
    return cf_info;
}

/* 
 * Build Control Flow graph for a statement.
 */

static _CFInfo CF_Stmt(stmt, pred_node)
Stmt stmt;
FlowNode pred_node;
{
    _CFInfo cf_info;
    FlowNode flow_node;
    Lptr cur_elmnt, node_list;
    Label cur_label;
    Integer dummy;

    if (!stmt)
    {
	InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, NIL);
	return cf_info;
    }

    switch (stmt->type) {
	case ST_NOOP:
	    cf_info = CF_Noop_Stmt(stmt, pred_node);
	    break;
	case ST_CONT:
	    cf_info = CF_Cont_Stmt(stmt, pred_node);
	    break;
	case ST_BREAK:
	    cf_info = CF_Break_Stmt(stmt, pred_node);
	    break;
	case ST_RETURN:
	    cf_info = CF_Return_Stmt(stmt, pred_node);
	    break;
	case ST_GOTO:
	    cf_info = CF_Goto_Stmt(stmt, pred_node);
	    break;
	case ST_COMPOUND:
	    cf_info = CF_Compound_Stmt(stmt, pred_node);
	    break;
	case ST_IF:
	    cf_info = CF_If_Stmt(stmt, pred_node);
	    break;
	case ST_SWITCH:
	    cf_info = CF_Switch_Stmt(stmt, pred_node);
	    break;
	case ST_PSTMT:
	    cf_info = CF_P_Stmt(stmt, pred_node);
	    break;
	case ST_ADVANCE:
	    cf_info = CF_Advance_Stmt(stmt, pred_node);
	    break;
	case ST_AWAIT:
	    cf_info = CF_Await_Stmt(stmt, pred_node);
	    break;
	case ST_MUTEX:
	    cf_info = CF_Mutex_Stmt(stmt, pred_node);
	    break;
	case ST_COBEGIN:
	    cf_info = CF_Cobegin_Stmt(stmt, pred_node);
	    break;
	case ST_PARLOOP:
	    cf_info = CF_Parloop_Stmt(stmt, pred_node);
	    break;
	case ST_SERLOOP:
	    cf_info = CF_Serloop_Stmt(stmt, pred_node);
	    break;
	case ST_EXPR:
	    cf_info = CF_Expr_Stmt(stmt, pred_node);
	    break;
	case ST_BODY:
	    Punt("CF_Stmt: Unexpected body statement encountered", stmt);
	    break;
	case ST_EPILOGUE:
	    Punt("CF_Stmt: Unexpected epilogue statement encountered", stmt);
	    break;
	default:
	    Punt("CF_Stmt: Invalid statement type", stmt);
	    break;
    }

    /* process labels attached to this statement */

    cur_label = stmt->labels;
/*
    if (cur_label == NIL && pred_node == NIL && stmt->type != ST_COMPOUND) {
	fprintf(Flog, "# cf_contr-flow: CF_Stmt: Warning: statement in file %s on line %d is unreachable\n", 
		stmt->filename, stmt->lineno);
    }
*/

    while (cur_label != NIL) {
	switch (cur_label->type) {

	    case LB_LABEL:
		if (C_find(goto_source_table, cur_label->val, 0, &dummy, 
			   (Pointer *) &node_list)) {
		    /* connect all goto flow nodes with corresponding label 
		       to the current statement's entry node */

		    cur_elmnt = node_list;
		    while (cur_elmnt != NIL) {
			if (stmt->parent != NIL &&
			    stmt->parent->type == ST_EPILOGUE) {
			    
			    ConnectFlowNodes((FlowNode) cur_elmnt->ptr,
					   stmt->parent->flow->entry_flow_node);
			}
			else {
			    ConnectFlowNodes((FlowNode) cur_elmnt->ptr, 
					     stmt->flow->entry_flow_node);
			}
			cur_elmnt = cur_elmnt->next;
		    }
		    FreeLptr(node_list);
		    C_delete(goto_source_table, cur_label->val, 0);
		}

		/* add to goto dest table, flag error if already present */
		if (!C_find(goto_dest_table, cur_label->val, 0, &dummy, 
			   (Pointer *) &flow_node)) {
		    C_update(goto_dest_table, cur_label->val, 0, 0, 
			     (Pointer) stmt->flow->entry_flow_node);
		}
		else Punt("CF_Stmt: Duplicate Label encountered", stmt);
		break;

	    case LB_CASE:
	    case LB_DEFAULT:
		/* add stmt entry flow node to switch list */
		cf_info.switch_list = 
		       AppendLptr(NewLptr((Void *) stmt->flow->entry_flow_node),
				  cf_info.switch_list);
		break;

	    default:
		Punt("CF_Stmt: Invalid label type", stmt);
		break;
	}
	cur_label = cur_label->next;
    }

    return cf_info;
}

	
/* 
 * Build Control Flow graph for a list of statements.
 */

static _CFInfo CF_Stmts(stmts, pred_node, parloop_flag)
Stmt stmts; 
FlowNode pred_node;
int parloop_flag;
{
    _CFInfo cf_info;
    _CFInfo temp;

    InitCFInfo(&cf_info, NIL, NIL, NIL, NIL, pred_node);

    while (stmts != NIL) {

	if (parloop_flag &&
	    (stmts->type == ST_BODY || stmts->type == ST_EPILOGUE)) break;

	temp = CF_Stmt(stmts, cf_info.exit_node);

	cf_info.break_list = AppendLptr(temp.break_list, cf_info.break_list);
	cf_info.cont_list = AppendLptr(temp.cont_list, cf_info.cont_list);
	cf_info.return_list = AppendLptr(temp.return_list, cf_info.return_list);
	cf_info.switch_list = AppendLptr(temp.switch_list, cf_info.switch_list);

	cf_info.exit_node = temp.exit_node;
	stmts = stmts->lex_next; 
    }

    return cf_info;
}

static void CF_Relink_Child_Stmt(parent, old_child, new_child)
Stmt parent, old_child, new_child;
{
    assert(parent != NIL);
    switch (parent->type) {
	case ST_COMPOUND:
	    assert(parent->stmtstruct.compound->stmt_list == old_child);
	    parent->stmtstruct.compound->stmt_list = new_child;
	    break;
	case ST_IF:
	    if (parent->stmtstruct.ifstmt->then_block == old_child) {
		parent->stmtstruct.ifstmt->then_block = new_child;
	    }
	    else {
		assert(parent->stmtstruct.ifstmt->else_block == old_child);
		parent->stmtstruct.ifstmt->else_block = new_child;
	    }
	    break;
	case ST_SWITCH:
	    assert(parent->stmtstruct.switchstmt->switchbody == old_child);
	    parent->stmtstruct.switchstmt->switchbody = new_child;
	    break;
	case ST_PSTMT:
	    assert(parent->stmtstruct.pstmt->stmt == old_child);
	    parent->stmtstruct.pstmt->stmt = new_child;
	    break;
	case ST_MUTEX:
	    assert(parent->stmtstruct.mutex->statement == old_child);
	    parent->stmtstruct.mutex->statement = new_child;
	    break;
	case ST_COBEGIN:
	    assert(parent->stmtstruct.cobegin->statements == old_child);
	    parent->stmtstruct.cobegin->statements = new_child;
	    break;
	case ST_PARLOOP:
	    assert(parent->stmtstruct.parloop->pstmt->stmt == old_child);
	    parent->stmtstruct.parloop->pstmt->stmt = new_child;
	    break;
	case ST_SERLOOP:
	    assert(parent->stmtstruct.serloop->loop_body == old_child);
	    parent->stmtstruct.serloop->loop_body = new_child;
	    break;
	case ST_BODY:
	    assert(parent->stmtstruct.bodystmt->statement == old_child);
	    parent->stmtstruct.bodystmt->statement = new_child;
	    break;
	case ST_EPILOGUE:
	    assert(parent->stmtstruct.epiloguestmt->statement == old_child);
	    parent->stmtstruct.epiloguestmt->statement = new_child;
	    break;
	case ST_NOOP:
	case ST_CONT:
	case ST_BREAK:
	case ST_RETURN:
	case ST_GOTO:
	case ST_ADVANCE:
	case ST_AWAIT:
	case ST_EXPR:
	default:
	    Punt("CF_Relink_Child_Stmt: Invalid statement type", parent);
	    break;
    }
}

/* 
 * Build Control Flow graph for the given function.
 */

void CF_Build_CFG_Function(func)
FuncDcl func;
{
    _CFInfo cf_info;
    FlowNode func_entry, func_exit;
    Lptr cur_return_list, succ, pred;
    FlowNode flow_node;
    int unreachable = FALSE;
    Stmt ur_stmt, lex_prev, lex_next;

    if (debug_yes || verbose_yes) {
	fprintf(Flog, "..Control Flow Analysis beginning on fn (%s)\n",
		func->name);
    }

    /* allocate goto tables if necessary */

    if (!tables_allocated) {
	if (debug_yes) {
	    fprintf(Flog, "..Allocating Goto Tables\n");
	}
	goto_source_table = C_open_name_table(GOTO_TABLE_ENTRIES);
	goto_dest_table = C_open_name_table(GOTO_TABLE_ENTRIES);

	if (goto_source_table < 0 || goto_dest_table < 0) {
	    Punt("CF_Build_CFG_Function: Cannot allocate goto tables, see c_symbol.h\n", 
		 NIL);
	}
	else tables_allocated = TRUE;
    }

    flow_graph = NewFlowGraph(func);

    /* create and init. control flow nodes for function entry and exit */
    func_entry = NewFlowNode(NT_FuncEntry, flow_graph);
    func_entry->pcode_ptr.func = func;
    func_entry->pred = NIL;

    func_exit = NewFlowNode(NT_FuncExit, flow_graph);
    func_exit->pcode_ptr.func = func;
    func_exit->succ = NIL;

    /* remove old func flow and create new one */
    func->flow = NewFuncFlow(func->flow);
    func->flow->entry_flow_node = func_entry;
    func->flow->exit_flow_node = func_exit;
    func->flow->flow_graph = flow_graph;

    /* calculate contr flow graph for body of function */
    cf_info = CF_Stmts(func->stmt, func_entry, FALSE);

    /* check lists of control flow markers to make sure all taken care of */
    if (cf_info.break_list != NIL) {
	flow_node = (FlowNode) cf_info.break_list->ptr;
	Punt("CF_Func: Illegal break statement encountered", 
	     flow_node->pcode_ptr.stmt);
    }

    if (cf_info.cont_list != NIL) {
	flow_node = (FlowNode) cf_info.cont_list->ptr;
	Punt("CF_Func: Illegal continue statement encountered",
	     flow_node->pcode_ptr.stmt);
    }

    if (cf_info.switch_list != NIL) {
	flow_node = (FlowNode) cf_info.switch_list->ptr;
	Punt("CF_Func: Illegal case or default label encountered",
	     flow_node->pcode_ptr.stmt);
    }

    if (cf_info.exit_node != NIL) 
	ConnectFlowNodes(cf_info.exit_node, func_exit);

    /* check to make sure all goto statment nodes have been connected to
       the corresponding labeled statement nodes */
    if (C_forall(goto_source_table, (C_Function) NIL) != 0) {
	C_forall(goto_source_table, (C_Function) CF_Goto_Error);
	exit(-1);
    }

    /* connect all return statement nodes to function exit node */
    cur_return_list = cf_info.return_list;
    while (cur_return_list != NIL) {
	ConnectFlowNodes((FlowNode) cur_return_list->ptr, func_exit);
	cur_return_list = cur_return_list->next;
    }
    FreeLptr(cf_info.return_list);

    /* clear goto tables' entries */
#if 0
    C_clear(goto_source_table);
    C_clear(goto_dest_table);
#endif
    /* BCC - garbage collection - 8/21/96 */
    C_clear_free_name(goto_source_table);
    C_clear_free_name(goto_dest_table);

    if (debug_yes || verbose_yes) {
	fprintf(Flog, "..Control Flow Analysis complete for fn (%s)\n",
		func->name);
    }
    if (debug_yes) {
	fprintf(Flog, "....Number of Flow Nodes in Flow Graph: %d\n",
		func->flow->flow_graph->num_nodes);
    }

    
    /* Check to make sure that there are no unreachable flow nodes */
    for (flow_node = flow_graph->first_node; 
	 flow_node != NIL; 
	 flow_node = flow_node->next) {

	succ = flow_node->succ;
        pred = flow_node->pred;

        /* only flow node with no successors should be function exit node */
        assert(succ != NIL || flow_node->type == NT_FuncExit);

        if (pred == NIL && flow_node->type != NT_FuncEntry) {
	    if (flow_node->type == NT_FuncExit) 
		Punt("Function has no detectable exit", NIL);
	    if (flow_node->pcode_ptr.stmt->flow->entry_flow_node == flow_node) {
		unreachable = TRUE;
		break;
	    }
	    else {
		fprintf(Ferr, "Warning: Statement in file %s at line %d contains unreachable code;\n",
			flow_node->pcode_ptr.stmt->filename, 
			flow_node->pcode_ptr.stmt->lineno);
		fprintf(Ferr, "\tNot able to remove unreachable code for this case yet.\n");
	    }
        }
    }

    /* remove unreachable statement and redo control flow analysis */
    if (unreachable) {
	ur_stmt = flow_node->pcode_ptr.stmt;

	if (debug_yes || verbose_yes) {
	    fprintf(Flog, "$ Removing Unreachable Statement on line %d\n",
		    ur_stmt->lineno);
	}

	lex_prev = ur_stmt->lex_prev;
	lex_next = ur_stmt->lex_next;
	if (lex_prev != NIL) lex_prev->lex_next = lex_next;
	else CF_Relink_Child_Stmt(ur_stmt->parent, ur_stmt, lex_next);
	if (lex_next != NIL) lex_next->lex_prev = lex_prev;
	RemoveStmt(ur_stmt);

	LinkStmts(func);
	LinkLoops(func);
	if (debug_yes || verbose_yes) {
	    fprintf(Flog, "..Rebuilding Control Flow Graph.\n");
	}
	CF_Build_CFG_Function(func);
    }
}
