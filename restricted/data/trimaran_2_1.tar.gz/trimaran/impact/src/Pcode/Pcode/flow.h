/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/

/*****************************************************************************\
 *	File:	flow.h
 *	Author:	Grant Haab and Wen-mei Hwu
\*****************************************************************************/


#ifndef FLOW_H
#define FLOW_H

#include <Pcode/impact_global.h>
#include <library/llist.h>
#include <library/set.h>
#include <Pcode/pcode.h>

typedef enum _LoopType {
        LT_PARLOOP,
        LT_SERLOOP,
        LT_IMPL_LOOP
} _LoopType;

typedef struct _LoopSumm {
	struct _Stmt *pcode_hdr;   /* pcode header statement:
				      BodyStmt for Parloop, 
				      Serloop Stmt for Serloop, 
				      Header Stmt for Implicit loop */
        _LoopType  loop_type;      /* type of loop (defined above) */
        int        header_bb;      /* index to loop header basic block */
        int        nesting_level;  /* nesting level of loop */
        Set        loop_bbs;       /* set of basic blocks in loop body */
        Set        back_edge_bbs;  /* set of back edge source bbs */
        Set        exit_bbs;       /* set of exit edge source bbs */
	Set	   out_bbs;	   /* set of exit edge dest bbs */
        Set        nested_loops;   /* set of nested loops indexes */
} _LoopSumm, *LoopSumm;

/* define flow node types */
typedef enum _NodeType {
	NT_FuncEntry=0,
	NT_FuncExit=1,
	NT_ParloopInitCond=2,
	NT_ParloopIterCond=3,
	NT_ParloopExit=4,
	NT_ParloopBody=5,
	NT_ParloopMainEpilogue=6,
	NT_ParloopAuxEpilogue=7,
	NT_PStmtCompEntry=8,
	NT_PStmtCompExit=9,
	NT_SerloopEntry=10,
	NT_SerloopInitCond=11,
	NT_SerloopCond=12,
	NT_SerloopIterCond=13,
	NT_SerloopExit=14,
	NT_CobeginEntry=15,
	NT_CobeginExit=16,
	NT_MutexEntry=17,
	NT_MutexExit=18,
	NT_Advance=19,
	NT_Await=20,
	NT_PStmtEntry=21,
	NT_PStmtExit=22,
	NT_SwitchCond=23,
	NT_SwitchExit=24,
	NT_IfCond=25,
	NT_IfExit=26,
	NT_CompoundEntry=27,
	NT_CompoundExit=28,
	NT_Break=29,
	NT_Continue=30,
	NT_Goto=31,
	NT_Return=32,
	NT_Expr=33,
	NT_Null=34
} _NodeType;

#define NUM_NODE_TYPES 	35

extern char *NodeTypeNames[NUM_NODE_TYPES];

typedef struct _BBGraph {
	struct _BBNode	*first_node; /* the first node of the bb graph */	
	struct _BBNode	*last_node;  /* the last node of the bb graph */
	unsigned int	num_nodes;   /* the number of nodes in the bb graph */
	struct _BBNode	**bb_node;   /* array of pointers to bb nodes */
				     /* in depth-first order */
        unsigned int    num_lbbs;    /* the number of nodes in loop_bbs array */
        struct _BBNode  **loop_bbs;  /* array of pointers to bb nodes in loops*/
	struct _BBNode	*entry_node; /* the function entry node for the graph */
	struct _BBNode	*exit_node;  /* the function exit node for the graph */
	struct _FuncDcl *func;       /* function structure assoc. with graph */
	struct _LoopSumm *loop_summ; /* array of loop summary information */
	int		num_loops;   /* number of loops in above array */
	/* boolean fields specifying what has been calculated go here */
	bool		has_doms;   /* have dominators been calculated */
	bool            has_post_doms;/* have post dominators been calculated */
	bool		has_rbbs;   /* have reaching bb's for loops been calc */
	bool		has_loops;  /* has loop summary info been calculated */
	bool		has_lvs;    /* have live variables been calculated */
	bool		has_ads;    /* have available defs been calculated */
	bool		has_aus;    /* have available uses been calculated */
	bool		has_rds;    /* have reaching defs been calculated */
	bool		has_rus;    /* have reaching uses been calculated */
	bool		has_lcrds;  /* are loop-carried reaching defs present */
	bool		has_lcrus;  /* are loop-carried reaching uses present */
} _BBGraph, *BBGraph;

#define BBNODE_VISITED	0x1	/* flag bits used below */

typedef struct _BBNode {
	_Lptr		*pred; 	/* list of predecessor basic block nodes */
	_Lptr		*succ; 	/* list of successor basic block nodes */
	_Lptr		*flows;	/* list of flow nodes for this basic block */
	unsigned int	index;	/* index into bb_node array of BBGraph */
	struct _BBNode	*next;	/* next bb node (Used internally) */
	int 		flags;	/* flags for internal use by algorithms */
	struct _ProfBB  *profile; /* LCW - profile information - 12/23/95 */

	/* fields for calculated info go here */
	Set		dominators;	/* set of nodes which dominate this */
	Set             post_dominators;/* set of nodes which post dom this */

	/* nesting level of nearest parloop, (= # of elmnts in rbbs4loop - 1) */
	char		loop_depth;
	/* array of sets of reaching basic blocks for each enclosing parloop */
	Set		*rbbs4loop;	

	/* The following sets reused by many types of dataflow analyses. */
	Set		d_gen;	/* set of definitions generated in this bb */
	Set		d_kill; /* set of definitions killed in this bb */
	Set		u_gen;	/* set of uses generated in this bb */
	Set		u_kill; /* set of uses killed in this bb */

	/* The following sets are specific to a particular dataflow analysis.*/
	Set		lv_in;	/* set of variables live at start of this bb */
	Set		lv_out;	/* set of variables live at end of this bb */

	Set		ad_in;  /* set of available defs at start of this bb */
	Set		ad_out;	/* set of available defs at end of this bb */
	Set		au_in;	/* set of available uses at start of this bb */
	Set		au_out; /* set of available uses at end of this bb */

	Set		rd_in;  /* set of reaching defs at start of this bb */
	Set		rd_out;	/* set of reaching defs at end of this bb */
	Set		ru_in;	/* set of reaching uses at start of this bb */
	Set		ru_out; /* set of reaching uses at end of this bb */

	Set		lcrd_in;  /* loop-carried reaching defs at start of bb*/
	Set		lcrd_out; /* loop-carried reaching defs at end of bb */
	Set		lcru_in;  /* loop-carried reaching uses at start of bb*/
	Set		lcru_out; /* loop-carried reaching uses at end of bb */
} _BBNode, *BBNode;

typedef struct _FlowGraph {
	struct _FlowNode *first_node;/* the first node of the flow graph */
	struct _FlowNode *last_node; /* the last node of the flow graph */
	unsigned int	num_nodes;   /* the number of nodes in the flow graph */
	struct _FuncDcl *func;       /* function structure assoc. with graph */
	struct _BBGraph *bb_graph;   /* basic block graph for this flow graph */

	uint		num_acc;     /* number of elements in access array */
	struct _a_access **access;   /* array of pointers to accesses */

	uint		num_var;     /* number of elements in the var array */
	struct _DDSymEntry **var;    /* array of pointers to sym entries */

	/* boolean fields specifying what has been calculated go here */
	bool		has_bbs;     /* true if bb_graph present */
	bool		has_defuse;  /* true if def-use sets present */
	bool		has_lvs;     /* true if live variables present */
	bool		has_ads;     /* true if available defs present */
	bool		has_aus;     /* true if available defs present */
	bool		has_rds;     /* true if reaching defs present */
	bool		has_rus;     /* true if reaching defs present */
	bool		has_lcrds;   /* true if loop-car. reach defs present */
	bool		has_lcrus;   /* true if loop-car. reach uses present */
} _FlowGraph, *FlowGraph;

typedef struct _FlowNode {
	_Lptr			*pred;	/* list of predecessor flow nodes */
	_Lptr			*succ;	/* list of successor flow nodes */
	union {
	    struct _Stmt  	*stmt;	/* ptr to statement assoc. with node */
	    struct _FuncDcl	*func;	/* ptr to function assoc. with node */
	} pcode_ptr;
	struct _BBNode 		*bb;	/* basic block which contains node */
	_NodeType		type;	/* part of statement assoc. with node */
	sint16			order;	/* ordering of flow nodes in bb */
	struct _FlowNode 	*next;	/* next flow node (Used internally) */

	/* The following sets reused by many types of dataflow analyses. */
	Set			must_def;/* set of known access definitions */
	Set			may_def; /* set of possible access definitions*/
	Set			may_use; /* set of possible access uses */
	Set			must_def_var; /* set of known var definitions */
	Set			may_def_var; /*set of possible var definitions*/
	Set			may_use_var; /* set of possible var uses */
	Set			d_gen;   /* definition generation set */
	Set			d_kill;  /* definition kill set */
	Set			u_gen;   /* use generation set */
	Set			u_kill;  /* use kill set */

	/* The following sets are specific to a particular dataflow analysis. */
	Set			l_in;   /*live variables at start of flow node*/
	Set			l_out;  /* live variables at end of flow node */

	Set			a_defs;	/* defs available at end of flow node */
	Set			a_uses; /* uses available at end of flow node */

	Set			r_defs;	/* defs reaching start of flow node*/
	Set			r_uses; /* uses reaching start of flow node*/

	Set			lcr_defs;/*loop-car. defs reaching start of fn*/
	Set			lcr_uses;/*loop-car. uses reaching start of fn*/
} _FlowNode, *FlowNode;
	
/* connected to the flow field of a _FuncDcl structure */
typedef struct _FuncFlow {
	_FlowGraph *flow_graph;	    /* pointer to the flow graph for this func*/
        _FlowNode *entry_flow_node; /* pointer to the func entry flow node */
        _FlowNode *exit_flow_node;  /* pointer to the func exit flow node */
} _FuncFlow, *FuncFlow;             /* function control flow info */

/* connected to the flow field of a _Stmt structure */
typedef struct _StmtFlow {
        _Lptr *flow_node_list;      /* pointer to the flow nodes assoc. with
                                       the statement (including entry node) */
        _FlowNode *entry_flow_node; /* pointer to the stmt entry flow node */
} _StmtFlow, *StmtFlow;             /* statement control flow info */

extern BBGraph NewBBGraph(FuncDcl func);
extern void RemoveBBGraph(BBGraph bbg);

extern BBNode NewBBNode(BBGraph bbg);
extern void ConnectBBNodes(BBNode pred, BBNode succ);
extern int IsPredBBNode(BBNode pred, BBNode node);
extern int IsSuccBBNode(BBNode succ, BBNode node);

extern void ResetBBGraphFlags(BBGraph bbg, int flags);
#define SET_BB_NODE_FLAGS(BBN, FLAGS)	((BBN)->flags |= (FLAGS))
#define RESET_BB_NODE_FLAGS(BBN, FLAGS)	((BBN)->flags &= ~(FLAGS))
#define IS_BB_NODE_FLAG_SET(BBN, FLAG)   ((BBN)->flags & (FLAG))

extern FlowGraph NewFlowGraph(FuncDcl func);
extern void RemoveFlowGraph(FlowGraph fg);

extern FlowNode	NewFlowNode(_NodeType node_type, FlowGraph fg);
extern void ConnectFlowNodes(FlowNode pred, FlowNode succ);
extern int IsPredFlowNode(FlowNode pred, FlowNode node);
extern int IsSuccFlowNode(FlowNode succ, FlowNode node);
extern FlowNode FindFlowNodeInList(_NodeType type, Lptr list);
extern uint FindFlowNodeDepth(FlowNode fn);

extern FuncFlow NewFuncFlow(FuncFlow old);
extern void RemoveFuncFlow(FuncFlow ff);

extern StmtFlow NewStmtFlow(StmtFlow old);
extern void RemoveStmtFlow(StmtFlow sf);

extern BBGraph bb_graph;
extern FlowGraph flow_graph;

#if 0
#define Set_subtract_union(a,b,c) \
	    ((temp = Set_subtract((a),(b))), Set_union(temp, (c))); \
	    Set_dispose(temp);  
#endif
#endif
