/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	init.h
 *	Author:	Nancy Warter and Wen-mei Hwu
 *	Modified from code written by: Po-hua Chang
 \*****************************************************************************/


#ifndef INIT_H
#define INIT_H

#include <Pcode/pcode.h>

/* 	NJW - the way that global variables (and static) are handled
 *	should be the same as hcode.  However, in pcode we also have
 *	local variables which will have initializers.  Code must be
 *	written to handle these cases.
 */

/*
 *	In this file, we will treat all initializers in a consistent
 *	manner. A final format will be guaranteed after applying the
 *	following functions.
 *
 *	In C, [K&R]
 *	1) An initializer is a list of initializers or a list of
 *		initializers nested in braces.
 *	2) All the expressions in the initializer for a static
 *		object or array must be constant expressions.
 *	3) A static object not explicitely initialized is initialized
 *		as if it (or its members) were assigned the constant 0.
 *	4) The initializer for a pointer or an object of arithmetic type
 *		is a single expression. Perhaps in braces.
 *	5) The initializer for a structure is either an expression of
 *		the same type, or a brace-enclosed list of initializers
 *		for its members in order. If there are fewer initializers
 *		in the list than members of the structure, the trailing
 *		members are initialized with 0. There may not be more
 *		initializers than members.
 *	6) The initializer for an array is a brace-enclosed list of
 *		initializers for its members. If the array has unknown
 *		size, the number of initializers determines the size
 *		of the array, and its type becomes complete. If the
 *		array has fixed size, the number of initializers may not
 *		exceed the number of members of the array; if there are
 *		fewer, the trailing members are initialzed with 0.
 *	7) As a special case, a character array may be initialized by
 *		a string literal. If the array has unknown size, the
 *		number of characters in the string, including the terminating
 *		null character, determines the size. If its size is fixed,
 *		the number of characters in the string, not counting the
 *		terminating null character, must not exceed the size of
 *		the array.
 *	8) The initializer for a union is either a single expression of
 *		the same type, or a brace-enclosed initializer for the
 *		first member of the union.
 *	9) An aggregate is a structure or array. If an aggregate contains
 *		members of aggregate type, the initialization rules apply
 *		recursively. Braces may be elided in the initialization
 *		as follows: if the initializer for an aggregate member
 *		that is itself an aggregate begins with a left brace, then
 *		the succeeding comma-separated list of initializers 
 *		initializes the members of the sbaggregate; it is erroneous
 *		for there to be more initializers than members. If, however,
 *		the initializer for a subaggregate does not begin with a
 *		left brace, then only enough elements from the list are taken 
 *		to account for the members of the subaggregate; any remaining
 *		members are left to initialize the next member of the aggregate
 *		of which the subaggregate is a part.	
 *
 *	The desirable final PCODE internal format:
 *	1) The initializer for a pointer or an object of arithmetic type
 *		is a single expression. (init->expr)
 *	2) The initializer for a structure is a list of initializers
 *		for its members. (init->set)
 *		f1 = init->set;
 *		f2 = init->set->next;
 *		f3 = init->set->next->next; ..... and so on.
 *	3) The initializer for a union is a set containing only one element.
 *		f1 = init->set;
 *	4) The initializer for an array is a list of initializers for its
 *		elements. (init->set)
 *		a[0] = init->set;
 *		a[1] = init->set->next;
 *		a[2] = init->set->next->next; ..... and so on.
 *	5) As a special case, a character array may be initialized by a
 *		string literal. (init->expr)
 *	6) !!! we do not allow initialization of union.
 */

extern void ProcessInit(VarDcl var, Scope poss_scopes);

#endif
