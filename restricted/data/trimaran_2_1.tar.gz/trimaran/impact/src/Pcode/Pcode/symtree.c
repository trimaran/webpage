/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	symtree.c
 *	Author: Nancy Warter and Wen-mei Hwu
 *	Modified from code written by:	Po-hua Chang
 *	Creation Date:	1988
 \*****************************************************************************/


#include <Pcode/impact_global.h>
#include <Pcode/symtree.h>
#include <Pcode/struct.h>
#include <Pcode/parms.h>

#undef  NEEDED

/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/
/*  	In pcode, symbols do not need to be renamed, can distinguish a symbol
 *	based on its scope_id and name.  This will allow easier reading of
 *	output code (either C or pcode).
 * 	In hcode, the following symbols may have to be renamed.
 *	auto : 		rename.
 *	extern :	no rename.
 *	global :	no rename.
 *	static :	rename.
 *	internal :	no rename.
 */
/*-------------------------------------------------------------------------*/
/*      Symbol Tree Management.
 *      1) SYMTREE FindSymT(name, scope_id, tree_type)
 *      2) SYMTREE AddSymT(name, scope_id, tree_type)
 */
static SymTree SymbolTree[MAX_TREE];

void InitSymbolTree() {
  int i;
  for(i=0; i < MAX_TREE; i++)
    SymbolTree[i] = 0;
}

/*      Allocate space for a new symbol.  */

static SymTree NewSymT() {
  SymTree new;
  new = ALLOCATE(_SymTree);
  new->symbol_name = 0;
  new->scope_id = 0;
  new->type = 0;
  new->status = 0;
  new->dcl.varDcl = 0;
  new->left = new->right = 0;
  return new;
}
/* find a symbol in the database */
/* SymbolTree[tree_type] - points to the desired tree */
SymTree FindSymT(name, scope_id, tree_type)
     char *name;
     int scope_id;
     int tree_type;
{
  int diff;
  SymTree ptr = SymbolTree[tree_type];
  while (ptr!=0) {
    diff = strcmp(ptr->symbol_name, name);
    if ((diff==0)&(ptr->scope_id==scope_id)&(ptr->type==tree_type)) 
      return ptr;
    if (diff<0)
      ptr = ptr->right;
    else
      ptr = ptr->left;
  }
  return 0;
}
/* (8/92) - don't need scope_id after renaming - unique reference to
 *          symbol tree.  Thus, provide a lookup w/o scope_id
 */
SymTree FindSymT_NoScopeId(name, tree_type)
     char *name;
     int tree_type;
{
  int diff;
  SymTree ptr = SymbolTree[tree_type];
  while (ptr!=0) {
    diff = strcmp(ptr->symbol_name, name);

	/* DMG - added check for invalid (<0) scope_id */
    if ((diff==0) && (ptr->type==tree_type) && (ptr->scope_id >= 0)) 
      return ptr;
    if (diff<0)
      ptr = ptr->right;
    else
      ptr = ptr->left;
  }
  return 0;
}

void Print_Tree(ptr)
     SymTree ptr;
{
  if(ptr == 0) return;
  Print_Tree(ptr->left);
  fprintf(Flog, "%s\n", ptr->symbol_name);
  Print_Tree(ptr->right);
}

void PrintSymT(tree_type)
     int tree_type;
{
  SymTree ptr = SymbolTree[tree_type];
  fprintf(Flog, "Print Symbol Tree -- Begin\n");
  Print_Tree(ptr);
  fprintf(Flog, "Print Symbol Tree -- End \n\n");
}

/* add a symbol */
SymTree AddSymT(name, scope_id, tree_type)
     char *name;
     int scope_id;
     int tree_type;
{
  int diff;
  SymTree ptr, last;
  if (SymbolTree[tree_type]==0) {
    ptr = NewSymT();
/*
    ptr->symbol_name = FindString(name);
 */
    ptr->symbol_name = NewName2(name);
    ptr->scope_id = scope_id;
    ptr->type = tree_type;
    SymbolTree[tree_type] = ptr;
    return ptr;
  }
  last = 0;
  ptr = SymbolTree[tree_type];
  while (ptr!=0) {
    diff = strcmp(ptr->symbol_name, name);
    if ((diff==0) && (ptr->scope_id==scope_id) && (ptr->type==tree_type))
      return ptr;
    if (diff<0) {
      last = ptr;
      ptr = ptr->right;
      if (ptr==0) {
	ptr = NewSymT();
	last->right = ptr;
/*
	ptr->symbol_name = FindString(name);
 */
	ptr->symbol_name = NewName2(name);
	ptr->scope_id = scope_id;
	ptr->type = tree_type;
	return ptr;
      }
    } else {
      last = ptr;
      ptr = ptr->left;
      if (ptr==0) {
	ptr = NewSymT();
	last->left = ptr;
/*
	ptr->symbol_name = FindString(name);
 */
	ptr->symbol_name = NewName2(name);
	ptr->scope_id = scope_id;
	ptr->type = tree_type;
	return ptr;
      }
    }
  }
}

#if NEEDED
void NullSymT(ptr) 
     SymTree ptr;
{
  ptr->symbol_name = 0;
  ptr->scope_id = 0;
  ptr->type = 0;
  ptr->status = 0;
  ptr->dcl.varDcl = 0;
}

/* clear the non-global elements of the symbol table - this doesn't
 * get rid of the element because a global element may be a child of a
 * local element.  The tree shouldn't get too large because it is
 * on a per file basis.  May do something more intelligent later if
 * needed.
 * Should be called as ClearSymT(SymbolTree[tree_type]).
 */
void ClearSymT(ptr) 
     SymTree ptr;
{
  if(ptr != 0) {
    if(ptr->scope_id != 0)
      NullSymT(ptr);
    ClearSymT(ptr->right);
    ClearSymT(ptr->left);
  }
}

void ClearSymTrees()
{
  ClearSymT(SymbolTree[TT_VAR]);
  ClearSymT(SymbolTree[TT_STRUCT]);
  ClearSymT(SymbolTree[TT_UNION]);
  ClearSymT(SymbolTree[TT_ENUM]);
  ClearSymT(SymbolTree[TT_ENUMFIELD]);
}
#endif

/*=============================================================================/
 * BCC - added to free the symbol trees for Pinline after processing each
 *       file.  Reset TT_VAR, TT_STRUCT, TT_UNION, TT_ENUM, TT_ENUMFIELD tables.
 *============================================================================*/

static void FreeSymT(ptr)
SymTree ptr;
{
  if(ptr != 0) {
    FreeSymT(ptr->right);
    FreeSymT(ptr->left);
    ptr->right = ptr->left = 0;
    switch (ptr->type) {
      case TT_VAR:
        /* ptr->dcl.varDcl should be freed here. A var can have two names -
           original_name and new_name. They both share the same copy of a VarDcl
           So only the one with status 1 sould really call RemoveVarDcl() */
        if (ptr->status == 1) RemoveVarDcl(ptr->dcl.varDcl);
        ptr->dcl.varDcl = 0;
        break;
      case TT_STRUCT:
        RemoveStructDcl(ptr->dcl.structDcl);
        ptr->dcl.structDcl = 0;
        break;
      case TT_UNION:
        RemoveUnionDcl(ptr->dcl.unionDcl);
        ptr->dcl.unionDcl = 0;
        break;
      case TT_ENUM:
        RemoveEnumDcl(ptr->dcl.enumDcl);
        ptr->dcl.enumDcl = 0;
        break;
    }
    free(ptr->symbol_name);
    DISPOSE(ptr);
  }
}
/*=============================================================================/
 * BCC - added to reset the symbol trees for Pinline after processing each
 *       file.  Reset TT_VAR, TT_STRUCT, TT_UNION, TT_ENUM, TT_ENUMFIELD tables.
 *============================================================================*/

ResetSymbolTables()
{
  int i;

  for(i=0; i < MAX_TREE; i++) {
    FreeSymT(SymbolTree[i]);
    SymbolTree[i] = 0;
  }
  /* BCC - a new compilation unit starts - 7/13/96 */
  struct_count = extern_count = 0;
}

void FreeSymTNode(ptr)
SymTree ptr;
{
  if(ptr != 0) {
    ptr->right = ptr->left = 0;
    switch (ptr->type) {
      case TT_VAR:
        /* ptr->dcl.varDcl should be freed here. A var can have two names -
           original_name and new_name. They both share the same copy of a VarDcl
           So only the one with status 1 sould really call RemoveVarDcl() */
        if (ptr->status == 1) RemoveVarDcl(ptr->dcl.varDcl);
        ptr->dcl.varDcl = 0;
        break;
      case TT_STRUCT:
        RemoveStructDcl(ptr->dcl.structDcl);
        ptr->dcl.structDcl = 0;
        break;
      case TT_UNION:
        RemoveUnionDcl(ptr->dcl.unionDcl);
        ptr->dcl.unionDcl = 0;
        break;
      case TT_ENUM:
        RemoveEnumDcl(ptr->dcl.enumDcl);
        ptr->dcl.enumDcl = 0;
        break;
    }
    free(ptr->symbol_name);
    DISPOSE(ptr);
  }
}


/* add a symbol */
void AddSymTNode(node, tree_type)
     SymTree node;
     int tree_type;
{
  int diff;
  SymTree ptr, last;
  if (SymbolTree[tree_type]==0) {
    SymbolTree[tree_type] = node;
    return; 
  }
  last = 0;
  ptr = SymbolTree[tree_type];
  while (ptr!=0) {
    diff = strcmp(ptr->symbol_name, node->symbol_name);
    if ((diff==0) && (ptr->scope_id==node->scope_id) && (ptr->type==node->type))
      return;
    if (diff<0) {
      last = ptr;
      ptr = ptr->right;
      if (ptr==0) {
	last->right = node;
	return;
      }
    } else {
      last = ptr;
      ptr = ptr->left;
      if (ptr==0) {
	last->left = node;
	return;
      }
    }
  }
}

void RemoveLocalSymTNode(ptr, tree_type)
    SymTree ptr;
    int tree_type;
{
    if (ptr == 0) return;
    RemoveLocalSymTNode(ptr->left, tree_type);
    RemoveLocalSymTNode(ptr->right, tree_type);
    ptr->left = ptr->right = 0;
    if (ptr->scope_id != 0) FreeSymTNode(ptr);
    else AddSymTNode(ptr, tree_type);
}

void RemoveLocalSymT(tree_type)
    int tree_type;
{
    SymTree ptr;
    ptr = SymbolTree[tree_type];
    SymbolTree[tree_type] = 0;
    RemoveLocalSymTNode(ptr, tree_type);
}

/* BCC - garbage collection - 8/17/96 */
void Pinline_GarbageCollection()
{
    FreeSymT(SymbolTree[TT_VAR]);
    SymbolTree[TT_VAR] = 0;
    ClearFreeSymTbl(TBT_TYPEDEF, (void (*)())RemoveTypeDcl);
    ClearFreeSymTbl(TBT_FUNC, (void (*)())RemoveType);
    struct_count = extern_count = 0;
}

