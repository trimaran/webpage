/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.30  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 14, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	gen_charlie.c
 *	Authors: Grant Haab, Krishna Subramanian and Wen-mei Hwu
 *	Code Modified from code written by Nancy Warter, Grant Haab 
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <Pcode/struct.h>
#include <Pcode/parms.h>
#include <Pcode/pcode.h>
#include <Pcode/gen_charlie.h>
#include <Pcode/gen_pcode.h>
#include <Pcode/print_charlie.h>

static FILE *F = NULL; /* THIS MUST REMAIN STATIC.  DO NOT MAKE IT VISIBLE
			    TO OTHER SOURCE FILES.  - GEH */

/*
 * This array of structures is indexed by the op number in the file pcode.h
 * For each pcode operation, the precedence value and associativity is given.
 * A value of -1 for the precedence indicates an improper operation number.
 * Values of -1, 0, and 1 for the associativity refer to left-associative,
 * non-associative, and right-associative operators respectively.
 * Note that the operations must be in the same order as defined in pcode.h
 */

#define LEFT_ASSOC      -1
#define NON_ASSOC       0
#define RIGHT_ASSOC     1

struct {int val, assoc;} prec[OP_call+1] = {
    {-1, NON_ASSOC},    /* none */
    {16, NON_ASSOC},    /* OP_var */
    {16, NON_ASSOC},    /* OP_enum */
    {16, NON_ASSOC},    /* OP_int */
    {16, NON_ASSOC},    /* OP_real */
    {0, NON_ASSOC},     /* OP_error (?) */
    {16, NON_ASSOC},    /* OP_char */
    {16, NON_ASSOC},    /* OP_string */
    {16, NON_ASSOC},    /* OP_dot */
    {16, NON_ASSOC},    /* OP_arrow */
    {14, NON_ASSOC},    /* OP_cast */
    {14, NON_ASSOC},    /* OP_expr_size */
    {14, NON_ASSOC},    /* OP_type_size */
    {3, RIGHT_ASSOC},   /* OP_quest */
    {4, LEFT_ASSOC},    /* OP_disj */
    {5, LEFT_ASSOC},    /* OP_conf */
    {1, LEFT_ASSOC},    /* OP_compexpr */
    {2, RIGHT_ASSOC},   /* OP_assign */
    {6, LEFT_ASSOC},    /* OP_or */
    {7, LEFT_ASSOC},    /* OP_xor */
    {8, LEFT_ASSOC},    /* OP_and */
    {9, LEFT_ASSOC},    /* OP_eq */
    {9, LEFT_ASSOC},    /* OP_ne */
    {10, LEFT_ASSOC},   /* OP_lt */
    {10, LEFT_ASSOC},   /* OP_le */
    {10, LEFT_ASSOC},   /* OP_ge */
    {10, LEFT_ASSOC},   /* OP_gt */
    {11, LEFT_ASSOC},   /* OP_rshft */
    {11, LEFT_ASSOC},   /* OP_lshft */
    {12, LEFT_ASSOC},   /* OP_add */
    {12, LEFT_ASSOC},   /* OP_sub */
    {13, LEFT_ASSOC},   /* OP_mul */
    {13, LEFT_ASSOC},   /* OP_div */
    {13, LEFT_ASSOC},   /* OP_mod */
    {14, NON_ASSOC},    /* OP_neg */
    {14, NON_ASSOC},    /* OP_not */
    {14, NON_ASSOC},    /* OP_inv */
    {-1, NON_ASSOC},    /* none */
    {14, NON_ASSOC},    /* OP_preinc */
    {14, NON_ASSOC},    /* OP_predec */
    {15, NON_ASSOC},    /* OP_postinc */
    {15, NON_ASSOC},    /* OP_postdec */
    {2, RIGHT_ASSOC},   /* OP_Aadd */
    {2, RIGHT_ASSOC},   /* OP_Asub */
    {2, RIGHT_ASSOC},   /* OP_Amul */
    {2, RIGHT_ASSOC},   /* OP_Adiv */
    {2, RIGHT_ASSOC},   /* OP_Amod */
    {2, RIGHT_ASSOC},   /* OP_Arshft */
    {2, RIGHT_ASSOC},   /* OP_Alshft */
    {2, RIGHT_ASSOC},   /* OP_Aand */
    {2, RIGHT_ASSOC},   /* OP_Aor */
    {2, RIGHT_ASSOC},   /* OP_Axor */
    {14, NON_ASSOC},    /* OP_indr */
    {14, NON_ASSOC},    /* OP_addr */
    {16, NON_ASSOC},    /* OP_index */
    {16, NON_ASSOC}     /* OP_call */
};


static int do_output = 1;
#define OUTPUT		do_output
#define DO_OUTPUT(x)	(do_output = x)
#define BLOCK_OUTPUT	(do_output == 0)

static int last_stmt_return;
static int last_stmt_break;
static int in_case;
static int in_default;
static int scope_count = 1;
static int in_switch;
static int default_yes;
static int pretty_print = 0;

/* forward declarations */
static void GenStmts();
static GenDoStmtHead();


/* EXPORT FUNCTION :
 *	Gen_CHARLIE_LinePos(F, n, file) int n; char *file;
 *	Gen_CHARLIE_Struct(F, st) Struct st;
 *	Gen_CHARLIE_Union(F, un) Union un;
 *	Gen_CHARLIE_Enum(F, en) Enum en;
 *	Gen_CHARLIE_Var(F, var) VarDcl var;
 *	Gen_CHARLIE_Func(F, fn) FuncDcl fn;
 */
/*========================================================================*/

/*========================================================================*/



/* Debugging Functions */

static GEN_CHARLIE_SUBPROC_ENTER(mesg,pos)
char *mesg, *pos;
{
    if (DEBUG_GEN_CHARLIE) {
      if (pos != 0)
        fprintf(Flog, "..Entering: Gen%s for %s \n",mesg,pos);
      else
	fprintf(Flog,"..Entering: Gen%s \n",mesg);
    }
}

static GEN_CHARLIE_SUBPROC_EXIT(mesg,pos)
char *mesg,*pos;
{
    if (DEBUG_GEN_CHARLIE) {
	if (pos != 0)
          fprintf(Flog, "..Exiting: Gen%s for %s \n",mesg,pos);
	else
	  fprintf(Flog,"..Exiting: Gen%s \n",mesg);
    }
}

/* Verbose Output */

static GEN_CHARLIE_PROC_ENTER(mesg,pos)
char *mesg, *pos;
{ 
    if (!DEMO_OUTPUT) {
	if (debug_yes || verbose_yes) {
	    if (pos != 0) 
	     fprintf(Flog, "..Entering: Gen%s for %s \n",mesg,pos);
	    else
	     fprintf(Flog,"..Entering: Gen%s \n",mesg);    
	}
    }
}

static GEN_CHARLIE_PROC_EXIT(mesg,pos)
char *mesg,*pos;
{
    if (!DEMO_OUTPUT) {
	if (debug_yes || verbose_yes) {
	  if (pos != 0) 
	    fprintf(Flog, "..Exiting: Gen%s for %s \n",mesg,pos);
	  else
	    fprintf(Flog,"..Exiting: Gen%s \n", mesg);
	}
    }
}


static Punt(mesg)
char *mesg;
{
	fprintf(Flog, "#gen_charlie: %s\n", mesg);
	exit(-1);
}

void WriteString(deststr, pos, srcstr)
char *deststr;
int *pos;
char *srcstr;
{
    if (*pos + strlen(srcstr) > MAX_STRING) {
	strncpy(&deststr[*pos], srcstr, MAX_STRING - *pos);
	*pos = MAX_STRING;
    }
    else {
	strcpy(&deststr[*pos], srcstr); 
	*pos += strlen(srcstr);
    }
}

void WriteInt(deststr, pos, srcint)
char *deststr;
int *pos;
long int srcint;
{
    char srcstr[MAX_STRING+1];
    sprintf(srcstr, "%ld", srcint);
    WriteString(deststr, pos, srcstr);
}

void WriteReal(deststr, pos, srcreal)
char *deststr;
int *pos;
double srcreal;
{
    char srcstr[MAX_STRING+1];
    /* GEH - changed FP format to match rest of compiler - 4/27/95 */
    sprintf(srcstr, "%1.16e", srcreal);
    WriteString(deststr, pos, srcstr);
}


/* 
 * If old_var is TRUE, strip beginning "P_" and ending "___<scopeID>"
 * from variable names 
 */
void Expr2String(char *string, int *pos, Expr expr, bool old_var)
{
    while (expr != NIL) {
        SingleExpr2String(string, pos, expr, old_var);
        expr = expr->next;
        if (expr != NIL) WriteString(string, pos, ",");
    }
}

/*
 * GEH - added this function so that only first expression in top-level
 * compound expression is converted.  (4/17/93)
 */
/* 
 * If old_var is TRUE, strip beginning "P_" and ending "___<scopeID>" 
 * from variable names 
 */

void SingleExpr2String(char *string, int *pos, Expr expr, bool old_var)
{
    char *var_name, *scope_str, *str, ch;
    VarDcl vardcl;
    int epv, pepv, epa, eplo;
    bool is_newvar, need_parens;

    need_parens = FALSE;
    if (expr->parentexpr != NIL) {
	epv = prec[expr->opcode].val; 	/* expr precedence value */
	pepv = prec[expr->parentexpr->opcode].val; /* parent expr prec val*/
	epa = prec[expr->opcode].assoc;	/* expr precedence assoc */
	eplo = (expr->parentexpr->operands == expr); 
				    /* expr is parent's left operand */

	if ((pepv > epv &&
	     epv != 1 &&		/* not compound expression */
	     ((expr->parentexpr->opcode != OP_index &&
	       expr->parentexpr->opcode != OP_call) ||
	      expr->parentexpr->operands == expr)) || 

	    (pepv == epv && 
	     ((eplo && (epa == RIGHT_ASSOC)) || 
	      (!eplo && (epa == LEFT_ASSOC))))) {

	    need_parens = TRUE;
	    WriteString(string, pos, "(");
	}
    }
	
    switch (expr->opcode) {

	case OP_var:
	    if (expr->enum_flag) 
		WriteString(string, pos, expr->value.string);

	    else {	/* expression is a var, not an enum */
		var_name = expr->value.var_name;
		assert(var_name != NIL);
		if (old_var) {

		    /* Strip of "P_" prefix and "___<scopeID>" if present */

		    if (var_name[0] == 'P' && var_name[1] == '_' &&
			(scope_str = strstr(&var_name[2], "___"))) {
			is_newvar = TRUE;

L1:			    for (str = scope_str+3; *str != '\0'; str++) {
			    if (!isdigit(*str)) {
				is_newvar = FALSE;
				break;
			    }
			}

			if (is_newvar == FALSE) {
			    if ((scope_str = strstr(scope_str+1, "___")) !=
				NIL) {
				is_newvar = TRUE;
				goto L1;
			    }
			    else WriteString(string, pos, var_name);
			}

			else { /* write truncated variable name */
			    ch = *scope_str;
			    *scope_str = '\0';
			    WriteString(string, pos, &var_name[2]);
			    *scope_str = ch;
			}
		    }
		    else WriteString(string, pos, var_name);

		    /* Don't assume VarDcl has oldname anymore (GEH) 
		    if ((vardcl = var_name_to_var_dcl(var_name)) != NIL)
			WriteString(string, pos, vardcl->name);
		    else WriteString(string, pos, var_name);
		    */
		}
		else WriteString(string, pos, var_name);
	    }
	    break;
	case OP_int:
	    WriteInt(string, pos, expr->value.scalar);
	    break;
	case OP_real:
	/* BCC - 2/7/97 */
	case OP_double:
	case OP_float:
	    WriteReal(string, pos, expr->value.real);
	    break;
	case OP_char:
	case OP_string:
	    WriteString(string, pos, expr->value.string);
	    break;
	case OP_dot:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, ".");
	    WriteString(string, pos, expr->value.string);
	    break;
	case OP_arrow:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "->");
	    WriteString(string, pos, expr->value.string);
	    break;
	case OP_quest:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "?");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    WriteString(string, pos, ":");
	    Expr2String(string, pos, expr->operands->sibling->sibling, 
			old_var); 
	    break; 
	case OP_disj: 
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "||");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_conj:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "&&");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_compexpr:
	    WriteString(string, pos, "(");
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, ")");
	    break;
	case OP_cast:
	    /* GEH - DeclSpec not implemented yet */
	    /*SK- Shortening the output name!*/
	    WriteString(string, pos, "(#)");
	    Expr2String(string, pos, expr->operands, old_var);
	    break;
	case OP_type_size:
	    /* GEH - DeclSpec not implemented yet */
	    WriteString(string, pos, "sizeof(#)");
	    break;
	case OP_expr_size:
	    WriteString(string, pos, "sizeof(");
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, ")");
	    break;
	case OP_or:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "|");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_and:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "&");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_xor:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "^");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_eq:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "==");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_ne:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "!=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_lt:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "<");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_gt:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, ">");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_le:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "<=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_ge:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, ">=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_rshft:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, ">>");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_lshft:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "<<");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_add:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "+");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_sub:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "-");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_mul:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "*");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_div:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "/");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_mod:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "%");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Aadd:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "+=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Asub:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "-=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Amul:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "*=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Adiv:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "/=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Amod:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "%=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Arshft:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, ">>=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Alshft:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "<<=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Aand:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "&=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Aor:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "|=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_Axor:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "%=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_assign:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "=");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    break;
	case OP_neg:
	    WriteString(string, pos, "-");
	    Expr2String(string, pos, expr->operands, old_var);
	    break;
	case OP_not:
	    WriteString(string, pos, "!");
	    Expr2String(string, pos, expr->operands, old_var);
	    break;
	case OP_inv:
	    WriteString(string, pos, "~");
	    Expr2String(string, pos, expr->operands, old_var);
	    break;
	case OP_preinc:
	    WriteString(string, pos, "++");
	    Expr2String(string, pos, expr->operands, old_var);
	    break;
	case OP_predec:
	    WriteString(string, pos, "--");
	    Expr2String(string, pos, expr->operands, old_var);
	    break;
	case OP_postinc:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "++");
	    break;
	case OP_postdec:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "--");
	    break;
	case OP_indr:
	    WriteString(string, pos, "*");
	    Expr2String(string, pos, expr->operands, old_var);
	    break;
	case OP_addr:
	    WriteString(string, pos, "&");
	    Expr2String(string, pos, expr->operands, old_var);
	    break;
	case OP_index:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "[");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    WriteString(string, pos, "]");
	    break;
	case OP_call:
	    Expr2String(string, pos, expr->operands, old_var);
	    WriteString(string, pos, "(");
	    Expr2String(string, pos, expr->operands->sibling, old_var);
	    WriteString(string, pos, ")");
	    break;
	case OP_error:
	    WriteString(string, pos, "<Error>");
	    break;
	default:
	    Punt("Expr2String: Error, invalid expression opcode", NIL); 
	    break;
    }
    if (need_parens) WriteString(string, pos, ")");
}

#ifdef IMPLEMENT_LATER

/*========================================================================*/

/* print type information. */

/******************************************************************************
    GenType():
        Write out a Pcode $TcSpec nonterm.

        Pcode grammar: $TcSpec =
                           CONST                |
                           VOLATILE             |
                           AUTO                 |
                           STATIC               |
                           EXTERN               |
                           REGISTER             |
                           (TYPEDEF $TypeID?)   |
                           (TYPEID $TypeID)     |
                           CHAR                 |
                           FLOAT                |
                           DOUBLE               |
                           INT                  |
                           SHORT                |
                           LONG                 |
                           SIGNED               |
                           UNSIGNED             |
                           VOID                 |
                           SYNC                 |
                           $EnumSpec            |
                           $StructSpec

        Parameters: TypeSpec: A pointer to a type specifier
                    TypeID: A type identifier (for typedefs only)

        Returns: Nothing

        Calls:  pcode_VarID()
                pcode_EnumSpec()
                extern charlie_token()
 ******************************************************************************/
static GenType(type)
Type type;
{
	int t;
	GEN_CHARLIE_SUBPROC_ENTER("TypeSpec",0);
	t = type->type;
	if (t==0) {
            Punt("ILLEGAL TYPE SPECIFICATION: NULL");
	    return;
	}
	/* storage class */
	if (t & TY_REGISTER) charlie_token(F, IDENT_TOKEN, REGISTER_CHARLIE, 0); 
	if (t & TY_STATIC) charlie_token(F, IDENT_TOKEN, STATIC_CHARLIE, 0); 
	if (t & TY_EXTERN) charlie_token(F, IDENT_TOKEN, EXTERN_CHARLIE, 0); 
	if (t & TY_AUTO)  charlie_token(F, IDENT_TOKEN, AUTO_CHARLIE, 0);
	/* qualifier */
	if (t & TY_CONST)  charlie_token(F, IDENT_TOKEN, CONST_CHARLIE, 0); 
	if (t & TY_VOLATILE)  charlie_token(F, IDENT_TOKEN, VOLATILE_CHARLIE, 0); 
	/* at present, won't gen noalias from pcode */
	/*
	if (t & TY_NOALIAS) charlie_token(F, IDENT_TOKEN, " NO ALIAS ", 0); 
	*/
	if (t & TY_SYNC) charlie_token(F, IDENT_TOKEN, SYNC_CHARLIE, 0); 

	/* type */ 
	if (t & TY_SIGNED)  charlie_token(F, IDENT_TOKEN, SIGNED_CHARLIE, 0); 
	if (t & TY_UNSIGNED)  charlie_token(F, IDENT_TOKEN, UNSIGNED_CHARLIE, 0); 
	if (t & TY_VOID)   charlie_token(F, IDENT_TOKEN, VOID_CHARLIE, 0);
	if (t & TY_SHORT) charlie_token(F, IDENT_TOKEN, SHORT_CHARLIE, 0); 
	if (t & TY_LONG) charlie_token(F, IDENT_TOKEN, LONG_CHARLIE, 0); 
	if (t & TY_CHAR) charlie_token(F, IDENT_TOKEN, CHAR_CHARLIE, 0); 
	if (t & TY_INT) charlie_token(F, IDENT_TOKEN, INT_CHARLIE, 0); 
	if (t & TY_FLOAT)  charlie_token(F, IDENT_TOKEN, FLOAT_CHARLIE, 0); 
	if (t & TY_DOUBLE) charlie_token(F, IDENT_TOKEN, DOUBLE_CHARLIE, 0); 
	if (t & TY_STRUCT) {
          charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
	  charlie_token(F, IDENT_TOKEN, TY_STRUCT_CHARLIE, 0);
          charlie_token(F, IDENT_TOKEN, type->struct_name, 0);
	  charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0); 
        } 
	if (t & TY_UNION) {
          charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
	  charlie_token(F, IDENT_TOKEN, TY_UNION_CHARLIE, 0); 
          charlie_token(F, IDENT_TOKEN, type->struct_name, 0); 
	  charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0); 
        } 
	if (t & TY_ENUM) { 
          charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
	  charlie_token(F, IDENT_TOKEN, TY_ENUM_CHARLIE, 0);
          charlie_token(F, IDENT_TOKEN, type->struct_name, 0); 
	  charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0); 
        } 
       GEN_CHARLIE_SUBPROC_EXIT("TypeSpec",0);
}
/* NOTE:  Don't know if we need this yet SK 
 *  type:
 *  0:  no restrictions
 *  1:  don't print function declarator "F"
 */
static GenDcltr(dcltr, type)
Dcltr dcltr;
int type;
{
        GEN_CHARLIE_SUBPROC_ENTER("Dcltr",0);

	while (dcltr!=0) {
	    switch (dcltr->method) {
	    case D_ARRY:
 	        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
                charlie_token(F, IDENT_TOKEN, ARRAY_CHARLIE, 0);
                if (dcltr->index != 0) {
                    GenExprList(dcltr->index);
                }
                charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
		break;
	    case D_PTR:
                charlie_token(F, IDENT_TOKEN, POINTER_CHARLIE, 0);
		break;
	    case D_FUNC:
		if(type != 1) {
                charlie_token(F, IDENT_TOKEN, FUNCTION_CHARLIE, 0);
		}
		break;
	    default:
		Punt("illegal dcltr");
	    }
	    dcltr = dcltr->next;
	}
    GEN_CHARLIE_SUBPROC_EXIT("Dcltr",0);

}
/*========================================================================*/

#endif

/******************************************************************************
     GenVarId():
        Write out a Pcode $VarID nonterm.

        Pcode grammar: $VarID = a standard C identifier

        Parameters: VarID: An identifier

        Returns: Nothing

        Calls:  extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenVarId(temp)
char *temp;
{
    GEN_CHARLIE_SUBPROC_ENTER("VarID", temp);

    charlie_token(F, IDENT_TOKEN, var_name_to_var_dcl(temp)->name, 0);
    GEN_CHARLIE_SUBPROC_EXIT("VarID",temp);
}


static GenIntVal(intval)
long int intval;
{
    char ident[MAX_STRING];

    sprintf(ident, "%d", intval);
    GEN_CHARLIE_SUBPROC_ENTER("IntVal", ident);
    charlie_token(F, IDENT_TOKEN, ident, 0);

    GEN_CHARLIE_SUBPROC_EXIT("IntVal", ident);

}

/******************************************************************************
    GenExprList():
        Write out a Pcode $ExprList nonterm.

        Pcode grammar: $ExprList =
                           $Expr+

        Parameters: ExprList: A pointer to a list of expressions

        Returns: Nothing

        Calls:  GenExpr()
  		Punt
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       

static GenExprList(exprlist)
Expr exprlist;
{
    char string[MAX_STRING];
    int pos = 0;

    GEN_CHARLIE_SUBPROC_ENTER("ExprList",0);

    if (exprlist == NULL) {
        Punt("GenExprList: Expr missing");
    }

    Expr2String(string, &pos, exprlist, TRUE); 
    charlie_token(F, IDENT_TOKEN, string, 0);

    GEN_CHARLIE_SUBPROC_EXIT("ExprList",0);
}

/******************************************************************************
    GenCompoundStmt():
        Write out a Pcode $CompoundStmt nonterm.

        Pcode grammar: $CompoundStmt =
                           (COMPSTMT ($LocalDecl*) ($Stmt*))

        Parameters: CompoundStmt: A pointer to a compound statement

        Returns: Nothing

        Calls:  GenLocalDecls()
                GenStmts()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenCompoundStmt(CompoundStmt,Localdecl)
Stmt CompoundStmt;
VarList Localdecl;
{
    GEN_CHARLIE_SUBPROC_ENTER("CompoundStmt",0);

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);

    /*
    GenLocalDecls(Localdecl);
    */

    GenStmts(CompoundStmt);

    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("CompoundStmt",0);
}

/******************************************************************************
    GenExprStmt():
        Write out a Pcode $ExprStmt nonterm.

        Pcode grammar: $ExprStmt =
                           (EXPR ($ExprList))

        Parameters: ExprStmt: A pointer to an expression statement

        Returns: Nothing

        Calls:  extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenExprStmt(ExprStmt)
Expr ExprStmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("ExprStmt",0);

    GenExprList(ExprStmt);
    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("ExprStmt",0);
}

/******************************************************************************
    GenDoStmt():
        Write out a Pcode $DoStmt nonterm.

        Pcode grammar: $DoStmt =
                           (DO $Stmt WHILE ($ExprList))

        Parameters: DoStmt: A pointer to a do statement

        Returns: Nothing

        Calls:  GenExprList()
                GenStmt()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenDoStmt(DoStmt)
SerLoop DoStmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("DoStmt",0);

    charlie_token(F, IDENT_TOKEN, DO_STMT_CHARLIE, 0);

    GenStmts(DoStmt->loop_body);

    charlie_token(F, IDENT_TOKEN, WHILE_STMT_CHARLIE, 0);

    charlie_token(F, IDENT_TOKEN, LEFT_PAREN_CHARLIE, 0);

    GenExprList(DoStmt->cond_expr);

    charlie_token(F, IDENT_TOKEN, RIGHT_PAREN_CHARLIE, 0);
    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("DoStmt",0);
}

/******************************************************************************
    GenForStmt():
        Write out a Pcode $ForStmt nonterm.

        Pcode grammar: $ForStmt =
                           (FOR ($ExprList?) ($ExprList?) ($ExprList?) DO $Stmt)

        Parameters: ForStmt: A pointer to a for statement

        Returns: Nothing

        Calls:  GenExprList()
                GenStmt()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenForStmt(ForStmt)
SerLoop ForStmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("ForStmt",0);

    charlie_token(F, IDENT_TOKEN, FOR_STMT_CHARLIE, 0);

    charlie_token(F, IDENT_TOKEN, LEFT_PAREN_CHARLIE, 0);
    if (ForStmt->init_expr != NULL) GenExprList(ForStmt->init_expr);
    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    if (ForStmt->cond_expr != NULL) GenExprList(ForStmt->cond_expr);

    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);
    if (ForStmt->iter_expr != NULL) GenExprList(ForStmt->iter_expr);
    charlie_token(F, IDENT_TOKEN, RIGHT_PAREN_CHARLIE, 0);

    GenStmts(ForStmt->loop_body);

    GEN_CHARLIE_SUBPROC_EXIT("ForStmt",0);
}

/******************************************************************************
    GenWhileStmt():
        Write out a Pcode $WhileStmt nonterm.

        Pcode grammar: $WhileStmt =
                           (WHILE ($ExprList) DO $Stmt)

        Parameters: WhileStmt: A pointer to a while statement

        Returns: Nothing

        Calls:  GenExprList()
                GenStmts()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenWhileStmt(WhileStmt)
SerLoop WhileStmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("WhileStmt",0);

    charlie_token(F, IDENT_TOKEN, WHILE_STMT_CHARLIE, 0);

    charlie_token(F, IDENT_TOKEN, LEFT_PAREN_CHARLIE, 0);
    GenExprList(WhileStmt->cond_expr);
    charlie_token(F, IDENT_TOKEN, RIGHT_PAREN_CHARLIE, 0);

    GenStmts(WhileStmt->loop_body);

    GEN_CHARLIE_SUBPROC_EXIT("WhileStmt",0);
}


/******************************************************************************
    GenIfStmt():
        Write out a Pcode $IfStmt nonterm.

        Pcode grammar: $IfStmt =
                           (IF ($ExprList) THEN $Stmt ELSE $Stmt)  |
                           (IF ($ExprList) THEN $Stmt)

        Parameters: IfStmt: A pointer to an if statement

        Returns: Nothing

        Calls:  GenExprList()
                GenStmts()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenIfStmt(stmt)
IfStmt stmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("IfStmt",0);

    charlie_token(F, IDENT_TOKEN, IF_STMT_CHARLIE, 0);

    charlie_token(F, IDENT_TOKEN, LEFT_PAREN_CHARLIE, 0);
    GenExprList(stmt->cond_expr);
    charlie_token(F, IDENT_TOKEN, RIGHT_PAREN_CHARLIE, 0);

    charlie_token(F, IDENT_TOKEN, THEN_STMT_CHARLIE, 0);
    GenStmts(stmt->then_block);

    if (stmt->else_block != NULL) {
        charlie_token(F, IDENT_TOKEN, ELSE_STMT_CHARLIE, 0);
        GenStmts(stmt->else_block);
    }

    GEN_CHARLIE_SUBPROC_EXIT("IfStmt",0);
}

/******************************************************************************
    GenSwitchStmt():
        Write out a Pcode $SwitchStmt nonterm.

        Pcode grammar: $SwitchStmt =
                           (SWITCH ($ExprList) $Stmt)

        Parameters: SwitchStmt: A pointer to a switch statement

        Returns: Nothing

        Calls:  GenExprList()
                GenStmts()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenSwitchStmt(stmt)
SwitchStmt stmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("SwitchStmt",0);

    charlie_token(F, IDENT_TOKEN, SWITCH_STMT_CHARLIE, 0);

    charlie_token(F, IDENT_TOKEN, LEFT_PAREN_CHARLIE, 0);
    GenExprList(stmt->expression);
    charlie_token(F, IDENT_TOKEN, RIGHT_PAREN_CHARLIE, 0);

    GenStmts(stmt->switchbody);

    GEN_CHARLIE_SUBPROC_EXIT("SwitchStmt",0);
}


/******************************************************************************
    GenBreakStmt():
        Write out a Pcode $BreakStmt nonterm.

        Pcode grammar: $BreakStmt =
                           (BREAK)

        Parameters: BreakStmt: A pointer to static

        Returns: Nothing

        Calls:  extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenBreakStmt()
{
    GEN_CHARLIE_SUBPROC_ENTER("BreakStmt",0);

    charlie_token(F, IDENT_TOKEN, BREAK_STMT_CHARLIE, 0);
    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("BreakStmt",0);
}
/******************************************************************************
    GenContinueStmt():
        Write out a Pcode $ContinueStmt nonterm.

        Pcode grammar: $ContinueStmt =
                           (CONTINUE)

        Parameters: ContinueStmt: A pointer to static

        Returns: Nothing

        Calls:  extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenContinueStmt()
{
    GEN_CHARLIE_SUBPROC_ENTER("ContinueStmt",0);

    charlie_token(F, IDENT_TOKEN, CONTINUE_STMT_CHARLIE, 0);
    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("ContinueStmt",0);
}

/******************************************************************************
    GenReturnStmt():
        Write out a Pcode $ReturnStmt nonterm.

        Pcode grammar: $ReturnStmt =
                           (RETURN ($ExprList))  |
                           (RETURN)

        Parameters: ReturnStmt: A pointer to a return statement

        Returns: Nothing

        Calls:  GenExprList()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenReturnStmt(ReturnStmt)
Expr ReturnStmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("ReturnStmt",0);

    charlie_token(F, IDENT_TOKEN, RETURN_STMT_CHARLIE, 0);

    if (ReturnStmt != NULL) {
        GenExprList(ReturnStmt);
    }
    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("ReturnStmt",0);
}



/******************************************************************************
    GenGotoStmt():
        Write out a Pcode $GotoStmt nonterm.

        Pcode grammar: $GotoStmt =
                           (GOTO $LabelID)

        Parameters: GotoStmt: A pointer to a goto statement

        Returns: Nothing

        Calls:  GenVarId()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenGotoStmt(label)
char *label;
{
    GEN_CHARLIE_SUBPROC_ENTER("GotoStmt",0);

    charlie_token(F, IDENT_TOKEN, GOTO_STMT_CHARLIE, 0);

    charlie_token(F, IDENT_TOKEN, label, 0);
    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("GotoStmt",0);
}


/******************************************************************************
    GenNullStmt():
        Write out a Pcode $NullStmt nonterm.

        Pcode grammar: $NullStmt =
                           (NULL)

        Parameters: NullStmt: A pointer to static

        Returns: Nothing

        Calls:  extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenNullStmt()
{
    GEN_CHARLIE_SUBPROC_ENTER("NullStmt",0);

    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("NullStmt",0);
}


/******************************************************************************
    GenPStmt():
        Write out a Pcode $PStmt nonterm.

        Pcode grammar: $PStmt =
                           (PSTMT $Stmt)

        Parameters: PStmt: A pointer to a P-statment

        Returns: Nothing

        Calls:  GenStmts()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenPStmt(stmt)
Pstmt stmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("PStmt",0);
    GenStmts(stmt->stmt);

    GEN_CHARLIE_SUBPROC_EXIT("PStmt",0);
}

/******************************************************************************
    GenAdvanceStmt():
        Write out a Pcode $AdvanceStmt nonterm.

        Pcode grammar: $AdvanceStmt =
                           (ADVANCE $IntVal)

        Parameters: AdvanceStmt: A pointer to an advance statement

        Returns: Nothing

        Calls:  GenIntVal()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenAdvanceStmt(stmt)
Advance stmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("AdvanceStmt",0);

    charlie_token(F, IDENT_TOKEN, ADVANCE_STMT_CHARLIE, 0);

    GenIntVal(stmt->marker);
    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("AdvanceStmt",0);
}
/******************************************************************************
    GenAwaitStmt():
        Write out a Pcode $AwaitStmt nonterm.

        Pcode grammar: $AwaitStmt =
                           (AWAIT $IntVal $IntVal)

        Parameters: AwaitStmt: A pointer to an await statement

        Returns: Nothing

        Calls:  GenIntVal()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenAwaitStmt(stmt)
Await stmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("AwaitStmt",0);

    charlie_token(F, IDENT_TOKEN, AWAIT_STMT_CHARLIE, 0);

    GenIntVal(stmt->marker);

    charlie_token(F, IDENT_TOKEN, COMMA_CHARLIE, 0);
    GenIntVal(stmt->distance);

    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("AwaitStmt",0);
}

/******************************************************************************
    GenDoallStmt():
        Write out a Pcode $DoallStmt nonterm.

        Pcode grammar: $DoallStmt =
                           (DOALL $DoStmtHead $DoPStmt)

        Parameters: DoallStmt: A pointer to an doall statement

        Returns: Nothing

        Calls:  GenDoStmtHead()
                GenDoPStmt()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenDoallStmt(DoallStmt)
ParLoop DoallStmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("DoallStmt",0);

    charlie_token(F, IDENT_TOKEN, DOALL_STMT_CHARLIE, 0);

    GenDoStmtHead(DoallStmt);

    GenStmts(Parloop_Body_Stmt(DoallStmt));

    GEN_CHARLIE_SUBPROC_EXIT("DoallStmt",0);
}

/******************************************************************************
    GenDoacrossStmt():
        Write out a Pcode $DoacrossStmt nonterm.

        Pcode grammar: $DoacrossStmt =
                           (DOACROSS $DoStmtHead $DoPStmt)

        Parameters: DoacrossStmt: A pointer to an doacross statement

        Returns: Nothing

        Calls:  GenDoStmtHead()
                GenDoPStmt()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenDoacrossStmt(DoacrossStmt)
 ParLoop DoacrossStmt ;
{
    GEN_CHARLIE_SUBPROC_ENTER("DoacrossStmt",0);

    charlie_token(F, IDENT_TOKEN, DOACROSS_STMT_CHARLIE, 0);

    GenDoStmtHead(DoacrossStmt);

    GenStmts(Parloop_Body_Stmt(DoacrossStmt));

    GEN_CHARLIE_SUBPROC_EXIT("DoacrossStmt",0);
}

/******************************************************************************
    GenDosuperStmt():
        Write out a Pcode $DosuperStmt nonterm.

        Pcode grammar: $DosuperStmt =
                           (DOSUPER $DoStmtHead $DoPStmt)

        Parameters: DosuperStmt: A pointer to an dosuper statement

        Returns: Nothing

        Calls:  GenDoStmtHead()
                GenDoPStmt()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenDosuperStmt(DosuperStmt)
 ParLoop DosuperStmt ;
{
    GEN_CHARLIE_SUBPROC_ENTER("DosuperStmt",0);

    charlie_token(F, IDENT_TOKEN, DOSUPER_STMT_CHARLIE, 0);

    GenDoStmtHead(DosuperStmt);

    GenStmts(Parloop_Body_Stmt(DosuperStmt));

    GEN_CHARLIE_SUBPROC_EXIT("DosuperStmt",0);
}

/******************************************************************************
    GenDoserialStmt():
        Write out a Pcode $DoserialStmt nonterm.

        Pcode grammar: $DoserialStmt =
                           (DOSERIAL $DoStmtHead $DoPStmt)

        Parameters: DoserialStmt: A pointer to an doserial statement

        Returns: Nothing

        Calls:  GenDoStmtHead()
                GenDoPStmt()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenDoserialStmt(DoserialStmt)
ParLoop DoserialStmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("DoserialStmt",0);

    charlie_token(F, IDENT_TOKEN, DOSERIAL_STMT_CHARLIE, 0);

    GenDoStmtHead(DoserialStmt);

    GenStmts(Parloop_Body_Stmt(DoserialStmt));

    GEN_CHARLIE_SUBPROC_EXIT("DoserialStmt",0);
}


/******************************************************************************
    GenDoStmtHead():
        Write out a Pcode $DoStmtHead nonterm.

        Pcode grammar: $DoStmtHead =
                         ((INDEX $VarID) (INIT $Expr) (FINAL $Expr) (INC $Expr))

        Parameters: DoStmtHead: A pointer to do statement index information

        Returns: Nothing

        Calls:  GenVarId()
                GenExpr()
                charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       

static GenDoStmtHead(DoStmtHead)
ParLoop DoStmtHead;
{
    GEN_CHARLIE_SUBPROC_ENTER("DoStmtHead",0);

    GenVarId(DoStmtHead->iteration_var->value.var_name);

    charlie_token(F, IDENT_TOKEN, LEFT_PAREN_CHARLIE, 0);

    GenExprList(DoStmtHead->init_value);

    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GenExprList(DoStmtHead->final_value);

    charlie_token(F, IDENT_TOKEN, SEMICOLON_CHARLIE, 0);

    GenExprList(DoStmtHead->incr_value);
    charlie_token(F, IDENT_TOKEN, RIGHT_PAREN_CHARLIE, 0);

    GEN_CHARLIE_SUBPROC_EXIT("DoStmtHead",0);
}


/******************************************************************************
    GenCobeginStmt():
        Write out a Pcode $CobeginStmt nonterm.

        Pcode grammar: $CobeginStmt =
                           (COBEGIN $Stmt+)

        Parameters: CobeginStmt: A pointer to a cobegin statement

        Returns: Nothing

        Calls:  GenStmtss()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenCobeginStmt(stmt)
Cobegin stmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("CobeginStmt",0);

    charlie_token(F, IDENT_TOKEN, COBEGIN_STMT_CHARLIE, 0);

    GenStmts(stmt);

    GEN_CHARLIE_SUBPROC_EXIT("CobeginStmt",0);
}


/******************************************************************************
    GenMutexStmt():
        Write out a Pcode $MutexStmt nonterm.

        Pcode grammar: $MutexStmt =
                           (MUTEX $Expr $Stmt)

        Parameters: MutexStmt: A pointer to a mutual exclusion statement

        Returns: Nothing

        Calls:  GenExpr()
                GenStmts()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenMutexStmt(MutexStmt)
Mutex MutexStmt;
{
    GEN_CHARLIE_SUBPROC_ENTER("MutexStmt",0);

    charlie_token(F, IDENT_TOKEN, MUTEX_STMT_CHARLIE, 0);

    charlie_token(F, IDENT_TOKEN, LEFT_PAREN_CHARLIE, 0);
    GenExprList(MutexStmt->expression);
    charlie_token(F, IDENT_TOKEN, RIGHT_PAREN_CHARLIE, 0);

    GenStmts(MutexStmt->statement);

    GEN_CHARLIE_SUBPROC_EXIT("MutexStmt",0);
}
 


/******************************************************************************
    GenStmt2():
        Write out a Pcode $Stmt2 nonterm.

        Pcode grammar: $Stmt2 =
                           $ExprStmt      |
                           $CompoundStmt  |
                           $DoStmt        |
                           $WhileStmt     |
                           $ForStmt       |
                           $IfStmt        |
                           $SwitchStmt    |
                           $BreakStmt     |
                           $ContinueStmt  |
                           $ReturnStmt    |
                           $GotoStmt      |
                           $NullStmt      |
                           $PStmt         |
                           $AdvanceStmt   |
                           $AwaitStmt     |
                           $DoserialStmt  |
                           $DoallStmt     |
                           $DoacrossStmt  |
                           $MutexStmt     |
                           $CobeginStmt

        Parameters: Stmt2: A pointer to a statement
                    Pos: A pointer to the statement position information

        Returns: Nothing

        Calls:
                GenExprStmt()
                GenCompoundStmt()
                GenDoStmt()
                GenWhileStmt()
                GenForStmt()
                GenIfStmt()
                GenSwitchStmt()
                GenBreakStmt()
                GenContinueStmt()
                GenReturnStmt()
                GenGotoStmt()
                GenNullStmt()
                GenPStmt()
                GenAdvanceStmt()
                GenAwaitStmt()
                GenDoserialStmt()
                GenDoallStmt()
                GenDoacrossStmt()
                GenMutexStmt()
                GenCobeginStmt()
                Punt()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

       
static GenStmt2(stmt)
Stmt stmt;
{
    int st_type;
 
    GEN_CHARLIE_SUBPROC_ENTER("Stmt2",0);

    switch (st_type = stmt->type) {
	    

        case ST_EXPR:   charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenExprStmt(stmt->stmtstruct.expr);
			charlie_token(F, NEWLINE_TOKEN, NULL, 0); break; 
        case ST_COMPOUND:GenCompoundStmt(stmt->stmtstruct.compound->stmt_list,
				stmt->stmtstruct.compound->var_list); break;
        case ST_SERLOOP:
         { 
            int looptype;
            switch (looptype = stmt->stmtstruct.serloop->loop_type) {
		case LT_DO: 
			charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenDoStmt(stmt->stmtstruct.serloop); break;
		case LT_FOR:
			charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenForStmt(stmt->stmtstruct.serloop); break;
		case LT_WHILE: 
			charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenWhileStmt(stmt->stmtstruct.serloop); break;
		default: Punt("GenStmt2: Invalid serial loop type");
            } 
            break;
          }
        case ST_IF: 	charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenIfStmt(stmt->stmtstruct.ifstmt); break;
        case ST_SWITCH: charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenSwitchStmt(stmt->stmtstruct.switchstmt); break;
        case ST_BREAK: 	charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenBreakStmt(); 
			charlie_token(F, NEWLINE_TOKEN, NULL, 0); break; 
        case ST_CONT: 	charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenContinueStmt(); 
			charlie_token(F, NEWLINE_TOKEN, NULL, 0); break; 
        case ST_RETURN: charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenReturnStmt(stmt->stmtstruct.ret);
			charlie_token(F, NEWLINE_TOKEN, NULL, 0); break; 
        case ST_GOTO: 	charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenGotoStmt(stmt->stmtstruct.label);
			charlie_token(F, NEWLINE_TOKEN, NULL, 0); break; 
        case ST_NOOP: 	GenNullStmt();
			charlie_token(F, NEWLINE_TOKEN, NULL, 0); break; 
        case ST_PSTMT: 	GenPStmt(stmt->stmtstruct.pstmt); break;
        case ST_ADVANCE: charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenAdvanceStmt(stmt->stmtstruct.advance); 
			charlie_token(F, NEWLINE_TOKEN, NULL, 0); break; 
        case ST_AWAIT: 	charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenAwaitStmt(stmt->stmtstruct.await);
			charlie_token(F, NEWLINE_TOKEN, NULL, 0); break; 
        case ST_PARLOOP:
          {        
            int ploop;       
            switch (ploop = stmt->stmtstruct.parloop->loop_type) {   
               case LT_DOALL:
			charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenDoallStmt(stmt->stmtstruct.parloop); break;   
               case LT_DOACROSS:
			charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenDoacrossStmt(stmt->stmtstruct.parloop); break; 
               case LT_DOSUPER:
			charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenDosuperStmt(stmt->stmtstruct.parloop); break;   
               case LT_DOSERIAL:
			charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenDoserialStmt(stmt->stmtstruct.parloop); break;
               default: Punt("GenStmt2: Invalid parallel loop type");  
               }       
            break;
	  }
	case ST_BODY: GenStmts(stmt->stmtstruct.bodystmt->statement); break;
	case ST_EPILOGUE: /* for now, don't print epilogue */ break;
        case ST_MUTEX: 	charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenMutexStmt(stmt->stmtstruct.mutex); break;
        case ST_COBEGIN: charlie_token(F, LINE_NUM_TOKEN, NULL, stmt->lineno);
			GenCobeginStmt(stmt->stmtstruct.cobegin); break; 
        default:
                Punt("GenStmt2: unknown Stmt2 tag");
    }

    GEN_CHARLIE_SUBPROC_EXIT("Stmt2",0);
}


/******************************************************************************
    GenLabels():
        Write out a list of Pcode $Label nonterms.

        Pcode grammar: $Label =
                           $CaseLabel    |
                           $DefaultLabel |
                           $GotoLabel

        Parameters: Labels: A pointer to a list of labels

        Returns: Whether or not at least one label was printed

        Calls:  GenGotoLabel()
                GenCaseLabel()
		Punt()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
******************************************************************************/

static int GenLabels(labels)
Label labels;
{
 int label_found = FALSE;

 GEN_CHARLIE_SUBPROC_ENTER("GenLabels",0);
 while (labels != 0){

   label_found = TRUE;
   switch (labels->type){
	case LB_LABEL:
		charlie_token(F, IDENT_TOKEN, labels->val, 0);
		charlie_token(F, IDENT_TOKEN, COLON_CHARLIE, 0);
		break;
	case LB_CASE:
		GenExprList(labels->expression);
		charlie_token(F, IDENT_TOKEN, COLON_CHARLIE, 0);
		break;
	case LB_DEFAULT:
		charlie_token(F, IDENT_TOKEN, DEFAULT_LABEL_CHARLIE, 0);
		charlie_token(F, IDENT_TOKEN, COLON_CHARLIE, 0);
		break;
 	default:
		Punt("GenLabels: unknown Label tag");
   }
 labels = labels->next;
 }

 GEN_CHARLIE_SUBPROC_EXIT("GenLabels",0);
 return label_found;
}

/******************************************************************************
    GenStmts():
        Write out a Pcode $Stmt nonterm.

        Pcode grammar: $Stmt =
                           (($Label*) $Stmt2 ($Pragma*) $Pos?)

        Parameters: Stmt: A pointer to the statement and position information
                    Pragmas: A pointer to a list of statement pragmas

        Returns: Nothing

        Calls:  GenStmt2()
                GenPragma()
                GenLabels()
                GenPos()
                extern charlie_token()
                extern ERR()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/


static void GenStmts(stmt)
Stmt stmt;
{
    Pragma cur_pragma;
    int label_found;
    int only_child = FALSE;

    GEN_CHARLIE_SUBPROC_ENTER("Stmt",0 );

    if (stmt != 0 && stmt->lex_next == 0 && 
	stmt->parent != 0 && stmt->parent->type != ST_COMPOUND) {

	charlie_token(F, INDENT_TOKEN, NULL, 0);
	only_child = TRUE;
    } else only_child = FALSE;

    while (stmt != 0) {

	label_found = GenLabels(stmt->labels);
	if (label_found) charlie_token(F, INDENT_TOKEN, NULL, 0);

	GenStmt2(stmt);

	/*
	if ( (!pretty_print) || stmt->pragma != 0){
	    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
	    cur_pragma = stmt->pragma;
	    while (cur_pragma != NULL) {

		     GEH - no longer needed (5/9/93)
		     if (strncmp(cur_pragma->specifier, STMT_PRAGMA_CHARLIE,
			     strlen(STMT_PRAGMA_CHARLIE)) != 0) {
			    Punt("GenStmt: statement pragma expected");
		     }
		     else {
			    GenPragma(cur_pragma, stmt->filename);
			    cur_pragma = cur_pragma->next;

		     }
	    }
	    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
	}
	*/

	if (label_found) charlie_token(F, OUTDENT_TOKEN, NULL, 0);

	stmt = stmt->lex_next;
    }
    if (only_child) charlie_token(F, OUTDENT_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("Stmt",0);
}


void Gen_CHARLIE_Stmt(FL, stmt)
FILE *FL;
Stmt stmt;
{
    int label_found;
    Pragma cur_pragma;

    F = FL;

    GEN_CHARLIE_SUBPROC_ENTER("_CHARLIE_Stmt", 0);

    label_found = GenLabels(stmt->labels);
    if (label_found) charlie_token(F, INDENT_TOKEN, NULL, 0);

    GenStmt2(stmt);

    /* 
    if ( (!pretty_print) || stmt->pragma != 0){
    	charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    	cur_pragma = stmt->pragma;
    	while (cur_pragma != NULL) {

		 GEH - no longer needed (5/9/93) 
       		 if (strncmp(cur_pragma->specifier, STMT_PRAGMA_CHARLIE,
               		 strlen(STMT_PRAGMA_CHARLIE)) != 0) {
                 	Punt("GenStmt: statement pragma expected");
        	 }
        	 else {
            		GenPragma(cur_pragma, stmt->filename);
            		cur_pragma = cur_pragma->next;
        	 }
    	}
    	charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
    }
    */

    if (label_found) charlie_token(F, OUTDENT_TOKEN, NULL, 0);
   
    GEN_CHARLIE_SUBPROC_EXIT("_CHARLIE_Stmt",0);
}


#ifdef IMPLEMENT_LATER

 /******************************************************************************
    GenFunctHead():
        Write out a Pcode $FunctHead nonterm.

        Pcode grammar: $FunctHead =
                (BEGIN_FN $VarID $Pos?) $DeclSpec ($FunctPrmDecl*) ($Pragma*)

        Parameters: FunctID: A function variable identifier
                    Pos: A pointer to the function position
                    TypeSpec: A pointer to the function return type
                                specifier
                    Dcltr: A pointer to a list of  function return type modifier
                    PrmDecls: A pointer to the list of function parameter
                                declarations
                    Pragmas: A pointer to the list of pragmas declared before
                                the function definition
                    FunctBody: A pointer to the function body which may
                                contain more pragmas
                   
        Returns: Nothing

        Calls:  GenVarId()
                GenPos()
                GenDeclSpec()
                GenFunctPrmDecl()
                GenPragma()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenFunctHead(FunctID, LPos, CPos, FName, TypeSpec, TDcltr, PrmDecls, Pragmas)
char *FunctID;
int  LPos, CPos;
char *FName;
Type TypeSpec;
Dcltr TDcltr;
VarList PrmDecls;
Pragma Pragmas;

{

    GEN_CHARLIE_SUBPROC_ENTER("FunctHead",FunctID);

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    charlie_token(F, IDENT_TOKEN, BEGIN_FUNCT_DECL_CHARLIE, 0);

    GenVarId(FunctID);
    if (line_yes) Gen_CHARLIE_LinePos(F,LPos, CPos, FName);

    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
    /* Function Declaration Specification */

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    if (TypeSpec == 0){
         fprintf(Ferr,"DeclSpec: TcSpec  missing for func %s \n", FunctID);
         return;
    }
     GenType(TypeSpec);
     GenDcltr(TDcltr, 0);
     charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

   /* Function Parameter Declaration */

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    while(PrmDecls != NULL) {
        GenFunctPrmDecl(PrmDecls);
        PrmDecls = PrmDecls->next;
    }
    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);


   /* Function Pragma Declaration */
    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);

    /* process function pragmas declared before function definition */
    while(Pragmas != NULL) {

	/* GEH - no longer needed (5/9/93)
        if (strncmp(Pragmas->specifier, FUNCT_PRAGMA_CHARLIE,
                strlen(FUNCT_PRAGMA_CHARLIE)) != 0) {
            Punt("GenFunctHead: function pragma expected");
        }
        else */ 
	GenPragma(Pragmas, FName);
        Pragmas = Pragmas->next;
    }

    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("FunctHead",FunctID);
}

/******************************************************************************
    GenFunctTail():
        Write out a Pcode $FunctTail nonterm.

        Pcode grammar: $FunctTail =
                           (END_FN $VarID)

        Parameters: FunctID: a function variable identifier

        Returns: Nothing

        Calls:  GenVarId()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenFunctTail(FunctID)
char *FunctID;
{
    GEN_CHARLIE_SUBPROC_ENTER("FunctTail",FunctID);

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    charlie_token(F, IDENT_TOKEN, END_FUNCT_DECL_CHARLIE, 0);

    GenVarId(FunctID);
    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("FunctTail",FunctID);
}



/* print function definition. */

/******************************************************************************
    GenFunction():
        Write out a Pcode $FunctDecl nonterm.

        Pcode grammar: $FunctDecl =
                           ($FunctHead $FunctBody $FunctTail)
                       $FunctBody =
                           $CompoundStmt

        Parameters: FunctDecl: A pointer to the FunctDecl_t structure
                    Pragmas: A pointer to the list of PragmaDecl_t structures

        Returns: Nothing

        Calls:  GenFunctHead()
                GenCompoundStmt()
                GenFunctTail()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
 
static GenFunction(func)
FuncDcl func;
{
   GEN_CHARLIE_SUBPROC_ENTER("FunctDecl",func->name);
     
    if (func==0) Punt("GenFunction : nil input");
    if (func->type==0) Punt("GenFunction : no return type");
    if (func->name==0) Punt("GenFunction : no name");

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);

    GenFunctHead(func->name, func->lineno, func->colno, func->filename, 
    func->type, func->type->dcltr, func->param, func->pragma);

    /*SK changing to reflect explicit compd. stmt*/
    GenStmt(func->stmt);


    GenFunctTail(func->name);

    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("FunctDecl",func->name);
}


/*========================================================================*/


/******************************************************************************
    GenEnumItem():
        Write out a Pcode $EnumItem nonterm.

        Pcode grammar: $EnumItem =
                           ($EnumID $Expr?)

        Parameters: EnumItem: A pointer to an enumeration item

        Returns: Nothing

        Calls:  GenVarId()
                GenExpr()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

static GenEnumItem(item)
EnumField item;
{
     char *name;
    if (item->new_name != 0) name = item->new_name;
    else name = item->name; 
    GEN_CHARLIE_SUBPROC_ENTER("EnumItem",name);

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    GenVarId(name);

    if (item->value != NULL) GenExpr(item->value);
    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("EnumItem",name);
}


/* print enum type definition. */

/******************************************************************************
    GenEnumDcl():
        Write out a Pcode $EnumSpec nonterm.

        Pcode grammar: $EnumSpec =
                           (ENUM $EnumID? $EnumItem*)

        Parameters: EnumSpec: A pointer to an enumeration specifier

        Returns: Nothing

        Calls:  GenVarId()
                GenEnumItem()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
    
static GenEnumDcl(E)
EnumDcl E;
{
    EnumField ptr;

    char *name;
    if (E->new_name != 0) name = E->new_name;
    else name = E->name; 

    GEN_CHARLIE_SUBPROC_ENTER("EnumSpec ",name);
    if (E==0) Punt("GenEnumDcl : nil E");

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    charlie_token(F, IDENT_TOKEN, TYPE_DEFINITION_CHARLIE, 0);
    
    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    charlie_token(F, IDENT_TOKEN, ENUM_CHARLIE, 0);

    /* ONLY using NEWNAME for now, may have to change this later */
    if (name != NULL) GenVarId(name);

    ptr = E->fields;

    while (ptr != NULL) {
        GenEnumItem(ptr);
        ptr = ptr->next;
    }

    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
    if(line_yes) /* output position */
       if (E->filename != 0)
         Gen_CHARLIE_LinePos(F, E->lineno, E->colno, E->filename);

    GEN_CHARLIE_SUBPROC_EXIT("EnumSpec",name);
}


/*========================================================================*/
/******************************************************************************
    
      GenStructField():
        Write out a Pcode struct or union $FieldDecl nonterm.

        Pcode grammar: $FieldDecl =
                           ($VarID $DeclSpec $Expr?)   |
                           ($DeclSpec $Expr)

        Parameters: Field: A pointer to a field declaration

        Returns: Nothing

        Calls:  GenVarId()
                _DeclSpec()
                pcode_Expr()
                extern charlie_token()
                extern ERR()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenStructField(field)
Field field;
{

    GEN_CHARLIE_SUBPROC_ENTER("GenStructField",field->name);

        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        if (field->name != 0) 
            GenVarId(field->name);
        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        if (field->type == 0){
         fprintf(Ferr,"DeclSpec: TcSpec  missing for field %s \n", field->name);         return;
        } 
        GenType(field->type);
        GenDcltr(field->type->dcltr, 0);
        charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);        
        if  (field->bit_field != 0) {
            charlie_token(F, IDENT_TOKEN," ", 0);
            GenExpr(field->bit_field); 
         }
        charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);


    GEN_CHARLIE_SUBPROC_EXIT("GenStructField", field->name);
}


/******************************************************************************
    GenStructDcl():
        Write out a Pcode structure nonterm.

        Pcode grammar: $StructSpec =
                           (STRUCT $StructID? $FieldDecl*)   

        Parameters: S: A pointer to a  structure declarator

        Returns: Nothing

        Calls:  GenVarId()
                GenStructField()
                extern charlie_token()
 ******************************************************************************/

static GenStructDcl(S)
StructDcl S;
{
 Field cur_field_decl = S->fields;
 char *name;
 
    if (S->new_name != 0) name = S->new_name;
    else name = S->name; 

    GEN_CHARLIE_SUBPROC_ENTER("GenStructDcl",name);
    
    if (S==0) Punt("GenStructDcl : nil S");

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);

    charlie_token(F, IDENT_TOKEN, TYPE_DEFINITION_CHARLIE, 0);

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);

    charlie_token(F, IDENT_TOKEN, STRUCT_CHARLIE, 0); 

    GenVarId(name);

    while (cur_field_decl != NULL) {
        GenStructField(cur_field_decl);
        cur_field_decl = cur_field_decl->next;
    }

    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("GenStructDcl",name);

    if(line_yes)	/* output position */
	  if(S->filename != 0)
	    Gen_CHARLIE_LinePos(F, S->lineno, S->colno, S->filename);
}

/******************************************************************************
    GenUnionDcl():
        Write out a Pcode Union nonterm.

        Pcode grammar: $StructSpec =
                           (UNION $StructID? $FieldDecl*)   

        Parameters: U: A pointer to a  union declarator

        Returns: Nothing

        Calls:  GenVarId()
                GenStructField()
                extern charlie_token()
 ******************************************************************************/

static GenUnionDcl(U)
StructDcl U;
{
 Field cur_field_decl = U->fields;
 char *name;

 if (U->new_name != 0) name = U->new_name;
 else name = U->name;

    GEN_CHARLIE_SUBPROC_ENTER("GenUnionDcl",name);
    
    if (U==0) Punt("GenUnionDcl : nil S");

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);

    charlie_token(F, IDENT_TOKEN, TYPE_DEFINITION_CHARLIE, 0);
    
    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
   
    charlie_token(F, IDENT_TOKEN, UNION_CHARLIE, 0); 
    

     GenVarId(name);

    while (cur_field_decl != NULL) {
        GenStructField(cur_field_decl);
        cur_field_decl = cur_field_decl->next;
    }

    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
    
    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("GenUnionDecl",name);

    if(line_yes)	/* output position */
	  if(U->filename != 0)
	    Gen_CHARLIE_LinePos(F, U->lineno, U->colno,  U->filename);
}

/*========================================================================*/
static GenInit(init)
Init init;
{
        Init ptr;
	GEN_CHARLIE_SUBPROC_ENTER("GenInit",0);
         if (init == 0) return;
	 if (init->expr != 0)
		GenExpr(init->expr);
	 else 
	 if (init->set != 0) {
		charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);  
		ptr = init->set;
		while (ptr != 0) {
		  GenInit(ptr);
		  ptr = ptr->next;
		}       
	        charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
         } else
		Punt("GenInit: unknown data type");

        

        GEN_CHARLIE_SUBPROC_EXIT("GenInit", "");
}



/******************************************************************************
    GenPragma():
        Write out a Pcode $Pragma nonterm.

        Pcode grammar: $Pragma =
                           (PRAGMA $PString $ExprList $Pos?)

        Parameters: PragmaStmt: A pointer to a pragma statement
                    Pos: A pointer to a position indicator

        Returns: Nothing

        Calls:  GenString()
                GenExprList()
                Gen_CHARLIE_LinePos()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenPragma(pragma, filename)
Pragma pragma; 
char filename;
{
    GEN_CHARLIE_SUBPROC_ENTER("Pragma",pragma->specifier);

    charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    charlie_token(F, IDENT_TOKEN, PRAGMA_CHARLIE, 0);

    GenString(pragma->specifier);
    GenExprList(pragma->expr);

    if (line_yes) Gen_CHARLIE_LinePos(F, pragma->lineno, pragma->colno, filename);
    charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("Pragma",pragma->specifier);
}

/******************************************************************************
    GenTypeDef():
        Write out a Pcode $TypeDef nonterm.

        Pcode grammar: $TypeDef =
                           (DEF $DeclSpec $Pos?)

        Parameters: TypeSpec: A pointer to a type specifier.
                    Pos: A pointer to a position structure.
                    Fname: name of the file.
        Returns: Nothing

        Calls:  GenDeclSpec()
                GenPos()
                extern charlie_token( )
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenTypeDef(TypeSpec,  LPos, CPos,  Fname)
Type TypeSpec;
int LPos, CPos;
char Fname;
{
    GEN_CHARLIE_SUBPROC_ENTER("TypeDef",0);

        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        charlie_token(F, IDENT_TOKEN, TYPE_DEFINITION_CHARLIE, 0);


        /* DECLSPEC */
        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        if (TypeSpec == 0){
          fprintf(Ferr,"DeclSpec:TcSpec missing for TypeDef\n");
          return;
        }
        GenType(TypeSpec);
        GenDcltr(TypeSpec->dcltr, 0);
        charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

        if(line_yes)    /* output position */
          if(Fname != 0)
            Gen_CHARLIE_LinePos(F, LPos, CPos, Fname);

  GEN_CHARLIE_SUBPROC_EXIT("TypeDef",0);
}


/*========================================================================*/
/* print parameter definition. */

/******************************************************************************
    GenFunctPrmDecl():
        Write out a Pcode $FunctPrmDecl nonterm.

        Pcode grammar: $FunctPrmDecl =
                           (PARAM $VarID $DeclSpec $Pos?)

        Parameters: FunctPrmDecl: A pointer to a function parameter declaration

        Returns: Nothing

        Calls:  GenVarId()
                GenType()
		GenDcltr
                GenPos()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/
       
static GenFunctPrmDecl(param)
VarList param;
{
   VarList cur_dcltr; 
   
    GEN_CHARLIE_SUBPROC_ENTER("FunctPrmDecl",0);

    cur_dcltr = param;

        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        charlie_token(F, IDENT_TOKEN, FUNCT_PRM_DECL_CHARLIE, 0);

        if (cur_dcltr->var->new_name != 0)
          GenVarId(cur_dcltr->var->new_name);
        else
	  GenVarId(cur_dcltr->var->name);

        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        if (cur_dcltr->var->type == 0){
          fprintf(Ferr, "DeclSpec: TcSpec missing for parameter %s \n",
          cur_dcltr->name);
          return;
        }
        GenType(cur_dcltr->var->type);
        GenDcltr(cur_dcltr->var->type->dcltr, 0);
        charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);


	if(line_yes)	/* output position */
	  if(cur_dcltr->var->filename != 0)
	    Gen_CHARLIE_LinePos(F, cur_dcltr->var->lineno, cur_dcltr->var->colno, 
            cur_dcltr->var->filename);

        charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);

    GEN_CHARLIE_SUBPROC_EXIT("FunctPrmDecl",0);
}


/******************************************************************************
    GenLocalDecls():
        Write out a list of Pcode $LocalDecl nonterms.

        Pcode grammar: $LocalDecl =
                           $TypeDef             |
                           $LocalDataDecl

        Parameters: local: A pointer to a list of local declarations

        Returns: Nothing

        Calls:  GenTypeDef()
                GenLocalDataDcl()
                extern ERR()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
 ******************************************************************************/

/*not at all sure of this one, need to check about the pragma stuff later */

static GenLocalDecls(local)
VarList local;
{
 GEN_CHARLIE_SUBPROC_ENTER("GenLocalDecls ",0);
  while (local != 0) {

  /* check if it is a typedef */

   if (local->var->type->type & TY_TYPEDEF){
      GenTypeDef(local->var->type,local->var->lineno,
      		 local->var->colno, local->var->filename);
   } else  
     /* not a typedef, must be a local data declarator */
     GenLocalDataDcl(local->var); 
     
     local = local->next;
   }
  GEN_CHARLIE_SUBPROC_EXIT("GenLocalDecls ",0);
} 
     

static GenLocalDataDcl(V)
VarDcl V;
{
        Pragma ptr;
	char *name;
	/*
	 * (RVAR name%s DeclSpec Initializer)
	 */
        if (V->new_name != 0) name = V->new_name;
        else name = V->name;

        GEN_CHARLIE_SUBPROC_ENTER("LocalDataDecl", name);
	if (V==0) Punt("GenGlobalDataDcl : declarator missing");

        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        charlie_token(F, IDENT_TOKEN, LOCAL_DATA_DECL_CHARLIE, 0);
        GenVarId(name);
       

 
        /* DECLSPEC */
        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    	if (V->type == 0){
          fprintf(Ferr,"DeclSpec:TcSpec missing for localdatadecl\n");        
          return;
    	} 
        GenType(V->type);
        GenDcltr(V->type->dcltr, 0);
    	charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0); 


        /* INIT EXPR */
        /* need to find out abou this extern */       
/*	if (! (V->type->type & TY_EXTERN)) { */
	    if (V->init!=0) {
		GenInit(V->init);
	    }else{
            charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
            charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
            }
       /* } */


        /* PRAGMA LIST */

        ptr = V->pragma;
        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        while (ptr != NULL) {
         
	  /* GEH - no longer needed (5/9/93)
          if (strncmp(ptr->expr, LVAR_PRAGMA_CHARLIE,
              strlen(GVAR_PRAGMA_CHARLIE)) != 0) {
            Punt("GenLocalDataDcl: local variable pragma expected"); 
          } else */ GenPragma(ptr, V->filename);
  

          ptr = ptr->next;
        } 
       charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
       charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
            
	if(line_yes)	/* output position */
	  if(V->filename != 0)
	    Gen_CHARLIE_LinePos(F, V->lineno, V->colno, V->filename);
       GEN_CHARLIE_SUBPROC_EXIT("LocalDataDecl",name);
}
 
/* print global variable definition. */
/* the type definition is what's recorded at that instance of the
 * global variable definition. If it is extern class, the initialization
 * section is not printed.
 */

/******************************************************************************
    GenGlobalDataDecl():
        Write out a Pcode $GlobalDataDecl nonterm.

        Pcode grammar: $GlobalDataDecl =
                            (GVAR $VarID $DeclSpec $InitExpr ($Pragma*) $Pos?) |
                            (GVAR $VarID $DeclSpec () ($Pragma*) $Pos?)

        Parameters: GlobalDataDecl: A pointer to a global data declaration
                    Pragmas: A pointer to a list of pragmas

        Returns: Nothing
 
        Calls:  GenVarId()
                GenType
                GenDcltr()
                GenInit()
                GenPragma()
                Gen_CHARLIE_LinePos()
                extern charlie_token()
                GEN_CHARLIE_SUBPROC_ENTER()
                GEN_CHARLIE_SUBPROC_EXIT()
                Punt()
 ******************************************************************************/
       

static GenGlobalDataDcl(V, type, dcltr)
VarDcl V;
Type type;
Dcltr dcltr;
{
        Pragma ptr;
	char *name; 
	/*
	 * (GVAR name%s DeclSpec Initializer)
	 */
	if (V->new_name != 0) name = V->new_name;
	else name = V->name;
        GEN_CHARLIE_SUBPROC_ENTER("GlobalDataDecl", name);
	if (V==0) Punt("GenGlobalDataDcl : declarator missing");

        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        charlie_token(F, IDENT_TOKEN, GLOBAL_DATA_DECL_CHARLIE, 0);
        GenVarId(name);
       

 
        /* DECLSPEC */
        charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
    	if (type == 0){
          fprintf(Ferr,"DeclSpec:TcSpec missing for globaldatadecl\n");        
          return;
    	} 
        GenType(type);
        GenDcltr(dcltr, 0);
    	charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0); 


        /* INIT EXPR */
        /* need to find out abou this extern */
	if (! (type->type & TY_EXTERN)) {
	    if (V->init!=0) 
		GenInit(V->init);
	    else{ 
		charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
		charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
		} 
            
        } else {
	charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);       
        charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
	}	


        /* PRAGMA LIST */

        ptr = V->pragma;
	charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
        while (ptr != NULL) {
         
	  /* GEH - no longer needed (5/9/93)
          if (strncmp(ptr->expr, GVAR_PRAGMA_CHARLIE,
              strlen(GVAR_PRAGMA_CHARLIE)) != 0) {
            Punt("GenGlobalDataDecl: global variable pragma expected"); 
          } else */ GenPragma(ptr, V->filename);
  

          ptr = ptr->next;
        } 
       charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
       charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);
            
	if(line_yes)	/* output position */
	  if(V->filename != 0)
	    Gen_CHARLIE_LinePos(F, V->lineno, V->colno, V->filename);
}
/*========================================================================*/
Gen_CHARLIE_LinePos(F, lineno, colno, src_file)
FILE *F;
int lineno, colno;
char *src_file;
{
	char ident1[1024], ident2[1024];
	if (BLOCK_OUTPUT) return;
	sprintf(ident1,"%d",lineno);
	sprintf(ident2, "%d",colno);
	charlie_token(F, LEFT_BRACKET_TOKEN, NULL, 0);
	charlie_token(F, IDENT_TOKEN, POS_CHARLIE, 0);
	charlie_token(F, IDENT_TOKEN, src_file, 0);
 	charlie_token(F, IDENT_TOKEN, ident1, 0);
	charlie_token(F, IDENT_TOKEN, ident2, 0);
	charlie_token(F, RIGHT_BRACKET_TOKEN, NULL, 0);	
}
Gen_CHARLIE_Struct(FL, st)
FILE *FL;
StructDcl st;
{
	if (BLOCK_OUTPUT) return;
        GEN_CHARLIE_SUBPROC_ENTER("_CHARLIE_Struct",0);
	F = FL;
	GenStructDcl(st);
        GEN_CHARLIE_SUBPROC_EXIT("_CHARLIE_Struct",0);

}
Gen_CHARLIE_Union(FL, un) 
FILE *FL;
UnionDcl un;
{
	if (BLOCK_OUTPUT) return;
	GEN_CHARLIE_SUBPROC_ENTER("_CHARLIE_Union",0);
	F = FL;
	GenUnionDcl(un);
	GEN_CHARLIE_SUBPROC_EXIT("_CHARLIE_Union",0);
}
Gen_CHARLIE_Enum(FL, en) 
FILE *FL;
EnumDcl en;
{
	if (BLOCK_OUTPUT) return;
	GEN_CHARLIE_SUBPROC_ENTER("_CHARLIE_Enum",0);
	F = FL;
	GenEnumDcl(en);
	GEN_CHARLIE_SUBPROC_EXIT("_CHARLIE_Enum",0);
}
Gen_CHARLIE_Var(FL, var) 
FILE *FL;
VarDcl var;
{
	if (BLOCK_OUTPUT) return;
	GEN_CHARLIE_SUBPROC_ENTER("_CHARLIE_Var",0);
	F = FL;
	GenGlobalDataDcl(var, var->type, var->type->dcltr);
	GEN_CHARLIE_SUBPROC_EXIT("_CHARLIE_Var",0);
}
Gen_CHARLIE_Func(FL, fn, print_option) 
FILE *FL;
FuncDcl fn;
int print_option;
{
	if (BLOCK_OUTPUT) return;
	GEN_CHARLIE_PROC_ENTER("_CHARLIE_Func",fn->name);
	F = FL;
        pretty_print = print_option;
	GenFunction(fn);
	GEN_CHARLIE_PROC_EXIT("_CHARLIE_Func",fn->name);
}

/*========================================================================*/
/* 
 *	The following functions are provided for debugging purpose
 *	only and should not be used in normal operational mode.
 */
Gen_CHARLIE_Init(FL, init)
FILE *FL;
Init init;
{
	F = FL;
	GenInit(init);
}
/*========================================================================*/

#endif
