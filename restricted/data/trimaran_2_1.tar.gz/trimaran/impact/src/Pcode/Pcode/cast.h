/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************
 *	File:	cast.h
 *	Authors: Nancy Warter, David August and Wen-mei Hwu
 *	Modified from code written by: Po-hua Chang
 *****************************************************************************/


#ifndef CAST_H
#define CAST_H

#include <Pcode/pcode.h>

/* 	NJW - this file provides both functions to determine the type
 *	of a variable and also the cast of an expression.  I'm not sure
 *	we want to reduce or simplify expressions in pcode (unless specifically
 *	requested by a transformation) since this will all be done in 
 *	hcode.  However, some of these functions are useful and should be
 *	usable as is.
 */

/*
 *	Structure assignment is allowed.
 *	e.g. struct _buf x, y;
 *		x = y; 		is allowed.
 *		x = &y;		is also allowed.
 *	When the LHS of an assignment is a structure, it copies
 *	sizeof(structure) bytes from the memory location specified
 *	by the RHS operand.
 *
 *	A function may return a structure. It actually returns
 *	a pointer to the structure (struct/union/array).
 *	When structure (struct/union), array, and function are
 *	passed to another function as parameters, their memory
 *	location (pointers to them) are passed instead.
 */

/*
 *	The constant literals can actually be modified by
 *	the user (bad practice). Therefore, it may be wrong
 *	to assume they are all constants. For example, some
 *	programs actually rewrite the string content (string I/O).
 *	When a constant string is passed as parameter, it may be
 *	changed. In this version of the C compiler, it is
 *	assumed that modifying constants causes unpredictable
 *	effect. This assumption allows the compiler more freedom
 *	to perform code optimization.
 *	As a direct consequence, the types of all constant expressions
 *	are marked as TY_CONST.
 */

/*
 *	integral types = [short, long, unsigned, signed, int, char, enum]
 *	arithmetic types = integral types + [float, double]
 *	pointer types = [pointer, 0-dimension array]
 *	fundamental types = arithmetic types + pointer types
 *	structure types = [union, struct]
 *	array type = [N-dimension array, N is defined]
 *	function type = [func]
 *
 *	** pointer and array are inter-changeable.
 */

/* external function declarations */

extern bool IsVoidType(Type type);
extern bool IsIntegralType(Type type);
extern bool IsRealType(Type type);
extern bool IsFloatType(Type type);
extern bool IsDoubleType(Type type);
extern bool IsArithmeticType(Type type);
extern bool IsPointerType(Type type);
extern bool IsFundamentalType(Type type);
extern bool IsStructureType(Type type);
extern bool IsArrayType(Type type);
extern bool IsFunctionType(Type type);
extern bool IsFunctionPointerType(Type type);
extern bool IsCharArrayType(Type type); /* BCC - 2/2/96 */

/*
 *      Upgrade the type to the natural data type (TY_INT, TY_DOUBLE).
 *      This function does not explicitly duplicate the formal parameter.
 *      The caller must make sure that there can be at most one reference
 *      to the expression. (since we assume the expression tree structure
 *      is NOT shared, in RemoveExpr())
 *      (char -> int)
 *      (short -> int)
 *      In this version, we do not do (float->double) in computation.
 */
extern Expr UpgradeArithmeticType(Expr expr, Expr parentexpr);
/* BCC - 8/2/96 */
extern Expr UpgradeArgumentType(Expr expr, Expr parentexpr, int arg_pos);

/*
 *      Add explicit casting operator to upgrade the result
 *      of an expression to a more powerful type.
 *      Need to duplicate the 'type' formal parameter.
 *
 *      HAVEN'T REDUCED TYPE HERE
 */
extern Expr UpgradeType(Expr expr, Type type, Expr parentexpr);

/*
 *      Returns -1 if the two types are not directly comparable.
 *      Returns 1 if the two types are compatible (same strength).
 *      Otherwise, return 0.
 *      !! This function works only for arithmetic types.
 */
extern int EqualStrength(Type type1, Type type2);

/*
 *      The type conversion rules are taken from K&R C book.
 *      The exception is that (float) is not converted to
 *      (double), since it is allowed to have single-precision
 *      computations (faster and less accuracy).
 *      We provide a function to compute the dominant type
 *      which can absorb both type1 and type2, according to
 *      usual arithmetic type conversion, as defined in K&R.
 *      The returned type is a brand new (duplicated) type structure.
 *      This function works only for arithmetic types.
 */
extern Type DominantType(Type type1, Type type2);

/*
 *      We do not care about the dcltr, and directly modify the type info.
 *
 *      TY_SHORT, TY_LONG, TY_SIGNED, and TY_UNSIGNED are
 *      treated as adjatives for TY_INT and TY_CHAR.
 *      In this version,
 *              (TY_SIGNED|TY_CHAR) == TY_CHAR
 *              (TY_SIGNED|TY_INT) == TY_INT
 *              (TY_SIGNED|TY_SHORT) == TY_SHORT
 *              (TY_SIGNED|TY_LONG) == TY_LONG
 *              (TY_SHORT|TY_INT) == TY_SHORT
 *              (TY_LONG|TY_INT) == TY_LONG
 *              (TY_UNSIGNED|TY_CHAR)
 *              (TY_UNSIGNED|TY_INT)
 *              (TY_UNSIGNED|TY_SHORT)
 *              (TY_UNSIGNED|TY_LONG)
 *
 *      All other combinations of [TY_SIGNED, TY_CHAR, TY_INT, TY_SHORT,
 *      TY_LONG, TY_UNSIGNED] are illegal.
 *
 *      TY_SHORT, and TY_LONG, cannot be
 *      used to describe TY_FLOAT and TY_DOUBLE.
 *      The exception is (TY_LONG|TY_FLOAT)==TY_DOUBLE
 *
 *      Since 'signed' is the default, we can mask out the TY_SIGNED bit
 *      after making sure that it is not TY_UNSIGNED. The reason for
 *      masking this bit is that some C compiler does not like 'signed'
 *      and we would like the output (in C) to work for most C compilers.
 */
extern void UnifyArithmeticType(Type type);

/*
 * Determine the resultant type of the expression based on
 * its operator and its operands.
 * Check if the types of operands are compatible.
 * Add new expressions to explicitely cast the operands to
 * the required types.
 *
 * 10/92 - NJW - remove scope from CastExpr 
 */
extern void CastExpr(Expr expr);

/* BCC - 2/17/97 */
int SizeOf(Type type);

#endif
