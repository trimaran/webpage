/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   links.c
 *      Author: Krishna Subramanian and Wen-mei Hwu
 \****************************************************************************/




#include <Pcode/impact_global.h>
#include <Pcode/pcode.h>
#include <Pcode/struct.h>
#include <Pcode/parms.h>
#include <Pcode/links.h>

/* initially, st = first stmt in fcn */
/* SK, changing LinkLoops to accept 2 parameters, one of which is a pointer
 * to the parent of the loop, which is not null only when a nested call is
 * made*/
/*KS*/


void LinkLoopsRt(st, parentptr)
     Stmt st;
     Stmt parentptr;
{
  if(st == 0)  return;
  switch(st->type) {
  case ST_NOOP:
  case ST_CONT:
  case ST_BREAK:
  case ST_RETURN:
  case ST_GOTO:
  case ST_EXPR:
  case ST_ADVANCE:
  case ST_AWAIT:
    break;
  case ST_IF:
    LinkLoopsRt(st->stmtstruct.ifstmt->then_block,parentptr);
    LinkLoopsRt(st->stmtstruct.ifstmt->else_block,parentptr);
    break;
  case ST_SWITCH:
    LinkLoopsRt(st->stmtstruct.switchstmt->switchbody,parentptr);
    break;
  case ST_PSTMT:
    LinkLoopsRt(st->stmtstruct.pstmt->stmt,parentptr);
    break;
  case ST_MUTEX:
    LinkLoopsRt(st->stmtstruct.mutex->statement,parentptr);
    break;
  case ST_COBEGIN:
    LinkLoopsRt(st->stmtstruct.cobegin->statements,parentptr);
    break;
  case ST_COMPOUND:
    LinkLoopsRt(st->stmtstruct.compound->stmt_list,parentptr);
    break;
  case ST_PARLOOP:
    {
      Stmt tptr;
      /*Making changes here; checking if parentptr is nil, in which case the
       * routine stays the same as before, if not, the current loop is nested
       * within another parloop and so its parent ptr is set to parentptr and
       *it is added to the linked list of children of the parent*/
      
      /*check if parentptr is NIL*/
      if(parentptr == 0) {
	if(currentFuncDcl->par_loop == 0) {
	  currentFuncDcl->par_loop = st;
	} else {
	  tptr = currentFuncDcl->par_loop;
	  
	  while(tptr->stmtstruct.parloop->sibling!= 0)
	    tptr = tptr->stmtstruct.parloop->sibling;
	  tptr->stmtstruct.parloop->sibling= st;
	}
	
	/* GEH - added to fix for multiple calls */
	st->stmtstruct.parloop->sibling = 0;
      }
      else /*add the loop to the list of children; if any*/
	{
	  if(parentptr->stmtstruct.parloop->child == 0)
	    parentptr->stmtstruct.parloop->child = st;
	  else
	    {
	      tptr = parentptr->stmtstruct.parloop->child;
	      while (tptr->stmtstruct.parloop->sibling!= 0)
		tptr = tptr->stmtstruct.parloop->sibling;
	      tptr->stmtstruct.parloop->sibling= st;
	    }
	  st->stmtstruct.parloop->parent = parentptr; /*set its parentptr*/
	  
	  /* GEH - added to fix for multiple calls */
	  st->stmtstruct.parloop->sibling = 0;
	  
	} /*end of add list*/
      
      /* GEH - attempt to fix for multiple calls */
      st->stmtstruct.parloop->child = 0;
      
      LinkLoopsRt(st->stmtstruct.parloop->pstmt->stmt,st);
      break;
      
    }
  case ST_SERLOOP:
    LinkLoopsRt(st->stmtstruct.serloop->loop_body,parentptr);
    break;
  case ST_BODY:
    LinkLoopsRt(st->stmtstruct.bodystmt->statement,parentptr);
    break;
  case ST_EPILOGUE:
    LinkLoopsRt(st->stmtstruct.epiloguestmt->statement,parentptr);
    break;
  default:
    Punt("LinkLoops: Invalid instruction type");
  }
  if(st->lex_next != 0)
    LinkLoopsRt(st->lex_next,parentptr);
}


void LinkLoops(func)
     FuncDcl func;
{
  if (!DEMO_OUTPUT && (verbose_yes || debug_yes))
    fprintf(Flog, "..LinkLoops beginning on fn (%s)\n", func->name);
  
  func->par_loop = 0;
  LinkLoopsRt(func->stmt, 0);
  
  if (!DEMO_OUTPUT && (verbose_yes || debug_yes))
    fprintf(Flog, "..LinkLoops complete for fn (%s)\n", func->name);
}



/* GEH - added previous pointer linking for ExprLists (4/23/93) */
void LinkExpr(expr, parentst, parentexpr, previous) 
     Expr expr;
     Stmt parentst;
     Expr parentexpr;
     Expr previous;
{
  Expr cur_child;
  
  while (expr != 0)
    {
      /* set parent ptrs of current expression */
      expr->parentstmt = parentst;
      expr->parentexpr = parentexpr;
      
      /* recurse over the children of the current expression */
      cur_child = expr->operands;
      while (cur_child != 0) {
	LinkExpr(cur_child,parentst,expr,0);
        cur_child = cur_child->sibling;
      }
      
      expr->previous = previous;

      /* GEH added semantics check.  These are the only expressions that
	 can have ExprLists as operands */

      if ((expr->next != 0 || expr->previous != 0) &&
	  expr->parentexpr != 0 &&
	  expr->parentexpr->opcode != OP_call &&
	  expr->parentexpr->opcode != OP_index &&
	  expr->parentexpr->opcode != OP_quest &&
	  expr->parentexpr->opcode != OP_compexpr) {
	  Punt("LinkExpr: ExprList where Expr expected");
      }
      previous = expr;
      expr = expr->next;
    }
  
}



/*SK LinkStmts links all the statements within a compound statement to the state
  ment*/
/* GEH - added lex_prev linking (4/23/92) */

void LinkStmtsRt(st, parentptr, lex_prev)
     Stmt st;
     Stmt parentptr;
     Stmt lex_prev;
{
  while (st != 0)
    {
      st->parent = parentptr;
      switch(st->type) {
      case ST_NOOP:
      case ST_CONT:
      case ST_BREAK:
      case ST_GOTO:
      case ST_ADVANCE:
      case ST_AWAIT:
	break;
      case ST_RETURN:
	if (st->stmtstruct.ret != 0)
	  LinkExpr(st->stmtstruct.ret,st,0,0);
	break;
      case ST_EXPR: 
	LinkExpr(st->stmtstruct.expr,st,0,0);
	break;
      case ST_IF:
	LinkStmtsRt(st->stmtstruct.ifstmt->then_block,st,0);
	LinkStmtsRt(st->stmtstruct.ifstmt->else_block,st,0);
	if (st->stmtstruct.ifstmt->cond_expr != 0) 
	  LinkExpr(st->stmtstruct.ifstmt->cond_expr,st,0,0); 
	break;
      case ST_SWITCH:
	LinkStmtsRt(st->stmtstruct.switchstmt->switchbody,st,0);
	LinkExpr(st->stmtstruct.switchstmt->expression,st,0,0);
	break;
      case ST_PSTMT:
	LinkStmtsRt(st->stmtstruct.pstmt->stmt,st,0);
	break;
      case ST_MUTEX:
	LinkStmtsRt(st->stmtstruct.mutex->statement,st,0);
	LinkExpr(st->stmtstruct.mutex->expression,st,0,0);
	break;
      case ST_COBEGIN:
	LinkStmtsRt(st->stmtstruct.cobegin->statements,st,0);
	break;
      case ST_COMPOUND:
	LinkStmtsRt(st->stmtstruct.compound->stmt_list,st,0);
	break;
      case ST_PARLOOP:
	LinkStmtsRt(st->stmtstruct.parloop->pstmt->stmt,st,0);
	/*SK: 1/19/93  Adding call to link iteration_var also, since it is a expr*/
	LinkExpr(st->stmtstruct.parloop->iteration_var,st,0,0);
	LinkExpr(st->stmtstruct.parloop->init_value,st,0,0);
	LinkExpr(st->stmtstruct.parloop->final_value,st,0,0);
	LinkExpr(st->stmtstruct.parloop->incr_value,st,0,0);
	break;
      case ST_SERLOOP:
	LinkStmtsRt(st->stmtstruct.serloop->loop_body,st,0);
	LinkExpr(st->stmtstruct.serloop->cond_expr,st,0,0);
	LinkExpr(st->stmtstruct.serloop->init_expr,st,0,0);
	LinkExpr(st->stmtstruct.serloop->iter_expr,st,0,0);
	break;
      case ST_BODY:
	LinkStmtsRt(st->stmtstruct.bodystmt->statement,st,0);
	break;
      case ST_EPILOGUE:
	LinkStmtsRt(st->stmtstruct.epiloguestmt->statement,st,0);
	break;
      default:
	Punt("LinkStmts: Invalid instruction type");
      }
      st->lex_prev = lex_prev;
      lex_prev = st;
      st = st->lex_next;
      if(st==0) return;
    }
}


void LinkStmts(func)
     FuncDcl func;
{
  
  if (DEBUG_LINKS)
    fprintf(Flog, "..LinkStmts beginning on fn (%s)\n", func->name);
  
  /* SK 03/06/93 Changing this to reflect that a function has an explicit
     compound stmt*/
  LinkStmtsRt(func->stmt, 0, 0);
  
  if (DEBUG_LINKS)
    fprintf(Flog, "..LinkStmts complete for fn (%s)\n", func->name);
} 
