/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/

/*****************************************************************************\
 *	File:	gen_pcode.h
 *	Author: Krishna Subramanian  and Wen-mei Hwu
 *	Code Modified from code written by Nancy Warter
 \*****************************************************************************/


#ifndef GEN_PCODE_H
#define GEN_PCODE_H

/* to specify if pretty printing(without null epilogues and prologues) needed */

#define PRETTY_PRINT_PCODE   1
#define NO_PRETTY_PRINT_PCODE 0

/* constant definitions for pcode grammar language identifiers */

#define POS_PCODE		"POS"
#define BEGIN_FUNCT_DECL_PCODE	"BEGIN_FN"
#define END_FUNCT_DECL_PCODE	"END_FN"
#define GLOBAL_DATA_DECL_PCODE	"GVAR"
#define TYPE_DEFINITION_PCODE	"DEF"
#define FUNCT_PRM_DECL_PCODE	"PARAM"
#define PROTOTYPE_DECL_PCODE    "FPARAM"        /* BCC - 1/21/96 */
#define LOCAL_DATA_DECL_PCODE	"LVAR"
#define EXPR_STMT_PCODE		"EXPR"
#define COMPOUND_STMT_PCODE	"COMPSTMT"
#define DO_STMT_PCODE		"DO"
#define WHILE_STMT_PCODE	"WHILE"
#define FOR_STMT_PCODE		"FOR"
#define IF_STMT_PCODE		"IF"
#define THEN_STMT_PCODE		"THEN"
#define ELSE_STMT_PCODE		"ELSE"
#define SWITCH_STMT_PCODE	"SWITCH"
#define BREAK_STMT_PCODE	"BREAK"
#define CONTINUE_STMT_PCODE	"CONTINUE"
#define RETURN_STMT_PCODE	"RETURN"
#define GOTO_STMT_PCODE		"GOTO"
#define GOTO_LABEL_PCODE	"LABEL"
#define CASE_LABEL_PCODE	"CASE"
#define DEFAULT_LABEL_PCODE	"DEFAULT"
#define NULL_STMT_PCODE		"NULL"
#define PRAGMA_PCODE		"PRAGMA"
/* BCC - added for splitting - 5/26/95 */
#define INCLUDE_PCODE		"INCLUDE"
/* GEH - no longer needed (5/9/93)
    #define FUNCT_PRAGMA_PCODE	"\"FN"
    #define STMT_PRAGMA_PCODE	"\"ST"
    #define GVAR_PRAGMA_PCODE	"\"GV"
    #define LVAR_PRAGMA_PCODE	"\"LV"
*/
#define P_STMT_PCODE		"PSTMT"
#define ADVANCE_STMT_PCODE	"ADVANCE"
#define AWAIT_STMT_PCODE	"AWAIT"
#define DOSERIAL_STMT_PCODE	"DOSERIAL"
#define DOALL_STMT_PCODE	"DOALL"
#define DOACROSS_STMT_PCODE	"DOACROSS"
#define DOSUPER_STMT_PCODE	"DOSUPER"
#define DOPSTMT_PCODE		"PSTMT"
#define DOPSTMT_PROLOGUE_PCODE	"PROLOGUE"
#define DOPSTMT_BODY_PCODE	"BODY"
#define DOPSTMT_EPILOGUE_PCODE	"EPILOGUE"
#define DOHEAD_INDEX_PCODE	"INDEX"
#define DOHEAD_INIT_PCODE	"INIT"
#define DOHEAD_FINAL_PCODE	"FINAL"
#define DOHEAD_INC_PCODE	"INC"
#define MUTEX_STMT_PCODE	"MUTEX"
#define COBEGIN_STMT_PCODE	"COBEGIN"
#define CONST_PCODE		"CONST"
#define	VOLATILE_PCODE		"VOLATILE"
#define CDECL_PCODE		"CDECL"
#define STDCALL_PCODE		"STDCALL"
#define FASTCALL_PCODE		"FASTCALL"
#define AUTO_PCODE		"AUTO"
#define STATIC_PCODE		"STATIC"
#define EXTERN_PCODE		"EXTERN"
#define REGISTER_PCODE		"REGISTER"
#define TYPEDEF_PCODE		"TYPEDEF"
#define TYPEID_PCODE		"TYPEID"
#define CHAR_PCODE		"CHAR"
#define FLOAT_PCODE		"FLOAT"
#define DOUBLE_PCODE		"DOUBLE"
#define INT_PCODE		"INT"
#define SHORT_PCODE		"SHORT"
#define LONG_PCODE		"LONG"
#define SIGNED_PCODE		"SIGNED"
#define UNSIGNED_PCODE		"UNSIGNED"
#define VOID_PCODE		"VOID"
#define SYNC_PCODE		"SYNC"
#define ENUM_PCODE		"ENUM"
#define STRUCT_PCODE		"STRUCT"
#define UNION_PCODE		"UNION"
#define TY_ENUM_PCODE		"ENUM"
#define TY_STRUCT_PCODE		"STRUCT"
#define TY_UNION_PCODE		"UNION"
#define POINTER_PCODE		"P"
#define FUNCTION_PCODE		"F"
#define ARRAY_PCODE		"A"
#define	ASSIGN_EXPR_PCODE	"ASSIGN"
#define	ADDR_ADD_EXPR_PCODE	"A_ADD"
#define	ADDR_SUB_EXPR_PCODE	"A_SUB"
#define	ADDR_MUL_EXPR_PCODE	"A_MUL"
#define	ADDR_DIV_EXPR_PCODE	"A_DIV"
#define	ADDR_MOD_EXPR_PCODE	"A_MOD"
#define	ADDR_RSHFT_EXPR_PCODE	"A_RSHFT"
#define	ADDR_LSHFT_EXPR_PCODE	"A_LSHFT"
#define	ADDR_AND_EXPR_PCODE	"A_AND"
#define	ADDR_OR_EXPR_PCODE	"A_OR"
#define	ADDR_XOR_EXPR_PCODE	"A_XOR"
#define	DISJ_EXPR_PCODE		"DISJ"
#define	CONJ_EXPR_PCODE		"CONJ"
#define	OR_EXPR_PCODE		"OR"
#define	XOR_EXPR_PCODE		"XOR"
#define	AND_EXPR_PCODE		"AND"
#define	EQ_EXPR_PCODE		"EQ"
#define	NE_EXPR_PCODE		"NE"
#define	LT_EXPR_PCODE		"LT"
#define	LE_EXPR_PCODE		"LE"
#define	GT_EXPR_PCODE		"GT"
#define	GE_EXPR_PCODE		"GE"
#define	RSHFT_EXPR_PCODE	"RSHFT"
#define	LSHFT_EXPR_PCODE	"LSHFT"
#define	ADD_EXPR_PCODE		"ADD"
#define	SUB_EXPR_PCODE		"SUB"
#define	MUL_EXPR_PCODE		"MUL"
#define	DIV_EXPR_PCODE		"DIV"
#define	MOD_EXPR_PCODE		"MOD"
#define	PRE_INC_EXPR_PCODE	"PREINC"
#define	PRE_DEC_EXPR_PCODE	"PREDEC"
#define	POST_INC_EXPR_PCODE	"POSTINC"
#define	POST_DEC_EXPR_PCODE	"POSTDEC"
#define	INDR_EXPR_PCODE		"INDR"
#define	ADDR_EXPR_PCODE		"ADDR"
#define	NEG_EXPR_PCODE		"NEG"
#define	NOT_EXPR_PCODE		"NOT"
#define	INV_EXPR_PCODE		"INV"
#define	VAR_EXPR_PCODE		"VAR"
#define ENUM_EXPR_PCODE         "ENUM"
#define	INT_EXPR_PCODE		"INT"
#define	REAL_EXPR_PCODE		"REAL"
#define	FLOAT_EXPR_PCODE	"FLOAT"
#define	DOUBLE_EXPR_PCODE	"DOUBLE"
#define	CHAR_EXPR_PCODE		"CHAR"
#define	STRING_EXPR_PCODE	"STRING"
#define	INDEX_EXPR_PCODE	"INDEX"
#define	CALL_EXPR_PCODE		"CALL"
#define	DOT_EXPR_PCODE		"DOT"
#define	ARROW_EXPR_PCODE	"ARROW"
#define	COMPOUND_EXPR_PCODE	"COMPEXPR"
#define	TYPE_SIZE_EXPR_PCODE	"TYPESIZE"
#define	EXPR_SIZE_EXPR_PCODE	"EXPRSIZE"
#define	CAST_EXPR_PCODE		"CAST"
#define	QUEST_EXPR_PCODE	"QUEST"
#define	ERROR_EXPR_PCODE	"ERROR"
#define	VARARG_PCODE		"VARARG"
/* LCW - Pcode profile - 10/25/95 */
#define PROFILE_PCODE		"PROFILE"

#include <Pcode/pcode.h>

extern Gen_PCODE_Struct(FILE *FL, StructDcl st);
extern Gen_PCODE_Union(FILE *FL, UnionDcl un);
extern Gen_PCODE_Enum(FILE *FL, EnumDcl en);
extern Gen_PCODE_Var(FILE *FL, VarDcl var);
extern Gen_PCODE_Func(FILE *FL, FuncDcl fn, int print_option);
/* BCC - 5/26/95 */
extern Gen_PCODE_Include(FILE *FL, char *file);

/* LCW - generate Pcode profiling information - 10/25/95 */
extern Gen_PCODE_Profile(FILE *FL, struct _ProfST *profptr);

#endif
