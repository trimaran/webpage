/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.31  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 21, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	process.c
 *	Author:	Nancy Warter and Wen-mei Hwu
 *	Modified from code written by: Po-hua Chang
\*****************************************************************************/


#include <Pcode/impact_global.h>
#include <Pcode/parms.h>
#include <Pcode/environ.h>
#include <Pcode/struct.h>
#include <Pcode/gen_pcode.h>
#include <Pcode/gen_hcode.h>
#include <Pcode/cf_contr-flow.h>
#include <Pcode/dd_conversion.h>
#include <Pcode/dd_data-dep.h>
#include <Pcode/dd_scalar-dep.h>
#include <Pcode/dd_fwd-sub.h>
#include <Pcode/dd_dead-code.h>
#include <Pcode/dd_ind-var-sub.h>
#include <Pcode/profile.h>
#include <Pcode/probe.h>
#include <Pcode/ip_print_func.h>

int num_struct = 0;
int num_union = 0;
int num_enum = 0;
int num_gvar = 0;
int num_func = 0;
int num_expandable_func = 0;	/* BCC - 8/30/96 */
int num_total_func_call = 0;	/* BCC - 8/30/96 */

int dep_pragmas_generated;
char *host_platform, *host_compiler, *preprocessor_invocation;


/*-------------------------------------------------------------*/
ProcessStruct(st)
StructDcl st;
{
	num_struct += 1;
	if (debug_yes | verbose_yes)
	    fprintf(Flog, ".. struct (%s)\n", st->name);
	switch (output_form) {
	    case OUTPUT_HCODE:

#if 0
	      /* BCC -6/99 */
		/* 
		 * BCC - 7/29/96
		 * Don't generate forward declarations for Hcode 
		 */
		if (st->fields)
		    Gen_HCODE_Struct(Fout, st);
#endif
		Gen_HCODE_Struct(Fout, st);
		if (do_merge_profiling)
		{
		    Gen_PCODE_Struct(Fout2, st);
		}
		break;
	    case OUTPUT_PCODE:  /* (Def (Struct ...)) */
		Gen_PCODE_Struct(Fout, st);
		break;
	    case OUTPUT_NM:	/* BCC - generate "nm -g" information 10/7/96 */
	    case OUTPUT_NONE:
		break;
	    default:
		break;
	}
}
/*-------------------------------------------------------------*/
ProcessUnion(un)
UnionDcl un;
{
	num_union += 1;
	if (debug_yes | verbose_yes)
	    fprintf(Flog, ".. union (%s)\n", un->name);
	switch (output_form) {
	    case OUTPUT_HCODE:
#if 0
	        /* BCC - 6/99 */
		/* 
		 * BCC - 7/29/96
		 * Don't generate forward declarations for Hcode 
		 */
		if (un->fields) 
		    Gen_HCODE_Union(Fout, un);
#endif
		Gen_HCODE_Union(Fout, un);
		if (do_merge_profiling)
		{
		    Gen_PCODE_Union(Fout2, un);
		}
		break;
	    case OUTPUT_PCODE:
		Gen_PCODE_Union(Fout, un);
		break;
	    case OUTPUT_NM:	/* BCC - generate "nm -g" information 10/7/96 */
	    case OUTPUT_NONE:
		break;
	    default:
		break;
	}
}
/*-------------------------------------------------------------*/
ProcessEnum(en)
EnumDcl en;
{
	num_enum += 1;
	if (debug_yes | verbose_yes)
	    fprintf(Flog, ".. enum (%s)\n", en->name);
	switch (output_form) {
	    case OUTPUT_HCODE:
		Gen_HCODE_Enum(Fout, en);
		if (do_merge_profiling)
		{
		    Gen_PCODE_Enum(Fout2, en);
		}
		break;
	    case OUTPUT_PCODE:
		Gen_PCODE_Enum(Fout, en);
		break;
	    case OUTPUT_NM:	/* BCC - generate "nm -g" information 10/7/96 */
	    case OUTPUT_NONE:
		break;
	    default:
		break;
	}
}
/*-------------------------------------------------------------*/
/* Global variable are printed directly to the output.  If a 
 * transformation alters a global variable then it must do a
 * second pass through the code.  The first pass must write to
 * pcode since that is the only input allowed.  The second
 * pass can write to either pcode or C.  Thus, anyone writing 
 * transformations which can alter global variables will have to
 * understand the impact2 code better.
 */
ProcessGlobalVar(var)
VarDcl var;
{
	num_gvar += 1;
	if (debug_yes | verbose_yes)
	    fprintf(Flog, ".. global var (%s)\n", var->name);

	switch (output_form) {
	    case OUTPUT_HCODE:
		Gen_HCODE_Var(Fout, var);
		if (do_merge_profiling)
		{
		    Gen_PCODE_Var(Fout2, var);
		}
		break;
	    case OUTPUT_PCODE:
		Gen_PCODE_Var(Fout, var);
		break;
	    case OUTPUT_NM: {
		char *name;

		name = var->new_name ? var->new_name : var->name;
		if (var->type->type & TY_EXTERN)
		  fprintf(Fout, "         U %s\n", name);
		else
		  fprintf(Fout, "         D %s\n", name);
		break;
	    }
	    case OUTPUT_NONE:
		break;
	    default:
		break;
	}
}

/* BCC - for sync arc stats */
extern int total_arc_count, jsr_access_arc_count, jsr_jsr_arc_count;

/*-------------------------------------------------------------*/
ProcessFuncDcl(func)
FuncDcl func;
{
	_Xform *ptr;
	bool transform_func = TRUE;
	int i;
	FILE *fptr;
	char filename[512];
	Pragma prag;

	/* BCC - remove dead functions after running PIP - 10/24/97 */
	if (remove_dead_function) {
	    sprintf(filename, "%s.pip1", func->name);
	    fptr = fopen(filename, "rt");
            if (fptr)
		fclose(fptr);
	    else {
		fprintf(stderr, "Function %s is dead and its body is removed\n",
			func->name);
		RemoveStmt(func->stmt->stmtstruct.compound->stmt_list);
		func->stmt->stmtstruct.compound->stmt_list = 0;
	    }
	}

	/* BCC - check brand names - 1/29/99 */
	if (verify_brand_names) {
	    prag = FindFunctionPragma(func, "\"IMPACT_HOST_PLATFORM\"");
	    if (prag) {
		if (host_platform == 0) {
		    host_platform = C_findstr(prag->expr->value.string);
		    fptr = fopen("impact_brand.platform", "wt");
		    fprintf(fptr, "%s\n", host_platform);
		    fclose(fptr);
		}
		else {
		    if (strcmp(host_platform, prag->expr->value.string)) {
			fprintf(stderr, 
			"Warning: %s's platform %s is not consistent with %s\n",
				func->name, prag->expr->value.string,
				host_platform);
		    }
		}
	    }

	    prag = FindFunctionPragma(func, "\"IMPACT_HOST_COMPILER\"");
	    if (prag) {
		if (host_compiler == 0) {
		    host_compiler = C_findstr(prag->expr->value.string);
		    fptr = fopen("impact_brand.compiler", "wt");
		    fprintf(fptr, "%s\n", host_compiler);
		    fclose(fptr);
		}
		else {
		    if (strcmp(host_compiler, prag->expr->value.string)) {
			fprintf(stderr, 
			"Warning: %s's compiler %s is not consistent with %s\n",
				func->name, prag->expr->value.string,
				host_compiler);
		    }
		}
	    }

	    prag = FindFunctionPragma(func, 
				      "\"IMPACT_PREPROCESSOR_INVOCATION\"");
	    if (prag) {
		if (preprocessor_invocation == 0) {
		    preprocessor_invocation = 
			C_findstr(prag->expr->value.string);
		    fptr = fopen("impact_brand.preprocessor", "wt");
		    fprintf(fptr, "%s\n", preprocessor_invocation);
		    fclose(fptr);
		}
		else {
		    if (strcmp(preprocessor_invocation, 
			       prag->expr->value.string)) {
			fprintf(stderr, 
	    "Warning: %s's preprocessor command %s is not consistent with %s\n",
				func->name, prag->expr->value.string,
				preprocessor_invocation);
		    }
		}
	    }
	}

#if 0
	/* BCC/INTEL - dump function calls with structure returns 6/24/97*/
	if (func->type->type & TY_STRUCT && func->type->dcltr->next == NULL) {
	    fprintf(stdout, "Function %s returns a structure\n",
		    func->name);
	}

	/* BCC/INTEL - dump function calls with structure arguments 6/4/97*/
	{
	    VarList param;

	    param = func->param;
	    while (param) {
		if (IsStructureType(param->var->type)) {
		    fprintf(stdout,
			    "Function %s has structure arguments\n",
			    func->name);
		}
		param = param->next;
	    }
	}
#endif

	/* BCC - skip some time consuming steps for Pinline - 11/15/95 */
	if (do_inline == 1) {
	    Gen_PCODE_Func(Fout, func, NO_PRETTY_PRINT_PCODE);
	    return;
	}
	/* BCC - end of change */

	/* BCC - annotate function calls - 12/17/95 */
	if (do_annotate_function == 1) {
	    (*PreprocessFunction)(func, 0);	/* in Pinline/annotate.c */
	    Gen_PCODE_Func(Fout, func, NO_PRETTY_PRINT_PCODE);
	    return;
	}
	/* BCC - end of change */

	/* BCC - add pragmas to if-{else-if}* statements - 1/2/97 */
        if (!FindFunctionPragma(func, "\"ifelse\"")) {
            Expr expr;

	    expr = NewIntExpr(1);
	    AddFunctionPragma(func, "\"ifelse\"", expr);
            RemoveExpr(expr);
	    P_FindNestedIf(func->stmt);
        }

	/* BCC - flattening - 11/26/95 */
	/* BCC - if we are in fast_mode, don't flatten or it will core dump */
	if (do_flatten == 1 && fast_mode == 0) {
	    P_Flatten(func);
	}
	/* BCC - end of change */

	dep_pragmas_generated = FALSE;

	num_func += 1;
	if (debug_yes | verbose_yes) {
	    fprintf(Flog, ".. fn begin (%s)\n", func->name);
	    Find_Expandable_Call_Stmts(func->stmt);
	}

        if (fast_mode == 0) {
	    CF_Build_CFG_Function(func); /* build control flow graph (GEH) */

	    /* only transform certain functions according to Pcode parameters */
	    if (trans_named_funcs_only) {
		transform_func = FALSE;
		for (i=0; i<func_trans_count; i++) {
		    if (!strcmp(func->name, funcs_to_trans[i])) 
			transform_func = TRUE; 
		}
	    }
	}

	/* C4: output */

	  switch (output_form) {
	    case OUTPUT_HCODE:
		CF_Build_Loop_Summ_Function(func);
		Gen_HCODE_Func(Fout, func);
		/* TLJ - added 1/12/95 */
		if (do_merge_profiling)
		{
		    Create_Dep_ExprPragmas(func);
		    Gen_PCODE_Func(Fout2, func, NO_PRETTY_PRINT_PCODE);
		}
		break;
	    case OUTPUT_PCODE:
		if (do_merge_profiling)
		{
		    Pannotate_Func(func);
		}

		/* LCW - call pseudo_gen_hcode to go through the places
		 * where the probes are inserted and generate the profile
		 * information - 10/20/95
		 */
		if (DO_ANNOTATE_PCODE || 
		    DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) {
		   Gen_HCODE_Func(Fnull, func);
		}
		   
		Gen_PCODE_Func(Fout, func, NO_PRETTY_PRINT_PCODE);
		break;
	    case OUTPUT_NM: {	/* BCC - generate "nm -g" information 10/7/96 */
		fprintf(Fout, "         T %s\n", func->name);
		break;
	    }
	    case OUTPUT_NONE:
	        break;
	    default:
		break;
	  }

     if (do_flatten == 1 && fast_mode == 0) 
	 Clear_Useless_Var_Table();

	if (debug_yes | verbose_yes)
	    fprintf(Flog, ".. fn end (%s)\n", func->name);
}
/*-------------------------------------------------------------*/
/*
 *	This function is automatically called after
 *	all inputs have been processed.
 */
PostProcess() {
    if (verbose_yes) {
	fprintf(Flog, "> total struct = %d\n", num_struct);
	fprintf(Flog, "> total union = %d\n", num_union);
	fprintf(Flog, "> total enum = %d\n", num_enum);
	fprintf(Flog, "> total gvar = %d\n", num_gvar);
	fprintf(Flog, "> total func = %d\n", num_func);
	fprintf(Flog, "> total expandable_func_call = %d\n",
			num_expandable_func);
	fprintf(Flog, "> total func_call = %d\n", num_total_func_call);
    }
    fflush(Fout);
    fflush(Flog);

    if (OPEN_STAT_PCODE) {
	fprintf(Fstpcode, "struct= %d\n", num_struct);
	fprintf(Fstpcode, "union= %d\n", num_union);
	fprintf(Fstpcode, "enum= %d\n", num_enum);
	fprintf(Fstpcode, "gvar= %d\n", num_gvar);
	fprintf(Fstpcode, "func= %d\n", num_func);
	fflush(Fstpcode);
	fclose(Fstpcode);
    }
    
    /* TLJ - added 1/16/95 */
    if (do_merge_profiling)
    {
	Pannotate_Finish();
    }

    /* TLJ 2/27/96 - moved next 2 paragraphs here from P_gen_code (was main2) */

    /* LCW - write the next probe number to the file and generate the c code
     * of dumping probe - 10/12/95 */
    if (DO_INSERT_PROBE || DO_ANNOTATE_PCODE) {
       Fprvprobe = fopen("impact_probe.tmp", "w");
       fprintf(Fprvprobe, "%d", next_probe);
       fclose(Fprvprobe);
       /*
       if (DO_INSERT_PROBE)
          gen_dump_probe_code(next_probe);
       */
    }

    /* LCW - write the next loop id to the file - 3/24/99 */
    if (DO_INSERT_LOOP_TRIP_COUNT_PROBE || 
	DO_ANNOTATE_PCODE_WITH_LOOP_TRIP_COUNT) {
       Fprvloopid = fopen("impact_loop_id.tmp", "w");
       fprintf(Fprvloopid, "%d", next_loop_id);
       fclose(Fprvloopid);
    }

    /* LCW - generate the initialization C code - 3/24/99 */
    if (DO_INSERT_PROBE || DO_INSERT_LOOP_TRIP_COUNT_PROBE)
       PP_gen_init_c_code(next_probe, next_loop_id);

    /* LCW - close profile data file - 10/22/95 */
    if (DO_ANNOTATE_PCODE)
       fclose(Fprofile);

    /* LCW - close probe status file and c code file of dumping probe 
     * - 10/12/95 
     */
    if (DO_INSERT_PROBE) {
       fclose(Fallprobe);
       fclose(Fdump_probe_code);
    }
}

/* BCC - added here to process INCLUDE directive - 5/26/95 */
ProcessInclude(file_name)
char *file_name;
{
    	switch (output_form) {
	    case OUTPUT_HCODE:
		Gen_HCODE_Include(Fout, file_name);/* ( INCLUDE "xxxxxx.hc" ) */
		if (do_merge_profiling) {
		    Gen_PCODE_Include(Fout2, file_name);
		}
		break;
	    case OUTPUT_PCODE:  /* ( INCLUDE "xxxxxx.pc" ) */
		Gen_PCODE_Include(Fout, file_name);
		break;
	    case OUTPUT_NM: 	/* BCC - generate "nm -g" information 10/7/96 */
	    case OUTPUT_NONE:
		/* BCC - still need to parse include files - 4/28/96 */
		ReadIncludeFile(file_name);
	        break;
	    default:
		break;
	}
}

