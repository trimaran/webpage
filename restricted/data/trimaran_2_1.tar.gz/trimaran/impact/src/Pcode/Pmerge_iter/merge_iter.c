/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.20  */
/* IMPACT Trimaran Release (www.trimaran.org)                  May 17, 1999  */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *      File:   merge_iter.c (merge Pcode loop iteratation profiles)
 *      Author: John C. Gyllenhaal, Wen-mei Hwu
 *      Creation Date:  April. 1999
\*****************************************************************************/

#include <stdio.h>
#include <library/dynamic_symbol.h>
#include <library/heap.h>

int expected_loop_count = 0;
INT_Symbol_Table **loop = NULL;

void print_usage()
{
    fprintf (stderr, "Usage: Pmerge_iter profile_iter.*\n");
    fprintf (stderr, "       Generates profile.iter\n");
}


/* Read in entry loop iteration profile file -JCG 4/99 */
void read_loop_iter_profile (char *input_name, int input_id, int num_inputs)
{
    FILE *in;
    INT_Symbol *iter_symbol;
    int loop_count, input_count;
    int size, weight_array_size;
    int loop_id, entry_id;
    int file_loop_id, entry_count;
    int iter;
    int ch, i;
    double *weight_array;

    if ((in = fopen (input_name, "r")) == NULL)
    {
	L_punt("read_loop_iter_profile: could not open '%s' for reading!",
	       input_name);
    }

    /* Get loop and input count */
    if (fscanf (in, "%d %d\n\n", &loop_count, &input_count) != 2)
    {
	L_punt("read_loop_iter_profile: error reading loop and input count "
	       "in '%s'!", input_name);
    }

    /* Initialize things if processing first input */
    if (loop == NULL)
    {
	/* Malloc the array to hold all the loop iteration info */
	loop = (INT_Symbol_Table **) malloc(loop_count * 
					    sizeof(INT_Symbol_Table *));
	if (loop == NULL)
	    L_punt ("read_loop_iter_profile: Out of memory");

	/* Initialize all loop pointers to NULL */
	for (loop_id = 0; loop_id < loop_count; loop_id++)
	{
	    loop[loop_id] = NULL;
	}

	/* Record expected loop count */
	expected_loop_count = loop_count;
    }

    /* Sanity check, make sure have expected loop count */
    if (expected_loop_count != loop_count)
    {
	L_punt ("Error: '%s' has %i loops, expect %i!",
		input_name, loop_count, expected_loop_count);
    }

    /* Sanity check, input count better be 1 */
    if (input_count != 1)
    {
	L_punt("read_loop_iter_profile: invalid input count (%i)!", 
	       input_count);
    }

    /* Calculate the size of each weight array (out of loop) */
    weight_array_size = num_inputs * sizeof (double);

    /* Read in each loop's info */
    for (loop_id = 0; loop_id < loop_count; loop_id++)
    {
	if (fscanf (in, "%d %d\n", &file_loop_id, &entry_count) != 2)
	{
	    L_punt("read_loop_iter_profile: error reading loop id and "
		 "entry count in '%s'!", input_name);
	}
	
	/* Sanity check, loop id's better match! */
	if (loop_id != file_loop_id)
	{
	    fprintf (stderr, "Expected loop id %i not %i!\n", loop_id, 
		     file_loop_id);
	    L_punt("read_loop_iter_profile: loop id mismatch in '%s'",
		   input_name);
	}
	
	/* Sanity check, better be non-negative number */
	if (entry_count < 0)
	{
	    L_punt("read_loop_iter_profile: invalid negative entry count");
	}

	/* Create symbol table for loop (if necessary), unless no entries */
	if ((loop[loop_id] == NULL) && (entry_count != 0))
	{
	    loop[loop_id] = INT_new_symbol_table ("loop", 0);
	}

	/* Read in each loop entry */
	for (entry_id = 0; entry_id < entry_count; entry_id++)
	{
	    /* Read in the iter count */
	    if (fscanf (in, "%d", &iter) != 1)
		L_punt ("read_loop_iter_profile: Error reading iter count!");

	    /* Get iter entry, add if necessary */
	    if ((iter_symbol = INT_find_symbol (loop[loop_id], iter)) == NULL)
	    {
		/* Malloc weight array */
		if ((weight_array = (double *)malloc(weight_array_size))==NULL)
		    L_punt ("read_loop_iter_profile: Out of memory");

		/* Initialize weight array */
		for (i = 0; i < num_inputs; i++)
		    weight_array[i] = 0.0;

		INT_add_symbol (loop[loop_id], iter, (void *) weight_array);
	    }
	    /* Otherwise, get weight array from symbol */
	    else
	    {
		weight_array = (double *)iter_symbol->data;
	    }

	    /* Read in input weight */
	    if (fscanf (in, "%lf", &weight_array[input_id]) != 1)
		L_punt ("read_loop_iter_profile: Error reading weight!");
	}
    }

    /* Sanity check, better only have whitespace left in file */
    while ((ch = getc (in)) != EOF)
    {
	if (!isspace (ch))
	{
	    fprintf (stderr, "Unexpected char '%c' at expected EOF!\n", ch);
	    L_punt ("read_loop_iter_profile: EOF expected!");
	}
    }
    
    fclose (in);
}

/* Write out combined loop iteration profile to output_name */
void write_loop_iter_profile (char *output_name, int num_inputs)
{
    FILE *out;
    INT_Symbol *iter_symbol;
    int loop_id, input_id, iter;
    double *weight_array;
    Heap *iter_heap;
    
    if ((out = fopen(output_name, "w")) == NULL)
    {
	L_punt ("Error, cannot open profile output file: %s\n", output_name);
    }

    /* Print out the number of loops and number of inputs profiled 
     */
    fprintf (out, "%i %i\n", expected_loop_count, num_inputs);

    /* Go through each loop and print out iterations for each */
    for (loop_id=0; loop_id < expected_loop_count; loop_id++)
    {
	/* Print out if exists */
	if (loop[loop_id] != NULL)
	{
	    /* Print out loop id and number of entries for this loop */
	    fprintf (out, "\n%i %i\n", loop_id, loop[loop_id]->symbol_count);

	    /* Create heap in order to sort iterations before printing them
	     * out.
	     */
	    iter_heap = Heap_Create (HEAP_MIN);

	    /* Put all the iteration data in a heap so we can sort the
	     * iterations before we print them out
	     */
	    for (iter_symbol = loop[loop_id]->head_symbol; iter_symbol != NULL;
		 iter_symbol = iter_symbol->next_symbol)
	    {
		/* Insert weight array (data) and sort by iterations (value)*/
		Heap_Insert (iter_heap, iter_symbol->data, 
			     (double)iter_symbol->value);
	    }

	    /* Print out in iteration order */
	    while ((weight_array = Heap_Top(iter_heap)) != NULL)
	    {
		/* Get iteration count */
		iter = (int)*(Heap_TopWeight(iter_heap));

		/* Print out iteration count */
		fprintf (out, "  %i", iter);

		/* Print out each iteration's data */
		for (input_id = 0; input_id < num_inputs; input_id++)
		{
		    fprintf (out, " %.0f", weight_array[input_id]);
		}

		/* Finish this line */
		fprintf (out, "\n");

		/* Pop data off the heap */
		Heap_ExtractTop (iter_heap);
	    }
	    
	    /* Free heap */
	    iter_heap = Heap_Dispose (iter_heap, NULL);
	}

	/* Otherwise, print out loop id and no entries for this loop */
	else
	{
	    fprintf (out, "\n%i %i\n", loop_id, 0);
	}
    }

    /* Close the iter profile file */
    fclose (out);

}

/* Get and process the command-line arguments */
int main (int argc, char **argv)
{
    FILE *in;
    char *output_file_name;
    char **input_name;
    int num_inputs, input_id;
    
    /* Require at least one input file*/
    if (argc < 2)
    {
	print_usage ();
	exit (1);
    }

    /* Use fixed output name for now */
    output_file_name = "profile.iter";

    /* Calculate number of inputs */
    num_inputs = argc - 1;

    /* Point to start of input names */
    input_name = &argv[1];

    /* Read in all input files */
    for (input_id = 0; input_id < num_inputs; input_id++)
    {
	read_loop_iter_profile (input_name[input_id], input_id, num_inputs);
    }
    
    /* Write out the combined input data */
    write_loop_iter_profile (output_file_name, num_inputs);

    return (0);
}

