/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.31  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 21, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_gen_c.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>


#undef ABORT_ON_PUNT

static int do_output = 1;
static int H_ansi_c_output = 0;		/* BCC - ANSI C or K&R C - 1/29/96 */
#define OUTPUT		do_output
#define DO_OUTPUT(x)	(do_output = x)
#define BLOCK_OUTPUT	(do_output == 0)

static FILE *F = NULL;
static int fn_profile_id;	/* PROFILE */
static GenParamDataDcl();
static GenLocalDataDcl();
static GenCDcltr();		/* BCC - forward - 1/22/96 */

VarDcl V;

/*	Generate C as the intermediate language.
 *	The code generated is very obscured and is definitely
 *	not suitable for human comprehension, but that is the
 *	idea, right!
 */

/* EXPORT FUNCTION :
 *	Gen_C_Include(F, file) char *file;
 *	Gen_C_LinePos(F, n, file) int n; char *file;
 *	Gen_C_Struct(F, st) Struct st;
 *	Gen_C_Union(F, un) Union un;
 *	Gen_C_Enum(F, en) Enum en;
 *	Gen_C_Var(F, var) VarDcl var;
 *	Gen_C_Func(F, fn) FuncDcl fn;
 */
/*========================================================================*/
/*
 *	profile interface.
 */
#define FN_CALL		"_profile_call"		/* (call_site_id) */
#define FN_ENTER	"_profile_fn_enter"	/* (fn_id) */
#define FN_EXIT		"_profile_fn_return"	/* (fn_id) */
#define FN_SETJMP	"_profile_setjmp"	/* (env) */
#define FN_LONGJMP	"_profile_longjmp"	/* (env) */
#define BB_VISIT	"_profile_bb"		/* (bb_id) */
#define SW_COND		"_profile_switch"	/* (case_id) */

/*========================================================================*/

static char *LabelPrefix = "LL_";

/*========================================================================*/
static Punt(mesg)
char *mesg;
{
	fprintf(stderr, "# gen_c: %s\n", mesg);
#ifdef ABORT_ON_PUNT
	abort();
#endif
	exit(-1);
}
/*========================================================================*/
/* print XXX and ignore "..." */
static PrintUnquote(str)
char *str;
{
	int i, len;
	len = strlen(str) - 1;
	if ((str[0]!='\"') || (str[len]!='\"')) {
	    fprintf(stderr, "# %s\n", str);
	    Punt("PrintUnquote: not a string");
	}
	for (i=1; i<len; i++)
	    fprintf(F, "%c", str[i]);
}
/*========================================================================*/
/* Convert "P_<name>___<number>" to "<name>" if <name> contains the word
   "builtin" - GEH 4/26/95 */
static void StripRenameFromBuiltins(char *name, char *newname)
{
	char *ptr;
        if (C_strstr(name, "builtin") && !strncmp(name, "P_", 2) &&
	    (ptr = strrchr(name, '_')) != 0 && ptr >= name + 5 &&
	    ptr[-1] == '_' && ptr[-2] == '_' && 
	    strspn(ptr+1, "0123456789") == strlen(ptr+1)) {
	     
	    strncpy(newname, name+2, ptr - name - 4);
	    newname[ptr - name - 4] = '\0';
	}
	else strcpy(newname, name);
	/* BCC - also convert '$' into '_' - 7/26/96 */
	ptr = newname;
	while (*ptr) {
	    if (*ptr == '$') *ptr = '_';
	    ptr++;
	}
}
/*========================================================================*/
/* print type information. */
GenCType(type, option)
Type type;
int option;	/* 0 : print no class, 1 : print class */
{
	int t;
	if (type==0) return;
	t = type->type;
	/* storage class */
	if (option!=0) {
		/* class */
#if 0
		if (t & TY_REGISTER) fprintf(F, " register");
#endif
		if (t & TY_STATIC) fprintf(F, " static");
		if (t & TY_EXTERN) fprintf(F, " extern");
		/* do nothing for TY_INTERNAL, TY_AUTO, TY_PARAMETER,
		 * and TY_GLOBAL.
		 */
		/* qualifier */
/* 
 * BCC - commented out because the const may bug the cc compiler - 1/18/96 
 * e.g. 
 *	source.c contains 
 *		const int i = 5;
 *		and this is the only place where i can be assigned a value to.
 *	source_rev.c will have
 *		const int i;
 *		i = 5;	-> illegal 
 * 	So just don't generate const in the reverse generated C code.
 */
#if 0
		if (t & TY_CONST) fprintf(F, " const");
#endif
		if (t & TY_VOLATILE) fprintf(F, " volatile");
		if (t & TY_NOALIAS) fprintf(F, " noalias");
	}
	/* type */ 
	if (t & TY_SIGNED) fprintf(F, " signed");
	if (t & TY_UNSIGNED) fprintf(F, " unsigned");
	if (t & TY_VOID) fprintf(F, " void");
	if (t & TY_SHORT) fprintf(F, " short");
	if (t & TY_LONG) fprintf(F, " long");
	if (t & TY_CHAR) fprintf(F, " char");
	if (t & TY_INT) fprintf(F, " int");
	if (t & TY_FLOAT) fprintf(F, " float");
	if (t & TY_DOUBLE) fprintf(F, " double");
	if (t & TY_VARARG) fprintf(F, " ...");	/* BCC - added - 1/24/96 */
	if (t & TY_STRUCT) fprintf(F, " struct %s", type->struct_name);
	if (t & TY_UNION) fprintf(F, " union %s", type->struct_name);
	if (t & TY_ENUM) fprintf(F, " enum %s", type->struct_name);
	fprintf(F, " ");
}
/* print dcltr, embed symbol_name in proper place. */
static ipnDcltr(dcltr, symbol_name, level, star_star, param, has_param, 
		func_qual)
Dcltr dcltr;
char *symbol_name;
int level, star_star;
VarList param;
int has_param;
int func_qual; /* qualifier from calling func dcltr */
{
    char buffer[256];

	if (dcltr==0) {
		VarList ptr;
		if (symbol_name==0)
			return;
		if (func_qual & DQ_CDECL) fprintf(F, "__cdecl ");
		if (func_qual & DQ_STDCALL) fprintf(F, "__stdcall ");
		if (func_qual & DQ_FASTCALL) fprintf(F, "__fastcall ");
		/*GEH - added code to strip renaming from builtin vars 4/26/95*/
		StripRenameFromBuiltins(symbol_name, buffer);

		fprintf(F, "%s", buffer);
		/* print parameter list */
		if (has_param) {
			fprintf(F, " (");
			ptr = param;
			while (ptr!=0) {
			    /* 
			     * BCC - 1/24/96 
			     *	 Now we want to be able to print both
			     *	 	foo1(int i, int j) 
			     *	 and 
			     *	 	foo1(i, j) 
			     *		int i;
			     *		int j;
			     *	 or we won't have place to put "..."
			     */

		            /* K&R C */	
			    if (!H_ansi_c_output) {
				/* GEH - added code to strip renaming from 
					 builtin vars 4/26/95 */
				StripRenameFromBuiltins(ptr->name, buffer);
				if (!strcmp(buffer, "...")) 
				    Punt("'...' encounterd. Internal error");
				fprintf(F, "%s", buffer);
			    }
			    /* ANSI C */
			    else {
				StripRenameFromBuiltins(ptr->name, buffer);
				if (!strcmp(buffer, "..."))
				    fprintf(F, "...");
				else {
				    GenCType(ptr->var->type, 1);
				    GenCDcltr(ptr->var->type->dcltr, buffer);
				}
			    }
			    ptr = ptr->next;
			    if (ptr!=0)
				fprintf(F, ", ");
			}
			fprintf(F, ")");
		}
		return;
	}
	if (dcltr->method==D_ARRY) {		/* X[] */
		ipnDcltr(dcltr->next, symbol_name, level+1, 0, param, has_param,
			 0);
		fprintf(F, "[");
		if (dcltr->index!=0)
			GenCExpr(dcltr->index, 0);
		fprintf(F, "]");
	} else
	if (dcltr->method==D_PTR) {		/* *X */
		if ((level>0) && !star_star)	fprintf(F, "(");
		if (func_qual & DQ_CDECL) fprintf(F, "__cdecl ");
		if (func_qual & DQ_STDCALL) fprintf(F, "__stdcall ");
		if (func_qual & DQ_FASTCALL) fprintf(F, "__fastcall ");
		fprintf(F, "*");
/* BCC - don't generate volatile in the reverse translated C - 2/11/96 */
#if 0
		if (dcltr->qualifier & DQ_CONST) fprintf(F, " const ");
#endif
		if (dcltr->qualifier & DQ_VOLATILE) fprintf(F, " volatile ");
		ipnDcltr(dcltr->next, symbol_name, level+1, 1, param, has_param,
			 0);
		if ((level>0) && !star_star)	fprintf(F, ")");
	} else
	if (dcltr->method==D_FUNC) {		/* () */
		ipnDcltr(dcltr->next, symbol_name, level+1, 0, param, has_param,			dcltr->qualifier);/* GEH - pass qual. to next level */
		/* 
		 * BCC - 1/29/96
		 * Find out if there is "..." to determine using ANSI C or KR C 
		 */
		 {
			Param param = dcltr->param;

			H_ansi_c_output = 0;
			while (param) {
				if (param->type->type & TY_VARARG) {
					H_ansi_c_output = 1;
					break;
				}
				param = param->next;
			}
		}

		if (!H_ansi_c_output)
		    	fprintf(F, "()");
		else {
			fprintf(F, "(");
			if (dcltr->param) {
				Param param = dcltr->param;
				int first = 1;

				while (param) {
					if (first == 0) fprintf(F, ",");
					first = 0; 

					GenCType(param->type, 0);
					GenCDcltr(param->type->dcltr, 0);

					param = param->next;
				}
			}
			fprintf(F, ")");
		}
	} else {
		Punt("ipnDcltr : illegal dcltr");
	}
}
static GenCDcltr(dcltr, symbol_name)
Dcltr dcltr;
char *symbol_name;
{
	dcltr = CopyDcltr(dcltr);
	dcltr = ReverseDcltr(dcltr);
	ipnDcltr(dcltr, symbol_name, 0, 0, 0, 0, 0);
	RemoveDcltr(dcltr);
}
/*
 *	need to handle special fn type
 *	e.g.
 *	int (*fn(a,b,c))[20][20]
 */
static GenFnCDcltr(dcltr, fn_name, param)
Dcltr dcltr;
char *fn_name;
VarList param;
{
	dcltr = CopyDcltr(dcltr);
	dcltr = ReverseDcltr(dcltr);
	ipnDcltr(dcltr, fn_name, 0, 0, param, 1, 0);
	RemoveDcltr(dcltr);
}
/*========================================================================*/
static GenOpcode(opcode)
int opcode;
{
	switch (opcode) {
	case OP_quest :		fprintf(F, " ? ");	break;
	case OP_disj :		fprintf(F, " || ");	break;
	case OP_conj :		fprintf(F, " && ");	break;
	case OP_comma :		fprintf(F, " , ");	break;
	case OP_assign :	fprintf(F, " = ");	break;
	case OP_or :		fprintf(F, " | ");	break;
	case OP_xor :		fprintf(F, " ^ ");	break;
	case OP_and :		fprintf(F, " & ");	break;
	case OP_eq :		fprintf(F, " == ");	break;
	case OP_ne :		fprintf(F, " != ");	break;
	case OP_lt :		fprintf(F, " < ");	break;
	case OP_le :		fprintf(F, " <= ");	break;
	case OP_ge :		fprintf(F, " >= ");	break;
	case OP_gt :		fprintf(F, " > ");	break;
	case OP_rshft :		fprintf(F, " >> ");	break;
	case OP_lshft :		fprintf(F, " << ");	break;
	case OP_add :		fprintf(F, " + ");	break;
	case OP_sub :		fprintf(F, " - ");	break;
	case OP_mul :		fprintf(F, " * ");	break;
	case OP_div :		fprintf(F, " / ");	break;
	case OP_mod :		fprintf(F, " %% ");	break;
	case OP_neg :		fprintf(F, " - ");	break;
	case OP_not :		fprintf(F, " ! ");	break;
	case OP_inv :		fprintf(F, " ~ ");	break;
	case OP_abs :		fprintf(F, " @ ");	break;
	case OP_preinc :	fprintf(F, " ++");	break;
	case OP_predec :	fprintf(F, " --");	break;
	case OP_postinc :	fprintf(F, "++ ");	break;
	case OP_postdec :	fprintf(F, "-- ");	break;
	case OP_Aadd :		fprintf(F, " += ");	break;
	case OP_Asub :		fprintf(F, " -= ");	break;
	case OP_Amul :		fprintf(F, " *= ");	break;
	case OP_Adiv :		fprintf(F, " /= ");	break;
	case OP_Amod :		fprintf(F, " %%= ");	break;
	case OP_Arshft :	fprintf(F, " >>= ");	break;
	case OP_Alshft :	fprintf(F, " <<= ");	break;
	case OP_Aand :		fprintf(F, " &= ");	break;
	case OP_Aor :		fprintf(F, " |= ");	break;
	case OP_Axor :		fprintf(F, " ^= ");	break;
	case OP_indr :		fprintf(F, " * ");	break;
	case OP_addr :		fprintf(F, " & ");	break;
	case OP_index :		Punt("no opcode for OP_index");
	case OP_call :		Punt("no opcode for OP_call");
	case OP_dot :		fprintf(F, ".");	break;
	case OP_arrow :		fprintf(F, "->");	break;
	case OP_var :	
	case OP_enum :
	case OP_signed :
	case OP_unsigned :
	case OP_float :
	/* BCC - added - 8/5/96 */
	case OP_double :
	case OP_char :
	case OP_string :
	case OP_cast :	
	case OP_expr_size :
	case OP_type_size :	
	case OP_return :
	case OP_goto :
	case OP_if :
	case OP_switch :
	/* LCW - 10/24/96 */
	case OP_nulldefine :
			Punt("no opcode for this instruction");
			break;
	default :
		Punt("GenOpcode : illegal opcode");
	}
}
/* generate expression. */
GenCExpr(expr, level)
Expr expr;
int level;
{
	int opcode, n;
	Expr arg;
	char buffer[256];
	if (expr==0) Punt("GenCExpr : nil expr");
	switch (opcode=expr->opcode) {
	case OP_var :
		/*GEH - added code to strip renaming from builtin vars 4/26/95*/
		StripRenameFromBuiltins(expr->value.var_name, buffer);
		fprintf(F, "%s", buffer);
		break;
	case OP_enum :
		/* remove the surrounding "..." */
		PrintUnquote(expr->value.string);	break;
	case OP_signed :
		fprintf(F, "%d", expr->value.scalar);	break;
	case OP_unsigned :
		/* BCC - 1/30/96
		 * We have to support type information. Or there is no way to
		 * determine the type of the constant in the later phase.
		 */
		fprintf(F, "(unsigned) ");
		fprintf(F, "%u", expr->value.uscalar);	break;
	case OP_float :
		/* BCC - use 8 digits for float - 8/22/96 */
	        /* ITI(JCG) - changed to cast instead of appending 'f' 2/99 */
		fprintf(F, "(float)%1.8e", (float)expr->value.real);	break;
	/* BCC - added - 8/5/96 */
	case OP_double :
/*** SAM 9-24-91
		fprintf(F, "%e", expr->value.real);	break;
***/
/* GEH - added one more significant digit to prevent rounding error 4-27-95 */
		fprintf(F, "%1.16e", expr->value.real);	break;
	case OP_char :
		fprintf(F, "%s", expr->value.string);	break;
	case OP_string :
		fprintf(F, "%s", expr->value.string);	break;
	case OP_cast :
		if (level) fprintf(F, "(");
		fprintf(F, "(");
		GenCType(expr->type, 0);
		GenCDcltr(expr->type->dcltr, 0);
		fprintf(F, ")");
		GenCExpr(ExprOperand(1, expr), level+1);
		if (level) fprintf(F, ")");
		break;
	case OP_type_size :
		if (level) fprintf(F, "(");
		fprintf(F, " sizeof(");
		GenCType(expr->value.type, 0);
		GenCDcltr(expr->value.type->dcltr, 0);
		fprintf(F, ")");
		if (level) fprintf(F, ")");
		break;
	case OP_expr_size :
		if (level) fprintf(F, "(");
		arg = ExprOperand(1, expr);
		if (arg==0) Punt("GenCExpr : sizeof missing argument");
		fprintf(F, " sizeof ");
		GenCExpr(arg, 0);
		fprintf(F, " ");
		if (level) fprintf(F, ")");
		break;
	case OP_return :
	case OP_goto :
	case OP_if :
	case OP_switch :
		Punt("GenCExpr : premature return/jump/cond_br/switch");
		break;
	case OP_quest :
		fprintf(F, "(");
		GenCExpr(ExprOperand(1, expr), level+1);
		fprintf(F, " ? ");
		GenCExpr(ExprOperand(2, expr), level+1);
		fprintf(F, " : ");
		GenCExpr(ExprOperand(3, expr), level+1);
		fprintf(F, ")");
		break;
	case OP_comma :
		fprintf(F, "(");
		GenCExpr(ExprOperand(1, expr), level+1);
		fprintf(F, ",");
		GenCExpr(ExprOperand(2, expr), level+1);
		fprintf(F, ")");
		break;
	case OP_call : {
		Expr op1, op2;
		int is_setjmp = 0, is_longjmp = 0;	/* PROFILE */
		int no_par = 0;
/* 
 * BCC - bug fix for an unusual case : __builtin_va_arg_incr" - 1/24/96
 *	 In acc, vararg list is handled by calling __builtin_va_arg_incr, but
 *	 you can not put any "(" or ")" around it, say, __builtin_va_arg_incr()
 *	 is legal but (__builtin_va_arg_incr()) is illegal.
 */
		if ((expr->operands->opcode == OP_var) && 
		    !strcmp(expr->operands->value.var_name, 
			    "__builtin_va_arg_incr"))
		    no_par = 1;

		/*
		 * If (H_do_insert_profile_probes)
		 * setjmp(env,..) -> setjmp(FN_SETJMP(env), ..)
		 * longjmp(env,..) -> longjmp(FN_LONGJMP(env), ...)
		 * f(...) -> (FN_CALL(call_site), f(...))
		 */
		/* BCC - added "!no_par" conditional test - 1/24/96 */
		if (level && !no_par) fprintf(F, "(");	
		if (H_do_insert_profile_probes) {	/* PROFILE */
		    int call_site;
		    Pragma pr;
		    pr = FindExprPragma(expr, "\"cs");
		    if (pr==0) Punt("GenCExpr: call site pragma missing");
		    sscanf(pr->specifier, "\"cs.%d", &call_site);
		    fprintf(F, "(%s(%d), ", FN_CALL, call_site);
		}
		op1 = ExprOperand(1, expr);
		GenCExpr(op1, level+1);
		if (H_do_insert_profile_probes &&
			(op1->opcode==OP_var)) {	/* PROFILE */
		    char *fn_name;
		    fn_name = op1->value.var_name;
		    if (! strcmp(fn_name, "setjmp")) {
			is_setjmp = 1;
		    } else
		    if (! strcmp(fn_name, "_setjmp")) {
			is_setjmp = 1;
		    } else
			/* for linux profiling - JCG 7/18/95 */
		    if (! strcmp(fn_name, "__setjmp")) { 
			is_setjmp = 1;
		    } else
		    if (! strcmp(fn_name, "sigsetjmp")) {
			is_setjmp = 1;
		    } else
		    if (! strcmp(fn_name, "longjmp")) {
			is_longjmp = 1;
		    } else
		    if (! strcmp(fn_name, "_longjmp")) {
			is_longjmp = 1;
		    } else
		    if (! strcmp(fn_name, "siglongjmp")) {
			is_longjmp = 1;
		    }
		}
		fprintf(F, "(");	/* output formal parameters */
		op2 = ExprOperand(2, expr);
		if (op2!=0) {
		    if (is_setjmp) {	/* PROFILE */
			fprintf(F, "(int *) %s(", FN_SETJMP);
		    } else
		    if (is_longjmp) {	/* PROFILE */
			fprintf(F, "(int *) %s(", FN_LONGJMP);
		    }
		    GenCExpr(op2, level+1);
		    if (is_setjmp || is_longjmp) {	/* PROFILE */
			fprintf(F, ")");
		    }
		}
		for (n=3; (arg=ExprOperand(n, expr)) != 0; n++) {
			fprintf(F, ",");
			GenCExpr(arg, level+1);
		}
		fprintf(F, ")");
		if (H_do_insert_profile_probes) {	/* PROFILE */
		    fprintf(F, ")");
		}
		/* BCC - added "!no_par" conditional test - 1/24/96 */
		if (level && !no_par) fprintf(F, ")");
		break;
	}
	case OP_index :
		if (level) fprintf(F, "(");
		GenCExpr(ExprOperand(1, expr), level+1);
		fprintf(F, "[");
		GenCExpr(ExprOperand(2, expr), level+1);
		fprintf(F, "]");
		if (level) fprintf(F, ")");
		break;
	/* binary */
	case OP_disj :
	case OP_conj :
		if (level) fprintf(F, "(");
		GenCExpr(ExprOperand(1, expr), level+1);
		GenOpcode(opcode);
		GenCExpr(ExprOperand(2, expr), level+1);
		if (level) fprintf(F, ")");
		break;
	case OP_assign :
                if (FindExprPragma(expr->operands->sibling, 
                                   "\"use_ret_as_parm0\"")) {
                    Expr op_l, op_call, op_callee, op_p1, op_p2;
                    op_l = expr->operands;
                    op_call = expr->operands->sibling;
                    op_callee = op_call->operands;
                    op_p1 = op_callee->sibling;
                    op_p2 = op_p1->sibling;

                    op_callee->sibling = op_l;
                    op_l->sibling = op_p2;
                    GenCExpr(op_call, level);

		    /* restore */
                    op_l->sibling = 0;
                    op_callee->sibling = op_p1;
                }
                else {
		    if (level) fprintf(F, "(");
		    GenCExpr(ExprOperand(1, expr), level+1);
		    GenOpcode(opcode);
		    GenCExpr(ExprOperand(2, expr), level+1);
		    if (level) fprintf(F, ")");
                }
		break;
	case OP_or :
	case OP_xor :
	case OP_and :
	case OP_eq :
	case OP_ne :
	case OP_lt :
	case OP_le :
	case OP_ge :
	case OP_gt :
	case OP_rshft :
	case OP_lshft :
	case OP_add :
	case OP_sub :
	case OP_mul :
	case OP_div :
	case OP_mod :
	case OP_Aadd :
	case OP_Asub :
	case OP_Amul :
	case OP_Adiv :
	case OP_Amod :
	case OP_Arshft :
	case OP_Alshft :
	case OP_Aand :
	case OP_Aor :
	case OP_Axor :
		if (level) fprintf(F, "(");
		GenCExpr(ExprOperand(1, expr), level+1);
		GenOpcode(opcode);
		GenCExpr(ExprOperand(2, expr), level+1);
		if (level) fprintf(F, ")");
		break;
	/* the second operand is in value.string */
	case OP_dot :
	case OP_arrow :
		if (level) fprintf(F, "(");
		GenCExpr(ExprOperand(1, expr), level+1);
		GenOpcode(opcode);
		/* remove the surrounding "..." */
		PrintUnquote(expr->value.string);
		if (level) fprintf(F, ")");
		break;
	/* prefix unary */
	case OP_neg :
	case OP_not :
	case OP_inv :
	case OP_abs :
	case OP_preinc :
	case OP_predec :
	case OP_indr :
	case OP_addr :
		if (level) fprintf(F, "(");
		GenOpcode(opcode);
		GenCExpr(ExprOperand(1, expr), level+1);
		if (level) fprintf(F, ")");
		break;
	/* postfix unary */
	case OP_postinc :
	case OP_postdec :
		if (level) fprintf(F, "(");
		GenCExpr(ExprOperand(1, expr), level+1);
		GenOpcode(opcode);
		if (level) fprintf(F, ")");
		break;
	case OP_sync:	/* GEH - don't generate anything for sync operation */
		break;
	/* LCW - 10/24/96 */
	case OP_nulldefine:
		break;  
	default :
		Punt("GenCExpr : illegal expression");
	}
}
/*========================================================================*/
static GenBasicBlock(bb, next_bb)
Block bb;
int next_bb;
{
	Expr expr;
	BLink link;

	/* generate a label to designate the entry point of
	 * the basic block. we will simply use the id of
	 * the basic block as the label name. in order to
	 * distinguish the label name from variable names,
	 * we prefix it with a reserved word.
	 */
	fprintf(F, "%s%d : \n", LabelPrefix, bb->id);

	/* skip over empty basic blocks. */
	if (bb->first==0)
		return;
	
	/* PROFILE */
	if (H_do_insert_profile_probes) {
	    fprintf(F, "\t%s(%d);\n", BB_VISIT, bb->id);
	}

	/* generate expressions in the basic block. */
	for (expr=bb->first; expr!=0; expr=expr->next) {
		/* skip over the last expression */
		if (expr==bb->last)
			break;
		fprintf(F, "\t");
		GenCExpr(expr, 0);
		fprintf(F, ";\n");
	}
	/* generate branch condition. */
	switch (bb->last->opcode) {
	case OP_return :
		/* generate return(expr); */
		{ Expr exp = ExprOperand(1, bb->last);
		  if (H_do_insert_profile_probes) {	/* PROFILE */
			fprintf(F, "\t%s(%d);\n", FN_EXIT, fn_profile_id);
		  }
		  if (exp!=0) {
			fprintf(F, "\treturn(");
			GenCExpr(ExprOperand(1, bb->last), 0);
			fprintf(F, ");\n");
		  } else
			fprintf(F, "\treturn;\n");
		}
		break;
	case OP_goto :
		/* goto L??; */
		link = bb->destination;
		if (link->destination!=next_bb)
			fprintf(F, "\tgoto %s%d;\n", LabelPrefix, 
				link->destination);
		break;
	case OP_if :
		/* if (cond) goto L??; else goto L??; */
		/* find true link */
		for (link=bb->destination; link!=0; link=link->next)
			if (IsTrueExpr(link->condition))
				break;
		if (link==0)
			Punt("GenBasicBlock : OP_if missing true BLink");
		fprintf(F, "\tif (");
		GenCExpr(ExprOperand(1, bb->last), 0);
		fprintf(F, ") goto %s%d;", LabelPrefix, 
				link->destination);
		/* find false link */
		for (link=bb->destination; link!=0; link=link->next)
			if (IsFalseExpr(link->condition))
				break;
		if (link==0)
			Punt("GenBasicBlock : OP_if missing false BLink");
		if (link->destination!=next_bb) {
			fprintf(F, " else goto %s%d;\n", LabelPrefix,
				link->destination);
		} else {
			fprintf(F, "\n");
		}
		break;
	case OP_switch : {
		/* switch (cond) {
		 * case cond1 : goto L??;
		 * default : goto L ??;
		 * }
		 */
		/*
		 * If H_do_insert_profile_probes
		 *	switch (cond) {
		 *	case cond1 : prof_sw_cond(1); goto L??
		 *	default : prof_sw_cond(0); goto L??
 		 *	}
		 */
		int case_id = 1;	/* always start from 1 */
		if (bb->destination==0)
			Punt("GenBasicBlock : missing BLink");
		fprintf(F, "\tswitch(");
		GenCExpr(ExprOperand(1, bb->last), 0);
		fprintf(F, ") {\n");
		/* generate switch body */
		for (link=bb->destination; link!=0; link=link->next) {
		    /* case expr : goto L??; */
		    if (link->condition==0)
			Punt("GenBasicBlock : no case condition");
		    if (IsDefaultExpr(link->condition))
			continue;
		    fprintf(F, "\tcase ");
		    GenCExpr(link->condition, 1);
		    fprintf(F, " : \n");
		    if (H_do_insert_profile_probes) {		/* PROFILE */
			int x = case_id++;
			if (x!=link->status)
			Punt("switch profile: order of case must be preserved");
			fprintf(F, "\t\t%s(%d);\n", SW_COND, x);
		    }
		    fprintf(F, "\t\tgoto %s%d;\n", 
		    	LabelPrefix, link->destination);
		}
		/* generate the default case */
		for (link=bb->destination; link!=0; link=link->next) {
		    int complete;
		    complete = 0;
		    /* there may be several conditions
		     * leading to the same destination block.
		     */
		    if (IsDefaultExpr(link->condition)) {
		    	fprintf(F, "\tdefault : \n");
		    	if (H_do_insert_profile_probes) {	/* PROFILE */
			    fprintf(F, "\t\t%s(%d);\n", SW_COND, 0);
		    	}
		    	fprintf(F, "\t\tgoto %s%d;\n", 
				LabelPrefix, link->destination);
			complete = 1;
			break;
		    }
		    if (complete) break;
		}
		/* complete the switch */
		fprintf(F, "\t}\n");
		break;
	}
	default :
		Punt("GenBasicBlock : illegal last instruction");
	}
}
/* generate the body of a function. */
static GenFunctionBody(func)
FuncDcl func;
{
	Block bb;
	if (func->blocks==0)
		Punt("GenFunctionBody : empty function body");

	if (H_do_insert_profile_probes) {	/* PROFILE */
	    fprintf(F, "  %s(%d);\n", FN_ENTER, fn_profile_id);
	}

	/* this is where the output will be drastically
	 * different from the source C file.
	 */
	for (bb=func->blocks; bb!=0; bb=bb->next) {
	    if (bb->next==0) 
		GenBasicBlock(bb, -1);
	    else
		GenBasicBlock(bb, bb->next->id);
	}
}
/* print function definition. */
static GenFunction(func)
FuncDcl func;
{
	VarList ptr;

	if (H_do_insert_profile_probes) {	/* PROFILE */
	    static stamp = 0;
	    if (stamp==0) {
		stamp = 1;
		fprintf(F, "static char impcc_sccsid[] = \"%s\";\n",
			"@(#)impcc 1.0 89/7/12 PHC");
	    }
	}
	if (func==0) Punt("GenFunction : nil input");
	if (func->type==0) Punt("GenFunction : no return type");
	if (func->name==0) Punt("GenFunction : no name");
	GenCType(func->type, 1);		/* return type */
#ifdef OLD_FN_DCLTR
	/*
	 *	this does not work for
 	 *	int (*fn(a,b,c))[20][2]
	 */
	GenCDcltr(func->type->dcltr, func->name);
	/* print parameter list */
	fprintf(F, " (");
	ptr = func->param;
	while (ptr!=0) {
		fprintf(F, "%s", ptr->name);
		ptr = ptr->next;
		if (ptr!=0)
			fprintf(F, ",");
	}
	fprintf(F, ")\n");
#else
	/* BCC - find out if there is "..." to determine using ANSI C or KR C */
	ptr = func->param;
	H_ansi_c_output = 0;
	while (ptr) {
		if (!strcmp(ptr->name, "...")) {
			H_ansi_c_output = 1;
			break;
		}
		ptr = ptr->next;
	}                                              	
	GenFnCDcltr(func->type->dcltr, func->name, func->param);
	fprintf(F, "\n");
#endif
	if (!H_ansi_c_output) {
	    /* print parameter definition */
	    for (ptr=func->param; ptr!=0; ptr=ptr->next) {
		    fprintf(F, "  ");
		    GenParamDataDcl(ptr->var);
	    }
	}

        /* BCC - gcc needs ... after parameter definitons -4/6/99 */
        if (FindFunctionPragma(func, "\"append_gcc_ellipsis\""))
           fprintf(F, "  ...\n");

	fprintf(F, "{\n");
	/* print local variable definition */
	for (ptr=func->local; ptr!=0; ptr=ptr->next) {
		fprintf(F, "  ");
		GenLocalDataDcl(ptr->var);
	}
	/* PROFILE */
	if (H_do_insert_profile_probes) {
	    fn_profile_id = func->profile.fn_id;
	    fprintf(F, "  extern void *%s(), *%s();\n", FN_SETJMP, FN_LONGJMP);
	}
	/* print function body */
	GenFunctionBody(func);
	fprintf(F, "}\n");
}
/*========================================================================*/
/* print enum type definition. */
static GenEnumDcl(E)
EnumDcl E;
{
	EnumField ptr;
	if (E==0) Punt("GenEnumDcl : nil E");
/* BCC - if E->fields != 0, then print "{" and "}" - 6/4/95 
	fprintf(F, "enum %s {", E->name); */
	fprintf(F, "enum %s", E->name);
	ptr=E->fields;
	/* BCC - print "{" */
	if (E->fields != 0) fprintf(F, " {");
	while (ptr!=0) {	/* print fields. */
		/* do not print the surrounding "..." */
		PrintUnquote(ptr->name);
		if (ptr->value!=0) {	
			fprintf(F, " = ");
			GenCExpr(ptr->value, 0);
		}
		ptr = ptr->next;
		if (ptr!=0)
			fprintf(F, ",\n");
	}

	/* BCC - print in pairs - 6/4/95 */
	if (E->fields != 0) fprintf(F, "} ;\n");
	else fprintf(F, " ;\n");

/* REH 9/8/93 - allow evaluation of the enum */
	HC_assign_enum(E);
/* HER */
}
/*========================================================================*/
/* print a struct/union field. */
static GenStructField(field)
Field field;
{
	char field_name[200];
	int i, len;
	if (field==0) return;
	if (field->name!=0) {
		len = strlen(field->name) - 1;
		for (i=1; i<len; i++)
		    field_name[i-1] = field->name[i];
		field_name[len-1] = '\0';
		GenCType(field->type, 1);
		GenCDcltr(field->type->dcltr, field_name);
	} else {
		GenCType(field->type, 1);
		GenCDcltr(field->type->dcltr, 0);
	}
	if (field->bit_field!=0) {
		fprintf(F, " : ");
		GenCExpr(field->bit_field, 0);
	}
	fprintf(F, ";\n");
}
/* print struct structure definition. */
static GenStructDcl(S)
StructDcl S;
{
        Field ptr;
        if (S==0) Punt("GenStructDcl : nil S");
        /* BCC - process struct prototypes - 6/99 */
        if (S->fields) {
            fprintf(F, "struct %s {\n", S->name);
            for (ptr=S->fields; ptr!=0; ptr=ptr->next) {
                    fprintf(F, "\t");
                    GenStructField(ptr);
            }
            fprintf(F, "} ;\n");
        }
        else {
            fprintf(F, "struct %s;\n", S->name);
        }
}
/* print union structure definition. */
static GenUnionDcl(U)
StructDcl U;
{
       Field ptr;
        if (U==0) Punt("GenUnionDcl : nil U");
        /* BCC - process union prototypes - 6/99 */
        if (U->fields) {
            fprintf(F, "union %s {\n", U->name);
            for (ptr=U->fields; ptr!=0; ptr=ptr->next) {
                    fprintf(F, "\t");
                    GenStructField(ptr);
            }
            fprintf(F, "} ;\n");
        }
        else {
            fprintf(F, "union %s;\n", U->name);
        }
}
/*========================================================================*/
static GenToken(init)
Init init;
{
	int n;
	if (init==0) return;	/* init is only optional. */
	if (init->expr!=0)
		GenCExpr(init->expr, 0);
	else
	if (init->set!=0) {
		Init ptr;
		fprintf(F, "{");
		ptr=init->set;
		n = 0;
		while (ptr!=0) {
			GenToken(ptr);
			ptr = ptr->next;
			if (ptr!=0)
				fprintf(F, ",");
			n++;
			if ((n%10)==0) fprintf(F, "\n");
		}
		fprintf(F, "}");
	} else
		Punt("GenInit : unknown data type");
}
static GenInit(init)
Init init;
{
	if (init==0) return;	/* init is only optional. */
	fprintf(F, " = ");
	GenToken(init);
}
/* print parameter definition. */
static GenParamDataDcl(V)
VarDcl V;
{
	if (V==0) Punt("GenParamDataDcl : nil V");
	GenCType(V->type, 1);			/* type */
	GenCDcltr(V->type->dcltr, V->name);	/* dcltr */
	fprintf(F, ";\n");
}
/* print local variable definition. */
static GenLocalDataDcl(V)
VarDcl V;
{
	if (V==0) Punt("GenLocalDataDcl : nil V");
	GenCType(V->type, 1);			/* type */
	GenCDcltr(V->type->dcltr, V->name);	/* dcltr */
	fprintf(F, ";\n");
}
/* print global variable definition. */
/* the type definition is what's recorded at that instance of the
 * global variable definition. If it is extern class, the initialization
 * section is not printed.
 */
static GenGlobalDataDcl(V, type, dcltr)
VarDcl V;
Type type;
Dcltr dcltr;
{
	if (V==0) Punt("GenGlobalDataDcl : nil V");
	GenCType(type, 1);				/* type */
	GenCDcltr(dcltr, V->name);			/* dcltr */
	if (! (type->type & TY_EXTERN)) 
		GenInit(V->init);
	fprintf(F, ";\n");
}
/*========================================================================*/
Gen_C_LinePos(F, n, src_file)
FILE *F;
int n;
char *src_file;
{
	if (BLOCK_OUTPUT) return;
/* BCC - Temporary fix for testing hp-cc -Aa - 9/15/95 
	fprintf(F, "# %d %s\n", n, src_file); */
}
Gen_C_Struct(FL, st)
FILE *FL;
StructDcl st;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenStructDcl(st);
}
Gen_C_Union(FL, un) 
FILE *FL;
UnionDcl un;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenUnionDcl(un);
}
Gen_C_Enum(FL, en) 
FILE *FL;
EnumDcl en;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenEnumDcl(en);
}
Gen_C_Var(FL, var) 
FILE *FL;
VarDcl var;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenGlobalDataDcl(var, var->type, var->type->dcltr);
}
Gen_C_Func(FL, fn) 
FILE *FL;
FuncDcl fn;
{
	if (BLOCK_OUTPUT) return;
	F = FL;
	GenFunction(fn);
}
Gen_C_Expr(FL, expr)
FILE *FL;
Expr expr;
{
	F = FL;
	fprintf(F, "# Gen_C_Expr: ");
	if (expr->type==0) {
	    fprintf(F, "?type");
	} else {
	    GenCType(expr->type, 1);
	    GenCDcltr(expr->type->dcltr, 0);
	}
	fprintf(F, " : ");
	GenCExpr(expr, 1);
	fprintf(F, "\n");
}
Gen_C_Type(FL, type)
FILE *FL;
Type type;
{
	F = FL;
	fprintf(F, "# Gen_C_Type: ");
	GenCType(type, 1);
	GenCDcltr(type->dcltr, 0);
	fprintf(F, "\n");
}
/*
 *	Expand an include file into the text.
 */
Gen_C_Include(FL, file)
FILE *FL;
char *file;
{
	int buf;
	if (! BLOCK_OUTPUT) {
	    char name[1024];
	    int len;
	    /*
	     *	.h is automatically suffixed.
	     *	The user must properly convert the
	     *	included files to C form and end with .h
	     */
	    sprintf(name, "%s", file);
	    len = strlen(name);
	    name[len-1] = '.';
	    name[len] = 'h';
	    name[len+1] = '"';
	    name[len+2] = '\0';
	    fprintf(FL, "#include %s\n", name);
	}
	/*
	 *	Do not output the body of the include file.
	 */
	buf = OUTPUT;
	DO_OUTPUT(0);
	ReadIncludeFile(file);		/* ccode.c */
	DO_OUTPUT(buf);
}
/*========================================================================*/
