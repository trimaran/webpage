/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.31  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 21, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_ccode.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Modified by:  Nancy J. Warter
\*****************************************************************************/
#include <Hcode/h_main.h>

/*===========================================================================*\
 *	Export Functions : 
 *		ReadIncludeFile(file) char *file;
 *		ProcessList()
 *		ClearSymbolTable()
\*===========================================================================*/

#undef ABORT


static int Clear();
static int SetUpSymbolTables();
extern Expr ReduceExpr();	/* reduce.c 9-12-89 */
extern DepInfo NewDepInfo();
static Expr Expression();
static Punt(char *mesg);

static int ccode_init = 0;	/* initialize symbol tables */
static char *file=0;		/* current file position. */
static int line=0;		/* current line position. */

SymTable SymbolTable;

/*
 * The current function definition being constructed.
 */
FuncDcl currentFuncDcl = 0;
/*
 * The current basic block being constructed.
 */
Block currentBlock = 0;

/*===================================================================*/
/*
 * Maintain a LIST stack, to make error reporting much more
 * user friendly.
 */
#define MAX_LEVEL 2000		/* max nest degree of expressions */
static int s_top = -1;
static LIST s_stack[MAX_LEVEL];
static Push(list)
LIST list;
{
	s_top++;
	if (s_top>=MAX_LEVEL) {
	    Clear(); Punt("internal LIST stack overflows");
	}
	s_stack[s_top] = list;
}
static Pop() {
	if (s_top>=0)
	    s_top--;
}
static LIST Top() {
	if ((s_top>=0)&&(s_top<MAX_LEVEL))
	    return (s_stack[s_top]);
	else
	    return 0;
}
static int Clear() {
	s_top = -1;
}
/*===================================================================*/
/* Print error message and then punt the program. */
static Punt(char *mesg)
{
	LIST err;
	fprintf(stderr, "Hcode: %s\n", mesg);
	if (file!=0)
	    fprintf(stderr, "At file [%s] line [%d],\n", file, line);
	err = Top();
#ifdef ABORT
	abort();
#endif
	exit(-1);
}
/* Print a warning message and then return. */
Warning(mesg)
char *mesg;
{
	fprintf(stderr, "CCODE warning: %s\n", mesg);
	if (file!=0)
	    fprintf(stderr, "At file [%s] line [%d],\n", file, line);
}
/*===================================================================*/
static Pragma expr_pragma = 0;

DepInfo
ReadDepInfo(LIST list)
{
    DepInfo new_info,first_info,last_info;
    LIST child, list1;
    char *keyword;

    list1 = list;

    first_info = NULL;
    last_info = NULL;

    while (list1 != NULL) {

        if (NodeType(list1) != T_LIST)
	    Punt("ReadDepInfo: not in list form");

        new_info = NewDepInfo();
        child = ChildOf(list1);

        if (child != NULL) {
	    if (NodeType(child) != T_INT)
	        Punt("ReadDepInfo: incorrect format (1)");
	    new_info->num = IntegerOf(child);

            child = SiblingOf(child);
            if (child != NULL) {
	        if (NodeType(child) != T_ID)
	            Punt("ReadDepInfo: incorrect format (2)");
		keyword = StringOf(child);
	        new_info->certainty = keyword[0];
	        new_info->freq = keyword[1];

                child = SiblingOf(child);
                if (child != NULL) {
	            if (NodeType(child) != T_INT)
	                Punt("ReadDepInfo: incorrect format (4)");
	            new_info->dist = IntegerOf(child);
   
                    child = SiblingOf(child);
                    if (child != NULL) {
	                if (NodeType(child) != T_INT)
	                    Punt("ReadDepInfo: incorrect format (5)");
	                new_info->flags = IntegerOf(child);
		    }
		}
	    }
        }
	if (first_info) {
	    last_info->next = new_info;
	    last_info = new_info;
	}
	else {
	    first_info = new_info;
	    last_info = new_info;
	}
	list1 = SiblingOf(list1);
    }
    return (first_info);
}


/*
 * Process a pragma for the next expression.
 */
static ReadExprPragma(list)
LIST list;
{
	LIST prag_expr;
	Pragma new, ptr;
	/* "%s" ) */
	if ((list==0)||(NodeType(list)!=T_STRING))
	    Punt("incorrect (EXPR_PRAGMA) specifier");
	new = NewPragma(StringOf(list));
	if (! strcmp (new->specifier, "\"DEP\"") ) {
	    prag_expr = SiblingOf(list);
	    new->dep_info = ReadDepInfo(prag_expr);
	}
	if (expr_pragma==0) 
	    expr_pragma = new;
	else {
	    ptr = expr_pragma;
	    while (ptr->next!=0) ptr = ptr->next;
	    ptr->next = new;
	}
}
/*
 * Process a non-nil expression.
 */
static Expr Expression(list)
LIST list;
{
	extern Type DeclSpec();	/* forward */
	LIST opcode, operands, ptr;
	char *keyword;
	Symbol sym;
	Expr expr;
	if ((list==0)||(NodeType(list)!=T_LIST))
	    Punt("incorrect expression format (1)");
	opcode = ChildOf(list);
	/* (opcode operands) */
	if ((opcode==0)||(NodeType(opcode)!=T_ID))
	    Punt("incorrect expression format (2)");
	keyword = StringOf(opcode);
	operands = SiblingOf(opcode);
	/* index into the opcode symbol table to find the opcode */
	sym = FindSym(SymbolTable[ST_OPCODE], keyword, 0);
	if (sym==0) {
	    fprintf(stderr, "> %s\n", keyword);
	    Punt("incorrect expression format (3)");
	}
	expr = NewExpr(sym->value);
	/* handle special expressions */
	Push(list);	/* level 1 */

/* DMG - moved pragma stuff out of default section of switch */

	     /*  scan expr for expr pragmas */

	expr_pragma = NULL;
	for (ptr=operands; ptr!=0; ptr=SiblingOf(ptr)) {
	    LIST temp;
	    if (NodeType(ptr)!=T_LIST)
		continue;
	    temp = ChildOf(ptr);
	    if ((temp!=0) && (NodeType(temp)==T_ID)
		&& !strcmp(StringOf(temp), "EXPR_PRAGMA")) {
	    	ReadExprPragma(SiblingOf(temp));
	    } 
	}
	    /* hook up the pragma */
	expr->pragma = expr_pragma;

	switch (expr->opcode) {
	case OP_var:
		/* var_name%s) */
		if ((operands==0)||(NodeType(operands)!=T_ID))
	    	    Punt("incorrect primary expression (1)");
		expr->value.var_name = StringOf(operands);
		break;
	case OP_enum:
		/* field_name%s) */
		if ((operands==0)||(NodeType(operands)!=T_STRING))
	    	    Punt("incorrect primary expression (2)");
		expr->value.string = StringOf(operands);
		break;
	case OP_signed:
		/* value%d) */
		if ((operands==0)||(NodeType(operands)!=T_INT))
	    	    Punt("incorrect primary expression (3)");
		expr->value.scalar = IntegerOf(operands);
		break;
	case OP_unsigned:
		/* value%d) */
		if ((operands==0)||(NodeType(operands)!=T_INT))
	    	    Punt("incorrect primary expression (4)");
		expr->value.uscalar = IntegerOf(operands);
		break;
	case OP_float:
	/* BCC - added - 8/5/96 */
	case OP_double:
		/* value%f) */
		if ((operands==0)||(NodeType(operands)!=T_REAL))
	    	    Punt("incorrect primary expression (5)");
		expr->value.real = RealOf(operands);
		break;
	case OP_char:
		/* str%s) */
		if ((operands==0)||(NodeType(operands)!=T_CHAR))
	    	    Punt("incorrect primary expression (6)");
		expr->value.string = StringOf(operands);
		break;
	case OP_string:
		/* str%s) */
		if ((operands==0)||(NodeType(operands)!=T_STRING))
	    	    Punt("incorrect primary expression (7)");
		expr->value.string = StringOf(operands);
		break;
	case OP_dot:
	case OP_arrow:
		/* we will keep the field name in value.string */
		/* expr field_name%s) */
		if (operands==0)
	    	    Punt("incorrect primary expression (8)");
		AddOperand(expr, Expression(operands));
		operands = SiblingOf(operands);
		if ((operands==0)||(NodeType(operands)!=T_STRING)) 
	    	    Punt("incorrect primary expression (8)");
		expr->value.string = StringOf(operands);
		break;
	case OP_cast:
		/* DeclSpec expr) */
		if (operands==0)
	    	    Punt("incorrect expression format (4) : cast");
		/*
		 *	Here, we violate the NO_SHARING rule.
		 *	But since the (value) field of Expr
		 *	structure is never deleted, this is safe.
		 */
		expr->value.type = expr->type = DeclSpec(operands);
		operands = SiblingOf(operands);
		if (operands==0)
	    	    Punt("incorrect expression format (5) : cast");
		AddOperand(expr, Expression(operands));
		break;
	case OP_expr_size:
		/* expr) */
		AddOperand(expr, Expression(operands));
		break;
	case OP_type_size:
		/* DeclSpec) */
		if (operands==0)
	    	    Punt("incorrect expression format (6) : type_size");
		expr->value.type = DeclSpec(operands);
		break;
	default:
		/*
		 *	scan all parameters.
		 */
		for (ptr=operands; ptr!=0; ptr=SiblingOf(ptr)) {
		    LIST temp;
		    if (NodeType(ptr)==T_LIST) {
		    	temp = ChildOf(ptr);
		    	if ((temp!=0) && (NodeType(temp)==T_ID)
				&& !strcmp(StringOf(temp), "EXPR_PRAGMA")) {
		    	    continue;	/* skip over pragma */
		    	} 
		    }
		    AddOperand(expr, Expression(ptr));
		}
	}
	Pop();	/* level 1 */
	CastExpr(expr);
	return expr;
}

/*===================================================================*/
/* BCC - 1/21/96
 * Read the parameter type declarations
 *
 */

Param ReadParamTypeList(list)
     LIST list;
{
  LIST opcode;
  char *keyword;
  Param first, new, last;
  extern Type DeclSpec();

    first = last = NULL;
    for(; list!=0; list=SiblingOf(list)) {
	if((list==0)||(NodeType(list)!=T_LIST))
	    Punt("incorrect parameter type specifier (1)");
	opcode = ChildOf(list);
	if((opcode==0)||(NodeType(opcode)!=T_ID))
	Punt("incorrect parameter type specifier (2)");
	keyword = StringOf(opcode);
	if(strcmp(keyword, "FPARAM"))
	    Punt("incorrect parameter type specifier (3)");
	opcode = SiblingOf(opcode);
	/* Specifier string */
	if((opcode==0)||(NodeType(opcode)!=T_LIST))
	    Punt("incorrect parameter type specifier (4)");
	new = NewParam();
	new->type = DeclSpec(opcode);
	if (last == NULL)
	    first = last = new;
	else {
	    last->next = new;
	    last = new;
	}
    }
    return first;
}

/*===================================================================*/
/*
 * Read a declaration_specifier, and return it.
 */
Type DeclSpec(list)
LIST list;
{
	LIST item;
	char *spec;
	int type_less = 0;
	Type type;
	type = NewType();
	/* (TYPE_LESS decl) |
	 * (type decl)
	 */
	if ((list==0)||(NodeType(list)!=T_LIST))
	    Punt("incorrect declarator_specifier");
	Push(list);	/* level 1 */
	list = ChildOf(list);
	for (; list!=0; list=SiblingOf(list)) {
	    if (NodeType(list)!=T_LIST) {
	 	if ((NodeType(list)==T_ID) && 
			(! strcmp("TYPE_LESS", StringOf(list)))) {
		    type_less = 1;
		    continue;
		} else
		    Punt("incorrect declarator_specifier field (1)");
	    }
	    item = ChildOf(list);
	    if ((item==0)||(NodeType(item)!=T_ID)) {
		spec = "dcltr";
	    } else {
	        spec = StringOf(item);
	    }
	    if (! strcmp(spec, "REGISTER")) 
		type->type |= TY_REGISTER;
	    else if (! strcmp(spec, "STATIC"))
		type->type |= TY_STATIC;
	    else if (! strcmp(spec, "EXTERN"))
		type->type |= TY_EXTERN;
	    else if (! strcmp(spec, "AUTO"))
		type->type |= TY_AUTO;
	    else if (! strcmp(spec, "GLOBAL"))
		type->type |= TY_GLOBAL;
	    else if (! strcmp(spec, "PARAMETER"))
		type->type |= TY_PARAMETER;
	    else if (! strcmp(spec, "CONST"))
		type->type |= TY_CONST;
	    else if (! strcmp(spec, "VOLATILE"))
		type->type |= TY_VOLATILE;
	    else if (! strcmp(spec, "NOALIAS"))
		type->type |= TY_NOALIAS;
	    else if (! strcmp(spec, "SIGNED"))
		type->type |= TY_SIGNED;
	    else if (! strcmp(spec, "UNSIGNED"))
		type->type |= TY_UNSIGNED;
	    else if (! strcmp(spec, "VOID"))
		type->type |= TY_VOID;
	    else if (! strcmp(spec, "SHORT"))
		type->type |= TY_SHORT;
	    else if (! strcmp(spec, "LONG"))
		type->type |= TY_LONG;
	    else if (! strcmp(spec, "CHAR"))
		type->type |= TY_CHAR;
	    else if (! strcmp(spec, "INT"))
		type->type |= TY_INT;
	    else if (! strcmp(spec, "FLOAT"))
		type->type |= TY_FLOAT;
	    else if (! strcmp(spec, "DOUBLE"))
		type->type |= TY_DOUBLE;
	    else if (! strcmp(spec, "VARARG"))	/* BCC - added - 1/24/96 */
		type->type |= TY_VARARG;
	    else if (! strcmp(spec, "STRUCT")) {
		if (type->type & (TY_STRUCT|TY_UNION|TY_ENUM))
		    Punt("incorrect declarator_specifier field (3)");
		type->type |= TY_STRUCT;
		item = SiblingOf(item);
		if ((item==0)||(NodeType(item)!=T_ID))
		    Punt("incorrect declarator_specifier field (4)");
		type->struct_name = StringOf(item);
	    } else
	    if (! strcmp(spec, "UNION")) {
		if (type->type & (TY_STRUCT|TY_UNION|TY_ENUM))
		    Punt("incorrect declarator_specifier field (5)");
		type->type |= TY_UNION;
		item = SiblingOf(item);
		if ((item==0)||(NodeType(item)!=T_ID))
		    Punt("incorrect declarator_specifier field (6)");
		type->struct_name = StringOf(item);
	    } else
	    if (! strcmp(spec, "ENUM")) {
		if (type->type & (TY_STRUCT|TY_UNION|TY_ENUM))
		    Punt("incorrect declarator_specifier field (7)");
		type->type |= TY_ENUM;
		item = SiblingOf(item);
		if ((item==0)||(NodeType(item)!=T_ID))
		    Punt("incorrect declarator_specifier field (8)");
		type->struct_name = StringOf(item);
	    } else {
		/* decl) */
		for (; item!=0; item=SiblingOf(item)) {
		    /* P | F | A */
		    Dcltr ptr, new = NewDcltr();
		    if (NodeType(item)==T_ID) {
			if (! strcmp(StringOf(item), "P")) {
			    new->method = D_PTR;
			}
			else if (! strcmp(StringOf(item), "F")) {
			    new->method = D_FUNC;
			}
			else if (! strcmp(StringOf(item), "A")) {
			    new->method = D_ARRY;
			    new->index = 0;
			}
			else
		    	    Punt("incorrect declarator_specifier field (9)");
		    } else
		    /* (F (param type ) qualifier) | (P qualifier) | 
		       (A const_expr) */
		    if (NodeType(item)==T_LIST) {
			LIST ll = ChildOf(item);
			if ((ll==0)||(NodeType(ll)!=T_ID))
		    	    Punt("incorrect declarator_specifier field (10)");
			if (! strcmp(StringOf(ll), "A")) {
			    new->method = D_ARRY;
			    ll = SiblingOf(ll);
			    if (ll!=0) {
				/* 9-12-89 */
				Expr exp = Expression(ll);
				new->index = ReduceExpr(exp);
				RemoveExpr(exp);
			    }
			} else if(! strcmp(StringOf(ll), "P")) {
			    new->method = D_PTR;
			    new->qualifier = 0;
			    ll = SiblingOf(ll);
			    while (ll!=0) {
				if (! strcmp(StringOf(ll), "CONST"))
				    new->qualifier |= DQ_CONST;
				else if (! strcmp(StringOf(ll), "VOLATILE"))
				    new->qualifier |= DQ_VOLATILE;
				else Punt("incorrect dcltr_qualifier (1)");
				ll = SiblingOf(ll);
			    }
			} else if(! strcmp(StringOf(ll), "F")) {
			    /* BCC - 1/22/96
			     * A function declarator may have a list of params 
			     */
			    new->method = D_FUNC;
			    new->qualifier = 0;
			    ll = SiblingOf(ll);
			    while (ll!=0 && NodeType(ll) == T_ID) {
				if (! strcmp(StringOf(ll), "CDECL"))
				    new->qualifier |= DQ_CDECL;
				else if (! strcmp(StringOf(ll), "STDCALL"))
				    new->qualifier |= DQ_STDCALL;
				else if (! strcmp(StringOf(ll), "FASTCALL"))
				    new->qualifier |= DQ_FASTCALL;
				else Punt("incorrect dcltr_qualifier (2)");
				ll = SiblingOf(ll);
			    }
			    if (ll!=0 && ChildOf(ll)!=0) 
				new->param = ReadParamTypeList(ChildOf(ll));
			}
			else
		    	    Punt("incorrect declarator_specifier field (11)");
		    }
		    /* link the new dcltr to the chain */
		    ptr = type->dcltr;
		    if (ptr==0) {
			type->dcltr = new;
		    } else {
			while (ptr->next!=0) ptr = ptr->next;
			ptr->next = new;
		    }
		}
		if (SiblingOf(list)!=0)
		    Punt("incorrect declarator_specifier field (12)");
	   	break; 	/* must be at the end of DeclSpec */
	    }
	}
	if (type_less && (type->type!=0))
	    Punt("incorrect declarator_specifier field (13)");
	Pop();	/* level 1 */
	UnifyArithmeticType(type);	/* cast.c */
	return type;
}
/*===================================================================*/
/* Set the line and file position. (for debugging purpose) */
static SetLinePosition(list)
LIST list;
{
	/* line%d file_name%s) */
	if ((list==0)||(NodeType(list)!=T_INT))
	    Punt("incorrect (POSITION) descriptor (1)");
	line = IntegerOf(list);
	list = SiblingOf(list);
	if ((list==0)||(NodeType(list)!=T_STRING))
	    Punt("incorrect (POSITION) descriptor (2)");
	file = StringOf(list);
	ProcessLinePos(file, line);
}
/*===================================================================*/
/* Read comments */
static ReadComment(list)
LIST list;
{
	/* ignore */
}
/*===================================================================*/
/* Read function pragma(s) : apply to the current function */
static ReadFnPragma(list)
LIST list;
{
	Pragma new, ptr;
	/* "%s" ) */
	if ((list==0)||(NodeType(list)!=T_STRING))
	    Punt("incorrect (FN_PRAGMA) specifier");
	new = NewPragma(StringOf(list));
	ptr = currentFuncDcl->pragma;
	if (ptr==0)
	    currentFuncDcl->pragma = new;
	else {
	    while (ptr->next!=0) ptr = ptr->next;
	    ptr->next = new;
	}
}
/*===================================================================*/
/* Read in a struct definition. */
static DefineStruct(list)
LIST list;
{
	LIST item;
	StructDcl en, old_en;
	Field field, ptr;
	en = NewStructDcl();
	/* struct_name%s struct_fields*) */
	if ((list==0)||(NodeType(list)!=T_ID))
	    Punt("incorrect struct definition (1)");
	en->name = StringOf(list);	/* var name */
	list = SiblingOf(list);
	/* process struct_fields */
	for (; list!=0; list=SiblingOf(list)) {
	    Push(list);	/* level 2 */
	    field = NewField();
	    /* (field_name%s DeclSpec const_expr?) */
	    if (NodeType(list)!=T_LIST)
		Punt("incorrect struct field definition (1)");
	    item = ChildOf(list);
	    if ((item==0)||(NodeType(item)!=T_STRING))
		Punt("incorrect struct field definition (2)");
	    field->name = StringOf(item);
	    item = SiblingOf(item);
	    if ((item==0)||(NodeType(item)!=T_LIST))
		Punt("incorrect struct field definition (3)");
	    field->type = DeclSpec(item);
	    item = SiblingOf(item);
	    if (item!=0) {
		Expr exp;
		exp = Expression(item);
		field->bit_field = ReduceExpr(exp);
		/* REH 2/7/96 */
		field->type->type |= TY_BIT_FIELD;
		RemoveExpr(exp);
	    }
	    ptr = en->fields;
	    if (ptr==0) {
		en->fields = field;
	    } else {
		while (ptr->next!=0) ptr = ptr->next;
		ptr->next = field;
	    }
	    Push(list);	/* level 2 */
	}
        /* insert into symbol table */
        /* BCC - handle previously declared structs - 6/99 */
        if ((old_en = FindStruct(en->name)) && old_en->fields) {
            fprintf(stderr, "=> struct %s\n", en->name);
            Punt("multiple definition of a struct");
        }
        if (old_en == 0 || en->fields) {
            AddStruct(en->name, en);
            /* process it (see process.c) */
            ProcessStruct(en);
        }
}
/*===================================================================*/
/* Read in an union definition. */
static DefineUnion(list)
LIST list;
{
	LIST item;
	UnionDcl en, old_en;
	Field field, ptr;
	en = NewUnionDcl();
	/* union_name%s union_fields*) */
	if ((list==0)||(NodeType(list)!=T_ID))
	    Punt("incorrect union definition (1)");
	en->name = StringOf(list);	/* var name */
	list = SiblingOf(list);
	/* process union_fields */
	for (; list!=0; list=SiblingOf(list)) {
	    Push(list);	/* level 2 */
	    field = NewField();
	    /* (field_name%s DeclSpec const_expr?) */
	    if (NodeType(list)!=T_LIST)
		Punt("incorrect union field definition (1)");
	    item = ChildOf(list);
	    if ((item==0)||(NodeType(item)!=T_STRING))
		Punt("incorrect union field definition (2)");
	    field->name = StringOf(item);
	    item = SiblingOf(item);
	    if ((item==0)||(NodeType(item)!=T_LIST))
		Punt("incorrect union field definition (3)");
	    field->type = DeclSpec(item);
	    item = SiblingOf(item);
	    if (item!=0) {
		/* 9-12-89 */
		Expr exp;
		exp = Expression(item);
		field->bit_field = ReduceExpr(exp);
		/* REH 2/7/96 */
		field->type->type |= TY_BIT_FIELD;
		RemoveExpr(exp);
	    }
	    ptr = en->fields;
	    if (ptr==0) {
		en->fields = field;
	    } else {
		while (ptr->next!=0) ptr = ptr->next;
		ptr->next = field;
	    }
	    Pop();	/* level 2 */
	}
        /* insert into symbol table */
        /* BCC - handle previously declared structs - 6/99 */
        if ((old_en = FindUnion(en->name)) && old_en->fields) {
            fprintf(stderr, "=> union %s\n", en->name);
            Punt("multiple definition of a union");
        }
        if (old_en == 0 || en->fields) {
            AddUnion(en->name, en);
            /* process it (see process.c) */
            ProcessUnion(en);
        }
}
/*===================================================================*/
/* Read in an Enum definition. */
/* The (ptr) fields of Enum symbol table are connected to
 * EnumDcls. All enum fields must have unique names (even
 * across different enums)
 */
static DefineEnum(list)
LIST list;
{
	LIST item;
	EnumDcl en;
	EnumField field, ptr;
	en = NewEnumDcl();
	/* enum_name%s enum_fields*) */
	if ((list==0)||(NodeType(list)!=T_ID))
	    Punt("incorrect enum definition (1)");
	en->name = StringOf(list);	/* var name */
	list = SiblingOf(list);
	/* process enum_fields */
	for (; list!=0; list=SiblingOf(list)) {
	    Push(list);	/* level 2 */
	    field = NewEnumField();
	    /* (identifier%s const_expr?) */
	    if (NodeType(list)!=T_LIST)
		Punt("incorrect enum field definition (1)");
	    item = ChildOf(list);
	    if ((item==0)||(NodeType(item)!=T_STRING))
		Punt("incorrect enum field definition (2)");
	    field->name = StringOf(item);
	    item = SiblingOf(item);
	    if (item!=0) {
		Expr exp;	/* 9-12-89 */
		exp = Expression(item);
		field->value = ReduceExpr(exp);
		RemoveExpr(exp);
	    }
	    ptr = en->fields;
	    if (ptr==0) {
		en->fields = field;
	    } else {
		while (ptr->next!=0) ptr = ptr->next;
		ptr->next = field;
	    }
	    Pop();	/* level 2 */
	}
	/* insert into symbol table */
	if (FindEnum(en->name)!=0) {
	    fprintf(stderr, "=> enum %s\n", en->name);
	    Punt("multiple definition of a enum");
	}
	AddEnum(en->name, en);
	/* process it (see process.c) */
	ProcessEnum(en);
}
/*===================================================================*/
/* Read the initialization form. */
static Init Initializer(list)
LIST list;
{
	LIST ptr;
	Init new, next, pn;
	if (list==0) return 0;		/* no initializer */
	new = NewInit();
	/* expression | (AGGR initializers) */
	if (NodeType(list)!=T_LIST)
	    Punt("incorrect initializer (1)");
	ptr = ChildOf(list);
	if ((ptr!=0)&&(NodeType(ptr)==T_ID)&&(!strcmp(StringOf(ptr),"AGGR"))) {
	    /* aggregate initializer */
	    for (ptr=SiblingOf(ptr); ptr!=0; ptr=SiblingOf(ptr)) {
		next = Initializer(ptr);
		/** add to the set **/
		pn = new->set;
		if (pn==0) {
		    new->set = next;
		} else {
		    while (pn->next!=0) pn = pn->next;
		    pn->next = next;
		}
	    }
	} else {
	    Expr exp = Expression(list);	/* 9-12 */
	    new->expr = ReduceExpr(exp);
	    RemoveExpr(exp);
	}
	return new;
}
/* Read in a global variable definition. */
/* The (ptr) fields of the global variable symbol table
 * points to the symbol definitions (VarDcl).
 */
static DefineGvar(list)
LIST list;
{
	VarDcl var, v;
	var = NewVarDcl();
	/* var_name%s DeclSpec Initializer) */
	if ((list==0)||(NodeType(list)!=T_ID))
	    Punt("incorrect global variable declaration (1)");
	var->name = StringOf(list);	/* var name */
	list = SiblingOf(list);
	if ((list==0)||(NodeType(list)!=T_LIST))
	    Punt("incorrect global variable declaration (2)");
	var->type = DeclSpec(list);	/* var type */
	/* make sure it is not defined several times */
	if ((v=FindVar(var->name))!=0) {
	    int type1, type2, class;
	    /* It is possible to have multiple definitions of
	     * the same variable. For example, several can be extern
	     * definitions, and one be a global definition.
	     * global + extern -> global
	     * extern + extern -> extern
	     * extern + static -> static
	     */
	    type1 = v->type->type;
	    type2 = var->type->type;
#define U_CLASS (TY_STATIC|TY_EXTERN|TY_GLOBAL)
	    class = (type1 | type2) & U_CLASS;
	    type1 &= ~U_CLASS;
	    type2 &= ~U_CLASS;
	    if (type1!=type2)
	    	Warning("multiple definitions of a global variable (1)");
	    if ((class & TY_STATIC) && (class & TY_GLOBAL)) {
	    	Warning("multiple definitions of a global variable (2)");
	    } else if (class & TY_GLOBAL) {
		class = TY_GLOBAL;
	    } else if (class & TY_STATIC) {
		class = TY_STATIC;
	    } else if (class & TY_EXTERN) {
		class = TY_EXTERN;
	    } else 
	    	Warning("multiple definitions of a global variable (3)");
	    /*
	     * we modify the OLD version of the variable declaration.
	     * the new copy must not be altered because it will appear
	     * in the output.
	     */
	    v->type->type = (type1 | class);
	} else {
	    /* add it to the symbol table */
	    AddVar(var->name, var);
	}
	/*
	 * must handle the initializer after the variable entry has
	 * been defined in the symbol table, because there are cases
	 * where the variable itself is used in its own initializer (cccp)
	 */
	list = SiblingOf(list);
	var->init = Initializer(list);	/* var initializer */
	/*
	 * convert the initializer list to our more strict format.
	 * also make necessary type conversion to the initializer.
	 */
	if (var->init!=0)
	    ProcessInit(var);
	/* process the symbol (process.c) */
	/* we actually print every definition (although there
	 * can be several for a variable). this is important
	 * to preserve the C semantics.
	 */
	ProcessGlobalVar(var);
}
/*===================================================================*/
/* Read in a local variable definition. */
static ReadLocalVar(list)
LIST list;
{
	VarDcl var;
	VarList new, ptr;
	/** create new variable declaration **/
	var = NewVarDcl();
	/* var_name%s DeclSpec) */
	if ((list==0)||(NodeType(list)!=T_ID))
	    Punt("incorrect local variable declaration");
	var->name = StringOf(list);
	list = SiblingOf(list);
	var->type = DeclSpec(list);
	/** link it to the function **/
	currentFuncDcl->local = AddVar2List(currentFuncDcl->local, var);
}
/*-------------------------------------------------------------------*/
/* Read in a parameter definition. */
static ReadParameter(list)
LIST list;
{
	VarDcl var;
	VarList new, ptr;
	/** create new variable declaration **/
	var = NewVarDcl();
	/* var_name%s DeclSpec) */
	if ((list==0)||(NodeType(list)!=T_ID))
	    Punt("incorrect parameter declaration (2)");
	var->name = StringOf(list);
	list = SiblingOf(list);
	var->type = DeclSpec(list);
	/*
	 * if it is not already declared TY_PARAMETER,
	 * make it one.
	 */
	if (var->type->type & (TY_AUTO|TY_STATIC|TY_EXTERN|TY_GLOBAL)) {
	    fprintf(stderr, "> %s\n", var->name);
	    Punt("incorrect parameter declaration (3)");
	}
	var->type->type |= TY_PARAMETER;
	/* link it to the function. 
	 * we must preserve the incoming order.
	 */
	currentFuncDcl->param = AddVar2List(currentFuncDcl->param, var);
}
/*-------------------------------------------------------------------*/
/*
 * Read a basic block pragma, add it to the currentBlock.
 */
static ReadBBPragma(list)
LIST list;
{
	Pragma new, ptr;
	/* "%s" ) */
	if ((list==0)||(NodeType(list)!=T_STRING))
	    Punt("incorrect (BB_PRAGMA) specifier");
	new = NewPragma(StringOf(list));
	ptr = currentBlock->pragma;
	if (ptr==0)
	    currentBlock->pragma = new;
	else {
	    while (ptr->next!=0) ptr = ptr->next;
	    ptr->next = new;
	}
}
/* Read a basic block.
 * The (source) link of basic block is NOT constructed at this point.
 */
static ReadBasicBlock(list)
LIST list;
{
	Block bb;
	LIST next;
	Expr expr;
	BLink link;
	/* bb_id%d expressions control_expression) */
	currentBlock = bb = NewBlock();
	if ((list==0)||(NodeType(list)!=T_INT))
	    Punt("incorrect basic block description (1)");
	bb->id = IntegerOf(list);
	list = SiblingOf(list);
	/* construct the basic block body */
	while (list!=0) {
	    next = SiblingOf(list);
	    /* see if its a pragma */
	    if (NodeType(list)==T_LIST) {
		LIST temp = ChildOf(list);
		if ((temp!=0)&&(NodeType(temp)==T_ID)) {
		    if (! strcmp(StringOf(temp), "PROFILE")) {
			LIST args;
			/* (PROFILE bb_weight (dest cond weight)*) */
			args = SiblingOf(temp);
			if ((args==0)||(NodeType(args)!=T_REAL))
			    Punt("incorrect (BB (PROFILE)) description");
			bb->profile.weight = RealOf(args);
			args = SiblingOf(args);
			while (args!=0) {
			    LIST dest_bb, cond, weight;
			    ProfArc parc, ptr;
			    if (NodeType(args)!=T_LIST)
			    	Punt("incorrect (BB (PROFILE)) description");
			    dest_bb = ChildOf(args);
			    if ((dest_bb==0)||(NodeType(dest_bb)!=T_INT))
			    	Punt("incorrect (BB (PROFILE)) description");
			    cond = SiblingOf(dest_bb);
			    if ((cond==0)||(NodeType(cond)!=T_INT))
			    	Punt("incorrect (BB (PROFILE)) description");
			    weight = SiblingOf(cond);
			    if ((weight==0)||(NodeType(weight)!=T_REAL))
			    	Punt("incorrect (BB (PROFILE)) description");
			    parc = NewProfArc();
			    parc->bb_id = IntegerOf(dest_bb);
			    parc->condition = IntegerOf(cond);
			    parc->weight = RealOf(weight);
			    ptr = bb->profile.destination;
			    if (ptr==0) {
				bb->profile.destination = parc;
			    } else {
				while (ptr->next!=0)
				    ptr = ptr->next;
			 	ptr->next = parc;
			    }
			    args = SiblingOf(args);
			}
			goto NEXT_EXPR;
		    } else
		    if (! strcmp(StringOf(temp), "BB_PRAGMA")) {
		    	ReadBBPragma(SiblingOf(temp));
		    	goto NEXT_EXPR;
		    }
		}
	    }
	    if (next==0) {
		/* last expression is a control_expression */
		LIST opcode, op, ptr;
		char *keyword;
		if (NodeType(list)!=T_LIST)
	    	    Punt("incorrect basic block description (2)");
		opcode = ChildOf(list);
		if ((opcode==0)||(NodeType(opcode)!=T_ID))
	    	    Punt("incorrect basic block description (3)");
		op = SiblingOf(opcode);
		keyword = StringOf(opcode);
		if (! strcmp(keyword, "RETURN")) {
		    /* expression?) */
		    expr = NewExpr(OP_return);
		    if (op!=0) {
			LIST temp;  /* LCW - 9/29/97 */
			/* LCW - check if op is a pragma or an expr -9/29/97 */
			if ((NodeType(op)==T_LIST) && ((temp=ChildOf(op))!=0) 
			    && (NodeType(temp)==T_ID) && 
			    (!strcmp(StringOf(temp), "EXPR_PRAGMA"))) {
			   expr_pragma = NULL;
			   for (ptr=op; ptr!=0; ptr=SiblingOf(ptr)) {
			       if (NodeType(ptr)!=T_LIST)
				  continue;
			       temp = ChildOf(ptr);
			       if ((temp!=0) && (NodeType(temp)==T_ID)
				   && !strcmp(StringOf(temp), "EXPR_PRAGMA")) {
				 ReadExprPragma(SiblingOf(temp));
			       } 
			   }
			   expr->pragma = expr_pragma;
			}
			else {  /* op is an expression */
			   Expr exp;	/* 9-12 */
			   exp = Expression(op);
			   AddOperand(expr, ReduceExpr(exp));
			   RemoveExpr(exp);
			   /* LCW - read RETURN pragma - 9/29/97 */
			   op = SiblingOf(op);
			   expr_pragma = NULL;
			   for (ptr=op; ptr!=0; ptr=SiblingOf(ptr)) {
			       if (NodeType(ptr)!=T_LIST)
				  continue;
			       temp = ChildOf(ptr);
			       if ((temp!=0) && (NodeType(temp)==T_ID)
				   && !strcmp(StringOf(temp), "EXPR_PRAGMA")) {
				  ReadExprPragma(SiblingOf(temp));
			       } 
			   }
			   expr->pragma = expr_pragma;
			}
		    }
		    CastExpr(expr);
		    AddExpr2BB(bb, expr);
		    bb->cnt_type = CNT_RETURN;
		} else
		if (! strcmp(keyword, "GOTO")) {
		    /* bb_id%d) */
		    expr = NewExpr(OP_goto);
		    CastExpr(expr);
		    AddExpr2BB(bb, expr);
		    bb->cnt_type = CNT_GOTO;
		    if ((op==0)||(NodeType(op)!=T_INT))
	    	    	Punt("incorrect basic block description (5)");
		    link = NewBLink();
		    link->condition = TrueExpr();
		    link->source = bb->id;
		    link->destination = IntegerOf(op);
		    bb->destination = link;
		    /* LCW - read GOTO pragma if there is any - 9/22/97 */
		    op = SiblingOf(op);
		    expr_pragma = NULL;
		    for (ptr=op; ptr!=0; ptr=SiblingOf(ptr)) {
		        LIST temp;
			if (NodeType(ptr)!=T_LIST)
			   continue;
			temp = ChildOf(ptr);
			if ((temp!=0) && (NodeType(temp)==T_ID)
			    && !strcmp(StringOf(temp), "EXPR_PRAGMA")) {
			   ReadExprPragma(SiblingOf(temp));
			} 
		    }
		    expr->pragma = expr_pragma;
		    /* LCW - end of change */
		} else
		if (! strcmp(keyword, "IF")) {
		    Expr cond_expr, ppx;
		    LIST bbid;
		    int then_id, else_id;
		    /* expression (THEN bb_id%d) (ELSE bb_id%d)) */
		    if (op==0)
	    	    	Punt("incorrect basic block description (6)");
		    ppx = Expression(op);	/* 9-12 */
		    cond_expr = ReduceExpr(ppx);
		    RemoveExpr(ppx);
		    op = SiblingOf(op);
		    /* (THEN bb_id%d) */
		    if ((op==0)||(NodeType(op)!=T_LIST))
	    	    	Punt("incorrect basic block description (7)");
		    bbid = ChildOf(op);
		    if ((bbid==0)||(NodeType(bbid)!=T_ID)||
				strcmp(StringOf(bbid), "THEN"))
	    	    	Punt("incorrect basic block description (8)");
		    bbid = SiblingOf(bbid);
		    if ((bbid==0)||(NodeType(bbid)!=T_INT))
	    	    	Punt("incorrect basic block description (9)");
		    link = NewBLink();
		    link->condition = TrueExpr();
		    link->source = bb->id;
		    then_id = IntegerOf(bbid);
		    link->destination = then_id;
		    bb->destination = link;
		    op = SiblingOf(op);
		    /* (ELSE bb_id%d) */
		    if ((op==0)||(NodeType(op)!=T_LIST))
	    	    	Punt("incorrect basic block description (10)");
		    bbid = ChildOf(op);
		    if ((bbid==0)||(NodeType(bbid)!=T_ID)||
				strcmp(StringOf(bbid), "ELSE"))
	    	    	Punt("incorrect basic block description (11)");
		    bbid = SiblingOf(bbid);
		    if ((bbid==0)||(NodeType(bbid)!=T_INT))
	    	    	Punt("incorrect basic block description (12)");
		    else_id = IntegerOf(bbid);
		    /*
		     *	If both cases go to the same place.
		     *	automatically convert into a OP_goto
		     */
		    if (then_id==else_id) {
			AddExpr2BB(bb, cond_expr);
		    	expr = NewExpr(OP_goto);
		    	CastExpr(expr);
		    	AddExpr2BB(bb, expr);
		    	bb->cnt_type = CNT_GOTO;
		    } else {
		    	expr = NewExpr(OP_if);
		    	AddOperand(expr, cond_expr);
		    	CastExpr(expr);
		    	AddExpr2BB(bb, expr);
		    	bb->cnt_type = CNT_IF;
		    	link = NewBLink();
		    	link->condition = FalseExpr();
		    	link->source = bb->id;
		    	link->destination = else_id;
		    	bb->destination->next = link;
			/* SAM 6-93 read in pragma of IF */
		        op = SiblingOf(op);
                        expr_pragma = 0;
                        for (ptr=op; ptr!=0; ptr=SiblingOf(ptr)) {
                            LIST temp;
                            if (NodeType(ptr)!=T_LIST)
                                continue;
                            temp = ChildOf(ptr);
                            if ((temp!=0) && (NodeType(temp)==T_ID)
                                && !strcmp(StringOf(temp), "EXPR_PRAGMA")) {
                                ReadExprPragma(SiblingOf(temp));
                            }
                        }
                        /* hook up the pragma */
                        expr->pragma = expr_pragma;
			/* end changes */
		    }
		} else
		if (! strcmp(keyword, "SWITCH")) {
		    Expr ppx;
		    Expr swt_expr;  /* LCW - 9/30/97 */
		    /* expression (const_expr bb_id%d)+ (DEFAULT bb_id%d)?) */
		    if (op==0)
	    	    	Punt("incorrect basic block description (13)");
		    expr = NewExpr(OP_switch);
		    ppx = Expression(op);
		    AddOperand(expr, ReduceExpr(ppx));
		    RemoveExpr(ppx);
		    CastExpr(expr);
		    swt_expr = expr;  /* LCW - 9/30/97 */
		    AddExpr2BB(bb, expr);
		    bb->cnt_type = CNT_SWITCH;
		    op = SiblingOf(op);
		    /* (const_expr bb_id%d)+ (DEFAULT bb_id%d)?) */
		    while (op!=0) {
			LIST expr, bbid, next = SiblingOf(op);
			BLink ptr;
			LIST temp, lptr;  /* LCW - 9/30/97 */
			if (NodeType(op)!=T_LIST)
	    	    	    Punt("incorrect basic block description (14)");
		        /* LCW - check if op is a pragma - 9/30/97 */
			if (((temp=ChildOf(op))!=0) && (NodeType(temp)==T_ID) 
			   && (!strcmp(StringOf(temp), "EXPR_PRAGMA"))) {
			   expr_pragma = NULL;
			   /* read SWITCH pragma */
			   for (lptr=op; lptr!=0; lptr=SiblingOf(lptr)) {
			       if (NodeType(lptr)!=T_LIST)
				  continue;
			       temp = ChildOf(lptr);
			       if ((temp!=0) && (NodeType(temp)==T_ID)
				   && !strcmp(StringOf(temp), "EXPR_PRAGMA")) {
				 ReadExprPragma(SiblingOf(temp));
			       } 
			   }
			   swt_expr->pragma = expr_pragma;
			   break;
			}
			/* LCW - end of change */
			expr = ChildOf(op);
			if (expr==0)
	    	    	    Punt("incorrect basic block description (15)");
			/* create link */
		    	link = NewBLink();
			if ((NodeType(expr)==T_ID) &&
				! strcmp(StringOf(expr), "DEFAULT")) {
		    	    link->condition = DefaultExpr();
			} else {
			    Expr ppx; /* 9-12 */
			    ppx = Expression(expr);
			    link->condition = ReduceExpr(ppx);
			    RemoveExpr(ppx);
			    if (IsDefaultExpr(link->condition))
	    	    	        Punt("incorrect basic block description (16)");
			}
			bbid = SiblingOf(expr);
			if ((bbid==0)||(NodeType(bbid)!=T_INT))
	    	    	    Punt("incorrect basic block description (17)");
		    	link->source = bb->id;
		    	link->destination = IntegerOf(bbid);
			/* add it to the BLink.
			 * The order of switch cases must be preserved.
			 * This is because the profiler interface
			 * assumes implicit switch case IDs.
			 */
			ptr = bb->destination;
			if (ptr==0) {
		    	    bb->destination = link;
			} else {
			    while (ptr->next!=0) ptr = ptr->next;
			    ptr->next = link;
			}
			op = next;
		    }
		} else
	    	    Punt("incorrect basic block description (18)");
	    } else {
		/* assume others are simple expressions */
		expr = Expression(list);
	    	AddExpr2BB(bb, ReduceExpr(expr));
		RemoveExpr(expr);
	    }
NEXT_EXPR:
	    list = next;
	}
	/* add the basic block to the function definition */
	if (currentFuncDcl->blocks==0) {
	    currentFuncDcl->blocks = bb;
	} else {
	    Block ppp;
	    ppp = currentFuncDcl->blocks;
	    while (ppp->next!=0) ppp = ppp->next;
	    ppp->next = bb;
	}
}
/*-------------------------------------------------------------------*/
/* 
 * From the (destination) links of basic blocks, construct
 * the (source) links, and also fill the (src_bb) and (dest_bb)
 * fields of BLinks.
 */
static ConnectAllBasicBlocks() {
	Block bb, src_ptr, dest_ptr;
	int dest_id;
	BLink link, new, ptr;
	for (bb=currentFuncDcl->blocks; bb!=0; bb=bb->next) {
	    src_ptr = bb;
	    for (link=bb->destination; link!=0; link=link->next) {
		dest_id = link->destination;
		/* find the basic block */
		for (dest_ptr=currentFuncDcl->blocks; dest_ptr!=0; 
			dest_ptr=dest_ptr->next)
		    if (dest_ptr->id==dest_id) break;
		if (dest_ptr==0)
		    Punt("ConnectAllBasicBlocks: missing destination block");
		link->src_bb = src_ptr;
		link->dest_bb = dest_ptr;
		/* create a link for the dest bb */
		new = NewBLink();
		new->condition = CopyExpr(link->condition);
		new->source = link->source;
		new->destination = link->destination;
		new->src_bb = link->src_bb;
		new->dest_bb = link->dest_bb;
		ptr = dest_ptr->source;
		if (ptr==0) {
		    dest_ptr->source = new;
		} else {
		    while (ptr->next!=0) ptr=ptr->next;
		    ptr->next = new;
		}
	    }
	}
}
/*-------------------------------------------------------------------*/
/* Read in a function definition. */
/* The (ptr) fields of the function symbol table point 
 * to the return DeclSpec of the functions.
 */
static BeginFunc(list)
LIST list;
{
	LIST ptr, opcode, argument;
	char *fn_name, *keyword;
	/* list = fn_name%s */
	if ((list==0)||(NodeType(list)!=T_ID)) 
	    Punt("BeginFunc: missing fn_name%s");
	fn_name = StringOf(list);		/* function name */
	currentFuncDcl = NewFuncDcl();		/* OPEN a new Func scope */
	currentFuncDcl->name = fn_name;
	/** add a symbol table entry **/
	if (FindFunction(fn_name)!=0) {
	    fprintf(stderr, "=> function %s\n", fn_name);
	    Punt("multiple definition of a function");
	}
	AddFunction(fn_name, 0);	/* return type is not yt known */
	/* read subsequent lists until END_FN or EOF */
	for (;(ptr=GetNode())!=0; ptr=DisposeNode(ptr)) {
	    if (NodeType(ptr)==T_EOF)
		break;
	    Push(ptr);	/* level 1 */
	    if (NodeType(ptr)!=T_LIST)
		Punt("illegal 1st level function descriptor (1)");
	    opcode = ChildOf(ptr);
	    if ((opcode==0)||(NodeType(opcode)!=T_ID))
		Punt("illegal 1st level function descriptor (2)");
	    keyword = StringOf(opcode);
	    argument = SiblingOf(opcode);
	    if (! strcmp(keyword, "RETURN_TYPE")) {
		/* we use the symbol table ptr to refer
		 * to the return type.
		 */
		Symbol sym;
		sym = FindFunction(fn_name);
		sym->ptr = currentFuncDcl->type = DeclSpec(argument);
	    } else
	    if (! strcmp(keyword, "PARAMETER")) {
		ReadParameter(argument);
	    } else
	    if (! strcmp(keyword, "LVAR")) {
		ReadLocalVar(argument);
  	    } else
	    if (! strcmp(keyword, "FN_PRAGMA")) {
	        ReadFnPragma(argument);
	    } else
	    if (! strcmp(keyword, "ENTRY")) {
		/* get the ENTRY basic block id */
		if (NodeType(argument)!=T_INT)
		    Punt("missing ENTRY id");
		currentFuncDcl->entry_bb = IntegerOf(argument);
	    } else
	    if (! strcmp(keyword, "BB")) {
		ReadBasicBlock(argument);
	    } else
	    if (! strcmp(keyword, "END_FN")) {
		/* completed function definition */
		if ((argument==0)||(NodeType(argument)!=T_ID))
		    Punt("incorrect (END_FN fn_name) specifier");
		if (strcmp(StringOf(argument), fn_name))
		    Punt("mismatched (BEGIN_FN) and (END_FN)");
		break;
	    } else 
	    if (! strcmp(keyword, "PROFILE")) {
		/* id%d weight%f) */
		if ((argument==0)||(NodeType(argument)!=T_INT))
		    Punt("incorrect (PROFILE fn_id) specifier");
		currentFuncDcl->profile.fn_id = IntegerOf(argument);
		argument = SiblingOf(argument);
		if ((argument==0)||(NodeType(argument)!=T_REAL))
		    Punt("incorrect (PROFILE fn_id weight) specifier");
		currentFuncDcl->profile.weight = RealOf(argument);
		argument = SiblingOf(argument);
		currentFuncDcl->profile.calls = 0;
		/* (call_site%d callee%d weight%f) */
		for (; argument!=0; argument=SiblingOf(argument)) {
		    LIST site, callee, weight;
		    ProfCS new, ptr;
		    if (NodeType(argument)!=T_LIST) continue;
		    site = ChildOf(argument);
		    if ((site==0)||(NodeType(site)!=T_INT))
		      Punt("incorrect (PROFILE call_sites) specifier");
		    callee = SiblingOf(site);   
		    if ((callee==0)||(NodeType(callee)!=T_INT))
		      Punt("incorrect (PROFILE call_sites) specifier");
		    weight = SiblingOf(callee);
		    if ((weight==0)||(NodeType(weight)!=T_REAL))
		      Punt("incorrect (PROFILE call_sites) specifier");
		    new = NewProfCS();
		    new->call_site_id = IntegerOf(site);
		    new->callee_id = IntegerOf(callee);
		    new->weight = RealOf(weight);
		    ptr = currentFuncDcl->profile.calls;
		    if (ptr==0) {
			currentFuncDcl->profile.calls = new;
		    } else {
			while (ptr->next!=0) ptr=ptr->next;
			ptr->next = new;
		    }
		}
	    } else {
		Punt("illegal 1st level function descriptor (3)");
	    }
	    Pop();		/* level 1 */
	    Clear();	/* prevent use after delete */
	}
	/* complete all basic block connections */
	ConnectAllBasicBlocks();
	CheckSourceLink(currentFuncDcl->blocks);
	/* process the currentFuncDcl (see process.c) */
	ProcessFuncDcl(currentFuncDcl);	
	/* dispose the memory space taken by it.
	 * It is IMPORTANT that currentFuncDcl is set to 0.
	 * So the local definitions will no longer be visible
	 * to future expressions (see cast.c: E_var part).
	 */
	RemoveFuncDcl(currentFuncDcl);
	currentFuncDcl = 0;
}
/*-------------------------------------------------------------------*/
/*
 * Include files into the text.
 *	file_name*
 */
static IncludeFile(arg)
LIST arg;
{
	char *file_name;
	while (arg != 0) {
	    if (NodeType(arg) != T_STRING) 
		Punt("illegal (INCLUDE) statement");
	    file_name = StringOf(arg);
	    ProcessInclude(file_name);
	    arg = SiblingOf(arg);
	}
}
/*-------------------------------------------------------------------*/
/*
 * Process a list. If it is a header for several subsequent
 * lists, read and process those lists.
 */
ProcessList(list)
LIST list;
{
	LIST opcode, argument;
	char *keyword;
	/* initialize symbol tables */
	if (! ccode_init) SetUpSymbolTables();
	if (list==0) Punt("unexpected )");
	if (NodeType(list)==T_LIST) {
	    opcode = ChildOf(list);
	    if (NodeType(opcode)==T_ID) {
		keyword = StringOf(opcode);
		argument = SiblingOf(opcode);
		if (! strcmp(keyword, "DEF_STRUCT")) {
		    DefineStruct(argument);
		} else
		if (! strcmp(keyword, "DEF_UNION")) {
		    DefineUnion(argument);
		} else
		if (! strcmp(keyword, "DEF_ENUM")) {
		    DefineEnum(argument);
		} else
		if (! strcmp(keyword, "GVAR")) {
		    DefineGvar(argument);
		} else
		if (! strcmp(keyword, "BEGIN_FN")) {
		    BeginFunc(argument);
		} else
		if (! strcmp(keyword, "POSITION")) {
		    SetLinePosition(argument);
		} else
		if (! strcmp(keyword, "COMMENT")) {
		    ReadComment(argument);
		} else
		if (! strcmp(keyword, "INCLUDE")) {
		    IncludeFile(argument);
		} else {
		    print_node(list, 0);
		    Warning("illegal first level opcode");
		}
	    } else {
		/* ignore */
	    }
	} else {
	    print_node(list, 0);
	    Warning("illegal first level list");
	}
	Clear();	/* prevent use after delete */
}
/*===================================================================*/
/*
 * Set up all symbol tables. Insert default names into the
 * symbol tables.
 */
static int SetUpSymbolTables() {
	int tid;
	Symbol sym;
	if (ccode_init) return;
  	ccode_init = 1;
	/** create symbol tables **/
	SymbolTable[ST_VAR] = NewSymTbl(MAX_VAR_TBL_SIZE);
	SymbolTable[ST_STRUCT] = NewSymTbl(MAX_STRUCT_TBL_SIZE);
	SymbolTable[ST_UNION] = NewSymTbl(MAX_UNION_TBL_SIZE);
	SymbolTable[ST_ENUM] = NewSymTbl(MAX_ENUM_TBL_SIZE);
	SymbolTable[ST_STRING] = NewSymTbl(MAX_STRING_TBL_SIZE);
	SymbolTable[ST_FUNC] = NewSymTbl(MAX_FUNC_TBL_SIZE);
	SymbolTable[ST_OPCODE] = NewSymTbl(MAX_OPCODE_TBL_SIZE);
	/** insert default values **/
	tid = SymbolTable[ST_OPCODE];
	sym = AddSym(tid, "var", 0); sym->value = OP_var;
	sym = AddSym(tid, "enum", 0); sym->value = OP_enum;
	sym = AddSym(tid, "signed", 0); sym->value = OP_signed;
	sym = AddSym(tid, "unsigned", 0); sym->value = OP_unsigned;
	sym = AddSym(tid, "float", 0); sym->value = OP_float;
	/* BCC - added - 8/5/96 */
	sym = AddSym(tid, "double", 0); sym->value = OP_double;
	sym = AddSym(tid, "char", 0); sym->value = OP_char;
	sym = AddSym(tid, "string", 0); sym->value = OP_string;
	sym = AddSym(tid, "dot", 0); sym->value = OP_dot;
	sym = AddSym(tid, "arrow", 0); sym->value = OP_arrow;
	sym = AddSym(tid, "cast", 0); sym->value = OP_cast;
	sym = AddSym(tid, "expr_size", 0); sym->value = OP_expr_size;
	sym = AddSym(tid, "type_size", 0); sym->value = OP_type_size;
	sym = AddSym(tid, "quest", 0); sym->value = OP_quest;
	sym = AddSym(tid, "disj", 0); sym->value = OP_disj;
	sym = AddSym(tid, "conj", 0); sym->value = OP_conj;
	sym = AddSym(tid, "comma", 0); sym->value = OP_comma;
	sym = AddSym(tid, "assign", 0); sym->value = OP_assign;
	sym = AddSym(tid, "or", 0); sym->value = OP_or;
	sym = AddSym(tid, "xor", 0); sym->value = OP_xor;
	sym = AddSym(tid, "and", 0); sym->value = OP_and;
	sym = AddSym(tid, "eq", 0); sym->value = OP_eq;
	sym = AddSym(tid, "ne", 0); sym->value = OP_ne;
	sym = AddSym(tid, "lt", 0); sym->value = OP_lt;
	sym = AddSym(tid, "le", 0); sym->value = OP_le;
	sym = AddSym(tid, "ge", 0); sym->value = OP_ge;
	sym = AddSym(tid, "gt", 0); sym->value = OP_gt;
	sym = AddSym(tid, "rshft", 0); sym->value = OP_rshft;
	sym = AddSym(tid, "lshft", 0); sym->value = OP_lshft;
	sym = AddSym(tid, "add", 0); sym->value = OP_add;
	sym = AddSym(tid, "sub", 0); sym->value = OP_sub;
	sym = AddSym(tid, "mul", 0); sym->value = OP_mul;
	sym = AddSym(tid, "div", 0); sym->value = OP_div;
	sym = AddSym(tid, "mod", 0); sym->value = OP_mod;
	sym = AddSym(tid, "neg", 0); sym->value = OP_neg;
	sym = AddSym(tid, "not", 0); sym->value = OP_not;
	sym = AddSym(tid, "inv", 0); sym->value = OP_inv;
	sym = AddSym(tid, "abs", 0); sym->value = OP_abs;
	sym = AddSym(tid, "preinc", 0); sym->value = OP_preinc;
	sym = AddSym(tid, "predec", 0); sym->value = OP_predec;
	sym = AddSym(tid, "postinc", 0); sym->value = OP_postinc;
	sym = AddSym(tid, "postdec", 0); sym->value = OP_postdec;
	sym = AddSym(tid, "Aadd", 0); sym->value = OP_Aadd;
	sym = AddSym(tid, "Asub", 0); sym->value = OP_Asub;
	sym = AddSym(tid, "Amul", 0); sym->value = OP_Amul;
	sym = AddSym(tid, "Adiv", 0); sym->value = OP_Adiv;
	sym = AddSym(tid, "Amod", 0); sym->value = OP_Amod;
	sym = AddSym(tid, "Arshft", 0); sym->value = OP_Arshft;
	sym = AddSym(tid, "Alshft", 0); sym->value = OP_Alshft;
	sym = AddSym(tid, "Aand", 0); sym->value = OP_Aand;
	sym = AddSym(tid, "Aor", 0); sym->value = OP_Aor;
	sym = AddSym(tid, "Axor", 0); sym->value = OP_Axor;
	sym = AddSym(tid, "indr", 0); sym->value = OP_indr;
	sym = AddSym(tid, "addr", 0); sym->value = OP_addr;
	sym = AddSym(tid, "index", 0); sym->value = OP_index;
	sym = AddSym(tid, "call", 0); sym->value = OP_call;
/* NJW */
	sym = AddSym(tid, "sync", 0); sym->value = OP_sync;
/* WJN */
	/* LCW - 10/24/96 */
	sym = AddSym(tid, "nulldefine", 0); sym->value = OP_nulldefine;
}
/*===================================================================*/
/*
 *	This function is not used by CCODE.
 *	Some external modules may require reading multiple
 *	ccode files in one pass. This function allows
 *	the user to completely destroy the image created
 *	by reading the previous ccode file.
 */
ClearSymbolTable() {
	if (! ccode_init) return;
	/* 	++++
	 *	The space allocated for VarDcl, StructDcl, and UnionDcl 
	 *	definitions are not recycled in this version. 
	 *	If this turns out to cause problem, some garbage
	 *	collection should be done before calling CleanSymTbl()
	 */
	/* 
	 *	Clear symbol tables.
	 *	Except opcode and string table.
	 */
	ClearSymTbl(SymbolTable[ST_VAR]);
	ClearSymTbl(SymbolTable[ST_STRUCT]);
	ClearSymTbl(SymbolTable[ST_UNION]);
	ClearSymTbl(SymbolTable[ST_ENUM]);
	ClearSymTbl(SymbolTable[ST_FUNC]);
}
/*===================================================================*/
/*
 *	1) remove " " from the file name.
 *	2) try to open the file.
 */
void ReadIncludeFile(char *file)
{
	char name[512];
	int flag;
	flag = RemoveDQ(file, name, 512);
	if (flag<=0) Punt("illegal (INCLUDE) file name");
	flag = (lexOpen(name, 1) == 0);
	if (flag) Punt("cannot open include file");
	for (;;) {
	    LIST node;
	    node = GetNode();
	    if (node == 0) break;
	    if (NodeType(node) == T_EOF) break;
	    ProcessList(node);
	    node = DisposeNode(node);
	}
	lexClose(file);
}
/*===================================================================*/
