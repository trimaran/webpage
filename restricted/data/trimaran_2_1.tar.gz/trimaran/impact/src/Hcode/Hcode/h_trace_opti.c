/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_trace_opti.h
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>


extern char *FindString();	/* list.c */

#define DO_ZERO_WEIGHT_TOO		1
#define MIN_TRACE_SELECT_WEIGHT		0.5

/*--------------------------------------------------------------------*/
static Punt(mesg)
char *mesg;
{
    fprintf(stderr, "error in Trace Select: %s\n", mesg);
    exit(-1);
}

static int trace_experiment = 0;

#define E_node_weight		0
#define E_arc_weight		1
#define E_min_prob60		2
#define E_min_prob70		3
#define E_min_prob80		4
#define E_min_prob90		5
#define E_max_arc		6

static double exp_stat[7][TRECORD_SIZE];

/*
 *	Initialize trace experiment.
 */
static InitExperiment() {
    int i, j;
    for (i=0; i<7; i++)
	for (j=0; j<TRECORD_SIZE; j++) 
	    exp_stat[i][j] = 0.0;
}
/*
 *	Accumulate the result of single graphs.
 */
static AddResult(type, stat)
int type;
double stat[];
{
    double weight, nratio, oratio;
    double *rec;
    weight = stat[W_NODES];
    if (weight==0.0)		/* skip over non-executed functions */
	return;
    rec = exp_stat[type];
    rec[W_A] += stat[W_A];
    rec[W_B] += stat[W_B];
    rec[W_C] += stat[W_C];
    rec[W_D] += stat[W_D];
    rec[W_E] += stat[W_E];
    rec[W_BACK_EDGE] += stat[W_BACK_EDGE];
    rec[W_SEQUENTIAL] += stat[W_SEQUENTIAL];
    rec[N_NODES] += stat[N_NODES];
    rec[W_NODES] += stat[W_NODES];
    rec[N_ARCS] += stat[N_ARCS];
    rec[W_ARCS] += stat[W_ARCS];
    rec[N_TRACE] += stat[N_TRACE];
    if (rec[N_TRACE]!=0.0) {
    	nratio = stat[N_TRACE] / rec[N_TRACE];
    	oratio = 1.0 - nratio;
    	rec[L_TRACE] *= oratio;
    	rec[L_TRACE] += (stat[L_TRACE] * nratio);
    }
    rec[N_LOOP] += stat[N_LOOP];
    if (rec[N_LOOP]!=0.0) {
    	nratio = stat[N_LOOP] / rec[N_LOOP];
    	oratio = 1.0 - nratio;
    	rec[L_LOOP] *= oratio;
    	rec[L_LOOP] += (stat[L_LOOP] * nratio);
    }
    rec[N_ROOT] += stat[N_ROOT];
    rec[N_LEAF] += stat[N_LEAF];
}
static PrintRecord(F, stat, mesg)
FILE *F;
double stat[];
char *mesg;
{
    fprintf(F, "#------------------------------------------------------\n");
    fprintf(F, "# selection method = %s\n", mesg);
    fprintf(F, "%f\t#W_A\n", stat[W_A]);
    fprintf(F, "%f\t#W_B\n", stat[W_B]);
    fprintf(F, "%f\t#W_C\n", stat[W_C]);
    fprintf(F, "%f\t#W_D\n", stat[W_D]);
    fprintf(F, "%f\t#W_E\n", stat[W_E]);
    fprintf(F, "%f\t#W_BACK_EDGE\n", stat[W_BACK_EDGE]);
    fprintf(F, "%f\t#W_SEQUENTIAL\n", stat[W_SEQUENTIAL]);
    fprintf(F, "%f\t#N_NODES\n", stat[N_NODES]);
    fprintf(F, "%f\t#W_NODES\n", stat[W_NODES]);
    fprintf(F, "%f\t#N_ARCS\n", stat[N_ARCS]);
    fprintf(F, "%f\t#W_ARCS\n", stat[W_ARCS]);
    fprintf(F, "%f\t#N_TRACE\n", stat[N_TRACE]);
    fprintf(F, "%f\t#L_TRACE\n", stat[L_TRACE]);
    fprintf(F, "%f\t#N_LOOP\n", stat[N_LOOP]);
    fprintf(F, "%f\t#L_LOOP\n", stat[L_LOOP]);
    fprintf(F, "%f\t#N_ROOT\n", stat[N_ROOT]);
    fprintf(F, "%f\t#N_LEAF\n", stat[N_LEAF]);
    fprintf(F, "\n");
}
static char *SelectionMethod(type)
int type;
{
    switch (type) {
    case E_node_weight: return "Selection By Node Weight";
    case E_arc_weight: return "Selection By Arc Weight";
    case E_min_prob60: return "Minimum Probability = 0.60";
    case E_min_prob70: return "Minimum Probability = 0.70";
    case E_min_prob80: return "Minimum Probability = 0.80";
    case E_min_prob90: return "Minimum Probability = 0.90";
    case E_max_arc: return "Selection From Maximum Arc";
    default : return "???";
    }
}
/*
 *	Print out the experimental result.
 *	Write to F_output.trace
 */
PrintTraceOptimizationResult() {
    int i, max;
    double max_weight;
    char fname[512];
    FILE *F;
    if (! trace_experiment)
	return;
    sprintf(fname, "%s.trace", F_output);
    F = fopen(fname, "w");
    if (F==0) Punt("Trace Selection/Placement: cannot write result");
    fprintf(F, "\n");
    fprintf(F, "### Trace Selection/Placement Result (%s)\n", F_input);
    /*
     *	Find the maximum sequential locality.
     */
    max = 0;
    max_weight = exp_stat[0][W_SEQUENTIAL];
    for (i=1; i<7; i++) {
	if (exp_stat[i][W_SEQUENTIAL] >= max_weight) {
	    max = i;
	    max_weight = exp_stat[i][W_SEQUENTIAL];
	}
    }
    fprintf(F, "# max sequentiality : %s\n", SelectionMethod(max));
    /*
     *	Find the most in-trace transition.
     */
    max = 0;
    max_weight = exp_stat[0][W_E];
    for (i=1; i<7; i++) {
	if (exp_stat[i][W_E] >= max_weight) {
	    max = i;
	    max_weight = exp_stat[i][W_E];
	}
    }
    fprintf(F, "# max in-trace transition : %s\n", SelectionMethod(max));
    /*
     *	Find the most off-trace transition.
     */
    max = 0;
    max_weight = exp_stat[0][W_B] + exp_stat[0][W_C] + exp_stat[0][W_D];
    for (i=1; i<7; i++) {
	double weight;
	weight = exp_stat[i][W_B] + exp_stat[i][W_C] + exp_stat[i][W_D];
	if (weight >= max_weight) {
	    max = i;
	    max_weight = weight;
	}
    }
    fprintf(F, "# max off-trace transition : %s\n", SelectionMethod(max));
    /*
     *	Print detailed result.
     */
    PrintRecord(F, exp_stat[E_node_weight], "Selection By Node Weight");
    PrintRecord(F, exp_stat[E_arc_weight], "Selection By Arc Weight");
    PrintRecord(F, exp_stat[E_min_prob60], "Minimum Probability = .6");
    PrintRecord(F, exp_stat[E_min_prob70], "Minimum Probability = .7");
    PrintRecord(F, exp_stat[E_min_prob80], "Minimum Probability = .8");
    PrintRecord(F, exp_stat[E_min_prob90], "Minimum Probability = .9");
    PrintRecord(F, exp_stat[E_max_arc], "Select From Maximum Arc");
}
/*
 *	Apply trace experiments.
 *	Record the selection results.
 */
static ApplyExperiment(fn_name, graph, expr)
char fn_name;
FGraph graph;
int expr;
{
    double stat[TRECORD_SIZE];
    static init = 0;
    if (! init) {
	InitExperiment();
	init = 1;
    }
    switch (expr) {
    case 1:
    	TraceSelection(graph, SELECT_BY_NODE_WEIGHT, 0.0);
    	ReportSelectionResult(graph, stat);
    	AddResult(E_node_weight, stat);
	break;
    case 2:
    	TraceSelection(graph, SELECT_BY_ARC_WEIGHT, 0.0);
    	ReportSelectionResult(graph, stat);
    	AddResult(E_arc_weight, stat);
	break;
    case 3:
    	TraceSelection(graph, SELECT_BY_MIN_PROB, 0.6);
    	ReportSelectionResult(graph, stat);
    	AddResult(E_min_prob60, stat);
	break;
    case 4:
    	TraceSelection(graph, SELECT_BY_MIN_PROB, 0.7);
    	ReportSelectionResult(graph, stat);
    	AddResult(E_min_prob70, stat);
	break;
    case 5:
    	TraceSelection(graph, SELECT_BY_MIN_PROB, 0.8);
    	ReportSelectionResult(graph, stat);
    	AddResult(E_min_prob80, stat);
	break;
    case 6:
    	TraceSelection(graph, SELECT_BY_MIN_PROB, 0.9);
    	ReportSelectionResult(graph, stat);
    	AddResult(E_min_prob90, stat);
	break;
    case 7:
    	TraceSelection(graph, SELECT_BY_MAX_ARC, 0.0);
    	ReportSelectionResult(graph, stat);
    	AddResult(E_max_arc, stat);
	break;
    default:
	break;
    }
}
/*--------------------------------------------------------------------*/
/*
 *	Apply trace selection and placement.
 *	The purpose is to achieve better sequential locality.
 */
TraceOptimization(func)
FuncDcl func;
{
    Pragma pragma;
    FGraph graph;
    Block bb;
    Node node;
    char line[512];
    Block bb_list[MAX_BB_IN_TRACE];
    int bb_id[MAX_BB_IN_TRACE];
    int n_bb, i;
    if (! DO_ZERO_WEIGHT_TOO) {
    	if (func->profile.weight < MIN_TRACE_SELECT_WEIGHT) {
    	    AddFunctionPragma(func, FindString("\"optimize.trace (0)\""));
	    return;
	}
    }
    if (H_trace_selection_method > 1)
	trace_experiment = H_trace_selection_method;
#ifdef TESTING
    pragma = FindFunctionPragma(func, "\"profiled");
    if (pragma==0) {
	fprintf(stderr, "# %s\n", func->name);
	Punt("no profile information");
    }
#endif
    /** create a new graph **/
    graph = NewGraph();
    /** create nodes **/
    for (bb=func->blocks; bb!=0; bb=bb->next) {
	Node node;
	node = NewNode();
	nodeId(node) = bb->id;
	nodeWeight(node) = bb->profile.weight;
	AddNode(graph, node);	/* bi-directional association */
	bb->ext = node;		
    }
    graph->root = FindNode(graph, func->entry_bb);
    /** create arcs **/
    for (bb=func->blocks; bb!=0; bb=bb->next) {
	BLink link;
	ProfArc ar;
	/** define basic connections **/
	for (link=bb->destination; link!=0; link=link->next) {
	    Node src, dest;
	    Arc arc;
	    src = FindNode(graph, link->source);
	    dest = FindNode(graph, link->destination);
	    if ((src==0)||(dest==0))
		Punt("internal error 1");
	    /* 
	     *	These two nodes may have been conected (switch)
	     *	Several cases can all go to the same destination block.
	     *	In this case, no new arc is created.
	     */
	    arc = FindSrcArc(src, dest, 0);
	    if (arc==0) {	/* create if necessary */
	    	ConnectNodes(src, dest, 0);
	    	arc = FindSrcArc(src, dest, 0);
	    }
	    if (arc==0) Punt("internal error 2");
	    arcWeight(arc) = 0.0;
	    arc = FindDestArc(src, dest, 0);
	    if (arc==0) Punt("internal error 3");
	    arcWeight(arc) = 0.0;
	}
	/** add profile information **/
	for (ar=bb->profile.destination; ar!=0; ar=ar->next) {
	    Node src, dest;
	    Arc arc;
	    src = bb->ext;
	    dest = FindNode(graph, ar->bb_id);
	    if ((src==0)||(dest==0)) {
		fprintf(stderr, "### func=%s\n", func->name);
	  	fprintf(stderr, "### src=%d, dest=%d\n", bb->id, ar->bb_id);
		Punt("internal error 4");
	    }
	    /* 
	     *	These two nodes may have been conected (switch)
	     *	Several cases can all go to the same destination block.
	     *	In this case, no new arc is created, but the weight 
	     *	is incremented.
	     */
	    arc = FindSrcArc(src, dest, 0);
	    if (arc==0) Punt("internal error 5");
	    arcWeight(arc) += ar->weight;
	    arc = FindDestArc(src, dest, 0);
	    if (arc==0) Punt("internal error 6");
	    arcWeight(arc) += ar->weight;
	}
    }
    /** apply trace selection **/
    if (trace_experiment)
	ApplyExperiment(func->name, graph, trace_experiment);
    TraceSelection(graph, SELECT_BY_MIN_PROB, BEST_TRACE_PROB);
    /** reconstruct function body, according to trace selection result **/
    node = graph->nodes;
    if (nodeId(node)!=func->entry_bb)
	Punt("ENTRY block is not the first block");
    n_bb = 0;
    for (node=graph->nodes; node!=0; node=nextNode(node)) {
	bb_id[n_bb] = nodeId(node);
    	for (bb=func->blocks; bb!=0; bb=bb->next) {
	    if (bb->id==nodeId(node)) {
		bb_list[n_bb] = bb;
		break;
	    }
	}
	if (bb==0) Punt("corrupted bb list after trace placement");
	sprintf(line, "\"trace.%d\"", nodeType(node));
	AddBlockPragma(bb, FindString(line));
	n_bb++;
	if (n_bb>=(MAX_BB_IN_TRACE-1))
	    Punt("too many blocks");
    }
    bb_list[n_bb] = 0;
    for (i=0; i<n_bb; i++) {
	bb_list[i]->next = bb_list[i+1];
    }
    AddFunctionPragma(func, FindString("\"optimize.trace\""));
}

