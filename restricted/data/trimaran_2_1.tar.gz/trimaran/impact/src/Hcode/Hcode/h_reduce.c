/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_reduce.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>


extern Expr CopyNode();		/* flatten.c */
extern Type DominantType();	/* cast.c */
extern int EqualStrength();	/* cast.c */
extern Expr UpgradeType();	/* cast.c */

/* BCC - used for reducing cast - 6/8/95 */
int H_CHAR_SIZE;
int H_SHORT_SIZE;
int H_INT_SIZE;
int H_LONG_SIZE;

unsigned long H_UNSIGNED_CHAR_MASK;
unsigned long H_UNSIGNED_SHORT_MASK;
unsigned long H_UNSIGNED_INT_MASK;

int init_mspec;

static Punt(mesg)
char *mesg;
{
    fprintf(stderr, "ReduceExpr: %s\n", mesg);
    exit(-1);
}
/*
 *	Bring the type up-to-date.
 *	Assume type is always more powerful than expr->type.
 */
static Expr Cast(expr, type)
Expr expr;
Type type;
{
    Type type1 = expr->type;
    if (! EqualStrength(type, type1))
	expr = UpgradeType(expr, type);
    return expr;
}
/*
 *	Compare against zero.
 *	If zero, returns 0.
 *	If not-zero, the resultant expression should return 1.
 */
static Expr NotZero(expr)
Expr expr;
{
    Expr new;
    if (expr==0) Punt("NotZero: expr is nil");
    if (IsBooleanExpr(expr)) {
	return expr;
    } else {
	new = NewInstExpr(OP_ne, IntType());
	AddOperand(new, expr);
	AddOperand(new, NewIntExpr(0));
	return new;
    }
}

/* BCC - added a function to get the size of integer types - 6/8/95 */
H_GetIntegerSize()
{
    _M_Type mtype;
    int i;

    init_mspec = 1;
    M_char(&mtype, 0);
    H_CHAR_SIZE = mtype.size;
    M_short(&mtype, 0);
    H_SHORT_SIZE = mtype.size;
    M_int(&mtype, 0);
    H_INT_SIZE = mtype.size;
    M_long(&mtype, 0);
    H_LONG_SIZE = mtype.size;

    for (i=1, H_UNSIGNED_CHAR_MASK=1; i < H_CHAR_SIZE; i++)
	H_UNSIGNED_CHAR_MASK = (H_UNSIGNED_CHAR_MASK << 1) + 1;
    for (i=1, H_UNSIGNED_SHORT_MASK=1; i < H_SHORT_SIZE; i++)
	H_UNSIGNED_SHORT_MASK = (H_UNSIGNED_SHORT_MASK << 1) + 1;
    for (i=1, H_UNSIGNED_INT_MASK=1; i < H_INT_SIZE; i++)
	H_UNSIGNED_INT_MASK = (H_UNSIGNED_INT_MASK << 1) + 1;
}

/*
 *	Apply constant folding.
 *	Apply algebraic operations to reduce the expression.
 *	OP_type_size and OP_expr_size nodes can only be reduced
 *	during RTL generation phase. Otherwise, ignore optimizing
 *	OP_type_size and OP_expr_size nodes (assume not reducible)
 *	+++ better garbage collection of nodes is necessary in the future.
 * GEH - added statements to set sibling pointers to NIL for op1 and op2
 *	 in places where it is necessary.  This prevents tag-along siblings
 *	 when op1 is being returned.  6/29/93.
 */
Expr ReduceExpr(expr)
Expr expr;
{
    Expr new;
    /* BCC - added Expr temp to temporarily hold return value - 6/10/95 */
    Expr temp;
    int i;
    Expr op;
    Expr op1, op2, op3;
    double d1, d2;
    long l1, l2;
    short scalar;
    /*
     *	Basic cases: leaf-level nodes. 
     */
    if (expr==0) 
	return 0;
    switch (expr->opcode) {
    case OP_var:
    case OP_signed:
    case OP_unsigned:
    case OP_char:
    case OP_float:
    /* BCC - added - 8/5/96 */
    case OP_double:
    case OP_string:
    	return CopyExpr(expr);
    case OP_enum: 	/* it is not desirable do not optimize enum as a */
			/* constant now, because of reverse-translation. **/
    	return CopyExpr(expr);
    case OP_type_size:
    	return CopyExpr(expr);
    case OP_expr_size:
    	return CopyExpr(expr);
    default:
	break;
    }
    /* 
     *	Compress all operands first.
     */
    new = CopyNode(expr);	/* copy the root node only */
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	AddOperand(new, ReduceExpr(op));
    }
    /* 
     *	Obtain the first three operands.
     *	Not all operations use these many, 
     *	but it is easier this way. 
     */
    op1 = ExprOperand(1, new);
    op2 = ExprOperand(2, new);
    op3 = ExprOperand(3, new);
    /* 
     *	Apply constant folding on the current node.
     */
    switch (new->opcode) {
    /* control */
    case OP_return :
    case OP_goto :
    case OP_if :
    case OP_switch :	/* cannot be reduced here. */
	return new;
    case OP_quest :
	/*	1) true ? A : B 	=> A
	 *	2) false ? A : B	=> B
	 */
	if (IsConstZero(op1)) {
	    new->operands = 0;
	    op2->sibling = 0;
	    return Cast(op3, new->type);
	}
	if (IsConstNonZero(op1)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    op2->sibling = 0;
	    return Cast(op2, new->type);
	}
	return new;
    case OP_disj :
	/*	1) true || B		=> true
	 *	2) false || B		=> (B!=0)
	 *	3) A || true		=> (A, true)
	 *	4) A || false		=> (A!=0)
	 */
	if (IsConstNonZero(op1))
	    return NewIntExpr(1);	/* true */
	if (IsConstZero(op1)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return NotZero(op2);	/* B!=0 */
	}
	if (IsConstNonZero(op2)) {
	    if (IsSideEffectFree(op1))	/* no need to execute A */
		return NewIntExpr(1);	/* true */
	    new = NewInstExpr(OP_comma, IntType());
	    op1->sibling = 0;
	    AddOperand(new, op1);
	    AddOperand(new, NewIntExpr(1));
	    return new;			/* (A, true) */
	} 
	if (IsConstZero(op2)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return NotZero(op1);
	}
	return new;
    case OP_conj :
	/*	1) false && B		=> false
	 *	2) true && B		=> (B!=0)
	 *	3) A && true		=> (A!=0)
	 *	4) A && false		=> (A, false)
	 */
	if (IsConstZero(op1))
	    return NewIntExpr(0);	/* false */
	if (IsConstNonZero(op1)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return NotZero(op2);	/* B!=0 */
	}
	if (IsConstNonZero(op2)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return NotZero(op1);	/* A!=0 */
	}
	if (IsConstZero(op2)) {
	    if (IsSideEffectFree(op1))	/* no need to execute A */
		return NewIntExpr(0);	/* false */
	    new = NewInstExpr(OP_comma, IntType());
	    AddOperand(new, op1);
	    AddOperand(new, NewIntExpr(0));
	    return new;			/* (A, false) */
	}
	return new;
    case OP_or :
	/*	1) 0 or B		=> B
	 *	2) A or 0		=> A
	 *	3) A and B are constants.
	 */
	if (IsConstZero(op1)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op2, new->type);
	}
	if (IsConstZero(op2)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op1, new->type);	
	}
	if (IsIntegralExpr(op1) && IsIntegralExpr(op2))
	    return NewIntExpr(IntegralExprValue(op1) | IntegralExprValue(op2));
	return new;
    case OP_xor :
	/*	1) 0 xor B		=> B
	 *	2) A xor 0		=> A
	 *	3) A and B are both constants
	 */
	if (IsConstZero(op1)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op2, new->type);
	}
	if (IsConstZero(op2)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op1, new->type);
	}
	if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) 
	    return NewIntExpr(IntegralExprValue(op1) ^ IntegralExprValue(op2));
	return new;
    case OP_and :
	/*
	 *	1) A and B are both constants
	 */
	if (IsIntegralExpr(op1) && IsIntegralExpr(op2))
	    return NewIntExpr(IntegralExprValue(op1) & IntegralExprValue(op2));
	return new;
    case OP_eq :
    case OP_ne :
    case OP_lt :
    case OP_le :
    case OP_ge :
    case OP_gt :
	/*
	 *	1) if A and B are both constants.
	 */
	if (IsConstNumber(op1) && IsConstNumber(op2)) {
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1))
		d1 = op1->value.real;
	    else if (IsIntegralExpr(op1))
		d1 = (double) IntegralExprValue(op1);
	    else Punt("OP_compare 1");
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op))
		d2 = op2->value.real;
	    else if (IsIntegralExpr(op2))
		d2 = (double) IntegralExprValue(op2);
	    else Punt("OP_compare 2");
	    switch (new->opcode) {
	    case OP_eq : return NewIntExpr(d1==d2);
	    case OP_ne : return NewIntExpr(d1!=d2);
	    case OP_lt : return NewIntExpr(d1<d2);
	    case OP_le : return NewIntExpr(d1<=d2);
	    case OP_ge : return NewIntExpr(d1>=d2);
	    case OP_gt : return NewIntExpr(d1>d2);
	    }
	    Punt("OP_compare 3");
	}
	return new;
case OP_rshft :
	case OP_lshft :
	/* 	1) A >> 0	=> A
	 *	2) A << 0	=> A
	 *	3) both A and B are constant.
	 */
	if (IsConstZero(op2)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op1, new->type);
	}
	if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
	    int unsigned_A;
	    unsigned_A = (op1->type->type & TY_UNSIGNED);
	    l1 = IntegralExprValue(op1);
	    l2 = IntegralExprValue(op2);
	    if (new->opcode==OP_rshft) {
	   	if (unsigned_A) {
		    new = NewIntExpr( ((unsigned) l1) >> l2 );
		    new->type->type |= TY_UNSIGNED;
		    return new;
		} else
		    return NewIntExpr(l1 >> l2);
	    }
	    if (new->opcode==OP_lshft) {
	   	if (unsigned_A) {
		    new = NewIntExpr( ((unsigned) l1) << l2 );
		    new->type->type |= TY_UNSIGNED;
		    return new;
		} else
		    return NewIntExpr(l1 << l2);
	    }
	    Punt("OP_shift : 1");
	}
	return new;
    case OP_add :
	/* 	1) A + 0	=> A
	 *	2) 0 + B	=> B
	 */
	if (IsConstZero(op1)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op2, new->type);
	}
	if (IsConstZero(op2)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op1, new->type);
	}
	scalar = 1;	/* expect all integral values. */
	if (IsConstNumber(op1) && IsConstNumber(op2)) {
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1)) {
		scalar = 0;
		d1 = op1->value.real;
	    } else
	    if (IsIntegralExpr(op1)) {
		l1 = IntegralExprValue(op1);
		d1 = (double) l1;
	    } else
		Punt("OP_arithmetic 1");
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op2)) {
		scalar = 0;
		d2 = op2->value.real;
	    } else
	    if (IsIntegralExpr(op2)) {
		l2 = IntegralExprValue(op2);
		d2 = (double) l2;
	    } else
		Punt("OP_arithmetic 2");
	    if (scalar) {
		if ((op1->type->type & TY_UNSIGNED) ||
			  (op2->type->type & TY_UNSIGNED)) {
		    new = NewIntExpr((unsigned) l1 + (unsigned) l2);
		    new->type->type |= TY_UNSIGNED;
		    return new;
		} else
		    return NewIntExpr(l1 + l2);
	    } else
		/* BCC - 8/5/96
		return NewRealExpr(d1 + d2);
		*/
		return (IsFloatExpr(op1) && IsFloatExpr(op2)) ? 
			NewFloatExpr(d1 + d2) : NewDoubleExpr(d1 + d2);
	}
	return new;
    case OP_sub :
	/*	1) A - 0	=> A	*/
	if (IsConstZero(op2)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op1, new->type);
	}
	scalar = 1;	/* expect all integral values. */
	if (IsConstNumber(op1) && IsConstNumber(op2)) {
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1)) {
		scalar = 0;
		d1 = op1->value.real;
	    } else
	    if (IsIntegralExpr(op1)) {
		l1 = IntegralExprValue(op1);
		d1 = (double) l1;
	    } else
		Punt("OP_arithmetic 1");
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op2)) {
		scalar = 0;
		d2 = op2->value.real;
	    } else
	    if (IsIntegralExpr(op2)) {
		l2 = IntegralExprValue(op2);
		d2 = (double) l2;
	    } else
		Punt("OP_arithmetic 2");
	    if (scalar) {
		if ((op1->type->type & TY_UNSIGNED) ||
			  (op2->type->type & TY_UNSIGNED)) {
		    new = NewIntExpr((unsigned) l1 - (unsigned) l2);
		    new->type->type |= TY_UNSIGNED;
		    return new;
		} else
		    return NewIntExpr(l1 - l2);
	    } else
		/* BCC - 8/5/96 
		return NewRealExpr(d1 - d2);
		*/
		return (IsFloatExpr(op1) && IsFloatExpr(op2)) ? 
			NewFloatExpr(d1 - d2) : NewDoubleExpr(d1 - d2);

	}
	return new;
    case OP_mul :
	/*	1) A * 0	=> (A, 0)
	 *	2) 0 * B	=> (B, 0)
	 *	3) A * 1	=> A
	 *	4) 1 * B	=> B
	 *	5) A and B are constants
	 */
	if (IsConstZero(op2)) {
	    if (IsSideEffectFree(op1)) {		/* 0 */
		/* BCC - 8/5/96 */
	    	if (IsDoubleExpr(new)) 
	    	    return NewDoubleExpr(0.0);
	    	else if (IsFloatExpr(new)) 
	    	    return NewFloatExpr(0.0);
	    	else
	    	    return NewIntExpr(0);
	    }
	    new = NewInstExpr(OP_comma, new->type);	/* (A, 0) */
	    op1->sibling = 0;
	    AddOperand(new, op1);
	    /* BCC - 8/5/96 */
	    if (IsDoubleExpr(new))
	    	AddOperand(new, NewDoubleExpr(0.0));
	    else if (IsFloatExpr(new))
	    	AddOperand(new, NewFloatExpr(0.0));
	    else
	    	AddOperand(new, NewIntExpr(0));
	    return new;
	}
	if (IsConstZero(op1)) {
	    if (IsSideEffectFree(op2)) {		/* 0 */
		/* BCC - 8/5/96 */
	    	if (IsDoubleExpr(new))
	    	    return NewDoubleExpr(0.0);
		else if (IsFloatExpr(new))
		    return NewFloatExpr(0.0);
	    	else
	    	    return NewIntExpr(0);
	    }
	    new = NewInstExpr(OP_comma, new->type);	/* (B, 0) */
	    op1->sibling = 0;
	    AddOperand(new, op2);
	    /* BCC - 8/5/96 */
	    if (IsDoubleExpr(new))
	    	AddOperand(new, NewDoubleExpr(0.0));
	    else if (IsFloatExpr(new))
	    	AddOperand(new, NewFloatExpr(0.0));
	    else
	    	AddOperand(new, NewIntExpr(0));
	    return new;
	}
	if (IsConstOne(op2)) {				/* A */
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op1, new->type);
	}
	if (IsConstOne(op1)) {				/* B */
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op2, new->type);
	}
	scalar = 1;	/* expect all integral values. */
	if (IsConstNumber(op1) && IsConstNumber(op2)) {
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1)) {
		scalar = 0;
		d1 = op1->value.real;
	    } else
	    if (IsIntegralExpr(op1)) {
		l1 = IntegralExprValue(op1);
		d1 = (double) l1;
	    } else
		Punt("OP_arithmetic 1");
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op2)) {
		scalar = 0;
		d2 = op2->value.real;
	    } else
	    if (IsIntegralExpr(op2)) {
		l2 = IntegralExprValue(op2);
		d2 = (double) l2;
	    } else
		Punt("OP_arithmetic 2");
	    if (scalar) {
		if ((op1->type->type & TY_UNSIGNED) ||
			  (op2->type->type & TY_UNSIGNED)) {
		    new = NewIntExpr((unsigned) l1 * (unsigned) l2);
		    new->type->type |= TY_UNSIGNED;
		    return new;
		} else
		    return NewIntExpr(l1 * l2);
	    } else
		/* BCC - 8/5/96 
		return NewRealExpr(d1 * d2);
		*/
		return (IsFloatExpr(op1) && IsFloatExpr(op2)) ? 
			NewFloatExpr(d1 * d2) : NewDoubleExpr(d1 * d2);
	}
	return new;
    case OP_div :
	/*	1) A / 1	=> A
	 *	2) A / 0	=> report error
	 *	3) both A and B are constants.
	 */
	if (IsConstOne(op2)) {
	    new->operands = 0;
	    op1->sibling = 0;
	    return Cast(op1, new->type);
	}
	if (IsConstZero(op2)) 
	    Punt("constant folding : division by zero found");
	scalar = 1;	/* expect all integral values. */
	if (IsConstNumber(op1) && IsConstNumber(op2)) {
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1)) {
		scalar = 0;
		d1 = op1->value.real;
	    } else
	    if (IsIntegralExpr(op1)) {
		l1 = IntegralExprValue(op1);
		d1 = (double) l1;
	    } else
		Punt("OP_arithmetic 1");
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op2)) {
		scalar = 0;
		d2 = op2->value.real;
	    } else
	    if (IsIntegralExpr(op2)) {
		l2 = IntegralExprValue(op2);
		d2 = (double) l2;
	    } else
		Punt("OP_arithmetic 2");
	    if (scalar) {
		if ((op1->type->type & TY_UNSIGNED) ||
			  (op2->type->type & TY_UNSIGNED)) {
		    new = NewIntExpr((unsigned) l1 / (unsigned) l2);
		    new->type->type |= TY_UNSIGNED;
		    return new;
		} else
		    return NewIntExpr(l1 / l2);
	    } else
		/* BCC - 8/5/96
		return NewRealExpr(d1 / d2);
		*/
		return (IsFloatExpr(op1) && IsFloatExpr(op2)) ? 
			NewFloatExpr(d1 / d2) : NewDoubleExpr(d1 / d2);
	}
	return new;
    case OP_mod :
	/*	1) A % 0	=> report error
	 *	2) 0 % B	=> 0
	 *	3) A and B are constants.
	 */
	if (IsConstZero(op2))
	    Punt("constant folding : mod by zero found");
	if (IsConstZero(op1))
	    return NewIntExpr(0);
	if (IsIntegralExpr(op1) && IsIntegralExpr(op2)) {
	    l1 = IntegralExprValue(op1);
	    l2 = IntegralExprValue(op2);
	    return NewIntExpr(l1 % l2);
	}
	return new;

/* BCC - if original expression is unsigned, then the new expression is also
	 unsigned 						- 6/10/95 */

    case OP_neg :
#if 0
	if (IsConstNumber(op1)) {
	    if (IsIntegralExpr(op1))
		return NewIntExpr(- IntegralExprValue(op1));
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1))
		return NewRealExpr(- op1->value.real);
	    Punt("constant folding : OP_neg");
	}
#endif
	if (IsConstNumber(op1)) {
	    if (IsIntegralExpr(op1)) {
		temp = NewIntExpr(- IntegralExprValue(op1));
		temp->type->type = op1->type->type;
		return temp;
	    };
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1)) {
		temp = IsFloatExpr(op1) ? NewFloatExpr(- op1->value.real) :
					  NewDoubleExpr(- op1->value.real);
		temp->type->type = op1->type->type;
		return temp;
	    };
	    Punt("constant folding : OP_neg");
	}
	return new;

/* BCC - if original expression is unsigned, then the new expression is also
	 unsigned 						- 6/10/95 */

    case OP_not :
#if 0
	if (IsConstNumber(op1)) {
	    if (IsIntegralExpr(op1))
		return NewIntExpr(! IntegralExprValue(op1));
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1))
		return NewIntExpr(! op1->value.real);
	    Punt("constant folding : OP_not");
	}
#endif
	if (IsConstNumber(op1)) {
	    if (IsIntegralExpr(op1)) {
		temp = NewIntExpr(! IntegralExprValue(op1));
                temp->type->type = op1->type->type;
                return temp;
	    };
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1)) {
		temp = NewIntExpr(! op1->value.real);
                temp->type->type = op1->type->type;
                return temp;
	    };
	    Punt("constant folding : OP_not");
	}
	return new;

/* BCC - if original expression is unsigned, then the new expression is also
	 unsigned 						- 6/10/95 */

    case OP_inv :
#if 0
	if (IsIntegralExpr(op1))
	    return NewIntExpr(~ IntegralExprValue(op1));
#endif
	if (IsIntegralExpr(op1)) {
	    temp = NewIntExpr(~ IntegralExprValue(op1));
	    temp->type->type = op1->type->type;
	    return temp;
	};
	return new;

/* BCC - if original expression is unsigned, then the new expression is also
	 unsigned 						- 6/10/95 */

    case OP_abs :
#if 0
	if (IsConstNumber(op1)) {
	    if (IsIntegralExpr(op1)) {
	    	l1 = IntegralExprValue(op1);
	    	if (l1<0) l1 = -l1;
		return NewIntExpr(l1);
	    }
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1)) {
		d1 = op1->value.real;
		if (d1<0.0) d1 = -d1;
		return NewRealExpr(d1);
	    }
	    Punt("constant folding : OP_abs");
	}
#endif
	if (IsConstNumber(op1)) {
	    if (IsIntegralExpr(op1)) {
	    	l1 = IntegralExprValue(op1);
	    	if (l1<0) l1 = -l1;
		temp = NewIntExpr(l1);
                temp->type->type = op1->type->type;
                return temp;
	    }
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1)) {
		d1 = op1->value.real;
		if (d1<0.0) d1 = -d1;
		/* BCC - 8/5/96
		temp = NewRealExpr(d1);
		*/
		temp = IsFloatExpr(op1) ? NewFloatExpr(d1) : NewDoubleExpr(d1);
                temp->type->type = op1->type->type;
                return temp;
	    }
	    Punt("constant folding : OP_abs");
	}
	return new;
    case OP_cast : {
	/*
	 *	Do not optimize for non-scalars (including pointers).
	 *	But during the RTL generation phase, we can convert
	 *	all pointers to 0 to (int) 0
	 */
	Dcltr dcltr  = new->type->dcltr;

	if (IsConstNumber(op1) && (new->type->dcltr==0)) {
	    int t;
	    t = new->type->type & TY_MASK;
	    /*
	     *	We can optimize (int)->(double)
	     *	and (double)->(int) conversions.
	     */
	    if (IsIntegralExpr(op1)) {	/* int->double */
		l1 = IntegralExprValue(op1);
		if (t & TY_REAL) {	/* int->double */
		    if (IsFloatType(expr->type)) {
			/* int -> float */
		    	Expr ppc;
			/* BCC - 8/5/96 */
		    	ppc = NewFloatExpr((double) l1);
		    	RemoveExpr(new);
		    	new = ppc;
			new->type->type &= ~TY_DOUBLE;
			new->type->type |= TY_FLOAT;
/*** SAM 9-25-91
			new->value.real = (double) ((float) new->value.real);
***/
			new->value.real = (double) new->value.real;
		    } else {
			/* int -> double */
		    	Expr ppc;
			/* BCC - 8/5/96 */
		    	ppc = NewDoubleExpr((double) l1);
		    	RemoveExpr(new);
		    	new = ppc;
		    }
		} else 
/* BCC - We can't ignore the type conversion among int types - 6/9/95 */
#if 0
		if (t & (TY_SHORT|TY_INT|TY_LONG)) {	/* int->int */
		    /*
		     *	This case might happen when the operand
		     *	of casting has just been reduced.
		     *	e.g. (int) (- 'a')
		     */
		    new = op1;
		}
#endif
/* BCC - here is what we should do - 6/11/95 */

		if (init_mspec == 1) {
		    int source,dest;
		    Expr ppc;
		    long value;

		    dest = new->type->type & TY_MASK;
		    source = op1->type->type & TY_MASK;

		    /* original value */
		    switch (op1->opcode) {
			case OP_signed :
			case OP_unsigned :
			    value = op1->value.scalar;
			    break;
			case OP_char:
			    value = C_str2char(op1->value.string);
			    break;
			case OP_enum:
			    value = HC_enum(op1->value.string);
		    }

/* The following code extends the sign bit from the source operand */
/* don't have to care about long because it's the longest type     */
		    if (dest & TY_INT) {
			if (H_LONG_SIZE != H_INT_SIZE) {
			    value <<= H_LONG_SIZE - H_INT_SIZE;
			    value >>= H_LONG_SIZE - H_INT_SIZE;
			};
		    }
		    else if (dest & TY_SHORT) {
			value <<= H_LONG_SIZE - H_SHORT_SIZE;
			value >>= H_LONG_SIZE - H_SHORT_SIZE;
		    }
		    else if (dest & TY_CHAR) {
			value <<= H_LONG_SIZE - H_CHAR_SIZE;
			value >>= H_LONG_SIZE - H_CHAR_SIZE;
		    };

/* Now handle the signed-unsigned destination operand, don't care long type */
		    if (dest & TY_UNSIGNED) {
			if (dest & TY_INT) 
			    value &= H_UNSIGNED_INT_MASK;
		    	else if (dest & TY_SHORT) 
			    value &= H_UNSIGNED_SHORT_MASK;
			else if (dest & TY_CHAR)
			    value &= H_UNSIGNED_CHAR_MASK;
		    };

/* Now build a new expression */
		    /* BCC - treat signed and unsigned differently - 1/30/96 */
		    if (dest & TY_UNSIGNED)
			ppc = NewUnsignedIntExpr((unsigned) value);
		    else
			ppc = NewIntExpr((int) value);
		    RemoveExpr(new);
		    new = ppc;

/* Now set type */
		    if (dest & TY_LONG)
			new->type->type = TY_LONG | TY_CONST;
		    else if (dest & TY_INT)
			new->type->type = TY_INT | TY_CONST;
		    else if (dest & TY_SHORT)
			new->type->type = TY_SHORT | TY_CONST;
		    else if (dest & TY_CHAR)
			new->type->type = TY_CHAR | TY_CONST;

		    if (dest & TY_UNSIGNED) 
			new->type->type |= TY_UNSIGNED;
		    else
			new->type->type |= TY_SIGNED;
		}
	    } else
	    /* BCC - use IsRealExpr() instead - 8/5/96 */
	    if (IsRealExpr(op1)) {	/* double->int */
		d1 = op1->value.real;
		if (t & (TY_SHORT|TY_INT|TY_LONG)) {
		    Expr ppc;
		    ppc = NewIntExpr((int) d1);
		    RemoveExpr(new);
		    new = ppc;
		    if (t & TY_UNSIGNED)
			new->type->type |= TY_UNSIGNED;
		} else
		if (t & TY_REAL) {	
		    if (IsFloatType(op1->type) && IsDoubleType(expr->type)) {
			/* float -> double */
			new = op1;
			new->type->type &= ~TY_FLOAT;
			new->type->type |= TY_DOUBLE;
			/* BCC - 8/5/96 */
			new->opcode = OP_double;
		    } else
		    if (IsFloatType(expr->type) && IsDoubleType(op1->type)) {
			/* double -> float */
			new = op1;
			new->type->type &= ~TY_DOUBLE;
			new->type->type |= TY_FLOAT;
/*** SAM 9-25-91
			new->value.real = (double) ((float) new->value.real);
***/
			new->value.real = (double) new->value.real;
			/* BCC - 8/5/96 */
			new->opcode = OP_float;
		    } else {
		    	new = op1;
		    }
		}
	    }
	}
	return new;
      }
    default :
	/* no compression */
	return new;
    }
}
/*--------------------------------------------------------------------------*/
/*
 *	Apply constant folding on all expressions.
 *	This function destroys all profile information and
 *	profile database.
 */
ConstantFold(func)
FuncDcl func;
{
    Block bb;
    Expr expr;
    Pragma pragma;
    pragma = FindFunctionPragma(func, "\"profiled");
    while (pragma!=0) {
	RemoveFunctionPragma(func, pragma);
    	pragma = FindFunctionPragma(func, "\"profiled");
    }
    for (bb=func->blocks; bb!=0; bb=bb->next) {
	Expr new, last, next;
	for (expr=bb->first; expr!=0; expr=new->next) {
	    last = expr->previous;
	    next = expr->next;
	    new = ReduceExpr(expr);
	    new->previous = last;
	    new->next = next;
	    if (last==0) {
		bb->first = new;
	    } else {
		last->next = new;
	    }
	    if (next==0) {
		bb->last = new;
	    } else {
		next->previous = new;
	    }
	    expr->previous = 0;
	    expr->next = 0;
	    RemoveExpr(expr);
	}
    }
}
/*--------------------------------------------------------------------------*/
