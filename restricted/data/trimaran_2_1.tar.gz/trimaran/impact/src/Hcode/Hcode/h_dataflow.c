/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_dataflow.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>

/*
 *	EXPORT FUNCTIONS:
 *	## int ContainCall(fn)
 *		FuncDcl fn;
 *	## VarList FindAllLocal(fn)
 *		FuncDcl fn;
 *	## VarList PointerAccessableLocal(fn)
 *		FuncDcl fn;
 *	## VarList RegisterAllocatableLocal(fn)
 *		FuncDcl fn;
 *
 *	If we try to optimize only for local variables (auto, parameter)
 *	the dataflow analysis become much simpler to implement.
 */

#define IsLocalVar(var) ((var!=0) && (var->type->type&(TY_AUTO|TY_PARAMETER)))
#define IsVolatileVar(var) ((var!=0) && (var->type->type&TY_VOLATILE))

#define MAX_LOCAL	4000

/*---------------------------------------------------------------------------*/
/*
 *	Find all local variables defined in the function.
 */
VarList FindAllLocal(fn)
FuncDcl fn;
{
    VarList l, result;
    result = 0;
    for (l=fn->local; l!=0; l=l->next) {
	if (! IsLocalVar(l->var))	/* skip extern/static */
	    continue;
	result = AddVar2List(result, l->var);
    }
    for (l=fn->param; l!=0; l=l->next) {
	if (! IsLocalVar(l->var))	/* skip extern/static */
	    continue;
	result = AddVar2List(result, l->var);
    }
    return result;
}
/*---------------------------------------------------------------------------*/
static VarList LookForAddr(expr, list, fn)
Expr expr;
VarList list;
FuncDcl fn;
{
    VarList result;
    Expr op;
    int i;
    if ((expr==0)||(fn==0)) 
	return list;
    result = list;
    for (i=1; (op=GetOperand(expr, i))!=0; i++)
	result = LookForAddr(op, result, fn);
    if (expr->opcode==OP_addr) {
	/*
	 *	See if the operand is a local variable.
	 */
	op = GetOperand(expr, 1);
	if (op->opcode==OP_var) {
	    char *var_name;
	    VarDcl var;
	    var_name = op->value.var_name;
	    var = FindVarList(fn->local, var_name);
	    if (var==0)
		var = FindVarList(fn->param, var_name);
	    if (IsLocalVar(var)) {
		result = AddVar2List(result, var);
	    }
	}
    }
    return result;
}
/*
 *	Return the set of local variables which are identified
 *	to be pointer accessable within this function.
 *	1) All local variables which are declared as (fn, array)
 *	2) All local variables which are directly under a OP_addr
 *	3) All local variables which are declared TY_VOLATILE.
 *	!!! we do not guarantee anything about strange pointer-arithmetic.
 *		e.g.	int a, b, c;
 *			*(&a+4) = 10;
 */
VarList PointerAccessableLocal(fn)
FuncDcl fn;
{
    VarList result = 0;
    register VarList l;
    Block bb;
    Expr expr;
    /* 1,3 */
    for (l=fn->local; l!=0; l=l->next) {
	Type type = l->var->type;
	Dcltr dcltr;
	if (! IsLocalVar(l->var))	/* skip extern/static */
	    continue;
	dcltr = type->dcltr;
	if (((dcltr!=0)&&(dcltr->method!=D_PTR)) || (type->type&TY_VOLATILE)) {
	    result = AddVar2List(result, l->var);
	}
    }
    for (l=fn->param; l!=0; l=l->next) {
	Type type = l->var->type;
	Dcltr dcltr;
	if (! IsLocalVar(l->var))	/* skip extern/static */
	    continue;
	dcltr = type->dcltr;
	if (((dcltr!=0)&&(dcltr->method!=D_PTR)) || (type->type&TY_VOLATILE)) {
	    result = AddVar2List(result, l->var);
	}
    }
    /* 2 */
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	for (expr=bb->first; expr!=0; expr=expr->next) {
	    result = LookForAddr(expr, result, fn);
	}
    }
    return result;
}
/*---------------------------------------------------------------------------*/
static ContainCallInExpr(expr)
Expr expr;
{
    if (expr==0) return 0;
    if (expr->opcode==OP_call)
	return 1;
    if (ContainCallInExpr(expr->operands))
	return 1;
    if (ContainCallInExpr(expr->sibling))
	return 1;
    return 0;
}
/*
 *	In many cases, we can make better local optimization if
 *	it is known that the function does not contain function
 *	calls.
 */
int ContainCall(fn)
FuncDcl fn;
{
    Block bb;
    Expr expr;
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	for (expr=bb->first; expr!=0; expr=expr->next) {
	    if (ContainCallInExpr(expr))
		return 1;
	}
    }
    return 0;
}
/*---------------------------------------------------------------------------*/
/*
 *	Return a list of local variables which can be safely
 *	register allocated. (auto, parameter)
 *	1) cannot be accessed through pointer.
 *	2) a simple type.
 */
VarList RegisterAllocatableLocal(fn)
FuncDcl fn;
{
    VarList all_local, ptr_accessable;
    VarList safe, p;
    VarDcl var;
    all_local = FindAllLocal(fn);
    ptr_accessable = PointerAccessableLocal(fn);
    /*
     *	safe = all_local - ptr_accessable
     */
    safe = 0;
    for (p=all_local; p!=0; p=p->next) {
	register int is_structure;
	Type type;
	/*
	 *	Can not allocate register for a structure:
 	 *	1) union, 2) struct, 3) array, 4) function
	 */
	type = p->var->type;
	is_structure = 0;
	if (type->dcltr!=0) {
	    switch (type->dcltr->method) {
	    case D_ARRY :
	    case D_FUNC :
		is_structure = 1;
		break;
	    default :
		/* do nothing */
		;
	    }
	} else {
	    register int t;
	    t = type->type;
	    is_structure =  ((t & (TY_UNION|TY_STRUCT)) != 0);
	}
	if (is_structure)
	    continue;
	/*
	 *	Can not allocate register for ptr-accessable variables.
	 */
	var = FindVarList(ptr_accessable, p->name);
	if (var==0) {
	    safe = AddVar2List(safe, p->var);
	}
    }
    RemoveVarList2(all_local);
    RemoveVarList2(ptr_accessable);
    return safe;
}
/*---------------------------------------------------------------------------*/


