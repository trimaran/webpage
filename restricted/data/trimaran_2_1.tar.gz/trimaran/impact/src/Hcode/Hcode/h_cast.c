/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.31  */
/* IMPACT Trimaran Release (www.trimaran.org)                  June 21, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_cast.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Modified by: Nancy Warter
\*****************************************************************************/
#include <Hcode/h_main.h>

/* BCC - signed or unsigned is important */
#define UNSIGNED_MATTERS

#undef ABORT

#undef TEST_VAR
#undef NO_CAST

/*
 *	Print error message and exit.
 */
static Punt(mesg)
char *mesg;
{
    fprintf(stderr, "cast: %s\n", mesg);
#ifdef ABORT
    abort();
#else
    exit(-1);
#endif
}
/*
 *	Structure assignment is allowed.
 *	e.g. struct _buf x, y;
 *		x = y; 		is allowed.
 *		x = &y;		is also allowed.
 *	When the LHS of an assignment is a structure, it copies
 *	sizeof(structure) bytes from the memory location specified
 *	by the RHS operand.
 *
 *	A function may return a structure. It actually returns
 *	a pointer to the structure (struct/union/array).
 *	When structure (struct/union), array, and function are
 *	passed to another function as parameters, their memory
 *	location (pointers to them) are passed instead.
 */

/*
 *	The constant literals can actually be modified by
 *	the user (bad practice). Therefore, it may be wrong
 *	to assume they are all constants. For example, some
 *	programs actually rewrite the string content (string I/O).
 *	When a constant string is passed as parameter, it may be
 *	changed. In this version of the C compiler, it is
 *	assumed that modifying constants causes unpredictable
 *	effect. This assumption allows the compiler more freedom
 *	to perform code optimization.
 *	As a direct consequence, the types of all constant expressions
 *	are marked as TY_CONST.
 */

/*
 *	integral types = [short, long, unsigned, signed, int, char, enum]
 *	arithmetic types = integral types + [float, double]
 *	pointer types = [pointer, 0-dimension array]
 *	fundamental types = arithmetic types + pointer types
 *	structure types = [union, struct]
 *	array type = [N-dimension array, N is defined]
 *	function type = [func]
 *
 *	** pointer and array are inter-changeable.
 */
int IsVoidType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr!=0) return 0;
    t = type->type;
    t &= TY_MASK;
    if (! (t&TY_VOID))
	return 0;
    t &= ~TY_VOID;
    if (t!=0)
	Punt("IsVoidType: detects an illegal real type");
    return 1;
}
int IsIntegralType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr!=0) return 0;
    t = type->type;
    t &= TY_MASK;
    if (! (t&TY_INTEGRAL))
	return 0;
    if (t & TY_REAL)
	return 0;
    t &= ~TY_INTEGRAL;
    if (t!=0) {
	fprintf(stderr, "> (%d) t=%d\n", type->type, t);
	Punt("IsIntegralType: detects an illegal integral type");
    }
    return 1;
}
int IsRealType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr!=0) return 0;
    t = type->type;
    t &= TY_MASK;
    if (! (t&TY_REAL))
	return 0;
    t &= ~TY_REAL;
    if (t!=0)
	Punt("IsRealType: detects an illegal real type");
    return 1;
}

/* REH - 3/25/94 Add function to detect real constants */
int IsRealConst(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr!=0) return 0;
    t = type->type;
    if (! (t&TY_CONST) )
   	return(0);
    t &= TY_MASK;
    if (! (t&TY_REAL))
	return 0;
    t &= ~TY_REAL;
    if (t!=0)
	Punt("IsRealType: detects an illegal real type");
    return 1;
}

int IsFloatType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr!=0) return 0;
    t = type->type;
    t &= TY_MASK;
    if (! (t&TY_FLOAT))
	return 0;
    t &= ~TY_FLOAT;
    if (t!=0)
	Punt("IsFloatType: detects an illegal real type");
    return 1;
}
int IsDoubleType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr!=0) return 0;
    t = type->type;
    t &= TY_MASK;
    if (! (t&TY_DOUBLE))
	return 0;
    t &= ~TY_DOUBLE;
    if (t!=0)
	Punt("IsDoubleType: detects an illegal real type");
    return 1;
}
int IsArithmeticType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr!=0) return 0;
    t = type->type;
    t &= TY_MASK;
    if (! (t&TY_ARITHMETIC))
	return 0;
    t &= ~TY_ARITHMETIC;
    if (t!=0)
	Punt("IsArithmeticType: detects an illegal arithmetic type");
    return 1;
}
int IsPointerType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr==0) return 0;
    t = type->dcltr->method;
    /* NJW (2/93) - allow single element arrays */
    /* old
       return (((t==D_ARRY)&&(type->dcltr->index==0)) || (t==D_PTR));
     */
    return (((t==D_ARRY)&&(type->dcltr->index==0)) || (t==D_PTR) ||
            ((t==D_ARRY)&&(type->dcltr->index->value.scalar == 1)));
}
int IsFundamentalType(type)
Type type;
{
    if (type==0) return 0;
    if (type->dcltr!=0) {
	/*
	 * array (e.g. int A[100], b;	(A>&b))
	 * A is treated as a memory address, and thus
	 * is a valid scalar variable.
	 */
	/* REH 2/94 - make a function a fundamental type
	return (IsPointerType(type) || IsArrayType(type));
	*/
	return (IsPointerType(type) || IsArrayType(type) || IsFunctionType(type));
    } else
	return IsArithmeticType(type);
}
int IsStructureType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr!=0) return 0;
    t = type->type;
    t &= TY_MASK;
    if (! (t&TY_STRUCTURE))
	return 0;
    t &= ~TY_STRUCTURE;
    if (t!=0)
	Punt("IsStructureType: detects an illegal structure type");
    return 1;
}
int IsArrayType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr==0) return 0;
    t = type->dcltr->method;
    return ((t==D_ARRY) && (type->dcltr->index!=0));
}
int IsFunctionType(type)
Type type;
{
    int t;
    if (type==0) return 0;
    if (type->dcltr==0) return 0;
    t = type->dcltr->method;
    return (t==D_FUNC);
}
/*
 *	Upgrade the type to the natural data type (TY_INT, TY_DOUBLE).
 *	This function does not explicitly duplicate the formal parameter.
 *	The caller must make sure that there can be at most one reference
 *	to the expression. (since we assume the expression tree structure
 *	is NOT shared, in RemoveExpr())
 *	(char -> int)
 *	(short -> int)
 *	In this version, we do not do (float->double) in computation.
 */
Expr UpgradeArithmeticType(expr)
Expr expr;
{
    Type type;
    int t;
    Expr cast;
    if (expr==0) Punt("UpgradeArithmeticType: nil expr");
    type = expr->type;
    if (type==0) Punt("UpgradeArithmeticType: nil type");
    if (type->dcltr!=0)
	return expr;		/* not arithmetic type */
    t = type->type;
    if (t & (TY_CHAR|TY_SHORT)) {	/* convert into TY_INT */
	type = NewType();
	type->type = TY_INT;
	cast = NewExpr(OP_cast);
	cast->value.type = cast->type = type;
	AddOperand(cast, expr);
	expr = cast;
    }
    return expr;
}
/*
 *	Add explicit casting operator to upgrade the result
 *	of an expression to a more powerful type.
 *	Need to duplicate the 'type' formal parameter.
 */
Expr UpgradeType(expr, type)
Expr expr;
Type type;
{
    Type new;
    Expr cast;
    new = CopyType(type);
    cast = NewExpr(OP_cast);
    cast->value.type = cast->type = new;
    AddOperand(cast, expr);
    return cast;
}
/*
 *	Returns -1 if the two types are not directly comparable.
 *	Returns 1 if the two types are compatible (same strength).
 *	Otherwise, return 0.
 *	!! This function works only for arithmetic types.
 */
int EqualStrength(type1, type2)
Type type1, type2;
{
    int t1, t2;
    /* DIA - To handle pointers */
    if (IsPointerType(type1) || IsPointerType(type2))
      return -1;
    if (! IsArithmeticType(type1)) {
	Gen_C_Type(Ferr, type1);
	Punt("EqualStrength: works only for arithmetic types");
    }
    if (! IsArithmeticType(type2)) {
	Gen_C_Type(Ferr, type2);
	Punt("EqualStrength: works only for arithmetic types");
    }
    if (IsIntegralType(type1)) {	/* fixed-point */
	if (! IsIntegralType(type2))
	    return 0;
	t1 = (type1->type & TY_INTEGRAL);
 	t2 = (type2->type & TY_INTEGRAL);
	if ((t1&TY_LONG) && !(t2&TY_LONG))	/* check for long */
	    return 0;
	if ((t2&TY_LONG) && !(t1&TY_LONG))
	    return 0;
	if ((t1&TY_SHORT) && !(t2&TY_SHORT))	/* check for short */
	    return 0;
	if ((t2&TY_SHORT) && !(t1&TY_SHORT))
	    return 0;
	if ((t1&TY_CHAR) && !(t2&TY_CHAR))	/* check for char */
	    return 0;
	if ((t2&TY_CHAR) && !(t1&TY_CHAR))
	    return 0;
#ifdef UNSIGNED_MATTERS
	if ((t1&TY_UNSIGNED) && !(t2&TY_UNSIGNED))	/* check for unsigned */
	    return 0;
	if ((t2&TY_UNSIGNED) && !(t1&TY_UNSIGNED))
	    return 0;
#endif
	return 1;
    } else {				/* floating-point */
	if (! IsRealType(type2))
	    return 0;
	t1 = (type1->type & TY_REAL);
	t2 = (type2->type & TY_REAL);
	if ((t1&TY_DOUBLE) && !(t2&TY_DOUBLE))	/* check for double */
	    return 0;
	if ((t2&TY_DOUBLE) && !(t1&TY_DOUBLE))
	    return 0;
	return 1;
    }
}
/*
 *	The type conversion rules are taken from K&R C book.
 *	The exception is that (float) is not converted to
 *	(double), since it is allowed to have single-precision
 *	computations (faster and less accuracy).
 *	We provide a function to compute the dominant type
 *	which can absorb both type1 and type2, according to
 *	usual arithmetic type conversion, as defined in K&R.
 *	The returned type is a brand new (duplicated) type structure.
 *	This function works only for arithmetic types.
 */
Type DominantType(type1, type2)
Type type1, type2;
{
    int t1, t2;
    Type type;
    if (! IsArithmeticType(type1))
	Punt("DominantType: works only for arithmetic types");
    if (! IsArithmeticType(type2))
	Punt("DominantType: works only for arithmetic types");
    t1 = (type1->type & TY_MASK);
    t2 = (type2->type & TY_MASK);
    type = NewType();
    if ((t1&TY_DOUBLE) || (t2&TY_DOUBLE)) {
	type->type = TY_DOUBLE;
    } else
    if ((t1&TY_FLOAT) || (t2&TY_FLOAT)) {
	type->type = TY_FLOAT;
    } else
    if ((t1&TY_LONG) || (t2&TY_LONG)) {
	type->type = TY_LONG;
    } else {
	type->type = TY_INT;
    }
    if ((t1&TY_UNSIGNED) || (t2&TY_UNSIGNED))
	if (IsIntegralType(type))
            type->type |= TY_UNSIGNED;
    return type;
}

/* REH  3/23/94 - Ensure ANSI C standard for fp conversions */
void FloatConstType(type1, type2)
Type type1,type2;
{
    if ( IsRealConst(type1) )  {
    	type1->type &= ~(TY_REAL);
	if ( IsRealType(type2) )  {
            type1->type |= (type2->type & TY_REAL);
	}
	else
	    type1->type |= TY_FLOAT;
    }
    else if ( IsRealConst(type2) )  {
        type2->type &= ~(TY_REAL);
	if ( IsRealType(type1) )
            type2->type |= (type1->type & TY_REAL);
	else
	    type2->type |= TY_FLOAT;
    }
}
/* HER */

/*
 *	We do not care about the dcltr, and directly modify the type info.
 *
 *	TY_SHORT, TY_LONG, TY_SIGNED, and TY_UNSIGNED are
 *	treated as adjatives for TY_INT and TY_CHAR.	
 *	In this version, 
 *		(TY_SIGNED|TY_CHAR) == TY_CHAR
 *		(TY_SIGNED|TY_INT) == TY_INT
 *		(TY_SIGNED|TY_SHORT) == TY_SHORT
 *		(TY_SIGNED|TY_LONG) == TY_LONG
 *		(TY_SHORT|TY_INT) == TY_SHORT
 *		(TY_LONG|TY_INT) == TY_LONG
 *		(TY_UNSIGNED|TY_CHAR)
 *		(TY_UNSIGNED|TY_INT)
 *		(TY_UNSIGNED|TY_SHORT)
 *		(TY_UNSIGNED|TY_LONG)
 *
 *	All other combinations of [TY_SIGNED, TY_CHAR, TY_INT, TY_SHORT,
 *	TY_LONG, TY_UNSIGNED] are illegal.
 *
 *	TY_SHORT, and TY_LONG, cannot be
 *	used to describe TY_FLOAT and TY_DOUBLE.
 *	The exception is (TY_LONG|TY_FLOAT)==TY_DOUBLE
 *
 *	Since 'signed' is the default, we can mask out the TY_SIGNED bit
 *	after making sure that it is not TY_UNSIGNED. The reason for
 *	masking this bit is that some C compiler does not like 'signed'
 *	and we would like the output (in C) to work for most C compilers.
 */
UnifyArithmeticType(type)
Type type;
{
    int t;
#ifdef NO_CAST
return;
#endif
    if (type==0) return;
    t = type->type;  
    if (t & (TY_FLOAT|TY_DOUBLE)) {
	if ((t&TY_FLOAT) && (t&TY_DOUBLE)) 	/* double float -> double */
	    t = (type->type &= ~TY_FLOAT);
	if ((t&TY_LONG) && (t&TY_FLOAT)) {	/* long float -> double */
	    type->type &= ~(TY_FLOAT|TY_LONG);
	    t = (type->type |= TY_DOUBLE);
	}
/* DIA */
        if ((t & (TY_DOUBLE)) && (t & (TY_LONG)))
            t = (type->type &= ~TY_LONG);    /* long double -> double */ 
	if (t & (TY_SHORT|TY_LONG))
	    Punt("[short, long] float/double violation");
	if ((t&TY_SIGNED) && (t&TY_UNSIGNED))	/* signed X unsigned */ 
	    Punt("signed/unsigned conflict");
	if (t&TY_SIGNED)			/* remove 'signed' */
	    t = (type->type &= ~TY_SIGNED);
    } else
    if (t & (TY_SHORT|TY_LONG|TY_INT|TY_CHAR)) {
	if ((t&TY_SHORT) && (t&TY_INT))		/* short int -> short */
	    t = (type->type &= ~TY_INT);
	if ((t&TY_LONG) && (t&TY_INT))		/* long int ->long */
	    t = (type->type &= ~TY_INT);
	if ((t&TY_SHORT) && (t&TY_LONG))	/* short X long */
	    Punt("short/long conflict");
	if ((t&TY_CHAR) && (t&(TY_INT|TY_SHORT|TY_LONG)))
	    Punt("char/int conflict");
	if ((t&TY_SIGNED) && (t&TY_UNSIGNED))	/* signed X unsigned */ 
	    Punt("signed/unsigned conflict");
	if (t&TY_SIGNED)			/* remove 'signed' */
	    t = (type->type &= ~TY_SIGNED);
    }
}

/*
 * Determine the resultant type of the expression based on
 * its operator and its operands.
 * Check if the types of operands are compatible.
 * Add new expressions to explicitely cast the operands to
 * the required types.
 */
CastExpr(expr)
Expr expr;
{
    int opcode;
#ifdef NO_CAST
return;
#endif
    if (expr==0) Punt("CastExpr: nil expr");
    /*
     *	If the type field is already defined, do nothing.
     */
    if (expr->type!=0)
	return;
    opcode = expr->opcode;
    switch (opcode) {
    /* VARIBLE */
    case OP_var : {
	/*
	 *	If the variable is defined, then the resultant type
	 *	is the type of the variable, as declared.
	 *	Otherwise, we assume it is (TY_INT | TY_EXTERN)
	 */
	char *var_name;
	Symbol sym;
	VarDcl var;
	VarList ptr;
	Type type, new;
	Dcltr dcltr;
	var_name = expr->value.var_name;
	/*
	 *	See if it has been declared as a local variable.
	 */
	if (currentFuncDcl!=0) {
	  for (ptr=currentFuncDcl->local; ptr!=0; ptr=ptr->next) {
	    if (! strcmp(ptr->var->name, var_name)) {
#ifdef TEST_VAR
fprintf(stderr, "> %s is local\n", var_name);
#endif
		type = ptr->var->type;
		new = CopyType(type);

		    /* DMG - an array is declared with a dcltr type D_ARRY
			in the symbol table; however a reference to the
			array variable be itself is really a pointer */

		if ( (type->dcltr != NULL) && (type->dcltr->method == D_ARRY) ){
#if 0
		    for (dcltr = new->dcltr; dcltr!=NULL; dcltr=dcltr->next) {
			if (dcltr->method == D_ARRY) {
			    dcltr->method = D_PTR;
			    if (dcltr->index == NULL) {
			        dcltr->index = NewExpr(OP_signed);
			        dcltr->index->value.scalar = 0;
			    }
			}
		    }
#endif
		    /* 
		     * BCC - 1/30/96
		     * The above code changed too much. A two dimension array,
		     * say, int a[10][20] is still a pointer, as int (*a)[20],
		     * not int **a;
		     * This causes a problem when we assign a temp variable 
		     * when we flatten the code, which should generate a var
		     * with type int (*a)[20], not int **a;
		     */
		    new->dcltr->method = D_PTR;
		    if (new->dcltr->index == NULL) {
			new->dcltr->index = NewExpr(OP_signed);
			new->dcltr->index->value.scalar = 0;
		    }
		}

	    	expr->type = new;
	    	goto DONE;
	    }
	  }
	}
	/*
	 *	See if it has been declared as a parameter.
	 */
	if (currentFuncDcl!=0) {
	  for (ptr=currentFuncDcl->param; ptr!=0; ptr=ptr->next) {
	    if (! strcmp(ptr->var->name, var_name)) {
#ifdef TEST_VAR
fprintf(stderr, "> %s is parameter\n", var_name);
#endif
		type = ptr->var->type;
		new = CopyType(type);

		    /* DMG - an array is declared with a dcltr type D_ARRY
			in the symbol table; however a reference to the
			array variable be itself is really a pointer */

		if ( (type->dcltr != NULL) && (type->dcltr->method == D_ARRY) ){
#if 0
		    for (dcltr = new->dcltr; dcltr!=NULL; dcltr=dcltr->next) {
			if (dcltr->method == D_ARRY) {
			    dcltr->method = D_PTR;
		/* DMG - 2 Jun 95 - 
			formal parameters are different; if the type is array,
				it really is a pointer, so don't add index 
			    if (dcltr->index == NULL) {
			        dcltr->index = NewExpr(OP_signed);
			        dcltr->index->value.scalar = 0;
			    }
		*/
			}
		    }
#endif
		    /* 
		     * BCC - 1/30/96
		     * The above code changed too much. A two dimension array,
		     * say, int a[10][20] is still a pointer, as int (*a)[20],
		     * not int **a;
		     * This causes a problem when we assign a temp variable 
		     * when we flatten the code, which should generate a var
		     * with type int (*a)[20], not int **a;
		     */
		    new->dcltr->method = D_PTR;
		}

	    	expr->type = new;
	    	goto DONE;
	    }
	  }
	}
	/*
	 *	See if it has been defined as a global variable.
	 */
	var = FindVar(var_name);
	if (var!=0) {
#ifdef TEST_VAR
fprintf(stderr, "> %s is global\n", var_name);
#endif
	    type = var->type;
		new = CopyType(type);

		    /* DMG - an array is declared with a dcltr type D_ARRY
			in the symbol table; however a reference to the
			array variable be itself is really a pointer */
		if ( (type->dcltr != NULL) && (type->dcltr->method == D_ARRY) ){
#if 0
		    for (dcltr = new->dcltr; dcltr!=NULL; dcltr=dcltr->next) {
			if (dcltr->method == D_ARRY) {
			    dcltr->method = D_PTR;
			    if (dcltr->index == NULL) {
			        dcltr->index = NewExpr(OP_signed);
			        dcltr->index->value.scalar = 0;
			    }
			}
		    }
#endif
		    /* 
		     * BCC - 1/30/96
		     * The above code changed too much. A two dimension array,
		     * say, int a[10][20] is still a pointer, as int (*a)[20],
		     * not int **a;
		     * This causes a problem when we assign a temp variable 
		     * when we flatten the code, which should generate a var
		     * with type int (*a)[20], not int **a;
		     */
		    new->dcltr->method = D_PTR;
		    if (new->dcltr->index == NULL) {
			new->dcltr->index = NewExpr(OP_signed);
			new->dcltr->index->value.scalar = 0;
		    }
		}

	    expr->type = new;
	    goto DONE;
	}
	/*
	 *	See if it has been defined as a function.
	 */
	sym = FindFunction(var_name);
	if (sym!=0) {
	    Dcltr dcltr;
#ifdef TEST_VAR
fprintf(stderr, "> %s is a function\n", var_name);
#endif
	    type = (Type) sym->ptr;	/* return_type */
	    new = CopyType(type);
	    dcltr = NewDcltr();		/* F */
	    dcltr->method = D_FUNC;
	    dcltr->next = new->dcltr;	/* F->return_type */
	    new->dcltr = dcltr;
	    expr->type = new;	
	    goto DONE;
	}
	/*
	 *	The variable is not yet defined. Just
	 *	assume it is (TY_INT | TY_EXTERN).
	 */
	{
#ifdef TEST_VAR
fprintf(stderr, "> %s is not defined\n", var_name);
#endif
	    new = NewType();
	    new->type = (TY_INT | TY_EXTERN);
	    expr->type = new;
	}
DONE:
    	break;
    }

    /* CONSTANTs */
    case OP_enum : 
    case OP_signed : 
	/*
	 *	(TY_INT | TY_CONST)
	 */
	expr->type = NewType();
	expr->type->type = (TY_INT | TY_CONST);
	break;
    case OP_unsigned :
	/*
	 *	(TY_UNSIGNED | TY_INT | TY_CONST)
	 */
	expr->type = NewType();
	expr->type->type = (TY_UNSIGNED | TY_INT | TY_CONST);
	break;
    /* BCC - let OP_float be of type TY_FLOAT - 8/5/96 */
    case OP_float :
	/*
	 *	According to K&R, floating-point constants are double.
	 *	(TY_FLOAT | TY_CONST)
	 */
	expr->type = NewType();
	expr->type->type = (TY_FLOAT | TY_CONST);
	break;
    /* BCC - added OP_float to be of type TY_DOUBLE - 8/5/96 */
    case OP_double :
	/*
	 *	According to K&R, floating-point constants are double.
	 *	(TY_DOUBLE | TY_CONST)
	 */
	expr->type = NewType();
	expr->type->type = (TY_DOUBLE | TY_CONST);
	break;
    case OP_char :
	/*
	 *	According to K&R, character literal is an integer.
	 *	(TY_INT | TY_CONST)
	 */
	expr->type = NewType();
	expr->type->type = (TY_INT | TY_CONST);
	break;
    case OP_string :
	/*
	 *	(TY_CHAR | TY_CONST) (P)
	 */
	expr->type = NewType();
	expr->type->type = (TY_CHAR | TY_CONST);
	expr->type->dcltr = NewDcltr();
	expr->type->dcltr->method = D_PTR;
	break;

    /* special COMPILE-TIME operations */
    case OP_cast :
	/*
	 *	The type is already defined in the input CCODE.
	 *	But, we should not got here, because CastExpr()
	 *	returns very early if the type field is already
	 *	defined. Therefore, it is an error to reach here.
	 */
	Punt("CastExpr: the type field of (OP_cast) is undefined");
	break;
    case OP_expr_size :
    case OP_type_size : {
	/*
	 *	Type size (expression size) is the number of
	 *	bytes required to store the type (result).
	 *	The resultant type is integer, and is a constant.
	 *	(TY_INT | TY_CONST)
	 */
	expr->type = NewType();
	expr->type->type = (TY_INT | TY_CONST);
	break;
    }
    /* BIT operations */
    case OP_or :
    case OP_xor :
    case OP_and : {
	/*
	 *	According to K&R,
	 *	1) normal arithmetic conversions are performed.
	 *	2) apply only on integral operands.
	 */
	Expr op1, op2, oper;
	Type type1, type2, type;
	/** type upgrade **/
	oper = GetOperand(expr, 1);	
	if (oper==0) Punt("illegal BIT operation: missing operand");
	op1 = UpgradeArithmeticType(oper);
	if (op1!=oper) ChangeOperand(expr, 1, op1);
	oper = GetOperand(expr, 2);
	if (oper==0) Punt("illegal BIT operation: missing operand");
	op2 = UpgradeArithmeticType(oper);
	if (op2!=oper) ChangeOperand(expr, 2, op2);
	/** compute result type **/
	type1 = op1->type;
	type2 = op2->type;
	if (! IsIntegralType(type1))
	    Punt("illegal BIT operation: must be integral type");
	if (! IsIntegralType(type2))
	    Punt("illegal BIT operation: must be integral type");
	type = DominantType(type1, type2);
	expr->type = type;	/* resultant type */
	if (! EqualStrength(type, type1)) {
	    op1 = UpgradeType(op1, type);
	    ChangeOperand(expr, 1, op1);
	}
	if (! EqualStrength(type, type2)) {
	    op2 = UpgradeType(op2, type);
	    ChangeOperand(expr, 2, op2);
	}
	break;
    }
    /* RELATIONAL operations */
    case OP_eq :
    case OP_ne :
    case OP_lt :
    case OP_le :
    case OP_ge :
    case OP_gt : {
	/*
	 *	1) normal arithmetic conversions are performed.
	 *	2) The result is TY_INT.
	 *	3) apply only on fundamental types.
	 */
	Expr oper, op1, op2;
	Type type, type1, type2;
	/* 
	 * perform arithmetic conversions. 
	 */
	oper = GetOperand(expr, 1);
	if (oper==0) Punt("illegal RELATIONAL operation: missing 1st operand");
	if (! IsFundamentalType(oper->type)) {
	 Gen_C_Expr(Ferr, expr);
	 Gen_C_Expr(Ferr, oper);
	 Punt("illegal RELATIONAL operation: operand must be fundamental type");
	}
	if (IsArithmeticType(oper->type)) {
	    op1 = UpgradeArithmeticType(oper);
	    if (op1!=oper)
	    	ChangeOperand(expr, 1, op1);
	} else
	    op1 = oper;
	oper = GetOperand(expr, 2);
	if (oper==0) Punt("illegal RELATIONAL operation: missing 2nd operand");
	if (! IsFundamentalType(oper->type)) {
	 Gen_C_Expr(Ferr, expr);
	 Gen_C_Expr(Ferr, oper);
	 Punt("illegal RELATIONAL operation: operand must be fundamental type");
	}
	if (IsArithmeticType(oper->type)) {
	    op2 = UpgradeArithmeticType(oper);
	    if (op2!=oper)
	    	ChangeOperand(expr, 2, op2);
	} else
	    op2 = oper;
	/*
	 *	Need to bring both operands to the same class.
	 */
	type1 = op1->type;
	type2 = op2->type;

/* REH	3/23/94 - Ensure ANSI C standard for fp conversions */
        FloatConstType(type1, type2);
/* HER */ 

 	if (IsArithmeticType(type1) && IsArithmeticType(type2)) {
	    type = DominantType(type1, type2);
	    if (! EqualStrength(type, type1)) {
		op1 = UpgradeType(op1, type);
		ChangeOperand(expr, 1, op1);
	    } 
	    if (! EqualStrength(type, type2)) {
		op2 = UpgradeType(op2, type);
		ChangeOperand(expr, 2, op2);
	    } 
	}
	/* 
	 * the result is TY_INT
	 */
	type = NewType();
	type->type = TY_INT;
	expr->type = type;
	break;
    }
    /* SHIFT operations */
    case OP_rshft :
    case OP_lshft : {
	/*
	 *	1) normal arithmetic conversions are performed.
	 *	2) apply only on integral types.
	 *	3) the right operand is converted to TY_INT.
	 *	4) the resultant type is the type of the left operand.
	 */
	Expr op1, op2, oper;
	Type type;
	/*
	 * apply arithmetic conversions.
	 */
	oper = GetOperand(expr, 1);
	if (oper==0)
	    Punt("illegal SHIFT operation: missing 1st operand");
	if (! IsIntegralType(oper->type))
	    Punt("1st operand of SHIFT is not an integral expression");
	op1 = UpgradeArithmeticType(oper);
	if (op1!=oper)
	    ChangeOperand(expr, 1, op1);
	oper = GetOperand(expr, 2);
	if (oper==0)
	    Punt("illegal SHIFT operation: missing 2nd operand");
	if (! IsIntegralType(oper->type))
	    Punt("2nd operand of SHIFT is not an integral expression");
	op2 = UpgradeArithmeticType(oper);
	if (op2!=oper)
	    ChangeOperand(expr, 2, op2);
	/* 
	 * the resulting type is the type of op1.
	 */
	type = CopyType(op1->type);
	expr->type = type;
	break;
    }
    /* ARITHEMETIC operations */
    case OP_add : {
	/*
	 *	1) the usual arithmetic conversions are performed.
	 *	2) a pointer to an array, integral -> pointer to array.
	 */
	Expr oper, op1, op2;
	Type type, type1, type2;
	int ptr1, ptr2;
	/*
	 * apply arithmetic conversions.
	 */
	oper = GetOperand(expr, 1);
	if (oper==0)
	    Punt("illegal (add) operation: missing 1st operand");
	op1 = UpgradeArithmeticType(oper);
	if (op1!=oper)
	    ChangeOperand(expr, 1, op1);
	oper = GetOperand(expr, 2);
	if (oper==0)
	    Punt("illegal (add) operation: missing 2nd operand");
	op2 = UpgradeArithmeticType(oper);
	if (op2!=oper)
	    ChangeOperand(expr, 2, op2);
	/*
	 * determine the type of the result.
	 */
	ptr1 = (IsPointerType(op1->type) || IsArrayType(op1->type));
	ptr2 = (IsPointerType(op2->type) || IsArrayType(op2->type));
	if (ptr1 & ptr2)
	    Punt("illegal (add) operation: cannot add two pointers");
	type1 = op1->type;
	type2 = op2->type;
	if (ptr1 | ptr2) {	/* adding a pointer to an integer */
	    if (ptr1)
		type = CopyType(type1);
	    else
		type = CopyType(type2);
	} else {		/* adding two arithmetic value */
	    if (! IsArithmeticType(type1) || ! IsArithmeticType(type2))
	 	Punt("illegal (add): operands are not arithmetic/pointer");

/* REH  3/23/94 - Ensure ANSI C standard for fp conversions */
	    FloatConstType(type1, type2);
/* HER */

	    type = DominantType(type1, type2);
	    if (! EqualStrength(type, type1)) {
		op1 = UpgradeType(op1, type);
		ChangeOperand(expr, 1, op1);
	    } 
	    if (! EqualStrength(type, type2)) {
		op2 = UpgradeType(op2, type);
		ChangeOperand(expr, 2, op2);
	    } 
	}
	expr->type = type;
	break;
    }
    case OP_sub : {
	/*
	 *	1) the usual arithmetic conversions are performed.
	 *	2) a pointer to an array, integral -> pointer to array.
	 *	3) pointer to array - pointer to array -> TY_INT.
	 */
	Expr oper, op1, op2;
	Type type, type1, type2;
	int ptr1, ptr2;
	/*
	 * apply arithmetic conversions.
	 */
	oper = GetOperand(expr, 1);
	if (oper==0)
	    Punt("illegal (sub) operation: missing 1st operand");
	op1 = UpgradeArithmeticType(oper);
	if (op1!=oper)
	    ChangeOperand(expr, 1, op1);
	oper = GetOperand(expr, 2);
	if (oper==0)
	    Punt("illegal (sub) operation: missing 2nd operand");
	op2 = UpgradeArithmeticType(oper);
	if (op2!=oper)
	    ChangeOperand(expr, 2, op2);
	/*
	 * determine the type of the result.
	 */
	ptr1 = (IsPointerType(op1->type) || IsArrayType(op1->type));
	ptr2 = (IsPointerType(op2->type) || IsArrayType(op2->type));
	type1 = op1->type;
	type2 = op2->type;
	if (ptr1 & ptr2) {	/* operating on two pointers */
	    type = NewType();
	    type->type = TY_INT;
	} else
	if (ptr1 | ptr2) {	/* subtracting a pointer by an integer */
	    if (ptr1)
		type = CopyType(type1);
	    else
		type = CopyType(type2);
	} else {		/* operating on two arithmetic value */
	    if (! IsArithmeticType(type1) || ! IsArithmeticType(type2))
	 	Punt("illegal (sub): operands are not arithmetic/pointer");

/* REH  3/23/94 - Ensure ANSI C standard for fp conversions */
	    FloatConstType(type1, type2);
/* HER */

	    type = DominantType(type1, type2);
	    if (! EqualStrength(type, type1)) {
		op1 = UpgradeType(op1, type);
		ChangeOperand(expr, 1, op1);
	    } 
	    if (! EqualStrength(type, type2)) {
		op2 = UpgradeType(op2, type);
		ChangeOperand(expr, 2, op2);
	    } 
	}
	expr->type = type;
	break;
    }
    case OP_mul :
    case OP_div :
    case OP_mod : {
	/*
 	 *	1) usual arithmetic conversions are performed.
	 *	2) the resultant type is the type of the operand.
	 *	3) apply only to arithmetic types.
	 *	** a%b = a - (a/b)*b
	 */
	Expr oper, op1, op2;
	Type type, type1, type2;
	/*
	 * apply arithmetic conversions.
	 */
	oper = GetOperand(expr, 1);
	if (oper==0)
	    Punt("illegal (mul/div/mod) operation: missing 1st operand");
	if (! IsArithmeticType(oper->type))
	    Punt("illegal (mul/div/mod): 1st operand is not arithmetic type");
	op1 = UpgradeArithmeticType(oper);
	if (op1!=oper)
	    ChangeOperand(expr, 1, op1);
	oper = GetOperand(expr, 2);
	if (oper==0)
	    Punt("illegal (mul/div/mod) operation: missing 2nd operand");
	if (! IsArithmeticType(oper->type))
	    Punt("illegal (mul/div/mod): 2nd operand is not arithmetic type");
	op2 = UpgradeArithmeticType(oper);
	if (op2!=oper)
	    ChangeOperand(expr, 2, op2);
	/*
	 * determine the type of the result.
	 */
	type1 = op1->type;
	type2 = op2->type;

/* REH  3/23/94 - Ensure ANSI C standard for fp conversions */
	FloatConstType(type1, type2);
/* HER */

	type = DominantType(type1, type2);
	if (! EqualStrength(type, type1)) {
	    op1 = UpgradeType(op1, type);
	    ChangeOperand(expr, 1, op1);
	} 
	if (! EqualStrength(type, type2)) {
	    op2 = UpgradeType(op2, type);
	    ChangeOperand(expr, 2, op2);
	} 
	expr->type = type;
	break;
    }
    case OP_neg : 
    case OP_abs : {
	/*
	 *	1) usual arithmetic conversions are performed.
	 *	** for unsigned, -a == (((unsigned)0xF*+1) - a)
 	 *	   where 0xF* is the biggest possible unsigned int.
	 *	2) the resultant type is the type of the operand.
	 *	3) apply only to arithmetic types.
	 */
	Expr oper, op1;
	/*
	 * apply arithmetic conversions.
	 */
	oper = GetOperand(expr, 1);
	if (oper==0)
	    Punt("illegal (neg/abs) operation: missing 1st operand");
	if (! IsArithmeticType(oper->type))
	    Punt("illegal (neg/abs): 1st operand is not arithmetic type");
	op1 = UpgradeArithmeticType(oper);
	if (op1!=oper)
	    ChangeOperand(expr, 1, op1);
	/*
	 * determine the type of the result.
	 */
	expr->type = CopyType(op1->type);
	break;
    }
    case OP_not : {
	/*
	 *	1) usual arithmetic conversions are performed.
	 *	2) the resultant type is TY_INT.
	 *	3) apply only to arithmetic types and to pointers.
	 */
	Expr oper, op1;
	/*
	 * apply arithmetic conversions.
	 */
	oper = GetOperand(expr, 1);
	if (oper==0)
	    Punt("illegal (not) operation: missing 1st operand");
	if (! IsArithmeticType(oper->type) &&
		! IsPointerType(oper->type))
	    Punt("illegal (not): 1st operand is not arithmetic/pointer");
	op1 = UpgradeArithmeticType(oper);
	if (op1!=oper)
	    ChangeOperand(expr, 1, op1);
	/*
	 * determine the type of the result.
	 */
	expr->type = NewType();
	expr->type->type = TY_INT;
	break;
    }
    case OP_inv : {
	/*
	 *	1) usual arithmetic conversions are performed.
	 *	2) the resultant type is the type of the operand.
	 *	3) apply only to integral types.
	 */
	Expr oper, op1;
	/*
	 * apply arithmetic conversions.
	 */
	oper = GetOperand(expr, 1);
	if (oper==0)
	    Punt("illegal (inv) operation: missing 1st operand");
	if (! IsIntegralType(oper->type))
	    Punt("illegal (inv): 1st operand is not integral type");
	op1 = UpgradeArithmeticType(oper);
	if (op1!=oper)
	    ChangeOperand(expr, 1, op1);
	/*
	 * determine the type of the result.
	 */
	expr->type = CopyType(op1->type);
	break;
    }
    /* SIDE-EFFECT operations */
    case OP_preinc :
    case OP_predec :
    case OP_postinc :
    case OP_postdec : {
	/*
	 *	1) the operand must be arithmetic type or pointer type.
	 *	2) the resultant type is the type of the operand.
	 */
	Expr oper;
	/*
	 * apply arithmetic conversions.
	 */
	oper = GetOperand(expr, 1);
	if (oper==0)
	    Punt("illegal (++,--) operation: missing 1st operand");
	if (! IsArithmeticType(oper->type) &&
		! IsPointerType(oper->type))
	    Punt("illegal (++,--): 1st operand is not arithmetic/pointer");
	/*
	 * determine the type of the result.
	 */
	expr->type = CopyType(oper->type);
	break;
    }
    case OP_assign : {
#if 0
/* BCC - we don't want to cast OP_A??? expressions so early - 6/13/95 */
    case OP_Aadd :
    case OP_Asub :
    case OP_Amul :
    case OP_Adiv :
    case OP_Amod :
    case OP_Arshft :
    case OP_Alshft :
    case OP_Aand :
    case OP_Aor :
    case OP_Axor : {
#endif
	/*
	 *	1) if both operands are arithmetic types, the right
	 *		operand is converted to the type of the left operand.
	 *	2) (E1 op= E2) == (E1 = E1 op (E2))
	 *	3) all right operands and all non-pointer left operands
	 *		must have arithemtic type. (except OP_assign,
	 *		for which the right hand side can also be ptr/arry)
	 *	4) for =, +=, -=, the left operand can be a pointer.
	 *	5) the resultant type is the type of the left operand.
	 */
	Expr op1, op2;
	int ptr1, arith1, struct1, arith2;
	/*
	 * apply required conversions.
	 */
	op1 = GetOperand(expr, 1);
	if (op1==0)
	    Punt("illegal (?=) operation: missing 1st operand");
	ptr1 = IsPointerType(op1->type);
	arith1 = IsArithmeticType(op1->type);
	struct1 = IsStructureType(op1->type);
	if (! (ptr1 | arith1 | struct1)) {
	    Gen_C_Expr(Ferr, expr);
	    Punt("illegal (assignment): illegal LHS of assignment");
	}
	if (struct1) {
	    if (opcode!=OP_assign)
		Punt("illegal (?=): illegal left hand side");
	} else
	if (ptr1) {
	    if ((opcode!=OP_Aadd)&&(opcode!=OP_Asub)&&(opcode!=OP_assign))
		Punt("illegal (?=): illegal left hand side");
	} 
	op2 = GetOperand(expr, 2);
	if (op2==0)
	    Punt("illegal (?=) operation: missing 2nd operand");
	arith2 = IsArithmeticType(op2->type);
	if (!arith2 && (opcode!=OP_assign))
	    Punt("illegal (?=): 2nd operand is not arithmetic (except =)");
	if (arith1 && arith2) {	/* if both operands are arithmetic */
	    /*
	     *	convert the second operand to the type of the first operand.
	     */
	    if (H_conservative_type_promotion)
	    {
		/* Inserts *unnecessary* type conversion code which prevents 
                 * Lopti from making type-unaware optimizations at the expense
		 * of generating very serial, stupid, and slow code for 
		 * those cases.  This is the quick, but not best, way to
		 * make Lopti handle corner cases properly. 
		 */
		if (! EqualStrength(op1->type, op2->type)) 
		{
		    op2 = UpgradeType(op2, op1->type);
		    ChangeOperand(expr, 2, op2);
		}
	    }
	    else
	    {
		/* ITI/BCC - 6/99 */
		if (! EqualStrength(op1->type, op2->type) &&
		    !((op2->type->type & (TY_INT | TY_LONG)) &&
		      (op1->type->type & (TY_CHAR | TY_SHORT))) &&
		    !((op2->type->type & TY_SHORT) &&
		      (op1->type->type & TY_CHAR))) 
		{
		    op2 = UpgradeType(op2, op1->type);
		    ChangeOperand(expr, 2, op2);
		}
	    }
	}
	if (IsStructureType(op2->type)) {
	    if (! struct1) {
	    	Gen_C_Expr(Ferr, expr);
		Punt("illegal assignment: LHS must be struct");
	    }
	}
	/*
	 * determine the type of the result.
	 */
	expr->type = CopyType(op1->type);
	break;
    }

/* BCC - just copy the type of op1 to expr, don't cast op2 - 6/13/95 */
    case OP_Aadd :
    case OP_Asub :
    case OP_Amul :
    case OP_Adiv :
    case OP_Amod :
    case OP_Arshft :
    case OP_Alshft :
    case OP_Aand :
    case OP_Aor :
    case OP_Axor : {
	/*
	 *	1) (E1 op= E2) == (E1 = E1 op (E2))
	 *	2) all right operands and all non-pointer left operands
	 *		must have arithemtic type. (except OP_assign,
	 *		for which the right hand side can also be ptr/arry)
	 *	3) for =, +=, -=, the left operand can be a pointer.
	 *	4) the resultant type is the type of the left operand.
	 */
	Expr op1, op2;
	int ptr1, arith1, struct1, arith2;
	/*
	 * apply required conversions.
	 */
	op1 = GetOperand(expr, 1);
	if (op1==0)
	    Punt("illegal (?=) operation: missing 1st operand");
	ptr1 = IsPointerType(op1->type);
	arith1 = IsArithmeticType(op1->type);
	struct1 = IsStructureType(op1->type);
	if (! (ptr1 | arith1 | struct1)) {
	    Gen_C_Expr(Ferr, expr);
	    Punt("illegal (assignment): illegal LHS of assignment");
	}
	if (struct1) 
	    Punt("illegal (?=): illegal left hand side");
	else
	if (ptr1) {
	    if ((opcode!=OP_Aadd)&&(opcode!=OP_Asub))
		Punt("illegal (?=): illegal left hand side");
	} 
	op2 = GetOperand(expr, 2);
	if (op2==0)
	    Punt("illegal (?=) operation: missing 2nd operand");
	arith2 = IsArithmeticType(op2->type);
	if (!arith2) 
	    Punt("illegal (?=): 2nd operand is not arithmetic");
	/*
	 * determine the type of the result.
	 */
	expr->type = CopyType(op1->type);
	break;
    }
    /* DECISION operations */
    case OP_quest : {
	/*
	 *	1) if possible, the usual arithmetic conversions are
	 *		performed to bring the second and third
	 *		expressions to a common type.
	 *	2) if both are pointers of the same type, the result
	 *		has the common type.
	 *	3) if one is a pointer, and the other is 0, the result
	 *		is a pointer.
	 */
	Expr oper, op1, op2, op3;
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	op3 = GetOperand(expr, 3);
	if ((op1==0)||(op2==0)||(op3==0))
	    Punt("illegal (?:) operation: missing operand");
	/*
	 * apply arithmetic conversions if possible.
	 */
	oper = UpgradeArithmeticType(op1);
	if (oper!=op1) {
	    op1 = oper;
	    ChangeOperand(expr, 1, oper);
	}
	oper = UpgradeArithmeticType(op2);
	if (oper!=op2) {
	    op2 = oper;
	    ChangeOperand(expr, 2, oper);
	}
	oper = UpgradeArithmeticType(op3);
	if (oper!=op3) {
	    op3 = oper;
	    ChangeOperand(expr, 3, oper);
	}
	/*
	 * if op2 and op3 are both arithmetic, try to
	 * bring them to the same type.
	 */
	if (IsArithmeticType(op2->type) && IsArithmeticType(op3->type)) {
	    Type type;
	    type = DominantType(op2->type, op3->type);
	    if (! EqualStrength(type, op2->type)) {
		op2 = UpgradeType(op2, type);
		ChangeOperand(expr, 2, op2);
	    }
	    if (! EqualStrength(type, op3->type)) {
		op3 = UpgradeType(op3, type);
		ChangeOperand(expr, 3, op3);
	    }
	}
	/* 
	 * compute the return type.
	 */

        /* BCC - choose the non-void type between the two operands as the 
		 return type - 9/15/95 */

	if (IsVoidType(op2->type))
	    expr->type = CopyType(op3->type);
	else expr->type = CopyType(op2->type);
	break;
    }
    case OP_disj :
    case OP_conj : {
	/*
	 *	1) the operands must have one of the fundamental types
	 *	2) the result is always TY_INT.
	 */
	Expr op1, op2;
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	if ((op1==0)||(op2==0))
	    Punt("illegal (&&,||) operation: missing operands");
	if (! IsFundamentalType(op1->type))
	    Punt("illegal (&&,||): operand must be arithmetic/pointer");
	if (! IsFundamentalType(op2->type))
	    Punt("illegal (&&,||): operand must be arithmetic/pointer");
	expr->type = NewType();
	expr->type->type = TY_INT;
	break;
    }
    case OP_comma : {
	/*
	 *	1) the resultant type is the type of the second operand.
	 */
	Expr op1, op2;
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	if ((op1==0)||(op2==0))
	    Punt("illegal (,) operation: missing operands");
	expr->type = CopyType(op2->type);
	break;
    }
    /* STRUCTURE access operations */
    case OP_dot :
    case OP_arrow : {
	/*
	 *	1) the first operand of . must be a struct or a union.
	 *	2) the first operand of -> must be a pointer to a
	 *		struct or a union.
	 *	3) the resultant type is the type of the field.
	 */
	Expr op1;
	char *struct_name, *field_name;
	Type type;
	Dcltr dcltr;
	op1 = GetOperand(expr, 1);
	if (op1==0)
	    Punt("illegal (dot,arrow) operation: missing operand");
	/*
	 * make sure it's a structure.
	 */
	type = op1->type;
	if (opcode==OP_dot) {	/* A.field */
	    if (! IsStructureType(type))
		Punt("illegal (.) operation: not a structure");
	} else {		/* A->field */
	    dcltr = type->dcltr;
            /* NJW (2/93) - allow single element arrays */
            if ((dcltr==0)||
                ((dcltr->method!=D_PTR)&&
                 (! ((dcltr->method==D_ARRY)&&
                     (type->dcltr->index->value.scalar == 1)))))
		Punt("illegal (->) operation: not a pointer to structure");
	    type->dcltr = dcltr->next;	/* should be nil */
	    if (! IsStructureType(type))
		Punt("illegal (->) operation: not a pointer to structure");
	    type->dcltr = dcltr;
	}
	/*
	 * find out more about the field.
	 */
	struct_name = type->struct_name;
	field_name = expr->value.string;
	if (type->type&TY_STRUCT) {
	    StructDcl dcl;
	    Field field;
	    dcl = FindStruct(struct_name);
	    if (dcl==0) {
		fprintf(Ferr, "> struct %s is not defined\n", struct_name);
		Punt("illegal (.,->) operation: undefined structure");
	    }
	    field = FindStructField(dcl, field_name);
	    if (field==0) {
		fprintf(Ferr, "> struct %s, field %s is not defined\n", 
			struct_name, field_name);
		Punt("illegal (.,->) operation: undefined structure");
	    }
		/* DMG - if the field type is an array, then the type
		   of the arrow is ptr; the associated index expr, if
		   it exists, converts the ptr to the field type */
	    type = CopyType(field->type);

	    if ( (type->dcltr != NULL) && (type->dcltr->method == D_ARRY) ){
		for (dcltr = type->dcltr; dcltr!=NULL; dcltr=dcltr->next) {
		    if (dcltr->method == D_ARRY) {
			dcltr->method = D_PTR;
			if (dcltr->index == NULL) {
			    dcltr->index = NewExpr(OP_signed);
			    dcltr->index->value.scalar = 0;
			}
		    }
		}
	    }


	} else
	if (type->type&TY_UNION) {
	    UnionDcl dcl;
	    Field field;
	    dcl = FindUnion(struct_name);
	    if (dcl==0) {
		fprintf(Ferr, "> union %s is not defined\n", struct_name);
		Punt("illegal (.,->) operation: undefined structure");
	    }
	    field = FindUnionField(dcl, field_name);
	    if (field==0) {
		fprintf(Ferr, "> union %s, field %s is not defined\n", 
			struct_name, field_name);
		Punt("illegal (.,->) operation: undefined structure");
	    }
	    type = CopyType(field->type);

	    if ( (type->dcltr != NULL) && (type->dcltr->method == D_ARRY) ){
		for (dcltr = type->dcltr; dcltr!=NULL; dcltr=dcltr->next) {
		    if (dcltr->method == D_ARRY) {
			dcltr->method = D_PTR;
			if (dcltr->index == NULL) {
			    dcltr->index = NewExpr(OP_signed);
			    dcltr->index->value.scalar = 0;
			}
		    }
		}
	    }


	} else {
	    Punt("illegal (.,->) operation: operand is not a structure");
	}
	expr->type = type;
	break;
    }
    case OP_indr : {
	/*
	 *	1) the operand must be a pointer. (pointer to ...)
	 *	2) the resultant type is (...)
	 */
	Expr op1;
	Type type;
	Dcltr dcltr;
	op1 = GetOperand(expr, 1);
	if (op1==0) {
	    Gen_C_Expr(Ferr, op1);
	    Punt("illegal (*) operator: missing operand");
	}
	if (! IsPointerType(op1->type) && ! IsArrayType(op1->type)) {
	    Gen_C_Expr(Ferr, op1);
	    Punt("illegal (*) operator: illegal operand");
	}
	dcltr = op1->type->dcltr;
	op1->type->dcltr = dcltr->next;
	type = CopyType(op1->type);
	op1->type->dcltr = dcltr;
	expr->type = type;
	break;
    }
    case OP_addr : {
	/*
	 *	1) the resultant type is (pointer to the type of the operand)
	 */
	Expr op1;
	Type type;
	Dcltr dcltr;
	op1 = GetOperand(expr, 1);
	if (op1==0)
	    Punt("illegal (&) operator: missing operand");
	type = CopyType(op1->type);
	dcltr = NewDcltr();
	dcltr->method = D_PTR;
	dcltr->next = type->dcltr;
	type->dcltr = dcltr;
	expr->type = type;
	break;
    }
    case OP_index : {
	/*
	 *	1) the first operand must be an array (pointer) type.
	 *		(array of ...) or (pointer to ...)
	 *	2) the second operand must be integral type.
	 *	3) the resultant type is ...
	 */
	Expr op1, op2;
	Type type, type1, type2;
	Dcltr dcltr;
	op1 = GetOperand(expr, 1);
	op2 = GetOperand(expr, 2);
	if ((op1==0) || (op2==0))
	    Punt("illegal [] operation: missing operands");
	type1 = op1->type;
	type2 = op2->type;
	if (! IsPointerType(type1) && ! IsArrayType(type1)) {
	    Gen_C_Type(Ferr, type1);
	    Gen_C_Expr(Ferr, expr);
	    Punt("illegal [] operation: 1st operand is not an array");
	}
	if (! IsIntegralType(type2)) {
	    Gen_C_Expr(Ferr, op2);
	    Gen_C_Type(Ferr, type2);
	    Punt("illegal [] operation: 2nd operand is not an integer");
	}
	/*
	 * compute the resultant type.
	 */
	dcltr = type1->dcltr;
	type1->dcltr = dcltr->next;
	type = CopyType(type1);
	type1->dcltr = dcltr;
	expr->type = type;
	break;
    }
    /* CALL/RETURN operations */
    case OP_call : {
	/*
	 *	** we no longer force float into double.
	 *	1) any of type char or short are converted to int;
	 *	2) any of array names are converted to pointers;
	 *	3) the resultant type is the return type of the function.
	 *	4) if the function is not defined, it is assumed to be 
	 *		TY_INT | TY_EXTERN.
	 */
	int i;
	Expr fn, op;
	Dcltr dcltr;
	Type return_type;
	/*
	 * apply type conversions to the parameters.
	 */
	for (i=2; (op=GetOperand(expr, i)) != 0; i++) {
	    if (IsArithmeticType(op->type)) {
		Expr new;
		new = UpgradeArithmeticType(op);
		if (new!=op) {
		    op = new;
		    ChangeOperand(expr, i, new);
		}
	    }
	}
	/*
	 * compute the resultant type.
	 */
	fn = GetOperand(expr, 1);
	if (fn==0)
	    Punt("illegal (call): missing operand");
	if (IsPointerType(fn->type)) {	/* must be a pointer to FN */
	    /*
	     * &FN is the same as FN.
	     */
	    dcltr = fn->type->dcltr;		/* P F return_type */
	    fn->type->dcltr = dcltr->next;	/* F return_type */
	    if (! IsFunctionType(fn->type))
	    	Punt("illegal (call): 1st operand is not a function");
	    fn->type->dcltr = fn->type->dcltr->next;	
	    return_type = CopyType(fn->type);	/* return_type */
	    fn->type->dcltr = dcltr;		/* P F return_type */
	} else
	if (IsFunctionType(fn->type)) {	/* or FN */
	    dcltr = fn->type->dcltr;		/* F return_type */
	    fn->type->dcltr = dcltr->next;	/* return_type */	
	    return_type = CopyType(fn->type);
	    fn->type->dcltr = dcltr;		/* F return_type */
	} else {
	    /*
	     * If (fn->type == TY_INT|TY_EXTERN), then it
	     * is an extern function which is assumed to be TY_INT.
	     * Otherwise, we have an error.
	     */
	    int t;
	    t = fn->type->type;
	    if ((fn->type->dcltr==0) && (t&TY_EXTERN) && (t&TY_INT)) {
		fn->type->dcltr = NewDcltr();
		fn->type->dcltr->method = D_FUNC;
		return_type = NewType();
		return_type->type = (TY_INT | TY_EXTERN);
	    } else
	    	Punt("illegal (call): 1st operand is not a function");
	}
	if (return_type==0)
	    Punt("illegal (call): return type is not yet defined");
	expr->type = return_type;
	break;
    }
    case OP_return : {
	/*
	 *	1) the operand is converted to the return type of
	 *		the function, before returning.
	 *	2) the resultant type is the return type of the function.
	 */
	Expr op1;
	Type type;
	int t;
	op1 = GetOperand(expr, 1);	/* op1 can be 0 */
	if (op1==0) {			/* no return value */
	    type = NewType();
	    type->type = TY_VOID;
	} else {
	    type = currentFuncDcl->type;
	    if (type==0) 
	    	Punt("illegal (return): function type is still undefined");
	    type = CopyType(type);	/* 6-6-90 */
	    t = type->type;
	    if ((t&TY_VOID) & (type->dcltr==0)) {
	    	Punt("illegal (return): void function should not return value");
	    }
	    if (H_verbose_yes && IsStructureType(type)) {	/* return a type */
		fprintf(Ferr, "> warning: function returning a structure\n");
		fprintf(Ferr, "> fn[%s] returns ", currentFuncDcl->name);
		Gen_C_Type(Ferr, type);
	    }
	    if (IsArithmeticType(type)) {
		if (! EqualStrength(type, op1->type)) {
		    op1 = UpgradeType(op1, type);
		    ChangeOperand(expr, 1, op1);
		}
	    }
	}
	expr->type = type;
	break;
    }
    /* CONTROL operations */
    case OP_goto :
    case OP_if :
    case OP_switch : {
	/*
	 *	1) the result is always TY_VOID.
	 *	2) the result is the branch condition.
	 */
	expr->type = NewType();
	expr->type->type = TY_VOID;
	break;
    }
/* NJW */
    case OP_sync:
	break;		/* ignore */
/* WNJ */
    /* LCW - ignore this opcode - 10/24/96 */
    case OP_nulldefine:
        break;
    default :
	Punt("CastExpr: illegal expression");
    }
}

