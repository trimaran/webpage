/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_struct.h
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#ifndef H_STRUCT_H
#define H_STRUCT_H

#include <Hcode/h_ccode.h>

/*
 *      Enum fields.
 */
#define HC_MAX_ENUM_FIELD       2048
#define HC_ILLEGAL_ENUM_VALUE   -9999
#define HC_BASE_ENUM_VALUE      0

extern int		HC_enum();		/* (char *name) */
extern void		HC_assign_enum();	/* (EnumDcl en) */

extern Expr		ReduceExpr();		/* see reduce.c */

extern char		*imp_alloc();
#define ALLOCATE(x)	(x *) imp_alloc (sizeof(x))
#define DISPOSE(x)	imp_free(x, sizeof(*x))

extern FuncDcl		NewFuncDcl();		/* () */
extern VarDcl		NewVarDcl();		/* () */
extern VarList		NewVarList();		/* () */
extern EnumDcl		NewEnumDcl();		/* () */
extern EnumField	NewEnumField();		/* () */
extern StructDcl	NewStructDcl();		/* () */
extern UnionDcl		NewUnionDcl();		/* () */
extern Field		NewField();		/* () */
extern Type		NewType();		/* () */
extern Param            NewParam();     	/* BCC - 1/22/96 */
extern Dcltr		NewDcltr();		/* () */
extern Init		NewInit();		/* () */
extern Block		NewBlock();		/* () */
extern BLink		NewBLink();		/* () */
extern Pragma		NewPragma();		/* (str) */
extern ProfCS		NewProfCS();		/* () */
extern ProfArc		NewProfArc();		/* () */

extern Type		NewBasicType();		/* (TY_..) */
#define IntType()	NewBasicType(TY_INT)

extern 			RemoveParam();       	/* BCC - 1/22/96 */
extern			RemoveType();		/* (type) */
extern			RemoveVarDcl();		/* (var) */
extern			RemoveVarList();	/* (list) */
extern			RemoveVarList2();	/* (list) */
extern			RemoveBlocks();		/* (bb) */
extern FuncDcl		RemoveFuncDcl();	/* (fn) */

extern void		AddOperand();		/* (expr1, expr2) */
extern Expr		GetOperand();		/* (expr, N) */
#define ExprOperand(x,y) GetOperand(y,x)
extern void		ChangeOperand();	/* (expr, N, operand) */

extern Expr		NewInstExpr();		/* (opcode, type) */
extern Expr		NewExpr();		/* (opcode) */
/*
 *	It is the programmer's responsibility to call
 *	CastType() after NewExpr(), or set up the type
 *	definition without going through CastType() as
 *	in NewVarExpr(), NewIntExpr(), and the following functions.
 */
extern Expr		NewVarExpr();		/* (name) */
/*
 *	Before calling NewVarExpr(), the variable must already
 *	have been defined. Otherwise, NewVarExpr() will mistakenly
 *	treat it as an external TY_INT variable.
 */
extern Expr		NewIntExpr();		/* (value) */
extern Expr		NewUnsignedIntExpr();	/* BCC - added - 1/30/96 */
extern Expr		NewRealExpr();		/* (value) */
extern Expr		NewFloatExpr();		/* BCC - (value) - 8/5/96 */
extern Expr		NewDoubleExpr();	/* BCC - (value) - 8/5/96 */
extern Expr		NewCharExpr();		/* (str) */
extern Expr		NewStringExpr();	/* (str) */

#define			DEFAULT_VALUE		0x7FFFFFFF
extern Expr		TrueExpr();		/* () */
extern Expr		FalseExpr();		/* () */
extern Expr		DefaultExpr();		/* () */
extern int		IsTrueExpr();		/* (expr) */
extern int		IsFalseExpr();		/* (expr) */
extern int		IsDefaultExpr();	/* (expr) */

extern int		IsVarExpr();		/* (expr) */

extern int		IsConstOne();		/* (expr) */
extern int		IsConstZero();		/* (expr) */
extern int		IsConstNonZero();	/* (expr) */
extern int		IsIntegralExpr();	/* (expr) */
extern int		IntegralExprValue();	/* (expr) */
extern int		IsFloatExpr();		/* (expr) */
/* BCC - added - 8/5/96 */
extern int		IsDoubleExpr();		/* (expr) */
extern double		FloatExprValue();	/* (expr) */
extern int		IsConstNumber();	/* (expr) */

extern void		AddExpr2BB();		/* (bb, expr) */
extern Block		FindBlock();		/* (fn, bb_id) */

extern Param            CopyParam(); 		/* BCC - 1/22/96 */
extern Dcltr		CopyDcltr();		/* (dcltr) */
extern Dcltr		ConcatDcltr();		/* (A, B) */
extern Dcltr		ReverseDcltr();		/* (dcltr) */

extern ProfArc		CopyProfArc();		/* (arc) */
extern ProfCS		CopyProfCS();		/* (cs) */
extern Pragma		CopyPragma();		/* (pragma) */
extern Type		CopyType();		/* (type) */
extern Expr		CopyExpr();		/* (expr) */
extern 			RemoveExpr();		/* (expr) */

extern			AddStruct();		/* (name, st) */
extern StructDcl	FindStruct();		/* (name) */
extern Field		FindStructField();	/* (st, name) */
extern			AddUnion();		/* (name, un) */
extern UnionDcl		FindUnion();		/* (name) */
extern Field		FindUnionField();	/* (un, name) */
extern			AddEnum();		/* (name, en) */
extern EnumDcl		FindEnum();		/* (name) */
extern EnumField	FindEnumField();	/* (en, name) */
extern 			AddVar();		/* (name, var) */
extern VarDcl		FindVar();		/* (name) */
extern			AddFunction();		/* (name, type) */
extern Symbol		FindFunction();		/* (name) */

extern 			OpenFunction();		/* (func) */
extern			CloseFunction();	/* (func) */
extern Block		CreateNewBlock();	/* () */
extern			ActivateBlock();	/* (bb) */
extern Block		ActiveBlock();		/* () */
extern 			ConnectBlocks();	/* (src_bb, dst_bb, cond) */
extern			AddExpr();		/* (expr) */
extern			EnableBlockPragma();	/* (pragma) */
extern			DisableBlockPragma();	/* () */

extern int		PrefixMatch();		/* (prefix, specifier) */
extern			AddFunctionPragma();	/* (fn, specifier) */
extern Pragma		FindFunctionPragma();	/* (fn, prefix) */
extern 			RemoveFunctionPragma();	/* (fn, pragma) */
extern			AddBlockPragma();	/* (bb, specifier) */
extern Pragma		FindBlockPragma();	/* (bb, prefix) */
extern			RemoveBlockPragma();	/* (bb, pragma) */
extern 			AddExprPragma();	/* (expr, specifier) */
extern Pragma		FindExprPragma();	/* (expr, prefix) */
extern			RemoveExprPragma();	/* (expr, pragma) */

extern int		IsSideEffectFree();	/* (expr) */
extern int		IsBooleanExpr();	/* (expr) */

extern int		SameStructDcl();	/* (st1, st2) */
extern int		SameUnionDcl();		/* (un1, un2) */
extern int		SameEnumDcl();		/* 9en1, en2) */

extern StructDcl	CopyStructDcl();	/* (st) */
extern UnionDcl		CopyUnionDcl();		/* (un) */
extern EnumDcl		CopyEnumDcl();		/* (en) */
extern VarDcl		CopyVarDcl();		/* (var) */
extern FuncDcl		CopyFuncDcl();		/* (fn) */

extern int		EqualDcltr();		/* (d1, d2) */
extern int		EqualType();		/* (t1, t2) */

/*
 *	Remove " " from "name", and returns the number of
 *	characters in " ". -1 is returned if str is not
 *	of the form "name".
 */
extern int		RemoveDQ();		/* (str, buf, N) */

/*
 *	Check that all source fields of links are correctly assigned.
 */
extern int		CheckSourceLink();	/* (bb) */

/*
 *	Constant scale all profile weights.
 */
extern int		ScaleFunctionWeight();	/* (fn, scale) */

extern int		LengthOfBLink();	/* (link) */

extern VarDcl		FindVarList();		/* (list, name) */
extern VarList		AddVar2List();		/* (list, var) */

#endif
