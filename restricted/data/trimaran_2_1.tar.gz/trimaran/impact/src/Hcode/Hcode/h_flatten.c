/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_flatten.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#include <Hcode/h_main.h>
#include <Hcode/h_prag.h>


static FuncDcl currentF = 0;

static Block IF_true_block = 0;
static Block IF_false_block = 0;
/* SAM 6-93 */
static Block curr_flatten_block = NULL;
/* end change */

extern Expr GenDisj2Rev();	/* !(X || Y) */
extern Expr GenConj2Rev();	/* !(X && Y) */
extern Expr GenDisj2();		/* (X || Y) */
extern Expr GenConj2();		/* (X && Y) */
extern Expr GenerateExpr();

/*--------------------------------------------------------------------------*/
Expr NotExpr(expr)
Expr expr;
{
    Expr X, A, B;
    switch (expr->opcode) {
    case OP_not:
	X = GetOperand(expr, 1);
	return CopyExpr(X);
	break;
    case OP_eq:
    case OP_ne:
    case OP_lt:
    case OP_le:
    case OP_gt:
    case OP_ge:
	switch (expr->opcode) {
	case OP_eq:
	    X = NewExpr(OP_ne);
	    break;
	case OP_ne:
	    X = NewExpr(OP_eq);
	    break;
	case OP_lt:
	    X = NewExpr(OP_ge);
	    break;
	case OP_le:
	    X = NewExpr(OP_gt);
	    break;
	case OP_gt:
	    X = NewExpr(OP_le);
	    break;
	case OP_ge:
	    X = NewExpr(OP_lt);
	    break;
	}
	A = GetOperand(expr, 1);
	B = GetOperand(expr, 2);
	A = CopyExpr(A);
	B = CopyExpr(B);
	AddOperand(X, A);
	AddOperand(X, B);
	CastExpr(X);
	return X;
	break;
    default:
	X = NewExpr(OP_not);
	A = CopyExpr(expr);
	AddOperand(X, A);
	CastExpr(X);
	return X;
	break;
    }
}
Expr GenDisj2Rev(expr, true_block, false_block)
Expr expr;
Block true_block, false_block;
{
    Expr X, Y, top, result;
    if (expr->opcode!=OP_disj) 
	Punt("GenDisj2Rev: illegal call");
    X = GetOperand(expr, 1);
    Y = GetOperand(expr, 2);
    /*
     *	! (X || Y) ==> !X && !Y
     */
    top = NewExpr(OP_conj);
    X = NotExpr(X);
    Y = NotExpr(Y);
    AddOperand(top, X);
    AddOperand(top, Y);
    CastExpr(top);
    result = GenConj2(top, true_block, false_block);
    RemoveExpr(top);
    return result;
}
Expr GenConj2Rev(expr, true_block, false_block)
Expr expr;
Block true_block, false_block;
{
    Expr X, Y, top, result;
    if (expr->opcode!=OP_conj) 
	Punt("GenConj2Rev: illegal call");
    X = GetOperand(expr, 1);
    Y = GetOperand(expr, 2);
    /*
     *	! (X && Y) ==> !X || !Y
     */
    top = NewExpr(OP_disj);
    X = NotExpr(X);
    Y = NotExpr(Y);
    AddOperand(top, X);
    AddOperand(top, Y);
    CastExpr(top);
    result = GenDisj2(top, true_block, false_block);
    RemoveExpr(top);
    return result;
}
/*--------------------------------------------------------------------------*/
Expr GenDisj2(expr, true_block, false_block)
Expr expr;
Block true_block, false_block;
{
    Expr A, B, control;
    Block second_block, active_block;
    char c[256];
    if (expr->opcode!=OP_disj) 
	Punt("GenDisj2: illegal call");
    /* SAM 6-93, GEH 10-93 */
/* GEH - Changed to new pragma format - 3/19/95
    sprintf(c, "\"disj%d\"", curr_flatten_block->id);
*/
    c[0] = '\"';	/* start string with d-quote */
    HC_write_name_to_pragma_str(c+1, "disj");
    HC_append_int_to_pragma_str(c+1, curr_flatten_block->id);
    c[strlen(c)+1] = '\0';  /* end string with d-quote */
    c[strlen(c)] = '\"';

    /* end change */
    A = GetOperand(expr, 1);
    B = GetOperand(expr, 2);
    /*
     *	create new basic blocks.
     */
    second_block = CreateNewBlock();
    /*
     *	if (A) 
     */
    if (A->opcode==OP_conj) {
	GenConj2(A, true_block, second_block);
    } else
    if (A->opcode==OP_disj) {
	GenDisj2(A, true_block, second_block);
    } else
    if (A->opcode==OP_not) {
	Expr AA;
	AA = GetOperand(A, 1);
	if (AA->opcode==OP_conj) {
	    GenConj2Rev(AA, true_block, second_block);
	} else
	if (AA->opcode==OP_disj) {
	    GenDisj2Rev(AA, true_block, second_block);
	} else {
	    A = GenerateExpr(A, 0);
	    control = NewExpr(OP_if);
	    AddOperand(control, A);
	    CastExpr(control);
	    /* SAM 6-93 */
	    AddExprPragma(control, FindString(c));
	    /* end change */
	    AddExpr(control);
	}
    } else {
	A = GenerateExpr(A, 0);
	control = NewExpr(OP_if);
	AddOperand(control, A);
	CastExpr(control);
	/* SAM 6-93 */
	AddExprPragma(control, FindString(c));
	/* end change */
	AddExpr(control);
    }
    active_block = ActiveBlock();
    active_block->cnt_type = CNT_IF;
    ConnectBlocks(active_block, true_block, NewIntExpr(1));
    ConnectBlocks(active_block, second_block, NewIntExpr(0));
    /*
     *	generate the true path.
     */
    ActivateBlock(second_block);
    if (B->opcode==OP_conj) {
	GenConj2(B, true_block, false_block);
    } else
    if (B->opcode==OP_disj) {
	GenDisj2(B, true_block, false_block);
    } else
    if (B->opcode==OP_not) {
	Expr BB;
	BB = GetOperand(B, 1);
	if (BB->opcode==OP_conj) {
	    GenConj2Rev(BB, true_block, false_block);
	} else
	if (BB->opcode==OP_disj) {
	    GenDisj2Rev(BB, true_block, false_block);
	} else {
	    B = GenerateExpr(B, 0);
	    control = NewExpr(OP_if);
	    AddOperand(control, B);
	    CastExpr(control);
	    /* SAM 6-93 */
	    AddExprPragma(control, FindString(c));
	    /* end change */
	    AddExpr(control);
	}
    } else {
	B = GenerateExpr(B, 0);
	control = NewExpr(OP_if);
	AddOperand(control, B);
	CastExpr(control);
	/* SAM 6-93 */
	AddExprPragma(control, FindString(c));
	/* end change */
	AddExpr(control);
    }
    active_block = ActiveBlock();
    active_block->cnt_type = CNT_IF;
    /* connection will be made by the caller */
    /*
     *	there is no result, but we will simply return 0 here.
     */
    return NewIntExpr(0);
}
Expr GenConj2(expr, true_block, false_block)
Expr expr;
Block true_block, false_block;
{
    Expr A, B, control;
    Block second_block, active_block;
    char c[256];
    if (expr->opcode!=OP_conj)
	Punt("GenConj2: illegal call");
    /* SAM 6-93, GEH 10-93 */
/* GEH - Changed to new pragma format - 3/19/95
    sprintf(c, "\"conj%d\"", curr_flatten_block->id);
*/
    c[0] = '\"';	/* start string with d-quote */
    HC_write_name_to_pragma_str(c+1, "conj");
    HC_append_int_to_pragma_str(c+1, curr_flatten_block->id);
    c[strlen(c)+1] = '\0';  /* end string with d-quote */
    c[strlen(c)] = '\"';

    /* end change */
    A = GetOperand(expr, 1);
    B = GetOperand(expr, 2);
    /*
     *	create new basic blocks.
     */
    second_block = CreateNewBlock();
    /*
     *	if (A) 
     */
    if (A->opcode==OP_conj) {
	GenConj2(A, second_block, false_block);
    } else
    if (A->opcode==OP_disj) {
	GenDisj2(A, second_block, false_block);
    } else
    if (A->opcode==OP_not) {
	Expr AA;
	AA = GetOperand(A, 1);
	if (AA->opcode==OP_conj) {
	    GenConj2Rev(AA, second_block, false_block);
	} else
	if (AA->opcode==OP_disj) {
	    GenDisj2Rev(AA, second_block, false_block);
	} else {
	    A = GenerateExpr(A, 0);
	    control = NewExpr(OP_if);
	    AddOperand(control, A);
	    CastExpr(control);
	    /* SAM 6-93 */
	    AddExprPragma(control, FindString(c));
	    /* end change */
	    AddExpr(control);
	}
    } else {
	A = GenerateExpr(A, 0);
	control = NewExpr(OP_if);
	AddOperand(control, A);
	CastExpr(control);
	/* SAM 6-93 */
	AddExprPragma(control, FindString(c));
	/* end change */
	AddExpr(control);
    }
    active_block = ActiveBlock();
    active_block->cnt_type = CNT_IF;
    ConnectBlocks(active_block, second_block, NewIntExpr(1));
    ConnectBlocks(active_block, false_block, NewIntExpr(0));
    /*
     *	generate the true path.
     */
    ActivateBlock(second_block);
    if (B->opcode==OP_conj) {
	GenConj2(B, true_block, false_block);
    } else
    if (B->opcode==OP_disj) {
	GenDisj2(B, true_block, false_block);
    } else
    if (B->opcode==OP_not) {
	Expr BB;
	BB = GetOperand(B, 1);
	if (BB->opcode==OP_conj) {
	    GenConj2Rev(BB, true_block, false_block);
	} else
	if (BB->opcode==OP_disj) {
	    GenDisj2Rev(BB, true_block, false_block);
	} else {
	    B = GenerateExpr(B, 0);
	    control = NewExpr(OP_if);
	    AddOperand(control, B);
	    CastExpr(control);
	    /* SAM 6-93 */
	    AddExprPragma(control, FindString(c));
	    /* end change */
	    AddExpr(control);
	}
    } else {
	B = GenerateExpr(B, 0);
	control = NewExpr(OP_if);
	AddOperand(control, B);
	CastExpr(control);
	/* SAM 6-93 */
	AddExprPragma(control, FindString(c));
	/* end change */
	AddExpr(control);
    }
    active_block = ActiveBlock();
    active_block->cnt_type = CNT_IF;
    /* connection will be made by the caller */
    /*
     *	there is no result, but we will simply return 0 here.
     */
    return NewIntExpr(0);
}
/*-------------------------------------------------------------------------*/
/*
 *	Break && || ?: nodes and then convert them into
 *	explicit IF THEN ELSE statements.
 *	Also break return(expr), where expr contains a call.
 *
 *	The (ext) field in all Expr and Block structures are destroyed
 *	after flattening a function.
 *	The (status) field of all Expr are also destroyed in this
 *	process.
 */
/*-------------------------------------------------------------------------*/
#define F_CONST		1
#define F_SIDE_EFFECT	2
#define F_BREAK		4
#define F_CALL		8
#define F_LVALUE	16
#define F_CONTAIN_BREAK	32
#define F_BOOLEAN	64

typedef struct _ExprExt {
	int	node_type;
} _ExprExt, *ExprExt;

#define MAX_EXPR_SIZE	2000
static _ExprExt expr_list[MAX_EXPR_SIZE];
static int expr_list_len = -1;
static long num_must_break_node = 0;
static long num_induced_break_node = 0;
/* BCC - 1/26/96
 * 	 When using acc, vararg list is handled by calling the function called
 *	 "__builtin_va_arg_incr", which is kind of special because it must keep
 *	 the following format when called:
 *	 (some_type *) __builtin_va_arg_incr(argument);
 *	 If we flatten it, we will lose the cast expression ahead of it.
 *	 so whenever we see the keywork "__builtin_va_arg_incr", we set the 
 *	 no_flatten flag and don't flatten it.
 */
static int no_flatten = 0;

static ClearExprExt() {
    expr_list_len = -1;
}
static ExprExt NewExprExt() {
    expr_list_len++;
    if (expr_list_len>=MAX_EXPR_SIZE)
	Punt("NewExprExt : expression tree is too large");
    expr_list[expr_list_len].node_type = 0;
    return (expr_list + expr_list_len);
}

/*
 *	Visit an expression tree in the execution order,
 *	return the index into expr_list, which contains
 *	the result of expr.
 *	Use the extension field of expressions to remember
 *	the returned location.
 */
static VisitExprNode(expr)
Expr expr;
{
    int opcode, i;
    ExprExt ext;
    Expr op;
    int func_call, side_effect, all_const;
    int contain_break;
    int last_break_node, last_side_effect_node;

    if (expr==0) return;
    ext = NewExprExt();		/* create extension field for expr */
    expr->ext = ext;

    /*
     *	for top nodes, (status field is still not assigned)
     *	set the status field to 1.
     */
    if (expr->status==0)
	expr->status = 1;

    /*
     *	step1 : handle basic cases (leaf nodes)
     */
    opcode = expr->opcode;
    switch (opcode) {
    case OP_var :	
	/* 
	 * BCC - if __builtin_va_arg_incr is encountered, don't flatten it so
	 * 	 as to keep the original structure - 1/26/96 
	 */
	if (!strcmp(expr->value.var_name, "__builtin_va_arg_incr"))
	    no_flatten = 1;
	return;
    case OP_enum :
    case OP_signed :
    case OP_unsigned :
    case OP_float :
    /* BCC - added - 8/5/96 */
    case OP_double :
    case OP_char :
    case OP_string :
    case OP_expr_size :		/* compile-time computation */
    case OP_type_size : {	/* compile-time computation */
	ext->node_type |= F_CONST;
	return;
    }
    default :
	/* do nothing: go to step2 */
	break;
    }

    /*
     *	step2 : mark operands by the order they are evaluated.
     */
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	op->status = i;
    }

    /*
     *	step3 : make recursive calls.
     */
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	VisitExprNode(op);
    }

    /*
     *	step4 : see if any of the operand has SIDE_EFFECT.
     *	and also function call.
     */
    func_call = 0;
    side_effect = 0;
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	ExprExt x;
	x = op->ext;
	if (x->node_type & F_SIDE_EFFECT)
	    side_effect = 1;
	if (x->node_type & F_CALL)
	    func_call = 1;
    }
    if (side_effect)
    	ext->node_type |= F_SIDE_EFFECT;
    if (func_call || (opcode==OP_call))
    	ext->node_type |= F_CALL;
    /*
     *	Assignment. (side-effect)
     */
    switch (opcode) {
    case OP_assign :	case OP_preinc :	case OP_predec :
    case OP_postinc :	case OP_postdec :	case OP_Aadd :
    case OP_Asub :	case OP_Amul :		case OP_Adiv :	
    case OP_Amod :	case OP_Arshft :	case OP_Alshft :
    case OP_Aand :	case OP_Aor :		case OP_Axor : {
	Expr op1;
	ExprExt x;
	op1 = GetOperand(expr, 1);
	x = op1->ext;
	x->node_type |= F_LVALUE;	/* LHS of assignment */
	ext->node_type |= F_SIDE_EFFECT;
	break;
    }
    case OP_call :
	ext->node_type |= F_SIDE_EFFECT;
	break;
    default :
	/* do nothing */
	break;
    }

    /*
     *	step5 : see if all operands are constants.
     */
    all_const = 1;
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	ExprExt x;
	x = op->ext;
	if (! (x->node_type & F_CONST))
	    all_const = 0;
	if (op->opcode==OP_call)
	    all_const = 0;
    }
    if (all_const)
	ext->node_type |= F_CONST;

    /*
     *	step6 : detect &&, ||, ?:
     */
    if ((opcode==OP_quest) || (opcode==OP_conj) || (opcode==OP_disj)) {
	num_must_break_node++;
	ext->node_type |= F_BREAK;
    }
    if (opcode==OP_call) {
	num_must_break_node++;
	ext->node_type |= F_BREAK;
    }

    /*
     *	step7 : detect the right-most operand which requires a break;
     */
    last_break_node = 0;
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	ExprExt x;
	x = op->ext;
	if (x->node_type & F_BREAK)
	    last_break_node = i;
    }

    /*
     *	step8 : determine if expr has to be broken because
     *	one of its subtree has been broken.
     */
    contain_break = (ext->node_type & F_BREAK);
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	ExprExt x;
	x = op->ext;
	if (x->node_type & F_CONTAIN_BREAK)
	    contain_break = 1;
    }
    if (contain_break) {
	ext->node_type |= F_CONTAIN_BREAK;
     	if ((expr->status!=1) && !(ext->node_type & F_BREAK)) {
	    ext->node_type |= F_BREAK;
	    num_induced_break_node++;
	}
    }

    /*
     *	step9 : detect the right-most operand which has side-effect.
     */
    last_side_effect_node = 0;
    for (i=1; ((op=GetOperand(expr, i))!=0)&&(i<=last_break_node); i++) {
	ExprExt x;
	x = op->ext;
	if (x->node_type & F_SIDE_EFFECT)
	    last_side_effect_node = i;
    }

    /*
     *	step10 : no need to go furthur if no additional break is required.
     */
    if ((last_break_node==0) || (last_side_effect_node==0)) 
	return;
    
    /*
     *	step11 : add additional break nodes.
     */
    for (i=1; ((op=GetOperand(expr, i))!=0)&&(i<=last_side_effect_node); i++) {
	ExprExt x;
	x = op->ext;
	if (! (x->node_type & F_BREAK)) {
	    x->node_type |= F_BREAK;
	    num_induced_break_node++;
	}
    }
}
static DefineExprStatus(expr)
Expr expr;
{
    Expr op;
    int i;
    ExprExt ext;
    if (expr==0) return;
    ext = (ExprExt) expr->ext;
    if (ext==0) return;
    expr->ext = 0;
    /* 
     * BCC - if no_flatten is set, turn off the F_BREAK bit - 1/26/96
     */
    if (no_flatten == 1)	
	expr->status = (ext->node_type & ~F_BREAK);
    else
	expr->status = ext->node_type;
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	DefineExprStatus(op);
    }
}
/*
 *	Determine which nodes require break.
 *	The decision is placed in the (status) fields
 *	of each expression node. The (ext) fields are
 *	set to 0, after this function has been applied.
 */
static Sequence(expr)
Expr expr;
{
    ClearExprExt();		/* start a new expression tree */
    no_flatten = 0;		/* reset the flag to zero - 1/26/96 */
    VisitExprNode(expr);	/* visit each node and evaluate its type */
    DefineExprStatus(expr);	/* copy the info. from ext to status */
}
/*-------------------------------------------------------------------------*/
/*
 *	copy only one node (do not care about operands)
 */
Expr CopyNode(expr)
Expr expr;
{
    Expr sibling, operand, new;
    if (expr==0) return 0;
    sibling = expr->sibling;
    operand = expr->operands;
    expr->sibling = 0;
    expr->operands = 0;
    new = CopyExpr(expr);
    expr->sibling = sibling;
    expr->operands = operand;
    return new;
}
/*
 *	if result_var is defined, use it as a new
 *	value holder. otherwise, we need to create
 *	a new local variable.
 */
Expr NewLocalVar(result_var, type)
Expr result_var;
Type type;
{
    Expr lvar;
    static int next_var_id = 0;
    char var_name[200];
    lvar = result_var;

    /* BCC - Don't create a variable of type VOID - 5/19/95 */
    if ((type->type & TY_VOID) && (type->dcltr == 0)) 
	return NewIntExpr(0);  /* this will never be used */

    if (lvar==0) {
	VarList lv, ptr;
	VarDcl var;
	Dcltr dcltr;
	/* create a new temporary variable */
	for (;;) {	/* find a new name */
	    sprintf(var_name, "_IMPACT_temp%d", next_var_id++);
	    for (lv = currentF->local; lv!=0; lv=lv->next) 
		if (! strcmp(lv->name, var_name))
		    break;
	    if (lv==0) 
		break;
	}
	var = NewVarDcl();
	var->name = (char *) FindString(var_name);	/* list.c */
	var->type = CopyType(type);
	var->type->type &= TY_MASK;
	var->type->type |= TY_AUTO;		/* local variable */
	/*
	 *	modify D_ARRY to D_PTR
	 *	D_FUNC is not allowed.
	 */
	dcltr = var->type->dcltr;
	if (dcltr!=0) {
#if 0
	    /* Old code, replacement below */
	    if (dcltr->method==D_FUNC)
		Punt("NewLocalVar: cannot create a function variable");
#endif
	    /* New code NJW 11/92 */
	    if (dcltr->method==D_FUNC) {
	  	var->type->dcltr = NewDcltr();
 		var->type->dcltr->method = D_PTR;
 		var->type->dcltr->next = dcltr;	
/*
                dcltr->next = NewDcltr();
                dcltr->next->method = D_FUNC;
                dcltr->method = D_PTR;
*/
            }
            /* End New Code */
	    if (dcltr->method==D_ARRY)
		dcltr->method = D_PTR;
	}
        /*
	 *	use register when possible.
	 */
/**
	if (IsArithmeticType(var->type) || IsPointerType(var->type))
	    var->type->type |= TY_REGISTER;
**/
	currentF->local = AddVar2List(currentF->local, var);
/**
	lv = NewVarList();
	lv->name = var->name;
	lv->var = var;
	ptr = currentF->local;
	if (ptr==0) {
	    currentF->local = lv;
	} else {
	    while (ptr->next!=0) ptr=ptr->next;
	    ptr->next = lv;
	}
**/
      	lvar = NewExpr(OP_var);
  	lvar->value.var_name = var->name;
  	lvar->type = CopyType(var->type);
    } else {
	lvar = CopyExpr(lvar);
    	/* check type : we assume that the type is correct */
    }
    return lvar;
}
/*-------------------------------------------------------------------------*/
/*
 *	generate a ?: subtree
 *	(X ? Y : Z)
 *		if (X) then
 *			result = Y
 *		else
 *			result = Z
 */
Expr GenQuest(expr, result_var)
Expr expr, result_var;
{
    Expr X, Y, Z;
    Expr result, control;
    Block true_path, false_path, active_bb, next_bb;
    X = GetOperand(expr, 1);
    Y = GetOperand(expr, 2);
    Z = GetOperand(expr, 3);
    result = NewLocalVar(result_var, expr->type);
    control = NewExpr(OP_if);		/* if X */
    X = GenerateExpr(X, 0);
    AddOperand(control, X);
    CastExpr(control);
    AddExpr(control);
    active_bb = ActiveBlock();
    active_bb->cnt_type = CNT_IF;
    /*
     * 	create new blocks.
     */
    true_path = CreateNewBlock();
    false_path = CreateNewBlock();
    ConnectBlocks(active_bb, true_path, NewIntExpr(1));
    ConnectBlocks(active_bb, false_path, NewIntExpr(0));
    /*
     *	generate the true_path.
     *	result = Y
     */
    ActivateBlock(true_path);
    Y->status |= F_BREAK;

    /* BCC - 9/16/95 
       If LHS is a null variable (allocated in NewLocalVar()), don't assign */
    if (result->opcode == OP_signed)
	Y = GenerateExpr(Y, 0);
    else
	Y = GenerateExpr(Y, CopyExpr(result));
    control = NewExpr(OP_goto);			/* goto */
    CastExpr(control);
    AddExpr(control);
    true_path = ActiveBlock();
    true_path->cnt_type = CNT_GOTO;
    /*
     *	generate the false_path.
     *	result = Z
     */
    ActivateBlock(false_path);
    Z->status |= F_BREAK;

    /* BCC - 9/16/95 
       If LHS is a null variable (allocated in NewLocalVar()), don't assign */
    if (result->opcode == OP_signed)
	Z = GenerateExpr(Z, 0);
    else
	Z = GenerateExpr(Z, CopyExpr(result));
    control = NewExpr(OP_goto);			/* goto */
    CastExpr(control);
    AddExpr(control);
    false_path = ActiveBlock();
    false_path->cnt_type = CNT_GOTO;
    /*
     *	make final connections.
     */
    next_bb = CreateNewBlock();
    ConnectBlocks(true_path, next_bb, NewIntExpr(1));
    ConnectBlocks(false_path, next_bb, NewIntExpr(1));
    ActivateBlock(next_bb);
    return result;
}
/*
 *	generate a || subtree
 *	(|| A B) 
 *		result = 1
 *		if (A == 0) then
 *			result = (B <> 0)
 */
Expr GenDisj(expr, result_var)
Expr expr, result_var;
{
    Expr A, B, result, assign, true, false, control, nequal;
    Block true_path, false_path, active_bb;
    assign = NewExpr(OP_assign);	/* result = 1 */
    true = NewIntExpr(1);
    result = NewLocalVar(0, true->type);
    AddOperand(assign, CopyExpr(result));
    AddOperand(assign, true);
    CastExpr(assign);
    AddExpr(assign);
    A = GenerateExpr(GetOperand(expr, 1), 0);
    control = NewExpr(OP_if);		/* if A */
    AddOperand(control, A);
    CastExpr(control);
    AddExpr(control);
    /*
     *	create new basic blocks.
     */
    active_bb = ActiveBlock();
    active_bb->cnt_type = CNT_IF;
    true_path = CreateNewBlock();
    false_path = CreateNewBlock();
    ConnectBlocks(active_bb, true_path, NewIntExpr(1));
    ConnectBlocks(active_bb, false_path, NewIntExpr(0));
    /*
     *	generate the false path.
     *	result = (B<>0)
     */
    ActivateBlock(false_path);
    B = GenerateExpr(GetOperand(expr, 2), 0);
    if (B->status & F_BOOLEAN) {	/* B <> 0 */
	nequal = B;
    } else {
    	nequal = NewExpr(OP_ne);	
    	false = NewIntExpr(0);
    	AddOperand(nequal, B);
    	AddOperand(nequal, false);
    	CastExpr(nequal);
    }
    assign = NewExpr(OP_assign);	/* result = (B<>0) */
    AddOperand(assign, CopyExpr(result));
    AddOperand(assign, nequal);
    CastExpr(assign);
    AddExpr(assign);
    control = NewExpr(OP_goto);		/* goto */
    CastExpr(control);
    AddExpr(control);
    false_path = ActiveBlock();
    false_path->cnt_type = CNT_GOTO;
    /*
     *	connect to the true_path.
     */
    ConnectBlocks(false_path, true_path, NewIntExpr(1));
    ActivateBlock(true_path);
    if (result_var!=0) {
	assign = NewExpr(OP_assign);
	AddOperand(assign, CopyExpr(result_var));
	AddOperand(assign, CopyExpr(result));
	CastExpr(assign);
	AddExpr(assign);
	result_var->status |= F_BOOLEAN;
    }
    result->status |= F_BOOLEAN;
    return result;
}
/*
 *	generate a && subtree
 *	(&& A B)
 *		result = 0
 *		if (A) then
 *			result = (B <> 0)
 */
Expr GenConj(expr, result_var)
Expr expr, result_var;
{
    Expr A, B, result, assign, false, control, nequal;
    Block true_path, false_path, active_bb;
    assign = NewExpr(OP_assign);	/* result = false */
    false = NewIntExpr(0);
    result = NewLocalVar(0, false->type);
    AddOperand(assign, CopyExpr(result));
    AddOperand(assign, false);
    CastExpr(assign);
    AddExpr(assign);
    A = GenerateExpr(GetOperand(expr, 1), 0);
    control = NewExpr(OP_if);		/* if A */
    AddOperand(control, A);
    CastExpr(control);
    AddExpr(control);
    /*
     *	create new basic blocks.
     */
    active_bb = ActiveBlock();
    active_bb->cnt_type = CNT_IF;
    true_path = CreateNewBlock();
    false_path = CreateNewBlock();
    ConnectBlocks(active_bb, true_path, NewIntExpr(1));
    ConnectBlocks(active_bb, false_path, NewIntExpr(0));
    /*
     *	generate the true path.
     *	result = (B<>0)
     */
    ActivateBlock(true_path);
    B = GenerateExpr(GetOperand(expr, 2), 0);
    if (B->status & F_BOOLEAN) {	/* B <> 0 */
	nequal = B;
    } else {
    	nequal = NewExpr(OP_ne);	
    	false = NewIntExpr(0);
    	AddOperand(nequal, B);
    	AddOperand(nequal, false);
    	CastExpr(nequal);
    }
    assign = NewExpr(OP_assign);	/* result = (B<>0) */
    AddOperand(assign, CopyExpr(result));
    AddOperand(assign, nequal);
    CastExpr(assign);
    AddExpr(assign);
    control = NewExpr(OP_goto);		/* goto */
    CastExpr(control);
    AddExpr(control);
    true_path = ActiveBlock();
    true_path->cnt_type = CNT_GOTO;
    /*
     *	connect to the false_path.
     */
    ConnectBlocks(true_path, false_path, NewIntExpr(1));
    ActivateBlock(false_path);
    if (result_var!=0) {
	assign = NewExpr(OP_assign);
	AddOperand(assign, CopyExpr(result_var));
	AddOperand(assign, CopyExpr(result));
	CastExpr(assign);
	AddExpr(assign);
	result_var->status |= F_BOOLEAN;
    }
    result->status |= F_BOOLEAN;
    return result;
}
/*
 *	Return 1 if lval is not affected by any side-effect
 *	expressions. Otherwise, return 0. 
 *	We should be very conservative in interpreting this condition.
 *	Invariant if:
 *	case1: lval = scalar variable (dcltr=0)
 *	case2: lval = array (which cannot be changed) 
 *			index must be defined.
 *	case3: lval = structure (dcltr=0)
 *	case4: lval = OP_dot
 */
static int InvariantLval(lval)
Expr lval;
{
    if (lval==0) Punt("InvariantLval: nil lval");
    if (lval->opcode==OP_var) {
	Type type;
	type = lval->type;
	if (type->dcltr==0) {
	    return 1;
	} else {
	    int method;
	    method = type->dcltr->method;
	    if (method==D_FUNC)
		return 1;
	    if ((method==D_ARRY) && (type->dcltr->index!=0))
		return 1;
	    return 0;
	}
    } else
    if (lval->opcode==OP_dot) {
/*
	Expr op;
	op = GetOperand(lval, 1);
	return InvariantLval(op);
*/
/* REH 8/31/93 ---
   The idea here is to prevent flattening of assignments to
   a bit field of a structure/union accessed via a pointer 
   to the structure
*/
        if ( lval->operands && lval->operands->type ) {
	    if ( lval->operands->type->type & TY_UNION )  {
		UnionDcl dcl = FindUnion(lval->operands->type->struct_name);
		Field fld;
		if ( dcl == NULL )
		    Punt("InvariantLval: unable to locate union information");

		for ( fld = dcl->fields; fld != NULL; fld = fld->next )  {
                    if ( !strcmp(fld->name,lval->value.var_name) )
                        break;
		}
		if ( fld == NULL )
                    Punt("InvariantLval: unable to locate union field");
                if ( fld->bit_field != NULL )
                    /* structure pointer accessing a bit field, call it invariant */
                    return 1;
		else  {
            	    Expr op = GetOperand(lval, 1);
            	    return InvariantLval(op);
	        }
            }
	    else if ( lval->operands->type->type & TY_STRUCT )  {
		StructDcl dcl = FindStruct(lval->operands->type->struct_name);
		Field fld;
		if ( dcl == NULL )
		    Punt("InvariantLval: unable to locate structure information");

		for ( fld = dcl->fields; fld != NULL; fld = fld->next )  {
                    if ( !strcmp(fld->name,lval->value.var_name) )
                        break;
		}
		if ( fld == NULL )
                    Punt("InvariantLval: unable to locate structure field");
                if ( fld->bit_field != NULL )
                    /* structure pointer accessing a bit field, call it invariant */
                    return 1;
		else  {
            	    Expr op = GetOperand(lval, 1);
            	    return InvariantLval(op);
	        }
            }
	}
	else  {
            Expr op = GetOperand(lval, 1);
            return InvariantLval(op);
	}
/* HER 8/31/93 */
    }
/* REG 8/31/93 */
    else if ( lval->opcode == OP_arrow )  {
        if ( lval->operands && lval->operands->type ) {
	    if ( lval->operands->type->type & TY_UNION )  {
	        /* we have a union pointer */
		UnionDcl dcl = FindUnion(lval->operands->type->struct_name);
		Field fld;
		if ( dcl == NULL )
		    Punt("InvariantLval: unable to locate union information");

		for ( fld = dcl->fields; fld != NULL; fld = fld->next )  {
                    if ( !strcmp(fld->name,lval->value.var_name) )
                        break;
		}
		if ( fld == NULL )
                    Punt("InvariantLval: unable to locate union field");
                if ( fld->bit_field != NULL )
                    /* structure pointer accessing a bit field, call it invariant */
                    return 1;
 	    }
	    else if ( lval->operands->type->type & TY_STRUCT )  {
	        /* we have a structure pointer */
		StructDcl dcl = FindStruct(lval->operands->type->struct_name);
		Field fld;
		if ( dcl == NULL )
		    Punt("InvariantLval: unable to locate structure information");

		for ( fld = dcl->fields; fld != NULL; fld = fld->next )  {
                    if ( !strcmp(fld->name,lval->value.var_name) )
                        break;
		}
		if ( fld == NULL )
                    Punt("InvariantLval: unable to locate structure field");
                if ( fld->bit_field != NULL )
                    /* structure pointer accessing a bit field, call it invariant */
                    return 1;
	    }
	    return 0;
	}	
        else
	    return 0;	
/* HER */
    } else
	return 0;
}
/*
 *	generate a complete expression tree, break into
 *	subtrees if necessary.
 */
Expr GenerateExpr(expr, result_var)
Expr expr, result_var;
{
    int status, opcode;
    Expr new, op, newop, op1, op2;
    Expr location, assign, temp, indr;
    int i;
    if (expr==0)
	Punt("GenerateExpr: nil expr");
    status = expr->status;
    opcode = expr->opcode;
    if (status & F_LVALUE) {	/* LHS of assignment */
	if (result_var!=0) Punt("GenerateExpr: internal error 1");
	/*
	 *	expand the entire tree first.
	 */
	new = CopyNode(expr);	/* type is defined */
	for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	    newop = GenerateExpr(op, 0);
	    AddOperand(new, newop);
	}
	/*
	 *	For F_BREAK and variant  nodes, now create :
	 *	1) t = &new;
	 *	2) return *t;
	 */
	if ((status & F_BREAK) && ! InvariantLval(new)) {
	    location = NewExpr(OP_addr);	/* &new */
	    AddOperand(location, new);
	    CastExpr(location);
	    temp = NewLocalVar(result_var, location->type);	/* temp */
	    assign = NewExpr(OP_assign);	/* temp = &new */
	    AddOperand(assign, temp);
	    AddOperand(assign, location);
	    CastExpr(assign);
	    AddExpr(assign);			/* output(temp=&new) */
	    temp = CopyExpr(temp);
	    indr = NewExpr(OP_indr);		/* *temp */
	    AddOperand(indr, temp);
	    CastExpr(indr);
		/* DMG - if new had a dep pragma, the dependence is really 
		    associated with the OP_indr now */
	    indr->pragma = new->pragma;
	    new->pragma = NULL;
	    new = indr;
	}
	return new;
    } else {
	if (! (status & F_BREAK)) {		/* no need to break */
	    if (result_var!=0) Punt("GenerateExpr: internal error 2");
	    if (opcode==OP_assign) {		/* special case of = */
		op1 = GetOperand(expr, 1);
		op2 = GetOperand(expr, 2);
		if ((op1->opcode==OP_var) &&
			(op2->status & F_BREAK)) {
		    return GenerateExpr(op2, op1);
		}
	    }
	    if (opcode==OP_if) {
		op1 = GetOperand(expr, 1);
		if (op1->opcode==OP_conj) {
		    return GenConj2(op1, IF_true_block, IF_false_block);
		} else
		if (op1->opcode==OP_disj) {
		    return GenDisj2(op1, IF_true_block, IF_false_block);
		} else
		if (op1->opcode==OP_not) {
                    op2 = GetOperand(op1, 1);
                    if (op2->opcode==OP_conj) {
                        return GenConj2Rev(op2, IF_true_block, IF_false_block);
                    } else
                    if (op2->opcode==OP_disj) {
                        return GenDisj2Rev(op2, IF_true_block, IF_false_block);
                    }
                }
	    }
	    new = CopyNode(expr);		/* type is defined */
	    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
		newop = GenerateExpr(op, 0);
		AddOperand(new, newop);	
	    }
	    switch (new->opcode) {		/* detect boolean operations */
	    case OP_or:
	    case OP_xor:
	    case OP_and:
		op1 = GetOperand(new, 1);
		op2 = GetOperand(new, 2);
		if ((op1->status&F_BOOLEAN) && (op2->status&F_BOOLEAN))
		    new->status |= F_BOOLEAN;
		break;
	    case OP_eq:
	    case OP_ne:
	    case OP_lt:
	    case OP_le:
	    case OP_gt:
	    case OP_ge:
		new->status |= F_BOOLEAN;
		break;
	    default : break;
	    }
	    return new;
	} else {
	    /*
	     *	output(t = expr)
	     * 	return t
	     */
	    switch (opcode) {
	    /*
	     *	NO operand / compile-time expressions
	     */
	    case OP_var: {
		Type type = expr->type;
		if (IsFunctionType(type)) {
		    if (result_var==0) {
		    	new = CopyExpr(expr);	/* this is a constant */
		    } else {
		    	assign = NewExpr(OP_assign);
		    	new = CopyExpr(result_var);
		    	AddOperand(assign, new);
		    	AddOperand(assign, CopyExpr(expr));
		    	CastExpr(assign);
		    	AddExpr(assign);
			new = CopyExpr(result_var);
		    }
		} else {
		    assign = NewExpr(OP_assign);
		    new = NewLocalVar(result_var, type);
		    AddOperand(assign, new);
		    AddOperand(assign, CopyExpr(expr));
		    CastExpr(assign);
		    AddExpr(assign);
		    new = CopyExpr(new);
		} 
		break;
	    }
	    case OP_enum:
	    case OP_signed:
	    case OP_unsigned:
   	    case OP_float:
	    /* BCC - added - 8/5/96 */
	    case OP_double:
	    case OP_char:
	    case OP_string:
	    case OP_expr_size:
	    case OP_type_size: {
		if (result_var!=0) {
		    assign = NewExpr(OP_assign);
		    new = CopyExpr(result_var);
		    AddOperand(assign, new);
		    AddOperand(assign, CopyExpr(expr));
		    CastExpr(assign);
		    AddExpr(assign);
		    new = CopyExpr(new);
		} else {
		    new = CopyExpr(expr);
		}
		break;
	    }
	    /*
	     *	BOOLEAN BINARY
	     */
	    case OP_eq:
	    case OP_ne:
	    case OP_lt:
	    case OP_le:
	    case OP_gt:
	    case OP_ge: {
		assign = NewExpr(OP_assign);
		new = NewLocalVar(result_var, expr->type);
		AddOperand(assign, new);
		expr->status &= ~F_BREAK;
		op = GenerateExpr(expr, 0);
		expr->status |= F_BREAK;
		AddOperand(assign, op);
		CastExpr(assign);
		AddExpr(assign);
		new->status |= F_BOOLEAN;
		new = CopyExpr(new);
		break;
	    }
	    /*
	     *	NORMAL
	     */
	    case OP_dot:
	    case OP_arrow:
	    /* BCC - moved below for handling casting to void - 5/28/95 */
	    /* case OP_cast: */
	    case OP_neg:
	    case OP_not:
	    case OP_inv:
	    case OP_abs:
	    case OP_indr:
	    case OP_addr: 
	    case OP_or:
	    case OP_xor:
	    case OP_and:
	    case OP_rshft:
	    case OP_lshft:
	    case OP_add:
	    case OP_sub:
	    case OP_mul:
	    case OP_div:
	    case OP_mod: 
	    case OP_index: {
		assign = NewExpr(OP_assign);
		new = NewLocalVar(result_var, expr->type);
		AddOperand(assign, new);
		expr->status &= ~F_BREAK;
		op = GenerateExpr(expr, 0);
		expr->status |= F_BREAK;
		AddOperand(assign, op);
		CastExpr(assign);
		AddExpr(assign);
		if ((opcode==OP_or) || (opcode==OP_xor) || (opcode==OP_and)) {
		    op1 = GetOperand(op, 1);
		    op2 = GetOperand(op, 2);
		    if ((op1->status&F_BOOLEAN) && (op2->status&F_BOOLEAN))
			new->status |= F_BOOLEAN;
		}
		new = CopyExpr(new);
		break;
	    }

	    /*
	     *	CAST BCC - 5/28/95 
	     */
	    case OP_cast: {
		Type type;
		int t;
		type = expr->type;
		t = type->type & TY_MASK;
		expr->status &= ~F_BREAK;
		op = GenerateExpr(expr, 0);
		expr->status |= F_BREAK;
		if ((type->dcltr==0) && (t==TY_VOID)) {
                    AddExpr(op);
                    new = NewIntExpr(0);  /* this will never be used */
		} else {
		    assign = NewExpr(OP_assign);
		    new = NewLocalVar(result_var, expr->type);
		    AddOperand(assign, new);
		    AddOperand(assign, op);
		    CastExpr(assign);
		    AddExpr(assign);
		    new = CopyExpr(new);
		}
		break;
	    }
	    /*
	     *	ASSIGNMENT
	     */
	    case OP_assign:
	    case OP_preinc:
	    case OP_predec:
	    case OP_postinc:
	    case OP_postdec:
	    case OP_Aadd:
	    case OP_Asub:
	    case OP_Amul:
	    case OP_Adiv:
	    case OP_Amod:
	    case OP_Arshft:
	    case OP_Alshft:
	    case OP_Aand:
	    case OP_Aor:
	    case OP_Axor: {
		assign = NewExpr(OP_assign);
		new = NewLocalVar(result_var, expr->type);
		AddOperand(assign, new);
		expr->status &= ~F_BREAK;
		op = GenerateExpr(expr, 0);
		expr->status |= F_BREAK;
		AddOperand(assign, op);
		CastExpr(assign);
		AddExpr(assign);
		new = CopyExpr(new);
		break;
	    }
	    /*
	     *	CONTROL
	     */
	    case OP_return:
	    case OP_goto:
	    case OP_if:
	    case OP_switch:
		Punt("GenerateExpr: return/goto/if/switch cannot be broken");
		break;
	    /*
	     *	SPECIAL
	     */
	    case OP_call: {
		/*
		 *	If the returned type is VOID, there is
		 *	no need to generate t=call().
		 */
		Type type;
	 	int t;
		type = expr->type;
		t = type->type & TY_MASK;
		expr->status &= ~F_BREAK;	/* generate the call */
		op = GenerateExpr(expr, 0);
		expr->status |= F_BREAK;
		if ((type->dcltr==0) && (t==TY_VOID)) {
		    AddExpr(op);
		    new = NewIntExpr(0);  /* this will never be used */
		} else {
		    assign = NewExpr(OP_assign);
		    new = NewLocalVar(result_var, expr->type);
		    AddOperand(assign, CopyExpr(new));
		    AddOperand(assign, op);
		    CastExpr(assign);
	 	    AddExpr(assign);
		}
		break;
	    }
	    case OP_comma: {
		int status;
		op1 = GetOperand(expr, 1);
		op2 = GetOperand(expr, 2);
		status = op1->status;		/* op1 has no output */
/****** DMG 7/94
		op1->status &= ~F_BREAK;
*********/
		op1->status |= F_BREAK;
		AddExpr(GenerateExpr(op1, 0));
		op1->status = status;
		status = op2->status;		/* op2 must output */
		op2->status |= F_BREAK;
		new = GenerateExpr(op2, result_var);
		op2->status = status;
		break;
	    }
	    case OP_quest:
		new = GenQuest(expr, result_var);
		break;
	    case OP_disj:
		new = GenDisj(expr, result_var);
		break;
	    case OP_conj:
		new = GenConj(expr, result_var);
		break;
	    default :
		Punt("GenerateExpr: illegal opcode");
	    }
	    return new;
	}
    }
}
/*
 *	If (expr->status & F_BREAK), then appropriate
 *	conversions are applied on expr to reduce the
 *	F_BREAK condition.
 */
static Partition(expr)
Expr expr;
{
    Expr result;
    if (expr==0) return;
    /*
     *	top-level fn_call does not require BREAK.
     */
    if (expr->opcode==OP_call) {
    	expr->status &= ~F_BREAK;
    }
    result = GenerateExpr(expr, 0);
    /*
     *	no need to output leaf-level nodes.
     */
    switch (result->opcode) {
    case OP_var:
    case OP_enum:
    case OP_signed:
    case OP_unsigned:
    case OP_float:
    /* BCC - added - 8/5/96 */
    case OP_double:
    case OP_char:
    case OP_string:
    case OP_expr_size:
    case OP_type_size:
	break;	/* do nothing */
    default:
    	AddExpr(result);	/* top level expression */
    }
}
/*-------------------------------------------------------------------------*/
static ClearExtensionField(expr)
Expr expr;
{
    Expr op;
    int i;
    if (expr==0) return;
    /*
     *	first, set the extension field to all 0s.
     */
    expr->status = 0;
    expr->ext = 0;
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	ClearExtensionField(op);
    }
}
/*
 *	flatten one expr at a time.
 */
static FlattenExpr(expr)
Expr expr;
{
    ClearExtensionField(expr);
    /*
     *	first determine a legal sequential ordering of all
     *	computations envolved in the expression.
     */
    Sequence(expr);
    /*
     *	begin the partitioning process.
     */
    Partition(expr);
    /*
     *	clear the extension field.
     */
    ClearExtensionField(expr);
}
/*
 *	convert the expressions in bb, and insert the
 *	transformed version in the ActiveBlock.
 */
static FlattenBlock(bb)
Block bb;
{
    Expr expr;
    /*
     *	apply the pragma on all blocks generated.
     */
    /* SAM 6-93 */
    curr_flatten_block = bb;
    /* end change */
    EnableBlockPragma(bb->pragma);
    for (expr=bb->first; expr!=0; expr=expr->next) {
	FlattenExpr(expr);
    }
    DisableBlockPragma();
    /* SAM 6-93 */
    curr_flatten_block = NULL;
    /* end change */
}
/*
 *	reconstruct the function definition, so all
 *	&& || ?: are removed, and calls are moved to the
 *	top level.
 */
Flatten(func)
FuncDcl func;
{
    Pragma pragma;
    Block bb, bb_list;
    int old_entry;

    currentF = func;

    /*
     *	can only flatten once.
     */
    pragma = FindFunctionPragma(func, "\"flatten\"");
    if (pragma!=0)
	return;
    /*
     *	save old function body definition.
     */
    bb_list = func->blocks;
    func->blocks = 0;
    old_entry = func->entry_bb;
    func->entry_bb = 0;
    OpenFunction(func);
    /*
     *	for each existing basic block, create
     *	a new basic block. and place it into
     *	the old basic block's extension field.
     */
    for (bb=bb_list; bb!=0; bb=bb->next) {
	Block new;
	new = CreateNewBlock();
	bb->ext = new;
	if (bb->id==old_entry)
	    func->entry_bb = ((Block) (bb->ext))->id;
    }
    /*
     * 	begin to modify the function body,
     *	one basic block at a time.
     */
    for (bb=bb_list; bb!=0; bb=bb->next) {
	/*
	 *	transform one basic block at a time.
	 *	several basic block may result.
	 *	however, there will be only one ENTRY
	 *	and one EXIT basic block.
	 *	therefore, the inter-basic block connections
	 *	remain the same as the original definition.
	 */
	BLink link;
	int cnt_type;
	Block bb_end;
	cnt_type = bb->cnt_type;
	/*
	 *	define the true and false path of OP_if
	 */
	if (cnt_type==CNT_IF) {
	    IF_true_block = 0;
	    IF_false_block = 0;
	    for (link=bb->destination; link!=0; link=link->next) {
		if (IsTrueExpr(link->condition)) {
		    IF_true_block = link->dest_bb->ext;
		} else
		if (IsFalseExpr(link->condition)) {
		    IF_false_block = link->dest_bb->ext;
		} else {
		    Punt("OP_if: illegal condition code");
		}
	    }
	    if (IF_true_block==0)
		Punt("OP_if: missing taken path");
	    if (IF_false_block==0)
		Punt("OP_if: missing fall-thru path");
	} else {
	    IF_true_block = 0;
	    IF_false_block = 0;
	}
	/*
	 *	emit code for a basic block.
	 */
/* NJW */
EnableBlockPragma(bb->pragma);
	ActivateBlock(bb->ext);
DisableBlockPragma();
/* WJN */
	FlattenBlock(bb);
	bb_end = ActiveBlock();
	bb_end->cnt_type = cnt_type;
	/*
	 *	define the outgoing arcs.
	 */
	for (link=bb->destination; link!=0; link=link->next) {
	    ConnectBlocks(bb_end, link->dest_bb->ext, 
		CopyExpr(link->condition));
	}
    }
    CloseFunction(func);
    /*
     *	remove the old function body definition.
     */
    RemoveBlocks(bb_list);
    /*
     *	add a function-level pragma.
     */
    AddFunctionPragma(func, "\"flatten\"");

    if (H_verbose_yes && (Ferr!=0)) {
	static last_mb=0, last_ib=0;
	fprintf(Ferr, "function (%s) : \n", func->name);
	fprintf(Ferr, "number of must break nodes = %u (total %u)\n", 
		num_must_break_node-last_mb, num_must_break_node);
	fprintf(Ferr, "number of induced break nodes = %u (total %u)\n", 
		num_induced_break_node-last_ib, num_induced_break_node);
	last_mb = num_must_break_node;
	last_ib = num_induced_break_node;
    }

    currentF = 0;
}

