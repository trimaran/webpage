/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	h_ccode.h
 *	Author:	Po-hua Chang, Wen-mei Hwu
\*****************************************************************************/
#ifndef H_CCODE_H
#define H_CCODE_H

#include <library/types.h>
#include <library/symbol.h>

/*===========================================================================*/
/*
 *	At all time, the internal CCODE structure is a tree structure.
 *	Maintaining a tree structure requires substantially more
 *	internal memory space, because we can not share trivial
 *	objects, such as (type INT). 
 *	However, we can completely dispose the data structure
 *	after they are used. For example, we process a function
 *	at a time. And after each time, we dispose the space.
 *	The only exception is strings, which we never dispose.
 *	User of the internal structure is not allowed to alter
 *	the structure (READ ONLY). However, the extension (ext)
 *	fields are managed by the user, and is not destroyed by
 *	ccode.c
 */
/*===========================================================================*/
/*
 * It may be necessary to modify the following constants to
 * compile larger programs.
 */
#define MAX_VAR_TBL_SIZE	5119
#define MAX_STRUCT_TBL_SIZE	5119
/* 6/20/97 -- sias -- MAX_STRUCT_TBL_SIZE increased from 2047 to 5119
	to compile SPECINT95 124.m88ksim.
	MAX_UNION_TBL_SIZE, MAX_ENUM_TBL_SIZE, MAX_STRING_TBL_SIZE,
	MAX_FUNC_TBL_SIZE changed from 2047 (composite) to 2053 (prime) iaw
	symbol.h's comment regarding hash table size. */
#define MAX_UNION_TBL_SIZE	2053
#define MAX_ENUM_TBL_SIZE	2053
#define MAX_STRING_TBL_SIZE	2053
#define MAX_FUNC_TBL_SIZE	2053	/* 7-bits is the most for UNIX-based */
#define MAX_OPCODE_TBL_SIZE	201

/*===========================================================================*/
/*
 * Extension.
 * It is desirable to attach additional information to the
 * data structures, which we will define below. In different
 * phases of the compilation process, different sets of
 * extended definitions are necessary. Therefore, we should
 * keep the extension field general. We provide a general
 * purpose pointer to whatever data structures the programmer
 * will define in each phase of the compiler.
 */
typedef Void *Extension;

/*===========================================================================*/
/*
 * Profile record.
 * (id, condition) identifies an instance of the
 * invocations of a function/basic_block.
 */
typedef struct _ProfFN {
	int		fn_id;		/* profile id */
	double		weight;		/* profile weight */
	struct _ProfCS	*calls;		/* call sites */
} _ProfFN, *ProfFN;

typedef struct _ProfCS {
	int		call_site_id;	/* call site id */
	int		callee_id;	/* callee id */
	double		weight;		/* invocation count */
 	struct _ProfCS	*next;
} _ProfCS, *ProfCS;

typedef struct _ProfBB {
	double		weight;		/* profile weight */
	struct _ProfArc	*destination;	/* control transitions */
} _ProfBB, *ProfBB;

typedef struct _ProfArc {
	int		bb_id;		/* destination bb */
	int		condition;	/* branch condition */
	double		weight;		/* profile weight */
	struct _ProfArc	*next;
} _ProfArc, *ProfArc;		

/*===========================================================================*/
/* 
 * Symbol Table Structure.
 * This is based on the symbol table management functions
 * provided by the impact library. 
 * The "type" attribute of Symbol is used to designate
 * one of the below types.
 */
#define ST_VAR		0	/* global variable table */
#define ST_STRUCT	1	/* struct tag table */
#define ST_UNION	2	/* union tag table */
#define ST_ENUM		3	/* enum tag table */
#define ST_STRING	4	/* string table */
#define ST_FUNC		5	/* function table */
#define ST_OPCODE	6	/* opcode table */
/*
 * The "ptr" attribute of Symbol is used to point to 
 * the below data structure.
 */
typedef union _Sym {
	struct _VarDcl		*varDcl;	/* variable declarations */
	struct _StructDcl	*structDcl;	/* struct definitions */
	struct _UnionDcl	*unionDcl;	/* union definitions */
	struct _EnumDcl		*EnumDcl;	/* enum definitions */
	struct _FuncDcl		*funcDcl;	/* function definitions */
} _Sym, *Sym;

typedef int SymTable[7];		/* we need 7 symbol table IDs (see symbol.c) */
extern SymTable SymbolTable;	/* ccode.c */

/*===========================================================================*/
/* Type Specifier.
 * A type specifier consists of two pieces of information:
 * 1) type : data type and special type properties of the data holder, and
 * 2) dcltr : the access pattern of the data holder.
 * The type attribute can be further broken down to three
 * subfields: (qualifier, class, data_type). To efficiently
 * represent these fields, bit vectors can be used. The meaning
 * of each bit is defined as below:
 */
/* (qualifier) */
#define TY_CONST	0x00000001		/* constant qualifier */
#define TY_VOLATILE	0x00000002		/* volatile qualifier */
#define TY_NOALIAS	0x00000004		/* no_alias qualifier */
/* (class) */
#define TY_REGISTER	0x00000008		/* auto in register */
#define TY_AUTO		0x00000010		/* auto */
#define TY_STATIC	0x00000020		/* static */
#define TY_EXTERN	0x00000040		/* extern */
#define TY_GLOBAL	0x00000080		/* global variable */
#define TY_PARAMETER	0x00000100		/* parameter */
/* (type) */
#define TY_VOID		0x00000200		/* void */
#define TY_CHAR		0x00000400		/* char */
#define TY_SHORT	0x00000800		/* short */
#define TY_INT		0x00001000		/* int */
#define TY_LONG		0x00002000		/* long */
#define TY_FLOAT	0x00004000		/* float */
#define TY_DOUBLE	0x00008000		/* double */
#define TY_SIGNED	0x00010000		/* signed */
#define TY_UNSIGNED	0x00020000		/* unsigned */
#define TY_STRUCT	0x00040000		/* struct */
#define TY_UNION	0x00080000		/* union */
#define TY_ENUM		0x00100000		/* enum */
#define TY_VARARG	0x00200000		/* vararg */
#define TY_BIT_FIELD	0x00400000		/* bit field */

/* 
 * useful macros 
 */
/* BCC - added TY_VARARG - 1/24/96 */
#define TY_MASK  (TY_VOID|TY_CHAR|TY_SHORT|TY_INT|TY_LONG|TY_FLOAT|TY_DOUBLE| \
	TY_SIGNED|TY_UNSIGNED|TY_STRUCT|TY_UNION|TY_ENUM|TY_VARARG)

#define TY_INTEGRAL \
	(TY_CHAR|TY_SHORT|TY_INT|TY_LONG|TY_SIGNED|TY_UNSIGNED|TY_ENUM)

#define TY_REAL (TY_FLOAT|TY_DOUBLE)

#define TY_ARITHMETIC	(TY_INTEGRAL | TY_REAL)

#define TY_STRUCTURE (TY_UNION|TY_STRUCT)

/*
 * For TY_STRUCT, TY_UNION, and TY_ENUM, another field is
 * required to specify the structure. The simplest way
 * is to remember the name of the structure. When we
 * are required to know the structure information, we
 * can use the name to index into the symbol table.
 * This may be less time efficient than remembering
 * the location of the struture definition, and save
 * the symbol table lookup. However, I trust that the
 * symbol table hashing scheme is good, and it is better
 * to keep the data structures independent of each other
 * to simplify the debugging (shorter pointer chains).
 */
typedef struct _Type {
	int		type;		/* type bit_vector */
	char		*struct_name;	/* structure name (struct/union/enum) */
	struct _Dcltr	*dcltr;		/* access pattern */
} _Type, *Type;
/*
 * The access pattern is a list of access declarators.
 * The actions are specified from the beginning of the
 * list to the end of the list. For example, (F, P) means
 * that it is a function which returns a pointer.
 * There are three types of access declarators:
 * 1: pointer 
 * 2: array index?
 * 3: function 
 * The index field of the array declarator is optional. When
 * defined, it specifies the dimension of the array. If not
 * defined, the array declarator acts very much like a pointer.
 * The index field is an expression, which may not be as simple as
 * a constant number. Therefore, we must use the Expr structure.
 * The qualifier bit field represents optional ANSI qualifiers for pointers
 * and optional calling convention qualifiers for functions.
 */

/* accessing method */
#define D_ARRY  1       /* array access */
#define D_PTR   2       /* pointer access */
#define D_FUNC  3       /* function call */

/* declarator qualifier bits */
#define DQ_CONST        1       /* constant qualifier (for D_PTR) */
#define DQ_VOLATILE     2       /* volatile qualifier (for D_PTR) */
#define DQ_CDECL        4       /* Visual C call convention (for D_FUNC) */
#define DQ_STDCALL      8       /* Visual C call convention (for D_FUNC) */
#define DQ_FASTCALL     16      /* Visual C call convention (for D_FUNC) */

typedef struct _Dcltr {
	int			method;		/* accessing method */
	struct _Expr		*index;		/* array index */
	struct _Param           *param;         /*BCC-parameters list 1/22/96*/
	struct _Dcltr		*next;		/* next accessing declarator */
        int                     qualifier;      /* declarator qualifiers */
} _Dcltr, *Dcltr;

/*
 * BCC - 1/20/96
 * To hole the formal parameters list to a function prototype, we added this
 * struct which is embedded within _Dcltr
 */

typedef struct _Param {
        struct _Type            *type;
        struct _Param           *next;
} _Param, *Param;

/*===========================================================================*/
/*
 * Initializer.
 * Global variables can be initialized by aggregate initializer.
 * Multiple level of aggregate initialization can occur. The simplest
 * case is when it is just a simple expression.
 * When it is a simple expression, the set field is set to 0.
 * When it is an aggregate initializer, the expr field is set to 0.
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the _Init
 * data structure.
 */
typedef struct _Init {
	struct _Expr	*expr;		/* expression */
	struct _Init	*set;		/* { ... } */
	struct _Init	*next;		/* next token in the set */
	Extension	ext;		/* extension field */
} _Init, *Init;

/*===========================================================================*/
/* 
 * Variable Definition.
 * A variable definition consists of the following fields:
 * 1: variable name,
 * 2: variable type, and
 * 3: initializer (for global variables)
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the _VarDcl
 * data structure.
 */
typedef struct _VarDcl {
	char		*name;		/* variable name */
	struct _Type	*type;		/* variable type */
	struct _Init	*init;		/* data initialization */
	Extension	ext;		/* extension field */
} _VarDcl, *VarDcl;

/*===========================================================================*/
/*
 * Struct/Union Definition.
 * Struct and union declarations are very much alike. 
 * Each has the following attributes:
 * 1: its name, and
 * 2: its fields.
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to these
 * data structures.
 */
typedef struct _StructDcl {
	char		*name;		/* identification */
	struct _Field	*fields;	/* field definition */
	Extension	ext;		/* extension field */
} _StructDcl, *StructDcl;

typedef struct _UnionDcl {
	char		*name;		/* identification */
	struct _Field	*fields;	/* field definition */
	Extension	ext;		/* extension field */
} _UnionDcl, *UnionDcl;
/*
 * Each field of the above structures consists of several subattributes:
 * 1: name of the field,
 * 2: type declaration,
 * 3: bit_field, and
 * 4: a link to the next field.
 * The bit_field attribute specifies the number of bits of this field.
 * This allows the user to pack fields tightly together to reduce data
 * space requirement. The bit_field attribute is a constant expression,
 * which can be expressed by using the Expr data structure. It is not
 * sufficient to use an integer to represent bit_field because of 
 * sizeof() and enum constants in C.
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the
 * data structures.
 */
typedef struct _Field {
	char		*name;		/* name of the field */
	struct _Type	*type;		/* field type */
	struct _Expr	*bit_field;	/* number of bits */
	struct _Field	*next;		/* next field */
	Extension	ext;		/* extension field */
} _Field, *Field;

/*===========================================================================*/
/* 
 * Enumeration Type.
 * Enum structure is a fairly simple data structure which
 * has a name and a list of enum constants. Each enum
 * constant has a name and a value attribute. The value
 * attribute is assigned by the compiler. 
 */
typedef struct _EnumDcl {
	char			*name;		/* identification */
	struct _EnumField	*fields;	/* fields */
} _EnumDcl, *EnumDcl;

typedef struct _EnumField {
	char			*name;		/* name of field */
	struct _Expr		*value;		/* constant value */
	struct _EnumField	*next;		/* next enum field */
} _EnumField, *EnumField;

/*===========================================================================*/
/*
 * Function Definition.
 * A function is a special construct which allows a
 * programmer to generalize a computation model and
 * to tailor a particular computation by passing
 * to a function appropriate parameters.
 * The following fields are defined for a function:
 * 1: name of the function,
 * 2: the return type,
 * 3: the parameter list,
 * 4: local variable definition,
 * 5: the ENTRY point, and
 * 6: the control graph.
 * The (id, weight) tuple is defined by the PROFILER.
 * id==0, for non-profiled functions.
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the
 * data structures.
 */
typedef struct _FuncDcl {
	char		*name;		/* the name of function */
	struct _Type	*type;		/* return type */
	struct _VarList	*param;		/* parameter definition */
	struct _VarList	*local;		/* local variable definition */
	int		entry_bb;	/* the bb_id of the ENTRY block */
	struct _Block	*blocks;	/* basic blocks */
	struct __Pragma	*pragma;	/* pragma specifiers */
	struct _ProfFN	profile;	/* profile information */
	Extension	ext;		/* extension field */
} _FuncDcl, *FuncDcl;

extern FuncDcl	currentFuncDcl;		/* ccode.c */
/*
 * A variable list is a list of variable names. The actual
 * definition of these variables can be obtained by accessing
 * the variable symbol table. To eliminate unncessary accessed,
 * a special pointer is provided to store the location of the
 * corresponding symbol table entry. However, this pointer must
 * be used with extreme care, because it is difficult to keep
 * track when it is valid. When it is not valid, it is set to 0.
 * Thereforem it is recommanded that it is checked against 0 before
 * it is used.
 */
typedef struct _VarList {
	char		*name;		/* name of the variable */
	struct _VarDcl	*var;		/* variable definition */
	struct _VarList	*next;		/* next variable */
} _VarList, *VarList;
/*
 * A basic block is a sequence of expressions which always
 * execute together in the order specified. A basic block is
 * identified by a integer identifier, which is unique in a
 * function. Since a lot of computation is expected on the
 * control graph, a status field is allocated, as required
 * in several algorithm to mark or to assign a weight to a
 * basic block. A basic block can be reached from one or
 * more basic blocks, and it can go to one of several possible
 * basic blocks, including itself. This information can be
 * captured by having two linked lists of control transfer paths.
 * Also, a basic block contains a pointer to its first expression,
 * and also a pointer to its last instruction. The last instruction
 * is a control expression which specifies how the control flow
 * progresses. Finally, a link to the next basic block is needed.
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the
 * data structures.
 * The control transfer type is specified in the cnt_type field.
 * For CNT_RETURN, CNT_IF and CNT_SWITCH, the expression to be 
 * evaluated is added to the basic block as its last expression.
 * The redirection information is stored in the BLinks.
 */
#define CNT_RETURN	1
#define CNT_GOTO	2
#define CNT_IF		3
#define CNT_SWITCH	4
typedef struct _Block {
	int		id;		/* basic block id */
	int		status;		/* current status */
	int		cnt_type;	/* control transfer type */
	struct _BLink	*source;	/* source arcs */
	struct _BLink	*destination;	/* destination arcs */
	struct _Expr	*first;		/* first expression */
	struct _Expr	*last;		/* last expression */
	struct _Block	*next;		/* next basic block */
	struct __Pragma	*pragma;	/* pragma specifiers */
	struct _ProfBB	profile;	/* profile information */
	Extension	ext;		/* extension field */
} _Block, *Block;

extern Block currentBlock;		/* ccode.c */
/*
 * Each link between two basic blocks has the following attributes:
 * 1: status field (for computation only),
 * 2: condition when it is taken,
 * 3: the id of the source basic block of this link,
 * 4: the id of the destination basic block of this link, and
 * 5: the next link.
 * A special extension field is defined, so when computation is
 * necessary, additional information can be attached to the
 * data structures.
 */
typedef struct _BLink {
	int		status;		/* current status */
	struct _Expr	*condition;	/* taken condition */
	int		source;		/* source block */
	int		destination;	/* destination block */
	struct _Block	*src_bb;	/* ptr to src bb */
	struct _Block	*dest_bb;	/* ptr to dest bb */
	struct _BLink	*next;		/* next arc */
	Extension	ext;		/* extension field */
} _BLink, *BLink;

/*===========================================================================*/
/* Expression.
 * A status field is provided for storing temporary information
 * in computations on expressions. The opcode field is an integer
 * because integer comparison is much faster than string comparison.
 * We need another table to map the name of opcode to a unique
 * integer value, including pre-defined operators.
 * The type field specifies the type of the result of the expression.
 * If the expression is a primary type, the value field specifies
 * its value. The sibling field is used to link all operands together.
 * The parent and the child pointers connect all expressions in a
 * basic block together. A parent expression is executed before a
 * child expression.
 * Finally, a special extension field is defined, so when computation is
 * necessary, additional information can be attached to the
 * data structures.
 */
typedef struct _Expr {
	int		status;			/* status */
	int		opcode;			/* opcode */
	struct _Type	*type;			/* result type */
	union {
		long		scalar;		/* signed scalar value */
		unsigned long	uscalar;	/* unsigned scalar value */
		double		real;		/* floating point value */
		char		*string;	/* string/char/enum literal */
		char		*var_name;	/* name of variable */
		struct _Type	*type;		/* type_size/cast */
	} value;
	struct _Expr	*sibling, *operands;	/* operands */
	struct _Expr	*next, *previous;	/* expression links */
	struct __Pragma	*pragma;		/* pragma */
	Extension	ext;			/* extension field */
} _Expr, *Expr;

/*===========================================================================*/
/*
 * Predefined opcodes.
 */
#define OP_var		1
#define OP_enum		2
#define OP_signed	3
#define OP_unsigned	4
#define OP_float	5
#define OP_char		6
#define OP_string	7
#define OP_dot		8
#define OP_arrow	9
#define OP_cast		10
#define OP_expr_size	11
#define OP_type_size	12
#define OP_quest	13
#define OP_disj		14
#define OP_conj		15
#define OP_comma	16
#define OP_assign	17
#define OP_or		18
#define OP_xor		19
#define OP_and		20
#define OP_eq		21
#define OP_ne		22
#define OP_lt		23
#define OP_le		24
#define OP_ge		25
#define OP_gt		26
#define OP_rshft	27
#define OP_lshft	28
#define OP_add		29
#define OP_sub		30
#define OP_mul		31
#define OP_div		32
#define OP_mod		33
#define OP_neg		34
#define OP_not		35
#define OP_inv		36
#define OP_abs		37
#define OP_preinc	38
#define OP_predec	39
#define OP_postinc	40
#define OP_postdec	41
#define OP_Aadd		42
#define OP_Asub		43
#define OP_Amul		44
#define OP_Adiv		45
#define OP_Amod		46
#define OP_Arshft	47
#define OP_Alshft	48
#define OP_Aand		49
#define OP_Aor		50
#define OP_Axor		51
#define OP_indr		52
#define OP_addr		53
#define OP_index	54
#define OP_call		55

#define OP_return	56
#define OP_goto		57
#define OP_if		58
#define OP_switch	59

/* NJW */
#define OP_sync		60
/* WJN */
#define OP_double	61

/* LCW - new opcode to propagate Pprofiler probe numbers to Lcode - 10/24/96 */
#define OP_nulldefine   62


/*===========================================================================*/

/*  DepInfo structure
	currently a 5 field structure holding dependence info coming from
	Pcode */

typedef struct _DepInfo {
    int num;
    char certainty;
    char freq;
    int dist;
    int flags;
    struct _DepInfo *next;
} _DepInfo, *DepInfo;


/*
 * Pragma specification is expected to grow richer.
 * Therefore, the representation must be extensible.
 */
typedef struct __Pragma {
	char *specifier;	/* the specifier is is string */
	DepInfo  dep_info;		/* pragma value */
	struct __Pragma *next;	/* a link to the next specifier */
} __Pragma, *Pragma;


/*
 *	External function prototypes
 */
extern void ReadIncludeFile(char *);

/*===========================================================================*/
#endif
