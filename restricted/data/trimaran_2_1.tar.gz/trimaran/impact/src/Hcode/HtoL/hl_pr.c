/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.10  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Apr. 12, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright 1999 IMPACT Technologies, Inc; Champaign, Illinois
 * For commercial license rights, contact: Marketing Office via
 * electronic mail: marketing@impactinc.com
 *
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	hl_pr.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Creation Date:	June 1990
 *	Modified:  Roger A. Bringmann  2/8/93
 *	    Changed Lcode paranthesization format
 *	Revised: Dave Gallagher, Scott Mahlke - 6/94
 *		Build Lcode structure rather than just printing out text file
 *      Revised by: Ben-Chung Cheng - June 1995
 *              Change M_SIZE_INT, M_SIZE_CHAR to H_INT_SIZE, H_CHAR_SIZE
 *              Those should be determined in runtime, not compile time
\*****************************************************************************/
/*****************************************************************************\
 * BCC - Existing bugs : casting a label/string address to short/char - 6/27/95 
\*****************************************************************************/
#include "hl_main.h"

#undef DEBUG

/* extern declarations */
extern char *M_get_base_macro ();
extern char *M_fn_label_name(char *, int (*is_func)(char *is_func_label));


/* forward declarations */
static void HC_gen_expand(L_Cb *cb, char *fn, _HC_Operand arg[], 
			  _M_Type ret_type,_M_Type mtype[], 
			  int argc, L_Attr *attr1);
static int is_char(int type);
static int is_short(int type);
static int is_integer(int type);
static int is_long(int type);
static int is_pointer(int type);
static int is_float(int type);
static int is_double(int type);
static char *typename(int type);
static char *typename2(int type, int unsign);
static L_Operand *gen_operand(HC_Operand op);

/* BCC - added - 6/15/95 */
static int is_int(int type);
void bcc_cast_char(L_Cb *, HC_Operand , HC_Operand , int );
void bcc_cast_short(L_Cb *, HC_Operand , HC_Operand , int );
void bcc_cast_int(L_Cb *, HC_Operand , HC_Operand , int );
void bcc_cast_float(L_Cb *, HC_Operand , HC_Operand , int );
void bcc_cast_double(L_Cb *, HC_Operand , HC_Operand , int );

void HC_new_char(HC_Operand op, long value, int unsign);
void HC_new_short(HC_Operand op, long value, int unsign);
void HC_new_int(HC_Operand op, long value, int unsign);
void HC_new_long(HC_Operand op, long value, int unsign);
void HC_new_pointer(HC_Operand op, long value);

void cast_gen_f_i(L_Cb *, HC_Operand, HC_Operand);
void cast_gen_f2_i(L_Cb *, HC_Operand, HC_Operand);
void cast_gen_lsl(L_Cb *, HC_Operand, HC_Operand, HC_Operand);
void cast_gen_asr(L_Cb *, HC_Operand, HC_Operand, HC_Operand);
void cast_gen_and(L_Cb *, HC_Operand, HC_Operand, HC_Operand);
void cast_gen_f2_f(L_Cb *, HC_Operand, HC_Operand);
void cast_gen_i_f(L_Cb *, HC_Operand, HC_Operand);
void cast_gen_f_f2(L_Cb *, HC_Operand, HC_Operand);
void cast_gen_i_f2(L_Cb *, HC_Operand, HC_Operand);
void cast_gen_sign_extend_byte(L_Cb *, HC_Operand, HC_Operand);
void cast_gen_sign_extend_half_word(L_Cb *, HC_Operand, HC_Operand);

void
HC_gen_subroutine_call_for_operation(L_Cb *, HC_Operand, HC_Operand, HC_Operand, int opc);


/*----------------------------------------------------------------------*/


/*
 *	For all HC_gen_XXX functions,
 *	we require each operand field to be unique.
 *	So we can modify them when necessary.
 *	This is incoherent to gen_func.c ... etc, need to fix
 *	in the future.
 */
/*----------------------------------------------------------------------*/
/*
 *	preserve type as much as possible,
 *	but make non-scalar types scalar (at least
 *	when they are used in a register -- address --)
 */
int HC_register_type(int type)
{
    switch (type) {
    case M_TYPE_VOID:	
	Punt("HC_register_type: VOID is not allowed in register");
	return type;
	break;
    case M_TYPE_CHAR:
    case M_TYPE_SHORT:
    case M_TYPE_INT:
    case M_TYPE_LONG:
    case M_TYPE_FLOAT:
    case M_TYPE_DOUBLE:
	return type;
    case M_TYPE_BIT_LONG:
/* REH 9/15/93 */
    case M_TYPE_BIT_SHORT:
/* HER */
    case M_TYPE_BIT_CHAR:
	return M_TYPE_INT;
    case M_TYPE_POINTER:
    case M_TYPE_BLOCK:
    case M_TYPE_UNION:
    case M_TYPE_STRUCT:
	return M_TYPE_POINTER;		/* address */
    default:
	Punt("HC_register_type: illegal type");
	return 0;
    }
}
/*----------------------------------------------------------------------*/
/*
 *	This function does not provide enough capability
 *	to handle all function calls. We use this only
 *	to generate calls to internal functions.
 *	Do not allow structure arguments.
 *      Added return_mtype -ITI/JCG 4/99
 */
static void HC_gen_expand(L_Cb *cb, char *fn, _HC_Operand arg[], 
			  _M_Type ret_mtype, _M_Type mtype[], 
			  int argc, L_Attr *attr1)
{
    int i;
    _HC_Operand fn_addr, dest, src1, src2, src3;
    _M_Type mtype2[HC_MAX_PARAM_VAR];
    long offset[HC_MAX_PARAM_VAR];
    int mode[HC_MAX_PARAM_VAR];
    int reg[HC_MAX_PARAM_VAR];
    int paddr[HC_MAX_PARAM_VAR];
/******    variables added for X86 patch  *******/
    _M_Type local_mtype[HC_MAX_PARAM_VAR];
    _M_Type rev_type2[HC_MAX_PARAM_VAR];
    long rev_offset[HC_MAX_PARAM_VAR];
    int rev_mode[HC_MAX_PARAM_VAR];
    int rev_reg[HC_MAX_PARAM_VAR];
    int rev_paddr[HC_MAX_PARAM_VAR];
    int num;
/***********************************************/

    int param_size;
    int tmcount = 0;
    char *base_macro;
    L_Attr *attr= NULL, *new_attr = NULL;
    Expr expr = NULL;
#ifdef GEN_J1
    attr == L_new_attr("j2", 1);
    L_set_int_attr_field(new_attr, 0, HC_next_call_site_id());
#endif
    /* LCW - move this out of #ifdef above - 8/7/97 */
    attr = L_concat_attr(attr1, attr);
    for (i=0; i<argc; i++) {
      if (L_propagate_sign_size_ctype_info)
	M_call_type2(mtype+i, mtype2+i);
      else
	M_call_type(mtype+i, mtype2+i);
    }
    /*
     *	For passing arguments to callee functions.
     *	However, here, we do not allow passing structure
     *	arguments. 
     */
    param_size = M_fnvar_layout(argc, mtype2, offset, mode, reg, paddr,
		 &base_macro, 0, M_PUT_FNVAR);
    for (i=0; i<argc; i++) {
	offset[i] /= H_CHAR_SIZE;
	paddr[i] /= H_CHAR_SIZE;
    }
/*******************************************************
          Patch for X86 - reverses the order of all function
          parameters, so they will be generated right-to-left,
          per X86 standard.
**********************************************************/
    if (M_arch == M_X86)  {
	num = argc;
        for(i=0; i<num; i++)  {
            rev_type2[i] = mtype2[i];
            rev_mode[i] = mode[i];
            rev_reg[i] = reg [i];
            rev_offset[i] = offset[i];
            rev_paddr[i] = paddr[i];

        }

        for(i=0; i<num; i++)  {
            local_mtype[num-1-i] = mtype[i];
            mtype2[num-1-i] = rev_type2[i];
            mode[num-1-i] = rev_mode[i];
            reg[num-1-i] = rev_reg [i];
            offset[num-1-i] = rev_offset[i];
            paddr[num-1-i] = rev_paddr[i];
        }
    }
    else {
        for(i=0; i<argc; i++)  {
            local_mtype[i] = mtype[i];
	}
    }
/*******************************************************/


    for (i=0; i<argc; i++) {
	if (mode[i]==M_THRU_REGISTER) {
	    char line[64];
	    sprintf(line, "$P%d", reg[i]);
	    if (L_propagate_sign_size_ctype_info)
	      HC_new_macro(&dest, line, mtype2[i].type, mtype2[i].unsign);
	    else
	      HC_new_macro(&dest, line, mtype2[i].type, 0);
	    /* LCW - use the copy of attr (instead of itself)
	       to avoid sharing - 8/7/97 */
	    if (M_arch == M_X86)  {
	        HC_gen_mov(cb,&dest, arg+(argc-1-i), L_copy_attr(attr));
	    }
	    else {
	        HC_gen_mov(cb,&dest, arg+i, L_copy_attr(attr));
	    }
	} else 
	if (mode[i]==M_THRU_MEMORY) {
	    if ((local_mtype[i].type==M_TYPE_UNION) ||
		(local_mtype[i].type==M_TYPE_STRUCT)) {
		Punt("HC_gen_expand: do not allow structure parameters");
	    }
	    if (local_mtype[i].type != mtype2[i].type) {
	        if (L_propagate_sign_size_ctype_info)
		  HC_new_register(&src3, HC_next_reg_id(), mtype2[i].type, mtype2[i].unsign);
		else
		  HC_new_register(&src3, HC_next_reg_id(), mtype2[i].type, 0);
		/* LCW - change the last argument from 0 to attr - 8/7/97 */
	        if (M_arch == M_X86)  {
	            HC_gen_mov(cb,&src3, arg+(argc-1-i), L_copy_attr(attr));
	        }
	        else {
		    HC_gen_mov(cb,&src3, arg+i, L_copy_attr(attr));
	        }
	    } else {
	        if (M_arch == M_X86)  {
		    src3 = arg[argc-1-i];
		}
	        else {
		    src3 = arg[i];
		}
	    }
	    HC_new_macro(&src1, base_macro, M_TYPE_POINTER, 0);
	    HC_new_int(&src2, offset[i], 0);
	    new_attr = L_new_attr("tm",1);
	    L_set_int_attr_field(new_attr,0,L_TM_START_VALUE+tmcount++);
	    /* LCW - append attr to new_attr - 8/7/97 */
	    new_attr = L_concat_attr(new_attr, L_copy_attr(attr));
	    HC_gen_store(cb,expr,&src1, &src2, &src3, src3.data_type, new_attr);
	} else {
	    fprintf(stderr, "# indirect memory fnvar mode is used\n");
	    Punt("HC_gen_expand: do not allow structure parameters");
	}
    }
    HC_new_label(&fn_addr, fn);

    /* REH 3/7/93 add attributes to jsr to identify parameters used */
    /* ITI/JCG 4/99 Enhanced attributes to match normal jsr attributes */
    {
    L_Attr *func_attr = NULL;
    L_Attr *tr_attr = NULL;
    L_Attr *tm_attr = NULL;
    L_Attr *tmo_attr = NULL;
    L_Attr *tmso_attr = NULL;
    int trcount = 0;
    tmcount = 0;
    new_attr = NULL;
    for ( i = 0; i < argc ; i++ )  
    {
        char *data_type;
        if ((mode[i]==M_THRU_REGISTER) ||
            (mode[i]==M_INDIRECT_THRU_REGISTER))
        {
	    if ( trcount == 0 )
	    {
		tr_attr = L_new_attr("tr",0);
	    }
	    if (L_propagate_sign_size_ctype_info)
	    {
	      L_set_macro_attr_field(tr_attr, trcount++, L_MAC_P0 + reg[i],
				   L_ctype_id(HC_typename2(mtype2[i].type, mtype2[i].unsign)),
				   L_PTYPE_NULL);
	    }
	    else
	    {
	      L_set_macro_attr_field(tr_attr, trcount++, L_MAC_P0 + reg[i],
				   L_ctype_id(HC_typename(mtype2[i].type)),
				   L_PTYPE_NULL);
	    }
	    /* Also, add structure offsets for indirect thru
             * register -ITI/JCG 4/99
             */
            if (mode[i]==M_INDIRECT_THRU_REGISTER)
            {
                if (tmso_attr == NULL)
                {
                    tmso_attr = L_new_attr("tmso",0);
                }
                L_set_int_attr_field(tmso_attr, i, paddr[i]);
            }
        }
	else  
	{
	    if ( tmcount == 0 )
	    {
		tm_attr = L_new_attr("tm",0);
		tmo_attr = L_new_attr("tmo",0);
	    }
	    L_set_int_attr_field(tm_attr,tmcount,L_TM_START_VALUE+tmcount);

	    
	    /* To make Lemulate robust, explicitly specify memory offsets
             * for thru-memory parameters on JSRs.  -ITI/JCG 4/99
             */
            L_set_int_attr_field(tmo_attr,tmcount,offset[i]);

            /* Also, add structure offsets for indirect thru
             * memory -ITI/JCG 4/99
             */
            if (mode[i]==M_INDIRECT_THRU_MEMORY)
            {
                if (tmso_attr == NULL)
                {
                    tmso_attr = L_new_attr("tmso",0);
                }
                L_set_int_attr_field(tmso_attr, i, paddr[i]);
            }
            tmcount++;
	}
    }
    if ( tr_attr != NULL )
	func_attr = L_concat_attr(func_attr,tr_attr);
    if ( tm_attr != NULL )
	func_attr = L_concat_attr(func_attr,tm_attr);
    if ( tmo_attr != NULL )
        func_attr = L_concat_attr(func_attr,tmo_attr);
    if ( tmso_attr != NULL )
        func_attr = L_concat_attr(func_attr,tmso_attr);

    /*
     *	ignore the return value. (NO LONGER! -ITI/JCG 4/99)
     *  Although, for now, will punt if return a structure (not
     *  expected to happen). -ITI/JCG 4/99
     */
    /* If the function returns a structure, punt for now! */
    if ((ret_mtype.type==M_TYPE_UNION) ||
	(ret_mtype.type==M_TYPE_STRUCT))
    {
	L_punt ("HC_gen_expand: returning structure expected and "
		"unimplemented!");
    }

    /* Provide the return register macro name */
    new_attr = L_new_attr("ret",1);
    if (L_propagate_sign_size_ctype_info)
    {
	L_set_macro_attr_field(new_attr,0,
		 L_MAC_P0 + M_return_register(ret_mtype.type,M_GET_FNVAR),
		 L_ctype_id(HC_typename2(ret_mtype.type, ret_mtype.unsign)),
		 L_PTYPE_NULL);
    }
    else
    {
	L_set_macro_attr_field(new_attr,0,
	         L_MAC_P0 + M_return_register(ret_mtype.type,M_GET_FNVAR),
                 L_ctype_id(HC_typename(ret_mtype.type)),
                 L_PTYPE_NULL);
    }

    func_attr = L_concat_attr (func_attr, new_attr);


    new_attr = L_new_attr("param_size", 1);
    L_set_int_attr_field(new_attr, 0, param_size/H_CHAR_SIZE);
    func_attr = L_concat_attr (func_attr, new_attr);
    /* LCW - append attr at the end of func_attr - 8/7/97 */
    func_attr = L_concat_attr (func_attr, L_copy_attr(attr));
    HC_gen_jsr(cb, 0, &(fn_addr), argc, func_attr);
    }

    /* LCW - We can free attr because we only use its copies. - 8/7/97 */
    if (attr != NULL)
       L_delete_all_attr(attr);
    
}

/*----------------------------------------------------------------------*/
void HC_dup(HC_Operand op1, HC_Operand op2)
{
    *op1 = *op2;
}

void HC_new_cb(HC_Operand op, int cb_id)
{
    op->type = HC_CB;
    op->data_type = M_TYPE_INT;		/* branch offset */
    op->unsign = 0;
    op->value.cb = cb_id;
}

void HC_new_register(HC_Operand op, int reg_id, int type, int unsign)
{
    type = HC_register_type(type);
    op->type = HC_R;
    op->data_type = type;
    op->unsign = unsign;
    op->value.r = reg_id;
    if ((type<M_TYPE_BIT_LONG) | (type>M_TYPE_POINTER)) {
	fprintf(stderr, "# type = %d\n", type);
	Punt("HC_new_register: illegal type");
    }
}

void HC_new_label(HC_Operand op, char *label)
{
    op->type = HC_L;
    op->data_type = M_TYPE_POINTER;
    op->unsign = 0;
    op->value.l = C_findstr(label);
}

void HC_new_macro(HC_Operand op, char *name, int type, int unsign)
{
    op->type = HC_MAC;
    op->data_type = type;
    op->unsign = unsign;
    op->value.mac = C_findstr(name);
    if ((type<M_TYPE_BIT_LONG) | (type>M_TYPE_POINTER))
	Punt("HC_new_macro: illegal type");
}

/* BCC - 6/15/95 */
void HC_new_short(HC_Operand op, long value, int unsign)
{
    op->type = HC_I;
    op->data_type = M_TYPE_SHORT;
    op->unsign = unsign;
    op->value.i = value;
}

/* BCC - 6/15/95 */
void HC_new_char(HC_Operand op, long value, int unsign)
{
    op->type = HC_I;
    op->data_type = M_TYPE_CHAR;
    op->unsign = unsign;
    op->value.i = value;
}

void HC_new_long(HC_Operand op, long value, int unsign)
{
    op->type = HC_I;
    op->data_type = M_TYPE_LONG;
    op->unsign = unsign;
    op->value.i = value;
}

void HC_new_pointer(HC_Operand op, long value)
{
    op->type = HC_I;
    op->data_type = M_TYPE_POINTER;
    op->unsign = 0; 
    op->value.i = value;
}

void HC_new_int(HC_Operand op, long value, int unsign)
{
    op->type = HC_I;
    op->data_type = M_TYPE_INT;
    op->unsign = unsign;
    op->value.i = value;
}

void HC_new_float(HC_Operand op, double value)
{
    op->type = HC_F;
    op->data_type = M_TYPE_FLOAT;
    op->unsign = 0;
    op->value.f = value;
}

void HC_new_double(HC_Operand op, double value)
{
    op->type = HC_F2;
    op->data_type = M_TYPE_DOUBLE;
    op->unsign = 0;
    op->value.f2 = value;
}

void HC_new_string(HC_Operand op, char *str)
{
    op->type = HC_S;
    op->data_type = M_TYPE_POINTER;
    op ->unsign = 0;
    op->value.s = C_findstr(str);
}

/*----------------------------------------------------------------------*/

static int is_char(int type)	/* used only for memory operations */
{
    return (type==M_TYPE_CHAR);
}

static int is_short(int type)	/* used only for memory operations */
{
    return (type==M_TYPE_SHORT);
}

/* BCC - added - 6/15/95 */
static int is_int(int type)	/* used only for memory operations */
{
    return (type==M_TYPE_INT);
}

static int is_long(int type)
{
    return (type==M_TYPE_LONG);
}

static int is_pointer(int type)
{
    return (type==M_TYPE_POINTER);
}

static int is_integer(int type)
{
    switch (type) {
    case M_TYPE_BIT_LONG:
/* REH 9/15/93 */
    case M_TYPE_BIT_SHORT:
/* HER */
    case M_TYPE_BIT_CHAR:
    case M_TYPE_CHAR:
    case M_TYPE_SHORT:
    case M_TYPE_INT:
    case M_TYPE_LONG:
    case M_TYPE_POINTER:
    case M_TYPE_BLOCK:		/* starting address of a block */
	return 1;
    default:
	return 0;
    }
}

static int is_float(int type)
{
    return (type==M_TYPE_FLOAT);
}

static int is_double(int type)
{
    return (type==M_TYPE_DOUBLE);
}

static char *typename(int type)
{
    switch (type) {
    case M_TYPE_FLOAT:		return "f";
    case M_TYPE_DOUBLE:		return "f2";
    default:			return "i";
    }
}

static char *typename2(int type, int unsign)
{
    switch (type) {
    case M_TYPE_FLOAT :		
      return "f";
    case M_TYPE_DOUBLE :		
      return "f2";
    case M_TYPE_CHAR :           
      if (unsign)
	return "uc";
      else
	return "c";
    case M_TYPE_SHORT :
      if (unsign)
	return "sh";
      else 
	return "ush";
    case M_TYPE_INT :
      if (unsign)
	return "ui";
      else
	return "i";
    case M_TYPE_LONG :
      if (unsign)
	return "ulng";
      else
	return "lng";
    case M_TYPE_POINTER :
      return "pnt";
    default:			return "i";
    }
}


char *HC_typename(int type)
{
    return typename(type);
}

char *HC_typename2(int type, int unsign)
{
    return typename2(type, unsign);
}


static L_Operand *gen_operand(HC_Operand op)
{
    L_Operand *new_operand;
    L_Cb *cb;
    char *new_label, name[256];
    int ctype, mac_num;

    if (op==0) Punt("gen_operand: no argument");
    switch (op->type) {
    case HC_CB:
	cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, op->value.cb);
	new_operand = L_new_cb_operand(cb);
	break;
    case HC_L:
	new_label = (char*)M_fn_label_name(op->value.l,HC_is_function);
	sprintf (name, "_%s",new_label);
	new_operand = L_new_gen_label_operand(name);
	break;
    case HC_I:
        if (L_propagate_sign_size_ctype_info) {
	  switch (op->data_type) {
	  case M_TYPE_CHAR :
	    if (op->unsign)
	      new_operand = L_new_int_operand(op->value.i, L_CTYPE_UCHAR);
	    else
	      new_operand = L_new_int_operand(op->value.i, L_CTYPE_CHAR);
	    break;
	  case M_TYPE_SHORT :
	    if (op->unsign)
	      new_operand = L_new_int_operand(op->value.i, L_CTYPE_USHORT);
	    else
	      new_operand = L_new_int_operand(op->value.i, L_CTYPE_SHORT);
	    break;
	  case M_TYPE_INT :
	    if (op->unsign)
	      new_operand = L_new_int_operand(op->value.i, L_CTYPE_UINT);
	    else
	      new_operand = L_new_int_operand(op->value.i, L_CTYPE_INT);
	    break;
	  case M_TYPE_LONG :
	    if (op->unsign)
	      new_operand = L_new_int_operand(op->value.i, L_CTYPE_ULONG);
	    else
	      new_operand = L_new_int_operand(op->value.i, L_CTYPE_LONG);
	    break;
	  case M_TYPE_POINTER :
	    new_operand = L_new_int_operand(op->value.i, L_CTYPE_POINTER);
	    break;
	  default :
	    L_warn("gen_operand : unknown Mtype %d", op->data_type);
	    break;
	  }
	}
	else 
	  new_operand = L_new_gen_int_operand(op->value.i);
	break;
    case HC_S:
	new_operand = L_new_gen_string_operand(op->value.s);
	break;
    case HC_F:
	/* BCC - use float type argument - 8/22/96 */
	new_operand = L_new_float_operand((float)op->value.f);
	break;
    case HC_F2:
	new_operand = L_new_double_operand(op->value.f2);
	break;
    case HC_R:
        if (L_propagate_sign_size_ctype_info) {
	  switch(op->data_type) {
	  case M_TYPE_FLOAT :
	    ctype = L_CTYPE_FLOAT;
	    break;
	  case M_TYPE_DOUBLE :
	    ctype = L_CTYPE_DOUBLE;
	    break;
	  case M_TYPE_CHAR :
	    if (op->unsign)
	      ctype  = L_CTYPE_UCHAR;
	    else
	      ctype = L_CTYPE_CHAR;
	    break;
	  case M_TYPE_SHORT :
	    if (op->unsign)
	      ctype  = L_CTYPE_USHORT;
	    else
	      ctype = L_CTYPE_SHORT;
	    break;
	  case M_TYPE_INT :
	    if (op->unsign)
	      ctype  = L_CTYPE_UINT;
	    else
	      ctype = L_CTYPE_INT;
	    break;
	  case M_TYPE_LONG :
	    if (op->unsign)
	      ctype  = L_CTYPE_ULONG;
	    else
	      ctype = L_CTYPE_LONG;
	    break;
	  case M_TYPE_POINTER :
	    ctype  = L_CTYPE_POINTER;
	    break;
	  default :
	    L_warn("gen_operand : unknown Mtype %d", op->data_type);
	    break;
	  }
	}
	else {
	  if (op->data_type == M_TYPE_FLOAT)
	    ctype = L_CTYPE_FLOAT;
	  else if (op->data_type == M_TYPE_DOUBLE)
	    ctype = L_CTYPE_DOUBLE;
	  else
	    ctype = L_CTYPE_INT;
	}
	new_operand = L_new_register_operand(op->value.r,ctype,L_PTYPE_NULL);
	break;
    case HC_MAC:
        if (L_propagate_sign_size_ctype_info) {
	  switch(op->data_type) {
	  case M_TYPE_FLOAT :
	    ctype = L_CTYPE_FLOAT;
	    break;
	  case M_TYPE_DOUBLE :
	    ctype = L_CTYPE_DOUBLE;
	    break;
	  case M_TYPE_CHAR :
	    if (op->unsign)
	      ctype  = L_CTYPE_UCHAR;
	    else
	      ctype = L_CTYPE_CHAR;
	    break;
	  case M_TYPE_SHORT :
	    if (op->unsign)
	      ctype  = L_CTYPE_USHORT;
	    else
	      ctype = L_CTYPE_SHORT;
	    break;
	  case M_TYPE_INT :
	    if (op->unsign)
	      ctype  = L_CTYPE_UINT;
	    else
	      ctype = L_CTYPE_INT;
	    break;
	  case M_TYPE_LONG :
	    if (op->unsign)
	      ctype  = L_CTYPE_ULONG;
	    else
	      ctype = L_CTYPE_LONG;
	    break;
	  case M_TYPE_POINTER :
	    ctype  = L_CTYPE_POINTER;
	    break;
	  default :
	    L_warn("gen_operand : unknown Mtype %d", op->data_type);
	    break;
	  }
	}
	else {
	  if (op->data_type == M_TYPE_FLOAT)
	    ctype = L_CTYPE_FLOAT;
	  else if (op->data_type == M_TYPE_DOUBLE)
	    ctype = L_CTYPE_DOUBLE;
	  else
	    ctype = L_CTYPE_INT;
	}
        mac_num = L_macro_id(op->value.mac);
	new_operand = L_new_macro_operand(mac_num,ctype,L_PTYPE_NULL);
	break;
    default:
	Punt("gen_operand: illegal type");
    }
    return (new_operand);
}

L_Operand *HC_operand(HC_Operand op)
{
    L_Operand *new_operand;
    L_Cb *cb;
    char new_label[256];
    int ctype, mac_num;

    if (op==0) Punt("HC_operand: no argument");
    switch (op->type) {
    case HC_CB:
	cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, op->value.cb);
	new_operand = L_new_cb_operand(cb);
	break;
    case HC_L:
	/* REH 1/16/96 - Make sure we check the label for a function name */ 
	sprintf (new_label,"_%s",(char *)M_fn_label_name (op->value.l,
					HC_is_function));
	new_operand = L_new_gen_label_operand(new_label);
	break;
    case HC_I:
      if (L_propagate_sign_size_ctype_info) {
        switch(op->data_type) {
	case M_TYPE_CHAR :
	  if (op->unsign)
	    new_operand = L_new_int_operand(op->value.i, L_CTYPE_UCHAR);
	  else
	    new_operand = L_new_int_operand(op->value.i, L_CTYPE_CHAR);
	  break;
	case M_TYPE_SHORT :
	  if (op->unsign)
	    new_operand = L_new_int_operand(op->value.i, L_CTYPE_USHORT);
	  else
	    new_operand = L_new_int_operand(op->value.i, L_CTYPE_SHORT);
	  break;
	case M_TYPE_INT :
	  if (op->unsign)
	    new_operand = L_new_int_operand(op->value.i, L_CTYPE_UINT);
	  else
	    new_operand = L_new_int_operand(op->value.i, L_CTYPE_INT);
	  break;
	case M_TYPE_LONG :
	  if (op->unsign)
	    new_operand = L_new_int_operand(op->value.i, L_CTYPE_ULONG);
	  else
	    new_operand = L_new_int_operand(op->value.i, L_CTYPE_LONG);
	  break;
	case M_TYPE_POINTER :
	  new_operand = L_new_int_operand(op->value.i, L_CTYPE_POINTER);
	  break;
	default : 
	  L_warn("HC_Operand : unknown M_type %d", op->data_type);
	  break;
	}
      }
      else
	new_operand = L_new_gen_int_operand(op->value.i);
      break;
    case HC_S:
        new_operand = L_new_gen_string_operand(op->value.s);
	break;
    case HC_F:
	/* BCC - use float type argument - 8/22/96 */
        new_operand = L_new_float_operand((float)op->value.f);
	break;
    case HC_F2:
        new_operand = L_new_double_operand(op->value.f2);
	break;
    case HC_R:
      if (L_propagate_sign_size_ctype_info) {
	switch(op->data_type) {
	case M_TYPE_FLOAT : 
	  ctype = L_CTYPE_FLOAT;
	  break;
	case M_TYPE_DOUBLE : 
	  ctype = L_CTYPE_DOUBLE;
	  break;
	case M_TYPE_CHAR : 
	  if (op->unsign)
	    ctype = L_CTYPE_UCHAR;
	  else
	    ctype = L_CTYPE_CHAR;
	  break;
	case M_TYPE_SHORT : 
	  if (op->unsign)
	    ctype = L_CTYPE_USHORT;
	  else
	    ctype = L_CTYPE_SHORT;
	  break;
	case M_TYPE_INT : 
	  if (op->unsign)
	    ctype = L_CTYPE_UINT;
	  else
	    ctype = L_CTYPE_INT;
	  break;
	case M_TYPE_LONG : 
	  if (op->unsign)
	    ctype = L_CTYPE_ULONG;
	  else
	    ctype = L_CTYPE_LONG;
	  break;
	case M_TYPE_POINTER : 
	    ctype = L_CTYPE_POINTER;
	  break;
	default :
	  L_warn("HC_Operand : unknown M type %d", op->data_type);
	  break;
	}
      }
      else {
        if (op->data_type == M_TYPE_FLOAT)
            ctype = L_CTYPE_FLOAT;
        else if (op->data_type == M_TYPE_DOUBLE)
            ctype = L_CTYPE_DOUBLE;
        else
 	    ctype = L_CTYPE_INT; 
      }
      new_operand = L_new_register_operand(op->value.r,ctype,L_PTYPE_NULL);
      break;
    case HC_MAC:
      if (L_propagate_sign_size_ctype_info) {
	switch(op->data_type) {
	case M_TYPE_FLOAT : 
	  ctype = L_CTYPE_FLOAT;
	  break;
	case M_TYPE_DOUBLE : 
	  ctype = L_CTYPE_DOUBLE;
	  break;
	case M_TYPE_CHAR : 
	  if (op->unsign)
	    ctype = L_CTYPE_UCHAR;
	  else
	    ctype = L_CTYPE_CHAR;
	  break;
	case M_TYPE_SHORT : 
	  if (op->unsign)
	    ctype = L_CTYPE_USHORT;
	  else
	    ctype = L_CTYPE_SHORT;
	  break;
	case M_TYPE_INT : 
	  if (op->unsign)
	    ctype = L_CTYPE_UINT;
	  else
	    ctype = L_CTYPE_INT;
	  break;
	case M_TYPE_LONG : 
	  if (op->unsign)
	    ctype = L_CTYPE_ULONG;
	  else
	    ctype = L_CTYPE_LONG;
	  break;
	case M_TYPE_POINTER : 
	    ctype = L_CTYPE_POINTER;
	  break;
	default :
	  L_warn("HC_Operand : unknown M type %d", op->data_type);
	  break;
	}
      }
      else {
        if (op->data_type == M_TYPE_FLOAT)
            ctype = L_CTYPE_FLOAT;
        else if (op->data_type == M_TYPE_DOUBLE)
            ctype = L_CTYPE_DOUBLE;
        else
            ctype = L_CTYPE_INT;
      }
      mac_num = L_macro_id(op->value.mac);
      new_operand = L_new_macro_operand(mac_num,ctype,L_PTYPE_NULL);
      break;
    default:
	Punt("HC_operand: illegal type");
    }
    return (new_operand);
}

/* BCC - bcc_cast_char added - 6/15/95 */
/*----------------------------------------------------------------------*/
void bcc_cast_char(L_Cb *cb, HC_Operand dest, HC_Operand src, int unsign)
{
    L_Oper *new_oper = NULL;
    int mac_num;
    long value;
    _HC_Operand src1;

    if (dest->data_type != M_TYPE_CHAR) 
	Punt("cast_char: Incorrect dest data type");
    src1 = *src;
    switch (src1.type) {
    case HC_CB:
    case HC_L:
    case HC_S:
/* BCC - Remove the restriction, but this is a bug, because upper 24 bits are 
	 not chopped - 6/27/95 
	Punt("Illegal cast to char"); */
	*dest = src1;
	break;
    case HC_I:
	value = src1.value.i;
	value <<= H_INT_SIZE - H_CHAR_SIZE;
	value >>= H_INT_SIZE - H_CHAR_SIZE;
	if ( unsign ) value &= H_UNSIGNED_CHAR_MASK;
	HC_new_char(dest, value, 0);
	break;
    case HC_F:
	value = (long) src1.value.f;
	value <<= H_INT_SIZE - H_CHAR_SIZE;
	value >>= H_INT_SIZE - H_CHAR_SIZE;
	if ( unsign ) value &= H_UNSIGNED_CHAR_MASK;
	HC_new_char(dest, value, 0);
	break;
    case HC_F2:
	value = (long) src1.value.f2;
	value <<= H_INT_SIZE - H_CHAR_SIZE;
	value >>= H_INT_SIZE - H_CHAR_SIZE;
	if ( unsign ) value &= H_UNSIGNED_CHAR_MASK;
	HC_new_char(dest, value, 0);
	break;
    case HC_R: 
	{
	    _HC_Operand temp, offset, before_and, mask;

	    if (is_float(src1.data_type)) {
		HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT, 0);
		cast_gen_f_i(cb, &temp, &src1);	
		src1 = temp;	/* cast to char later */
	    }
    	    else if (is_double(src1.data_type)) {
		HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT, 0);
		cast_gen_f2_i(cb, &temp, &src1);	
		src1 = temp;	/* cast to char later */
	    };
	    if ( unsign ) {
/* BCC - old inefficient code - 8/15/95
		HC_new_int(&offset, H_INT_SIZE - H_CHAR_SIZE);
		HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT);
		cast_gen_lsl(cb, &temp, &src1, &offset);
		HC_new_register(&before_and, HC_next_reg_id(), M_TYPE_INT);
		cast_gen_asr(cb, &before_and, &temp, &offset);
		HC_new_int(&mask, H_UNSIGNED_CHAR_MASK);
		cast_gen_and(cb, dest, &before_and, &mask);
*/

/* BCC - if the dest operand type is unsigned char, don't shift - 8/15/95 */
		HC_new_int(&mask, H_UNSIGNED_CHAR_MASK, 0);
		cast_gen_and(cb, dest, &src1, &mask);
	    }
	    else {	/* signed */
	       if (HL_generate_sign_extend_operations) {
		 cast_gen_sign_extend_byte(cb,dest,&src1);
	       }
	       else {
	 	 HC_new_int(&offset, H_INT_SIZE - H_CHAR_SIZE, 0);
		 HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT, 0);
		 cast_gen_lsl(cb, &temp, &src1, &offset);
		 cast_gen_asr(cb, dest, &temp, &offset);
	       }
	    }
    	}
	break;
    case HC_MAC:
	Punt("Can't cast a MAC register to char");
	break;
    default:
	Punt("cast_char: Incorrect src data type");
	break;
    }
}

/* BCC - bcc_cast_short added - 6/15/95 */
/*----------------------------------------------------------------------*/
void bcc_cast_short(L_Cb *cb, HC_Operand dest, HC_Operand src, int unsign)
{
    L_Oper *new_oper = NULL;
    int mac_num;
    long value;
    _HC_Operand src1;

    if (dest->data_type != M_TYPE_SHORT) 
	Punt("cast_short: Incorrect dest data type");
    src1 = *src;
    switch (src1.type) {
    case HC_CB:
    case HC_L:
    case HC_S:
/* BCC - Remove the restriction, but this is a bug, because upper 16 bits are 
	 not chopped - 6/27/95 
	Punt("Illegal cast to short"); */
	*dest = src1;
	break;
    case HC_I:
	value = src1.value.i;
	value <<= H_INT_SIZE - H_SHORT_SIZE;
	value >>= H_INT_SIZE - H_SHORT_SIZE;
	if ( unsign ) value &= H_UNSIGNED_SHORT_MASK;
	HC_new_short(dest, value, 0);
	break;
    case HC_F:
	value = (long) src1.value.f;
	value <<= H_INT_SIZE - H_SHORT_SIZE;
	value >>= H_INT_SIZE - H_SHORT_SIZE;
	if ( unsign ) value &= H_UNSIGNED_SHORT_MASK;
	HC_new_short(dest, value, 0);
	break;
    case HC_F2:
	value = (long) src1.value.f2;
	value <<= H_INT_SIZE - H_SHORT_SIZE;
	value >>= H_INT_SIZE - H_SHORT_SIZE;
	if ( unsign ) value &= H_UNSIGNED_SHORT_MASK;
	HC_new_short(dest, value, 0);
	break;
    case HC_R: 
	{
	    _HC_Operand temp, offset, before_and, mask;

	    if (is_float(src1.data_type)) {
		HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT, 0);
		cast_gen_f_i(cb, &temp, &src1);	
		src1 = temp;	/* cast to short later */
	    }
    	    else if (is_double(src1.data_type)) {
		HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT, 0);
		cast_gen_f2_i(cb, &temp, &src1);	
		src1 = temp;	/* cast to short later */
	    };
	    if ( unsign ) {
/* BCC - old inefficient code - 8/15/95
		HC_new_int(&offset, H_INT_SIZE - H_SHORT_SIZE);
		HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT);
		cast_gen_lsl(cb, &temp, &src1, &offset);
		HC_new_register(&before_and, HC_next_reg_id(), M_TYPE_INT);
		cast_gen_asr(cb, &before_and, &temp, &offset);
		HC_new_int(&mask, H_UNSIGNED_SHORT_MASK);
		cast_gen_and(cb, dest, &before_and, &mask);
*/
/* BCC - if the dest operand type is unsigned short, don't shift - 8/15/95 */
		HC_new_int(&mask, H_UNSIGNED_SHORT_MASK, 0);
		cast_gen_and(cb, dest, &src1, &mask);
	    }
	    else {	/* signed */

              if (HL_generate_sign_extend_operations) {
                  cast_gen_sign_extend_half_word(cb,dest,&src1);
               }
               else {
	 	  HC_new_int(&offset, H_INT_SIZE - H_SHORT_SIZE, 0);
		  HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT, 0);
		  cast_gen_lsl(cb, &temp, &src1, &offset);
		  cast_gen_asr(cb, dest, &temp, &offset);
	       }
	    }
    	}
	break;
    case HC_MAC:
	Punt("Can't cast a MAC register to short");
	break;
    default:
	Punt("cast_short: Incorrect src data type");
	break;
    }
}

/* BCC - bcc_cast_int added - 6/15/95 */
/*----------------------------------------------------------------------*/
void bcc_cast_int(L_Cb *cb, HC_Operand dest, HC_Operand src, int unsign)
{
    L_Oper *new_oper = NULL;
    int mac_num;
    long value;
    _HC_Operand src1;

    src1 = *src;
    switch (src1.type) {
    case HC_CB:
    case HC_L:
    case HC_S:
    /* BCC - Remove the restriction - 6/27/95 
	Punt("Illegal cast to int"); */
    case HC_I:
	*dest = src1;
	break;
    case HC_F:
	value = (long) src1.value.f;
	HC_new_int(dest, value, unsign);
	break;
    case HC_F2:
	value = (long) src1.value.f2;
	HC_new_int(dest, value, unsign);
	break;
    case HC_R: 
	{
	    if (is_float(src1.data_type)) {
		cast_gen_f_i(cb, dest, &src1);	
	    }
    	    else if (is_double(src1.data_type)) {
		cast_gen_f2_i(cb, dest, &src1);	
	    }
	    else if (is_integer(src1.data_type)) {
		*dest = src1;
		dest->unsign = unsign;
	    }
	    else Punt("Illegal cast to int from register");
    	}
	break;
    case HC_MAC:
	Punt("Can't cast a MAC register to int");
	break;
    default:
	Punt("cast_int: Incorrect src data type");
	break;
    }
}

/* BCC - bcc_cast_float added - 6/15/95 */
/*----------------------------------------------------------------------*/
void bcc_cast_float(L_Cb *cb, HC_Operand dest, HC_Operand src, int unsign)
{
    L_Oper *new_oper = NULL;
    int mac_num;
    long value;
    _HC_Operand src1;

    if (dest->data_type != M_TYPE_FLOAT) 
	Punt("cast_float: Incorrect dest data type");
    src1 = *src;
    switch (src1.type) {
    case HC_CB:
    case HC_L:
    case HC_S:
	Punt("Illegal cast to float");
    case HC_I:
	HC_new_float(dest, (double) src1.value.i);
	break;
    case HC_F:
	*dest = src1;
	break;
    case HC_F2:
	HC_new_float(dest, (double) src1.value.f2);
	break;
    case HC_R: 
	{
    	    if (is_double(src1.data_type)) {
		cast_gen_f2_f(cb, dest, &src1);	
	    }
	    else if (is_integer(src1.data_type)) {
		cast_gen_i_f(cb, dest, &src1);	
	    }
	    else if (is_float(src1.data_type)) {
		*dest = src1;
	    }
	    else Punt("Illegal cast to float from register");
    	}
	break;
    case HC_MAC:
	Punt("Can't cast a MAC register to float");
	break;
    default:
	Punt("cast_float: Incorrect src data type");
	break;
    }
}

/* BCC - bcc_cast_double added - 6/15/95 */
/*----------------------------------------------------------------------*/
void bcc_cast_double(L_Cb *cb, HC_Operand dest, HC_Operand src, int unsign)
{
    L_Oper *new_oper = NULL;
    int mac_num;
    long value;
    _HC_Operand src1;

    if (dest->data_type != M_TYPE_DOUBLE) 
	Punt("cast_double: Incorrect dest data type");
    src1 = *src;
    switch (src1.type) {
    case HC_CB:
    case HC_L:
    case HC_S:
	Punt("Illegal cast to double");
    case HC_I:
	HC_new_double(dest, (double) src1.value.i);
	break;
    case HC_F:
	HC_new_double(dest, (double) src1.value.f);
	break;
    case HC_F2:
	*dest = src1;
	break;
    case HC_R: 
	{
    	    if (is_float(src1.data_type)) {
		cast_gen_f_f2(cb, dest, &src1);	
	    }
	    else if (is_integer(src1.data_type)) {
		cast_gen_i_f2(cb, dest, &src1);	
	    }
	    else if (is_double(src1.data_type)) {
		*dest = src1;
	    }
	    else Punt("Illegal cast to double from register");
    	}
	break;
    case HC_MAC:
	Punt("Can't cast a MAC register to double");
	break;
    default:
	Punt("cast_double: Incorrect src data type");
	break;
    }
}

/*----------------------------------------------------------------------*/
void HC_gen_block_mov(L_Cb *cb, Expr expr,HC_Operand dest, int dest_offset, 
		 HC_Operand src, int src_offset, M_Type mtype, L_Attr *attr1)
{
    int size, align;
    int N, i;
    _HC_Operand dest_addr, src_addr, offset;
    size = mtype->size / H_CHAR_SIZE;
    align = mtype->align / H_CHAR_SIZE;
    if (align==0) Punt("HC_gen_block_mov: align cannot be 0");
    if ((size%align)!=0)
	Punt("HC_gen_block_mov: size must be a multiple of align");
#ifdef DEBUG
printf("HC_gen_block_mov: size=%d, align=%d\n", size, align);
#endif
    /*
     *	compute base address.
     */
    if (dest_offset==0) {
	dest_addr = *dest;
    } else {
	HC_new_int(&offset, dest_offset, 0);
	HC_new_register(&dest_addr, HC_next_reg_id(), M_TYPE_POINTER, 0);
	HC_gen_add(cb, &dest_addr, dest, &offset, 1, L_copy_attr(attr1));
    }
    if (src_offset==0) {
	src_addr = *src;
    } else {
	HC_new_int(&offset, src_offset, 0);
	HC_new_register(&src_addr, HC_next_reg_id(), M_TYPE_POINTER, 0);
	HC_gen_add(cb, &src_addr, src, &offset, 1, L_copy_attr(attr1));
    }
    /*
     *	generate copy code.
     */

/* REH 9/8/93 - changed the limit to 64 words 
#define HC_UNWRAP_LIMIT	16
*/
#define HC_UNWRAP_LIMIT	64
/* HER */

    N = size / align;
    if (N < HC_UNWRAP_LIMIT) {
	_HC_Operand temp;
	_HC_Operand dest, src1, src2, src3;
	L_Attr *block_move_attr;

	block_move_attr = L_new_attr ("block_move", 0);
	block_move_attr = L_concat_attr (block_move_attr, L_copy_attr (attr1));

	if (align>=(M_ALIGN_INT/H_CHAR_SIZE)) {
	    /*  REH 5/20/95 -> moved this into the inner loop
		so that a new temp is created for each ld/st pair. */
	    /*
	    HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT);
	    */
	    if ((align%(M_ALIGN_INT/H_CHAR_SIZE))!=0) {
		fprintf(stderr, "size=%d, align=%d\n", size, align);
		Punt("HC_gen_block_mov: bad align");
	    }
	    N = size / (H_INT_SIZE/H_CHAR_SIZE);
	    for (i=0; i<N; i++) {
		/* load */

		/* REH 5/20/95 - moved here from above */
		HC_new_register(&temp, HC_next_reg_id(), M_TYPE_INT, 0);

		dest = temp;
		src1 = src_addr;
                /* DMG - Patch for X86 - need to reverse order in which
                   structure elements are moved, so that for moves
                   which are function parameter passing, the push
                   opers are laid out in correct order  */
                if (M_arch == M_X86)
                    HC_new_int(&src2, (N-i-1)*(H_INT_SIZE/H_CHAR_SIZE), 0);
                else
                    HC_new_int(&src2, i*(H_INT_SIZE/H_CHAR_SIZE), 0);

		/* load expr is really the sibling if it exists :) - SAM 6/94 */
		if (expr->sibling)
		    HC_gen_load(cb, expr->sibling,&dest, &src1, &src2, 1,  L_copy_attr(block_move_attr));
		else
		    HC_gen_load(cb, expr,&dest, &src1, &src2, 1,  L_copy_attr(block_move_attr));

		/* store */
		src1 = dest_addr;
		src3 = dest;
		HC_gen_store(cb, expr,&src1, &src2, &src3, src3.data_type, 
						 L_copy_attr(block_move_attr));
	    }
	} else {
	    /*  REH 5/20/95 -> moved this into the inner loop
		so that a new temp is created for each ld/st pair. */
	    /*
	    HC_new_register(&temp, HC_next_reg_id(), M_TYPE_CHAR);
	    */
	    N = size;
	    for (i=0; i<N; i++) {

		/* REH 5/20/95 - moved here from above */
		HC_new_register(&temp, HC_next_reg_id(), M_TYPE_CHAR, 0);
		
		/* load */
		dest = temp;
		src1 = src_addr;
		HC_new_int(&src2, i, 0);
		HC_gen_load(cb, expr,&dest, &src1, &src2, 1,  L_copy_attr(block_move_attr));
		/* store */
		src1 = dest_addr;
		src3 = dest;
		HC_gen_store(cb,expr,&src1,&src2, &src3,src3.data_type, L_copy_attr(block_move_attr));
	    }
	}

	L_delete_all_attr (block_move_attr);

    } else {
	L_Attr *call_info_attr = NULL;
	/*
	 *  OLD: makes a call to our internal block copy routine.
	 *  OLD: IMPACT_block_mov(dest_addr, src_addr, length, align)
         *
         *  Now make a call to the library call memcpy, as follows:
         *  memcpy (dest_addr, src_addr, length). -JCG 4/30/98
	 */
	_HC_Operand arg[4];
	_M_Type type[4];
	_M_Type ret_type;
	arg[0] = dest_addr;
	M_pointer(type+0);
	arg[1] = src_addr;
	M_pointer(type+1);
	HC_new_int(arg+2, size, 0);
	M_int(type+2, 0);
	M_pointer(&ret_type);

	/* Add call_info attribute to attr1 -JCG 5/24/98 */
	call_info_attr = L_new_attr ("call_info", 1);
	L_set_string_attr_field(call_info_attr, 0, 
				"\"void+P%void+P%void+P%int\"");
	call_info_attr = L_concat_attr (call_info_attr,
					 L_copy_attr(attr1));

	HC_gen_expand(cb, "memcpy", arg, ret_type, type, 3, call_info_attr);
       
    }

    /* LCW - change L_free to L_delete_all_attr since attr1 might be a list 
       - 8/7/97 */
    if (attr1 != NULL)
       /* L_free(L_alloc_attr, attr1); */
       L_delete_all_attr(attr1);

}
/*----------------------------------------------------------------------*/
void HC_gen_mov(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("HC_gen_mov: arguments must be unique");
    if (is_integer(dest->data_type)) {
	if (is_float(src1->data_type)) {
            new_oper = L_create_new_op(Lop_F_I);
            new_oper->dest[0] = gen_operand(dest);
            new_oper->src[0] = gen_operand(src1);
	} else
	if (is_double(src1->data_type)) {
            new_oper = L_create_new_op(Lop_F2_I);
            new_oper->dest[0] = gen_operand(dest);
            new_oper->src[0] = gen_operand(src1);
	} else {
            new_oper = L_create_new_op(Lop_MOV);
            new_oper->dest[0] = gen_operand(dest);
            new_oper->src[0] = gen_operand(src1);
	}
    } else
    if (is_float(dest->data_type)) {
	if (is_integer(src1->data_type)) {
            new_oper = L_create_new_op(Lop_I_F);
            new_oper->dest[0] = gen_operand(dest);
            new_oper->src[0] = gen_operand(src1);
	} else
	if (is_double(src1->data_type)) {
            new_oper = L_create_new_op(Lop_F2_F);
            new_oper->dest[0] = gen_operand(dest);
            new_oper->src[0] = gen_operand(src1);
	} else {
            new_oper = L_create_new_op(Lop_MOV_F);
            new_oper->dest[0] = gen_operand(dest);
            new_oper->src[0] = gen_operand(src1);
	}
    } else
    if (is_double(dest->data_type)) {
	if (is_integer(src1->data_type)) {
            new_oper = L_create_new_op(Lop_I_F2);
            new_oper->dest[0] = gen_operand(dest);
            new_oper->src[0] = gen_operand(src1);
	} else
	if (is_float(src1->data_type)) {
            new_oper = L_create_new_op(Lop_F_F2);
            new_oper->dest[0] = gen_operand(dest);
            new_oper->src[0] = gen_operand(src1);
	} else {
            new_oper = L_create_new_op(Lop_MOV_F2);
            new_oper->dest[0] = gen_operand(dest);
            new_oper->src[0] = gen_operand(src1);
	}
    } else {
	Punt("HC_gen_mov: illegal arguments");
    }

    if (attr1!=0) 	/* RAB 9/1/94 */
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op,new_oper);
}
/*----------------------------------------------------------------------*/

/* SAM 6-94 */
/*
 *	For memory accesses insert the name of the array/var that
 *	is being accessed to assist Lcode memory disambiguation
 */
static void HC_gen_label_attr(Expr expr, L_Oper *oper)
{
    char buf[128];
    L_Attr *attr;
    Expr operands;

    if (expr==NULL)
	return;

    if (expr->opcode==OP_var) {
        sprintf(buf, "lab_%s", expr->value.var_name);
        attr = L_new_attr(buf, 0);
        oper->attr = L_concat_attr(oper->attr, attr);
    }
    else if (expr->opcode==OP_index) {
        operands = expr->operands;
        if (operands->opcode==OP_var) {
            sprintf(buf, "lab_%s", operands->value.var_name);
            attr = L_new_attr(buf, 0);
            oper->attr = L_concat_attr(oper->attr, attr);
        }
    }
}

int  HC_safe_mem_ref(L_Oper *oper)
{
    if (!(M_is_stack_operand(oper->src[0]) || 
	  M_is_stack_operand(oper->src[1])))
	return 0;

    if (L_is_int_constant(oper->src[0]) || 
	L_is_int_constant(oper->src[1]))
	return 1;
    else
	return 0;
}

void HC_gen_load(L_Cb *cb, Expr expr, HC_Operand dest, HC_Operand src1, 
		HC_Operand src2, int unsign, L_Attr *attr1)
{

    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_load: arguments must be unique");
    if (is_char(dest->data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_load (1)");
	if (unsign)
            new_oper = L_create_new_op(Lop_LD_UC);
	else
            new_oper = L_create_new_op(Lop_LD_C);
        new_oper->dest[0] = gen_operand(dest);
        new_oper->src[0] = gen_operand(src1);
        new_oper->src[1] = gen_operand(src2);
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,0);
    } else
    if (is_short(dest->data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_load (2)");
	if (unsign)
            new_oper = L_create_new_op(Lop_LD_UC2);
	else
            new_oper = L_create_new_op(Lop_LD_C2);
        new_oper->dest[0] = gen_operand(dest);
        new_oper->src[0] = gen_operand(src1);
        new_oper->src[1] = gen_operand(src2);
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,0);
    } else
    if (is_integer(dest->data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_load (3)");
        new_oper = L_create_new_op(Lop_LD_I);
        new_oper->dest[0] = gen_operand(dest);
        new_oper->src[0] = gen_operand(src1);
        new_oper->src[1] = gen_operand(src2);
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,0);
    } else
    if (is_float(dest->data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_load (4)");
        new_oper = L_create_new_op(Lop_LD_F);
        new_oper->dest[0] = gen_operand(dest);
        new_oper->src[0] = gen_operand(src1);
        new_oper->src[1] = gen_operand(src2);
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,0);
    } else
    if (is_double(dest->data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_load (5)");
        new_oper = L_create_new_op(Lop_LD_F2);
        new_oper->dest[0] = gen_operand(dest);
        new_oper->src[0] = gen_operand(src1);
        new_oper->src[1] = gen_operand(src2);
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,0);
    } else {
	Punt("HC_gen_load: illegal data type");
    }

    /* SAM 6-94 */
    if (HL_generate_label_attrs)
        HC_gen_label_attr(expr, new_oper);

    /* Mark scalar stack references as trivially safe - RAB 8/94 */
    if (HC_safe_mem_ref(new_oper))
	new_oper->flags = L_SET_BIT_FLAG(new_oper->flags, L_OPER_SAFE_PEI);

    if (attr1!=0) 	/* RAB 9/94 */
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);

}
/*----------------------------------------------------------------------*/
void HC_gen_store(L_Cb *cb, Expr expr, HC_Operand src1, HC_Operand src2, 
		HC_Operand src3, int data_type, L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((src3==src1)|(src3==src2)|(src1==src2))
	Punt("HC_gen_store: arguments must be unique");
    if (is_char(data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_store (1)");
        new_oper = L_create_new_op(Lop_ST_C);
        new_oper->src[0] = gen_operand(src1);
        new_oper->src[1] = gen_operand(src2);
        new_oper->src[2] = gen_operand(src3);
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,1);
    } else
    if (is_short(data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_store (2)");
        new_oper = L_create_new_op(Lop_ST_C2);
        new_oper->src[0] = gen_operand(src1);
        new_oper->src[1] = gen_operand(src2);
        new_oper->src[2] = gen_operand(src3);
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,1);
    } else
    if (is_integer(data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_store (3)");
        new_oper = L_create_new_op(Lop_ST_I);
        new_oper->src[0] = gen_operand(src1);
        new_oper->src[1] = gen_operand(src2);
        new_oper->src[2] = gen_operand(src3);
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,1);
    } else
    if (is_float(data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_store (4)");
	/* BCC - fix for assigning an f2 to f - 7/8/95 */
	if (is_double(src3->data_type)) {
	    _HC_Operand temp;
	    HC_new_register(&temp, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    bcc_cast_float(cb, &temp, src3, 0);
	    new_oper = L_create_new_op(Lop_ST_F);
	    new_oper->src[0] = gen_operand(src1);
	    new_oper->src[1] = gen_operand(src2);
	    new_oper->src[2] = gen_operand(&temp);
	}
	else {
	    new_oper = L_create_new_op(Lop_ST_F);
	    new_oper->src[0] = gen_operand(src1);
	    new_oper->src[1] = gen_operand(src2);
	    new_oper->src[2] = gen_operand(src3);
	}
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,1);
    } else
    if (is_double(data_type)) {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_store (5)");
	/* BCC - fix for assigning an f to f2 - 7/8/95 */
	if (is_float(src3->data_type)) {
	    _HC_Operand temp;
	    HC_new_register(&temp, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    bcc_cast_double(cb, &temp, src3, 0);
	    new_oper = L_create_new_op(Lop_ST_F2);
	    new_oper->src[0] = gen_operand(src1);
	    new_oper->src[1] = gen_operand(src2);
	    new_oper->src[2] = gen_operand(&temp);
	}
	else {
	    new_oper = L_create_new_op(Lop_ST_F2);
	    new_oper->src[0] = gen_operand(src1);
	    new_oper->src[1] = gen_operand(src2);
	    new_oper->src[2] = gen_operand(src3);
	}
	if (HL_generate_sync_arcs)
	    HC_gen_dep_arcs (new_oper,expr,src1,src2,1);
    } else {
	Punt("HC_gen_store: illegal data type");
    }

    /* SAM 6-94 */
    if (HL_generate_label_attrs)
        HC_gen_label_attr(expr, new_oper);

    /* Mark scalar stack references as trivially safe - RAB 8/94 */
    if (HC_safe_mem_ref(new_oper))
	new_oper->flags = L_SET_BIT_FLAG(new_oper->flags, L_OPER_SAFE_PEI);

    if (attr1!=0) 	/* RAB 9/94 */
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);
	
    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/*----------------------------------------------------------------------*/
void HC_gen_add(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, 
		int unsign, L_Attr *attr1)
{
    L_Oper *new_oper;
    _HC_Operand Src1, Src2, Dest;
    int implicit_cast=0;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_add: arguments must be unique");

    if ( is_double(src1->data_type) || is_double(src2->data_type) ) {
	if ( is_double(src1->data_type) ) 
	    Src1 = *src1;
	else {
	    HC_new_register(&Src1, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    bcc_cast_double(cb, &Src1, src1, 0);
	};
	if ( is_double(src2->data_type) ) 
	    Src2 = *src2;
	else {
	    HC_new_register(&Src2, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    bcc_cast_double(cb, &Src2, src2, 0);
	};
	if ( is_double(dest->data_type) )
	    Dest = *dest;
	else {
	    HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    implicit_cast = 1;
	};
	
        new_oper = L_create_new_op(Lop_ADD_F2);
        new_oper->dest[0] = gen_operand(&Dest);
        new_oper->src[0] = gen_operand(&Src1);
        new_oper->src[1] = gen_operand(&Src2);
    } else 
    if ( is_float(src1->data_type) || is_float(src2->data_type) ) {
	if ( is_float(src1->data_type) ) 
	    Src1 = *src1;
	else {
	    HC_new_register(&Src1, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    bcc_cast_float(cb, &Src1, src1, 0);
	};
	if ( is_float(src2->data_type) ) 
	    Src2 = *src2;
	else {
	    HC_new_register(&Src2, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    bcc_cast_float(cb, &Src2, src2, 0);
	};
	if ( is_float(dest->data_type) )
	    Dest = *dest;
	else {
	    HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    implicit_cast = 1;
	};
	
        new_oper = L_create_new_op(Lop_ADD_F);
        new_oper->dest[0] = gen_operand(&Dest);
        new_oper->src[0] = gen_operand(&Src1);
        new_oper->src[1] = gen_operand(&Src2);
    } else 
    if ( is_integer(src1->data_type) && is_integer(src2->data_type) ) {
	Src1 = *src1;
	Src2 = *src2;
	switch (dest->data_type) {
	    case M_TYPE_CHAR :
	    case M_TYPE_SHORT:
	    case M_TYPE_FLOAT:
	    case M_TYPE_DOUBLE:
		HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_INT, 0);
		implicit_cast = 1;
		break;
	    default :
		Dest = *dest;
	}
	if (unsign)
            new_oper = L_create_new_op(Lop_ADD_U);
	else
            new_oper = L_create_new_op(Lop_ADD);
        new_oper->dest[0] = gen_operand(&Dest);
        new_oper->src[0] = gen_operand(&Src1);
        new_oper->src[1] = gen_operand(&Src2);
    };

    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);

    if (implicit_cast) {
	switch (dest->data_type) {
	    case M_TYPE_CHAR :
		bcc_cast_char(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_SHORT :
		bcc_cast_short(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_INT :
	    case M_TYPE_LONG :
		bcc_cast_int(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_FLOAT :
		bcc_cast_float(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_DOUBLE :
		bcc_cast_float(cb, dest, &Dest, unsign);
		break;
	    default :
		Punt("Illegal dest type for HC_gen_add");
		break;
	}
    };
}

/*----------------------------------------------------------------------*/
void HC_gen_sub(L_Cb *cb, HC_Operand dest, HC_Operand src1, 
				HC_Operand src2, int unsign, L_Attr *attr1)
{
    L_Oper *new_oper;
    _HC_Operand Src1, Src2, Dest;
    int implicit_cast=0;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_sub: arguments must be unique");

    if ( is_double(src1->data_type) || is_double(src2->data_type) ) {
	if ( is_double(src1->data_type) ) 
	    Src1 = *src1;
	else {
	    HC_new_register(&Src1, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    bcc_cast_double(cb, &Src1, src1, 0);
	};
	if ( is_double(src2->data_type) ) 
	    Src2 = *src2;
	else {
	    HC_new_register(&Src2, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    bcc_cast_double(cb, &Src2, src2, 0);
	};
	if ( is_double(dest->data_type) )
	    Dest = *dest;
	else {
	    HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    implicit_cast = 1;
	};
	
        new_oper = L_create_new_op(Lop_SUB_F2);
        new_oper->dest[0] = gen_operand(&Dest);
        new_oper->src[0] = gen_operand(&Src1);
        new_oper->src[1] = gen_operand(&Src2);
    } else
    if ( is_float(src1->data_type) || is_float(src2->data_type) ) {
	if ( is_float(src1->data_type) ) 
	    Src1 = *src1;
	else {
	    HC_new_register(&Src1, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    bcc_cast_float(cb, &Src1, src1, 0);
	};
	if ( is_float(src2->data_type) ) 
	    Src2 = *src2;
	else {
	    HC_new_register(&Src2, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    bcc_cast_float(cb, &Src2, src2, 0);
	};
	if ( is_float(dest->data_type) )
	    Dest = *dest;
	else {
	    HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    implicit_cast = 1;
	};
	
        new_oper = L_create_new_op(Lop_SUB_F);
        new_oper->dest[0] = gen_operand(&Dest);
        new_oper->src[0] = gen_operand(&Src1);
        new_oper->src[1] = gen_operand(&Src2);
    } else
    if ( is_integer(src1->data_type) && is_integer(src2->data_type) ) {
	Src1 = *src1;
	Src2 = *src2;
	switch (dest->data_type) {
	    case M_TYPE_CHAR :
	    case M_TYPE_SHORT:
	    case M_TYPE_FLOAT:
	    case M_TYPE_DOUBLE:
		HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_INT, 0);
		implicit_cast = 1;
		break;
	    default :
		Dest = *dest;
	}
	if (unsign)
            new_oper = L_create_new_op(Lop_SUB_U);
	else
            new_oper = L_create_new_op(Lop_SUB);
        new_oper->dest[0] = gen_operand(&Dest);
        new_oper->src[0] = gen_operand(&Src1);
        new_oper->src[1] = gen_operand(&Src2);
    };

    /* LCW -- 8/8/95 */
    if (attr1!=0)
        new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);

    if (implicit_cast) {
	switch (dest->data_type) {
	    case M_TYPE_CHAR :
		bcc_cast_char(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_SHORT :
		bcc_cast_short(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_INT :
	    case M_TYPE_LONG :
		bcc_cast_int(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_FLOAT :
		bcc_cast_float(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_DOUBLE :
		bcc_cast_float(cb, dest, &Dest, unsign);
		break;
	    default :
		Punt("Illegal dest type for HC_gen_sub");
		break;
	}
    };
}

/*----------------------------------------------------------------------*/
void HC_gen_mul(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, 
				int unsign, L_Attr *attr1)
{
    L_Oper *new_oper;
    _HC_Operand Src1, Src2, Dest;
    int implicit_cast=0;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_mul: arguments must be unique");

    if ( is_double(src1->data_type) || is_double(src2->data_type) ) {
	if ( is_double(src1->data_type) ) 
	    Src1 = *src1;
	else {
	    HC_new_register(&Src1, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    bcc_cast_double(cb, &Src1, src1, 0);
	};
	if ( is_double(src2->data_type) ) 
	    Src2 = *src2;
	else {
	    HC_new_register(&Src2, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    bcc_cast_double(cb, &Src2, src2, 0);
	};
	if ( is_double(dest->data_type) )
	    Dest = *dest;
	else {
	    HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    implicit_cast = 1;
	};
	
        new_oper = L_create_new_op(Lop_MUL_F2);
        new_oper->dest[0] = gen_operand(&Dest);
        new_oper->src[0] = gen_operand(&Src1);
        new_oper->src[1] = gen_operand(&Src2);
    } else
    if ( is_float(src1->data_type) || is_float(src2->data_type) ) {
	if ( is_float(src1->data_type) ) 
	    Src1 = *src1;
	else {
	    HC_new_register(&Src1, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    bcc_cast_float(cb, &Src1, src1, 0);
	};
	if ( is_float(src2->data_type) ) 
	    Src2 = *src2;
	else {
	    HC_new_register(&Src2, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    bcc_cast_float(cb, &Src2, src2, 0);
	};
	if ( is_float(dest->data_type) )
	    Dest = *dest;
	else {
	    HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    implicit_cast = 1;
	};
	
        new_oper = L_create_new_op(Lop_MUL_F);
        new_oper->dest[0] = gen_operand(&Dest);
        new_oper->src[0] = gen_operand(&Src1);
        new_oper->src[1] = gen_operand(&Src2);
    } else
    if ( is_integer(src1->data_type) && is_integer(src2->data_type) ) {
	Src1 = *src1;
	Src2 = *src2;
	switch (dest->data_type) {
	    case M_TYPE_CHAR :
	    case M_TYPE_SHORT:
	    case M_TYPE_FLOAT:
	    case M_TYPE_DOUBLE:
		HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_INT, 0);
		implicit_cast = 1;
		break;
	    default :
		Dest = *dest;
	}
	if (unsign)
            new_oper = L_create_new_op(Lop_MUL_U);
	else
            new_oper = L_create_new_op(Lop_MUL);
        new_oper->dest[0] = gen_operand(&Dest);
        new_oper->src[0] = gen_operand(&Src1);
        new_oper->src[1] = gen_operand(&Src2);
    };

    /* LCW -- 8/8/95 */
    if (attr1!=0)
        new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);

    if (implicit_cast) {
	switch (dest->data_type) {
	    case M_TYPE_CHAR :
		bcc_cast_char(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_SHORT :
		bcc_cast_short(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_INT :
	    case M_TYPE_LONG :
		bcc_cast_int(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_FLOAT :
		bcc_cast_float(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_DOUBLE :
		bcc_cast_float(cb, dest, &Dest, unsign);
		break;
	    default :
		Punt("Illegal dest type for HC_gen_mul");
		break;
	}
    };
}

/*----------------------------------------------------------------------*/
void HC_gen_div(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, 
					int unsign, L_Attr *attr1)
{

    L_Oper *new_oper;
    _HC_Operand Src1, Src2, Dest;
    int implicit_cast=0;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_div: arguments must be unique");

    if ( is_double(src1->data_type) || is_double(src2->data_type) ) {
	if ( is_double(src1->data_type) ) 
	    Src1 = *src1;
	else {
	    HC_new_register(&Src1, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    bcc_cast_double(cb, &Src1, src1, 0);
	};
	if ( is_double(src2->data_type) ) 
	    Src2 = *src2;
	else {
	    HC_new_register(&Src2, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    bcc_cast_double(cb, &Src2, src2, 0);
	};
	if ( is_double(dest->data_type) )
	    Dest = *dest;
	else {
	    HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_DOUBLE, 0);
	    implicit_cast = 1;
	};

	if ((HL_use_subroutine_call)&&(M_subroutine_call(Lop_DIV_F2))) {
	  /* Support for machine software emulation of Lcode operations */
	  HC_gen_subroutine_call_for_operation(cb,&Dest,&Src1,&Src2,Lop_DIV_F2);
	}	
	else {
          new_oper = L_create_new_op(Lop_DIV_F2);
          new_oper->dest[0] = gen_operand(&Dest);
          new_oper->src[0] = gen_operand(&Src1);
          new_oper->src[1] = gen_operand(&Src2);
          L_insert_oper_after(cb,cb->last_op, new_oper);
	}

    } else
    if ( is_float(src1->data_type) || is_float(src2->data_type) ) {
	if ( is_float(src1->data_type) ) 
	    Src1 = *src1;
	else {
	    HC_new_register(&Src1, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    bcc_cast_float(cb, &Src1, src1, 0);
	};
	if ( is_float(src2->data_type) ) 
	    Src2 = *src2;
	else {
	    HC_new_register(&Src2, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    bcc_cast_float(cb, &Src2, src2, 0);
	};
	if ( is_float(dest->data_type) )
	    Dest = *dest;
	else {
	    HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_FLOAT, 0);
	    implicit_cast = 1;
	};
	
	if ((HL_use_subroutine_call)&&(M_subroutine_call(Lop_DIV_F))) {
	  /* Support for machine software emulation of Lcode operations */
	  HC_gen_subroutine_call_for_operation(cb,&Dest,&Src1,&Src2,Lop_DIV_F);
	}
	else {
          new_oper = L_create_new_op(Lop_DIV_F);
          new_oper->dest[0] = gen_operand(&Dest);
          new_oper->src[0] = gen_operand(&Src1);
          new_oper->src[1] = gen_operand(&Src2);
          L_insert_oper_after(cb,cb->last_op, new_oper);
	}
    } else
    if ( is_integer(src1->data_type) && is_integer(src2->data_type) ) {
	Src1 = *src1;
	Src2 = *src2;
	switch (dest->data_type) {
	    case M_TYPE_CHAR :
	    case M_TYPE_SHORT:
	    case M_TYPE_FLOAT:
	    case M_TYPE_DOUBLE:
		HC_new_register(&Dest, HC_next_reg_id(), M_TYPE_INT, 0);
		implicit_cast = 1;
		break;
	    default :
		Dest = *dest;
	}
	if (((HL_use_subroutine_call)&&(M_subroutine_call(Lop_DIV)))||
	   ((HL_use_subroutine_call)&&(M_subroutine_call(Lop_DIV_U)))) {
	  /* Support for machine software emulation of Lcode operations */
	  if (unsign)
	    HC_gen_subroutine_call_for_operation(cb,&Dest,&Src1,&Src2,Lop_DIV_U);
	  else 
	    HC_gen_subroutine_call_for_operation(cb,&Dest,&Src1,&Src2,Lop_DIV);
	}
	else {
	  if (unsign)
            new_oper = L_create_new_op(Lop_DIV_U);
	  else
            new_oper = L_create_new_op(Lop_DIV);
          new_oper->dest[0] = gen_operand(&Dest);
          new_oper->src[0] = gen_operand(&Src1);
          new_oper->src[1] = gen_operand(&Src2);
          L_insert_oper_after(cb,cb->last_op, new_oper);
	}
    }
    else 
	H_punt("HC_gen_div: unsupported divide functionality");

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    if (implicit_cast) {
	switch (dest->data_type) {
	    case M_TYPE_CHAR :
		bcc_cast_char(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_SHORT :
		bcc_cast_short(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_INT :
	    case M_TYPE_LONG :
		bcc_cast_int(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_FLOAT :
		bcc_cast_float(cb, dest, &Dest, unsign);
		break;
	    case M_TYPE_DOUBLE :
		bcc_cast_float(cb, dest, &Dest, unsign);
		break;
	    default :
		Punt("Illegal dest type for HC_gen_div");
		break;
	}
    };
}

/*----------------------------------------------------------------------*/

void HC_gen_mod(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, 
					int unsign, L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_mod: arguments must be unique");
    if (is_float(dest->data_type)) {
	Punt("HC_gen_mod: arguments must be integer type");
    } else
    if (is_double(dest->data_type)) {
	Punt("HC_gen_mod: arguments must be integer type");
    } else {
	if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) )
	    Punt("Non-int operands for HC_gen_mod (1)");
	if (((HL_use_subroutine_call)&&(M_subroutine_call(Lop_REM)))||
	   ((HL_use_subroutine_call)&&(M_subroutine_call(Lop_REM_U)))) {
	  /* Support for machine software emulation of Lcode operations */
	  if (unsign)
	    HC_gen_subroutine_call_for_operation(cb,dest,src1,src2,Lop_REM_U);
	  else
	    HC_gen_subroutine_call_for_operation(cb,dest,src1,src2,Lop_REM);
	}
	else {
	  if (unsign)
            new_oper = L_create_new_op(Lop_REM_U);
	  else
            new_oper = L_create_new_op(Lop_REM);
          new_oper->dest[0] = gen_operand(dest);
          new_oper->src[0] = gen_operand(src1);
          new_oper->src[1] = gen_operand(src2);
          L_insert_oper_after(cb,cb->last_op, new_oper);
	}
    }

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

}
/*----------------------------------------------------------------------*/
void HC_gen_abs(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("HC_gen_abs: arguments must be unique");
    if (is_float(dest->data_type)) {
	if ( !is_float(src1->data_type) ) 
	    Punt("HC_gen_abs: incorrect src1 data type (float)");
        new_oper = L_create_new_op(Lop_ABS_F);
        new_oper->dest[0] = gen_operand(dest);
        new_oper->src[0] = gen_operand(src1);
    } else
    if (is_double(dest->data_type)) {
	if ( !is_double(src1->data_type) ) 
	    Punt("HC_gen_abs: incorrect src1 data type (double)");
        new_oper = L_create_new_op(Lop_ABS_F2);
        new_oper->dest[0] = gen_operand(dest);
        new_oper->src[0] = gen_operand(src1);
    } else {
	if ( !is_integer(src1->data_type) ) 
	    Punt("HC_gen_abs: incorrect src1 data type (integer)");
        new_oper = L_create_new_op(Lop_ABS);
        new_oper->dest[0] = gen_operand(dest);
        new_oper->src[0] = gen_operand(src1);
    }

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/*----------------------------------------------------------------------*/
void HC_gen_or(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
				L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_or: arguments must be unique");

    if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) ||
	 !is_integer(dest->data_type) )
	    Punt("Non-int operands for HC_gen_or");

    new_oper = L_create_new_op(Lop_OR);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/*----------------------------------------------------------------------*/
void HC_gen_and(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
				L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_and: arguments must be unique");

    if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) ||
	 !is_integer(dest->data_type) )
	    Punt("Non-int operands for HC_gen_and");

    new_oper = L_create_new_op(Lop_AND);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/*----------------------------------------------------------------------*/
void HC_gen_xor(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
				L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_xor: arguments must be unique");

    if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) ||
	 !is_integer(dest->data_type) )
	    Punt("Non-int operands for HC_gen_xor");

    new_oper = L_create_new_op(Lop_XOR);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/*----------------------------------------------------------------------*/
void HC_gen_lsl(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
				L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_lsl: arguments must be unique");

    if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) ||
	 !is_integer(dest->data_type) )
	    Punt("Non-int operands for HC_gen_lsl");

    new_oper = L_create_new_op(Lop_LSL);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lsr(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
				L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_lsr: arguments must be unique");

    if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) ||
	 !is_integer(dest->data_type) )
	    Punt("Non-int operands for HC_gen_lsr");

    new_oper = L_create_new_op(Lop_LSR);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_asr(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
				L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_asr: arguments must be unique");

    if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) ||
	 !is_integer(dest->data_type) )
	    Punt("Non-int operands for HC_gen_asr");

    new_oper = L_create_new_op(Lop_ASR);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/*----------------------------------------------------------------------*/
void HC_gen_extract_bits(L_Cb *cb, HC_Operand dest, HC_Operand src0, HC_Operand src1, HC_Operand src2)
{
    L_Oper *new_oper;

    if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) ||
         !is_integer(dest->data_type) )
            Punt("Non-int operands for HC_gen_extract_bits");

    new_oper = L_create_new_op(Lop_BIT_EXTRACT);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src0);
    new_oper->src[1] = gen_operand(src1);
    new_oper->src[2] = gen_operand(src2);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/*----------------------------------------------------------------------*/
void HC_gen_deposit_bits(L_Cb *cb, HC_Operand dest, HC_Operand src0, HC_Operand src1, HC_Operand src2, HC_Operand src3)
{
    L_Oper *new_oper;

    if ( !is_integer(src1->data_type) || !is_integer(src2->data_type) ||
         !is_integer(dest->data_type) )
            Punt("Non-int operands for HC_gen_deposit_bits");

    new_oper = L_create_new_op(Lop_BIT_DEPOSIT);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src0);
    new_oper->src[1] = gen_operand(src1);
    new_oper->src[2] = gen_operand(src2);
    new_oper->src[3] = gen_operand(src3);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/*----------------------------------------------------------------------*/
void HC_gen_eq(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
               Expr operand_expr, L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_eq: arguments must be unique");

    if ( !is_int(dest->data_type) )
	Punt("HC_gen_eq: dest should be of integer type");

    if (is_double(src1->data_type) && is_double(src2->data_type)) {
        new_oper = L_create_new_op(Lop_EQ_F2);
    } else
    if (is_float(src1->data_type) && is_float(src2->data_type)) {
        new_oper = L_create_new_op(Lop_EQ_F);
    } else 
    if (is_integer(src1->data_type) && is_integer(src2->data_type)) {
        new_oper = L_create_new_op(Lop_EQ);
    }
    else Punt("HC_gen_eq: non-equal operands types");

    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* This was added solely to aid with static branch prediction.  I want to
     * be able to propagate the pointer attribute from eq opers to branch opers,
     * which will happen during Lopti. */
    if (operand_expr)
	new_oper->attr = HC_gen_pointer_attr (operand_expr);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_ne(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
				L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_ne: arguments must be unique");

    if ( !is_int(dest->data_type) )
	Punt("HC_gen_ne: dest should be of integer type");

    if (is_double(src1->data_type) && is_double(src2->data_type)) {
        new_oper = L_create_new_op(Lop_NE_F2);
    } else
    if (is_float(src1->data_type) && is_float(src2->data_type)) {
        new_oper = L_create_new_op(Lop_NE_F);
    } else 
    if (is_integer(src1->data_type) && is_integer(src2->data_type)) {
        new_oper = L_create_new_op(Lop_NE);
    }
    else Punt("HC_gen_ne: non-equal operands types");

    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lt(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, 
				int unsign, L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_lt: arguments must be unique");

    if ( !is_int(dest->data_type) )
	Punt("HC_gen_lt: dest should be of integer type");

    if (is_double(src1->data_type) && is_double(src2->data_type)) {
        new_oper = L_create_new_op(Lop_LT_F2);
    } else
    if (is_float(src1->data_type) && is_float(src2->data_type)) {
        new_oper = L_create_new_op(Lop_LT_F);
    } else 
    if (is_integer(src1->data_type) && is_integer(src2->data_type)) {
    	if (unsign)
            new_oper = L_create_new_op(Lop_LT_U);
    	else
            new_oper = L_create_new_op(Lop_LT);
    }
    else Punt("HC_gen_lt: non-equal operands types");

    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_le(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, 
					int unsign, L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_le: arguments must be unique");

    if ( !is_int(dest->data_type) )
	Punt("HC_gen_le: dest should be of integer type");

    if (is_double(src1->data_type) && is_double(src2->data_type)) {
        new_oper = L_create_new_op(Lop_LE_F2);
    } else
    if (is_float(src1->data_type) && is_float(src2->data_type)) {
        new_oper = L_create_new_op(Lop_LE_F);
    } else 
    if (is_integer(src1->data_type) && is_integer(src2->data_type)) {
    	if (unsign)
            new_oper = L_create_new_op(Lop_LE_U);
    	else
            new_oper = L_create_new_op(Lop_LE);
    }
    else Punt("HC_gen_le: non-equal operands types");

    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_ge(L_Cb *cb,HC_Operand dest,HC_Operand src1, HC_Operand src2, 
					int unsign, L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_ge: arguments must be unique");

    if ( !is_int(dest->data_type) )
	Punt("HC_gen_ge: dest should be of integer type");

    if (is_double(src1->data_type) && is_double(src2->data_type)) {
        new_oper = L_create_new_op(Lop_GE_F2);
    } else
    if (is_float(src1->data_type) && is_float(src2->data_type)) {
        new_oper = L_create_new_op(Lop_GE_F);
    } else 
    if (is_integer(src1->data_type) && is_integer(src2->data_type)) {
    	if (unsign)
            new_oper = L_create_new_op(Lop_GE_U);
    	else
            new_oper = L_create_new_op(Lop_GE);
    }
    else Punt("HC_gen_ge: non-equal operands types");

    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_gt(L_Cb *cb, HC_Operand dest,HC_Operand src1,HC_Operand src2, 
					int unsign, L_Attr *attr1)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("HC_gen_gt: arguments must be unique");

    if ( !is_int(dest->data_type) )
	Punt("HC_gen_gt: dest should be of integer type");

    if (is_double(src1->data_type) && is_double(src2->data_type)) {
        new_oper = L_create_new_op(Lop_GT_F2);
    } else
    if (is_float(src1->data_type) && is_float(src2->data_type)) {
        new_oper = L_create_new_op(Lop_GT_F);
    } else 
    if (is_integer(src1->data_type) && is_integer(src2->data_type)) {
    	if (unsign)
            new_oper = L_create_new_op(Lop_GT_U);
    	else
            new_oper = L_create_new_op(Lop_GT);
    }
    else Punt("HC_gen_gt: non-equal operands types");

    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_f2_f(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("HC_gen_f2_f: arguments must be unique");
    
    if ( !is_double(src1->data_type) )
	Punt("HC_gen_f2_f: incorrect src type");
    if ( !is_float(dest->data_type) )
	Punt("HC_gen_f2_f: incorrect dest type");

    new_oper = L_create_new_op(Lop_F2_F);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_i_f(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("HC_gen_i_f: arguments must be unique");

    if ( !is_integer(src1->data_type) )
	Punt("HC_gen_i_f: incorrect src type");
    if ( !is_float(dest->data_type) )
	Punt("HC_gen_i_f: incorrect dest type");

    new_oper = L_create_new_op(Lop_I_F);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_f_f2(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("HC_gen_f_f2: arguments must be unique");

    if ( !is_float(src1->data_type) )
	Punt("HC_gen_f_f2: incorrect src type");
    if ( !is_double(dest->data_type) )
	Punt("HC_gen_f_f2: incorrect dest type");

    new_oper = L_create_new_op(Lop_F_F2);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_i_f2(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("HC_gen_i_f2: arguments must be unique");

    if ( !is_integer(src1->data_type) )
	Punt("HC_gen_i_f2: incorrect src type");
    if ( !is_double(dest->data_type) )
	Punt("HC_gen_i_f2: incorrect dest type");

    new_oper = L_create_new_op(Lop_I_F2);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_f2_i(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("HC_gen_f2_i: arguments must be unique");

    if ( !is_double(src1->data_type) )
	Punt("HC_gen_f2_i: incorrect src type");
    if ( !is_integer(dest->data_type) )
	Punt("HC_gen_f2_i: incorrect dest type");

    new_oper = L_create_new_op(Lop_F2_I);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_f_i(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("HC_gen_f_i: arguments must be unique");

    if ( !is_float(src1->data_type) )
	Punt("HC_gen_f_i: incorrect src type");
    if ( !is_integer(dest->data_type) )
	Punt("HC_gen_f_i: incorrect dest type");

    new_oper = L_create_new_op(Lop_F_I);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    /* LCW -- 8/8/95 */
    if (attr1!=0)
	new_oper->attr = L_concat_attr(new_oper->attr, attr1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_alloc(L_Cb *cb, HC_Operand dest, int size, int align)
{
    L_Oper *new_oper;

    if ( dest->data_type != M_TYPE_POINTER )
	Punt("HC_gen_alloc: incorrect dest type");

    new_oper = L_create_new_op(Lop_ALLOC);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = L_new_gen_int_operand(size);
    new_oper->src[1] = L_new_gen_int_operand(align);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
/* THIS IS FOR THE EXCLUSIVE USE OF THE STATIC BRANCH ANALYSIS WORK */

#define FPRINTF_STDOUT 1
#define FPRINTF_STDERR 2

static int HC_classify_fprintf (Expr expr)
{
    Expr op1, op2, iob_op, iob_op1, iob_op2;

    if (!expr) return (0);

    if (expr->opcode != OP_call) return (0);

    op1 = GetOperand (expr, 1);
    if (op1->opcode != OP_var) return (0);
    if (strcmp (op1->value.var_name, "fprintf")) return (0);

    op2 = GetOperand (expr, 2);
    if (op2->opcode == OP_addr) {
       iob_op = GetOperand (op2, 1);
       if (iob_op->opcode != OP_index) return (0);
    }
    else if (op2->opcode == OP_add)
       iob_op = op2;
    else
       return (0);

    iob_op1 = GetOperand (iob_op, 1);
    if (iob_op1->opcode != OP_var) return (0);
    if (strcmp (iob_op1->value.var_name, "__iob")) return (0);

    iob_op2 = GetOperand (iob_op, 2);
    if (iob_op2->opcode != OP_signed) return (0);
    if (iob_op2->value.scalar == 1) return (FPRINTF_STDOUT);
    else if (iob_op2->value.scalar == 2) return (FPRINTF_STDERR);
    else return (0);
}
/*----------------------------------------------------------------------*/
void HC_gen_jsr(L_Cb *cb, Expr expr, HC_Operand src, int argc, L_Attr *attr1)
{
    L_Oper *new_oper;
    L_Attr *new_attr;
    Pragma pragma;

    new_oper = L_create_new_op(Lop_JSR);
    new_oper->src[0] = gen_operand(src);
    if (attr1!=0)
        new_oper->attr = attr1;

    if (expr != NULL && expr->pragma != NULL) {
	new_attr = HC_gen_attr_from_pragma(expr->pragma);
	new_oper->attr = L_concat_attr (new_oper->attr, new_attr); 
    }

    if (HL_generate_static_branch_attrs) {
	int is_special_fprintf = HC_classify_fprintf (expr);

	if (is_special_fprintf) {
	    if (is_special_fprintf == FPRINTF_STDOUT)
		new_attr = HC_gen_attr ("fprintf_stdout", 0);
	    else if (is_special_fprintf == FPRINTF_STDERR)
		new_attr = HC_gen_attr ("fprintf_stderr", 0);
	    else
		Punt ("internal error for FPRINTF handling");
	    new_oper->attr = L_concat_attr (new_oper->attr, new_attr);
	}
    }

    if (HL_generate_sync_arcs)
	HC_gen_dep_arcs (new_oper,expr,0,0,0);

    /* SAM 9-95, added to mark setjmp and longjmps and sync jsrs */
    if (L_op_in_synchronization_func_table(new_oper))
	new_oper->flags = L_SET_BIT_FLAG(new_oper->flags, L_OPER_SYNC);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*======================================================================*/
void HC_gen_lcode_select_i(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<3)
	Punt("HC_gen_lcode_select_i: not enough arguments");

    if (!is_integer(src->data_type) || !is_integer((src+1)->data_type) ||
	!is_integer((src+2)->data_type) )
	Punt("HC_gen_lcode_select_i: incorrect src types");

    new_oper = L_create_new_op(Lop_SELECT);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);
    new_oper->src[1] = gen_operand(src+1);
    new_oper->src[2] = gen_operand(src+2);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_select_f(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<3)
	Punt("HC_gen_lcode_select_f: not enough arguments");

    if (!is_integer(src->data_type) || !is_float((src+1)->data_type) ||
	!is_float((src+2)->data_type) )
	Punt("HC_gen_lcode_select_f: incorrect src types");

    new_oper = L_create_new_op(Lop_SELECT_F);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);
    new_oper->src[1] = gen_operand(src+1);
    new_oper->src[2] = gen_operand(src+2);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_select_f2(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<3)
	Punt("HC_gen_lcode_select_f2: not enough arguments");

    if (!is_integer(src->data_type) || !is_double((src+1)->data_type) ||
	!is_double((src+2)->data_type) )
	Punt("HC_gen_lcode_select_f2: incorrect src types");

    new_oper = L_create_new_op(Lop_SELECT_F2);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);
    new_oper->src[1] = gen_operand(src+1);
    new_oper->src[2] = gen_operand(src+2);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_rev(L_Cb *cb, HC_Operand dest, _HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<1)
	Punt("HC_gen_lcode_rev: not enough arguments");

    if (!is_integer(src->data_type)) 
	Punt("HC_gen_lcode_rev: incorrect src type");

    new_oper = L_create_new_op(Lop_REV);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_bit_pos(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<1)
	Punt("HC_gen_lcode_bit_pos: not enough arguments");

    if (!is_integer(src->data_type)) 
	Punt("HC_gen_lcode_bit_pos: incorrect src type");

    new_oper = L_create_new_op(Lop_BIT_POS);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_abs_i(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<1)
	Punt("HC_gen_lcode_abs_i: not enough arguments");

    if (!is_integer(src->data_type)) 
	Punt("HC_gen_lcode_abs_i: incorrect src type");

    new_oper = L_create_new_op(Lop_ABS);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_abs_f(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<1)
	Punt("HC_gen_lcode_abs_f: not enough arguments");

    if (!is_float(src->data_type)) 
	Punt("HC_gen_lcode_abs_f: incorrect src type");

    new_oper = L_create_new_op(Lop_ABS_F);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_abs_f2(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<1)
	Punt("HC_gen_lcode_abs_f2: not enough arguments");

    if (!is_double(src->data_type)) 
	Punt("HC_gen_lcode_abs_f2: incorrect src type");

    new_oper = L_create_new_op(Lop_ABS_F2);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_co_proc(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<2)
	Punt("HC_gen_lcode_co_proc: not enough arguments");

    if (!is_integer(src->data_type) || !is_integer((src+1)->data_type) )
	Punt("HC_gen_lcode_co_proc: incorrect src types");

    new_oper = L_create_new_op(Lop_CO_PROC);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);
    new_oper->src[1] = gen_operand(src+1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_fetch_add(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<2)
	Punt("HC_gen_lcode_fetch_add: not enough arguments");

    if (!is_integer(src->data_type) || !is_integer((src+1)->data_type) )
	Punt("HC_gen_lcode_fetch_add: incorrect src types");

    new_oper = L_create_new_op(Lop_FETCH_AND_ADD);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);
    new_oper->src[1] = gen_operand(src+1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_fetch_or(L_Cb *cb, HC_Operand dest, 
		_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<2)
	Punt("HC_gen_lcode_fetch_or: not enough arguments");

    if (!is_integer(src->data_type) || !is_integer((src+1)->data_type) )
	Punt("HC_gen_lcode_fetch_or: incorrect src types");

    new_oper = L_create_new_op(Lop_FETCH_AND_OR);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);
    new_oper->src[1] = gen_operand(src+1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_fetch_and(L_Cb *cb, HC_Operand dest, _HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<2)
	Punt("HC_gen_lcode_fetch_and: not enough arguments");

    if (!is_integer(src->data_type) || !is_integer((src+1)->data_type) )
	Punt("HC_gen_lcode_fetch_and: incorrect src types");

    new_oper = L_create_new_op(Lop_FETCH_AND_AND);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);
    new_oper->src[1] = gen_operand(src+1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_fetch_st(L_Cb *cb, HC_Operand dest, 
			_HC_Operand src[], int n_src)
{
    L_Oper *new_oper;

    if (n_src<2)
	Punt("HC_gen_lcode_fetch_st: not enough arguments");

    if (!is_integer(src->data_type) || !is_integer((src+1)->data_type) )
	Punt("HC_gen_lcode_fetch_st: incorrect src types");

    new_oper = L_create_new_op(Lop_FETCH_AND_ST);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);
    new_oper->src[1] = gen_operand(src+1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}
/*----------------------------------------------------------------------*/
void HC_gen_lcode_fetch_cond_st(L_Cb *cb,HC_Operand dest,
			_HC_Operand src[],int n_src)
{
    L_Oper *new_oper;

    if (n_src<3)
	Punt("HC_gen_lcode_fetch_cond_st: not enough arguments");

    if (!is_integer(src->data_type) || !is_integer((src+1)->data_type) ||
	!is_integer((src+2)->data_type) )
	Punt("HC_gen_lcode_fetch_cond_st: incorrect src types");

    new_oper = L_create_new_op(Lop_FETCH_AND_COND_ST);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src);
    new_oper->src[1] = gen_operand(src+1);
    new_oper->src[2] = gen_operand(src+2);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* BCC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 6/17/95 	     */

/*----------------------------------------------------------------------*/
void cast_gen_f_i(L_Cb *cb, HC_Operand dest, HC_Operand src1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("cast_gen_f_i: arguments must be unique");
    new_oper = L_create_new_op(Lop_F_I);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* BCC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 6/17/95 	     */

/*----------------------------------------------------------------------*/
void cast_gen_f2_i(L_Cb *cb, HC_Operand dest, HC_Operand src1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("cast_gen_f2_i: arguments must be unique");
    new_oper = L_create_new_op(Lop_F2_I);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* BCC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 6/17/95 	     */

/*----------------------------------------------------------------------*/
void cast_gen_lsl(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2)
{
    L_Oper *new_oper;
    L_Attr *new_attr;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("cast_gen_lsl: arguments must be unique");
    new_oper = L_create_new_op(Lop_LSL);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    /* Need to add an attribute so optimizer knows that this shift is associated
     * with a cast, so the remove_sign_extend local optimization does not
     * apply itself in this situation.  The optimization cannot be safely
     * applied when the shifts are associated with a cast. */
    new_attr = L_new_attr ("cast", 0);
    new_oper->attr = L_concat_attr (new_oper->attr, new_attr);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* BCC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 6/17/95 	     */

/*----------------------------------------------------------------------*/
void cast_gen_asr(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("cast_gen_asr: arguments must be unique");
    new_oper = L_create_new_op(Lop_ASR);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* BCC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 6/17/95 	     */

/*----------------------------------------------------------------------*/
void cast_gen_and(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2)
{
    L_Oper *new_oper;

    if ((dest==src1)|(dest==src2)|(src1==src2))
	Punt("cast_gen_and: arguments must be unique");
    new_oper = L_create_new_op(Lop_AND);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    new_oper->src[1] = gen_operand(src2);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* BCC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 6/17/95 	     */

/*----------------------------------------------------------------------*/
void cast_gen_f2_f(L_Cb *cb, HC_Operand dest, HC_Operand src1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("cast_gen_f2_f: arguments must be unique");
    new_oper = L_create_new_op(Lop_F2_F);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* BCC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 6/17/95 	     */

/*----------------------------------------------------------------------*/
void cast_gen_i_f(L_Cb *cb, HC_Operand dest, HC_Operand src1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("cast_gen_i_f: arguments must be unique");
    new_oper = L_create_new_op(Lop_I_F);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* BCC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 6/17/95 	     */

/*----------------------------------------------------------------------*/
void cast_gen_f_f2(L_Cb *cb, HC_Operand dest, HC_Operand src1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("cast_gen_f_f2: arguments must be unique");
    new_oper = L_create_new_op(Lop_F_F2);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* BCC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 6/17/95 	     */

/*----------------------------------------------------------------------*/
void cast_gen_i_f2(L_Cb *cb, HC_Operand dest, HC_Operand src1)
{
    L_Oper *new_oper;

    if (dest==src1)
	Punt("cast_gen_i_f2: arguments must be unique");
    new_oper = L_create_new_op(Lop_I_F2);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);

    L_insert_oper_after(cb,cb->last_op, new_oper);
}


/* DAC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 1/15/97 	     */

/*----------------------------------------------------------------------*/
void cast_gen_sign_extend_byte(L_Cb *cb, HC_Operand dest, HC_Operand src1)
{
    L_Oper *new_oper;

    new_oper = L_create_new_op(Lop_EXTRACT_C);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    L_insert_oper_after(cb,cb->last_op, new_oper);
}

/* DAC - inside bcc_cast_XXXX, don't use any functions that will call 
	 bcc_cast_XXXX in order to avoid indefinite cast - 1/15/97 	     */

/*----------------------------------------------------------------------*/
void cast_gen_sign_extend_half_word(L_Cb *cb, HC_Operand dest, HC_Operand src1)
{
    L_Oper *new_oper;

    new_oper = L_create_new_op(Lop_EXTRACT_C2);
    new_oper->dest[0] = gen_operand(dest);
    new_oper->src[0] = gen_operand(src1);
    L_insert_oper_after(cb,cb->last_op, new_oper);
}

void
HC_gen_subroutine_call_for_operation(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, int opc) 
{
    L_Oper *new_oper;
    L_Operand *new_operand;
    int macro_operand_type, macro_operand_sign;
    L_Attr *attr = NULL;
    _HC_Operand operand;
    L_Attr *func_attr=NULL,*new_attr, *tr_attr;
    char line[128];
    char *new_label, name[256];

    if (M_arch != M_TI)
	H_punt("HC_gen_subroutine_call: currently this function works for TI only");

    if (L_propagate_sign_size_ctype_info) {
      switch (opc) {
      case Lop_DIV:
      case Lop_REM:
	macro_operand_sign = 0;
	macro_operand_type = M_TYPE_INT;
	break;
      case Lop_DIV_U:
      case Lop_REM_U:
	macro_operand_sign = 1;
	macro_operand_type = M_TYPE_INT;
	break;
      case Lop_DIV_F:
      case Lop_DIV_F2:
	macro_operand_sign = 0;
	macro_operand_type = M_TYPE_FLOAT;
	break;
      default:
	H_punt("HC_gen_subroutine_call: unsupported opcode %d",opc);
      }
    }
    else {
      macro_operand_sign = 0;
      switch (opc) {
      case Lop_DIV:
      case Lop_DIV_U:
      case Lop_REM:
      case Lop_REM_U:
	macro_operand_type = M_TYPE_INT;
	break;
      case Lop_DIV_F:
      case Lop_DIV_F2:
	macro_operand_type = M_TYPE_FLOAT;
	break;
      default:
	H_punt("HC_gen_subroutine_call: unsupported opcode %d",opc);
      }
    }

    sprintf(line, "$P0");
    HC_new_macro(&operand, line, macro_operand_type, macro_operand_sign);
    HC_gen_mov(cb, &operand, src1, attr);

    sprintf(line, "$P1");
    HC_new_macro(&operand, line, macro_operand_type, macro_operand_sign);
    HC_gen_mov(cb, &operand, src2, attr);

    tr_attr = L_new_attr("tr",0);
    if (L_propagate_sign_size_ctype_info) {
      L_set_macro_attr_field(tr_attr, 0, L_MAC_P0, 
	L_ctype_id(HC_typename2(macro_operand_type, macro_operand_sign)), L_PTYPE_NULL);
      L_set_macro_attr_field(tr_attr, 1, L_MAC_P1, 
	L_ctype_id(HC_typename2(macro_operand_type, macro_operand_sign)), L_PTYPE_NULL);
    } else {
      L_set_macro_attr_field(tr_attr, 0, L_MAC_P0, 
	L_ctype_id(HC_typename(macro_operand_type)), L_PTYPE_NULL);
      L_set_macro_attr_field(tr_attr, 1, L_MAC_P1, 
	L_ctype_id(HC_typename(macro_operand_type)), L_PTYPE_NULL);
    }
    func_attr = L_concat_attr(func_attr,tr_attr);

    new_attr = L_new_attr("ret",1);
    if (L_propagate_sign_size_ctype_info) 
      L_set_macro_attr_field(new_attr,0,L_MAC_P6, 
	L_ctype_id(HC_typename2(macro_operand_type, macro_operand_sign)), L_PTYPE_NULL);
    else 
      L_set_macro_attr_field(new_attr,0,L_MAC_P6, 
	L_ctype_id(HC_typename(macro_operand_type)), L_PTYPE_NULL);
    func_attr = L_concat_attr (func_attr, new_attr);

    new_attr = L_new_attr("param_size", 1);
    L_set_int_attr_field(new_attr, 0, 16);
    func_attr = L_concat_attr (func_attr, new_attr);

    new_oper = L_create_new_op(Lop_JSR);

    switch(opc) {
       case Lop_DIV_F:
       case Lop_DIV_F2:
         new_label = (char*)M_fn_label_name("divide_f",HC_is_function);
	 break;
       case Lop_DIV:
         new_label = (char*)M_fn_label_name("divide",HC_is_function);
	 break;
       case Lop_DIV_U:
         new_label = (char*)M_fn_label_name("divide_u",HC_is_function);
	 break;
       case Lop_REM:
         new_label = (char*)M_fn_label_name("remainder",HC_is_function);
	 break;
       case Lop_REM_U:
         new_label = (char*)M_fn_label_name("remainder_u",HC_is_function);
	 break;
       default:
	H_punt("HC_gen_subroutine_call: unsupported opcode %d",opc);
    }

    sprintf (name, "_%s",new_label);
    new_operand = L_new_gen_label_operand(name);
    new_oper->src[0] = new_operand;

    new_oper->attr = L_concat_attr (new_oper->attr, func_attr);
    L_insert_oper_after(cb,cb->last_op, new_oper);

    sprintf(line, "$P6");
    HC_new_macro(&operand, line, macro_operand_type, 0);
    HC_gen_mov(cb, dest, &operand, attr);
}
