/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.20  */
/* IMPACT Trimaran Release (www.trimaran.org)                  May 17, 1999  */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright 1999 IMPACT Technologies, Inc; Champaign, Illinois
 * For commercial license rights, contact: Marketing Office via
 * electronic mail: marketing@impactinc.com
 *
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	hl_func.c
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *      Modified by: Nancy J. Warter
 *	Modified by: Roger A. Bringmann  2/8/93
 *	    Modified to produce new Lcode parenthesization/format
 *	 Revised: Dave Gallagher, Scott Mahlke - 6/94
 *              Build Lcode structure rather than just printing out text file
 *      Revised by: Ben-Chung Cheng - June 1995
 *              Change M_SIZE_INT, M_SIZE_CHAR to H_INT_SIZE, H_CHAR_SIZE
 *              Those should be determined in runtime, not compile time
 *	Creation Date:	June 1990
\*****************************************************************************/
#include <assert.h>
#include "hl_main.h"
#include <library/c_basic.h>
#include <library/c_symbol.h>
#include <Hcode/h_prag.h>

#undef OLD_CB_NAME		/* see Mspec */

#define PRINT_MACRO_DEFINE	/* this one is no longer needed */
#define PRINT_RETURN_DEFINE	/* need this for SPARC code generator */

#undef DEBUG_PCODE

#undef TEST_GEN_EXPR
#undef DEBUG_LAYOUT
#undef DEBUG_FLOW


L_Datalist *L_datalist = NULL;
L_Datalist *L_hash_datalist = NULL;

static void find_allocatable(FuncDcl fn);
static void look_for_addr(Expr expr);
static int is_scalar_type(Type type);
static int is_structure(Type type);
static void layout_local();
static void layout_formal(int need_ST);
static void compute_actual_space(FuncDcl fn);
static void compute_actual_space2(Expr expr);
static char *new_hash_table(char *fn);
static char *cb_label_name(char *fn, int cb);


static int HC_num_prefix_backslashes(char *string, char *pos);
static char *HC_find_first_pragma_delimiter(char *string);
static L_Oper *gen_if(L_Cb *cb, Expr expr, Pragma pragma, int reverse_cc, 
		int taken_bb, double taken_weight, double fall_thru_weight);
static void gen_switch(L_Cb *cb, Expr expr, int implement_hash_jump, 
                  char *hash_table_label, int n_cnt, long cnt_cc[],
                  int cnt_dest[], double cnt_weight[], char cnt_is_default[]);
static int gen_return(L_Cb *cb, Expr expr);
static void gen_expr(L_Cb *cb, Expr expr);
static int eval_mtype(int type);
static L_Oper *gen_beq_0(HC_Operand op, int target, int fs);
static L_Oper *gen_bne_0(HC_Operand op, int target, int fs);
static L_Oper *gen_beq(HC_Operand op1, HC_Operand op2, int target, 
		int fs);
static L_Oper *gen_bne(HC_Operand op1, HC_Operand op2, int target, 
		int fs);
static L_Oper *gen_ble(HC_Operand op1, HC_Operand op2, int target,
                int fs, int unsign);
static L_Oper *gen_blt(HC_Operand op1, HC_Operand op2, int target,
                int fs, int unsign);
static L_Oper *gen_bge(HC_Operand op1, HC_Operand op2, int target,
                int fs, int unsign);
static L_Oper *gen_bgt(HC_Operand op1, HC_Operand op2, int target,
                int fs, int unsign);
/* LCW - put local variables and parameters information in function 
 * attribute - 5/20/96 
 */
static void gen_local_info_attribute();
static void gen_local_type_attribute(struct _Type *type);

/*-------------------------------------------------------------------------*/
/*
 *  There is a problem with a function that returns structures (union/struct).
 *  We require the space to be allocated by the caller before function call,
 *  and pass the address through the $R register.
 *	e.g.
 *		(alloc ($R) (size align))
 *		(jsr ....)
 *  After the function call, it is assumed that $R is unchanged, and
 *  points to the return data.
 *	e.g.
 *		(jsr ....)
 *		(mov (r.new) ($R))
 *  Now the data is safe to be operated upon until the next call.
 *  Usually the caller copies the data to a variable immediately.
 *
 *  The callee (that returns structure) should do the following:
 *  	e.g.
 *		(prologue ....)
 *		(mov (r.new) ($R))
 *  So it does not need to worry about $R being clobbered when it does
 *  function calls. If there is no function call in the callee body,
 *  the code optimizer will automatically propagate $R to the return block.
 */
/*
 *  Be careful about the type of variables.
 *  Because we automatically promote function arguments,
 *  when a formal parameter is referred, its "param_mtype"
 *  should be used (!!! not "param->type").
 *  For local variables, they are not promoted. Therefore,
 *  we can used either "local_mtype" or local->type.
 *  For consistency, we will use "mtype" at all times.
 *  For global variables, the usual var->type can be
 *  converted by HC_hcode2lcode_type().
 */
/*-------------------------------------------------------------------------*/
static int bb_tbl = -1;		/* basic block id table */
static int local_tbl = -1;	/* local variable table */
static int param_tbl = -1;	/* formal parameter table */

static int attr_flag = 0;

static Block block[HC_MAX_BB];
static int block_id[HC_MAX_BB];
static int n_block;

#define MAX_VAR ((HC_MAX_LOCAL_VAR>HC_MAX_PARAM_VAR) ? \
	HC_MAX_LOCAL_VAR:HC_MAX_PARAM_VAR)
static _M_Type temp_mtype[MAX_VAR];
static long temp_offset[MAX_VAR];
static int temp_mode[MAX_VAR];
static int temp_reg[MAX_VAR];
static int temp_paddr[MAX_VAR];
static char *temp_base_macro = "???";

/*
 *  Local variable information.
 */
static VarDcl local[HC_MAX_LOCAL_VAR];
static int n_local;
static _M_Type local_mtype[HC_MAX_LOCAL_VAR];
static long local_offset[HC_MAX_LOCAL_VAR];
static char *local_base_macro = "???";
static int local_register_allocatable[HC_MAX_LOCAL_VAR];
static int local_mode[HC_MAX_LOCAL_VAR];
static int local_reg_id[HC_MAX_LOCAL_VAR];
static int local_space;	/* total needed bytes */

/*
 *  Formal parameter information.
 */
static VarDcl param[HC_MAX_PARAM_VAR];
static int n_param;
static _M_Type param_mtype[HC_MAX_PARAM_VAR];
static long param_offset[HC_MAX_PARAM_VAR];
static char *param_base_macro = "???";
static int param_register_allocatable[HC_MAX_PARAM_VAR];
static int param_mode[HC_MAX_PARAM_VAR];
static int param_reg[HC_MAX_PARAM_VAR];
static int param_reg_id[HC_MAX_PARAM_VAR];
static int param_paddr[HC_MAX_PARAM_VAR];
static int param_space;	/* total needed bytes */

/*
 *  Actual parameter space.
 */
static int actual_space;	/* max. needed bytes */

/*
 *  Return value.
 */
static int return_structure;	/* need to return a struct/union */
static int return_addr_reg;	/* the address register of caller space */
static Type return_type;	/* the return type */

/*
 *  Basic block and operation identifiers.
 */
static int next_bb_id;		/* basic block id counter */
static int next_oper_id;	/* operation id counter */
static int prologue_bb_id;	/* prologue block id */
static int epilogue_bb_id;	/* epilogue block id */
static int next_reg_id;		/* virtual register counter */
static int next_cs_id;		/* call site id */

double HC_profile_weight;

/*-------------------------------------------------------------------------*/
int HC_next_oper_id() {
    return next_oper_id++;
}
int HC_next_reg_id() {
    return next_reg_id++;
}
int HC_next_call_site_id() {
    return next_cs_id++;
}
/*-------------------------------------------------------------------------*/
int HC_find_local_var(char *name, M_Type mtype, int *in_reg, int *reg_id, 
			char **base_macro, int *offset)
{
    int n;
    Void *ptr;
    if (C_find(local_tbl, name, 1, &n, &ptr)) {
	if (mtype!=0)
	    *mtype = local_mtype[n];
	if (in_reg!=0)
	    *in_reg = (local_mode[n]==M_THRU_REGISTER);
	if (reg_id!=0)
	    *reg_id = local_reg_id[n];
	if (base_macro!=0)
	    *base_macro = local_base_macro;
	if (offset!=0)
	    *offset = local_offset[n];
	return 1;
    } else {
	return 0;
    } 
}
int HC_find_param_var(char *name, M_Type mtype, int *in_reg, int *reg_id, 
			char **base_macro, int *offset)
{
    int n;
    Void *ptr;
    if (C_find(param_tbl, name, 1, &n, &ptr)) {
	if (mtype!=0)
	    *mtype = param_mtype[n];
	if (reg_id!=0)
	    *reg_id = param_reg_id[n];
	if (base_macro!=0)
	    *base_macro = param_base_macro;
	if (in_reg!=0) {
	    switch (param_mode[n]) {
	    case M_THRU_REGISTER:	
		*in_reg = 1;	
		break;
	    case M_THRU_MEMORY:
	    case M_INDIRECT_THRU_REGISTER:
	    case M_INDIRECT_THRU_MEMORY:
		*in_reg = 0;
		break;
	    default:
		Punt("illegal mode returned by M_fnvar_layout");
	    }
	}
	if (offset!=0) {
	    switch (param_mode[n]) {
	    case M_THRU_REGISTER:	
	    case M_THRU_MEMORY:		
		*offset = param_offset[n];
		break;
	    case M_INDIRECT_THRU_REGISTER:
	    case M_INDIRECT_THRU_MEMORY:
		*offset = param_paddr[n];
		break;
	    default:		
		Punt("illegal mode returned by M_fnvar_layout");
	    }
	}
	return 1;
    } else {
	return 0;
    }
}
/*-------------------------------------------------------------------------*/
static void find_allocatable(FuncDcl fn)
{
    int i;
    Block bb;
    /*
     *	first assume everything is register allocatable.
     *	except can not allocate a structure to a register.
     *	1. union, 2. struct, 3. array, 4. function
     */
    for (i=0; i<n_local; i++) {
	local_register_allocatable[i] = is_scalar_type(local[i]->type);
    }
    for (i=0; i<n_param; i++) {
	param_register_allocatable[i] = is_scalar_type(param[i]->type);
    }
    /*
     *	delete those that are pointer accessable.
     */
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	Expr expr;
	for (expr=bb->first; expr!=0; expr=expr->next) {
	    look_for_addr(expr);
	}
    }
}
static void look_for_addr(Expr expr)
{
    int i;
    Expr op;
    if (expr==0) return;
    for (i=1; (op=GetOperand(expr, i))!=0; i++) {
	look_for_addr(op);
    }
    if (expr->opcode==OP_addr) {
	op = GetOperand(expr, 1);
	if (op->opcode==OP_var) {
	    char *var_name;
	    Void *ptr;
	    int n;
	    var_name = op->value.var_name;
	    if (C_find(local_tbl, var_name, 1, &n, &ptr)) {
		local_register_allocatable[n] = 0;
	    } 
	    if (C_find(param_tbl, var_name, 1, &n, &ptr)) {
		param_register_allocatable[n] = 0;
	    }
	}
    }
}
static int is_scalar_type(Type type)
{
    int t = type->type;
    Dcltr dcltr = type->dcltr;
    int method;
    /* do not move volatile objects to register */
    if (t & TY_VOLATILE)	
	return 0;
    if (dcltr!=0) {	/* only pointer is allowed */
	method = dcltr->method;
	return ((method!=D_ARRY) & (method!=D_FUNC));
    } else {
	return ((t&(TY_UNION|TY_STRUCT)) == 0);
    }
}
static int is_structure(Type type)
{
    int t = type->type;
    return ((type->dcltr==0) & ((t&(TY_UNION|TY_STRUCT))!=0));
}
/*-------------------------------------------------------------------------*/
/*
 *	do not allocate space to those that are register
 *	allocatable. the space will be automatically
 *	allocated if spilling occurs.
 */
static void layout_local() {
    int i, num;
    num = 0;
    for (i=0; i<n_local; i++) {
	if (! local_register_allocatable[i]) {
	    temp_mtype[num] = local_mtype[i];
	    num++;
	} 
    }
    local_space =
	M_lvar_layout(num, temp_mtype, temp_offset, &local_base_macro);
    for (i=0; i<num; i++) {
	temp_offset[i] /= H_CHAR_SIZE;		/* convert to byte */
    }
    local_space /= H_CHAR_SIZE;
    num = 0;
    for (i=0; i<n_local; i++) {
	if (local_register_allocatable[i]) {
	    local_reg_id[i] = next_reg_id++;
	    local_mode[i] = M_THRU_REGISTER;
	    local_offset[i] = -1;
	} else {
	    local_reg_id[i] = -1;
	    local_mode[i] = M_THRU_MEMORY;
	    local_offset[i] = temp_offset[num];
	    num++;
	}
    }
}
/*
 *	the allocation decision is not done here, because
 *	the caller has no idea what's pointer accessable
 *	or not. so we will let the caller make the decision,
 *	and make necessary repair.
 */
static void layout_formal(int need_ST)
{
    int i;
    for (i=0; i<n_param; i++) {
	param_reg_id[i] = -1;
    }

    /* Initialize arrays to known values to prevent random numbers
     * from being put into new attributes -ITI/JCG 3/99
     */
    for (i=0; i<n_param; i++) {
	param_offset[i] = 0;
	param_paddr[i] = 0;
    }    

    /*
     *	Prepare for recieving incoming parameters.
     */
    param_space =
    	M_fnvar_layout(n_param, param_mtype, param_offset, 
		param_mode, param_reg, param_paddr,
	 	&param_base_macro, need_ST, M_GET_FNVAR);
    for (i=0; i<n_param; i++) {
	param_offset[i] /= H_CHAR_SIZE;		/* convert to byte */
	param_paddr[i] /= H_CHAR_SIZE;		/* convert to byte */
    }
    param_space /= H_CHAR_SIZE;
}
/*-------------------------------------------------------------------------*/
static void compute_actual_space(FuncDcl fn)
{
    Block bb;
    Expr expr;
    int size;
    actual_space = 0;

    /*
     *	for Sparc code generator, even if the function does not
     *	make function call, we still need to allocate some
     *	minimum parameter region (for OS registers saves)
     */
    size = M_fnvar_layout(0, temp_mtype, temp_offset, 
		temp_mode, temp_reg, temp_paddr,
		&temp_base_macro, 0, M_PUT_FNVAR);
    size /= H_CHAR_SIZE;
    if (size > actual_space) actual_space = size;


    if (is_structure(fn->type)) {
    /* If a structure is returned by this function, account for the parameter
     * size needed by the internal block copy routine, IMPACT_block_mov. */
        _M_Type type[4];
        M_int(type+0, 1);
        M_int(type+1, 1);
        M_int(type+2, 0);
        M_int(type+3, 0);

        size = M_fnvar_layout(4, type, temp_offset, temp_mode, temp_reg,
                              temp_paddr, &temp_base_macro, 0, M_PUT_FNVAR);
        size /= H_CHAR_SIZE;
        if (size > actual_space) actual_space = size;
    }

    /*
     *	check for actual calls.
     */
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	for (expr=bb->first; expr!=0; expr=expr->next) {
	    compute_actual_space2(expr);
	}
    }
}
static void compute_actual_space2(Expr expr)
{
    int i, num, size, need_ST;
    Expr op;
    if (expr==0) return;
    for (i=1; (op=GetOperand(expr,i))!=0; i++) {
	compute_actual_space2(op);
    }
    if (expr->opcode==OP_call) {
	num = 0;
	for (i=2; (op=GetOperand(expr,i))!=0; i++) {
	    _M_Type mtype;
	    HC_hcode2lcode_type(op->type, &mtype);
	    if (L_propagate_sign_size_ctype_info)
	      M_call_type2(&mtype, temp_mtype+num);
	    else
	      M_call_type(&mtype, temp_mtype+num);
	    num++;
	}
	need_ST = is_structure(expr->type);
	size = M_fnvar_layout(num, temp_mtype, temp_offset, 
		temp_mode, temp_reg, temp_paddr,
		&temp_base_macro, need_ST, M_PUT_FNVAR);
	size /= H_CHAR_SIZE;
	if (size > actual_space)
	    actual_space = size;
    }
}

/*-------------------------------------------------------------------------*/
/* LCW - put local variables and parameters information in function 
 * attribute - 5/20/96 */
static void gen_local_info_attribute()
{
  int i;
  char str_buffer[256];
  L_Attr *new_attr;

  for (i = 0; i < n_local; i++) {
      /* generate variable name */
      new_attr = L_new_attr("LVAR_NAME", 1);
      sprintf(str_buffer, "\"%s\"", local[i]->name);
      L_set_string_attr_field(new_attr, 0, str_buffer);
      L_fn->attr=L_concat_attr(L_fn->attr, new_attr);

      /* generate type infomation */
      gen_local_type_attribute(local[i]->type);

      /* generate actual location */
      new_attr = L_new_attr("LVAR_LOC", 2);
      if (local_mode[i] == M_THRU_REGISTER) {
	 L_set_string_attr_field(new_attr, 0, "\"r\"");
	 L_set_int_attr_field(new_attr, 1, local_reg_id[i]);
      }
      else { /* M_THRU_MEMORY */
	 L_set_string_attr_field(new_attr, 0, "\"m\"");
	 L_set_int_attr_field(new_attr, 1, local_offset[i]);
      }
      L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }

  for (i = 0; i < n_param; i++) {
      /* generate parameter name */
      new_attr = L_new_attr("LVAR_NAME", 1);
      sprintf(str_buffer, "\"%s\"", param[i]->name);
      L_set_string_attr_field(new_attr, 0, str_buffer);
      L_fn->attr=L_concat_attr(L_fn->attr, new_attr);

      /* generate type infomation */
      gen_local_type_attribute(param[i]->type);

      /* generate actual location */
      new_attr = L_new_attr("LVAR_LOC", 2);
      L_set_string_attr_field(new_attr, 0, "\"m\"");
      L_set_int_attr_field(new_attr, 1, param_offset[i]);
      L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
}

/* LCW - generate function attribute for local variable type - 5/20/96 */
static void gen_local_type_attribute(struct _Type *type)
{
  char st_name[256];
  int t;
  L_Attr *new_attr;
  struct _Dcltr *dclptr;

  t = type->type;
  if (t & TY_REGISTER) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"register\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_STATIC) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"static\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_EXTERN) { /* put error message here? */
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"extern\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_AUTO) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"auto\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_GLOBAL) { /* put error message here? */
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"global\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_PARAMETER) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"parameter\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_CONST) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"const\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_VOLATILE) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"volatile\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_NOALIAS) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"noalias\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_SIGNED) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"signed\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_UNSIGNED) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"unsigned\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_VOID) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"void\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_SHORT) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"short\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_LONG) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"long\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_CHAR) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"char\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_INT) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"int\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_FLOAT) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"float\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_DOUBLE) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"double\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_STRUCT) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     sprintf(st_name, "\"struct %s\"", type->struct_name);
     L_set_string_attr_field(new_attr, 0, st_name);
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_UNION) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     sprintf(st_name, "\"union %s\"", type->struct_name);
     L_set_string_attr_field(new_attr, 0, st_name);
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_ENUM) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     sprintf(st_name, "\"enum %s\"", type->struct_name);
     L_set_string_attr_field(new_attr, 0, st_name);
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  if (t & TY_VARARG) {
     new_attr = L_new_attr("LVAR_TYPE", 1);
     L_set_string_attr_field(new_attr, 0, "\"vararg\"");
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
  }
  dclptr = type->dcltr;
  while (dclptr) {
     new_attr = L_new_attr("LVAR_DCLTR", 1);
     switch (dclptr->method) {
     case D_ARRY:
       L_set_string_attr_field(new_attr, 0, "\"a\"");
       break;
     case D_PTR:
       L_set_string_attr_field(new_attr, 0, "\"p\"");
       break;
     case D_FUNC:
       L_set_string_attr_field(new_attr, 0, "\"f\"");
       break;
     default:
       Punt("gen_local_type_attribute: illegal declarator (access pattern)");
     }
     L_fn->attr=L_concat_attr(L_fn->attr, new_attr);
     dclptr = dclptr->next;
  }
}	 

 
/*-------------------------------------------------------------------------*/
int HC_bb_id(Block bb)
{
    int id;
    Void *ptr;
    C_find(bb_tbl, "BB", bb->id, &id, &ptr);
    return id;
}

/*-------------------------------------------------------------------------*/
/* SAM 8-96, modified to be Mspec driven */
static int next_hash_tbl_id = 0;
static char *new_hash_table(char *fn)
{
    char line[1024], name[1024];

    sprintf(name, "_%s", fn);	/* prefix with _ */
    M_jumptbl_label_name(name, next_hash_tbl_id, line, 1024);
    next_hash_tbl_id++;

    return C_findstr(line);
}

static char *cb_label_name(char *fn, int cb)
{
    char name[512], line[512];
#ifdef OLD_CB_NAME
    sprintf(line, "cb%d_%s", cb, fn);
#else
    sprintf(name, "_%s", fn);	/* prefix with _ */
    M_cb_label_name(name, cb, line, 512);
#endif
    return C_findstr(line);
}

/*-------------------------------------------------------------------------*/
/*
 *	Convert string to upper case, convert -'s to _'s
 */
void HL_convert_to_upper(char *str)
{
    int i, len;

    len = strlen(str);
    for (i=0; i<len; i++) {
	if (str[i]=='-')
	    str[i] = '_';
	else
	    str[i] = toupper(str[i]);
    }
}

/*
 *	1. need to put a prologue immediately after the function header.
 *	2. need to put an epilogue immediately after the most important
 *		rts block.
 */
void HC_gen_func(FuncDcl fn)
{
    /*** control flow information (for 1 basic block) ***/
    Block cnt_dest[HC_MAX_FLOW];
    int cnt_dest_id[HC_MAX_FLOW];
    long cnt_cc[HC_MAX_FLOW];
    char cnt_switch_default[HC_MAX_FLOW];
    double cnt_weight[HC_MAX_FLOW];
    int n_cnt;
    /*** switch generation ***/
    Block default_bb;
    int default_bb_id;
    int block_hash_jump[HC_MAX_BB];
    char *block_hash_table[HC_MAX_BB];
    int hash_jump;
    /*** about return point and return value ***/
    Block best_rts_bb;
    /*** temporary variables ***/
    VarList var;
    Block bb, entry_bb;
    double weight;
    int i, ctype;
    char arch_name[100];
    char model_name[100];
    char temp_name[5000], *temp_ptr;
    L_Data *new_data;
    L_Expr *new_expr;
    L_Cb *prologue_cb, *first_cb, *new_cb, *dest_cb, *epilogue_cb;
    L_Oper *new_oper, *return_oper = NULL;
    L_Attr *new_attr;
    L_Attr *tr_attr = NULL;
    L_Attr *tro_attr = NULL;
    L_Attr *tm_attr = NULL;
    L_Attr *tmo_attr = NULL;
    L_Attr *tmso_attr = NULL;
    int tr_count = 0;
    int tmo_count = 0;
    Expr expr=NULL;
    char *attr_name;
    char *loop_type;
    int return_generated, need_return_register = 0;
    int return_register_created = 0;
    int old_style_param;	/* BCC - 8/23/96 */

    int tmcount = L_TM_START_VALUE;

    /*
     *	Set output stream.
     */
    /*
     *	Clear all information from the previous function.
     */
    if (bb_tbl==-1) {
	bb_tbl = C_open(HC_MAX_BB+1, C_MATCH_BY_EXACT_TYPE);
	if (bb_tbl==-1)
	    Punt("HC_gen_func: cannot open symbol table");
    } else {
	C_clear(bb_tbl);
    }
    if (local_tbl==-1) {
	local_tbl = C_open(HC_MAX_LOCAL_VAR*2+1, C_MATCH_BY_EXACT_TYPE);
	if (local_tbl==-1)
	    Punt("HC_gen_func: cannot open symbol table");
    } else {
	C_clear(local_tbl);
    }
    if (param_tbl==-1) {
	param_tbl = C_open(HC_MAX_PARAM_VAR*2+1, C_MATCH_BY_EXACT_TYPE);
	if (param_tbl==-1)
	    Punt("HC_gen_func: cannot open symbol table");
    } else {
	C_clear(param_tbl);
    }
    n_block = 0;
    n_local = 0;
    n_param = 0;
    next_bb_id = 1;	/* reserve 0 for special purpose */
    next_oper_id = 1;	/* reserve 0 for special purpose */
    next_reg_id = 1;
    next_cs_id = 1;
    next_hash_tbl_id = 0;	/* SAM 8-96 */
    /*
     *	Generate global (static) variables hidden in the function.
     */
    for (var=fn->local; var!=0; var=var->next) {
	Type type = var->var->type;
	if (type->type & TY_STATIC)
	    HC_gen_var(L_datalist, var->var);
    }
    /*
     *	Generate function header.
     */

    HC_invalidate_last_ms();
    HC_ms(L_datalist, "text");

    return_type = fn->type;
    if (! (return_type->type & TY_STATIC)) {

        new_data = L_new_data(L_INPUT_GLOBAL);
        new_data->address = L_new_expr(L_EXPR_LABEL);
	sprintf(&temp_name[0], "_%s", fn->name);
	temp_ptr = C_findstr(temp_name);
	new_data->address->value.l = temp_ptr;
	/* LCW - insert L_Type in L_Data structure - 4/25/96 */
	if (HL_emit_source_info)
	   new_data->h_type = L_gen_type(return_type);
        L_concat_datalist_element (L_datalist, 
				L_new_datalist_element(new_data));
    }

        /* have to add the stupid underscore by hand */
    sprintf(&temp_name[0], "_%s", fn->name);
    L_fn = L_new_func(temp_name, fn->profile.weight);

#if 0  /* REH - removed as unnecessary, 11/7/94 */
    sprintf (&arch_name[0],"ARCH:%s",H_arch);
    sprintf (&model_name[0],"MODEL:%s",H_model);
    HL_convert_to_upper(&arch_name[0]);
    HL_convert_to_upper(&model_name[0]);

    new_attr = L_new_attr(arch_name, 0);
    L_fn->attr = L_concat_attr(L_fn->attr, new_attr);

    new_attr = L_new_attr(model_name, 0);
    L_fn->attr = L_concat_attr(L_fn->attr, new_attr);
#endif 

    /* GEH - added conversion of function pragmas to function attributes */

    L_fn->attr = L_concat_attr(L_fn->attr, HC_gen_attr_from_pragma(fn->pragma));

    prologue_bb_id = next_bb_id++;
    /*
     *	Gather information about the function.
     */
    entry_bb = 0;
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	block[n_block] = bb;
	block_id[n_block] = next_bb_id++;
	C_update(bb_tbl, "BB", bb->id, block_id[n_block], bb);
	n_block += 1;
	if (n_block>=HC_MAX_BB)
	    Punt("HC_gen_func: too many basic blocks in function");
	if (fn->entry_bb==bb->id)
	    entry_bb = bb;
    }
    epilogue_bb_id = next_bb_id++;
    if (entry_bb!=fn->blocks) {
	Punt("HC_gen_func: entry block must be the first block");
    }
    /*** determine the best rts: where we will append rts ***/
    best_rts_bb = 0;
    for (bb=fn->blocks; bb!=0; bb=bb->next) {
	if (bb->cnt_type==CNT_RETURN) {
	    if (best_rts_bb==0) {
		best_rts_bb = bb;
	    } else 
	    if (bb->profile.weight > best_rts_bb->profile.weight) {
		best_rts_bb = bb;
	    }
	}
    }
    if (best_rts_bb==0) {
	fprintf(stderr, "function %s may not terminate\n", fn->name);
	/*
	 *  It is possible that a function has no return point.
	 *  All (rts) blocks have been removed by dead code.
	 *  (see main() in ditroff)
  	 *  The user uses exit() to end the program.
	 *  : simply put rts at the end of function.
	 */
    }
    for (var=fn->local; var!=0; var=var->next) {
	VarDcl v = var->var;
	Type type = v->type;
	if (! (type->type & (TY_STATIC|TY_EXTERN))) {
	    local[n_local] = v;
	    HC_hcode2lcode_type(local[n_local]->type, local_mtype+n_local);
	    C_update(local_tbl, local[n_local]->name, 1, n_local,local+n_local);
	    n_local++;
	    if (n_local>=HC_MAX_LOCAL_VAR)
	    	Punt("HC_gen_func: too many local variables in function");
	}
    }
    old_style_param = FindFunctionPragma(fn, "\"old_style_param\"") ? 1 : 0;
    for (var=fn->param; var!=0; var=var->next) {
	_M_Type mtype;
	param[n_param] = var->var;
	HC_hcode2lcode_type(param[n_param]->type, &mtype);
	if (L_propagate_sign_size_ctype_info)
	  M_call_type2(&mtype, param_mtype+n_param);
	else
	  M_call_type(&mtype, param_mtype+n_param);
	/* 
	 * BCC - 8/23/96
	 * for functions using old-style parameters, floats are still passed 
	 * via doubles
	 */
	if (old_style_param && mtype.type == M_TYPE_FLOAT) 
	  M_double(param_mtype+n_param, (param_mtype+n_param)->unsign);
	C_update(param_tbl, param[n_param]->name, 1, n_param, param+n_param);
	n_param++;
/* 
 * BCC - 1/29/96
 *	 commented out because we need to know the accumulated parameter size
 *	 in order to handle "...". This part of code is executed after calling
 *	 layout_formal();
 */
#if 0
        if (strstr (var->name, "va_alist") != NULL) 
	    new_attr = L_new_attr("VARARG", 1);
	    /* BCC - change the last parameter to param_pffset[n_param-1] 
	    L_set_int_attr_field(new_attr, 0, n_param);	- 1/29/96 */
	    L_set_int_attr_field(new_attr, 0, param_offset[n_param-1]);	
	    printf("offset = %d\n", param_offset[n_param-1]);
            L_fn->attr=L_concat_attr(L_fn->attr,new_attr);
	}
#endif
	if (n_param>=HC_MAX_PARAM_VAR)
	    Punt("HC_gen_func: too many parameters in function");
    }
    /*
     *	Determine which local variables can be safely allocated
     *	to registers.
     */
    find_allocatable(fn);
    /*
     *	Decide how to layout the local variables and formal parameters.
     */
    layout_local();
    layout_formal(is_structure(return_type));

    /* BCC - added to subtract the correct offset for "..." - 1/29/96 */
    for (var=fn->param, i=0; i < n_param; var=var->next, i++) {
	/* BCC - "..." is also a vararg parameter - 1/29/96 */
        if (strstr (var->name, "va_alist") != NULL) {
	    new_attr = L_new_attr("VARARG", 1);
	    L_set_int_attr_field(new_attr, 0, 0);	
            L_fn->attr=L_concat_attr(L_fn->attr,new_attr);
	}
	else if (strcmp(var->name, "...") == NULL ) {
	    if (i == 0) Punt("\"...\" can not be the first parameter");
	    new_attr = L_new_attr("VARARG", 1);
    /* BCC - bug fix for sending param_offset[i] instead of [i-1] - 2/7/96 */
	    L_set_int_attr_field(new_attr, 0, param_offset[i]);	
            L_fn->attr=L_concat_attr(L_fn->attr,new_attr);
	}
    }

    /*
     *	Find maximum space that we need for pushing actual parameters.
     */
    compute_actual_space(fn);

    /*
     * LCW - put local variables and parameters information in function
     * attribute - 5/20/96
     */
    if (HL_emit_source_info)
       gen_local_info_attribute();

    /*
     *	Generate function prologue.
     */

    prologue_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
						prologue_bb_id);
    L_insert_cb_after(L_fn,L_fn->last_cb,prologue_cb);
    first_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
						block_id[0]);
    prologue_cb->weight = fn->profile.weight;
    prologue_cb->dest_flow = L_new_flow(0,prologue_cb, first_cb,
			fn->profile.weight);

    /*
     *	Print parameter types.
     */
#ifdef PRINT_MACRO_DEFINE
    for (i=0; i<n_param; i++) {
	_M_Type mtype;

	switch (param_mode[i]) {
	case M_THRU_REGISTER:
	  if (L_propagate_sign_size_ctype_info) {
	    switch(param_mtype[i].type) {
	    case M_TYPE_FLOAT : 
	      ctype = L_CTYPE_FLOAT;
	      break;
	    case M_TYPE_DOUBLE :
	      ctype = L_CTYPE_DOUBLE;
	      break;
	    case M_TYPE_CHAR :
	      if (param_mtype[i].unsign)
		ctype = L_CTYPE_UCHAR;
	      else
		ctype = L_CTYPE_CHAR;
	      break;
	    case M_TYPE_SHORT :
	      if (param_mtype[i].unsign)
		ctype = L_CTYPE_USHORT;
	      else
		ctype = L_CTYPE_SHORT;
	      break;
	    case M_TYPE_INT :
	      if (param_mtype[i].unsign)
		ctype = L_CTYPE_UINT;
	      else
		ctype = L_CTYPE_INT;
	      break;
	    case M_TYPE_LONG :
	      if (param_mtype[i].unsign)
		ctype = L_CTYPE_ULONG;
	      else
		ctype = L_CTYPE_LONG;
	      break;
	    case M_TYPE_POINTER :
	      ctype = L_CTYPE_POINTER;
	      break;
	    default :
	      L_warn("HC_gen_func : unknown M_TYPE %d", param_mtype[i].type);
	      break;
	    }
	  }
	  else {
	    if (param_mtype[i].type == M_TYPE_FLOAT)
	      ctype = L_CTYPE_FLOAT;
	    else if (param_mtype[i].type == M_TYPE_DOUBLE)
	      ctype = L_CTYPE_DOUBLE;
	    else 
	      ctype = L_CTYPE_INT;
	  }
	  new_oper = L_create_new_op(Lop_DEFINE);
	  new_oper->dest[0] = L_new_macro_operand((L_MAC_P0+param_reg[i]), 
						  ctype, L_PTYPE_NULL);
	  L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);
	  /* Add explicit attribute to function to specify where
	   * thru-register parameters are expected.  Simplifies Lemulate's
	   * job of emulating this code. -ITI/JCG 3/99
	   * 
	   * Added memory offset for cases where parameter thru-register
	   * must be written back to memory (so can get address). -ITI/JCG 3/99
	   *
	   */
	  if (tr_attr == NULL)
	  {
	      tr_attr = L_new_attr("tr", 0);
	      L_fn->attr=L_concat_attr(L_fn->attr, tr_attr);
	      tro_attr = L_new_attr("tro", 0);
	      L_fn->attr=L_concat_attr(L_fn->attr, tro_attr);
	  }
	  L_set_macro_attr_field(tr_attr, tr_count, (L_MAC_P0+param_reg[i]), 
				 ctype, L_PTYPE_NULL);
	  L_set_int_attr_field(tro_attr, tr_count, param_offset[i]);

	  tr_count++;
	  break;
	  
	  
	case M_INDIRECT_THRU_REGISTER:
 	    /* I believe this case is used only for passing copies
	     * of structures to the function.  The address of the space
	     * the structure is passing in the register but then the
	     * structure is actually put on the stack after all the
	     * parameters (which is how it is accessed by Lcode).  The 
	     * thru-register part (which has the address) doesn't 
	     * seem to be actually used by Lcode, but is very useful 
	     * for Lemulate to find the copy of the structure. -ITI/JCG 3/99
             */
	    new_oper = L_create_new_op(Lop_DEFINE);
	    new_oper->dest[0] = L_new_macro_operand((L_MAC_P0+param_reg[i]), 
						L_CTYPE_INT, L_PTYPE_NULL);
	    L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);

	    /* Add explicit attribute to function to specify where
	     * indirect thru-register parameters are expected.  
	     * Simplifies Lemulate's job of emulating this code. -ITI/JCG 3/99
	     * 
	     * Added tro attribute update for consistency, but I am
	     * not sure if it is truely needed here (but better
	     * safe then sorry). -ITI/JCG 3/99
	     */
	    if (tr_attr == NULL)
	    {
		 tr_attr = L_new_attr("tr", 0);
		 L_fn->attr=L_concat_attr(L_fn->attr, tr_attr);
		 tro_attr = L_new_attr("tro", 0);
		 L_fn->attr=L_concat_attr(L_fn->attr, tro_attr);
	    }
	    L_set_macro_attr_field(tr_attr, tr_count, (L_MAC_P0+param_reg[i]), 
				   L_CTYPE_INT, L_PTYPE_NULL);
	    L_set_int_attr_field(tro_attr, tr_count, param_offset[i]);

	    /* Add explicit attribute to function to specify where
	     * the copy of the structure is place on the stack 
	     * (relative to the IP macro). -ITI/JCG 3/99 
	     */
	    if (tmso_attr == NULL)
	    {
		 tmso_attr = L_new_attr("tmso", 0);
		 L_fn->attr=L_concat_attr(L_fn->attr, tmso_attr);
	    }
	    L_set_int_attr_field(tmso_attr, i, param_paddr[i]);

	    tr_count++;
	    break;

	case M_THRU_MEMORY:
	    HC_hcode2lcode_type(param[i]->type, &mtype);
	    if (L_propagate_sign_size_ctype_info) {
	      switch (mtype.type) {
	      case M_TYPE_FLOAT :
		ctype = L_CTYPE_FLOAT;
		break;
	      case M_TYPE_DOUBLE :
		ctype = L_CTYPE_DOUBLE;
		break;
	      case M_TYPE_CHAR :
		if (mtype.unsign)
		  ctype = L_CTYPE_UCHAR;
		else
		  ctype = L_CTYPE_CHAR;
		break;
	      case M_TYPE_SHORT :
		if (mtype.unsign)
		  ctype = L_CTYPE_USHORT;
		else
		  ctype = L_CTYPE_SHORT;
		break;
	      case M_TYPE_INT :
		if (mtype.unsign)
		  ctype = L_CTYPE_UINT;
		else
		  ctype = L_CTYPE_INT;
		break;
	      case M_TYPE_LONG :
		if (mtype.unsign)
		  ctype = L_CTYPE_ULONG;
		else
		  ctype = L_CTYPE_LONG;
		break;
	      case M_TYPE_POINTER :
		ctype = L_CTYPE_POINTER;
		break;
	      default :
		L_warn("HC_gen_func : unknown M_TYPE %d", mtype.type);
		break;
	      }
	    }
	    else {
	      if (mtype.type == M_TYPE_FLOAT)
		ctype = L_CTYPE_FLOAT;
	      else if (mtype.type == M_TYPE_DOUBLE)
		ctype = L_CTYPE_DOUBLE;
	      else
		ctype = L_CTYPE_INT;
	    }
	    new_oper = L_create_new_op(Lop_DEFINE);
	    new_oper->src[0] = L_new_macro_operand(L_MAC_IP, 
						   L_CTYPE_INT, L_PTYPE_NULL);
	    new_oper->src[1] = L_new_gen_int_operand(param_offset[i]);
	    new_oper->dest[0] = L_new_macro_operand(L_MAC_TM_TYPE, 
					ctype, L_PTYPE_NULL);
	    new_oper->attr = L_new_attr("tm",1);
	    L_set_int_attr_field(new_oper->attr,0,tmcount);
	    L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);

	    /* Add explicit attribute to function to specify where
	     * thru-memory parameters are expected.  Simplifies Lemulate's
	     * job of emulating this code. -ITI/JCG 3/99
	     */
	    if (tmo_attr == NULL)
	    {
		 tm_attr = L_new_attr("tm", 0);
		 L_fn->attr=L_concat_attr(L_fn->attr, tm_attr);
		 tmo_attr = L_new_attr("tmo", 0);
		 L_fn->attr=L_concat_attr(L_fn->attr, tmo_attr);
	    }
	    /* Use tmo_count as index, since tm_count has base 
	     * offset (of 300) added in.
	     */
	    L_set_int_attr_field(tm_attr, tmo_count, tmcount);
	    L_set_int_attr_field(tmo_attr, tmo_count, param_offset[i]);
	    tmcount++;
	    tmo_count++;
	    break;

	    /* Added, since just dropped on the floor before -ITI/JCG 3/99 */
	case M_INDIRECT_THRU_MEMORY:
 	    /* This case is used only for passing copies of structures to 
	     * the function.  The address of the space the structure is 
	     * passing in thru memory where a pointer parameter would be
	     * placed but then the structure is actually put on the stack 
	     * after all the parameters (which is how it is accessed by 
	     * Lcode).  The thru-memory part (which has the address) 
	     * doesn't seem to be actually used by Lcode, but is very 
	     * useful for Lemulate to find the copy of the
	     * structure. -ITI/JCG 3/99
             */
	    new_oper = L_create_new_op(Lop_DEFINE);
	    new_oper->src[0] = L_new_macro_operand(L_MAC_IP, 
						   L_CTYPE_INT, L_PTYPE_NULL);
	    new_oper->src[1] = L_new_gen_int_operand(param_offset[i]);
	    new_oper->dest[0] = L_new_macro_operand(L_MAC_TM_TYPE, 
					L_CTYPE_INT, L_PTYPE_NULL);
	    new_oper->attr = L_new_attr("tm",1);
	    L_set_int_attr_field(new_oper->attr,0,tmcount);
	    L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);

	    /* Add explicit attribute to function to specify where
	     * thru-memory parameters are expected.  Simplifies Lemulate's
	     * job of emulating this code. -ITI/JCG 3/99
	     */
	    if (tmo_attr == NULL)
	    {
		 tm_attr = L_new_attr("tm", 0);
		 L_fn->attr=L_concat_attr(L_fn->attr, tm_attr);
		 tmo_attr = L_new_attr("tmo", 0);
		 L_fn->attr=L_concat_attr(L_fn->attr, tmo_attr);
	    }
	    /* Add explicit attribute to function to specify where
	     * the copy of the structure is place on the stack 
	     * (relative to the IP macro). -ITI/JCG 3/99 
	     */
	    if (tmso_attr == NULL)
	    {
		 tmso_attr = L_new_attr("tmso", 0);
		 L_fn->attr=L_concat_attr(L_fn->attr, tmso_attr);
	    }
	    L_set_int_attr_field(tmso_attr, i, param_paddr[i]);

	    /* Use tmo_count as index, since tm_count has base 
	     * offset (of 300) added in.
	     */
	    L_set_int_attr_field(tm_attr, tmo_count, tmcount);
	    L_set_int_attr_field(tmo_attr, tmo_count, param_offset[i]);
	    tmcount++;
	    tmo_count++;
	    break;

	    
	default:
	    break;
	}
    }
    if ( is_structure(return_type) )  {
	new_oper = L_create_new_op(Lop_DEFINE);
	new_oper->dest[0] = 
        /* SAM 4-95 used to be 
		L_new_macro_operand((L_MAC_P0+M_return_register(return_type,  */
		L_new_macro_operand((L_MAC_P0+M_return_register(M_TYPE_STRUCT,
			M_PUT_FNVAR)), L_CTYPE_INT, L_PTYPE_NULL);
	L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);
    }
#endif
    /*
     *	Print return types.
     */
#ifdef PRINT_RETURN_DEFINE
    if (is_structure(return_type)) {
	new_oper = L_create_new_op(Lop_DEFINE);
	new_oper->dest[0] = L_new_macro_operand(L_MAC_RET_TYPE,
						L_CTYPE_INT, L_PTYPE_NULL);
	L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);

    } else {
	_M_Type mtype;
	HC_hcode2lcode_type(return_type, &mtype);
	if (L_propagate_sign_size_ctype_info) {
	  switch (mtype.type) {
	  case M_TYPE_VOID :
	    ctype = 0;
	    break;
	  case M_TYPE_FLOAT :
	      ctype = L_CTYPE_FLOAT;
	      break;
	  case M_TYPE_DOUBLE :
	      ctype = L_CTYPE_DOUBLE;
	      break;
	  case M_TYPE_CHAR :
	      if (mtype.unsign)
		ctype = L_CTYPE_UCHAR;
	      else
		ctype = L_CTYPE_CHAR;
	      break;
	  case M_TYPE_SHORT :
	      if (mtype.unsign)
		ctype = L_CTYPE_USHORT;
	      else
		ctype = L_CTYPE_SHORT;
	      break;
	  case M_TYPE_INT :
	      if (mtype.unsign)
		ctype = L_CTYPE_UINT;
	      else
		ctype = L_CTYPE_INT;
	      break;
	  case M_TYPE_LONG :
	      if (mtype.unsign)
		ctype = L_CTYPE_ULONG;
	      else
		ctype = L_CTYPE_LONG;
	      break;
	  case M_TYPE_POINTER :
	      ctype = L_CTYPE_POINTER;
	      break;
	  default :
	      L_warn("HC_gen_func : unknown M_TYPE %d", mtype.type);
	      break;
	  }
	}
	else {
	  switch (mtype.type) {
	  case M_TYPE_VOID:
	    ctype = 0;
	    break;
	  default:
	    if (mtype.type == M_TYPE_FLOAT)
	      ctype = L_CTYPE_FLOAT;
	    else if (mtype.type == M_TYPE_DOUBLE)
	      ctype = L_CTYPE_DOUBLE;
	    else
	      ctype = L_CTYPE_INT;
	    break;
	  }
	}

	if (ctype) {
	  new_oper = L_create_new_op(Lop_DEFINE);
	  new_oper->dest[0] = L_new_macro_operand(L_MAC_RET_TYPE, 
						  ctype, L_PTYPE_NULL);
	  L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);
	}
    }
#endif
    /*
     *	Print define statements.
     */
    new_oper = L_create_new_op(Lop_DEFINE);
    new_oper->dest[0] = L_new_macro_operand(L_MAC_LOCAL_SIZE,
						L_CTYPE_INT, L_PTYPE_NULL);
    new_oper->src[0] = L_new_gen_int_operand (local_space);
    L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);

    new_oper = L_create_new_op(Lop_DEFINE);
    new_oper->dest[0] = L_new_macro_operand(L_MAC_PARAM_SIZE,
						L_CTYPE_INT, L_PTYPE_NULL);
    new_oper->src[0] = L_new_gen_int_operand (actual_space);
    L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);

    new_oper = L_create_new_op(Lop_PROLOGUE);
    L_insert_oper_after(prologue_cb,prologue_cb->last_op,new_oper);

    
     tmcount = L_TM_START_VALUE;
    /*
     *	Fix parameters.
     */
    for (i=0; i<n_param; i++) {
	L_Attr *new_attr;
	_HC_Operand dest, src1, src2, src3;
	if (param_register_allocatable[i]) {
	    param_reg_id[i] = next_reg_id++;
	    switch (param_mode[i]) {
	    case M_THRU_REGISTER: {
		/*** r <- $Rreg ***/
		_M_Type mtype;
		char line[64];
		HC_hcode2lcode_type(param[i]->type, &mtype);
		HC_new_register(&dest, param_reg_id[i], mtype.type, mtype.unsign);
		sprintf(line, "$P%d", param_reg[i]);
		HC_new_macro(&src1, line, param_mtype[i].type, param_mtype[i].unsign);
		HC_gen_mov(prologue_cb,&dest, &src1, 0);
		/*
		 *  type may have been changed.
		 */
		if (! M_compatible_type(param_mtype+i, &mtype)) {
		    param_mtype[i] = mtype;
		}
		break;
	    }
	    case M_THRU_MEMORY: {
		/*** r <- mem[param_base_macro + offset] ***/
		_M_Type mtype;
		/*
		 *  load into a register.
		 */
		HC_new_register(&dest, param_reg_id[i], param_mtype[i].type, param_mtype[i].unsign);
		HC_new_macro(&src1, param_base_macro, M_TYPE_POINTER, 0);
		HC_new_int(&src2, param_offset[i], 0);

		new_attr = L_new_attr("tm",1);
		L_set_int_attr_field(new_attr,0,tmcount++);
		HC_gen_load(prologue_cb, expr, &dest,&src1,&src2, 
				param_mtype[i].unsign, new_attr);
		/*
		 *  change type if necessary.
		 */
		HC_hcode2lcode_type(param[i]->type, &mtype);
		if (! M_compatible_type(param_mtype+i, &mtype)) {
		    src1 = dest;
	    	    param_reg_id[i] = next_reg_id++;
		    HC_new_register(&dest, param_reg_id[i], mtype.type, mtype.unsign);
		    HC_gen_mov(prologue_cb,&dest, &src1, 0);
		    param_mtype[i] = mtype;
		}
		break;
	    }
	    case M_INDIRECT_THRU_REGISTER:
	    case M_INDIRECT_THRU_MEMORY:
		Punt("do not allocate structures to registers");
		break;
	    default:
		Punt("illegal mode returned from M_fnvar_layout");
	    }
	    param_mode[i] = M_THRU_REGISTER;
	} else {
	    _M_Type mtype;
	    param_reg_id[i] = -1;
	    switch (param_mode[i]) {
	    case M_THRU_REGISTER: {
		/*** mem[param_base_macro + offset] <- $Preg ***/
		char line[64];
		sprintf(line, "$P%d", param_reg[i]);
		HC_new_macro(&src3, line, param_mtype[i].type, param_mtype[i].unsign);
	    	/*
	    	 *  change type if necessary.
	    	 */
	    	HC_hcode2lcode_type(param[i]->type, &mtype);
	    	if (! M_compatible_type(param_mtype+i, &mtype)) {
		    src1 = src3;
		    HC_new_register(&src3, next_reg_id++, mtype.type, mtype.unsign);
		    HC_gen_mov(prologue_cb,&src3, &src1, 0);
		    param_mtype[i] = mtype;
	    	}
		HC_new_macro(&src1, param_base_macro, M_TYPE_POINTER, 0);
		HC_new_int(&src2, param_offset[i], 0);
		HC_gen_store(prologue_cb, expr,&src1, &src2, &src3, 
				param_mtype[i].type, 0);
		/*
		 *  change to memory.
		 */
	    	param_mode[i] = M_THRU_MEMORY;
		break;
	    }
	    case M_THRU_MEMORY: {
	    	/*
	    	 *  change type if necessary.
	    	 */
	    	HC_hcode2lcode_type(param[i]->type, &mtype);
	    	if (! M_compatible_type(param_mtype+i, &mtype)) {
		    /*
		     *  load into a register.
		     */
		    HC_new_register(&dest, next_reg_id++, param_mtype[i].type, param_mtype[i].unsign);
		    HC_new_macro(&src1, param_base_macro, M_TYPE_POINTER, 0);
		    HC_new_int(&src2, param_offset[i], 0);
		    HC_gen_load(prologue_cb, expr,&dest,&src1,&src2,
					param_mtype[i].unsign, 0);
		    /*
		     *	change type.
		     */
		    src3 = dest;
		    HC_new_register(&dest, next_reg_id++, mtype.type, mtype.unsign);
		    HC_gen_mov(prologue_cb,&dest, &src3, 0);
		    param_mtype[i] = mtype;
		    src3 = dest;
		    /*
		     *	store back to memory.
		     */
		    HC_gen_store(prologue_cb,expr,&src1,&src2,&src3,
					param_mtype[i].type, 0);
	    	}
		break;
	    }
	    case M_INDIRECT_THRU_REGISTER:
	    case M_INDIRECT_THRU_MEMORY: {
	    	/*
	    	 *  keep in memory.
	    	 */
		break;
	    }
	    default:
		Punt("illegal parameter mode returned by M_fnvar_layout");
	    }
	}
    }
    /*
     *	Handle special case of returning a structure.
     */
    if (is_structure(return_type)) {
	/*
	 *  Need to save the address of the caller allocated space,
	 *  which is assumed to be passed in through $Pn.
	 */
	_HC_Operand src1, dest;
	char line[64];
	return_structure = 1;
	return_addr_reg = next_reg_id++;
	HC_new_register(&dest, return_addr_reg, M_TYPE_POINTER, 0);
	sprintf(line, "$P%d", M_structure_pointer(M_GET_FNVAR));
	HC_new_macro(&src1, C_findstr(line), M_TYPE_POINTER, 0);
	HC_gen_mov(prologue_cb,&dest, &src1, 0);
    } else {
	return_structure = 0;
	return_addr_reg = -1;
    }
#ifdef DEBUG_LAYOUT
    printf("### actual parameter space = (%d bytes) \n", actual_space);
    printf("### local variable space = (%d bytes) (%s) \n",
	local_space, local_base_macro);
    for (i=0; i<n_local; i++) {
	printf("\t%s : offset=%d, mode=%d, reg=%d\n",
	    local[i]->name, local_offset[i], local_mode[i], local_reg_id[i]);
    }
    printf("### formal space = (%d bytes) (%s) \n",
	param_space, param_base_macro);
    for (i=0; i<n_param; i++) {
	printf("\t%s : offset=%d, mode=%d, reg=%d\n",
	    param[i]->name, param_offset[i], param_mode[i], param_reg_id[i]);
    }
#endif
    /*
     *	Generate function body.
     */
    for (i=0; i<n_block; i++) 
    {
  	int case_id, k;
	BLink ln;
	ProfArc arc;
  	Block bb;
	Expr expr;
	bb = block[i];
  	HC_profile_weight = bb->profile.weight;
	/*
	 *  Gather the control flow information.
	 */
	n_cnt = 0;
	case_id = 0;
	default_bb = 0;
	default_bb_id = -1;
	for (ln=bb->destination; ln!=0; ln=ln->next) {
	    Expr reduced;
	    long value;
	    reduced = HC_ReduceExpr(ln->condition);
	    if (! IsIntegralExpr(reduced)) {
		Punt("HC_gen_func: branch condition must be known now");
	    }
	    value = IntegralExprValue(reduced);
	    RemoveExpr(reduced);
	    /*** 1. if it is the switch default case ***/
	    if (IsDefaultExpr(ln->condition) && (bb->cnt_type==CNT_SWITCH)) {
	    	cnt_switch_default[n_cnt] = 1;
		default_bb = ln->dest_bb;
		default_bb_id = HC_bb_id(ln->dest_bb);
	    } else {
	    	cnt_switch_default[n_cnt] = 0;
	    }
	    /*** 2. the destination block (may not be unique for switch) ***/
	    cnt_dest[n_cnt] = ln->dest_bb;
	    cnt_dest_id[n_cnt] = HC_bb_id(ln->dest_bb);
	    /*** 3. the condition for going there ***/
	    cnt_cc[n_cnt] = value;
	    /*** 4. the profile weight ***/
	    if (bb->cnt_type==CNT_SWITCH) {
		long cs;
		/* the default case is always 0, others 1.. */
		if (cnt_switch_default[n_cnt])
		    cs = 0;
		else {
		    case_id += 1;	
		    cs = case_id;
		}
		for (arc=bb->profile.destination; arc!=0; arc=arc->next) {
		    if ((arc->bb_id==ln->destination) &
			(arc->condition==cs)) {
			break;
		    }
		}
		if (arc==0) {
		   cnt_weight[n_cnt] = 0.0;
		} else {
		   cnt_weight[n_cnt] = arc->weight;
		}
	    } else {
		for (arc=bb->profile.destination; arc!=0; arc=arc->next) {
		    if (arc->bb_id==ln->destination) 
			break;
		}
		if (arc==0) {
		   cnt_weight[n_cnt] = 0.0;
		} else {
		   cnt_weight[n_cnt] = arc->weight;
		}
	    }
	    n_cnt += 1;
	}
#ifdef DEBUG_FLOW
	printf("### block [%d] %f\n", HC_bb_id(bb), bb->profile.weight);
	for (k=0; k<n_cnt; k++) {
	    printf("\tdest=%d, cc=%d, weight=%f, default=%d\n",
		cnt_dest_id[k], cnt_cc[k], 
		cnt_weight[k], cnt_switch_default[k]);
	}
#endif
	if ((bb->cnt_type==CNT_SWITCH) && (default_bb_id==-1)) {
	    fprintf(stderr, "function %s block %d\n",
		fn->name, HC_bb_id(bb));
	    Punt("IMPACT C frontend must create default case for switch");
 	}
	/*
	 *  Decide how to implement the control flow.
	 *  Except CNT_SWITCH, others are trivial.
	 */
	block_hash_jump[i] = 0;		/* assume not hashing jump */
	block_hash_table[i] = "???";
	if (bb->cnt_type==CNT_SWITCH) {
	    /*
	     *  Sort according to profile weight.
	     */
	    int n;
	    double cost, total_weight;
	    {
		ST_Entry list[HC_MAX_FLOW];
		int n_list, n, default_n;
		Block temp_dest[HC_MAX_FLOW];
		int temp_dest_id[HC_MAX_FLOW];
		long temp_cc[HC_MAX_FLOW];
		char temp_switch_default[HC_MAX_FLOW];
		double temp_weight[HC_MAX_FLOW];
		n_list = 0;
		default_n = -1;
		for (n=0; n<n_cnt; n++) {
		    if (cnt_switch_default[n]) {
			default_n = n;
			continue;
		    }
		    list[n_list].ptr = 0;
		    list[n_list].index = n;
		    list[n_list].weight = cnt_weight[n] - (0.0001*n);
		    n_list += 1;
		}
		max_sort(list, n_list);
		list[n_list].ptr = 0;
		list[n_list].index = default_n;
		list[n_list].weight = cnt_weight[default_n];
		n_list += 1;
		if (n_list != n_cnt)
		    Punt("internal error X0001");
		/*
		 *  Reorder fields.
		 */
		for (n=0; n<n_cnt; n++) {
		    int index = list[n].index;
		    temp_dest[n] = cnt_dest[index];
		    temp_dest_id[n] = cnt_dest_id[index];
		    temp_cc[n] = cnt_cc[index];
		    temp_switch_default[n] = cnt_switch_default[index];
		    temp_weight[n] = cnt_weight[index];
		}
		for (n=0; n<n_cnt; n++) {
		    cnt_dest[n] = temp_dest[n];
		    cnt_dest_id[n] = temp_dest_id[n];
		    cnt_cc[n] = temp_cc[n];
		    cnt_switch_default[n] = temp_switch_default[n];
		    cnt_weight[n] = temp_weight[n];
	  	}
	    }
	    cost = 0.0;
	    total_weight = 0.0;
	    for (n=0; n<n_cnt; n++) {
		cost += (n+1) * cnt_weight[n];
		total_weight += cnt_weight[n];
	    }
	    if (total_weight<=0.0) {
	    	cost = 1.0e100;	/* some large number */
	    } else {
	    	cost = cost / total_weight;
	    }
#undef DEBUG_HASH
#ifdef DEBUG_HASH
for (n=0; n<n_cnt; n++)
	fprintf(stderr, "# cc=%d, dest=%d, weight=%f\n", 
		cnt_cc[n], cnt_dest_id[n], cnt_weight[n]);
fprintf(stderr, "cost of br sequence in cb %d is %f\n",
		bb->id, cost);
#endif
	    /*
	     *	use hashint jump if
	     *	1. number of cases if large,
	     *	2. case_values can be easily packed into a table,
	     *	3. the switch is important.
	     */
	    hash_jump = 0;	
	    if ( HL_generate_hashing_branches &&
		(n_cnt>=HC_MIN_HASH_JUMP_CASE) &&
		((bb->profile.weight>=HC_MIN_HASH_JUMP_WEIGHT) ||
		 (HL_ignore_hash_profile_weight) ) &&
		( (cost>HC_MAX_BR_SEQUENCE_WEIGHT) ||
		  (HL_ignore_hash_br_seq_weight) ) ) {
	    	long m, min, max;
		min = 0x1FFFFFFF;
		max = -0x1FFFFFFF;
		for (m=0; m<n_cnt; m++) {
		    if (cnt_switch_default[m])
			continue;
		    if (cnt_cc[m]<min) min = cnt_cc[m];
		    if (cnt_cc[m]>max) max = cnt_cc[m];
		}
		hash_jump = ((max-min)<=HC_MAX_HASH_JUMP_SIZE);
	    } 
	    block_hash_jump[i] = hash_jump;
	    if (hash_jump) {
	    	block_hash_table[i] = new_hash_table(fn->name);
	    } 
	}
	/*
	 *  Print block header.
	 */

        new_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                block_id[i]);
	new_cb->weight = bb->profile.weight;
        L_insert_cb_after(L_fn,L_fn->last_cb,new_cb);

	switch (bb->cnt_type) {
	case CNT_GOTO: {
	    for (k=0; k<n_cnt; k++) {
		dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                cnt_dest_id[k]);
		new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
			L_new_flow(1,new_cb,dest_cb,cnt_weight[k]));
	    }
	    break;
	}
	case CNT_IF: {
	    Block taken_bb = 0;
	    int first_flow = 1;
	    for (k=0; k<n_cnt; k++) {
		if (cnt_cc[k]!=0)
		    taken_bb = cnt_dest[k];
	    }
	    if ((bb->next!=0) & (bb->next==taken_bb)) {
	 	/* reversed placement due to code motion */
	    	for (k=0; k<n_cnt; k++) {
		    if (! cnt_cc[k]) {
		      if(first_flow)
			  first_flow = 0;
		      dest_cb = 
			  L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        cnt_dest_id[k]);
		      new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
				L_new_flow(1,new_cb,dest_cb, cnt_weight[k]));
		    }
	    	}
	    	for (k=0; k<n_cnt; k++) {
		    if (cnt_cc[k]) {
		      if(first_flow)
			first_flow = 0;
		      dest_cb = 
			  L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        cnt_dest_id[k]);
		      new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
				L_new_flow(0,new_cb,dest_cb, cnt_weight[k]));
		    }
	    	}
	    } else {
	    	for (k=0; k<n_cnt; k++) {
		    if (cnt_cc[k]) {
		      if(first_flow)
			first_flow = 0;
		      dest_cb = 
			  L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        cnt_dest_id[k]);
		      new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
				L_new_flow(1,new_cb,dest_cb, cnt_weight[k]));
		    }
	    	}
	    	for (k=0; k<n_cnt; k++) {
		    if (! cnt_cc[k]) {
		      if(first_flow)
			first_flow = 0;
		      dest_cb = 
			  L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        cnt_dest_id[k]);
		      new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
				L_new_flow(0,new_cb,dest_cb, cnt_weight[k]));
		    }
	    	}
	    }
	    break;
	}
	case CNT_SWITCH: {
	    int first_flow = 1;
	    /*
	     *	Always print the default flow last.
	     */
	    if (hash_jump) {
		/*
		 *  Print 2 additional flow.
		 */
		first_flow = 0;
		dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        default_bb_id);
		new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
				L_new_flow(1,new_cb,dest_cb, 0.0));
		dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        default_bb_id);
		new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
				L_new_flow(1,new_cb,dest_cb, 0.0));
	    }
	    for (k=0; k<n_cnt; k++) {
	 	if (! cnt_switch_default[k]) {
		  if(first_flow)
		    first_flow = 0;
		  dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        cnt_dest_id[k]);
		  new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
					L_new_flow(cnt_cc[k],new_cb,dest_cb, 
					cnt_weight[k]));
		}
	    }
	    for (k=0; k<n_cnt; k++) {
	 	if (cnt_switch_default[k]) {
		  if(first_flow)
		    first_flow = 0;
		  dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        cnt_dest_id[k]);
		  new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
				L_new_flow(cnt_cc[k],new_cb,dest_cb, 
				cnt_weight[k]));
		}
	    }
	    break;
	}
	case CNT_RETURN: {
#ifdef OLD
	    if (bb==best_rts_bb) {	/* fall-thru */
		  dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        epilogue_bb_id);
		  new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
			L_new_flow(0,new_cb,dest_cb, bb->profile.weight));

	    } else {			/* taken jump */
		  dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        epilogue_bb_id);
		  new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
			L_new_flow(1,new_cb,dest_cb, bb->profile.weight));
	    }
#else
	    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        epilogue_bb_id);
	    new_cb->dest_flow = L_concat_flow(new_cb->dest_flow,
			L_new_flow(1,new_cb,dest_cb, bb->profile.weight));
#endif
	    break;
	}
	default:
	    Punt("HC_gen_func: illegal control type");
	}
#ifdef DEBUG_PCODE
	fprintf(stderr, "bb->id = %d\n", bb->id);
	fprintf(stderr, "bb->pragma = %d\n", bb->pragma);
#endif
	if(bb->pragma != 0) {
            L_Attr *attr;
            L_Attr *doall_attr = 0;
#ifdef DEBUG_PCODE
	    fprintf(stderr, "bb->pragma->specifier = %s\n", bb->pragma->specifier);
#endif
            new_cb->attr = HC_gen_attr_from_pragma(bb->pragma);

        /* GEH - changed above code to handle pragmas uniformly.  7/14/93 */

        /* JCG - scale pcode loop iteration profile info (if necessary)
         *       after function inlining.  Easiest to do here.   4/99 
         */
        if (L_find_attr (new_cb->attr, "iteration_header") != NULL)
	{
	    L_Attr *attr;
	    double loop_freq, count, scale;
	    int index;

	    /* Calculate original loop execution frequency using loop
	     * iteration info 
	     */
	    loop_freq = 0.0;
	    for (attr = new_cb->attr; attr != NULL; attr = attr->next_attr)
	    {
		/* Only handle "iter_x" attributes */
		if ((attr->name[0] != 'i') ||
		    (attr->name[1] != 't') ||
		    (attr->name[2] != 'e') ||
		    (attr->name[3] != 'r') ||
		    (attr->name[4] != '_'))
		    continue;

		/* Convert rest of name into double */
		count = atof (&attr->name[5]);

		/* Sanity check, count better be >= 1 */
		if (count < 1)
		{
		    L_print_attr (stderr, attr);
		    L_punt ("Invalid count value (%f) in iter_x attribute!",
			    count);
		}
		
		/* Sanity check, field[0] better be double! */
		if (!L_is_ctype_dbl(attr->field[0]))
		{
		    L_print_attr (stderr, attr);
		    L_punt ("field[0] not double!");
		}

		/* Add this iteration count's average contribution */
		loop_freq += count * attr->field[0]->value.f2;
	    }

	    /* Rescale the loop iteration profile weights if the
	     * current cb weight is lower than what the loop
	     * iteration profile indicates (assumed due to inlining).
	     */
	    if ((new_cb->weight < (loop_freq - .1)) && (loop_freq > .1))
	    {
		scale = new_cb->weight / loop_freq;

		
		for (attr = new_cb->attr; attr != NULL; attr = attr->next_attr)
		{
		    /* Only scale "iter_x" attributes */
		    if ((attr->name[0] != 'i') ||
			(attr->name[1] != 't') ||
			(attr->name[2] != 'e') ||
			(attr->name[3] != 'r') ||
			(attr->name[4] != '_'))
			continue;

		    /* Scale all the fields, expected to be doubles */
		    for (index=0; index < attr->max_field; index++)
		    {
			/* Sanity check, field[index] better be double! */
			if (!L_is_ctype_dbl(attr->field[index]))
			{
			    L_print_attr (stderr, attr);
			    L_punt ("field[%i] not double!", index);
			}

			attr->field[index]->value.f2 *= scale;
		    }
		}
	    }
	    /* Sanity check, should never have higher weight (I think) */
	    else if (new_cb->weight > (loop_freq + .1))
	    {
		fprintf (stderr, 
			 "Warning: %s cb %i, weight %f > loop_freq %f!\n",
			 L_fn->name, new_cb->id, new_cb->weight, loop_freq);
	    }
	}

        /* DML 5/29/95 skip setting softpipe flag and DOALL attribute.
           Do it in lcode */
#if 0
	    for (attr = new_cb->attr; attr != NULL; attr = attr->next_attr) {
                if (!strcmp(attr->name, "LOOP") && 
		    L_is_string(attr->field[0]) &&
		    !strcmp(attr->field[0]->value.s, "\"dosuper\"")) {
                    doall_attr = L_new_attr("DOALL", 1);
                    L_set_int_attr_field(doall_attr, 0, 0);
                }
            }
           if (doall_attr != NULL) {
               new_cb->attr = L_concat_attr(new_cb->attr, doall_attr);
           }
        /* DML */
#endif
	}
	/*
	 *  Print operations.
	 */
	for (expr=bb->first; (expr!=0)&(expr!=bb->last); expr=expr->next) {
	    gen_expr(new_cb, expr);
	}
	/*
	 *  Print control information.
	 */
	expr = bb->last;
	if (expr==0) {
	    Punt("HC_gen_func: empty basic block");
	}
	switch (bb->cnt_type) {
	case CNT_GOTO:
	    if (n_cnt!=1) {
		Punt("CNT_GOTO: n_cnt must be 1");
	    }
	    if ((bb->next==0) | (cnt_dest[0]!=bb->next)) {
		weight = bb->profile.weight;
    		if (weight>=HC_DEFAULT_FS_MINIMUM) {
		    new_oper = L_create_new_op(Lop_JUMP_FS);
    		} else {
		    new_oper = L_create_new_op(Lop_JUMP);
    		}
	        dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        cnt_dest_id[0]);
		new_oper->src[0] = L_new_cb_operand (dest_cb);
		L_insert_oper_after(new_cb,new_cb->last_op,new_oper);
	    } else {
		/* just let it fall thru */
	    }
	    break;
	case CNT_IF: {
	    Block taken_bb, fall_thru_bb;
	    double taken_weight, fall_thru_weight;
	    int reverse_cc;
	    if (n_cnt!=2) {
		Punt("CNT_IF: n_cnt must be 2");
	    }
	    if (cnt_cc[0]==0) {
		fall_thru_bb = cnt_dest[0];
		fall_thru_weight = cnt_weight[0];
	  	taken_bb = cnt_dest[1];
		taken_weight = cnt_weight[1];
	    } else {
		fall_thru_bb = cnt_dest[1];
		fall_thru_weight = cnt_weight[1];
	  	taken_bb = cnt_dest[0];
		taken_weight = cnt_weight[0];
	    }
	    /*
	     *	due to trace placement, the role of taken and
	     *	fall_thru blocks may have been reversed.
	     */
	    reverse_cc = 0;
	    if ((bb->next!=0) & (bb->next==taken_bb)) {
		Block temp_bb;
		double temp_weight;
		temp_bb = taken_bb;
		temp_weight = taken_weight;
		taken_bb = fall_thru_bb;
		taken_weight = fall_thru_weight;
		fall_thru_bb = temp_bb;
		fall_thru_weight = temp_weight;
		reverse_cc = 1;
	    }
	    /*
	     *	generate output.
	     */
	    new_oper = gen_if(new_cb, GetOperand(expr,1), expr->pragma, 
		reverse_cc, HC_bb_id(taken_bb), taken_weight, fall_thru_weight);
	    L_insert_oper_after(new_cb,new_cb->last_op,new_oper);

	    if ((bb->next==0) | (fall_thru_bb!=bb->next)) {
		weight = fall_thru_weight;
    		if (weight>=HC_DEFAULT_FS_MINIMUM) {
		    new_oper = L_create_new_op(Lop_JUMP_FS);
    		} else {
		    new_oper = L_create_new_op(Lop_JUMP);
    		}
	        dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        HC_bb_id(fall_thru_bb));
		new_oper->src[0] = L_new_cb_operand (dest_cb);
		L_insert_oper_after(new_cb,new_cb->last_op,new_oper);
	    } else {
		/* just let it fall thru */
	    }
	    break;
	}
	case CNT_RETURN:
		/* DMG - code to check if tr attr should be on return */
	    return_generated = gen_return(new_cb, GetOperand(expr,1));
	    if (return_generated)
		need_return_register = 1;
	    if (bb==best_rts_bb) 
	    {
    		/*
    		 *	Generate function epilogue.
    		 */
    		weight = 0.0;
    		for (bb=fn->blocks; bb!=0; bb=bb->next) {
		    if (bb->cnt_type == CNT_RETURN)
	    		weight += bb->profile.weight;
    		}

        	epilogue_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                epilogue_bb_id);
		epilogue_cb->weight = weight;
        	L_insert_cb_after(L_fn,L_fn->last_cb,epilogue_cb);

		new_oper = L_create_new_op(Lop_EPILOGUE);
		L_insert_oper_after(epilogue_cb,epilogue_cb->last_op,new_oper);
/* *******RAB */

                if (is_structure(return_type)) 
		{
		    _M_Type mtype;
	            HC_hcode2lcode_type(return_type, &mtype);
		    
		    return_oper = L_create_new_op(Lop_RTS);
			/* DMG - return value was generated, so add attr */
		    if (need_return_register) 
		    {
			return_register_created = 1;
    		        return_oper->attr = L_new_attr("tr", 1);
		    }
		    else
		    {
			/* Added undefined thru register attribute for
			 * those cases where the function returns 
			 * a undefined value (due to the way it was coded).
			 * Make Lemulate more robust. -ITI/JCG 4/99
			 */
    		        return_oper->attr = L_new_attr("utr", 1);
		    }
		    /* REH 1/26/95 Changes M_GET_FNVAR->M_PUT_FNVAR for Sparc*/
		    if (L_propagate_sign_size_ctype_info)
		    {
			L_set_macro_attr_field(return_oper->attr, 0,
		            L_MAC_P0 + M_return_register(M_TYPE_POINTER, 
							    M_PUT_FNVAR), 
			    L_ctype_id(HC_typename2(mtype.type, mtype.unsign)),
			    L_PTYPE_NULL);	
		    }
		    else
		    {
			L_set_macro_attr_field(return_oper->attr, 0,
			     L_MAC_P0 + M_return_register(M_TYPE_POINTER, 
							  M_PUT_FNVAR), 
			     L_ctype_id(HC_typename(mtype.type)),
			     L_PTYPE_NULL);
		    }

		    L_insert_oper_after(epilogue_cb, epilogue_cb->last_op,
					return_oper);
    		}
		else 
		{
		    _M_Type mtype;
	            HC_hcode2lcode_type(return_type, &mtype);
	            switch (mtype.type) 
		    {
	            case M_TYPE_VOID:
	                /* does not return anything */

		        return_oper = L_create_new_op(Lop_RTS);
		        L_insert_oper_after(epilogue_cb, epilogue_cb->last_op,
					return_oper);
	                break;
	            default:
		        return_oper = L_create_new_op(Lop_RTS);
			    /* DMG - return value was generated, so add attr */
		        if (need_return_register) 
			{
			    return_register_created = 1;
			    return_oper->attr = L_new_attr("tr",1);
			}
			else
			{
			    /* Added undefined thru register attribute for
			     * those cases where the function returns 
			     * a undefined value (due to the way it was coded).
			     * Make Lemulate more robust. -ITI/JCG 4/99
			     */
			    return_oper->attr = L_new_attr("utr", 1);
			}
			/* REH 1/26/95 Changes M_GET_FNVAR ->  
			   M_PUT_FNVAR for Sparc */
			if (L_propagate_sign_size_ctype_info) 
			{
			    L_set_macro_attr_field(return_oper->attr,0,
   			       L_MAC_P0+ M_return_register(mtype.type, 
							   M_PUT_FNVAR), 
			       L_ctype_id(HC_typename2(mtype.type, 
						       mtype.unsign)),
			       L_PTYPE_NULL);
			}
			else
			{
			    L_set_macro_attr_field(return_oper->attr,0,
				L_MAC_P0+ M_return_register(mtype.type, 
							    M_PUT_FNVAR), 
				L_ctype_id(HC_typename(mtype.type)), 
				L_PTYPE_NULL);
			}
		        L_insert_oper_after(epilogue_cb, epilogue_cb->last_op,
					return_oper);
	            break;
	            }
                }
	    } 
	    else
	    {
		/*
		 *	Generate a jump to the epilogue block.
		 */
		weight = bb->profile.weight;
    		if (weight>=HC_DEFAULT_FS_MINIMUM) {
		    new_oper = L_create_new_op(Lop_JUMP_FS);
    		} else {
		    new_oper = L_create_new_op(Lop_JUMP);
    		}
	        dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                        epilogue_bb_id);
		new_oper->src[0] = L_new_cb_operand (dest_cb);
		L_insert_oper_after(new_cb,new_cb->last_op,new_oper);
		if (need_return_register && ! return_register_created) {
		    if (return_oper != NULL) {
		        _M_Type mtype;

			return_register_created = 1;

			if (L_find_attr(return_oper->attr, "tr"))
			    Punt ("function tr return attr already set");

	                HC_hcode2lcode_type(return_type, &mtype);

			/* Remove utr attribute, if it exists -ITI/JCG 4/99 */
			if (return_oper->attr != NULL)
			{
			    if ((return_oper->attr->next_attr == NULL) &&
				strcmp (return_oper->attr->name, "utr") == 0)
			    {
				return_oper->attr = 
				    L_delete_attr (return_oper->attr, 
						   return_oper->attr);
			    }
			    else
			    {
				L_print_oper (stderr, return_oper);
				L_punt ("Unexpected rts attributes!");
			    }
			}

			return_oper->attr = L_new_attr("tr",1);

			if (is_structure(return_type)) {
			  if (L_propagate_sign_size_ctype_info)
		            L_set_macro_attr_field(return_oper->attr, 0,
			      L_MAC_P0 + M_return_register(M_TYPE_POINTER, 
			      M_PUT_FNVAR), L_ctype_id(HC_typename2(mtype.type, mtype.unsign)),
			      L_PTYPE_NULL);
			  else
		            L_set_macro_attr_field(return_oper->attr, 0,
			      L_MAC_P0 + M_return_register(M_TYPE_POINTER, 
			      M_PUT_FNVAR), L_ctype_id(HC_typename(mtype.type)),
			      L_PTYPE_NULL);
			}
			else {
			  if (L_propagate_sign_size_ctype_info)
			    L_set_macro_attr_field(return_oper->attr,0,L_MAC_P0+
				M_return_register(mtype.type, M_PUT_FNVAR), 
				L_ctype_id(HC_typename2(mtype.type, mtype.unsign)), 
				L_PTYPE_NULL);
			  else
			    L_set_macro_attr_field(return_oper->attr,0,L_MAC_P0+
				M_return_register(mtype.type, M_PUT_FNVAR), 
				L_ctype_id(HC_typename(mtype.type)), 
				L_PTYPE_NULL);
			}
		    }
		}
	    }
	    break;
	case CNT_SWITCH:
	    gen_switch(new_cb, GetOperand(expr, 1), hash_jump, 
		block_hash_table[i], n_cnt, cnt_cc, 
		cnt_dest_id, cnt_weight, cnt_switch_default);
	    break;
	}
    }
    if (best_rts_bb==0) {
	_M_Type mtype;
	
        epilogue_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
                                                epilogue_bb_id);
	epilogue_cb->weight = weight;

        L_insert_cb_after(L_fn,L_fn->last_cb,epilogue_cb);

	new_oper = L_create_new_op(Lop_EPILOGUE);
	L_insert_oper_after(epilogue_cb,epilogue_cb->last_op,new_oper);

	HC_hcode2lcode_type(return_type, &mtype);
	switch (mtype.type)  {
	    case M_TYPE_VOID:
		/* does not return anything */

		new_oper = L_create_new_op(Lop_RTS);
		L_insert_oper_after(epilogue_cb, epilogue_cb->last_op,new_oper);
		break;
	    default:
		new_oper = L_create_new_op(Lop_RTS);
		new_oper->attr = L_new_attr("tr",1);   /* same attr string as jsr */
		if (L_propagate_sign_size_ctype_info) 
		  L_set_macro_attr_field(new_oper->attr, 0,        
				       L_MAC_P0 + M_return_register(mtype.type,M_GET_FNVAR),	      
				       L_ctype_id(HC_typename2(mtype.type, mtype.unsign)),	      
				       L_PTYPE_NULL);
		else
		  L_set_macro_attr_field(new_oper->attr, 0,        
				       L_MAC_P0 + M_return_register(mtype.type,M_GET_FNVAR),	      
				       L_ctype_id(HC_typename(mtype.type)),	      
				       L_PTYPE_NULL);
		L_insert_oper_after(epilogue_cb, epilogue_cb->last_op,new_oper);
	}

    }
    /*
     *	Generate hash tables.
     */
    HC_invalidate_last_ms();
    for (i=0; i<n_block; i++) {
	Block bb;
	BLink ln;
	ProfArc arc;
	int case_id, cs;
	long m, min, max, size;
	if (! block_hash_jump[i])
	    continue;

    	HC_ms(L_hash_datalist, "data");
	bb = block[i];
	HC_profile_weight = bb->profile.weight;
	n_cnt = 0;
	default_bb = 0;
	case_id = 0;
	for (ln=bb->destination; ln!=0; ln=ln->next) {
	    Expr reduced;
	    reduced = HC_ReduceExpr(ln->condition);
	    cnt_cc[n_cnt] = IntegralExprValue(reduced);
	    RemoveExpr(reduced);
	    cnt_dest[n_cnt] = ln->dest_bb;
	    cnt_dest_id[n_cnt] = HC_bb_id(ln->dest_bb);
	    cnt_switch_default[n_cnt] = 0;
	    if (IsDefaultExpr(ln->condition)) {
		cnt_switch_default[n_cnt] = 1;
		default_bb = ln->dest_bb;
	    }
	    if (cnt_switch_default[n_cnt]) {
		cs = 0;
	    } else {
		case_id++;
		cs = case_id;
	    }
	    for (arc=bb->profile.destination; arc!=0; arc=arc->next) {
		if ((arc->bb_id==ln->destination) &
		    (arc->condition==cs)) {
		    break;
		}
	    }
	    if (arc==0) {
		cnt_weight[n_cnt] = 0.0;
	    } else {
		cnt_weight[n_cnt] = arc->weight;
	    }
	    n_cnt++;
	}
	/*
	 *  print hash table.
	 */
	min = 0x1FFFFFFF;
	max = -0x1FFFFFFF;
	for (m=0; m<n_cnt; m++) {
	    if (cnt_switch_default[m])
		continue;
	    if (cnt_cc[m]<min) min = cnt_cc[m];
	    if (cnt_cc[m]>max) max = cnt_cc[m];
	}
	size = max - min + 1;

        new_data = L_new_data(L_INPUT_ALIGN);
	new_data->N = M_ALIGN_INT/H_CHAR_SIZE;
        new_expr = L_new_expr(L_EXPR_STRING);
	temp_ptr = C_findstr(block_hash_table[i]);
        new_expr->value.s =temp_ptr;
        new_data->address = new_expr;

        L_concat_datalist_element (L_hash_datalist, 
				L_new_datalist_element(new_data));

        new_data = L_new_data(L_INPUT_RESERVE);
	new_data->N = size * M_ALIGN_INT/H_CHAR_SIZE;

        L_concat_datalist_element (L_hash_datalist, 
				L_new_datalist_element(new_data));

	for (m=min; m<=max; m++) {
	    int k;
	    for (k=0; k<n_cnt; k++) {
		if (cnt_cc[k]==m)
		    break;
	    }
	    if (k==n_cnt) {	/* not found */
		if (default_bb==0) {
		    new_data = L_new_data_w(L_INPUT_WI,
			(L_Expr *) L_new_addr(block_hash_table[i],
			(m-min) * (H_INT_SIZE/H_CHAR_SIZE)), 
			L_new_expr_int (HC_SWITCH_MISS_ADDRESS) );
		} else {
		    new_data = L_new_data_w(L_INPUT_WI,
			(L_Expr *) L_new_addr_no_underscore(block_hash_table[i],
			(m-min) * (H_INT_SIZE/H_CHAR_SIZE)), 
			(L_Expr *) L_new_expr_label_no_underscore (cb_label_name(fn->name, 
						HC_bb_id(default_bb))));
		}
	    } else {
		 new_data = L_new_data_w(L_INPUT_WI,
			(L_Expr *) L_new_addr_no_underscore(block_hash_table[i],
			(m-min) * (H_INT_SIZE/H_CHAR_SIZE)), 
			L_new_expr_label_no_underscore (cb_label_name(fn->name, 
						cnt_dest_id[k])));
	    }

            L_concat_datalist_element (L_hash_datalist, 
				L_new_datalist_element(new_data));
	}
    }
    HC_invalidate_last_ms();
}


/* Returns 1 if a loop iteration profiling attribute, 0 otherwise -JCG 4/99 */
int HC_loop_iter_attr (char *buffer)
{
   if (strcmp(buffer, "iteration_header") == 0)
      return (1);
   
   /* Accept iter_* */
   if ((buffer[0] == 'i') && 
       (buffer[1] == 't') && 
       (buffer[2] == 'e') && 
       (buffer[3] == 'r') && 
       (buffer[4] == '_'))
   {
      return (1);
   }

   /* Otherwise, not a loop iter attribute */
   return (0);
}


/*---------------------------------------------------------------------------*/
/* SAM 6-93 */
/*
 *	Print out pragma in Lcode attribute format
 */

L_Attr *HC_gen_attr_from_pragma(Pragma pragma)
{
    Pragma ptr;
    char buffer[256], *pragmastr, *delim;
    int field;
    long int integer;
    double real;
    L_Attr *new_attr = NULL, *attr, *old_attr;

    if (pragma==NULL)
	return (NULL);

    /*  
     *  GEH - 3/95
     *	Make the following assumption for pragma format
     *	since pragma only has string component:
     *
     *		pragma->specifier = \"<name><field>*\"
     *		<field> = \$<string> |
     *			  \!<label> |
     *			  \%<integer> |
     *			  \#<real>
     *
     *  <name> must be a valid Lcode identifier and becomes the attribute name.
     *  Fields are converted to attribute field of appropriate type.
     */
    for (ptr=pragma; ptr!=NULL; ptr=ptr->next) {
	pragmastr = HC_read_attr_name_from_pragma_str(ptr->specifier, buffer); 
	/*
         *	(SAM 2-94) Allow only selective pragmas to go
	 *	from Hcode to Lcode, because I was sick of looking
	 *	at some stupid ones that are generated for Hcode 
	 *	debugging!!!  So if you want a pragma to go from
	 *	Hcode to Lcode, you need to add it here.
         */
	if ((!strcmp(buffer, "FUNC")) ||
	    (!strcmp(buffer, "FILE")) ||
	    (!strcmp(buffer, "CONJDISJ") && HL_generate_static_branch_attrs) ||
	    (!strcmp(buffer, "IFELSE") && HL_generate_static_branch_attrs) ||
	    (!strcmp(buffer, "QUEST") && HL_generate_static_branch_attrs) ||
	    /* next comparison should let either ACC_NAME or ACC_NAME_BY_TYPE
             * attributes pass through when parameter is set to yes */
	    (strstr(buffer, "ACC_NAME") && HL_generate_acc_name_attrs) ||
	    (!strcmp(buffer, "LOOP")) ||
	    (!strcmp(buffer, "SWP_INFO")) ||
	    (!strcmp(buffer, "INLINE")) ||
	    (!strcmp(buffer, "CALLNAME")) ||
	    (!strcmp(buffer, "call_info")) || /* JCG -added 5/20/98 */
	    (!strcmp(buffer, "old_style_param")) || /* ITI/JCG -added 4/99 */
	    (!strcmp(buffer, "append_gcc_ellipsis")) || /*ITI/JCG -added 4/99*/
	    (!strcmp(buffer, "use_ret_as_parm0")) || /* ITI/JCG -added 4/99 */
  	    (HC_loop_iter_attr (buffer)) || /* JCG -added 4/99 */
	    (!strcmp(buffer, "impact_info")) || /* JCG -added 6/99 */
	    (!strcmp(buffer, "host_info")) || /* BCC -added 1/28/99 */
	    (!strcmp(buffer, "preprocess_info")) || /* JCG -added 6/99 */
            (!strcmp(buffer, "PCODE_PROBE")) || /* LCW - added 10/24/96 */
	    (!strcmp(buffer, "JSR_SIDE_EFFECT")) ||
	    (!strcmp(buffer, "POS")) ||  /* LCW - add file name and line no. */
	    (!strcmp(buffer, "SCOPE")) || /* LCW - add scope id. -  8/4/95 */
	    (!strcmp(buffer, "CALL_CONV")) || /* GEH - added 10/27/95 */
	    ((!strcmp(buffer, "DEP_PRAGMAS")) && HL_generate_sync_arcs) ||
	    ((!strcmp(buffer, "JSR_DEP_PRAGMAS")) && HL_generate_sync_arcs) ||
	    /* BCC - added NEW_JSR_DEP_PRAGMAS - 11/18/97 */
	    ((!strcmp(buffer,"NEW_JSR_DEP_PRAGMAS"))&&HL_generate_sync_arcs) ||
	    (!strcmp(buffer, "COPY"))) { /* GEH - added COPY (6/30/94) */

	    /* DMG - combine attributes with same name 3/31/95 */
	    if ((old_attr = L_find_attr (new_attr, buffer)) == NULL) {
	        attr = L_new_attr(buffer, 0);
	        field = 0;
	    }
	    else {
		attr = old_attr;
	        field = attr->max_field;
	    }
	    while (pragmastr != NULL) {
		pragmastr = 
		    HC_read_attr_field_from_pragma_str(pragmastr, buffer, 
						       &integer, &real, &delim);
		switch (delim[1]) {
		  case '$':
		    L_set_string_attr_field(attr, field, buffer);
		    break;
		  case '!':
		    L_set_label_attr_field(attr, field, buffer);
		    break;
		  case '%':
		    L_set_int_attr_field(attr, field, integer);
		    break;
		  case '#':
		    L_set_double_attr_field(attr, field, real);
		    break;
		  default:
		    Punt("Internal error: unknown pragma delimiter type");
		 }
		 field ++;
	    }
	    if (old_attr == NULL)
	        new_attr = L_concat_attr(new_attr, attr);
	}
    }
    return (new_attr);

}
/*
 *	Print out an Lcode attribute
 */
L_Attr *HC_gen_attr(char *name, int value)
{
    L_Attr *new_attr;

    if (! attr_flag) {
	attr_flag = 1;
    }

    new_attr = L_new_attr(name, 1);
    L_set_int_attr_field(new_attr, 0, value);

    return (new_attr);
}

int HC_uses_pointer_operand(Expr expr)
{
    if (expr==NULL)
	return 0;
    switch (expr->opcode) {
    /* constants never a ptr */
    case OP_enum:
    case OP_signed:
    case OP_unsigned:
    case OP_float:
    /* BCC - added - 8/5/96 */
    case OP_double:
    case OP_char:
    case OP_string:
    case OP_expr_size:
    case OP_type_size:
    case OP_goto:
	return (0);
	break;
    /* pointer if ret type is ptr */
    case OP_var:
    case OP_dot:
    case OP_arrow:
    case OP_cast:
    case OP_indr:
    case OP_addr:
    case OP_index:
    case OP_comma:
    case OP_assign:
    case OP_or:
    case OP_xor:
    case OP_and:
    case OP_rshft:
    case OP_lshft:
    case OP_add:
    case OP_sub:
    case OP_mul:
    case OP_div:
    case OP_mod:
    case OP_Aadd:
    case OP_Asub:
    case OP_Amul:
    case OP_Adiv:
    case OP_Amod:
    case OP_Arshft:
    case OP_Alshft:
    case OP_Aand:
    case OP_Aor:
    case OP_Axor:
    case OP_neg:
    case OP_not:
    case OP_inv:
    case OP_abs:
    case OP_preinc:
    case OP_predec:
    case OP_postinc:
    case OP_postdec:
    case OP_sync:
    case OP_nulldefine:  /* LCW - 10/24/96 */
    case OP_call:
    case OP_return:
	return (IsPointerType(expr->type));
        break;
    /* illegal OP's in flattened Hcode */
    case OP_quest:
    case OP_disj:
    case OP_conj:
	Punt("HC_uses_pointer_operand: Hcode should be flattened");
	break;
    /* These always ret int, so check operands */
    case OP_eq:
    case OP_ne:
    case OP_lt:
    case OP_le:
    case OP_ge:
    case OP_gt:
	return (HC_uses_pointer_operand(GetOperand(expr, 1)) ||
		HC_uses_pointer_operand(GetOperand(expr, 2)));
	break;
    /* return if first operand has ptr access */
    case OP_if:
    case OP_switch:
	return (HC_uses_pointer_operand(GetOperand(expr, 1)));
	break;
    default:
	Punt("HC_uses_pointer_operand: illegal opcode");
    }
    return (0);
}

L_Attr *HC_gen_pointer_attr(Expr expr)
{
    L_Attr *attr = NULL;
    int has_ptr;

    has_ptr = HC_uses_pointer_operand(expr);
    if (has_ptr) {
        attr = HC_gen_attr("ptr", 0);
    }

    return (attr);
}

L_Attr *HC_gen_if_attr(Pragma pragma, Expr expr)
{
    L_Attr *attr;

    attr = HC_gen_attr_from_pragma(pragma);
    attr = L_concat_attr(attr,HC_gen_pointer_attr(expr));

/* LCW -- concatnate the pragma of the condition expression of a 
 * if-statement to the attributes of this if-statement for line no,
 * file name and scope information - 8/9/95 
 */
    if (expr->pragma != 0)
       attr = L_concat_attr(attr, HC_gen_attr_from_pragma(expr->pragma));

    return (attr);
}

/* end changes */

static L_Oper *gen_if(L_Cb *cb, Expr expr, Pragma pragma, int reverse_cc, 
		int taken_bb, double taken_weight, double fall_thru_weight)
{
    _HC_Ret cc;
    int fs;
    L_Oper *new_oper;

    fs = (taken_weight >= (fall_thru_weight + HC_DEFAULT_FS_MINIMUM));
    HC_gen_data(cb, expr, &cc);
    switch (cc.type) {
    case HC_RET_NONE:		/* not taken */
	break;
    case HC_RET_SIMPLE:
	if (reverse_cc)
	    new_oper = gen_beq_0(&(cc.op1), taken_bb, fs);
	else
	    new_oper = gen_bne_0(&(cc.op1), taken_bb, fs);
	break;
    case HC_RET_EQ:
	if (reverse_cc)
	    new_oper = gen_bne(&(cc.op1), &(cc.op2), taken_bb, fs);
	else
	    new_oper = gen_beq(&(cc.op1), &(cc.op2), taken_bb, fs);
	break;
    case HC_RET_NE:
	if (reverse_cc)
	    new_oper = gen_beq(&(cc.op1), &(cc.op2), taken_bb, fs);
	else
	    new_oper = gen_bne(&(cc.op1), &(cc.op2), taken_bb, fs);
	break;
    case HC_RET_GT:
	if (reverse_cc)
	    new_oper = gen_ble(&(cc.op1), &(cc.op2), taken_bb, fs, 0);
	else
	    new_oper = gen_bgt(&(cc.op1), &(cc.op2), taken_bb, fs, 0);
	break;
    case HC_RET_GE:
	if (reverse_cc)
	    new_oper = gen_blt(&(cc.op1), &(cc.op2), taken_bb, fs, 0);
	else
	    new_oper = gen_bge(&(cc.op1), &(cc.op2), taken_bb, fs, 0);
	break;
    case HC_RET_LT:
	if (reverse_cc)
	    new_oper = gen_bge(&(cc.op1), &(cc.op2), taken_bb, fs, 0);
	else
	    new_oper = gen_blt(&(cc.op1), &(cc.op2), taken_bb, fs, 0);
	break;
    case HC_RET_LE:
	if (reverse_cc)
	    new_oper = gen_bgt(&(cc.op1), &(cc.op2), taken_bb, fs, 0);
	else
	    new_oper = gen_ble(&(cc.op1), &(cc.op2), taken_bb, fs, 0);
	break;
    case HC_RET_GT_U:
	if (reverse_cc)
	    new_oper = gen_ble(&(cc.op1), &(cc.op2), taken_bb, fs, 1);
	else
	    new_oper = gen_bgt(&(cc.op1), &(cc.op2), taken_bb, fs, 1);
	break;
    case HC_RET_GE_U:
	if (reverse_cc)
	    new_oper = gen_blt(&(cc.op1), &(cc.op2), taken_bb, fs, 1);
	else
	    new_oper = gen_bge(&(cc.op1), &(cc.op2), taken_bb, fs, 1);
	break;
    case HC_RET_LT_U:
	if (reverse_cc)
	    new_oper = gen_bge(&(cc.op1), &(cc.op2), taken_bb, fs, 1);
	else
	    new_oper = gen_blt(&(cc.op1), &(cc.op2), taken_bb, fs, 1);
	break;
    case HC_RET_LE_U:
	if (reverse_cc)
	    new_oper = gen_bgt(&(cc.op1), &(cc.op2), taken_bb, fs, 1);
	else
	    new_oper = gen_ble(&(cc.op1), &(cc.op2), taken_bb, fs, 1);
	break;
    default:
	HC_simplify(cb, &cc);
	if (reverse_cc)
	    new_oper = gen_beq_0(&(cc.op1), taken_bb, fs);
	else
	    new_oper = gen_bne_0(&(cc.op1), taken_bb, fs);
	break;
    }

    new_oper->attr = HC_gen_if_attr(pragma, expr);
    return (new_oper);
}

static int switch_id = 0;

static void gen_switch(L_Cb *cb, Expr expr, int implement_hash_jump, 
		  char *hash_table_label, int n_cnt, long cnt_cc[], 
		  int cnt_dest[], double cnt_weight[], char cnt_is_default[])
{
    _HC_Ret cc;
    int i, min, max, default_bb;
    double total_weight;
    _HC_Operand Oindex, Omin, Odest;
    L_Oper *new_oper;
    L_Cb *dest_cb;
    L_Attr *new_attr;
    L_Attr *attr= NULL; /* LCW 8/9/95 */

    HC_gen_data(cb, expr, &cc);
    HC_simplify(cb, &cc);
    if (implement_hash_jump) {
	min = 0x1FFFFFFF;
	max = -0x1FFFFFFF;
	default_bb = -1;
	total_weight = 0.0;
	for (i=0; i<n_cnt; i++) {
	    if (cnt_is_default[i]) {
		default_bb = cnt_dest[i];
		continue;
	    }
	    total_weight += cnt_weight[i];
	    if (cnt_cc[i]<min) min = cnt_cc[i];
	    if (cnt_cc[i]>max) max = cnt_cc[i];
	}
	/** generate target address **/
	HC_new_int(&Omin, min, 0);
	HC_new_register(&Oindex, next_reg_id++, M_TYPE_POINTER, 0);
        /* LCW -- transfer the pragmas to attributes  -- 8/3/95 */
        if (expr->pragma != 0)
       	   attr = HC_gen_attr_from_pragma(expr->pragma);
	/* LCW - add an additional argument attr - 8/9/95 */
	HC_gen_sub(cb, &Oindex, &(cc.op1), &Omin, 0, attr);
	HC_new_int(&Omin, H_INT_SIZE/H_CHAR_SIZE, 0);
	HC_dup(&Odest, &Oindex);
	HC_gen_mul(cb, &Odest, &Oindex, &Omin, 0, L_copy_attr(attr));
	HC_dup(&Oindex, &Odest);

	/** check lower bound **/

	new_oper = L_create_new_op(Lop_BLT);
	new_oper->src[0] = HC_operand(&(cc.op1));
	new_oper->src[1] = L_new_gen_int_operand (min);
	if (default_bb == -1)
	    new_oper->src[2] = L_new_gen_int_operand (HC_SWITCH_MISS_ADDRESS);
	else {
	    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
							default_bb);
	    new_oper->src[2] = L_new_cb_operand (dest_cb);
	}
	L_insert_oper_after(cb,cb->last_op,new_oper);

	/** check upper bound **/

	new_oper = L_create_new_op(Lop_BGT);
	new_oper->src[0] = HC_operand(&(cc.op1));
	new_oper->src[1] = L_new_gen_int_operand (max);
	if (default_bb == -1)
	    new_oper->src[2] = L_new_gen_int_operand (HC_SWITCH_MISS_ADDRESS);
	else {
	    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
							default_bb);
	    new_oper->src[2] = L_new_cb_operand (dest_cb);
	}
	L_insert_oper_after(cb,cb->last_op,new_oper);

	/** fetch target address */

	Odest = Oindex;
/*
	fprintf(F, "    (op %d ld_i [", next_oper_id++);
	fprintf(F, "] [(l %s)", hash_table_label);
	HC_operand(F, &Oindex);
	fprintf(F, "])\n");
*/
	new_oper = L_create_new_op(Lop_LD_I);
	new_oper->dest[0] = HC_operand(&Odest);
	new_oper->src[0] = L_new_gen_label_operand (hash_table_label);
	new_oper->src[1] = HC_operand(&Oindex);
	L_insert_oper_after(cb,cb->last_op,new_oper);

	/** generate a jump **/
	if (total_weight >= HC_DEFAULT_FS_MINIMUM) {
	    new_oper = L_create_new_op(Lop_JUMP_RG_FS);
	} else {
	    new_oper = L_create_new_op(Lop_JUMP_RG);
	}
	new_oper->src[0] = HC_operand(&Odest);
	new_oper->src[1] = HC_operand(&(cc.op1));
	L_insert_oper_after(cb,cb->last_op,new_oper);
	
    } else {
	ST_Entry list[HC_MAX_FLOW];
	int n_list, fs;
	default_bb = -1;
	n_list = 0;
	total_weight = 0.0;
	for (i=0; i<n_cnt; i++) {
	    if (cnt_is_default[i]) {
		default_bb = cnt_dest[i];
		continue;
	    }
	    total_weight += cnt_weight[i];
	    list[n_list].ptr = 0;
	    list[n_list].index = i;
	    /* using floating-point weight produces funny
	     * result when the weights are equal.
	     * when weights are the same, we want to
	     * preserve the original order.
	     */
	    list[n_list].weight =  cnt_weight[i] - (0.0001*i);
	    n_list++;
	}
#ifdef OLD
	/** moved to the caller **/
	max_sort(list, n_list);
#endif
	for (i=0; i<n_list; i++) {
	    int index = list[i].index;
	    /** (beq (cc cnt_cc[index] cnt_dest[index])) **/
	    total_weight -= cnt_weight[index];
/**
	    fs = (cnt_weight[index] >= (total_weight+HC_DEFAULT_FS_MINIMUM));
**/
	    fs = 0;	/* just make them unlikely */
	    if (fs) {
	        new_oper = L_create_new_op(Lop_BEQ_FS);
	    } else {
	        new_oper = L_create_new_op(Lop_BEQ);
	    }
	    new_oper->src[0] = HC_operand(&(cc.op1));
	    if (L_propagate_sign_size_ctype_info)
	      new_oper->src[1] = L_new_int_operand (cnt_cc[index], new_oper->src[0]->ctype);
	    else
	      new_oper->src[1] = L_new_gen_int_operand (cnt_cc[index]);
	    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
							cnt_dest[index]);
	    new_oper->src[2] = L_new_cb_operand (dest_cb);
	    L_insert_oper_after(cb,cb->last_op,new_oper);

	    /* Add a "SWITCH" attribute to these branches, so the branch
	     * predictor will know that these branches are associated with a
	     * switch statement. */
	    if (HL_generate_static_branch_attrs) {
		new_attr = L_new_attr ("SWITCH", 1);
		L_set_int_attr_field (new_attr, 0, switch_id);
		new_oper->attr = L_concat_attr (new_attr, new_oper->attr);
	    }
	}
	switch_id++;
	fs = total_weight >= HC_DEFAULT_FS_MINIMUM;
	if (default_bb==-1) {
	    if (fs)
	        new_oper = L_create_new_op(Lop_JUMP_FS);
	    else
	        new_oper = L_create_new_op(Lop_JUMP);
	    new_oper->src[0] = L_new_gen_int_operand (HC_SWITCH_MISS_ADDRESS);
	    L_insert_oper_after(cb,cb->last_op,new_oper);
	} else {
	    if (fs)
	        new_oper = L_create_new_op(Lop_JUMP_FS);
	    else
	        new_oper = L_create_new_op(Lop_JUMP);
	    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl,
							default_bb);
	    new_oper->src[0] = L_new_cb_operand (dest_cb);
	    L_insert_oper_after(cb,cb->last_op,new_oper);
	}
    }
}
/*---------------------------------------------------------------------------*/
static int gen_return(L_Cb *cb, Expr expr)
		/* no need to generate control flow */
{
    _HC_Ret cc;
    _M_Type mtype;
    _HC_Operand dest, src;
    Expr reduced;
    char line[64];
    if (expr==0) 
	return (0);
    HC_hcode2lcode_type(return_type, &mtype);
    if (mtype.type==M_TYPE_VOID)
	return (0);
    reduced = HC_ReduceExpr(expr);
    if (return_structure) {
    	HC_gen_addr(cb, reduced, &cc);
    	HC_simplify(cb, &cc);
	HC_new_register(&dest, return_addr_reg, M_TYPE_POINTER, 0);
	HC_gen_block_mov(cb, expr, &dest, 0, &(cc.op1), 0, &mtype, 0);
	src = dest;
	sprintf(line, "$P%d", M_return_register(M_TYPE_POINTER, M_PUT_FNVAR));
	HC_new_macro(&dest, C_findstr(line), M_TYPE_POINTER, 0);
	HC_gen_mov(cb, &dest, &src, 0);
    } else {
    	HC_gen_data(cb, reduced, &cc);
    	HC_simplify(cb, &cc);
	sprintf(line, "$P%d", M_return_register(mtype.type, M_PUT_FNVAR));
	HC_new_macro(&dest, C_findstr(line), mtype.type, mtype.unsign);
	HC_gen_mov(cb, &dest, &(cc.op1), 0);
    }
    RemoveExpr(reduced);
	/* DMG - return (1) means a return value was generated */
    return (1);
}
static void gen_expr(L_Cb *cb, Expr expr)
{
    _HC_Ret cc;
    Expr reduced;
    if (expr==0) return;
    reduced = HC_ReduceExpr(expr);
    HC_gen_data(cb, reduced, &cc);
    HC_simplify(cb, &cc);
    RemoveExpr(reduced);
}
/*---------------------------------------------------------------------------*/
/*
 *	BRANCH GENERATION.
 */
static int eval_mtype(int type)	/* in register */
{
    switch (type) {
    case M_TYPE_FLOAT:
	return M_TYPE_FLOAT;
    case M_TYPE_DOUBLE:
	return M_TYPE_DOUBLE;
    case M_TYPE_VOID:	
    case M_TYPE_BIT_LONG:
/* REH 9/15/93 */
    case M_TYPE_BIT_SHORT:
/* HER */
    case M_TYPE_BIT_CHAR:
    case M_TYPE_CHAR:
    case M_TYPE_SHORT:
    case M_TYPE_INT:
    case M_TYPE_LONG:
    case M_TYPE_POINTER:
    case M_TYPE_UNION:
    case M_TYPE_STRUCT:
    case M_TYPE_BLOCK:
    default:
	return M_TYPE_INT;
    }
}
static L_Oper *gen_beq_0(HC_Operand op, int target, int fs)
{
    L_Oper *new_oper;
    L_Cb *dest_cb;
    int type = eval_mtype(op->data_type);

    if (fs) {
	switch (type) {
	case M_TYPE_FLOAT:
	    new_oper = L_create_new_op(Lop_BEQ_F_FS);
	    break;
	case M_TYPE_DOUBLE:
	    new_oper = L_create_new_op(Lop_BEQ_F2_FS);
	    break;
	default:
	    new_oper = L_create_new_op(Lop_BEQ_FS);
	    break;
	}
    } else {
	switch (type) {
	case M_TYPE_FLOAT:
	    new_oper = L_create_new_op(Lop_BEQ_F);
	    break;
	case M_TYPE_DOUBLE:
	    new_oper = L_create_new_op(Lop_BEQ_F2);
	    break;
	default:
	    new_oper = L_create_new_op(Lop_BEQ);
	    break;
	}
    }
    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, target);
    new_oper->src[0] = HC_operand(op);

    if (L_propagate_sign_size_ctype_info) {
      switch (type) {
      case M_TYPE_FLOAT :
        new_oper->src[1] = L_new_float_operand((float)0.0);
	break;
      case M_TYPE_DOUBLE :
        new_oper->src[1] = L_new_double_operand(0.0);
	break;
      case M_TYPE_CHAR :
	if (op->unsign)
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_UCHAR); 
	else
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_CHAR); 
	break;
      case M_TYPE_SHORT :
	if (op->unsign)
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_USHORT); 
	else
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_SHORT); 
	break;
      case M_TYPE_INT :
	if (op->unsign)
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_UINT); 
	else
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_INT); 
	break;
      case M_TYPE_LONG :
	if (op->unsign)
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_ULONG); 
	else
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_LONG); 
	break;
      case M_TYPE_POINTER :
	new_oper->src[1] = L_new_int_operand(0, L_CTYPE_POINTER); 
	break;
      default :
	L_warn("gen_beq_0 : unknown mtype %d", type);
	break;
      }
    }
    else {
      switch (type) {
      case M_TYPE_FLOAT:
	/* BCC - using float type argument - 8/22/96 */  
        new_oper->src[1] = L_new_float_operand((float)0.0);
	break;
      case M_TYPE_DOUBLE:
        new_oper->src[1] = L_new_double_operand(0.0);
	break;
      default:
        new_oper->src[1] = L_new_gen_int_operand(0);
	break;
      }
    }
    new_oper->src[2] = L_new_cb_operand (dest_cb);

    return (new_oper);
}
static L_Oper *gen_bne_0(HC_Operand op, int target, int fs)
{
    L_Oper *new_oper;
    L_Cb *dest_cb;
    int type = eval_mtype(op->data_type);
    if (fs) {
	switch (type) {
	case M_TYPE_FLOAT:
	    new_oper = L_create_new_op(Lop_BNE_F_FS);
	    break;
	case M_TYPE_DOUBLE:
	    new_oper = L_create_new_op(Lop_BNE_F2_FS);
	    break;
	default:
	    new_oper = L_create_new_op(Lop_BNE_FS);
	    break;
	}
    } else {
	switch (type) {
	case M_TYPE_FLOAT:
	    new_oper = L_create_new_op(Lop_BNE_F);
	    break;
	case M_TYPE_DOUBLE:
	    new_oper = L_create_new_op(Lop_BNE_F2);
	    break;
	default:
	    new_oper = L_create_new_op(Lop_BNE);
	    break;
	}
    }
    new_oper->src[0] = HC_operand(op);

    if (L_propagate_sign_size_ctype_info) {
      switch (type) {
      case M_TYPE_FLOAT :
        new_oper->src[1] = L_new_float_operand((float)0.0);
	break;
      case M_TYPE_DOUBLE :
        new_oper->src[1] = L_new_double_operand(0.0);
	break;
      case M_TYPE_CHAR :
	if (op->unsign)
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_UCHAR); 
	else
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_CHAR); 
	break;
      case M_TYPE_SHORT :
	if (op->unsign)
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_USHORT); 
	else
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_SHORT); 
	break;
      case M_TYPE_INT :
	if (op->unsign)
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_UINT); 
	else
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_INT); 
	break;
      case M_TYPE_LONG :
	if (op->unsign)
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_ULONG); 
	else
	  new_oper->src[1] = L_new_int_operand(0, L_CTYPE_LONG); 
	break;
      case M_TYPE_POINTER :
	new_oper->src[1] = L_new_int_operand(0, L_CTYPE_POINTER); 
	break;
      default :
	L_warn("gen_beq_0 : unknown mtype %d", type);
	break;
      }
    }
    else {
      switch (type) {
      case M_TYPE_FLOAT:
	/* BCC - using float type argument - 8/22/96 */ 
        new_oper->src[1] = L_new_float_operand((float)0.0);
	break;
      case M_TYPE_DOUBLE:
        new_oper->src[1] = L_new_double_operand(0.0);
	break;
      default:
        new_oper->src[1] = L_new_gen_int_operand(0);
	break;
      }
    }
    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, target);
    new_oper->src[2] = L_new_cb_operand (dest_cb);

    return (new_oper);
}

static L_Oper *gen_beq(HC_Operand op1, HC_Operand op2, 
			int target, int fs)
{
    L_Oper *new_oper;
    L_Cb *dest_cb;
    int type = eval_mtype(op1->data_type);
    if (fs) {
	switch (type) {
	case M_TYPE_FLOAT:
	    new_oper = L_create_new_op(Lop_BEQ_F_FS);
	    break;
	case M_TYPE_DOUBLE:
	    new_oper = L_create_new_op(Lop_BEQ_F2_FS);
	    break;
	default:
	    new_oper = L_create_new_op(Lop_BEQ_FS);
	    break;
	}
    } else {
	switch (type) {
	case M_TYPE_FLOAT:
	    new_oper = L_create_new_op(Lop_BEQ_F);
	    break;
	case M_TYPE_DOUBLE:
	    new_oper = L_create_new_op(Lop_BEQ_F2);
	    break;
	default:
	    new_oper = L_create_new_op(Lop_BEQ);
	    break;
	}
    }
    new_oper->src[0] = HC_operand(op1);
    new_oper->src[1] = HC_operand(op2);
    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, target);
    new_oper->src[2] = L_new_cb_operand (dest_cb);

    return (new_oper);
}
static L_Oper *gen_bne(HC_Operand op1, HC_Operand op2, int target, 
			int fs)
{
    L_Oper *new_oper;
    L_Cb *dest_cb;
    int type = eval_mtype(op1->data_type);
    if (fs) {
	switch (type) {
	case M_TYPE_FLOAT:
            new_oper = L_create_new_op(Lop_BNE_F_FS);
	    break;
	case M_TYPE_DOUBLE:
            new_oper = L_create_new_op(Lop_BNE_F2_FS);
	    break;
	default:
            new_oper = L_create_new_op(Lop_BNE_FS);
	    break;
	}
    } else {
	switch (type) {
	case M_TYPE_FLOAT:
            new_oper = L_create_new_op(Lop_BNE_F);
	    break;
	case M_TYPE_DOUBLE:
            new_oper = L_create_new_op(Lop_BNE_F2);
	    break;
	default:
            new_oper = L_create_new_op(Lop_BNE);
	    break;
	}
    }
    new_oper->src[0] = HC_operand(op1);
    new_oper->src[1] = HC_operand(op2);
    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, target);
    new_oper->src[2] = L_new_cb_operand (dest_cb);

    return (new_oper);
}
/*---------------------------------------------------------------------------*/
static L_Oper *gen_ble(HC_Operand op1, HC_Operand op2, int target, 
		int fs, int unsign)
{
    L_Oper *new_oper;
    L_Cb *dest_cb;
    int type = eval_mtype(op1->data_type);
    switch (type) {
    case M_TYPE_FLOAT:
	if (fs) {
            new_oper = L_create_new_op(Lop_BLE_F_FS);
	} else {
            new_oper = L_create_new_op(Lop_BLE_F);
	}
	break;
    case M_TYPE_DOUBLE:
	if (fs) {
            new_oper = L_create_new_op(Lop_BLE_F2_FS);
	} else {
            new_oper = L_create_new_op(Lop_BLE_F2);
	}
	break;
    default:
	if (fs) {
	    if (!unsign)
                new_oper = L_create_new_op(Lop_BLE_FS);
	    else
                new_oper = L_create_new_op(Lop_BLE_U_FS);
	} else {
	    if (!unsign)
                new_oper = L_create_new_op(Lop_BLE);
	    else
                new_oper = L_create_new_op(Lop_BLE_U);
	}
	break;
    }
    new_oper->src[0] = HC_operand(op1);
    new_oper->src[1] = HC_operand(op2);
    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, target);
    new_oper->src[2] = L_new_cb_operand (dest_cb);

    return (new_oper);
}
/*---------------------------------------------------------------------------*/
static L_Oper *gen_blt(HC_Operand op1, HC_Operand op2, int target, 
                int fs, int unsign)
{
    L_Oper *new_oper;
    L_Cb *dest_cb;
    int type = eval_mtype(op1->data_type);
    switch (type) {
    case M_TYPE_FLOAT:
	if (fs) {
            new_oper = L_create_new_op(Lop_BLT_F_FS);
	} else {
            new_oper = L_create_new_op(Lop_BLT_F);
	}
	break;
    case M_TYPE_DOUBLE:
	if (fs) {
            new_oper = L_create_new_op(Lop_BLT_F2_FS);
	} else {
            new_oper = L_create_new_op(Lop_BLT_F2);
	}
	break;
    default:
	if (fs) {
	    if (!unsign)
                new_oper = L_create_new_op(Lop_BLT_FS);
	    else
                new_oper = L_create_new_op(Lop_BLT_U_FS);
	} else {
	    if (!unsign)
                new_oper = L_create_new_op(Lop_BLT);
	    else
                new_oper = L_create_new_op(Lop_BLT_U);
	}
	break;
    }
    new_oper->src[0] = HC_operand(op1);
    new_oper->src[1] = HC_operand(op2);
    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, target);
    new_oper->src[2] = L_new_cb_operand (dest_cb);

    return (new_oper);
}
/*---------------------------------------------------------------------------*/
static L_Oper *gen_bge(HC_Operand op1, HC_Operand op2, int target, 
                int fs, int unsign)
{
    L_Oper *new_oper;
    L_Cb *dest_cb;
    int type = eval_mtype(op1->data_type);
    switch (type) {
    case M_TYPE_FLOAT:
	if (fs) {
            new_oper = L_create_new_op(Lop_BGE_F_FS);
	} else {
            new_oper = L_create_new_op(Lop_BGE_F);
	}
	break;
    case M_TYPE_DOUBLE:
	if (fs) {
            new_oper = L_create_new_op(Lop_BGE_F2_FS);
	} else {
            new_oper = L_create_new_op(Lop_BGE_F2);
	}
	break;
    default:
	if (fs) {
	    if (!unsign)
                new_oper = L_create_new_op(Lop_BGE_FS);
	    else
                new_oper = L_create_new_op(Lop_BGE_U_FS);
	} else {
	    if (!unsign)
                new_oper = L_create_new_op(Lop_BGE);
	    else
                new_oper = L_create_new_op(Lop_BGE_U);
	}
	break;
    }
    new_oper->src[0] = HC_operand(op1);
    new_oper->src[1] = HC_operand(op2);
    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, target);
    new_oper->src[2] = L_new_cb_operand (dest_cb);

    return (new_oper);
}
/*---------------------------------------------------------------------------*/
static L_Oper *gen_bgt(HC_Operand op1, HC_Operand op2, int target, 
                int fs, int unsign)
{
    L_Oper *new_oper;
    L_Cb *dest_cb;
    int type = eval_mtype(op1->data_type);
    switch (type) {
    case M_TYPE_FLOAT:
	if (fs) {
            new_oper = L_create_new_op(Lop_BGT_F_FS);
	} else {
            new_oper = L_create_new_op(Lop_BGT_F);
	}
	break;
    case M_TYPE_DOUBLE:
	if (fs) {
            new_oper = L_create_new_op(Lop_BGT_F2_FS);
	} else {
            new_oper = L_create_new_op(Lop_BGT_F2);
	}
	break;
    default:
	if (fs) {
	    if (!unsign)
                new_oper = L_create_new_op(Lop_BGT_FS);
	    else
                new_oper = L_create_new_op(Lop_BGT_U_FS);
	} else {
	    if (!unsign)
                new_oper = L_create_new_op(Lop_BGT);
	    else
                new_oper = L_create_new_op(Lop_BGT_U);
	}
	break;
    }
    new_oper->src[0] = HC_operand(op1);
    new_oper->src[1] = HC_operand(op2);
    dest_cb = L_cb_hash_tbl_find_and_alloc (L_fn->cb_hash_tbl, target);
    new_oper->src[2] = L_new_cb_operand (dest_cb);

    return (new_oper);
}
/*----------------------------------------------------------------------------*/
