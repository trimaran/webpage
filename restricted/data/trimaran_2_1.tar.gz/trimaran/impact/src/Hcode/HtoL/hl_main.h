/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.10  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Apr. 12, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File:	hl_main.h
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Creation Date:	June, 1990
 *	Revised: Dave Gallagher, Scott Mahlke - 6/94
 *              Build Lcode structure rather than just printing out text file
 *	Modified: Le-Chun Wu -- 8/8/95
 *	        Add a formal parameter "attr1" to most of the HC_gen_xxx 
 *		functions so that Hcode pragma (debugging information) can be
 *		passed to Lcode.
\*****************************************************************************/
#ifndef HL_MAIN_H
#define HL_MAIN_H
#include <Hcode/h_main.h>
#include <Lcode/l_main.h>

/*========================================================================*/
/*
 *	Parameters for HtoL 
 */
/*========================================================================*/

extern int HL_do_flatten;
extern int HL_generate_hashing_branches;
extern int HL_ignore_hash_profile_weight;
extern int HL_ignore_hash_br_seq_weight;
extern int HL_generate_abs_instructions;
extern int HL_generate_sync_arcs;
extern int HL_generate_label_attrs;
extern int HL_generate_static_branch_attrs;
extern int HL_generate_acc_name_attrs;
extern int HL_verbose_yes;
extern int HL_retain_sync_nums;
extern int HL_debug_sync_arcs;
extern int HL_gen_bit_field_operations;
extern int HL_generate_sign_extend_operations;
extern int HL_use_subroutine_call;
/* LCW - emit source information - 8/5/97 */
extern int HL_emit_source_info;
/* Allow emitting of subset of source info that Lemulate needs -ITI/JCG 4/99 */
extern int HL_emit_data_type_info;

/*------------------------------------------------------------------------*/
/*
 *	SOME USEFUL FUNCTIONS USED INTERNALLY BY LCODE GENERATOR.
 */
extern void HC_hcode2lcode_type(Type, M_Type);

extern void HC_struct_info(char *, int *, int*);
extern void HC_union_info(char *, int *, int *);

extern void HC_struct_field_info(char *sname, char *fname, long *offset, 
    M_Type mtype, int *is_bit, int *bit_offset, long *bit_mask, int *length);
extern void HC_union_field_info(char *sname, char *fname, long *offset, 
    M_Type mtype, int *is_bit, int *bit_offset, long *bit_mask, int *length);


/*
 *	Be aware that Mtype specifies size and align in bits.
 *	Also the alignment of bit fields is not adjusted to
 *	integer operations. 
 */

extern char *HC_typename();		/* (int type) */
extern char *HC_typename2();		/* (int type) */

/*------------------------------------------------------------------------*/
/*
 *	Struct fields.
 */
#define HC_MAX_STRUCT		2048
#define HC_MAX_STRUCT_FIELD	256
#define HC_MAX_UNION		2048
#define HC_MAX_UNION_FIELD	512	/* BCC - 4/14/96 - from 256 to 512 */

/*
 *	Allow HCODE files to be nested by (include)
 *	statements.
 */
#define HC_EXPAND_INCLUDE_FILE		1

/*========================================================================*/
/** h_lcode_data.c **/
#define HC_DEFAULT_LABEL	"_"

/*========================================================================*/
/** h_lcode_func.c **/

#define HC_MAX_BB		5120
#define HC_MAX_LOCAL_VAR	3072
#define HC_MAX_PARAM_VAR	128
#define HC_MAX_FLOW		1024

/*
 *	Do not want to allocate branch slots for
 *	infrequently executed branches.
 */
#define HC_DEFAULT_FS_MINIMUM		50.0

/*
 *	The compiler must decide when to use hashing jump
 *	to implement a switch.
 */
#define ALLOW_HASH_TABLE
#define ASSUME_HCODE_PROFILE

#ifdef ALLOW_HASH_TABLE
#ifdef ASSUME_HCODE_PROFILE
#define HC_MIN_HASH_JUMP_WEIGHT		5.0 
#else
#define HC_MIN_HASH_JUMP_WEIGHT		0.0 		/* always */
#endif
#else
#define HC_MIN_HASH_JUMP_WEIGHT		0x1FFFFFFF	/* never */
#endif
#define HC_MAX_BR_SEQUENCE_WEIGHT	6.0
#define HC_MIN_HASH_JUMP_CASE		5
#define HC_MAX_HASH_JUMP_SIZE		512
#define HC_SWITCH_MISS_ADDRESS		-1

extern int HC_next_oper_id();		/* () */
extern int HC_next_reg_id();		/* () */
extern int HC_bb_id(Block bb);		/* (bb) */

extern int HC_find_local_var(char *name, M_Type mtype, int *in_reg, int *reg_id,
                        char **base_macro, int *offset);
extern int HC_find_param_var(char *name, M_Type mtype, int *in_reg, int *reg_id,
                        char **base_macro, int *offset);

/* (name, mtype, in_reg, reg_id, base_macro, offset) */

/*-----------------------------------------------------------------------*/
#define HC_CB		1
#define HC_R		2
#define HC_L		3
#define HC_I		4
#define HC_F		5
#define HC_F2		6
#define HC_S		7
#define HC_MAC		8

typedef struct {
	short		type;
	short		data_type;
        int           unsign;
	union {
	int		cb;		/* basic block id */
	int		r;		/* register index */
	char		*l;		/* label name */
	Integer		i;		/* integer value */
/*** SAM 9-24-91
	Float		f;
***/
	Double		f;		/* single-precision */
	Double		f2;		/* double-precision */
	char		*s;		/* string */
	char		*mac;		/* macro */
	}		value;
} _HC_Operand, *HC_Operand;

/*-----------------------------------------------------------------------*/
/*
 *	The code generation function has a complex recursive structure.
 *	For each node, we generate appropriate code, and return a value.
 *	It is desirable to sometimes look at several nodes and perhaps
 *	combine a few terms. We aim to generate good assembly code in order
 *	to alleviate the later RTL optimization.
 */
#define HC_RET_NONE	0	/* result = 0 */
#define HC_RET_SIMPLE	1	/* result = op1 */
#define HC_RET_ADD	2	/* result = op1 + op2 (unsigned integer) */
#define HC_RET_SUB	3	/* result = op1 - op2 (unsigned integer) */
#define HC_RET_OR	4	/* result = op1 | op2 */
#define HC_RET_AND	5	/* result = op1 & op2 */
#define HC_RET_XOR	6	/* result = op1 ^ op2 */
#define HC_RET_EQ	7	/* result = op1 == op2 */
#define HC_RET_NE	8	/* result = op1 != op2 */
#define HC_RET_GT	9	/* result = op1 > op2 */
#define HC_RET_GT_U	10	/* result = op1 > op2 */
#define HC_RET_GE	11	/* result = op1 >= op2 */
#define HC_RET_GE_U	12	/* result = op1 >= op2 */
#define HC_RET_LT	13	/* result = op1 < op2 */
#define HC_RET_LT_U	14	/* result = op1 < op2 */
#define HC_RET_LE	15	/* result = op1 <= op2 */
#define HC_RET_LE_U	16	/* result = op1 <= op2 */

typedef struct _HC_Ret {
	short		type;
	_HC_Operand	op1;
	_HC_Operand	op2;
} _HC_Ret, *HC_Ret;

/*
 *	Substantially more operations are required when operating
 *	on bit fields. Need the following information, in addition
 *	to the starting address (GenerateAddr) of a structure field,
 *	for reading and writing bit fields.
 */
#if 0
extern short 	HC_is_bit_field;
extern int 	HC_bit_field_shift;
extern long 	HC_bit_field_mask;
#endif

/*-----------------------------------------------------------------------*/
/*
 *	In order to preserve correct profile weight,
 *	we need to record before generating each
 *	basic block the current profile weight.
 */
extern double	HC_profile_weight;

/*========================================================================*/
/*
 *	SPECIAL FUNCTIONS.
 */
#define HCfn_SELECT_I			"__I_select_i__"
#define HCfn_SELECT_F			"__I_select_f__"
#define HCfn_SELECT_F2			"__I_select_f2__"
#define HCfn_REV			"__I_rev__"
#define HCfn_BIT_POS			"__I_bit_pos__"
#define HCfn_ABS_I			"__I_abs_i__"
#define HCfn_ABS_F			"__I_abs_f__"
#define HCfn_ABS_F2			"__I_abs_f2__"
#define HCfn_CO_PROC			"__I_coproc__"
#define HCfn_FETCH_AND_ADD		"__I_fetch_add__"
#define HCfn_FETCH_AND_OR		"__I_fetch_or__"
#define HCfn_FETCH_AND_AND		"__I_fetch_and__"
#define HCfn_FETCH_AND_ST		"__I_fetch_st__"
#define HCfn_FETCH_AND_COND_ST		"__I_fetch_cond_st__"

/*========================================================================*/

/*========================================================================*/

typedef struct L_Tail_List {
    L_Oper              *tail_oper;
    struct L_Tail_List  *next_list;
} L_Tail_List;


typedef struct L_Sync_Hash {
    int                 num;
    L_Oper              *head_oper;
    L_Tail_List         *tail_list;
    struct L_Sync_Hash  *next_hash;
} L_Sync_Hash;


/*========================================================================*/
/** h_lcode.c **/
/*
 *	EXPORT VARIABLES & FUNCTIONS.
 */
extern int H_gen_lcode;
extern L_Alloc_Pool *L_alloc_sync_hash;
extern L_Alloc_Pool *L_alloc_tail_list;

extern void H_gen_lcode_include(char *);
extern void H_gen_lcode_struct(L_Datalist *, StructDcl);
extern void H_gen_lcode_union(L_Datalist *, UnionDcl);
extern void H_gen_lcode_enum(L_Datalist *,EnumDcl);
extern void H_gen_lcode_var(L_Datalist *, VarDcl);
extern void H_gen_lcode_func(FuncDcl);

extern int H_lcode_typesize(Type);
extern int H_lcode_enum_value(char *);

extern int HC_is_function(char *fn_name);
extern int HC_is_not_function(char *fn_name);

extern void HC_ms(L_Datalist *list, char *name);
extern void HC_invalidate_last_ms(void);
extern void HC_gen_var(L_Datalist *list, VarDcl var);

extern int HC_find_local_var(char *name, M_Type mtype, int *in_reg, 
			int *reg_id, char **base_macro, int *offset);
extern int HC_find_param_var(char *name, M_Type mtype, int *in_reg, 
			int *reg_id, char **base_macro, int *offset);
extern int HC_bb_id(Block bb);
extern void HC_gen_func(FuncDcl fn);
extern char *HC_read_attr_name_from_pragma_str(char *pragmastr, char *name);
extern char *HC_read_attr_field_from_pragma_str(char *pragmastr, char *string,
					      long int *integer, double *real,
					      char **delim_type);

extern L_Attr *HC_gen_attr_from_pragma(Pragma pragma);
extern L_Attr *HC_gen_attr(char *name, int value);
extern int HC_uses_pointer_operand(Expr expr);
extern L_Attr *HC_gen_pointer_attr(Expr expr);
extern L_Attr *HC_gen_if_attr(Pragma pragma, Expr expr);


extern void HC_ret_mulC(L_Cb *cb, HC_Ret ret, int n);
extern void _ret_add(FILE *F, HC_Ret sum, HC_Ret x, HC_Ret y);
extern void HC_simplify(L_Cb *cb, HC_Ret ret);
extern int gen_var_addr(L_Cb *cb, Expr expr, HC_Ret ret);
extern int is_addr_expr(Expr expr);
extern int HC_gen_addr(L_Cb *cb, Expr expr, HC_Ret ret);
extern void HC_gen_data(L_Cb *cb, Expr expr, HC_Ret ret);

extern int HC_register_type(int type);
extern void HC_dup(HC_Operand op1, HC_Operand op2);
extern void HC_new_register(HC_Operand op, int reg_id, int type, int unsign);
extern void HC_new_cb(HC_Operand op, int cb_id);
extern void HC_new_label(HC_Operand op, char *label);
extern void HC_new_macro(HC_Operand op, char *name, int type, int unsign);
extern void HC_new_char(HC_Operand op, long value, int unsign);
extern void HC_new_short(HC_Operand op, long value, int unsign);
extern void HC_new_int(HC_Operand op, long value, int unsign);
extern void HC_new_long(HC_Operand op, long value, int unsign);
extern void HC_new_pointer(HC_Operand op, long value);
extern void HC_new_float(HC_Operand op, double value);
extern void HC_new_double(HC_Operand op, double value);
extern void HC_new_string(HC_Operand op, char *str);
extern char *HC_typename(int type);
extern char *HC_typename2(int type, int unsign);
extern L_Operand *HC_operand(HC_Operand op);
extern void HC_gen_block_mov(L_Cb *cb, Expr expr,HC_Operand dest, int dest_offset,
                 HC_Operand src, int src_offset, M_Type mtype, L_Attr *attr1);
extern void HC_gen_mov(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1);
extern void HC_gen_load(L_Cb *cb, Expr expr, HC_Operand dest, HC_Operand src1,
                HC_Operand src2, int unsign, L_Attr *attr1);
extern void HC_gen_store(L_Cb *cb, Expr expr, HC_Operand src1, HC_Operand src2,
                HC_Operand src3, int data_type, L_Attr *attr1);
extern void HC_gen_add(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
                int unsign, L_Attr *attr1);
extern void HC_gen_sub(L_Cb *cb, HC_Operand dest, HC_Operand src1,
                                HC_Operand src2, int unsign, L_Attr *attr1);
extern void HC_gen_mul(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
                                int unsign, L_Attr *attr1);
extern void HC_gen_div(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
                                        int unsign, L_Attr *attr1);
extern void HC_gen_mod(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
                                        int unsign, L_Attr *attr1);
extern void HC_gen_abs(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1);
extern void HC_gen_or(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, L_Attr *attr1);
extern void HC_gen_and(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, L_Attr *attr1);
extern void HC_gen_xor(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, L_Attr *attr1);
extern void HC_gen_lsl(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, L_Attr *attr1);
extern void HC_gen_lsr(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, L_Attr *attr1);
extern void HC_gen_asr(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, L_Attr *attr1);
extern void HC_gen_extract_bits(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, HC_Operand src3);
extern void HC_gen_deposit_bits(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, HC_Operand src3, HC_Operand src4);
extern void HC_gen_eq(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, Expr operand_expr, L_Attr *attr1);
extern void HC_gen_ne(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2, L_Attr *attr1);
extern void HC_gen_lt(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
                                int unsign, L_Attr *attr1);
extern void HC_gen_le(L_Cb *cb, HC_Operand dest, HC_Operand src1, HC_Operand src2,
                                        int unsign, L_Attr *attr1);
extern void HC_gen_ge(L_Cb *cb,HC_Operand dest,HC_Operand src1, HC_Operand src2, 
					int unsign, L_Attr *attr1);
extern void HC_gen_gt(L_Cb *cb, HC_Operand dest,HC_Operand src1,HC_Operand src2, 
					int unsign, L_Attr *attr1);
extern void HC_gen_f2_f(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1);
extern void HC_gen_i_f(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1);
extern void HC_gen_f_f2(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1);
extern void HC_gen_i_f2(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1);
extern void HC_gen_f2_i(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1);
extern void HC_gen_f_i(L_Cb *cb, HC_Operand dest, HC_Operand src1, L_Attr *attr1);
extern void HC_gen_alloc(L_Cb *cb, HC_Operand dest, int size, int align);
extern void HC_gen_jsr(L_Cb *cb, Expr expr, HC_Operand src, 
				int argc, L_Attr *attr1);
extern void HC_gen_lcode_select_i(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_select_f(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_select_f2(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_rev(L_Cb *cb, HC_Operand dest,
		_HC_Operand src[], int n_src);
extern void HC_gen_lcode_bit_pos(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_abs_i(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_abs_f(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_abs_f2(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_co_proc(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_fetch_add(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_fetch_or(L_Cb *cb, HC_Operand dest,
                _HC_Operand src[], int n_src);
extern void HC_gen_lcode_fetch_and(L_Cb *cb, HC_Operand dest,
		_HC_Operand src[], int n_src);
extern void HC_gen_lcode_fetch_st(L_Cb *cb, HC_Operand dest,
                        _HC_Operand src[], int n_src);
extern void HC_gen_lcode_fetch_cond_st(L_Cb *cb,HC_Operand dest,
                        _HC_Operand src[],int n_src);

/* LCW - added some functions for preserving debugging information - 4/15/96 */
extern void HC_gen_struct(L_Datalist *list, StructDcl st);
extern void HC_gen_union(L_Datalist *list, UnionDcl un);
extern void HC_gen_enum(L_Datalist *list, EnumDcl en);
extern L_Type *L_gen_type(Type htype);
extern L_Dcltr *L_gen_dcltr(Dcltr hdcltr);

extern L_Datalist *L_datalist;
extern L_Datalist *L_hash_datalist;

extern Expr HC_ReduceExpr (Expr expr);

extern int IsPointerType();
extern int IsStructureType();
extern void Gen_C_Expr();
extern void Gen_C_Type();

extern void HC_gen_dep_arcs (L_Oper *oper, Expr expr, HC_Operand src1, 
			HC_Operand src2, int is_store);

extern void L_remove_redundant_sync_numbers (L_Func *fn);
extern void L_rename_sync_arcs(L_Func *fn);

/* BCC - used for reducing cast - 6/8/95 */
extern int H_CHAR_SIZE;
extern int H_SHORT_SIZE;
extern int H_INT_SIZE;
extern int H_LONG_SIZE;

extern unsigned long H_UNSIGNED_CHAR_MASK;
extern unsigned long H_UNSIGNED_SHORT_MASK;
extern unsigned long H_UNSIGNED_INT_MASK;

#endif
