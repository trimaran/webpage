/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*****************************************************************************\
 *	File :		l_codegen.c
 *	Description :	pseudo main routine - all Lcode modules should have
 *			a set of functions with similar functionality
 *	Author:	Po-hua Chang, Wen-mei Hwu
 *	Creation Date:	June 1990
\*****************************************************************************/
#include <Lcode/l_main.h>

/* Parameters local to Lcode executable */
int Lcode_echo = 0;
int Lcode_print_stat = 0;
int Lcode_unit_time = 0;
int Lcode_run_df_live_variable = 0;
int Lcode_run_df_print_pred_flow = 0;
int Lcode_run_loop_detection = 0;

static void process_input(void)
{
  Set set;

    switch (L_token_type) {
    case L_INPUT_EOF:
    case L_INPUT_MS:
    case L_INPUT_VOID:
    case L_INPUT_BYTE:
    case L_INPUT_WORD:
    case L_INPUT_LONG:
    case L_INPUT_FLOAT:
    case L_INPUT_DOUBLE:
    case L_INPUT_ALIGN:
    case L_INPUT_ASCII:
    case L_INPUT_ASCIZ:
    case L_INPUT_RESERVE:
    case L_INPUT_GLOBAL:
    case L_INPUT_WB:
    case L_INPUT_WW:
    case L_INPUT_WI:
    case L_INPUT_WF:
    case L_INPUT_WF2:
    case L_INPUT_WS:
    case L_INPUT_ELEMENT_SIZE:
    case L_INPUT_DEF_STRUCT:  /* Folded in SAM fix.  -JCG 5/99 */
    case L_INPUT_DEF_UNION:
    case L_INPUT_DEF_ENUM:
    case L_INPUT_FIELD:
    case L_INPUT_ENUMERATOR:
        if (Lcode_echo)
            L_print_data(L_OUT, L_data);
	L_delete_data(L_data);
        break;
    case L_INPUT_EVENT_LIST:
	if (Lcode_echo)
	    L_print_event_list(L_OUT,L_event_list);
	L_delete_event_list(L_event_list);
	break;
    case L_INPUT_RESULT_LIST:
	if (Lcode_echo)
	    L_print_result_list(L_OUT,L_result_list);
	L_delete_event_list(L_result_list);
	break;
    case L_INPUT_FUNCTION:
    	if (Lcode_print_stat)
	    L_record_stat(L_fn);

	/* Testing options for Lcode executable */
 	if (Lcode_run_df_live_variable) {
	  L_do_flow_analysis(L_fn, POST_DOMINATOR_CB | LIVE_VARIABLE);
	}

	/* Testing options for Lcode executable */
 	if (Lcode_run_df_print_pred_flow) {
	  PG_test_partition_graph(L_fn);
	}	

	if (Lcode_run_loop_detection) {
	    L_do_flow_analysis(L_fn, DOMINATOR);
	    L_loop_detection(L_fn, 0);
	}

        if (Lcode_echo)
            L_print_func(L_OUT, L_fn);
	L_delete_func(L_fn);

        break;
    default:
        L_punt("process_input: illegal token");
    }
}

/*
 *	Read module specific parameters
 */
void L_read_parm_lcode (Parm_Parse_Info *ppi)
{
    L_read_parm_b(ppi, "echo", &Lcode_echo);
    L_read_parm_b(ppi, "print_stat", &Lcode_print_stat);
    L_read_parm_b(ppi, "unit_time", &Lcode_unit_time); 
    L_read_parm_b(ppi, "run_df_live_variable", &Lcode_run_df_live_variable); 
    L_read_parm_b(ppi, "run_df_print_pred_flow", &Lcode_run_df_print_pred_flow);
    L_read_parm_b(ppi, "run_loop_detection", &Lcode_run_loop_detection); 
}

void L_gen_code(Parm_Macro_List *command_line_macro_list) 
{
    /* Load the parameters specific to Lcode code generation */
    L_load_parameters (L_parm_file, command_line_macro_list,  
		       "(Lcode", L_read_parm_lcode);

    L_open_input_file(L_input_file);
    while (L_get_input() != L_INPUT_EOF) {
        process_input();
    }

    L_close_input_file(L_input_file);
    /*
     *	print statistic.
     */
    if (Lcode_print_stat)
    	L_print_stat();
}
