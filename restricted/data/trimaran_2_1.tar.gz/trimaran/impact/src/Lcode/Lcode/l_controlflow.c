/* IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.00  */
/* IMPACT Trimaran Release (www.trimaran.org)                  Feb. 22, 1999 */
/*****************************************************************************\
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1999 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/
/*===========================================================================
 *      File :          l_controlflow.c
 *      Description :   control flow functions
 *      Creation Date : February 1993
 *      Author :        Scott Mahlke, Wen-mei Hwu
 *
 *==========================================================================*/
#include <Lcode/l_main.h>

/*=======================================================================*/
/*
 *	Functions to reconstruct source control flow
 */
/*=======================================================================*/

void L_clear_src_flow(L_Func *fn)
{
    L_Cb *cb;
    for (cb=fn->first_cb; cb!=NULL; cb=cb->next_cb) {
	L_delete_all_flow(cb->src_flow);
	cb->src_flow = NULL;
    }
}

void L_rebuild_src_flow(L_Func *fn)
{
    L_Flow *flow, *new_flow;
    L_Cb *cb, *dst_cb;

    /* release any source links that still exist */
    for (cb=fn->first_cb; cb!=NULL; cb=cb->next_cb) {
        L_delete_all_flow(cb->src_flow);        
        cb->src_flow = NULL;
    }

    /* construct src flow arcs from dest flow arcs */
    for (cb=fn->first_cb; cb!=NULL; cb=cb->next_cb) {
	for (flow=cb->dest_flow; flow!=NULL; flow=flow->next_flow) {
	    dst_cb = flow->dst_cb;
	    new_flow = L_new_flow(flow->cc, flow->src_cb, flow->dst_cb, flow->weight);
	    dst_cb->src_flow = L_concat_flow(dst_cb->src_flow, new_flow);
	}
    }
}

/*=======================================================================*/
/*
 *      Functions to assign to coloring
 */
/*=======================================================================*/

static int L_is_not_jump(L_Oper *oper)
{
    /* anything which is not always taken */
    if (oper==NULL)
	return 1;
    switch (oper->opc) {
    case Lop_RTS:
    case Lop_RTS_FS:
    case Lop_JUMP_RG:
    case Lop_JUMP_RG_FS:
    case Lop_JUMP:
    case Lop_JUMP_FS:
        return 0;
    default:
        return 1;
    }
}

static void L_realloc_color_arrays()
{
    int i, tmp_n_entries_allocated;
    L_Oper **tmp_cnt_oper;
    L_Flow **tmp_cnt_flow;

    /* allocate new larger arrays */
    tmp_n_entries_allocated = L_n_color_entries_alloc * 2;
    tmp_cnt_oper = (L_Oper **) malloc(sizeof(L_Oper *)*tmp_n_entries_allocated);
    tmp_cnt_flow = (L_Flow **) malloc(sizeof(L_Flow *)*tmp_n_entries_allocated);

    /* copy values old arrays into new arrays */
    for (i=0; i<L_n_color_entries_alloc; i++) {
	tmp_cnt_oper[i] = L_cnt_oper[i];
	tmp_cnt_flow[i] = L_cnt_flow[i];
    }

    /* free up old arrays */
    free(L_cnt_oper);
    free(L_cnt_flow);

    /* assign global vars to new arrays */
    L_cnt_oper = tmp_cnt_oper;
    L_cnt_flow = tmp_cnt_flow;
    L_n_color_entries_alloc = tmp_n_entries_allocated;
}

void L_print_color_info(L_Cb *cb)
{
    int i;
    printf("## Color info (cb %d) ##\n", cb->id);
    printf("\t L_n_cnt_oper %d\n", L_n_cnt_oper);
    for (i=0; i<L_n_cnt_oper; i++) {
	if (L_cnt_oper[i]!=NULL) {
	    printf("\t exit %d op %d cc %d target %d weight %f\n",
			i+1,
			L_cnt_oper[i]->id,
			L_cnt_flow[i]->cc,
			L_cnt_flow[i]->dst_cb->id,
			L_cnt_flow[i]->weight);
	}
	else {
	    printf("\t exit %d op fthru cc %d target %d weight %f\n",
			i+1,
			L_cnt_flow[i]->cc,
			L_cnt_flow[i]->dst_cb->id,
			L_cnt_flow[i]->weight);
	}
    }
}

void L_color_cb(L_Cb *cb)
{
    int i, color;
    L_Oper *oper;
    L_Flow *flow;
    if ((L_cnt_oper==NULL) || (L_cnt_flow==NULL)) {
	if (L_cnt_oper!=NULL)
	    L_punt("L_color_cb: L_cnt_oper not freed");
	if (L_cnt_flow!=NULL)
	    L_punt("L_color_cb: L_cnt_flow not freed");
	L_n_color_entries_alloc = 128;
	L_cnt_oper = (L_Oper **) malloc(sizeof(L_Oper *)*L_n_color_entries_alloc);
	L_cnt_flow = (L_Flow **) malloc(sizeof(L_Flow *)*L_n_color_entries_alloc);
    }
    /*
     *  define operations.
     */
    color = 0;
    flow = cb->dest_flow;
    for (oper=cb->first_op; oper!=NULL; oper=oper->next_op) {
        if (L_general_branch_opcode(oper)) {
            if (color>=L_n_color_entries_alloc)
		L_realloc_color_arrays();
            L_cnt_oper[color] = oper;
            if (flow==NULL) {
		fprintf(stderr, "# cb %d\n", cb->id);
                L_punt("L_color_cb: too few flows");
            }
            L_cnt_flow[color] = flow;
            flow = flow->next_flow;
            color += 1;
        }
    }

    /* handle fall thru path */
    if (L_is_not_jump(cb->last_op)) {
        if (color>=L_n_color_entries_alloc)
	    L_realloc_color_arrays();
        L_cnt_oper[color] = NULL;
        L_cnt_flow[color] = flow;
        if (flow==NULL) {
            fprintf(stderr, "# cb %d\n", cb->id);
            L_punt("L_color_cb: missing fall-thru arc");
        }
        flow = flow->next_flow;
        color += 1;
    }
    L_n_cnt_oper = color;
    /*
     *  Check flow information.
     */
    for (i=0; i<L_n_cnt_oper; i++) {
        L_Oper *oper;
        int opc;
        L_Operand *src;
        L_Flow *flow;
        oper = L_cnt_oper[i];
        flow = L_cnt_flow[i];
        if (oper==NULL)
            continue;
        opc = oper->opc;
        if ((opc==Lop_JUMP_RG) || (opc==Lop_JUMP_RG_FS)) {
            /*
             *  1. JUMP_RG must be the last operation.
             */
            if (i != (L_n_cnt_oper-1)) {
		fprintf(stderr, "# cb %d\n", cb->id);
                L_punt("L_color_cb: JUMP_RG must be the last operation");
            }
        }
	else {
            /*
             *  2. check flow information.
             */
            switch (opc) {
            case Lop_JUMP:
            case Lop_JUMP_FS:
                src = oper->src[0];
		if (!L_is_cb(src)) {
		    fprintf(stderr, "# cb %d oper %d\n", cb->id, oper->id);
                    L_punt("L_color_cb: 1st operand of JUMP must be cb");
		}
                if (src->value.cb!=flow->dst_cb) {
                    fprintf(stderr, "# cb %d, oper %d\n", cb->id, oper->id);
                    fprintf(stderr, "# jump target = cb %d\n", src->value.cb->id);
                    fprintf(stderr, "# flow = cb %d\n", flow->dst_cb->id);
                    L_punt("L_color_cb: bad flow for JUMP");
                }
                break;
            case Lop_BEQ:
            case Lop_BNE:
            case Lop_BGT:
            case Lop_BGE:
            case Lop_BLT:
            case Lop_BLE:
            case Lop_BGT_U:
            case Lop_BGE_U:
            case Lop_BLT_U:
            case Lop_BLE_U:
            case Lop_BEQ_FS:
            case Lop_BNE_FS:
            case Lop_BGT_FS:
            case Lop_BGE_FS:
            case Lop_BLT_FS:
            case Lop_BLE_FS:
            case Lop_BGT_U_FS:
            case Lop_BGE_U_FS:
            case Lop_BLT_U_FS:
            case Lop_BLE_U_FS:
            case Lop_BEQ_F:
            case Lop_BNE_F:
            case Lop_BGT_F:
            case Lop_BGE_F:
            case Lop_BLT_F:
            case Lop_BLE_F:
            case Lop_BEQ_F_FS:
            case Lop_BNE_F_FS:
            case Lop_BGT_F_FS:
            case Lop_BGE_F_FS:
            case Lop_BLT_F_FS:
            case Lop_BLE_F_FS:
            case Lop_BEQ_F2:
            case Lop_BNE_F2:
            case Lop_BGT_F2:
            case Lop_BGE_F2:
            case Lop_BLT_F2:
            case Lop_BLE_F2:
            case Lop_BEQ_F2_FS:
            case Lop_BNE_F2_FS:
            case Lop_BGT_F2_FS:
            case Lop_BGE_F2_FS:
            case Lop_BLT_F2_FS:
            case Lop_BLE_F2_FS:
                src = oper->src[2];
		if (!L_is_cb(src)) {
		    fprintf(stderr, "# cb %d oper %d\n", cb->id, oper->id);
                    L_punt("L_color_cb: 3rd operand of BRANCH must be cb");
		}
                if (src->value.cb!=flow->dst_cb) {
                    fprintf(stderr, "# cb %d, oper %d\n", cb->id, oper->id);
                    fprintf(stderr, "# br target = cb %d\n", src->value.cb->id);
                    fprintf(stderr, "# flow = cb %d\n", flow->dst_cb->id);
                    L_punt("L_color_cb: bad flow (cond br)");
                }
                break;
            default:
                L_punt("L_color_cb: illegal control operation");
            }
        }
    }
    if (L_debug_color_cb) {
	L_print_color_info(cb);
    }
}
