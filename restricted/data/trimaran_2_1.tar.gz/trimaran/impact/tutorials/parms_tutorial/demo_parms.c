/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/* Authors: John C. Gyllenhaal, Wen-mei Hwu                                  */
#include <stdio.h>
#include <library/l_parms.h>


/* Declare Section1 parameters */
int binary_parm1 = -1000;
int int_parm1 = -1000;
char *string_parm1 = NULL;
float float_parm1 = -1000.0;
double double_parm1 = -1000.0;
int dev_int_parm1 = -1000;

/* Declare Section2 parameters */
int int_parm2 = -1000;

/* 
 * Read in Section1 parms
 */
void L_read_parm_Section1 (Parm_Parse_Info *ppi)
{
    /* Read in a example of each type of parameter */
    L_read_parm_b (ppi, "binary_parm1", &binary_parm1);
    L_read_parm_i (ppi, "int_parm1", &int_parm1);
    L_read_parm_s (ppi, "string_parm1", &string_parm1);
    L_read_parm_f (ppi, "float_parm1", &float_parm1);
    L_read_parm_lf (ppi, "double_parm1", &double_parm1);

    /* Development parms are marked with a leading '?'.  
     * These parameters will not cause warnings if they are 
     * not set in the parameter file.
     */
    L_read_parm_i (ppi, "?dev_int_parm1", &dev_int_parm1);

    /* Read in some parameter file configuration flags.  These
     * are read in Lcode's main program, parm section '(global'.
     * They are being read in here so we can exercise them.
     */
    L_read_parm_b (ppi, "warn_parm_not_defined", &L_warn_parm_not_defined);
    L_read_parm_b (ppi, "warn_parm_defined_twice", &L_warn_parm_defined_twice);
    L_read_parm_b (ppi, "warn_parm_not_used", &L_warn_parm_not_used);
    L_read_parm_b (ppi, "dump_parms", &L_dump_parms);
    L_read_parm_s (ppi, "parm_warn_file_name", &L_parm_warn_file_name);
    L_read_parm_s (ppi, "parm_dump_file_name", &L_parm_dump_file_name);
}

void L_read_parm_Section2 (Parm_Parse_Info *ppi)
{
    /* Read in an int parameter only */
    L_read_parm_i (ppi, "int_parm2", &int_parm2);
}

int main (int argc, char **argv, char **envp)
{
    Parm_Macro_List *external_list;
    char *parm_file;
    int i;

    /* Print out all the arguments passed to this program */
    printf ("Parm_test arguments:\n");
    for (i = 1; i < argc; i++)
    {
	printf ("  argv[%i] = '%s'\n", i, argv[i]);
    }
    printf ("\n");

    /* Get -Fname=value and -Pname=value arguments from the command line,
     * and build symbol table from environment definitions for use by
     * the parameter file reader.
     */
    external_list = L_create_external_macro_list (argv, envp);

    /*
     * Get the name of the parm file to use from command line (-p path), 
     * or environment variable "STD_PARMS_FILE".  If all else fails,
     * default to "./STD_PARMS"
     */
    parm_file = L_get_std_parm_name (argv, envp, "STD_PARMS_FILE",
                                          "./STD_PARMS");
    
    /* Print out parameter file we are using */
    printf ("Parameter file: %s\n", parm_file);

    /* Read in 'Section1' parms */
    L_load_parameters (parm_file, external_list, "(Section1", 
		       L_read_parm_Section1);

    /* Read in 'Section2' parms */
    L_load_parameters (parm_file, external_list, "(Section2", 
		       L_read_parm_Section2);

    printf ("Values of variables controlling the parm file reader (set in Section1):\n");
    PRINT_PARM_B_YES_NO (stdout, L_dump_parms);
    PRINT_PARM_B_YES_NO (stdout, L_warn_dev_parm_not_defined);
    PRINT_PARM_B_YES_NO (stdout, L_warn_parm_defined_twice);
    PRINT_PARM_B_YES_NO (stdout, L_warn_parm_not_used);
    PRINT_PARM_S (stdout, L_parm_warn_file_name);
    PRINT_PARM_S (stdout, L_parm_dump_file_name);
    printf ("\n");

    /* Print out Section1's values */
    printf ("Values of parameters set in Section1:\n");
    printf ("    binary_parm1  = '%i'\n", binary_parm1);
    printf ("    int_parm1     = '%i'\n", int_parm1);
    printf ("    string_parm1  = '%s'\n", string_parm1);
    printf ("    float_parm1   = '%f'\n", float_parm1);
    printf ("    double_parm1  = '%f'\n", double_parm1);
    printf ("    dev_int_parm1 = '%i'\n", dev_int_parm1);
    printf ("\n");


    printf ("Values of parameters set in Section2:\n");
    printf ("    int_parm2     = '%i'\n", int_parm2);

    /* Print warning about any unused command line parameter arguments.
     * (Call only after have read in all the parameter file sections.
     *  Otherwise false warnings may occur.)
     */
    L_warn_about_unused_macros (stderr, external_list);

    /* Return 0 so shell script doesn't complain */
    return (0);
}
