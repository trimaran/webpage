 # IMPACT Public Release (www.crhc.uiuc.edu/IMPACT)            Version 2.32  #
 # IMPACT Trimaran Release (www.trimaran.org)                  June 28, 1999 #
###############################################################################
#  Run 'read_project_info --help | more' for documentation.
#
#  Revision history for this file:
#     6/99  Created by John C. Gyllenhaal (www.crhc.uiuc.edu/IMPACT)
###############################################################################

# Reduce the compile-time memory requirements for this benchmark
(Lsuperscalar $PROJECT_DIR$/project_parms
    # maximum number of times can ever unroll this loop (default 32)
    # Set to a maximum of 4 to reduce compile-time memory requirements
    max_unroll_allowed = 4;


    # Setting the following parameters to 'yes' yields the best performance.
    # However, they can cause a huge amount of code duplication and thus
    # significantly increase compile time and memory requirements.
    #
    # Set the following to 'no' to reduce compile-time memory requirements
    allow_backedge_exp=no;
    allow_expansion_of_loops=no;
    allow_extra_unrolling_for_small_loops=no;
end)

(Lhyper $PROJECT_DIR$/project_parms
    # Do not hyperblock 'chckside' unless you have a lot of memory.
    prevent_hyperblock_functions=chckside
end)

# Use project settings for everything else
(* $PROJECT_DIR$/project_parms
end)
