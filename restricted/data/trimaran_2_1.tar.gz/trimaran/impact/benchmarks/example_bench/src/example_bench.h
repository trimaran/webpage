/* An example program used by the .../impact/tutorials/bench_info_tutorial
 * to demonstrate the new bench_info framework.
 * Author: John C. Gyllenhaal and Wen-mei Hwu  11/19/98
 */
extern int int_array[16];
extern int sum1, sum3;

extern int convert_to_int (char *buf);
extern int do_sum2 (int val);
extern void do_sum3 (int val);
