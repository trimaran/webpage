/* An example program used by the .../impact/tutorials/bench_info_tutorial
 * to demonstrate the new bench_info framework.
 * Author: John C. Gyllenhaal and Wen-mei Hwu  11/19/98
 */
#include <stdio.h>
#include <stdlib.h>
#include "example_bench.h"

int int_array[16];
int sum1, sum3;

int convert_to_int (char *buf)
{
    int value;
    char *end_ptr;

    value = strtol (buf, &end_ptr, 10);

    if ((*end_ptr != 0) || (*buf == 0))
    {
	fprintf (stderr, "Invalid int parameter '%s'!\n", buf);
	exit (1);
    }

    return (value);
}


int do_sum2 (int val)
{
    int sum, i;

    sum = 0;

    for (i=0; i < 16; i++)
    {
	sum += int_array[i] - val;
    }
    return (sum);
}

void do_sum3 (int val)
{
    if ((val & 2) == 0)
	sum3 += val;
}

