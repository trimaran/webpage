/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/*************************************************************************\
*                                                                         *
*  File:            lbx86_main.h                                          *
*  Original Author: Matthew C. Merten, Mike Thiems, Wen-mei Hwu           *
*  Creation Date:   October, 1997                                         *
*                                                                         *
*  Description:                                                           *
*                                                                         *
*       General include files for lbx86 (binary optizer).                 *
*                                                                         *
\*************************************************************************/

#ifndef L_CODEGEN_H
#define L_CODEGEN_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <assert.h>

/* MST - this is a HACK to prevent inclusion of l_pred_graph.h */
#define L_PRED_GRAPH_H

#include <Lcode/l_main.h>
#include "lbx86_phase2.h"
#include "lbx86_phase3.h"
#include <machine/m_bx86.h>

/*
 * Declare exterm code generator specific runtime variables
 * and parameters 
 */

extern L_Cb * mcb;
extern char CurrentFunction[];
extern int Function_Num;

extern int L_bx86_do_k6_esi_plus0_opti;

#define FIRSTWAY

/*
 * Create several operand macros in addition to those in l_lcode.h
 */

#if 0    /* These are for Lx86, but serve as examples */

#define L_is_reg_or_mac(operand)  L_is_variable(operand)

#define L_is_lbl_or_str(operand) ((operand)==NULL? 0 :	\
        (L_is_label(operand) ||	                        \
         L_is_string(operand)))

#define L_is_ctype_FP(operand) ((operand)==NULL? 0 :	\
        (L_is_ctype_flt(operand) ||	                \
         L_is_ctype_dbl(operand)))

#define L_is_FP_constant(operand) ((operand)==NULL? 0 : \
        (L_is_flt_constant(operand) ||                  \
         L_is_dbl_constant(operand)))

#define L_is_P0(operand) ((operand)==NULL? 0 :		\
        (L_is_macro(operand) &&	                        \
         ((operand)->value.mac == L_MAC_P0)))

#define L_is_P1(operand) ((operand)==NULL? 0 :		\
        (L_is_macro(operand) &&	                        \
         ((operand)->value.mac == L_MAC_P1)))

#define L_is_esp(operand) ((operand)==NULL? 0 :		\
        (L_is_macro(operand) &&	                        \
         ((operand)->value.mac == LX86_MAC_ESP)))

#define L_is_FP_zero(operand) ((operand)==NULL? 0 :             \
	(L_is_zero(operand) && ( L_is_ctype_flt(operand) ||     \
				 L_is_ctype_dbl(operand) ) ) )

#define L_is_FP_one(operand) ((operand)==NULL? 0 :              \
	(L_is_one(operand) && ( L_is_ctype_flt(operand) ||      \
				 L_is_ctype_dbl(operand) ) ) )

#define L_is_FP_zero_or_one(operand) ((operand)==NULL? 0 :      \
        (L_is_FP_zero(operand) || L_is_FP_one(operand)))

#define L_is_FP_stack(operand) ((operand)==NULL? 0 :	\
        (L_is_macro(operand) &&	                        \
         ((operand)->value.mac == LX86_MAC_FPSTACK)))

#define L_is_flags(operand) ((operand)==NULL? 0 :	\
        (L_is_macro(operand) &&	                        \
         ((operand)->value.mac == LX86_MAC_FLAGS)))

#define L_is_ST(operand) ((operand)==NULL? 0 :		        \
        (L_is_macro(operand) &&	                                \
         ((operand)->value.mac == L_MAC_P1  ||		        \
	  (operand)->value.mac == LX86_MAC_ST1 ||		\
	  (operand)->value.mac == LX86_MAC_ST2 ||		\
	  (operand)->value.mac == LX86_MAC_ST3 ||		\
	  (operand)->value.mac == LX86_MAC_ST4 ||		\
	  (operand)->value.mac == LX86_MAC_ST5 ||		\
	  (operand)->value.mac == LX86_MAC_ST6 ||		\
	  (operand)->value.mac == LX86_MAC_ST7)))

#define L_is_ST1(operand) ((operand)==NULL? 0 :		\
        (L_is_macro(operand) &&	                        \
         ((operand)->value.mac == LX86_MAC_ST1)))

#define L_is_ST1_7(operand) ((operand)==NULL? 0 :	        \
        (L_is_macro(operand) &&	                                \
         ((operand)->value.mac == LX86_MAC_ST1 ||		\
	  (operand)->value.mac == LX86_MAC_ST2 ||		\
	  (operand)->value.mac == LX86_MAC_ST3 ||		\
	  (operand)->value.mac == LX86_MAC_ST4 ||		\
	  (operand)->value.mac == LX86_MAC_ST5 ||		\
	  (operand)->value.mac == LX86_MAC_ST6 ||		\
	  (operand)->value.mac == LX86_MAC_ST7)))

#endif


union CONVERT_FLOAT {
   int  val;
   float  sgl;
};

#if defined(i386)

union CONVERT_DOUBLE {
  struct {
    int  lo;
    int  hi;
  } integer;
   double dbl;
};

#else

union CONVERT_DOUBLE {
  struct {
    int  hi;
    int  lo;
  } integer;
   double dbl;
};

#endif

union CONVERT_FLOAT convert_float;
union CONVERT_DOUBLE convert_double;


extern L_Operand *L_zero;
extern L_Operand *L_one;
extern L_Operand *L_two;
extern L_Operand *L_four;
extern L_Operand *L_eight;
extern L_Operand *L_minus1;
extern L_Operand *L_oszapc_flags;
extern L_Operand *L_c_flags;
extern L_Operand *L_oszap_flags;
extern L_Operand *L_oc_flags;
extern L_Operand *L_szapc_flags;
extern L_Operand *L_oszpc_flags;
extern L_Operand *L_d_flags;
extern L_Operand *L_z_flags;
extern L_Operand *L_zc_flags;
extern L_Operand *L_osz_flags;
extern L_Operand *L_os_flags;
extern L_Operand *L_gp_reg32;
extern L_Operand *L_gp_reg16;
extern L_Operand *L_eax;
extern L_Operand *L_ebx;
extern L_Operand *L_ecx;
extern L_Operand *L_edx;
extern L_Operand *L_esi;
extern L_Operand *L_edi;
extern L_Operand *L_ebp;
extern L_Operand *L_esp;
extern L_Operand *L_ax;
extern L_Operand *L_bx;
extern L_Operand *L_cx;
extern L_Operand *L_dx;
extern L_Operand *L_si;
extern L_Operand *L_di;
extern L_Operand *L_bp;
extern L_Operand *L_sp;
extern L_Operand *L_al;
extern L_Operand *L_bl;
extern L_Operand *L_cl;
extern L_Operand *L_dl;
extern L_Operand *L_ah;
extern L_Operand *L_bh;
extern L_Operand *L_ch;
extern L_Operand *L_dh;
extern L_Operand *L_cs;
extern L_Operand *L_ds;
extern L_Operand *L_es;
extern L_Operand *L_fs;
extern L_Operand *L_gs;
extern L_Operand *L_ss;
extern L_Operand *L_st0;
extern L_Operand *L_st1;
extern L_Operand *L_st2;
extern L_Operand *L_st3;
extern L_Operand *L_st4;
extern L_Operand *L_st5;
extern L_Operand *L_st6;
extern L_Operand *L_st7;
extern L_Operand *L_mm0;
extern L_Operand *L_mm1;
extern L_Operand *L_mm2;
extern L_Operand *L_mm3;
extern L_Operand *L_mm4;
extern L_Operand *L_mm3;
extern L_Operand *L_mm4;
extern L_Operand *L_mm5;
extern L_Operand *L_mm6;
extern L_Operand *L_mm7;
extern L_Operand *L_addr;
extern L_Operand *L_fpsw;
extern L_Operand *L_fpcw;


#define LBX86_EXT_FLAGS_STR_INST       0x01
#define LBX86_EXT_FLAGS_SYNC_MEM       0x02
#define LBX86_EXT_FLAGS_MEM_READ       0x10  /* the MEM_ flags are encoded */
#define LBX86_EXT_FLAGS_MEM_WRITE      0x20  /*  together in a 2-bit field */
#define LBX86_EXT_FLAGS_MEM_READ_WRITE 0x30  /*  .                         */
#define LBX86_EXT_FLAGS_MMX_INST       0x40

#define SEG_OVR_CS 1
#define SEG_OVR_SS 2
#define SEG_OVR_DS 3
#define SEG_OVR_ES 4
#define SEG_OVR_FS 5
#define SEG_OVR_GS 6



typedef struct Lbx86_Ext_Fields {
	unsigned short flags;
	char mem_size;
	char seg_ovr_popval;
} Lbx86_Ext_Fields;


#define LBX86_EXT(oper) ((Lbx86_Ext_Fields *)(oper->ext))

#define LBX86_SEG_OVR(oper) (LBX86_EXT(oper)->seg_ovr_popval & 0xF)
#define LBX86_POPVAL(oper) ((LBX86_EXT(oper)->seg_ovr_popval >> 4) & 0xF)
#define LBX86_ENCODE_SEG_OVR_POPVAL(seg_ovr, popval) ((char)((popval << 4) | \
                                                             (seg_ovr & 0xF)))

#define LBX86_EXTRACT_GENOPC(popc) ((int)(((unsigned)(popc)) >> 4))
#define LBX86_GENOPC(oper) (LBX86_EXTRACT_GENOPC(oper->proc_opc))
#define LBX86_EXTRACT_VARIANT(popc) ((int)(((unsigned)(popc)) & 0xF))
#define LBX86_VARIANT(oper) (LBX86_EXTRACT_VARIANT(oper->proc_opc))

#define LBX86_ENCODE_POPC(genopc, variant) ((int)((genopc << 4) | variant))

#endif
