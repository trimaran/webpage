/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/*===========================================================================*\
 *
 *  File:  lhppa_phase1.h
 *  
 *  Description:
 *	    Predefined HP PA-RISC opcodes
 *
 *  Creation Date :  March, 1992 
 *
 *  Author:  Richard E. Hank, Wen-mei Hwu
 *
 *
 *===========================================================================*/

#define L_PRELOAD 	0

#ifndef L_HPPA_H
#define L_HPPA_H

/* define extensions to instructions */
enum {
	JSR_BV=1,		/* jsr converted to bv		      */
	JSR_BL_MILLICODE,	/* millicode subroutine call	      */
	JSR_BLE,		/* jsr converted to long jsr ble      */


	MOV_LDI,		/* mov converted to ldi		      */
        MOV_LDIL,
        MOV_LDIL_LDO,		/* mov converted to ldil/ldo	      */
	MOV_ADDIL_LDO,		/* mov converted to addil/ldo	      */
	MOV_MTCTL,		/* mov converted to MTCTL	      */
	MOV_ZDEPI,		/* mov converted to ZDEPI	      */
	MOV_MFSP,		/* move from space register	      */
	MOV_MTSP,		/* move to space register	      */

	SUB_SUBI,    		/* sub converted to subi     	      */
	ADD_ADDI,		/* add converted to addi	      */
	ADD_UADDCM,		/* add converted to uaddcm	      */
	ADD_LDO,	 	/* add converted to ldo		      */
	ADD_ADDIL_LDO,		/* add converted to addil/ldo	      */
        ADD_ADDIL,
	ADD_LDIL,
	ADD_SH1ADD,		/* phase 2 optimizations combine lsl  */
	ADD_SH2ADD, 		/* and add instructions to form one   */
	ADD_SH3ADD,		/* shxadd instruction 		      */

	CMP_COMICLR,		/* eq,neq,etc converted to comiclr    */

	LSL_SUBI_MTCTL_ZVDEP,	/* lsl converted to subi/mtctl/zvdep  */
	LSL_SHxADD,		/* lsl converted to shxadd	      */
	LSL_ZDEP,		/* lsl converted to zdep	      */
	LSL_ZVDEP,		/* lsl converted to zvdep	      */

	LSR_MTCTL_VSHD,		/* lsr converted to mtctl/vshd	      */
	LSR_EXTRU,		/* lsr converted to extru	      */
        LSR_VSHD,	

	ASR_EXTRS_MTCTL_VSHD,	/* asr converted to extrs/mtctl/vshd  */
	ASR_EXTRS,	 	/* asr converted to extrs	      */
	ASR_EXTRS_LD,		/* asr converted to extrs for the     */
			        /*  purpose of signed extending a load*/
				/*  thus, src2 = field len and start  */
				/*  position is always 31	      */
	ASR_VEXTRS,
	ASR_DIV,		/* used to hide integer division by a */
				/* power of 2 from the register alloc.*/
			        /* because it is not annotated until  */	
				/* phase 3 			      */

	AND_EXTRU,
	AND_DEPI,
    
	MUL_XMPYU,		/* convert int multiply to xmpyu      */	
	MUL_FMPYADD,
	MUL_FMPYSUB,
	
	CBR_COMCLR,
	CBR_COMICLR,
	CBR_IMMED_EXT,		/* cond br converted to comibt(f) */
	BGE_BB,
	BLT_BB,
	BLT_ADDIB,
	BEQ_FTEST_BL,	        /* used for floating point cond. br  */
	AND_FTEST_LDI,		/* used for floating point comparison*/

	LOAD_INDEXED,
	LOAD_LONG,		/* load converted to load long	  */
	LOAD_SHORT,		/* load converted to load short   */ 
	LOAD_ADDIL_LD,		/* load converted to addil/load   */
	LOAD_LDWM,		/* load converted to ldwm	  */
        LOAD_REG,		/* load provided to the register  */
				/* allocator to be annotated later*/

	STORE_INDEXED,		/* store converted to index store */
	STORE_LONG,		/* store converted to store long  */
	STORE_SHORT,		/* store converted to store short */
	STORE_ADDIL_ST, 	/* store converted to addil/store */
	STORE_STWM,		/* store converted to stwm	  */
	STORE_REG,		/* store provided to the register */
				/* allocator to be annotated later*/

	DELETE,			/* insruction to be deleted	  */
	JSR_BLE_COND,		/* jsr converted to long cond. ble    */
	
	SUB_LDIL,		/* sub converted to ldil/ldo for     */
	SUB_LDO,		/* subtraction of two label operands */
	
	LSL_ZDEPI,	
	LSL_ZVDEPI,
	
	LOAD_PROBERI,		/* load converted to a probe instruction */
	MOV_LDIL2,
	ADD_LDO2,

	AND_DEP,			/* Deposit */
	
	/* 
	 * PlayDoh Extensions
	 */
	BEQ_BRCT,
	BEQ_BRCF,
};

/* defines for instruction nullification condition codes */ 
enum {
    /* comparison instructions */
    COMP_EQ=1,	/* op1 = op2 		  */
    COMP_NE,	/* op1 <> op2		  */

    COMP_LT,	/* op1 < op2 	  	  */
    COMP_GE,	/* op1 >= op2		  */

    COMP_LE,	/* op1 <= op 2 		  */
    COMP_GT,	/* op1 >  op2		  */

    COMP_LT_U,	/* op1 << op2 (unsigned)  */
    COMP_GE_U,	/* op1 >>= op2 (unsigned) */

    COMP_LE_U,	/* op1 <<= op2 (unsigned) */
    COMP_GT_U,	/* op1 >>  op2 (unsigned) */
  
    COMP_ALWAYS,	/* always nullify	  */

    SHORT_LD_ST_MA,     /* modify base register after */ 
    SHORT_LD_ST_MB,	/* modify base register before */

    INDEXED_LD_ST_SHIFT, /* shift the index register by data size */
    INDEXED_LD_ST_MODIFY
};

/* branch direction and field selection extensions */
enum {
	CBR_FORWARD_EXT=1,	/*   forward conditional branch	  */
	CBR_BACKWARD_EXT,	/*   backward conditinal branch	  */

	/* field selectors */
	NO_FIELD_SELECT,	
	HIGH_ORDER_21,
	LOW_ORDER_11  
};

/* Extension field bit-mapping for HP-PA Mcode 				  */
/*      | -  | field select/branch dir | nullify cond | instr extension | */
/*	                 8			8	 	8         */
#define EXT(fs_bd,null,instr)  ( (fs_bd << 16) | (null << 8) | instr )
#define INSTR_EXT(ext)		( ext & 0xFF )
#define NULL_COND(ext)	        ( (ext & 0xFF00) >> 8 )
#define BRANCH_DIR(ext)		( (ext & 0xFF0000) >> 16 )
#define FIELD_SELECT(ext)	( (ext & 0xFF0000) >> 16 )

/* maximum values for immediate operands */
#define INT_2EXP13		0x2000 
#define INT_2EXP10		0x400
#define INT_2EXP4		0x10

#define FIELD_5(a)	((((a) >= -INT_2EXP4)&&((a) < INT_2EXP4))?1:0)
#define FIELD_11(a)	((((a) >= -INT_2EXP10)&&((a) < INT_2EXP10))?1:0)
#define FIELD_14(a)	((((a) >= -INT_2EXP13)&&((a) < INT_2EXP13))?1:0)

/* This attribute is placed one loads/stores that are not potentially
 * excepting (segmentation fault or bus error) since they are spill code,
 * local variable acesses, etc.  This attr prevents phase3 from "probing"
 * the load/store.  It is undesirable to probe these memory operations,
 * because the use of %r31 in the "probe" operations will destroy the address
 */
#define NTRAP_ATTR	"ntrap"
#define	MARK_NTRAP(a)	{a->flags = L_SET_BIT_FLAG(a->flags,L_OPER_SAFE_PEI);}

/* This is used to clear flags from new opers resulting from annotation.
 * These opers need not inherit the flags of their parents. Use this carefully!
 */
#define CLEAR_FLAGS(oper)	{ (oper)->flags = L_CLR_BIT_FLAG((oper)->flags,\
    						       (L_OPER_SPILL_CODE|\
							L_OPER_SAFE_PEI|\
							L_OPER_MASK_PE|\
							L_OPER_SIDE_EFFECT_FREE|\
							L_OPER_LABEL_REFERENCE|\
							L_OPER_PROBE_MARK)); \
				}

union CONVERT {
  struct {
    int  hi;
    int  lo;
  } integer;
  float  sgl;
  double dbl;
};
union CONVERT convert;

typedef struct label_list {
    char label[64];
} LABEL_LIST;

/* global flags for profiling and trace generation */
int	L_profile;
int 	L_trace;

extern int L_NextString;
int	leaf;
Set 	callee_registers;
int 	callee_i;
int 	callee_f;
int	alloc_size;
int	swap_size;
int     prev_regalloc_swap;
extern int original_max_reg_id;

/* Define a few used functions that the system doesn't define */

extern void L_scan_for_regs();
extern void L_scan_for_local_regs();
extern int  L_scan_for_alloc();
extern int  L_update_local();
extern int  L_leaf_func();
extern int  L_non_leaf_func;
extern void L_update_callee_caller();
extern void L_scan_prologue_defines();
extern L_Oper *L_int_constant_load();




#endif
