/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/*************************************************************************\
 *
 *  File:  lx86_phase3.h 
 *
 *  Description:
 *    Include file for Print module of X86 code generator
 *
 *  Creation Date :  May, 1993
 *
 *  Author:  Dave Gallagher, Wen-mei Hwu
 *
 *
\************************************************************************/

#ifndef LX86_PHASE3_H
#define LX86_PHASE3_H

#define NUM_SPACE	2
#define NUM_SUBSP	9

extern int FUNC_ALIGN;
extern int DATA_ALIGN;
extern int CB_ALIGN;
extern int DBL_ALIGN;

extern int *current_offset;             /* current offset in cur subsp  */
extern int space_offset[NUM_SUBSP];	/* current offset in subspace 	*/
extern int space_defined[NUM_SPACE];	/* entry = 1 if space defined	*/ 
extern int subsp_defined[NUM_SUBSP];	/* entry = 1 if subsp defined	*/
extern char *space_name[];		/* defined in p_x86_data.c 	*/
extern char *subsp_name[];		/* define in p_x86_data.c  	*/
extern int flag;

#define OFFSET(a)		(&space_offset[a>>1])
#define DEFINE_SPACE(a)		(space_defined[a>>1]=1)
#define SPACE_DEFINED(a)	(space_defined[a>>1])
#define SPACE_NAME(a,def)	(space_name[a+def])
#define DEFINE_SUBSP(a)		(subsp_defined[a>>1]=1)
#define SUBSP_DEFINED(a)	(subsp_defined[a>>1])
#define SUBSP_NAME(a,def)	(subsp_name[a+def])
#define SUBSP_LABEL(a)		(subsp_label[a>>1])

extern void P_print_string();
extern void P_process_data();
extern void P_process_datalist(FILE *F, L_Datalist *list);
extern void P_print_fp_constant_data();
extern void P_init();

enum {
    DATA=0,
    CODE,
    ENTRY,
    MILLICODE
};

extern char *symbol_type[];

typedef struct extern_data {
    int action;
    int type;
    char *label;
    struct extern_data *next;
} EXT_DATA; 

extern EXT_DATA *extern_list;

extern void P_free_extern_data();
extern void P_print_extern_data();

typedef struct string_data {
    char *label;
    char *string;
    struct string_data *next;
} STR_DATA;

extern STR_DATA *string_list;
extern STR_DATA *string_tail;

typedef struct data_list {
    char *label;
    struct data_list *next;
} DATA_LIST;

extern DATA_LIST *data_list;
extern DATA_LIST *data_tail;

extern int P_is_in_data_list();
extern void P_free_data_list();
extern void P_add_data_list();

typedef struct float_list {
    int type;
    union {
	double f;
	double f2;
    } value;
} FLOAT_LIST;

#define MAX_FLOATS		100

extern FLOAT_LIST float_list[MAX_FLOATS];
extern int num_floats;

typedef enum Pn_OPCODE {
        Pn_none,
        Pn_nop,

        Pn_label,
        Pn_align,

        Pn_call,
        Pn_ret,
        Pn_jmp,

        Pn_push,
        Pn_pop,

        Pn_cmpb,	/* order of b/w/l is important! */
        Pn_cmpw,
        Pn_cmpl,

        Pn_testb,	/* order of b/w/l is important! */
        Pn_testw,
        Pn_testl,

        Pn_jz,
        Pn_jnz,
        Pn_jg,
        Pn_jge,
        Pn_jl,
        Pn_jle,
        Pn_ja,
        Pn_jae,
        Pn_jb,
        Pn_jbe,

        Pn_sete,
        Pn_setne,
        Pn_setg,
        Pn_setge,
        Pn_setl,
        Pn_setle,
        Pn_seta,
        Pn_setae,
        Pn_setb,
        Pn_setbe,

        Pn_orb,		/* order of b/w/l is important! */
        Pn_orw,
        Pn_orl,

        Pn_andb,	/* order of b/w/l is important! */
        Pn_andw,
        Pn_andl,

        Pn_xorb,	/* order of b/w/l is important! */
        Pn_xorw,
        Pn_xorl,

        Pn_xchgb,	/* order of b/w/l is important! */
        Pn_xchgw,
        Pn_xchgl,

        Pn_lea,

        Pn_salb,	/* order of b/w/l is important! */
        Pn_salw,
        Pn_sall,

        Pn_shrb,	/* order of b/w/l is important! */
        Pn_shrw,
        Pn_shrl,

        Pn_sarb,	/* order of b/w/l is important! */
        Pn_sarw,
        Pn_sarl,

        Pn_rolb,	/* order of b/w/l is important! */
        Pn_rolw,
        Pn_roll,

        Pn_rorb,	/* order of b/w/l is important! */
        Pn_rorw,
        Pn_rorl,

        Pn_rclb,	/* order of b/w/l is important! */
        Pn_rclw,
        Pn_rcll,

        Pn_rcrb,	/* order of b/w/l is important! */
        Pn_rcrw,
        Pn_rcrl,

        Pn_sahf,
	Pn_lahf,

        Pn_imulb,	/* order of b/w/l is important! */
        Pn_imulw,	
        Pn_imull,
        Pn_mulb,
        Pn_mulw,
        Pn_mull,

        Pn_idivb,	/* order of b/w/l is important! */
        Pn_idivw,
        Pn_idivl,
        Pn_divb,
        Pn_divw,
        Pn_divl,

        Pn_addb,	/* order of b/w/l is important! */
        Pn_addw,
        Pn_addl,

        Pn_subb,	/* order of b/w/l is important! */
        Pn_subw,
        Pn_subl,

        Pn_incb,	/* order of b/w/l is important! */
        Pn_incw,
        Pn_incl,

        Pn_decb,	/* order of b/w/l is important! */
        Pn_decw,
        Pn_decl,

        Pn_negb,	/* order of b/w/l is important! */
        Pn_negw,
        Pn_negl,

        Pn_movb,	/* order of b/w/l is important! */
        Pn_movw,
        Pn_movl,

        Pn_movsb,
        Pn_movzb,

        Pn_movsw,
        Pn_movzw,

	Pn_rep_movsb,
	Pn_rep_movsw,
	Pn_rep_movsl,

        Pn_cdq,

	Pn_float,

        Pn_fld,		/* order of (none), _l, _s is important! */
        Pn_fld_l,
        Pn_fld_s,
        Pn_fild,
        Pn_fldz,
        Pn_fld1,

        Pn_fxch,

        Pn_fldcw,
        Pn_fstcw,
        Pn_fstsw,

        Pn_fst,
        Pn_fst_l,
        Pn_fst_s,
        Pn_fistp,
        Pn_fstp,
        Pn_fstp_l,
        Pn_fstp_s,

        Pn_fcom,
        Pn_fcom_l,
        Pn_fcom_s,
        Pn_fcomp,
        Pn_fcomp_l,
        Pn_fcomp_s,
        Pn_fcompp,
        Pn_fcompp_l,
        Pn_fcompp_s,

        Pn_fadd,
        Pn_fadd_l,
        Pn_fadd_s,
        Pn_faddp,
        Pn_faddp_l,
        Pn_faddp_s,

        Pn_fsub,
        Pn_fsub_l,
        Pn_fsub_s,
        Pn_fsubr,
        Pn_fsubr_l,
        Pn_fsubr_s,
        Pn_fsubp,
        Pn_fsubp_l,
        Pn_fsubp_s,
        Pn_fsubrp,
        Pn_fsubrp_l,
        Pn_fsubrp_s,

        Pn_fmul,
        Pn_fmul_l,
        Pn_fmul_s,
        Pn_fmulp,
        Pn_fmulp_l,
        Pn_fmulp_s,

        Pn_fdiv,
        Pn_fdiv_l,
        Pn_fdiv_s,
        Pn_fdivr,
        Pn_fdivr_l,
        Pn_fdivr_s,
        Pn_fdivp,
        Pn_fdivp_l,
        Pn_fdivp_s,
        Pn_fdivrp,
        Pn_fdivrp_l,
        Pn_fdivrp_s,

        Pn_jecxz,

        Pn_last

#if 0
        Pn_aaa
        Pn_aad
        Pn_aam
        Pn_aas
        Pn_adc
        Pn_aaa
        Pn_arpl
        Pn_bound
        Pn_bsf
        Pn_bsr
        Pn_bswap
        Pn_bt
        Pn_btc
        Pn_btr
        Pn_bts
        Pn_cbw
        Pn_cwde
        Pn_clc
        Pn_cld
        Pn_cli
        Pn_clts
        Pn_cmc
        Pn_cmps
        Pn_cmpsb
        Pn_cmpsw
        Pn_cmpsd
        Pn_cmpxchg
        Pn_cmpxchg8b
        Pn_cpuid
        Pn_cwd
        Pn_daa
        Pn_das
        Pn_div
        Pn_enter
        Pn_f2xm1
        Pn_fabs
        Pn_fiadd
        Pn_fbld
        Pn_fbstp
        Pn_fchs
        Pn_fclex
        Pn_fnclex
        Pn_fcos
        Pn_fdecstp
        Pn_fidiv
        Pn_fidivr
        Pn_ffree
        Pn_ficom
        Pn_ficomp
        Pn_fincstp
        Pn_finit
        Pn_fninit
        Pn_fistp
        Pn_fldl2t
        Pn_fldl2e
        Pn_fldpi
        Pn_fldlg2
        Pn_fldln2
        Pn_fldenv
        Pn_fimul
        Pn_fnop
        Pn_fpatan
        Pn_fprem
        Pn_fprem1
        Pn_fptan
        Pn_frndint
        Pn_frstor
        Pn_fsave
        Pn_fnsave
        Pn_fscale
        Pn_fsin
        Pn_fsincos
        Pn_fsqrt
        Pn_fnstcw
        Pn_fstenv
        Pn_fnstenv
        Pn_fnstsw
        Pn_fisub
        Pn_fisubr
        Pn_ftst
        Pn_fucom
        Pn_fucomp
        Pn_fucompp
        Pn_fwait
        Pn_fxam
        Pn_fxtract
        Pn_fyl2x
        Pn_fyl2xp1
        Pn_hlt
        Pn_in
        Pn_ins
        Pn_insb
        Pn_insw
        Pn_insd
        Pn_int
        Pn_into
        Pn_invd
        Pn_invlpg
        Pn_iret
        Pn_iretd
        Pn_lahf
        Pn_lar
        Pn_lds
        Pn_les
        Pn_lfs
        Pn_lgs
        Pn_lss
        Pn_leave
        Pn_lgdt
        Pn_lidt
        Pn_lldt
        Pn_lmsw
        Pn_lock
        Pn_lods
        Pn_lodsb
        Pn_lodsw
        Pn_lodsd
        Pn_loop
        Pn_loopz
        Pn_loopnz
        Pn_lsl
        Pn_ltr
        Pn_movs
        Pn_movsd
        Pn_movsx
        Pn_movzx
        Pn_mul
        Pn_out
        Pn_outs
        Pn_outsb
        Pn_outsw
        Pn_outsd
        Pn_popa
        Pn_popad
        Pn_popf
        Pn_popfd
        Pn_pusha
        Pn_pushad
        Pn_pushf
        Pn_pushfd
        Pn_rcl
        Pn_rcr
        Pn_rol
        Pn_ror
        Pn_rdmsr
        Pn_rep
        Pn_repz
        Pn_repnz
        Pn_rsm
        Pn_sbb
        Pn_scas
        Pn_scasb
        Pn_scasw
        Pn_scasd
        Pn_setc
        Pn_setnc
        Pn_seto
        Pn_setno
        Pn_setp
        Pn_setnp
        Pn_sets
        Pn_setns
        Pn_sgdt
        Pn_sidt
        Pn_shld
        Pn_shrd
        Pn_sldt
        Pn_smsw
        Pn_stc
        Pn_std
        Pn_sti
        Pn_stos
        Pn_stosb
        Pn_stosw
        Pn_stosd
        Pn_str
        Pn_verr
        Pn_verw
        Pn_wait
        Pn_wbinvd
        Pn_wrmsr
        Pn_xadd
        Pn_xlat
        Pn_xlatb
#endif

} Pn_OPCODE;

typedef enum P_TARGET {

   /* Target_major */
	P_ATT,
	P_MASM,

   /* Target_minor */
	P_ATT_LINUX,
	P_ATT_LINUX_ELF,

	P_MASM_PHARLAP,
	P_MASM_WIN32,

	P_MASM_LAST

} P_TARGET;

extern char   **Pn_OPC;
extern int      PP_reverse_operand;
extern P_TARGET P_target;
extern int      P_target_minor;
extern char    *P_target_s;
extern char     P_target_mem1;
extern char     P_target_mem2;
extern char     P_target_local_prefix;
extern char     P_target_del;
extern int      P_att_lblofs;
extern char    *P_target_dirtBlock;

#define MAX_WIN32_HASH_TABLE            20

extern int P_hash_table_exist[MAX_WIN32_HASH_TABLE];
extern int P_hash_table_count;
extern char *P_hash_table_user_function_name;

char *P_add_extrn(char *lbl, int flg, int size);
void P_print_extrn(void);

extern int P_text_num,P_data_num,P_data1_num,P_bss_num,P_other_num;

extern char *P_dirtAlign;

char *sPrintf(char *buf, ...);

void P_add_comm(char *label, int size, int total);
void P_print_comm();

extern int P_literal_num;

extern char *P_literal_ary[];
extern int   P_literal_id[];

int  P_add_literal(char *name, int id);
void P_print_literal();
 
#endif
