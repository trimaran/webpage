/* IMPACT Public Release 1.00 / IMPACT Trimaran Release 1.00   Aug. 1, 1998  */
/* See www.crhc.uiuc.edu/Impact / www.trimaran.org for latest info.          */
/*****************************************************************************\ 
 * LICENSE AGREEMENT NOTICE
 * 
 * IT IS A BREACH OF THIS LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM
 * THE FILE OR SOFTWARE, OR ANY MODIFIED VERSIONS OF THIS FILE OR
 * SOFTWARE OR DERIVATIVE WORKS.
 * 
 * ------------------------------						
 * 
 * Copyright Notices/Identification of Licensor(s) of 
 * Original Software in the File
 * 
 * Copyright 1990-1998 The Board of Trustees of the University of Illinois
 * For commercial license rights, contact: Research and Technology
 * Management Office, University of Illinois at Urbana-Champaign; 
 * FAX: 217-244-3716, or email: rtmo@uiuc.edu
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------
 * 	
 * Copyright Notices/Identification of Subsequent Licensor(s)/Contributors 
 * of Derivative Works
 * 
 * Copyright  <Year> <Owner>
 * <Optional:  For commercial license rights, contact:_____________________>
 * 
 * 
 * All rights reserved by the foregoing, respectively.
 * 
 * ------------------------------						
 * 
 * The code contained in this file, including both binary and source 
 * [if released by the owner(s)] (hereafter, Software) is subject to
 * copyright by the respective Licensor(s) and ownership remains with
 * such Licensor(s).  The Licensor(s) of the original Software remain
 * free to license their respective proprietary Software for other
 * purposes that are independent and separate from this file, without
 * obligation to any party.
 * 
 * Licensor(s) grant(s) you (hereafter, Licensee) a license to use the
 * Software for academic, research and internal business purposes only,
 * without a fee.  "Internal business purposes" means that Licensee may
 * install, use and execute the Software for the purpose of designing and
 * evaluating products.  Licensee may submit proposals for research
 * support, and receive funding from private and Government sponsors for
 * continued development, support and maintenance of the Software for the
 * purposes permitted herein.
 * 
 * Licensee may also disclose results obtained by executing the Software,
 * as well as algorithms embodied therein.  Licensee may redistribute the
 * Software to third parties provided that the copyright notices and this
 * License Agreement Notice statement are reproduced on all copies and
 * that no charge is associated with such copies.  No patent or other
 * intellectual property license is granted or implied by this Agreement,
 * and this Agreement does not license any acts except those expressly
 * recited.
 * 
 * Licensee may modify the Software to make derivative works (as defined
 * in Section 101 of Title 17, U.S. Code) (hereafter, Derivative Works),
 * as necessary for its own academic, research and internal business
 * purposes.  Title to copyrights and other proprietary rights in
 * Derivative Works created by Licensee shall be owned by Licensee
 * subject, however, to the underlying ownership interest(s) of the
 * Licensor(s) in the copyrights and other proprietary rights in the
 * original Software.  All the same rights and licenses granted herein
 * and all other terms and conditions contained in this Agreement
 * pertaining to the Software shall continue to apply to any parts of the
 * Software included in Derivative Works.  Licensee's Derivative Work
 * should clearly notify users that it is a modified version and not the
 * original Software distributed by the Licensor(s).
 * 
 * If Licensee wants to make its Derivative Works available to other
 * parties, such distribution will be governed by the terms and
 * conditions of this License Agreement.  Licensee shall not modify this
 * License Agreement, except that Licensee shall clearly identify the
 * contribution of its Derivative Work to this file by adding an
 * additional copyright notice to the other copyright notices listed
 * above, to be added below the line "Copyright Notices/Identification of
 * Subsequent Licensor(s)/Contributors of Derivative Works."  A party who
 * is not an owner of such Derivative Work within the meaning of
 * U.S. Copyright Law (i.e., the original author, or the employer of the
 * author if "work of hire") shall not modify this License Agreement or
 * add such party's name to the copyright notices above.
 * 
 * Each party who contributes Software or makes a Derivative Work to this
 * file (hereafter, Contributed Code) represents to each Licensor and to
 * other Licensees for its own Contributed Code that:
 * 
 * (a) Such Contributed Code does not violate (or cause the Software to
 * violate) the laws of the United States, including the export control
 * laws of the United States, or the laws of any other jurisdiction.
 * 
 * (b) The contributing party has all legal right and authority to make
 * such Contributed Code available and to grant the rights and licenses
 * contained in this License Agreement without violation or conflict with
 * any law.
 * 
 * (c) To the best of the contributing party's knowledge and belief,
 * the Contributed Code does not infringe upon any proprietary rights or
 * intellectual property rights of any third party.
 * 
 * LICENSOR(S) MAKE(S) NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE
 * SOFTWARE OR DERIVATIVE WORKS FOR ANY PURPOSE.  IT IS PROVIDED "AS IS"
 * WITHOUT EXPRESS OR IMPLIED WARRANTY, INCLUDING BUT NOT LIMITED TO THE
 * MERCHANTABILITY, USE OR FITNESS FOR ANY PARTICULAR PURPOSE AND ANY
 * WARRANTY AGAINST INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS.
 * LICENSOR(S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS
 * OF THE SOFTWARE OR DERIVATIVE WORKS.
 * 
 * Any Licensee wishing to make commercial use of the Software or
 * Derivative Works should contact each and every Licensor to negotiate
 * an appropriate license for such commercial use, and written permission
 * of all Licensors will be required for such a commercial license.
 * Commercial use includes (1) integration of all or part of the source
 * code into a product for sale by or on behalf of Licensee to third
 * parties, or (2) distribution of the Software or Derivative Works to
 * third parties that need it to utilize a commercial product sold or
 * licensed by or on behalf of Licensee.
 * 
 * By using or copying this Contributed Code, Licensee agrees to abide by
 * the copyright law and all other applicable laws of the U.S., and the
 * terms of this License Agreement.  Any individual Licensor shall have
 * the right to terminate this license immediately by written notice upon
 * Licensee's breach of, or non-compliance with, any of its terms.
 * Licensee may be held legally responsible for any copyright
 * infringement that is caused or encouraged by Licensee's failure to
 * abide by the terms of this License Agreement.  
\*****************************************************************************/ 
/*****************************************************************************\
 *      File:   dd_lang-interf.h
 *      Author: Grant Haab and Wen-mei Hwu
\*****************************************************************************/


#ifndef DD_LANG_INTERF_H
#define DD_LANG_INTERF_H

#include <Pcode/dd_data-dep.h>
#include <Pcode/dd_acc-tbl.h>
#include <Pcode/dd_affine.h>
#define NOT_TINY 1
#ifndef SKIP_OMEGA2
#define SKIP_OMEGA2
#endif

/* define the type "a_access", which identifies an array access,
   and provides access to information about the access (such as
   its depth, line number, the symbol accessed, and the type of
   access (read or write)).

   It must also be possible to extract information about the
   subscript expressions used in the access, with "sub_i_for_access",
   information about the "context" of an access (the enclosing reads
   & writes), with "cont_i_for_access", and information about the
   output dependences from a write access, with "odd_i_for_write".

   Two a_accesses must be equal in a self-dependence test

   If there is no existing structure that provides all this information,
   you may need to create an aggregate with pointers to the different
   structures you use.
 */

#define access_as_string(A)  	((A)->text)  /* only used in debugging output */
#define accesss_sym(A)	     	((A)->sym_type->sym_entry) /* now obselete */
					/* used only in an assertion */ 

/* currently only in debugging output */
#define accesss_lineno(A)    	((A)->acc_expr->parentstmt->lineno)       

#define accesss_depth(A)     	((A)->access_depth)
#define access_fetch_p(A)    	((A)->is_fetch)
#define access_store_p(A) 	((A)->is_store)
#define access_next(A)		((A)->next_access)
#define access_done(A)		((A) == NIL)

/* can we execute A1 and then A2 without going to another iteration */
#define access_lexcally_preceeds(A1, A2, DT) \
			(DD_Access_Precedes_Within_Common_Loop(A1, A2, DT))

/* define the type "sub_iterator" - an iterator over the
   subscripts of an array access.  We need to test these
   subscripts to see if they are affine expressions of the
   loop index variables and symbolic constants, and if so,
   find the associated affine_expr structure.
   We also need to have access to all the variables used in
   the expression (for the purpose of building the set of
   variables used), via the function sub_i_map_over_cur_vars,
   which calls F(V,ARGS) for each variable V in the expression.
 */

#define sub_i_for_access(A)       	((A)->first_subi)
#define sub_i_next(SUBI)           	((SUBI) = (SUBI)->next)
#define sub_i_done(SUBI)           	((SUBI) == NIL)
#define sub_i_cur_is_affine(SUBI)  	((SUBI)->affexpr != &not_affine) 
#define sub_i_cur_affine(SUBI)     	((SUBI)->affexpr)

/* GEH - figure out how to map over variables, use those in affine expr? */
#define sub_i_map_over_cur_vars(SUBI,F,ARGS) 	\
	    if(sub_i_cur_is_affine(SUBI))map_over_vars((SUBI)->sub_expr,F,ARGS)


/* define the type "cont_iterator" - an iterator over the
   enclosing contexts of an array access.  Each cont_i_next
   operation must select the next enclosing loop or if.
   We must be able to tell which we have selected, and
   get a "loop_context" or "if_context" object from it.
 */

#define cont_i_for_access(A)	((A)->first_context)
#define cont_i_next(C)        	((C) = (C)->stmtstruct.parloop->parent)

/* GEH - loops at depth 1 must have null parent pointer during dep test*/
#define cont_i_done(C)          ((C) == NIL)

#define cont_i_cur_loop_p(C)    ((C)->type == ST_PARLOOP)
#define cont_i_cur_if_p(C)      ((C)->type == ST_IF)
#define cont_i_cur_if(C)        (C)	/* GEH - Not Implemented */
#define cont_i_cur_loop(C)    	((loop_context)((C)->ext))
#define cont_i_cur_depth(C)	((C)->stmtstruct.parloop->depth)
#define cont_i_cur_lineno(C)    ((C)->lineno)

/* Get var_id structure from Pcode variable expression */
#define	exprs_var_id(E)		((E)->acc)

/* a "loop_context" provides information about a loop.
   We need to be able to find affine_exprs for the start
   and end bounds (if a bound is not affine, we should
   get a result for which "is_affine" is false).
   We also need to know if there is a step expression,
   and whether it is known at compile time, and if so,
   what it is.  These last two must be answered by the
   function "loops_step(LOOP,S,KNOWN)", which sets *KNOWN
   to true if the step is known at compile time, and sets
   *S to the step if it is known.
   We must also be able to map a function over all the
   variables used in the start and end bounds (as we did
   for the variables used in the step expressions).
 */

#define loop_var_id(LOOP) \
	    (exprs_var_id((LOOP)->loop_stmt->stmtstruct.parloop->iteration_var))
#define loop_start(LOOP)         ((LOOP)->init_affexpr)
#define loop_end(LOOP)           ((LOOP)->final_affexpr)
#define loop_has_step_p(LOOP)    (TRUE)	
#define loops_depth(LOOP)	 ((LOOP)->loop_stmt->stmtstruct.parloop->depth)

#define loops_step(LOOP,S,KNOWN)  \
	(evaluate((LOOP)->loop_stmt->stmtstruct.parloop->incr_value, S, KNOWN))

#define loop_map_over_start_vars(LOOP,F,ARGS) \
	if(is_affine(loop_start(LOOP)))\
	map_over_vars((LOOP)->loop_stmt->stmtstruct.parloop->init_value,F,ARGS)

#define loop_map_over_end_vars(LOOP,F,ARGS) \
	if(is_affine(loop_end(LOOP)))\
	map_over_vars((LOOP)->loop_stmt->stmtstruct.parloop->final_value,F,ARGS)

typedef void (*map_fn) (var_id v, void *args);
extern void map_over_vars(Expr expr, map_fn f, void *args);

/* define the type used to identify a variable (typically
   a pointer into the symbol table or some such).
   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  
   GEH - not true! Need dynamically changing entity.

   It must be possible to tell the difference between a loop
   index and a symbolic constant, and for a loop index, we must
   be able to find the depth of the loop.
   We must also be able to associate a integer "tag" with each
   variable - all tags must start out with the value UNTAGGED.
 */

/* AE_VAR is really a pointer to an _a_access structure */
#define var_id_const_p(AE_VAR)	(!((AE_VAR)->is_index))
#define var_id_index_p(AE_VAR)	((AE_VAR)->is_index)
#define var_ids_loop_no(AE_VAR)	((AE_VAR)->index_depth)
#define var_ids_tag(AE_VAR)	((AE_VAR)->sym_type->sym_entry->tag)
#define var_ids_name(AE_VAR)	((AE_VAR)->sym_type->sym_entry->var_name)
#endif
