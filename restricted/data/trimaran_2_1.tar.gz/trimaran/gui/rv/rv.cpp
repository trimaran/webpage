/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   rv.cpp (Rebel Viewer)
// Author: Suren Talla
///////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <fcntl.h>
#include <sys/unistd.h>
#include <stdlib.h>

#include "ir_region.h"
#include "dlist.h"
#include "ir_op.h"
#include "ir_edge.h"
#include "IR_symbol.h"
#include "meld.h"
#include "el_jumptbl.h"
#include <iostream.h>
#include "el_io.h" 
#include "el_data.h"
#include "el_args.h"
#include "el_init.h"
#include "el_error.h"
#include "ir_reader.h"
#include "region_purge.h"
#include "adjlist_graph.h"
#include "iterators.h"
#include "pred_analysis.h"
#include "flow_analysis_solver.h"
#include "edge_drawing.h"
#include "opcode_properties.h"

#include "rv.h"
#include "rv_resources.h"


#define FALSE  0
#define TRUE   1
#define Bool   bool


const char Q = '"';

//------------------------------------------------------------

long int gTemperatureRange[] = {
  -1,
  0,   
  2,     
  4,     
  8,   
  16,     
  32,      
  64, 
  128,
  256,
  512,
  1024,
  2048,
  4096,
  8182,
  16364,
  32728,
  65456,
  130912,
  261824,
  523648,
  1047296,
  2094582,
  4189164
};


char* gMacroNames[] = {
  "un",             // 0
  "local",          // 1
  "param",          // 2
  "swap",           // 3
  "irettyp",        // 4
  "frettyp",        // 5
  "drettyp",        // 6
  "iret",           // 7
  "intp1",          // 8
  "intp2",          // 9
  "intp3",          // 10
  "intp4",          // 11
  "fret",           // 12
  "fltp1",          // 13
  "fltp2",          // 14
  "fltp3",          // 15
  "fltp4",          // 16
  "dret",           // 17
  "dblp1",          // 18
  "dblp2",          // 19
  "int_tm_type",    // 20	/* int thru memory parameter */
  "flt_tm_type",    // 21	/* int thru memory parameter */
  "dbl_tm_type",    // 22       /* int thru memory parameter */
  "sp",		    // 23	/* stack pointer */
  "fp",		    // 24	/* frame pointer */
  "ip",		    // 25	/* pointer to incoming parameter space */
  "op",		    // 26	/* pointer to outgoing parameter space */
  "lv",		    // 27	/* pointer to local variable space     */
  "rgs",	    // 28	/* pointer to register swap space      */
  "lc",		    // 29	/* loop counter */
  "esc",	    // 30	/* epilogue stage counter */
  "all_p",  	    // 31	/* refers to the entire predicate register file */
  "all_rp",	    // 32	/* all the rotating predicate regs */
  "all_sp",	    // 33       /* all the non-rotating predicate regs */
  "rrb",            // 34
  "ret_addr",       // 35
  "flt_0",          // 36
  "flt_1",          // 37
  "dbl_0",          // 38
  "dbl_1",          // 39
  "int_0",          // 40
  "pred_f",         // 41
  "pred_t",         // 42
  "sp_reg",         // 43
  "last_macro"		/* insert all macros before this one! */
};

//------------------------------------------------------------
char*  gRegionLabels[] = {
  BB_REGION, 
  HB_REGION, 
  PROC_REGION, 
  LOOP_REGION, 
  COMP_REGION,
  OP_REGION
};


//------------------------------------------------------------
IR_outstream *gdl_stream = NULL;
IR_instream  *rebel_stream = NULL;
int    gDataListCounter;
int    gProcedureCounter;

char*  gBlankStrings[] = {
  "", 
  " ", 
  "  ", 
  "   ", 
  "    ", 
  "     ", 
  "      ",
  "       ",
  "        ",
  "         ",
  "          ",
  "           ",
  "            ",
  "             ",
  "              ",
  "               ",
  "                ",
  "                 ",
  "                  ",
  "                   ",
  "                    ",
  "                     ",
  "                      ",
  "                        ",
  "                         ",
  "                          ",
  "                           ",
  "                            ",
  "                             ",
  "                              ",
  "                               ",
  "                                ",
  "                                 ",
  "                                  ",
  "                                   "
};

Hash_map<Opcode, eString> el_opcode_to_symbol_map(hash_opcode, 10000) ;
Hash_map<IR_BASE_OPCODE, eString> el_base_opcode_to_symbol_map(hash_IR_BASE_OPCODE, 200) ;

  
//------------------------------------------------------------
//  variables for command line options to the rebel-viewer
//------------------------------------------------------------
char*  El_output_graph_type;
char*  El_ir_scope;
char*  El_procedure_name;

int    El_bb_no ;
int    El_op_info_format;
int    El_compute_liveness;
int    El_color_code;
int    El_write_dictionaries;

int El_geom_x=800, El_geom_y=800;

//------------------------------------------------------------
int read_line(int fd, char* buf, char stop_char)
{
  int n, sum=0;
  char c;
  do {
    n = read(fd, buf, 1);
    sum += n;
  } 
  while (n>0 && *buf++ != stop_char);
  return sum;
}

//------------------------------------------------------------
int all_hbs_bbs(Procedure* f, Dlist<Region*>& hb_bb_list)
{
  Dlist<Region*> rstack;
  rstack.push(f);

  while(!rstack.is_empty()){
    Region* r = rstack.pop();
    
    if (r->is_bb() || r->is_hb()){
      hb_bb_list.push(r);
    } else if (r->is_compound()){
      for (Region_subregions subri(r); subri!=0; subri++) {
	Region* subr = *subri;
	if (*subri == r) continue;
	rstack.push(subr);
      }
    } else {
      cerr << "unknown region type!!\n";
    }
    
  }
  return hb_bb_list.size();

}

//------------------------------------------------------------
int main(int argc, char **argv, char** envp)
{
  main_rview(argc,argv,envp);
  return (0);
}

//------------------------------------------------------------
//     MAIN DRIVER FOR REBEL_VIEWER
//------------------------------------------------------------
int main_rview(int argc, char **argv, char** envp){
  
    El_Arg arg[EL_MAX_ARG];
    int n_arg, i, j;
    Parm_Macro_List *external_list;
    int read_i, read_o;
    Bool rv_error = FALSE;

    external_list = L_create_external_macro_list (argv, envp);
    El_parm_file_name = L_get_std_parm_name (argv, envp, "ELCOR_PARMS_FILE", "./ELCOR_PARMS");
    L_load_parameters (El_parm_file_name, external_list, "(Elcor_Global", El_read_parm_global);
    L_load_parameters (El_parm_file_name, external_list, "(Elcor_Architecture", El_read_parm_arch);
    L_load_parameters (El_parm_file_name, external_list, "(Elcor_IO", El_read_parm_io);
    El_init_all(external_list);
    
    /* init command line variables */
    El_ir_scope = NULL;
    El_output_graph_type = NULL;
    El_procedure_name = NULL;
    El_bb_no = 0;
    El_op_info_format = 0;
    El_compute_liveness = 0;
    El_color_code = 0;
    El_write_dictionaries = 0;
    
    /* Mark that we have not read the input or output file yet */
    read_i = 0;
    read_o = 0;
    
    
    /* Process the  command line arguments */
    n_arg = El_get_arg(argc-1, argv+1, arg, EL_MAX_ARG);
    for (i=0; i < n_arg; i++) {
	
	char *option;
	option = arg[i].name;
	
	/* Get input file name */
	if (! strcmp(option, "-i")) {
	    
	    /* Punt if input file specified twice */
	    if (read_i)
		El_punt ("main: Parsing command line: -i specified twice.\n");
	    
	    /* Make sure file name specified */
	    if (arg[i].count < 1)
		El_punt("main: Parsing command line: -i needs input_file_name.");
	    /* Make sure that only one file name specified */
	    if (arg[i].count > 1) {
		
		fprintf (stderr, "Error parsing command line: -i");
		for (j = 0; j < arg[i].count; j++)
		    fprintf (stderr, " %s", arg[i].value[j]);
		fprintf (stderr, "\n");
		El_punt ("main: Cannot specify more than one input file with -i.");
	    }
	    
	    El_input_file_name = strdup(arg[i].value[0]);
	    cerr << "input file = " << El_input_file_name << endl;
	    
	    /* Mark that we have read an input file name */
	    read_i = 1;
	    
	} else if (! strcmp(option, "-o")) {  /* Get output file name */
	    
	    /* Punt if output file specified twice */
	    if (read_o)
		El_punt ("main: Parsing command line: -o specified twice.\n");
	    
	    /* Make sure file name specified */
	    if (arg[i].count < 1)
		El_punt("main: Parsing command line: -o needs output_file_name.");
	    /* Make sure only one file name specified */
	    if (arg[i].count > 1) {

		fprintf (stderr, "Parsing command line: -o");
		for (j = 0; j < arg[i].count; j++)
		    fprintf (stderr, " %s", arg[i].value[j]);
		fprintf (stderr, "\n");
		El_punt ("main: Cannot specify more than one output file with -o.");
	    }
	    
	    El_output_file_name = strdup(arg[i].value[0]);
	    cerr << "output file = " << El_output_file_name << endl;
	    
	    /* Mark that we have read an output file */
	    read_o = 1;
	    
	} else if (! strcmp(option, "-t")){
	    El_output_graph_type = strdup(arg[i].value[0]);
	    cerr << "graph type = " << El_output_graph_type << endl;
	} else if (! strcmp(option, "-s")){
	    El_ir_scope = strdup(arg[i].value[0]);
	    cerr << "ir scope = " << El_ir_scope << endl;
	} else if (! strcmp(option, "-f")){
	    El_procedure_name = strdup(arg[i].value[0]);
	    cerr << "procedure = " << El_procedure_name << endl;
	} else if (! strcmp(option, "-b")){
	    El_bb_no = atoi(arg[i].value[0]);
	    cerr << "bb no = " << El_bb_no << endl;
	} else if (! strcmp(option, "-k")){
	    El_op_info_format = atoi(arg[i].value[0]);
	    cerr << "extra op info  = " << El_op_info_format << endl;
	} else if (! strcmp(option, "-d")){
	    El_write_dictionaries = atoi(arg[i].value[0]);
	    cerr << "extra op info y/n = " << El_write_dictionaries << endl;
	} else if (! strcmp(option, "-l")){
	    El_compute_liveness = atoi(arg[i].value[0]);
	    cerr << "compute liveness y/n = " << El_compute_liveness << endl;
	} else if (! strcmp(option, "-c")){
	    El_color_code = atoi(arg[i].value[0]);
	    cerr << "color code y/n = " << El_color_code << endl;
	} else if (! strcmp(option, "-x")){
	    El_geom_x = atoi(arg[i].value[0]);
	    cerr << "geometry X = " << El_geom_x << endl;
	} else if (! strcmp(option, "-y")){
	    El_geom_y = atoi(arg[i].value[0]);
	    cerr << "geometry Y = " << El_geom_y << endl;
	}
	
    }
    
    /* check consistency of command line options */
    if (options_consistent() == 0)
	El_punt("main_rview: invalid command line options.\n");
    
    
    el_init_elcor_opcode_to_symbol_maps();
    
    rebel_stream = new IR_instream(El_input_file_name); 
    gdl_stream = new IR_outstream(El_output_file_name);
    
    //call the rebel to gdl translator depending on options;
    if (! strcmp(El_output_graph_type, "rh")){
	cerr << "computing the region hierarchy..." << endl;
	region_hierarchy_to_gdl(*rebel_stream, *gdl_stream);
    } else if (! strcmp(El_output_graph_type, "ddg")){
	cerr << "computing the data dependence graph..." << endl;
	ddg_to_gdl(*rebel_stream, *gdl_stream);
    } else if (! strcmp(El_output_graph_type, "cfg")){
	cerr << "computing the control flow graph..." << endl;
	cfg_to_gdl(*rebel_stream, *gdl_stream, El_procedure_name);
    } else if (! strcmp(El_output_graph_type, "sched")){
	cerr << "computing the schedule..." << endl;
	sched_to_gdl(*rebel_stream, *gdl_stream);
    } else if (! strcmp(El_output_graph_type, "stats")){
	cerr << "computing the stats display..." << endl;
	int cyc_count = stats_to_gdl();
	if (cyc_count==0) {
	  cerr << "cannot display execution profile : the rebel file has no profile weights!\n";
	  rv_error = TRUE;
	}
    } else if (! strcmp(El_output_graph_type, "names")){
	cerr << "output: names/block-ids..." << endl;
	names_to_gdl(*rebel_stream, *gdl_stream);
	rv_error = TRUE;
    } else if (! strcmp(El_output_graph_type, "misc")){
	cerr << "misc elcor testing..." << endl;
	elcor_misc_to_gdl(*rebel_stream, *gdl_stream);
    } else {
	cerr << "ERROR:: illegal value for option -t" << endl;
	rv_error = TRUE;
    }
    
    delete gdl_stream;
    delete rebel_stream;
    
    //invoke xvcg to display the graph;
    char cmd[200];
    if (!rv_error){
      sprintf(cmd, "xvcg -geometry %dx%d %s", El_geom_x, El_geom_y, El_output_file_name);
      system(cmd);  
    }
    return 1;
}




//------------------------------------------------------------
//          This routine to test misc elcor modules
//------------------------------------------------------------

IR_outstream& 
elcor_misc_to_gdl(IR_instream& in, IR_outstream &out)
{

  Bool procedure_found = FALSE;
  Procedure* f;
  
  while ((ir_read(in) != EL_INPUT_EOF) && !procedure_found) {
    
    switch (El_input_type) {
    case EL_INPUT_EOF:
      break;
    case EL_INPUT_DATA:   
      {
	  El_datalist *D = (El_datalist *) El_input;
	  delete D;
      }
      break;
    case EL_INPUT_CODE:
      {
	f = (Procedure *) El_input;
	
	if (strcmp(El_procedure_name, (char*)(f->get_name())) ==0)
	  procedure_found = TRUE;
	else {
	  /* Deallocate the Elcor procedure */
	  region_purge (f);
	}
      }
    break;
    default:
      El_punt("El_process_input: illegal token");
    }
  }
  
  Basicblock *entry_bb;
  Hyperblock *hb;
  Hash_set<Basicblock*> hb_bbs;
  Hash_set<Hyperblock*> all_hbs;
  Bool push_flag;
  Dlist<Region*> rstack;
  Region *rtmp;
  Compound_region *new_hb;
  

  // First find all the HBs in f and add them to set all_hbs
  rstack.push(f);
  while (! rstack.is_empty()) {
    rtmp = rstack.pop();
    push_flag = TRUE;
    if (rtmp->is_hb()) {
      all_hbs += ((Hyperblock *) rtmp);
      push_flag = FALSE;  // Only ops below, so don't waste time!
    }
    else if (rtmp->is_bb()) {
      push_flag = FALSE;  // Only ops below, so don't waste time!
    }
    if (push_flag==TRUE) {
      for (Region_subregions subri(rtmp); subri!=0; subri++) {
	if ((*subri)->is_compound())
	  rstack.push(*subri);
      }
    }
  }

  //proc_cfg_to_gdl(out, f);

  for (Hash_set_iterator<Hyperblock*> hseti(all_hbs); hseti!=0; hseti++) {
    hb = *hseti;
    hb_bbs.clear();
    //El_find_bbs_in_hb(hb, &entry_bb, hb_bbs);
  
  }

  /* Deallocate the Elcor procedure */
  region_purge (f);
  return out;
}

//------------------------------------------------------------
//               Procedure names and block-ids output routine
//------------------------------------------------------------

IR_outstream& 
names_to_gdl(IR_instream& in, IR_outstream &out)
{

  while (ir_read(in) != EL_INPUT_EOF) {
    switch (El_input_type) {
    case EL_INPUT_EOF:
      break;
    case EL_INPUT_DATA:   
      {
	  El_datalist *D = (El_datalist *) El_input;
	  delete D;
      }
      break;
    case EL_INPUT_CODE:
      {
	Procedure* region = (Procedure *) El_input;
	out << "FUNCTION " << (char*)(((Procedure*)region)->get_name()) << endline;
        for (Region_subregions subri(region); subri!=0; subri++) {
	  Region* subr = *subri;
	  if (subr->is_bb()){
	    out << "BB" << subr->id() << endline;
	  } else if (subr->is_hb()){
	    out << "HB" << subr->id() << endline;
	  } 
	}
	/* Deallocate the Elcor procedure */
	region_purge (region);
      }
    break;
    default:
      El_punt("El_process_input: illegal token");
    }
  }

  return out;
}


//------------------------------------------------------------
//               Procedure output routine
//------------------------------------------------------------

IR_outstream& 
cfg_to_gdl(IR_instream& in, IR_outstream &out, char* procedure_name)
{

  Bool procedure_found = FALSE;
  Region* region;

  if (! strcmp(El_ir_scope, "all") ){
    out << "graph: { title: " << Q << El_input_file_name << Q << endline;

    if (El_color_code){
      dump_extra_color_entries(out);
    }

  }

  while (ir_read(in) != EL_INPUT_EOF) {
    
    switch (El_input_type) {
    case EL_INPUT_EOF:
      break;
    case EL_INPUT_DATA:   
      {
	El_datalist *D = (El_datalist *) El_input;
        delete D;
	// The following is not necessary in a cfg graph - RMR 7/14/99 
	// if (! strcmp(El_ir_scope, "all") ) {
	//  El_datalist *D = (El_datalist *) El_input;
	//  datalist_to_gdl(out, D);
	//  delete D;
	//  gDataListCounter++;
	// }
      }
    break;
    case EL_INPUT_CODE:
      {
	region = (Region *) El_input;
	procedure_found = TRUE;
	if (! strcmp(El_ir_scope, "proc") ){
	  procedure_found = FALSE;
	  if (! strcmp(procedure_name, (char*)(((Procedure*)region)->get_name())))
	    procedure_found = TRUE;
	}

	if (procedure_found)
	  proc_cfg_to_gdl(out, (Procedure*)region);

	/* Deallocate the Elcor procedure */
	region_purge (region);
	
      }
    break;
    default:
      El_punt("El_process_input: illegal token");
    }
  }

  if (! strcmp(El_ir_scope, "all") ){
    out << R_CURLY << endline;
  }


  return out;
}



//------------------------------------------------------------
//               Procedure output routine
//------------------------------------------------------------

IR_outstream& 
proc_cfg_to_gdl(IR_outstream &out, Procedure* f)
{
  char* procedure_name = (char*)(f->get_name());
  cerr << "\nprocessing procedure = " << procedure_name << endl;

  IR_token::init_pointer_map();
  op_table.reset();
  out.reset_maps();

  name_edges(out, f);
  name_attributes(out, f);

  
  //compute liveness info for the procedure if nec;
  if (El_compute_liveness){
    create_local_analysis_info_for_all_hbs_bbs((Compound_region*)f);
    el_flow_compute_liveness(f, ANALYZE_ALLREG);
  }
  
  //start a subgraph for the procedure;
  out << "graph: { title: " 
      << Q << (char*)(f->get_name()) << Q << endline
      << "node.color : lightgreen" << endline
      << "edge.backarrowcolor : red" << endline
      << "edge.backarrowsize : 3" << endline;

  if (El_color_code && (! strcmp(El_ir_scope, "proc"))){
    dump_extra_color_entries(out);
  }


  out << "label: " << endline
      << Q << REGION_WEIGHT_STRING 
      << L_PAREN << ((Compound_region*)f)->weight
      << R_PAREN << endline << tab;

  // disabled since in the new version there is no way to print;
  // the region flags;
  // region flags;
  //if (((const Compound_region*)f)->region_flags.ones_count() > 0)
  //  out << ((const Compound_region*)f)->region_flags << endline << tab;


  // print procedure attributes;
  Lcode_attribute_map *map = get_lcode_attributes((Region*)f);
  if ((map && !map->is_empty()) ||
      (has_ms_constraints((Compound_region*)f))) {
    out << ATTR_STRING << L_PAREN;
    if (map && !map->is_empty())
      out << map;
    if (has_ms_constraints((Compound_region*)f)) {
      MS_constraints *ms = get_ms_constraints((Compound_region*)f);
      out << ms;
    }
    out << R_PAREN << endline << tab;
  }
  out << Q << endline;
 
  double max_freq = region_max_freq(f);

  {
    //Dlist<Region*> rstack;
    Dlist<Region*> hb_bb_list;
    all_hbs_bbs(f, hb_bb_list);

    Dlist_iterator<Region*> region_ptr;
    for(region_ptr(hb_bb_list); region_ptr != 0; region_ptr++){
      Region* rgn = *region_ptr;
      const Compound_region &crgn = (const Compound_region &) (*rgn);
      region_to_gdl(out, (char*)(f->get_name()), rgn, max_freq);
    }


    //print all the edges between the BB's/HB's of the procedure;
    for(region_ptr(hb_bb_list); region_ptr !=0; region_ptr++) {
      Region* src_rgn = *region_ptr;
	
      for(Region_exit_edges exit_edges(src_rgn); exit_edges != 0; exit_edges++){
	Edge* e = *exit_edges;
	Region* dest_rgn = e->dest()->parent();
	Region* src_rgn = e->src()->parent();
	Control_flow_freq *cfreq = get_control_flow_freq(e);
	
	if (dest_rgn->id() == src_rgn->id()){
	  //print backedge ;
	  out << "backedge: { sourcename: " << Q  << (char*)(f->get_name())
	      << "." << src_rgn << Q << TAB << endline 
	      << "targetname: " << Q  << (char*)(f->get_name())
	      << "." << dest_rgn << Q << TAB << endline 
	      << "label: " << Q << "\fb" << cfreq->freq << Q
	      << "color: red "
	      << "thickness: 3 "
	      << "anchor: 1 "
	      << R_CURLY << endline;
	} else {
	  //print edge ;
	  out << "edge: { sourcename: " << Q << (char*)(f->get_name()) 
	      << "." << src_rgn << Q << TAB << endline 
	      << "targetname: " << Q << (char*)(f->get_name())
	      << "." << dest_rgn << Q << TAB << endline 
	      << "label: " << Q << "\fb" << cfreq->freq << Q
	      << R_CURLY << endline;
	}
      }
    }


    if (El_write_dictionaries){
      // write edge dictionary;
      out << "node: {  title: " << Q << (char*)(f->get_name()) << ".edges" << Q << endline
	  << " color : lightyellow" << endline;
      out << "label: " << endline;
      out << Q << EDGE_DICT_STRING << SPACE << L_PAREN << indent;
      print_edges(out, f);
      out << outdent << endline << R_PAREN << Q << endline << endline;
      out << R_CURLY << endline;
      
      // write attributes dictionary;
      out << "node: {  title: " << Q << (char*)(f->get_name()) << ".attributes" << Q << endline
	  << " color : lightcyan" << endline;
      out << "label: " << endline;
      out << Q << ATTR_DICT_STRING << SPACE << L_PAREN << indent << endline << tab;
      //print_attributes(out, f);
      out << outdent << endline  << R_PAREN << Q << endline << endline;
      out << R_CURLY << endline;
      
      // write mem_vrs dictionary;
      out << "node: {  title: " << Q << (char*)(f->get_name()) << ".mem_vrs" << Q << endline
	  << " color : lightred" << endline;
      out << "label: " << endline;
      out << Q << MEMVR_DICT_STRING << SPACE << L_PAREN << indent << endline << tab;
      print_mem_vrs(out, f);
      out << outdent << endline  << R_PAREN << Q << endline;
      out << R_CURLY << endline;
      
      // write out jump tables;
      if (f->is_procedure() && El_proc_has_jump_tables(f)) {
	out << "node: {  title: " << Q << (char*)(f->get_name()) << ".jumptbl" << Q << endline;
	out << "label: " << endline;
	out << Q << JUMPTBL_DICT_STRING << SPACE << L_PAREN  << endline;
	print_jump_tables(out, f);
	out  << endline  << R_PAREN << Q << endline;
	out << R_CURLY << endline;
      }
    }

  }

  //end the procedure subgraph;
  out << R_CURLY << endline;

  if (El_compute_liveness){
    el_flow_delete_liveness(f);
    delete_local_analysis_info_for_all_hbs_bbs(f);
  }

  return out;
}


//---------------------------------------------------------------
//               region to GDL routine
//---------------------------------------------------------------
IR_outstream& region_to_gdl(IR_outstream &out, char* procedure_name,
			    Region *region, double max_freq)
{
  
  //double max_freq = region_max_freq(f);
  double freq = ((Compound_region*)region)->weight;
  const Compound_region &crgn = (const Compound_region &) (*region);

  out << "node: { title: " << Q << procedure_name << "." << region << Q << endline;

  if (El_color_code){
    out << "color: " << region_freq_color(freq, max_freq) << endline;
  }
  out << "label: " << endline << Q;
  out << "ID = " << region->id() << endline << tab;
  out << REGION_WEIGHT_STRING << L_PAREN 
      << freq << R_PAREN << endline << tab;
  // region flags;
  //if (region->region_flags.ones_count() > 0)
  //  out << region->region_flags << endline << tab;
  
  // attributes;
  Lcode_attribute_map *map = get_lcode_attributes(region);
  if ((map && !map->is_empty()) ||
      (has_ms_constraints((Compound_region*)region))) {
    out << ATTR_STRING << L_PAREN;
    if (map && !map->is_empty())
      out << map;
    if (has_ms_constraints((Compound_region*)region)) {
      MS_constraints *ms = get_ms_constraints((Compound_region*)region);
      out << ms;
    }
    out << R_PAREN << endline;
  }


  // Write out all the ops of the region;
  
  Region_all_ops op_iter ;
  for(op_iter(region) ; op_iter != 0 ; op_iter++ ) {
    Op* op = *op_iter ;
    
    switch(El_op_info_format){
    case OP_INFO_LONG_FORM:
      op_to_gdl(out, *op);
      break;
    case OP_INFO_SHORT_FORM:
      out << op;
      break;
    case OP_INFO_ASM_FORM:
      {
	if (is_dummy_branch(op) || is_control_merge(op) 
	    || is_merge(op) || is_pseudo(op)) 
	  break;;
	op_to_asm_to_gdl(out, *op);
      }
      break;
    default:
      break;
    }
    out << endline;
  }

  out << Q << endline;  //end of "label:"


  //show liveouts on left mouse click;
  if (El_compute_liveness){
    out << "info1: " << endline << Q << "live outs = \n";
    for(Region_exit_edges rgn_exit_edges(region); 
	rgn_exit_edges != 0; rgn_exit_edges++){
      Edge* e = *rgn_exit_edges;
      Liveness_info* liveness = get_liveness_info(e);
      if (liveness) {
	liveness_to_gdl(out, liveness);
      }
    }
    out << Q << endline;
      
    //show livein's on middle mouse click;
    out << "info2: " << endline << Q << "live ins = \n";
    for(Region_entry_edges rgn_entry_edges(region); 
	rgn_entry_edges != 0; rgn_entry_edges++){
      Edge* e = *rgn_entry_edges;
      Liveness_info* liveness = get_liveness_info(e);
      if (liveness) {
	liveness_to_gdl(out, liveness);
      }
    }
    out << Q << endline;
  }

  out << R_CURLY << endline;
  
  return out;
}

//---------------------------------------------------------------
//               Liveness to GDL routine
//---------------------------------------------------------------
//#ifdef LIVENESS
IR_outstream& liveness_to_gdl(IR_outstream &out, Liveness_info* liveness)
{
  Liveness_info_iterator li;
  for(li(*liveness); li != 0; li++){
    Operand& oper = *li;
    //to check what kind of operand it is later on;
    operand_to_gdl(out, oper);
    out << endline;
  }
  return out;

}
//#endif

//---------------------------------------------------------------
//               op output routines
//---------------------------------------------------------------
IR_outstream& op_to_gdl(IR_outstream &out, const Op &op)
{
   int port ;
   // Write out a "pointer" to and "body" of an op;

   // Pointer; start body; id; opcode;
   out << &op << SPACE << L_PAREN 
       << (char *) el_opcode_to_string_map.value(op.opcode()) << SPACE;
   
   // Dest operands;
   out << L_BRACKET;
   for (port = int(op.first_dest()); port <= int(op.last_dest()); port++){
     //out << op.dest(Port_num(port));
     operand_to_gdl(out, op.dest(Port_num(port)));
   }
   out << R_BRACKET << SPACE;
   
   // Src operands;
   out << L_BRACKET;
   for (port = int(op.first_src()); port <= int(op.last_src()); port++) {
     //out << op.src(Port_num(port));
     operand_to_gdl(out, op.src(Port_num(port)));
   }
   out << R_BRACKET << SPACE;
    
   // Optional fields (not written if they have default values);
   if (op.predicated()) out << op.src(PRED1);
   if (op.sched_time()!=-1) out << SCHED_TIME_STRING << L_PAREN
				<< op.sched_time() << R_PAREN;

   out << R_PAREN;
   /*
   if (strlen(((char *)(op.sched_opcode()))) > 0) out 
     << SCHED_OPCODE_STRING << L_PAREN << (char *)(op.sched_opcode())
     << R_PAREN;
   if ((op.related_ops) && (op.related_ops->size() > 0)) {
     out << RELATED_OPS_STRING << L_PAREN;
     for(List_iterator<Op*> ptr(*op.related_ops);  ptr != 0;  ptr++)
       out << (*ptr)->id();
     out << R_PAREN;
   }
   */
    
   return out;
}



//---------------------------------------------------------------
//              operand -> gdl translator
//---------------------------------------------------------------
IR_outstream&  operand_to_gdl(IR_outstream &out, Operand &oper)
{
  char buf[512];

    // Write out an operand;
    Operand &op = oper;

     const Base_operand& operand = *op.get_ptr(); //sptr->optr ;
    if (operand.is_int())
	out << operand.data_type() << L_ANGLE
	    << ((const Int_lit&) operand).value() << R_ANGLE;
    else if (operand.is_predicate())
	out << operand.data_type() << L_ANGLE
	    << (((const Pred_lit&) operand).value() ? 't' : 'f') << R_ANGLE;
    else if (operand.is_float())
	out << operand.data_type() << L_ANGLE
	    << ((const Float_lit&) operand).value() << R_ANGLE;
    else if (operand.is_double())
	out << operand.data_type() << L_ANGLE
	    << ((const Double_lit&) operand).value() << R_ANGLE;
    else if (operand.is_string()) {
      sprintf(buf, "%s" , (char*)((const String_lit&)operand).value());
      int len = strlen(buf);
      buf[len-1]  = '\0';
      out << (char*)(buf+1);
      //out << STRING_OPERAND_STRING << COLON << operand.data_type() << L_ANGLE
      //<< BACK_SLASH << (char*)((const String_lit&)operand).value() 
      //<< BACK_SLASH 
      //<< R_ANGLE;
    } else if (operand.is_label())
	out << LABEL_OPERAND_STRING << COLON << operand.data_type() << L_ANGLE
	    << (char*)((const Label_lit&)operand).value() << R_ANGLE;
    else if (operand.is_cb())
	out << operand.data_type() << L_ANGLE
	    << ((const Cb_operand&) operand).id() << R_ANGLE;
    else if (operand.is_undefined())
	out << UNDEFINED_OPERAND_STRING << L_ANGLE << R_ANGLE;
    else if (operand.is_macro_reg()) {
	const Macro_reg &reg = (const Macro_reg&) operand;
	out << MACRO_OPERAND_STRING << L_ANGLE << reg.name() << R_ANGLE;
    } else if (operand.is_reg()) {
	const Reg &reg = (const Reg&) operand;
	if (reg.assigned_to_file() && reg.allocated())
	    out << BOUND_REG_OPERAND_STRING << L_ANGLE
		<< reg.vr_num();	// fully bound register;
	else if (reg.assigned_to_file() && !reg.allocated())
	    out << FILEBOUND_REG_OPERAND_STRING << L_ANGLE
		<< reg.vr_num();	// file bound register;
	else
	    out << UNBOUND_REG_OPERAND_STRING << L_ANGLE
		<< reg.vr_num();	// unbound register;
	if (reg.omega() != 0)
	    out << L_BRACKET << reg.omega() << R_BRACKET;
	out << COLON << reg.data_type();
	if (reg.assigned_to_file() && reg.allocated()) {
	    out << reg.file_type();
	    if (reg.is_rotating())
                out << ROTATING_OPERAND_STRING;
	    out << reg.mc_num();
	    out << R_ANGLE;
	}
	else if (reg.assigned_to_file() && !reg.allocated()) {
	    out << reg.file_type();
	    if (reg.is_rotating())
		out << ROTATING_OPERAND_STRING;
	    out << R_ANGLE;
	}
	else
	    out << R_ANGLE;
    } else if (operand.is_mem_vr()) {
	const Mem_vr &reg = (const Mem_vr&) operand;
	out << MEMVR_OPERAND_STRING << L_ANGLE << reg.vr_num();
	if (reg.omega() != 0)  out << L_BRACKET << reg.omega() << R_BRACKET;
	out << R_ANGLE;
    } else if (operand.is_vr_name()) {
	const VR_name &reg = (const VR_name&) operand;
	out << VR_NAME_OPERAND_STRING << L_ANGLE << reg.vr_num() <<
		COLON << reg.data_type() << R_ANGLE;
    } else {
	cerr << "unknown operand type" << endl;
	exit(1);
    }
    return out;
}


//---------------------------------------------------------------
//               El_datalist output routines
//---------------------------------------------------------------
IR_outstream& datalist_to_gdl(IR_outstream &out, El_datalist *datalist)
{
    if (datalist == NULL)
	return (out);

    //one subgraph for each dataset
    out << "graph: { title: " << Q << "data list<" 
	<< gDataListCounter << ">" << Q << endline
        << "node.color : lightblue" << endline;
    int index = 0;

    //print all nodes (each node is a data element;
    out << "node: { title:" << Q << gDataListCounter << Q << endline;
    out << "color: lightblue" << endline;
    out << "label: " << Q << endline;
    for (List_iterator<El_data *> li(datalist->elements); li!=0; index++, li++) {
      data_to_gdl(out, *li);
    }
    out << Q << endline << R_CURLY << endline;
    
    //print a seq. of edges - one between adjacent data elements;
    /*
    for(int i=0; i< index - 1; i++){
      out << "edge: { sourcename: " << Q << gDataListCounter << "." << i << Q << TAB ;
      out << "targetname: " << Q << gDataListCounter << "." 
          << (i+1) << Q << R_CURLY << endline;
    }
    */
    //close the subgraph of this data set
    out << R_CURLY << endline;

    return (out);
}

//---------------------------------------------------------------
//               El_data output routines
//---------------------------------------------------------------
IR_outstream& data_to_gdl(IR_outstream &out, El_data *data)
{
    if (data == NULL)
	return (out);

    out << tab << L_PAREN;
    switch (data->t_type) {
	case EL_DATA_TOKEN_MS:
	    out << "ms" << data->ms_type;
	    break;
	case EL_DATA_TOKEN_VOID:
	    out << "void" << SPACE;
	    print_symbol_expr_value(out, data->address);
	    break;
	case EL_DATA_TOKEN_BYTE:
	    out << "byte" << SPACE << data->N << SPACE;
	    print_symbol_expr_value(out, data->address);
	    if (data->value)
		out << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_WORD:
	    out << "word" << SPACE << data->N << SPACE;
	    print_symbol_expr_value(out, data->address);
	    if (data->value)
		out << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_LONG:
	    out << "long" << SPACE << data->N << SPACE;
	    print_symbol_expr_value(out, data->address);
	    if (data->value)
		out << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_FLOAT:
	    out << "float" << SPACE << data->N << SPACE;
	    print_symbol_expr_value(out, data->address);
	    if (data->value)
		out << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_DOUBLE:
	    out << "double" << SPACE << data->N << SPACE;
	    print_symbol_expr_value(out, data->address);
	    if (data->value)
		out << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_ALIGN:
	    out << "align" << SPACE << data->N << SPACE;
	    print_symbol_expr_value(out, data->address);
	    if (data->value)
		out << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_ASCII:
	    out << "ascii" << SPACE;
	    print_string_expr_value(out, data->value);
	    out << SPACE;
	    print_symbol_expr_value(out, data->address);
	    break;
	case EL_DATA_TOKEN_ASCIZ:
	    out << "asciz" << SPACE;
	    print_string_expr_value(out, data->value);
	    out << SPACE;
	    print_symbol_expr_value(out, data->address);
	    break;
	case EL_DATA_TOKEN_RESERVE:
	    out << "reserve" << SPACE << data->N;
	    break;
	case EL_DATA_TOKEN_GLOBAL:
	    out << "global" << SPACE;
	    print_symbol_expr_value(out, data->address);
	    break;
	case EL_DATA_TOKEN_WB:
	    out << "wb" << SPACE << (data->address) << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_WW:
	    out << "ww" << SPACE << (data->address) << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_WI:
	    out << "wi" << SPACE << (data->address) << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_WF:
	    out << "wf" << SPACE << (data->address) << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_WF2:
	    out << "wf2" << SPACE << (data->address) << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_WS:
	    out << "ws" << SPACE << (data->address) << SPACE << (data->value);
	    break;
	case EL_DATA_TOKEN_ELEMENT_SIZE:
	    out << "element_size" << SPACE << data->N << SPACE;
	    print_symbol_expr_value(out, data->address);
	    if (data->value)
		out << SPACE << (data->value);
	    break;
	default:
	    El_punt("<< El_data: illegal type for data");
    }
    out << R_PAREN << endline;

    return (out);
}

//---------------------------------------------------------------
//     print data dependence graph of a basic/hyper block
//---------------------------------------------------------------
IR_outstream& bb_dfg_to_gdl(IR_outstream &out, 
			    Region* region, int bb_id)
{

  IR_token::init_pointer_map();
  op_table.reset();
  out.reset_maps();

  name_edges(out, region);
  name_attributes(out, region);

  //compute liveness info for the procedure
  create_local_analysis_info_for_all_hbs_bbs((Compound_region*)region);
  el_flow_compute_liveness((Procedure*)region, ANALYZE_ALLREG);

  
  //get pointer to the region of interest (the one corresp to bb_id);
  Region* rgn = NULL;
  //for (Dlist_iterator<Region*> region_ptr(((Compound_region*)region)->subregions());  
  //     region_ptr!=0; region_ptr++){
  for (Region_subregions_freq subri((Compound_region*)region); subri!=0; subri++) {
    rgn = *subri; //region_ptr;
    if (rgn->id()==bb_id) break;
  }

  int i;
  int maxtime = minus_infinity;
  int mintime = infinity;

  if (rgn!=NULL){
    //do edge drawing;
    insert_region_scalar_edges((Compound_region *)rgn);

    Bool scheduled = FALSE;
    //is region scheduled? ;
    if (rgn->flag(EL_REGION_SCHEDULED)){
      scheduled = TRUE;

      // initialize max/min sched times
      for(Region_all_ops op_iter((Compound_region*)rgn) ; op_iter != 0 ; op_iter++ ) {
	Op* op = *op_iter;
	maxtime = max(maxtime, op->sched_time());
	mintime = min(mintime, op->sched_time());
      }

      //write the schedule timeline in gdl;
      out << "node.borderwidth: 0" << endline
	  << "node.color: white" << endline
	  << "node.width: 60" << endline
	  << "edge.linestyle: dotted" << endline;
      //nodes on the timeline;
      for(i=0; i<(maxtime+1); i++){
	out << "node: { title: " << Q << "T" << i << Q << endline
	    << "vertical_order: " << i << endline
	    << "horizontal_order: 0" << endline
	    << "label: " << Q << "<" << i << ">" << Q << endline << "}\n";
      }
      //write the edges between nodes on the timeline;
      for(i=0; i<maxtime; i++){
	out << "edge: { sourcename: " << Q << "T" << i << Q << tab 
	    << "targetname: " << Q << "T" << (i+1) << Q << TAB
	    << "color: " << TIMELINE_EDGE_COLOR
	    << "class: " << TIMELINE_EDGES << "}\n";
      }
    }

    

    //back to normal settings for nodes and edges;
    out << "node.borderwidth: 2" << endline
	<< "node.width: -1" << endline
	<< "node.color: lightgreen" << endline
	<< "edge.linestyle: solid" << endline;

    int num_scheduled_at_t[2000];
    for(i=0; i<2000; i++) num_scheduled_at_t[i] = 0;
    i = 0;

    // Write out all the nodes (one for each op) of the region;
    Region_all_ops op_iter ;
    for(op_iter((Compound_region*)rgn) ; op_iter != 0 ; op_iter++ ) {
      Op* op = *op_iter ;
    
      if (is_pseudo(op)) continue;

      out << "node: { title: " << Q << op << Q << endline;
      out << "label: ";
      switch(El_op_info_format){
      case OP_INFO_LONG_FORM:
	{
	  out << Q ;
	  op_to_gdl(out, *op);
	  out << Q << endline;
	}
      break;
      case OP_INFO_SHORT_FORM:
	out << Q << op << Q << endline;
	break;
      case OP_INFO_ASM_FORM:
	{
	  out << Q ;
	  op_to_asm_to_gdl(out, *op);
	  out << Q << endline;
	}
      break;
      default:
	out << Q << "--" << Q << endline;
	break;
      }


      if (El_color_code)
	out << "color: " << op_node_color(op) << endline;

      if (scheduled) out << "vertical_order: " << op->sched_time() << endline;
      if (is_switch(op)) out << "horizontal_order: 1" << endline;
      out << R_CURLY << endline;
    
    }
    
    //write out the edges of the region;
    i =0;
    for (Region_all_internal_edges edgei(rgn) ; edgei != 0 ; edgei++) {
      Edge* e = * edgei ;
      Op* srcop = e->src();
      Op* destop = e->dest();

      if (is_pseudo(srcop) || is_pseudo(destop)) continue;

      int edge_color = DEFAULT_EDGE_COLOR;
      int edge_class = DEFAULT_EGDES;
      
      //some invisible edges to make the graph connected;
      if (scheduled && i<3){
	out << "edge: { sourcename: " << Q 
	    << "T" << i << Q << TAB 
	    << "targetname: " << Q 
	    << e->dest() << Q << TAB
	    << "class: " << TIMELINE_EDGES << TAB
	    << "linestyle: invisible priority: 0 }" << endline;
	i++;
      }
	
      if (e->is_seq()){
	edge_class = SEQ_EDGES;
	edge_color = SEQ_EDGE_COLOR;             //purple;
      } else if (e->is_control()){
	edge_class = CONTROL1_EDGES;
	edge_color = CONTROL1_EDGE_COLOR;              //cyan;
      } else if (e->is_mem()){
	edge_class = MEM_EDGES;
	edge_color = MEM_EDGE_COLOR;              //cyan;
      } else if (e->is_reg_flow()){
	edge_class = FLOW_EDGES;
	edge_color = FLOW_EDGE_COLOR;              //red;
      } else if (e->is_reg_anti()){
	edge_class = ANTI_EDGES;
	edge_color = ANTI_EDGE_COLOR;             //darkgreen;
      } else if (e->is_reg_out()){
	edge_class = OUTPUT_EDGES;
	edge_color = OUTPUT_EDGE_COLOR;              //darkblue;
      } 

      out << "edge: { sourcename: " << Q 
	  << e->src() << Q << TAB 
	  << "targetname: " << Q 
	  << e->dest() << Q << TAB
	  << "label: " << Q << "\fb" << e->latency() << Q << TAB
	  << "color: " << edge_color << TAB
	  << "class: " << edge_class 
	  << R_CURLY << endline;
      
    }

    delete_region_edges((Compound_region*)rgn);
  }


  //end the procedure subgraph;
  //out << R_CURLY << endline;

  el_flow_delete_liveness((Procedure*)region);
  delete_local_analysis_info_for_all_hbs_bbs((Procedure*)region);

  return out;
  
}

//---------------------------------------------------------------
//     print schedule of a basic/hyper block/procedure
//---------------------------------------------------------------
int proc_sched_to_gdl(IR_outstream &out, Procedure* f, int proc_num, int start_level)
{
    int i;
    int maxtime = minus_infinity;
    int mintime = infinity;
    
    if (!f->flag(EL_PROC_SCHEDULED)) 
      return start_level;

    IR_token::init_pointer_map();
    op_table.reset();
    out.reset_maps();

    name_edges(out, f);
    name_attributes(out, f);

    int current_level = start_level;

    Dlist<Region*> hb_bb_list;
    all_hbs_bbs(f, hb_bb_list);
    
    for(Dlist_iterator<Region*> subri(hb_bb_list); subri!=0; subri++) {
      Region* rgn = *subri; 

      //is region scheduled? ;
      //if (!rgn->flag(EL_REGION_SOFTPIPE))
      //    return current_level;
    
	//if only one BB was selected, then skip till we reach that BB;
	if ((strcmp(El_ir_scope, "all")!=0) && (El_bb_no!=0) && (rgn->id()!=El_bb_no))
	    continue;

	out << "/*  -------------------------------------------------" << endline;
	out << "          BB :: " <<  rgn->id() << endline;
	out << "    -------------------------------------------------  */\n" << endline;

	maxtime = minus_infinity;
	mintime = infinity;

 	// initialize max/min sched times;
	for(Region_all_ops op_iter1((Compound_region*)rgn) ; 
	    op_iter1 != 0 ; op_iter1++ ) {
	    Op* op = *op_iter1;
	    maxtime = max(maxtime, op->sched_time());
	    mintime = min(mintime, op->sched_time());
	}

	//write the BB id ;
	out << "node.borderwidth: 2" << endline
	    << "node.color: gold" << endline
	    << "node.width: 250" << endline;
	if (rgn->is_bb()) {
	    out << "node: { title: " << Q << proc_num
		<< ".BB." << rgn->id() << Q << endline
		<< "loc: {x: 50 y: " << current_level*NODE_Y_SEP << "}" << endline
		<< "label: " << Q << "BB <" << rgn->id() << ">" << Q << endline << "}\n";
	} else if (rgn->is_hb()) {
	    out << "node: { title: " << Q  << proc_num
		<< ".HB." << rgn->id() << Q << endline
		<< "loc: {x: 50 y: " << current_level*NODE_Y_SEP << "}" << endline
	        << "label: " << Q << "HB <" << rgn->id() << ">" << Q << endline << "}\n";
	}
	
	current_level++;
      
	//write the schedule timeline in gdl;
	out << "node.borderwidth: 0" << endline
	    << "node.color: white" << endline
	    << "node.width: 60" << endline;

	//nodes on the timeline;
	for(i=0; i<(maxtime+1); i++){
	    out << "node: { title: " << Q << proc_num
		<< ".BB." << rgn->id() << ".T." << i << Q << endline
		<< "loc: {x: 50  y: " << (current_level+i)*NODE_Y_SEP << "}" << endline
                << "label: " << Q << "<" << i << ">" << Q << endline << "}\n";
	}


	//back to normal settings for nodes and edges;
	if (El_color_code) {
	  out << "node.borderwidth: 2" << endline
	      << "node.width: -1" << endline
	      << "node.color: white" << endline
	      << "edge.linestyle: solid" << endline;
	} else {
	  out << "node.borderwidth: 1" << endline
	      << "node.width: -1" << endline
	      << "node.color: white" << endline;
	}

	int num_scheduled_at_t[2000];
	for(i=0; i<2000; i++) num_scheduled_at_t[i] = 0;
	i = 0;
	int delta_x, dby2;
	int width;

	if (El_op_info_format==OP_INFO_SHORT_FORM) {
	    delta_x = NODE_SMALL_X_SEP;
	    width = NO_OP_INFO_WIDTH;
	} else if (El_op_info_format==OP_INFO_LONG_FORM) {
	    delta_x = NODE_BIG_X_SEP;
	    width = OP_INFO_WIDTH;
	} else {  
	    //asm format;
	    delta_x = NODE_ASM_X_SEP;
	    width = OP_INFO_ASM_WIDTH;
	}
	dby2 = (delta_x*2)/3;

	// Write out all the nodes (one for each op) of the region;
	Region_all_ops op_iter ;
	for(op_iter((Compound_region*)rgn) ; op_iter != 0 ; op_iter++ ) {
	    Op* op = *op_iter ;
	    
	    if (is_pseudo(op)) continue;
	    
	    out << "node: { title: " << Q << proc_num
		<< ".BB." << rgn->id() << "." << op << Q << endline;
	    out << "label: ";
	    switch(El_op_info_format){
	      case OP_INFO_LONG_FORM:
		{
		    out << Q ;
		    op_to_gdl(out, *op);
		    out << Q << endline;
		}
		break;
	      case OP_INFO_SHORT_FORM:
		out << Q << op << Q << endline;
		break;
	      case OP_INFO_ASM_FORM:
		{
		    out << Q ;
		    op_to_asm_to_gdl(out, *op);
		    out << Q << endline;
		}
		break;
	      default:
		out << Q << "--" << Q << endline;
		break;
	    }
    
	    if (El_color_code)
		out << "color: " << op_node_color(op) << endline;

	    out << "width: " << width << endline;

	    //num_scheduled_at_t[op->sched_time()]++;
	    out << "loc: {x: " << (num_scheduled_at_t[op->sched_time()]*delta_x + 150) 
		<< " y: " 
		<< ((op->sched_time() + current_level)*NODE_Y_SEP) 
		<< "}" << endline;
	    num_scheduled_at_t[op->sched_time()]++;
	    
	    out << R_CURLY << endline;
    
	} 
	current_level += (maxtime+1);
    }
    
    return current_level;
  
}


//---------------------------------------------------------------
//     print  basic/hyper block stats
//---------------------------------------------------------------
int proc_stats_to_gdl(ofstream &out, Region* region, int proc_num, 
		      int start_level, double total_cycle_count)
{
  /*
    IR_token::init_pointer_map();
    op_table.reset();
    out.reset_maps();

    name_edges(out, region);
    name_attributes(out, region);
    */

    int current_level = start_level;

    Region* rgn = NULL;
    //for (Dlist_iterator<Region*> region_ptr(((Compound_region*)region)->subregions());  
    // region_ptr!=0; region_ptr++){
    for (Region_subregions subri((Compound_region*)region); subri!=0; subri++) {
      rgn = *subri; //region_ptr;

	//is region scheduled? ;
	if (!rgn->flag(EL_REGION_SCHEDULED)) {
	  cerr << "region <" << rgn->id() << " not scheduled." << endl;
	  return current_level;
	}
    
	double region_total = 0;
	for(Region_exit_edges eedges((Compound_region*)rgn); eedges != 0; eedges++){
	    Edge* e = *eedges;
	    Op* eop = e->src();
	    Control_flow_freq *cfreq = get_control_flow_freq(e);
	    if (cfreq) {
		region_total += (eop->sched_time() * cfreq->freq);
	    }
	}

	int width = (int)(region_total * 1000 / total_cycle_count);

	//out << "/*  -------------------------------------------------" << endl;
	//out << "    BB :: " <<  rgn->id() << " - " << region_total << endl;
	//out << "    -------------------------------------------------  */\n" << endl;


	char label[64];

	//dont diplay if the cycle count is too low;
	if (width > 9) {
	  //write the BB id ;

	  out << "node: { title: " << Q << proc_num 
	      << ".BB.lbl." << rgn->id() << Q << endl
	      << "loc: {x: 10 y: " << (current_level*NODE_Y_SEP + 8) << "}" << endl
	      << "textmode: right_justify" << endl;

	  if (rgn->is_bb()) {
	    sprintf(label, "%s%d - %d", "BB", rgn->id(), (int)(width/10));
	  } else {
	    sprintf(label, "%s%d - %d", "HB", rgn->id(), (int)(width/10));
	  }
	  out << "label: " << Q << label << Q << endl 
	      << "borderwidth: 0" << endl
	      << "color: white" << endl
	      << "width: 80" << "}\n";

	  if (rgn->is_bb()) {
		out << "node: { title: " << Q << proc_num
		    << ".BB." << rgn->id() << Q << endl
		    << "loc: {x: 100 y: " << current_level*NODE_Y_SEP << "}" << endl
		    << "label: " << Q << " " << Q << endl 
		    << "width: " << width 
		    << "color: gold" << endl
		    << "borderwidth: 2" << endl
		    << "}\n";
	    } else if (rgn->is_hb()) {
		out << "node: { title: " << Q << proc_num
		    << ".HB." <<  rgn->id() << Q << endl
		    << "loc: {x: 100 y: " << current_level*NODE_Y_SEP << "}" << endl
		    << "label: " << Q << " " << Q << endl
		    << "color: gold" << endl
		    << "borderwidth: 2" << endl
		    << "width: " << width << "}\n";
	    }
	
	    current_level++;
	}
    }
    
    return current_level;
  
}

//---------------------------------------------------------------
//               Region hierarchy tree
//---------------------------------------------------------------
IR_outstream& 
region_hierarchy_to_gdl(IR_instream& in, IR_outstream &out) 
{

  //main graph object for the entire rebel file;
  out << "graph: { title: " 
      << Q << El_input_file_name << Q << endline 
      << "color: white" << endline 
      << "display_edge_labels: yes" << endline
      << "layout_algorithm: minbackward" << endline 
      << "orientation: left_to_right" << endline
      << "layout_nearfactor: 0" << endline 
      << "layout_downfactor: 100" << endline;



  //output the program unit node;
  out << "node: { title: " << Q << "program unit" << Q << endline
      << "label: " << Q << "program unit" << Q << TAB
      << "color: red  vertical_order: 0 horizontal_order: 0}";

  
  gProcedureCounter = 0;
  while (ir_read(in) != EL_INPUT_EOF) {

    switch (El_input_type) {
    case EL_INPUT_EOF:
      break;
    case EL_INPUT_DATA:
      {
 	El_datalist *D = (El_datalist *) El_input;
	delete D;
      }
     break;
    case EL_INPUT_CODE:
      {
	Procedure *region = (Procedure *) El_input;
	out.reset_maps();	
	
	cerr << "processing : " << (char*)(((Procedure*)region)->get_name()) << "\n";

	Dlist<Region*> rstack;
	Dlist<double> lstack;  //keep track of the levels;
	
	rstack.push(region);
	lstack.push(0);
	int g = gProcedureCounter;

	while(!rstack.is_empty()){
	  Region* r = rstack.pop();
	  double dl = lstack.pop();
	  int l = (int)dl;
	  int level = (2*gProcedureCounter) + l;
	  
	  if (r->is_bb()){
	    //write bb node;
	    out << "node: { title: " << Q << "BB" << g << "." << r->id() << "." << l << Q << "  ";
	    out << "label: " << Q << "BB" << g << "." << r->id() << "." << l << Q << "  ";
	    out << "color: 18" << "  ";   // 18 =  lightgreen;
	    out << "vertical_order: " << level << "}" << endline;
	  } else if (r->is_hb()) {
	    //write hb node;
	    out << "node: { title: " << Q << "HB" << g << "."  << r->id() << "." << l << Q << "  ";
	    out << "label: " << Q << "HB" << g << "." << r->id() << "." << l << Q << "  ";
	    out << "color: 17" << "  ";    // 17 lightred;
	    out << "vertical_order: " << level << "}" << endline;
	  } else if (r->is_compound()){
	    //write r-node;
	    char * label;
	    if (r->is_procedure()){
	      label = gRegionLabels[2];
	      out << "node: { title: " << Q << label << g << "." << r->id() << "." << l << Q << TAB;
	      out << "label: " << Q << (char*)(((Procedure*)region)->get_name()) << Q << TAB;
	      out << "color: 16" << "  ";  // 16 lightblue
	      out << "vertical_order: " << level << TAB;
	      out << "horizontal_order: 1" << TAB;
	      out << "}" << endline;
	    } else if (r->is_loopbody()) {
	      label = gRegionLabels[3];
	      out << "node: { title: " << Q << label << g << "." << r->id() << "." << l << Q << "  ";
	      out << "label: " << Q << label << g << "." << r->id() << "." << l << Q << "  ";
	      out << "color: 6" << "  ";   // 6 cyan;
	      out << "vertical_order: " << level << "}" << endline;
	    } else {
	      label = gRegionLabels[4];
	      out << "node: { title: " << Q << label << g << "." << r->id() << "." << l << Q << "  ";
	      out << "label: " << Q << label << g << "." << r->id() << "." << l << Q << "  ";
	      out << "color: 0" << "  ";   // 0 = white;
	      out << "vertical_order: " << level << "}" << endline;
	    }
	    
	    //write subregion-nodes;
	    
	    //add edges from r-node to subregion-nodes;
	    //for (Dlist_iterator<Region*> subri(r->subregions()) ; subri != 0 ; subri++) {
	    for (Region_subregions subri(r); subri!=0; subri++) {
	      Region* subr = *subri;
	      out << "edge: { sourcename: " << Q << label << g << "." 
		  << r->id() << "." << l << Q << "  ";
	      if (subr->is_bb()){
		out << "targetname: " << Q << "BB" << g << "." 
		    << subr->id() << "." << (l+1) << Q << "  ";
	      } else if (subr->is_hb()){
		out << "targetname: " << Q << "HB" << g << "." 
		    << subr->id() << "." << (l+1) << Q << "  ";
	      } else if (subr->is_compound()){
		char* slabel;
		if (subr->is_procedure()){
		  slabel = gRegionLabels[2];
		} else if (subr->is_loopbody()) {
		  slabel = gRegionLabels[3];
		} else {
		  slabel = gRegionLabels[4];
		}
		out << "targetname: " << Q <<  slabel << g << "." 
		    << subr->id() << "." << (l+1) << Q << "  ";
	      }
	      out << "}" << endline;
	    }
	    
	    if (r->is_procedure()){
	      //edge from program unit to the procedure node;
	      out << "edge: { sourcename: " << Q << "program unit" << Q ;
	      out << "targetname: " << Q << gRegionLabels[2] << g << "." << r->id()
		  << "." << l << Q  << TAB
		  << "color: 2}" << endline;   //2 = red
	    }
	    //push subregions into stack;
            for (Region_subregions subri1(r); subri1!=0; subri1++) {

	      if (*subri1 == r) continue;
	      rstack.push(*subri1);
	      lstack.push(l+1);

	      //for (Dlist_iterator<Region*> ri(r->subregions()) ; ri != 0 ; ri++) {
	      //if (*ri == r) continue;
	      //rstack.push(*ri) ;
	      //lstack.push(l+1) ;
	    }
	  } else {
	    cerr << "unknown region type!\n";
	    return out;
	  }
	}
	gProcedureCounter++;
	
	/* Deallocate the Elcor procedure */
	region_purge (region);
	
      }
    break;
    default:
      break;
    }

  }

  //end the program unit graph;
  out << R_CURLY << endline;

  cerr << "region hierarchy done." << endl;

  return out;
}


//---------------------------------------------------------------
// translate a ddg of a basic/hyper block to GDL
//---------------------------------------------------------------
IR_outstream& 
ddg_to_gdl(IR_instream& in, IR_outstream &out) 
{

  //main graph object for the entire rebel file;
  out << "graph: { title: " 
      << Q << El_input_file_name << Q << endline 
      << "color: white" << endline 
      << "display_edge_labels: yes" << endline
      << "layout_algorithm: minbackward" << endline 
      << "layout_nearfactor: 0" << endline 
      << "layout_downfactor: 100" << endline
      << "late_edge_labels: yes" << endline;

  while (ir_read(in) != EL_INPUT_EOF) {

    switch (El_input_type) {
    case EL_INPUT_EOF:
      break;
    case EL_INPUT_DATA:
      {
 	El_datalist *D = (El_datalist *) El_input;
	delete D;
      }
     break;
    case EL_INPUT_CODE:
      {
	Procedure *region = (Procedure *) El_input;
	if (strcmp(El_procedure_name, (char*)(region->get_name()))!=0) {
	  /* Deallocate the Elcor procedure */
	  region_purge (region);
	  break;
	}
	out.reset_maps();	
	bb_dfg_to_gdl(out, region, El_bb_no);
	/* Deallocate the Elcor procedure */
	region_purge (region);
      }
    break;
    default:
      break;
    }

  }

  //end the program unit graph;
  out << R_CURLY << endline;

  cerr << "DDG done." << endl;

  return out;
}


//---------------------------------------------------------------
// translate a scheduled ddg of a basic/hyper block to GDL
//---------------------------------------------------------------
IR_outstream& 
sched_to_gdl(IR_instream& in, IR_outstream &out) 
{
    int current_level =0;
    int proc_num = 0;

    //main graph object for the entire rebel file;
    out << "graph: { title: " 
	<< Q << El_input_file_name << Q << endline 
        << "color: white" << endline ;

    while (ir_read(in) != EL_INPUT_EOF) {
	
	switch (El_input_type) {
	  case EL_INPUT_EOF:
	    break;
	  case EL_INPUT_DATA:
	    {
		El_datalist *D = (El_datalist *) El_input;
		delete D;
	    }
	    break;
	  case EL_INPUT_CODE:
	    {
		Procedure *region = (Procedure *) El_input;
		if (((strcmp(El_ir_scope, "proc") == 0) || 
		    (strcmp(El_ir_scope, "bb") == 0)) &&
		    (strcmp(El_procedure_name, (char*)(region->get_name()))!=0)) {
		  /* Deallocate the Elcor procedure */
		  region_purge (region);
		  break;
		}
		
		cerr << "processing = " << ((char*)(region->get_name())) << endl;

		out << "/*  ================================================= " << endline;
		out << "    PROCEDURE <" << proc_num << "> " << ((char*)(region->get_name())) << endline;
		out << "    =================================================  */\n" << endline;

		//write the procedure node ;
		out << "node.borderwidth: 2" << endline
		    << "node.color: orange" << endline
		    << "node.width: 1000" << endline;
		out << "node: { title: " << Q << ((char*)(region->get_name())) << Q << endline
		    << "loc: {x: 10 y: " << current_level*NODE_Y_SEP << "}" << endline
		    << "label: " << Q << ((char*)(region->get_name())) << Q << endline << "}\n";
		out.reset_maps();	

		current_level++;
		proc_num++;
		current_level = proc_sched_to_gdl(out, region, proc_num, current_level);
		
		/* Deallocate the Elcor procedure */
		region_purge (region);

	    }
	    break;
	  default:
	    break;
	}

    }

    out << R_CURLY << endline;

    cerr << "schedule done." << endl;

    return out;
}


//---------------------------------------------------------------
// translate a scheduled ddg of a basic/hyper block to GDL
//---------------------------------------------------------------
int stats_to_gdl()
{
  int current_level =0;
  int proc_num = 0;
  
  //make one pass over the input file to get the max-cycle count;
  double total_cycle_count = 0;
  IR_instream *in_stream = new IR_instream(El_input_file_name); 
  while (ir_read(*in_stream) != EL_INPUT_EOF) {
	
    switch (El_input_type) {
    case EL_INPUT_EOF:
      break;
    case EL_INPUT_DATA:
      {
	  El_datalist *D = (El_datalist *) El_input;
	  delete D;
      }
      break;
    case EL_INPUT_CODE:
      {
	Procedure *region = (Procedure *) El_input;
	double proc_cycle_count = procedure_total_cycle_count(region); 
	cerr << "procedure cycle count = " 
	     <<  proc_cycle_count 
	     << "  > " << ((char*)(region->get_name())) << endl;
	total_cycle_count += proc_cycle_count;

	/* Deallocate the Elcor procedure */
	region_purge (region);

      }
      break;
    default:
      break;
    }

  }
  delete in_stream;
    
  if (total_cycle_count<=0) return 0;
  cerr << "total cycle count = " << total_cycle_count  << endl;
  
  in_stream = new IR_instream(El_input_file_name); 
  ofstream out_stream(El_output_file_name); 

  //main graph object for the entire rebel file;
  out_stream << "graph: { title: " 
	     << Q << El_input_file_name << Q << endl
	     << "color: white" << endl ;

  while (ir_read(*in_stream) != EL_INPUT_EOF) {
    
    switch (El_input_type) {
    case EL_INPUT_EOF:
      break;
    case EL_INPUT_DATA:
      {
	  El_datalist *D = (El_datalist *) El_input;
	  delete D;
      }
      break;
    case EL_INPUT_CODE:
      {
	Procedure *region = (Procedure *) El_input;

	out_stream << " /* PROCEDURE <" << proc_num << "> " 
		   << ((char*)(region->get_name())) << "*/ \n" << endl;

	cerr << " PROC  =  " << ((char*)(region->get_name())) << endl << flush;

	//write the procedure node ;
	out_stream << "node: { title: " << Q 
		   << ((char*)(region->get_name())) << Q << endl
		   << "textmode: left_justify" << endl
		   << "borderwidth: 0" << endl
		   << "color: white" << endl
		   << "width: 500" << endl
		   << "loc: {x: 20 y: " << current_level*NODE_Y_SEP << "}" << endl
		   << "label: " << Q << "\fb" 
		   << ((char*)(region->get_name())) << Q << endl << "}\n" << flush;
	
	current_level++;
	proc_num++;
	current_level = proc_stats_to_gdl(out_stream, region, 
					  proc_num, current_level, total_cycle_count);

	/* Deallocate the Elcor procedure */
	region_purge (region);

      }
      break;
    default:
      break;
    }
    
  }

  out_stream << R_CURLY << endl << flush;
  delete in_stream;
  
  cerr << "stats done." << endl;

  return 1;
}

//---------------------------------------------------------------
// consistency checking for the command line options
//---------------------------------------------------------------
int options_consistent()
{
    if (!El_input_file_name || !El_output_file_name) {
	cerr << "input/output files (-i/-o options) not specified." << endl;
	return 0;
    }
    
    if (!El_output_graph_type){
	cerr << "output graph type (-t cfg|ddg|sched|rh) not specified." << endl;
	return 0;
    }
  
    if (! strcmp(El_output_graph_type, "rh")){
	cerr << "note:: region hirarchy for the entire program (-s all) only." << endl;
	return 1;
    } 

    if (!El_ir_scope) {
	El_ir_scope = strdup("all");
    }

    if (! strcmp(El_output_graph_type, "ddg")){
	if (! strcmp(El_ir_scope, "bb")){
	    if (! El_procedure_name) {
		cerr << "procedure not specified. use -f option." << endl;
		return 0;
	    }
	    if (El_bb_no<=0) {
		cerr << "basic/hyper block no. not specified. use -b option." << endl;
		return 0;
	    }
	    return 1;
	} else {
	    cerr << "ddg can be computed for basic/hyper blocks only. -s bb only." << endl;
	    return 0;
	}
    } 

    if (! strcmp(El_output_graph_type, "cfg")){
	if (! strcmp(El_ir_scope, "proc")){
	    if (! El_procedure_name) {
		cerr << "procedure not specified. use -f option." << endl;
		return 0;
	    }
	    return 1;
	}
	if (! strcmp(El_ir_scope, "all")) 
	  return 1;
	cerr << "CFG for program|procedure regions only. Use -s [proc|all] only." << endl;
	return 0;
    } 

    if (! strcmp(El_output_graph_type, "sched")){
	if ((! strcmp(El_ir_scope, "bb")) || 
	    (! strcmp(El_ir_scope, "proc"))) {
	    if (! El_procedure_name) {
		cerr << "procedure not specified. use -f option." << endl;
		return 0;
	    }
	    if (! strcmp(El_ir_scope, "bb")) {
	      if (El_bb_no <= 0) {
		cerr << "bb/hb not specified. use -b option." << endl;
		return 0;
	      }
	    }
	} 
    }

    return 1;

}

//---------------------------------------------------------------
// extra color entries needed when color coding cfg's
//---------------------------------------------------------------
int dump_extra_color_entries(IR_outstream& out)
{
    out << "colorentry 69 : 255 255 255" << endline;
    out << "colorentry 68 : 255 240 240" << endline;
    out << "colorentry 67 : 255 220 220" << endline;
    out << "colorentry 66 : 255 200 200" << endline;
    out << "colorentry 65 : 255 180 180" << endline;
    out << "colorentry 64 : 255 160 160" << endline;
    out << "colorentry 63 : 255 120 120" << endline;
    out << "colorentry 62 : 255 100 100" << endline;
    out << "colorentry 61 : 255 80 80" << endline;
    out << "colorentry 60 : 255 60 60" << endline;
    out << "colorentry 59 : 255 40 40" << endline;
    out << "colorentry 58 : 255 20 20" << endline;
    out << "colorentry 57 : 255 0 0 " << endline;
    out << "colorentry 56 : 240 0 0" << endline;
    out << "colorentry 55 : 230 0 0" << endline;
    out << "colorentry 54 : 220 0 0" << endline;
    out << "colorentry 53 : 210 0 0" << endline;
    out << "colorentry 52 : 200 0 0" << endline;
    out << "colorentry 51 : 190 0 0" << endline;
    out << "colorentry 50 : 180 0 0" << endline;
    out << "colorentry 49 : 170 0 0 " << endline;
    out << "colorentry 48 : 160 0 0" << endline;
    out << "colorentry 47 : 150 0 0" << endline;
    out << "colorentry 46 : 140 0 0 " << endline;
    out << "colorentry 45 : 130 0 0 " << endline;
    out << "colorentry 44 : 120 0 0" << endline;
    out << "colorentry 43 : 110 0 0" << endline;
    out << "colorentry 42 : 100 0 0" << endline;
    out << "colorentry 41 : 90 0 0" << endline;
    out << "colorentry 40 : 80 0 0 " << endline;
    out << "colorentry 39 : 70 0 0 " << endline;
    out << "colorentry 38 : 60 0 0" << endline;
    out << "colorentry 37 : 50 0 0" << endline;
    out << "colorentry 36 : 40 0 0" << endline;
    out << "colorentry 35 : 30 0 0" << endline;
    out << "colorentry 34 : 20 0 0" << endline;
    out << "colorentry 33 : 10 0 0" << endline;
    out << "colorentry 32 : 0 0 0" << endline;
    
    return 1;
}


//---------------------------------------------------------------
// color coding of instruction nodes
//---------------------------------------------------------------
int op_node_color(Op* op)
{
  int color;
  Opcode opc = op->opcode();
  if (is_no_op(op)){
    color = NOOP;
  } else if (is_pseudo(op)) {   //these do not consume any m/c cycles;
    color = PSEUDO_OP;
  } else if (is_memory(op)){    //load, store;
    color = MEM_OP;
  } else if (is_ialu(op)){
    color = IALU_OP;
  } else if (is_cmpp(op)){
    color = CMPP_OP;
  } else if (is_falu(op)){
    color = FALU_OP;
  } else if (is_pbr(op)) {
    color = PBR_OP;
  } else if (is_control_switch(op)){  
    color = SWITCH_OP;
  } else if (opc == PRED_CLEAR || opc == PRED_CLEAR_ALL || 
	     opc == PRED_CLEAR_ALL_STATIC || opc == PRED_CLEAR_ALL_ROTATING ||
	     opc == PRED_SET || opc == PRED_AND || opc == PRED_COMPL ||
	     opc == PRED_LOAD_ALL || opc == PRED_STORE_ALL) {
    color = PRED_OPS;
  } else {
    cerr << "unknown op = " << op->id() << " " << *op << endl << flush;
    El_punt("color_code_op: unknown op");
    return 0;
  }

  return color;
  
}


//---------------------------------------------------------------
// color coding of region nodes according to freq
//---------------------------------------------------------------
int region_freq_color(double freq, double max_freq)
{
  int color;
  //double delta_freq = max_freq/NUM_COLOR_RANGES;
  
  for(int i=0; i<NUM_COLOR_RANGES; i++){
    //if ((freq > i*delta_freq) && (freq <= (i+1)*delta_freq))
    if ((freq > gTemperatureRange[i]) && (freq <= gTemperatureRange[i+1]))
      return 69 - i; 
  }
  
  return 31; //black if freq is higher than max range;
}


//---------------------------------------------------------------
// color coding of region nodes according to freq
//---------------------------------------------------------------
double region_max_freq(Region* region)
{
  double max_freq = 0, freq;
  Dlist_iterator<Region*> region_ptr;

  //for (region_ptr(((Compound_region*)region)->subregions());  
  //     region_ptr!=0; region_ptr++){
  for (Region_subregions subri((Compound_region*)region); subri!=0; subri++) {
    Region* rgn  = *subri; //region_ptr;
    freq = ((Compound_region*)rgn)->weight;
    if (freq > max_freq) max_freq = freq;
  }
  
  return max_freq;
}


//---------------------------------------------------------------
// total cycle count of the region
//---------------------------------------------------------------
double procedure_total_cycle_count(Region* region)
{
    double total_freq = 0;
    Dlist_iterator<Region*> region_ptr;

    //for (region_ptr(((Compound_region*)region)->subregions());  
    // region_ptr!=0; region_ptr++){
    for (Region_subregions subri((Compound_region*)region); subri!=0; subri++) {
      Region* rgn  = *subri; //region_ptr;
	double region_total = 0;
	for(Region_exit_edges eedges((Compound_region*)rgn); 
	    eedges != 0; eedges++){
	    Edge* e = *eedges;
	    Op* eop = e->src();
	    Control_flow_freq *cfreq = get_control_flow_freq(e);
	    if (cfreq) {
		region_total += (eop->sched_time() * cfreq->freq);
	    }
	}
	//cerr << "region <" << rgn->id() << "> = " << region_total << endl;
	total_freq += region_total;
    }
  
    return total_freq;
}


//---------------------------------------------------------------
//         op to pseudo assembly to gdl output routines
//---------------------------------------------------------------
IR_outstream& op_to_asm_to_gdl(IR_outstream &out, const Op &op)
{
   int i, port ;

   char buf[512], temp_buf[512];
   char* bufptr = temp_buf;

   for(i=0; i<512; i++) temp_buf[i] = buf[i] = 0;

   // Dest operands;
   for (port = int(op.first_dest()); port <= int(op.last_dest()); port++){
     operand_to_asm_to_gdl_buf(out, op.dest(Port_num(port)), bufptr);
     strcat(temp_buf, " ");
     bufptr = temp_buf + strlen(temp_buf);
   }

   if ((int)(op.last_dest()) <= 0) {
     // write out symbol for opcode;
     strcpy(bufptr, (char *) el_opcode_to_symbol_map.value(op.opcode()) );
     strcat(temp_buf, " ");
   }

   // right-adjust the dest operand string ;
   if (strlen(temp_buf) < DEST_OPERS_LEN) {
     int diff_len = DEST_OPERS_LEN - strlen(temp_buf);
     strcpy(buf, gBlankStrings[diff_len]);
     strcat(buf, temp_buf);
   } else {
     strcpy(buf, temp_buf);
   }


   if ((int)(op.last_dest()) > 0) 
     strcat(buf, "= ");

   for(i=0; i<512; i++) temp_buf[i] = 0;
   bufptr = temp_buf;

   Opcode opc;

   if (is_ialu_simple_binary_op(op.opcode()) ||
       is_falu_simple_binary_op(op.opcode())) {

     operand_to_asm_to_gdl_buf(out, op.src(Port_num(1)), bufptr);
     strcat(temp_buf, " ");
     strcat(temp_buf, (char *) el_opcode_to_symbol_map.value(op.opcode()) );
     strcat(temp_buf, " ");
     bufptr = temp_buf + strlen(temp_buf);
     operand_to_asm_to_gdl_buf(out, op.src(Port_num(2)), bufptr);
     bufptr = temp_buf + strlen(temp_buf);

   } else {
    
     opc = op.opcode();
     int num_dest = (int)(op.last_dest());
     if (num_dest > 0) {
       //write out symbol for opcode;
       strcpy(bufptr, (char *) el_opcode_to_symbol_map.value(op.opcode()) );
       if (!is_move(op.opcode())) strcat(temp_buf, " ");
       if (is_pbr(op.opcode())) strcat(temp_buf, " ");
     }

     bufptr = temp_buf + strlen(temp_buf);

     // Src operands;
     for (port = int(op.first_src()); port <= int(op.last_src()); port++) {
       operand_to_asm_to_gdl_buf(out, op.src(Port_num(port)), bufptr);
       strcat(temp_buf, " ");
       bufptr = temp_buf + strlen(temp_buf);
     }
   }

   if (strlen(temp_buf) < SRC_OPERS_LEN){
     int diff_len = SRC_OPERS_LEN - strlen(temp_buf);
     if ((int)(op.last_dest()) <= 0) diff_len += 2;
     strcat(temp_buf, gBlankStrings[diff_len]);
     strcat(buf, temp_buf);
   }

   // Optional fields (not written if they have default values);
   if (op.predicated()) {
     strcat(buf, " ");
     bufptr = buf + strlen(buf);
     operand_to_asm_to_gdl_buf(out, op.src(PRED1), bufptr);
   }
   
   strcat(buf, "  ");
   bufptr = buf + strlen(buf);
   sprintf(bufptr, "%d" , op.sched_time());

   out << buf;

   return out;
}


//---------------------------------------------------------------
//         opcode to pseudo assembly symbol
//---------------------------------------------------------------
void el_init_elcor_opcode_to_symbol_maps_arithmetic()
{
  //is_no_op();
  el_opcode_to_symbol_map.bind(NO_OP, "nop") ;
  el_opcode_to_symbol_map.bind(M_NO_OP, "m-nop") ;

  el_opcode_to_symbol_map.bind(ABS_W, "abs") ;

  //is_ialu_simple_binary_op();
  el_opcode_to_symbol_map.bind(ADD_W, "+") ;
  el_opcode_to_symbol_map.bind(ADDL_W, "+") ;
  el_opcode_to_symbol_map.bind(AND_W, "and") ;
  el_opcode_to_symbol_map.bind(DIV_W, "/") ;
  el_opcode_to_symbol_map.bind(DIVL_W, "/") ;
  el_opcode_to_symbol_map.bind(MPY_W, "*") ;
  el_opcode_to_symbol_map.bind(MPYL_W, "*") ;
  el_opcode_to_symbol_map.bind(OR_W, "or") ;
  el_opcode_to_symbol_map.bind(REM_W, "%") ;
  el_opcode_to_symbol_map.bind(REML_W, "%") ;
  el_opcode_to_symbol_map.bind(SHL_W, "<<") ;
  el_opcode_to_symbol_map.bind(SHR_W, ">>") ;
  el_opcode_to_symbol_map.bind(SHLA_W, "<<a") ;
  el_opcode_to_symbol_map.bind(SHRA_W, ">>a") ;
  el_opcode_to_symbol_map.bind(SUB_W, "-") ;
  el_opcode_to_symbol_map.bind(SUBL_W, "-") ;
  el_opcode_to_symbol_map.bind(XOR_W, "xor") ;
  
  //is_ialu_complex_binary_op();
  el_opcode_to_symbol_map.bind(NAND_W, "nand") ;
  el_opcode_to_symbol_map.bind(NOR_W, "nor") ;
  el_opcode_to_symbol_map.bind(ORCM_W, "or!") ;
  el_opcode_to_symbol_map.bind(XORCM_W, "xor!") ;
  el_opcode_to_symbol_map.bind(ANDCM_W, "and!") ;
  el_opcode_to_symbol_map.bind(SH1ADDL_W, "<<1+") ;
  el_opcode_to_symbol_map.bind(SH2ADDL_W, "<<2+") ;
  el_opcode_to_symbol_map.bind(SH3ADDL_W, "<<3+") ;


  //is_falu_simple_binary_op();
  el_opcode_to_symbol_map.bind(FADD_S, "+") ;
  el_opcode_to_symbol_map.bind(FADD_D, "+") ;
  el_opcode_to_symbol_map.bind(FDIV_S, "/") ;
  el_opcode_to_symbol_map.bind(FDIV_D, "/") ;
  el_opcode_to_symbol_map.bind(FMAX_S, "max") ;
  el_opcode_to_symbol_map.bind(FMAX_D, "max") ;
  el_opcode_to_symbol_map.bind(FMIN_S, "min") ;
  el_opcode_to_symbol_map.bind(FMIN_D, "min") ;
  el_opcode_to_symbol_map.bind(FMPY_S, "*") ;
  el_opcode_to_symbol_map.bind(FMPY_D, "*") ;
  el_opcode_to_symbol_map.bind(FRCP_S, "1 /") ;
  el_opcode_to_symbol_map.bind(FRCP_D, "1 /") ;
  el_opcode_to_symbol_map.bind(FSUB_S, "-") ;
  el_opcode_to_symbol_map.bind(FSUB_D, "-") ;
  
  el_opcode_to_symbol_map.bind(DIVFLOOR_W, "/F") ;
  el_opcode_to_symbol_map.bind(DIVCEIL_W, "/C") ;
  el_opcode_to_symbol_map.bind(MIN_W, "min") ;
  el_opcode_to_symbol_map.bind(MAX_W, "max") ;
  el_opcode_to_symbol_map.bind(FABS_S, "abs") ;
  el_opcode_to_symbol_map.bind(FABS_D, "abs") ;
  
  //is_falu_complex_binary_op();
  el_opcode_to_symbol_map.bind(FMPYADD_S, "*+") ;
  el_opcode_to_symbol_map.bind(FMPYADD_D, "*+") ;
  el_opcode_to_symbol_map.bind(FMPYADDN_S, "*+N") ;
  el_opcode_to_symbol_map.bind(FMPYADDN_D, "*+N") ;
  el_opcode_to_symbol_map.bind(FMPYRSUB_S, "-*") ;
  el_opcode_to_symbol_map.bind(FMPYRSUB_D, "-*") ;
  el_opcode_to_symbol_map.bind(FMPYSUB_S, "*-") ;
  el_opcode_to_symbol_map.bind(FMPYSUB_D, "*-") ;
  el_opcode_to_symbol_map.bind(FSQRT_S, "sqrt") ;
  el_opcode_to_symbol_map.bind(FSQRT_D, "sqrt") ;

  
  el_opcode_to_symbol_map.bind(CONVWS, "(float)") ;
  el_opcode_to_symbol_map.bind(CONVWD, "(double)") ;
  el_opcode_to_symbol_map.bind(CONVSW, "(int)") ;
  el_opcode_to_symbol_map.bind(CONVDW, "(int)") ;
  el_opcode_to_symbol_map.bind(CONVSD, "(double)") ;
  el_opcode_to_symbol_map.bind(CONVDS, "(float))") ;
  el_opcode_to_symbol_map.bind(EXTS_B, "exts_b") ;
  el_opcode_to_symbol_map.bind(EXTS_H, "exts_h") ;

  el_opcode_to_symbol_map.bind(MOVE, "") ;
  el_opcode_to_symbol_map.bind(MOVEGF_L, "") ;
  el_opcode_to_symbol_map.bind(MOVEGF_U, "") ;
  el_opcode_to_symbol_map.bind(MOVEF_S, "") ;
  el_opcode_to_symbol_map.bind(MOVEF_D, "") ;
  el_opcode_to_symbol_map.bind(MOVEFG_L, "") ;
  el_opcode_to_symbol_map.bind(MOVEFG_U, "") ;
  el_opcode_to_symbol_map.bind(MOVEPG, "") ;
  el_opcode_to_symbol_map.bind(LDCM, "LDCM") ;    //load a control reg; dest1 = (src1 & src3)|src2
  
  el_opcode_to_symbol_map.bind(CMPR_W_FALSE, "F") ;
  el_opcode_to_symbol_map.bind(CMPR_W_EQ, "==") ;
  el_opcode_to_symbol_map.bind(CMPR_W_LT, "<") ;
  el_opcode_to_symbol_map.bind(CMPR_W_LEQ, "<=") ;
  el_opcode_to_symbol_map.bind(CMPR_W_GT, ">") ;
  el_opcode_to_symbol_map.bind(CMPR_W_GEQ, ">=") ;
  el_opcode_to_symbol_map.bind(CMPR_W_SV, "-ov") ;
  el_opcode_to_symbol_map.bind(CMPR_W_OD, "-odd") ;
  el_opcode_to_symbol_map.bind(CMPR_W_TRUE, "T") ;
  el_opcode_to_symbol_map.bind(CMPR_W_NEQ, "<>") ;
  el_opcode_to_symbol_map.bind(CMPR_W_LLT, "<L") ;
  el_opcode_to_symbol_map.bind(CMPR_W_LLEQ, "<=L") ;
  el_opcode_to_symbol_map.bind(CMPR_W_LGT, ">L") ;
  el_opcode_to_symbol_map.bind(CMPR_W_LGEQ, ">=L") ;
  el_opcode_to_symbol_map.bind(CMPR_W_NSV, "!-ov") ;
  el_opcode_to_symbol_map.bind(CMPR_W_EV, "-even") ;
  
  el_opcode_to_symbol_map.bind(FCMPR_S_FALSE, "F") ;
  el_opcode_to_symbol_map.bind(FCMPR_S_EQ, "==") ;
  el_opcode_to_symbol_map.bind(FCMPR_S_LT, "<") ;
  el_opcode_to_symbol_map.bind(FCMPR_S_LEQ, "<=") ;
  el_opcode_to_symbol_map.bind(FCMPR_S_GT, ">") ;
  el_opcode_to_symbol_map.bind(FCMPR_S_GEQ, ">=") ;
  el_opcode_to_symbol_map.bind(FCMPR_S_NEQ, "<>") ;
  el_opcode_to_symbol_map.bind(FCMPR_S_TRUE, "T") ;
  
  el_opcode_to_symbol_map.bind(FCMPR_D_FALSE, "F") ;
  el_opcode_to_symbol_map.bind(FCMPR_D_EQ, "==") ;
  el_opcode_to_symbol_map.bind(FCMPR_D_LT, "<") ;
  el_opcode_to_symbol_map.bind(FCMPR_D_LEQ, "<=") ;
  el_opcode_to_symbol_map.bind(FCMPR_D_GT, ">") ;
  el_opcode_to_symbol_map.bind(FCMPR_D_GEQ, ">=") ;
  el_opcode_to_symbol_map.bind(FCMPR_D_NEQ, "<>") ;
  el_opcode_to_symbol_map.bind(FCMPR_D_TRUE, "T") ;
  
}



void el_init_elcor_opcode_to_symbol_maps_cmpp1_1()
{
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UN_UN, "cmpp.f.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UN_UC, "cmpp.f.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UN_CN, "cmpp.f.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UN_CC, "cmpp.f.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UN_ON, "cmpp.f.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UN_OC, "cmpp.f.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UN_AN, "cmpp.f.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UN_AC, "cmpp.f.UN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UC_UN, "cmpp.f.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UC_UC, "cmpp.f.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UC_CN, "cmpp.f.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UC_CC, "cmpp.f.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UC_ON, "cmpp.f.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UC_OC, "cmpp.f.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UC_AN, "cmpp.f.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_UC_AC, "cmpp.f.UC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CN_UN, "cmpp.f.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CN_UC, "cmpp.f.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CN_CN, "cmpp.f.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CN_CC, "cmpp.f.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CN_ON, "cmpp.f.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CN_OC, "cmpp.f.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CN_AN, "cmpp.f.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CN_AC, "cmpp.f.CN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CC_UN, "cmpp.f.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CC_UC, "cmpp.f.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CC_CN, "cmpp.f.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CC_CC, "cmpp.f.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CC_ON, "cmpp.f.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CC_OC, "cmpp.f.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CC_AN, "cmpp.f.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_CC_AC, "cmpp.f.CC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_ON_UN, "cmpp.f.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_ON_UC, "cmpp.f.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_ON_CN, "cmpp.f.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_ON_CC, "cmpp.f.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_ON_ON, "cmpp.f.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_ON_OC, "cmpp.f.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_ON_AN, "cmpp.f.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_ON_AC, "cmpp.f.ON.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_OC_UN, "cmpp.f.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_OC_UC, "cmpp.f.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_OC_CN, "cmpp.f.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_OC_CC, "cmpp.f.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_OC_ON, "cmpp.f.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_OC_OC, "cmpp.f.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_OC_AN, "cmpp.f.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_OC_AC, "cmpp.f.OC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AN_UN, "cmpp.f.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AN_UC, "cmpp.f.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AN_CN, "cmpp.f.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AN_CC, "cmpp.f.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AN_ON, "cmpp.f.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AN_OC, "cmpp.f.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AN_AN, "cmpp.f.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AN_AC, "cmpp.f.AN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AC_UN, "cmpp.f.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AC_UC, "cmpp.f.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AC_CN, "cmpp.f.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AC_CC, "cmpp.f.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AC_ON, "cmpp.f.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AC_OC, "cmpp.f.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AC_AN, "cmpp.f.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_FALSE_AC_AC, "cmpp.f.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp1_2()
{
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UN_UN, "cmpp.=.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UN_UC, "cmpp.=.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UN_CN, "cmpp.=.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UN_CC, "cmpp.=.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UN_ON, "cmpp.=.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UN_OC, "cmpp.=.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UN_AN, "cmpp.=.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UN_AC, "cmpp.=.UN.AC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UC_UN, "cmpp.=.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UC_UC, "cmpp.=.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UC_CN, "cmpp.=.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UC_CC, "cmpp.=.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UC_ON, "cmpp.=.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UC_OC, "cmpp.=.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UC_AN, "cmpp.=.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_UC_AC, "cmpp.=.UC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CN_UN, "cmpp.=.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CN_UC, "cmpp.=.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CN_CN, "cmpp.=.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CN_CC, "cmpp.=.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CN_ON, "cmpp.=.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CN_OC, "cmpp.=.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CN_AN, "cmpp.=.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CN_AC, "cmpp.=.CN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CC_UN, "cmpp.=.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CC_UC, "cmpp.=.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CC_CN, "cmpp.=.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CC_CC, "cmpp.=.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CC_ON, "cmpp.=.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CC_OC, "cmpp.=.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CC_AN, "cmpp.=.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_CC_AC, "cmpp.=.CC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_ON_UN, "cmpp.=.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_ON_UC, "cmpp.=.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_ON_CN, "cmpp.=.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_ON_CC, "cmpp.=.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_ON_ON, "cmpp.=.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_ON_OC, "cmpp.=.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_ON_AN, "cmpp.=.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_ON_AC, "cmpp.=.ON.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_OC_UN, "cmpp.=.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_OC_UC, "cmpp.=.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_OC_CN, "cmpp.=.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_OC_CC, "cmpp.=.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_OC_ON, "cmpp.=.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_OC_OC, "cmpp.=.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_OC_AN, "cmpp.=.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_OC_AC, "cmpp.=.OC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AN_UN, "cmpp.=.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AN_UC, "cmpp.=.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AN_CN, "cmpp.=.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AN_CC, "cmpp.=.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AN_ON, "cmpp.=.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AN_OC, "cmpp.=.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AN_AN, "cmpp.=.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AN_AC, "cmpp.=.AN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AC_UN, "cmpp.=.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AC_UC, "cmpp.=.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AC_CN, "cmpp.=.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AC_CC, "cmpp.=.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AC_ON, "cmpp.=.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AC_OC, "cmpp.=.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AC_AN, "cmpp.=.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EQ_AC_AC, "cmpp.=.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp1_3()
{
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UN_UN, "cmpp.<.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UN_UC, "cmpp.<.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UN_CN, "cmpp.<.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UN_CC, "cmpp.<.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UN_ON, "cmpp.<.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UN_OC, "cmpp.<.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UN_AN, "cmpp.<.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UN_AC, "cmpp.<.UN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UC_UN, "cmpp.<.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UC_UC, "cmpp.<.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UC_CN, "cmpp.<.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UC_CC, "cmpp.<.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UC_ON, "cmpp.<.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UC_OC, "cmpp.<.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UC_AN, "cmpp.<.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_UC_AC, "cmpp.<.UC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CN_UN, "cmpp.<.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CN_UC, "cmpp.<.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CN_CN, "cmpp.<.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CN_CC, "cmpp.<.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CN_ON, "cmpp.<.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CN_OC, "cmpp.<.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CN_AN, "cmpp.<.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CN_AC, "cmpp.<.CN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CC_UN, "cmpp.<.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CC_UC, "cmpp.<.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CC_CN, "cmpp.<.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CC_CC, "cmpp.<.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CC_ON, "cmpp.<.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CC_OC, "cmpp.<.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CC_AN, "cmpp.<.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_CC_AC, "cmpp.<.CC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_ON_UN, "cmpp.<.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_ON_UC, "cmpp.<.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_ON_CN, "cmpp.<.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_ON_CC, "cmpp.<.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_ON_ON, "cmpp.<.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_ON_OC, "cmpp.<.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_ON_AN, "cmpp.<.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_ON_AC, "cmpp.<.ON.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_OC_UN, "cmpp.<.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_OC_UC, "cmpp.<.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_OC_CN, "cmpp.<.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_OC_CC, "cmpp.<.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_OC_ON, "cmpp.<.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_OC_OC, "cmpp.<.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_OC_AN, "cmpp.<.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_OC_AC, "cmpp.<.OC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AN_UN, "cmpp.<.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AN_UC, "cmpp.<.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AN_CN, "cmpp.<.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AN_CC, "cmpp.<.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AN_ON, "cmpp.<.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AN_OC, "cmpp.<.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AN_AN, "cmpp.<.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AN_AC, "cmpp.<.AN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AC_UN, "cmpp.<.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AC_UC, "cmpp.<.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AC_CN, "cmpp.<.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AC_CC, "cmpp.<.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AC_ON, "cmpp.<.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AC_OC, "cmpp.<.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AC_AN, "cmpp.<.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LT_AC_AC, "cmpp.<.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp1_4()
{
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UN_UN, "cmpp.<=.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UN_UC, "cmpp.<=.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UN_CN, "cmpp.<=.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UN_CC, "cmpp.<=.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UN_ON, "cmpp.<=.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UN_OC, "cmpp.<=.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UN_AN, "cmpp.<=.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UN_AC, "cmpp.<=.UN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UC_UN, "cmpp.<=.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UC_UC, "cmpp.<=.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UC_CN, "cmpp.<=.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UC_CC, "cmpp.<=.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UC_ON, "cmpp.<=.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UC_OC, "cmpp.<=.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UC_AN, "cmpp.<=.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_UC_AC, "cmpp.<=.UC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CN_UN, "cmpp.<=.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CN_UC, "cmpp.<=.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CN_CN, "cmpp.<=.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CN_CC, "cmpp.<=.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CN_ON, "cmpp.<=.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CN_OC, "cmpp.<=.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CN_AN, "cmpp.<=.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CN_AC, "cmpp.<=.CN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CC_UN, "cmpp.<=.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CC_UC, "cmpp.<=.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CC_CN, "cmpp.<=.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CC_CC, "cmpp.<=.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CC_ON, "cmpp.<=.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CC_OC, "cmpp.<=.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CC_AN, "cmpp.<=.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_CC_AC, "cmpp.<=.CC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_ON_UN, "cmpp.<=.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_ON_UC, "cmpp.<=.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_ON_CN, "cmpp.<=.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_ON_CC, "cmpp.<=.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_ON_ON, "cmpp.<=.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_ON_OC, "cmpp.<=.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_ON_AN, "cmpp.<=.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_ON_AC, "cmpp.<=.ON.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_OC_UN, "cmpp.<=.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_OC_UC, "cmpp.<=.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_OC_CN, "cmpp.<=.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_OC_CC, "cmpp.<=.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_OC_ON, "cmpp.<=.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_OC_OC, "cmpp.<=.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_OC_AN, "cmpp.<=.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_OC_AC, "cmpp.<=.OC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AN_UN, "cmpp.<=.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AN_UC, "cmpp.<=.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AN_CN, "cmpp.<=.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AN_CC, "cmpp.<=.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AN_ON, "cmpp.<=.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AN_OC, "cmpp.<=.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AN_AN, "cmpp.<=.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AN_AC, "cmpp.<=.AN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AC_UN, "cmpp.<=.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AC_UC, "cmpp.<=.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AC_CN, "cmpp.<=.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AC_CC, "cmpp.<=.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AC_ON, "cmpp.<=.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AC_OC, "cmpp.<=.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AC_AN, "cmpp.<=.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LEQ_AC_AC, "cmpp.<=.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp1_5()
{
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UN_UN, "cmpp.>.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UN_UC, "cmpp.>.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UN_CN, "cmpp.>.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UN_CC, "cmpp.>.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UN_ON, "cmpp.>.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UN_OC, "cmpp.>.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UN_AN, "cmpp.>.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UN_AC, "cmpp.>.UN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UC_UN, "cmpp.>.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UC_UC, "cmpp.>.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UC_CN, "cmpp.>.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UC_CC, "cmpp.>.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UC_ON, "cmpp.>.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UC_OC, "cmpp.>.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UC_AN, "cmpp.>.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_UC_AC, "cmpp.>.UC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CN_UN, "cmpp.>.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CN_UC, "cmpp.>.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CN_CN, "cmpp.>.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CN_CC, "cmpp.>.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CN_ON, "cmpp.>.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CN_OC, "cmpp.>.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CN_AN, "cmpp.>.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CN_AC, "cmpp.>.CN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CC_UN, "cmpp.>.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CC_UC, "cmpp.>.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CC_CN, "cmpp.>.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CC_CC, "cmpp.>.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CC_ON, "cmpp.>.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CC_OC, "cmpp.>.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CC_AN, "cmpp.>.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_CC_AC, "cmpp.>.CC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_ON_UN, "cmpp.>.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_ON_UC, "cmpp.>.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_ON_CN, "cmpp.>.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_ON_CC, "cmpp.>.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_ON_ON, "cmpp.>.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_ON_OC, "cmpp.>.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_ON_AN, "cmpp.>.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_ON_AC, "cmpp.>.ON.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_OC_UN, "cmpp.>.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_OC_UC, "cmpp.>.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_OC_CN, "cmpp.>.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_OC_CC, "cmpp.>.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_OC_ON, "cmpp.>.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_OC_OC, "cmpp.>.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_OC_AN, "cmpp.>.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_OC_AC, "cmpp.>.OC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AN_UN, "cmpp.>.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AN_UC, "cmpp.>.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AN_CN, "cmpp.>.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AN_CC, "cmpp.>.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AN_ON, "cmpp.>.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AN_OC, "cmpp.>.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AN_AN, "cmpp.>.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AN_AC, "cmpp.>.AN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AC_UN, "cmpp.>.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AC_UC, "cmpp.>.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AC_CN, "cmpp.>.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AC_CC, "cmpp.>.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AC_ON, "cmpp.>.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AC_OC, "cmpp.>.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AC_AN, "cmpp.>.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GT_AC_AC, "cmpp.>.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp1_6()
{
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UN_UN, "cmpp.>=.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UN_UC, "cmpp.>=.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UN_CN, "cmpp.>=.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UN_CC, "cmpp.>=.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UN_ON, "cmpp.>=.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UN_OC, "cmpp.>=.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UN_AN, "cmpp.>=.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UN_AC, "cmpp.>=.UN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UC_UN, "cmpp.>=.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UC_UC, "cmpp.>=.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UC_CN, "cmpp.>=.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UC_CC, "cmpp.>=.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UC_ON, "cmpp.>=.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UC_OC, "cmpp.>=.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UC_AN, "cmpp.>=.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_UC_AC, "cmpp.>=.UC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CN_UN, "cmpp.>=.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CN_UC, "cmpp.>=.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CN_CN, "cmpp.>=.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CN_CC, "cmpp.>=.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CN_ON, "cmpp.>=.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CN_OC, "cmpp.>=.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CN_AN, "cmpp.>=.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CN_AC, "cmpp.>=.CN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CC_UN, "cmpp.>=.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CC_UC, "cmpp.>=.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CC_CN, "cmpp.>=.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CC_CC, "cmpp.>=.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CC_ON, "cmpp.>=.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CC_OC, "cmpp.>=.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CC_AN, "cmpp.>=.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_CC_AC, "cmpp.>=.CC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_ON_UN, "cmpp.>=.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_ON_UC, "cmpp.>=.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_ON_CN, "cmpp.>=.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_ON_CC, "cmpp.>=.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_ON_ON, "cmpp.>=.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_ON_OC, "cmpp.>=.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_ON_AN, "cmpp.>=.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_ON_AC, "cmpp.>=.ON.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_OC_UN, "cmpp.>=.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_OC_UC, "cmpp.>=.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_OC_CN, "cmpp.>=.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_OC_CC, "cmpp.>=.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_OC_ON, "cmpp.>=.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_OC_OC, "cmpp.>=.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_OC_AN, "cmpp.>=.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_OC_AC, "cmpp.>=.OC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AN_UN, "cmpp.>=.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AN_UC, "cmpp.>=.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AN_CN, "cmpp.>=.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AN_CC, "cmpp.>=.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AN_ON, "cmpp.>=.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AN_OC, "cmpp.>=.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AN_AN, "cmpp.>=.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AN_AC, "cmpp.>=.AN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AC_UN, "cmpp.>=.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AC_UC, "cmpp.>=.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AC_CN, "cmpp.>=.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AC_CC, "cmpp.>=.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AC_ON, "cmpp.>=.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AC_OC, "cmpp.>=.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AC_AN, "cmpp.>=.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_GEQ_AC_AC, "cmpp.>=.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp1_7()
{
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UN_UN, "cmpp.-ov.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UN_UC, "cmpp.-ov.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UN_CN, "cmpp.-ov.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UN_CC, "cmpp.-ov.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UN_ON, "cmpp.-ov.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UN_OC, "cmpp.-ov.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UN_AN, "cmpp.-ov.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UN_AC, "cmpp.-ov.UN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UC_UN, "cmpp.-ov.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UC_UC, "cmpp.-ov.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UC_CN, "cmpp.-ov.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UC_CC, "cmpp.-ov.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UC_ON, "cmpp.-ov.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UC_OC, "cmpp.-ov.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UC_AN, "cmpp.-ov.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_UC_AC, "cmpp.-ov.UC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CN_UN, "cmpp.-ov.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CN_UC, "cmpp.-ov.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CN_CN, "cmpp.-ov.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CN_CC, "cmpp.-ov.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CN_ON, "cmpp.-ov.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CN_OC, "cmpp.-ov.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CN_AN, "cmpp.-ov.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CN_AC, "cmpp.-ov.CN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CC_UN, "cmpp.-ov.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CC_UC, "cmpp.-ov.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CC_CN, "cmpp.-ov.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CC_CC, "cmpp.-ov.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CC_ON, "cmpp.-ov.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CC_OC, "cmpp.-ov.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CC_AN, "cmpp.-ov.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_CC_AC, "cmpp.-ov.CC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_ON_UN, "cmpp.-ov.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_ON_UC, "cmpp.-ov.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_ON_CN, "cmpp.-ov.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_ON_CC, "cmpp.-ov.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_ON_ON, "cmpp.-ov.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_ON_OC, "cmpp.-ov.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_ON_AN, "cmpp.-ov.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_ON_AC, "cmpp.-ov.ON.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_OC_UN, "cmpp.-ov.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_OC_UC, "cmpp.-ov.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_OC_CN, "cmpp.-ov.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_OC_CC, "cmpp.-ov.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_OC_ON, "cmpp.-ov.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_OC_OC, "cmpp.-ov.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_OC_AN, "cmpp.-ov.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_OC_AC, "cmpp.-ov.OC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AN_UN, "cmpp.-ov.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AN_UC, "cmpp.-ov.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AN_CN, "cmpp.-ov.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AN_CC, "cmpp.-ov.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AN_ON, "cmpp.-ov.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AN_OC, "cmpp.-ov.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AN_AN, "cmpp.-ov.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AN_AC, "cmpp.-ov.AN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AC_UN, "cmpp.-ov.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AC_UC, "cmpp.-ov.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AC_CN, "cmpp.-ov.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AC_CC, "cmpp.-ov.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AC_ON, "cmpp.-ov.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AC_OC, "cmpp.-ov.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AC_AN, "cmpp.-ov.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_SV_AC_AC, "cmpp.-ov.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp1_8()
{
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UN_UN, "cmpp.-odd.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UN_UC, "cmpp.-odd.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UN_CN, "cmpp.-odd.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UN_CC, "cmpp.-odd.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UN_ON, "cmpp.-odd.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UN_OC, "cmpp.-odd.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UN_AN, "cmpp.-odd.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UN_AC, "cmpp.-odd.UN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UC_UN, "cmpp.-odd.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UC_UC, "cmpp.-odd.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UC_CN, "cmpp.-odd.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UC_CC, "cmpp.-odd.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UC_ON, "cmpp.-odd.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UC_OC, "cmpp.-odd.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UC_AN, "cmpp.-odd.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_UC_AC, "cmpp.-odd.UC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CN_UN, "cmpp.-odd.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CN_UC, "cmpp.-odd.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CN_CN, "cmpp.-odd.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CN_CC, "cmpp.-odd.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CN_ON, "cmpp.-odd.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CN_OC, "cmpp.-odd.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CN_AN, "cmpp.-odd.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CN_AC, "cmpp.-odd.CN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CC_UN, "cmpp.-odd.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CC_UC, "cmpp.-odd.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CC_CN, "cmpp.-odd.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CC_CC, "cmpp.-odd.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CC_ON, "cmpp.-odd.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CC_OC, "cmpp.-odd.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CC_AN, "cmpp.-odd.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_CC_AC, "cmpp.-odd.CC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_ON_UN, "cmpp.-odd.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_ON_UC, "cmpp.-odd.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_ON_CN, "cmpp.-odd.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_ON_CC, "cmpp.-odd.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_ON_ON, "cmpp.-odd.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_ON_OC, "cmpp.-odd.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_ON_AN, "cmpp.-odd.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_ON_AC, "cmpp.-odd.ON.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_OC_UN, "cmpp.-odd.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_OC_UC, "cmpp.-odd.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_OC_CN, "cmpp.-odd.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_OC_CC, "cmpp.-odd.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_OC_ON, "cmpp.-odd.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_OC_OC, "cmpp.-odd.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_OC_AN, "cmpp.-odd.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_OC_AC, "cmpp.-odd.OC.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AN_UN, "cmpp.-odd.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AN_UC, "cmpp.-odd.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AN_CN, "cmpp.-odd.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AN_CC, "cmpp.-odd.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AN_ON, "cmpp.-odd.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AN_OC, "cmpp.-odd.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AN_AN, "cmpp.-odd.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AN_AC, "cmpp.-odd.AN.AC") ;

   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AC_UN, "cmpp.-odd.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AC_UC, "cmpp.-odd.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AC_CN, "cmpp.-odd.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AC_CC, "cmpp.-odd.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AC_ON, "cmpp.-odd.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AC_OC, "cmpp.-odd.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AC_AN, "cmpp.-odd.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_OD_AC_AC, "cmpp.-odd.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp1()
{
   el_init_elcor_opcode_to_symbol_maps_cmpp1_1() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp1_2() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp1_3() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp1_4() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp1_5() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp1_6() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp1_7() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp1_8() ;
}



void el_init_elcor_opcode_to_symbol_maps_cmpp2_1()
{
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UN_UN, "cmpp.t.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UN_UC, "cmpp.t.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UN_CN, "cmpp.t.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UN_CC, "cmpp.t.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UN_ON, "cmpp.t.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UN_OC, "cmpp.t.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UN_AN, "cmpp.t.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UN_AC, "cmpp.t.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UC_UN, "cmpp.t.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UC_UC, "cmpp.t.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UC_CN, "cmpp.t.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UC_CC, "cmpp.t.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UC_ON, "cmpp.t.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UC_OC, "cmpp.t.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UC_AN, "cmpp.t.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_UC_AC, "cmpp.t.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CN_UN, "cmpp.t.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CN_UC, "cmpp.t.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CN_CN, "cmpp.t.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CN_CC, "cmpp.t.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CN_ON, "cmpp.t.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CN_OC, "cmpp.t.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CN_AN, "cmpp.t.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CN_AC, "cmpp.t.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CC_UN, "cmpp.t.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CC_UC, "cmpp.t.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CC_CN, "cmpp.t.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CC_CC, "cmpp.t.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CC_ON, "cmpp.t.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CC_OC, "cmpp.t.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CC_AN, "cmpp.t.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_CC_AC, "cmpp.t.CC.AC") ;
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_ON_UN, "cmpp.t.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_ON_UC, "cmpp.t.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_ON_CN, "cmpp.t.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_ON_CC, "cmpp.t.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_ON_ON, "cmpp.t.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_ON_OC, "cmpp.t.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_ON_AN, "cmpp.t.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_ON_AC, "cmpp.t.ON.AC") ;
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_OC_UN, "cmpp.t.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_OC_UC, "cmpp.t.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_OC_CN, "cmpp.t.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_OC_CC, "cmpp.t.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_OC_ON, "cmpp.t.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_OC_OC, "cmpp.t.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_OC_AN, "cmpp.t.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_OC_AC, "cmpp.t.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AN_UN, "cmpp.t.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AN_UC, "cmpp.t.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AN_CN, "cmpp.t.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AN_CC, "cmpp.t.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AN_ON, "cmpp.t.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AN_OC, "cmpp.t.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AN_AN, "cmpp.t.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AN_AC, "cmpp.t.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AC_UN, "cmpp.t.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AC_UC, "cmpp.t.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AC_CN, "cmpp.t.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AC_CC, "cmpp.t.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AC_ON, "cmpp.t.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AC_OC, "cmpp.t.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AC_AN, "cmpp.t.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_TRUE_AC_AC, "cmpp.t.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp2_2()
{
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UN_UN, "cmpp.<>.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UN_UC, "cmpp.<>.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UN_CN, "cmpp.<>.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UN_CC, "cmpp.<>.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UN_ON, "cmpp.<>.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UN_OC, "cmpp.<>.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UN_AN, "cmpp.<>.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UN_AC, "cmpp.<>.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UC_UN, "cmpp.<>.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UC_UC, "cmpp.<>.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UC_CN, "cmpp.<>.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UC_CC, "cmpp.<>.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UC_ON, "cmpp.<>.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UC_OC, "cmpp.<>.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UC_AN, "cmpp.<>.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_UC_AC, "cmpp.<>.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CN_UN, "cmpp.<>.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CN_UC, "cmpp.<>.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CN_CN, "cmpp.<>.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CN_CC, "cmpp.<>.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CN_ON, "cmpp.<>.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CN_OC, "cmpp.<>.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CN_AN, "cmpp.<>.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CN_AC, "cmpp.<>.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CC_UN, "cmpp.<>.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CC_UC, "cmpp.<>.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CC_CN, "cmpp.<>.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CC_CC, "cmpp.<>.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CC_ON, "cmpp.<>.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CC_OC, "cmpp.<>.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CC_AN, "cmpp.<>.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_CC_AC, "cmpp.<>.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_ON_UN, "cmpp.<>.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_ON_UC, "cmpp.<>.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_ON_CN, "cmpp.<>.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_ON_CC, "cmpp.<>.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_ON_ON, "cmpp.<>.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_ON_OC, "cmpp.<>.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_ON_AN, "cmpp.<>.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_ON_AC, "cmpp.<>.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_OC_UN, "cmpp.<>.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_OC_UC, "cmpp.<>.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_OC_CN, "cmpp.<>.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_OC_CC, "cmpp.<>.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_OC_ON, "cmpp.<>.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_OC_OC, "cmpp.<>.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_OC_AN, "cmpp.<>.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_OC_AC, "cmpp.<>.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AN_UN, "cmpp.<>.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AN_UC, "cmpp.<>.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AN_CN, "cmpp.<>.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AN_CC, "cmpp.<>.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AN_ON, "cmpp.<>.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AN_OC, "cmpp.<>.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AN_AN, "cmpp.<>.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AN_AC, "cmpp.<>.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AC_UN, "cmpp.<>.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AC_UC, "cmpp.<>.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AC_CN, "cmpp.<>.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AC_CC, "cmpp.<>.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AC_ON, "cmpp.<>.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AC_OC, "cmpp.<>.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AC_AN, "cmpp.<>.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NEQ_AC_AC, "cmpp.<>.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp2_3()
{
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UN_UN, "cmpp.<L.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UN_UC, "cmpp.<L.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UN_CN, "cmpp.<L.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UN_CC, "cmpp.<L.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UN_ON, "cmpp.<L.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UN_OC, "cmpp.<L.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UN_AN, "cmpp.<L.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UN_AC, "cmpp.<L.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UC_UN, "cmpp.<L.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UC_UC, "cmpp.<L.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UC_CN, "cmpp.<L.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UC_CC, "cmpp.<L.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UC_ON, "cmpp.<L.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UC_OC, "cmpp.<L.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UC_AN, "cmpp.<L.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_UC_AC, "cmpp.<L.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CN_UN, "cmpp.<L.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CN_UC, "cmpp.<L.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CN_CN, "cmpp.<L.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CN_CC, "cmpp.<L.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CN_ON, "cmpp.<L.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CN_OC, "cmpp.<L.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CN_AN, "cmpp.<L.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CN_AC, "cmpp.<L.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CC_UN, "cmpp.<L.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CC_UC, "cmpp.<L.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CC_CN, "cmpp.<L.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CC_CC, "cmpp.<L.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CC_ON, "cmpp.<L.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CC_OC, "cmpp.<L.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CC_AN, "cmpp.<L.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_CC_AC, "cmpp.<L.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_ON_UN, "cmpp.<L.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_ON_UC, "cmpp.<L.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_ON_CN, "cmpp.<L.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_ON_CC, "cmpp.<L.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_ON_ON, "cmpp.<L.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_ON_OC, "cmpp.<L.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_ON_AN, "cmpp.<L.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_ON_AC, "cmpp.<L.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_OC_UN, "cmpp.<L.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_OC_UC, "cmpp.<L.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_OC_CN, "cmpp.<L.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_OC_CC, "cmpp.<L.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_OC_ON, "cmpp.<L.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_OC_OC, "cmpp.<L.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_OC_AN, "cmpp.<L.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_OC_AC, "cmpp.<L.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AN_UN, "cmpp.<L.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AN_UC, "cmpp.<L.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AN_CN, "cmpp.<L.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AN_CC, "cmpp.<L.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AN_ON, "cmpp.<L.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AN_OC, "cmpp.<L.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AN_AN, "cmpp.<L.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AN_AC, "cmpp.<L.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AC_UN, "cmpp.<L.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AC_UC, "cmpp.<L.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AC_CN, "cmpp.<L.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AC_CC, "cmpp.<L.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AC_ON, "cmpp.<L.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AC_OC, "cmpp.<L.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AC_AN, "cmpp.<L.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLT_AC_AC, "cmpp.<L.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp2_4()
{
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UN_UN, "cmpp.<=L.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UN_UC, "cmpp.<=L.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UN_CN, "cmpp.<=L.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UN_CC, "cmpp.<=L.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UN_ON, "cmpp.<=L.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UN_OC, "cmpp.<=L.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UN_AN, "cmpp.<=L.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UN_AC, "cmpp.<=L.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UC_UN, "cmpp.<=L.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UC_UC, "cmpp.<=L.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UC_CN, "cmpp.<=L.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UC_CC, "cmpp.<=L.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UC_ON, "cmpp.<=L.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UC_OC, "cmpp.<=L.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UC_AN, "cmpp.<=L.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_UC_AC, "cmpp.<=L.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CN_UN, "cmpp.<=L.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CN_UC, "cmpp.<=L.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CN_CN, "cmpp.<=L.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CN_CC, "cmpp.<=L.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CN_ON, "cmpp.<=L.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CN_OC, "cmpp.<=L.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CN_AN, "cmpp.<=L.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CN_AC, "cmpp.<=L.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CC_UN, "cmpp.<=L.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CC_UC, "cmpp.<=L.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CC_CN, "cmpp.<=L.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CC_CC, "cmpp.<=L.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CC_ON, "cmpp.<=L.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CC_OC, "cmpp.<=L.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CC_AN, "cmpp.<=L.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_CC_AC, "cmpp.<=L.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_ON_UN, "cmpp.<=L.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_ON_UC, "cmpp.<=L.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_ON_CN, "cmpp.<=L.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_ON_CC, "cmpp.<=L.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_ON_ON, "cmpp.<=L.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_ON_OC, "cmpp.<=L.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_ON_AN, "cmpp.<=L.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_ON_AC, "cmpp.<=L.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_OC_UN, "cmpp.<=L.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_OC_UC, "cmpp.<=L.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_OC_CN, "cmpp.<=L.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_OC_CC, "cmpp.<=L.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_OC_ON, "cmpp.<=L.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_OC_OC, "cmpp.<=L.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_OC_AN, "cmpp.<=L.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_OC_AC, "cmpp.<=L.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AN_UN, "cmpp.<=L.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AN_UC, "cmpp.<=L.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AN_CN, "cmpp.<=L.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AN_CC, "cmpp.<=L.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AN_ON, "cmpp.<=L.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AN_OC, "cmpp.<=L.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AN_AN, "cmpp.<=L.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AN_AC, "cmpp.<=L.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AC_UN, "cmpp.<=L.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AC_UC, "cmpp.<=L.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AC_CN, "cmpp.<=L.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AC_CC, "cmpp.<=L.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AC_ON, "cmpp.<=L.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AC_OC, "cmpp.<=L.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AC_AN, "cmpp.<=L.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LLEQ_AC_AC, "cmpp.<=L.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp2_5()
{
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UN_UN, "cmpp.>L.UN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UN_UC, "cmpp.>L.UN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UN_CN, "cmpp.>L.UN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UN_CC, "cmpp.>L.UN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UN_ON, "cmpp.>L.UN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UN_OC, "cmpp.>L.UN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UN_AN, "cmpp.>L.UN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UN_AC, "cmpp.>L.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UC_UN, "cmpp.>L.UC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UC_UC, "cmpp.>L.UC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UC_CN, "cmpp.>L.UC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UC_CC, "cmpp.>L.UC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UC_ON, "cmpp.>L.UC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UC_OC, "cmpp.>L.UC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UC_AN, "cmpp.>L.UC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_UC_AC, "cmpp.>L.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CN_UN, "cmpp.>L.CN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CN_UC, "cmpp.>L.CN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CN_CN, "cmpp.>L.CN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CN_CC, "cmpp.>L.CN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CN_ON, "cmpp.>L.CN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CN_OC, "cmpp.>L.CN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CN_AN, "cmpp.>L.CN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CN_AC, "cmpp.>L.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CC_UN, "cmpp.>L.CC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CC_UC, "cmpp.>L.CC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CC_CN, "cmpp.>L.CC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CC_CC, "cmpp.>L.CC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CC_ON, "cmpp.>L.CC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CC_OC, "cmpp.>L.CC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CC_AN, "cmpp.>L.CC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_CC_AC, "cmpp.>L.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_ON_UN, "cmpp.>L.ON.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_ON_UC, "cmpp.>L.ON.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_ON_CN, "cmpp.>L.ON.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_ON_CC, "cmpp.>L.ON.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_ON_ON, "cmpp.>L.ON.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_ON_OC, "cmpp.>L.ON.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_ON_AN, "cmpp.>L.ON.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_ON_AC, "cmpp.>L.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_OC_UN, "cmpp.>L.OC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_OC_UC, "cmpp.>L.OC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_OC_CN, "cmpp.>L.OC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_OC_CC, "cmpp.>L.OC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_OC_ON, "cmpp.>L.OC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_OC_OC, "cmpp.>L.OC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_OC_AN, "cmpp.>L.OC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_OC_AC, "cmpp.>L.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AN_UN, "cmpp.>L.AN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AN_UC, "cmpp.>L.AN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AN_CN, "cmpp.>L.AN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AN_CC, "cmpp.>L.AN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AN_ON, "cmpp.>L.AN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AN_OC, "cmpp.>L.AN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AN_AN, "cmpp.>L.AN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AN_AC, "cmpp.>L.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AC_UN, "cmpp.>L.AC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AC_UC, "cmpp.>L.AC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AC_CN, "cmpp.>L.AC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AC_CC, "cmpp.>L.AC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AC_ON, "cmpp.>L.AC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AC_OC, "cmpp.>L.AC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AC_AN, "cmpp.>L.AC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGT_AC_AC, "cmpp.>L.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp2_6()
{
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UN_UN, "cmpp.>=L.UN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UN_UC, "cmpp.>=L.UN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UN_CN, "cmpp.>=L.UN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UN_CC, "cmpp.>=L.UN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UN_ON, "cmpp.>=L.UN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UN_OC, "cmpp.>=L.UN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UN_AN, "cmpp.>=L.UN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UN_AC, "cmpp.>=L.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UC_UN, "cmpp.>=L.UC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UC_UC, "cmpp.>=L.UC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UC_CN, "cmpp.>=L.UC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UC_CC, "cmpp.>=L.UC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UC_ON, "cmpp.>=L.UC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UC_OC, "cmpp.>=L.UC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UC_AN, "cmpp.>=L.UC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_UC_AC, "cmpp.>=L.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CN_UN, "cmpp.>=L.CN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CN_UC, "cmpp.>=L.CN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CN_CN, "cmpp.>=L.CN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CN_CC, "cmpp.>=L.CN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CN_ON, "cmpp.>=L.CN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CN_OC, "cmpp.>=L.CN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CN_AN, "cmpp.>=L.CN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CN_AC, "cmpp.>=L.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CC_UN, "cmpp.>=L.CC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CC_UC, "cmpp.>=L.CC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CC_CN, "cmpp.>=L.CC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CC_CC, "cmpp.>=L.CC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CC_ON, "cmpp.>=L.CC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CC_OC, "cmpp.>=L.CC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CC_AN, "cmpp.>=L.CC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_CC_AC, "cmpp.>=L.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_ON_UN, "cmpp.>=L.ON.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_ON_UC, "cmpp.>=L.ON.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_ON_CN, "cmpp.>=L.ON.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_ON_CC, "cmpp.>=L.ON.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_ON_ON, "cmpp.>=L.ON.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_ON_OC, "cmpp.>=L.ON.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_ON_AN, "cmpp.>=L.ON.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_ON_AC, "cmpp.>=L.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_OC_UN, "cmpp.>=L.OC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_OC_UC, "cmpp.>=L.OC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_OC_CN, "cmpp.>=L.OC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_OC_CC, "cmpp.>=L.OC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_OC_ON, "cmpp.>=L.OC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_OC_OC, "cmpp.>=L.OC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_OC_AN, "cmpp.>=L.OC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_OC_AC, "cmpp.>=L.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AN_UN, "cmpp.>=L.AN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AN_UC, "cmpp.>=L.AN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AN_CN, "cmpp.>=L.AN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AN_CC, "cmpp.>=L.AN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AN_ON, "cmpp.>=L.AN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AN_OC, "cmpp.>=L.AN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AN_AN, "cmpp.>=L.AN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AN_AC, "cmpp.>=L.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AC_UN, "cmpp.>=L.AC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AC_UC, "cmpp.>=L.AC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AC_CN, "cmpp.>=L.AC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AC_CC, "cmpp.>=L.AC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AC_ON, "cmpp.>=L.AC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AC_OC, "cmpp.>=L.AC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AC_AN, "cmpp.>=L.AC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_LGEQ_AC_AC, "cmpp.>=L.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp2_7()
{
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UN_UN, "cmpp.!-ov.UN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UN_UC, "cmpp.!-ov.UN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UN_CN, "cmpp.!-ov.UN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UN_CC, "cmpp.!-ov.UN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UN_ON, "cmpp.!-ov.UN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UN_OC, "cmpp.!-ov.UN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UN_AN, "cmpp.!-ov.UN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UN_AC, "cmpp.!-ov.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UC_UN, "cmpp.!-ov.UC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UC_UC, "cmpp.!-ov.UC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UC_CN, "cmpp.!-ov.UC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UC_CC, "cmpp.!-ov.UC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UC_ON, "cmpp.!-ov.UC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UC_OC, "cmpp.!-ov.UC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UC_AN, "cmpp.!-ov.UC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_UC_AC, "cmpp.!-ov.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CN_UN, "cmpp.!-ov.CN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CN_UC, "cmpp.!-ov.CN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CN_CN, "cmpp.!-ov.CN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CN_CC, "cmpp.!-ov.CN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CN_ON, "cmpp.!-ov.CN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CN_OC, "cmpp.!-ov.CN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CN_AN, "cmpp.!-ov.CN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CN_AC, "cmpp.!-ov.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CC_UN, "cmpp.!-ov.CC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CC_UC, "cmpp.!-ov.CC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CC_CN, "cmpp.!-ov.CC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CC_CC, "cmpp.!-ov.CC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CC_ON, "cmpp.!-ov.CC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CC_OC, "cmpp.!-ov.CC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CC_AN, "cmpp.!-ov.CC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_CC_AC, "cmpp.!-ov.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_ON_UN, "cmpp.!-ov.ON.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_ON_UC, "cmpp.!-ov.ON.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_ON_CN, "cmpp.!-ov.ON.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_ON_CC, "cmpp.!-ov.ON.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_ON_ON, "cmpp.!-ov.ON.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_ON_OC, "cmpp.!-ov.ON.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_ON_AN, "cmpp.!-ov.ON.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_ON_AC, "cmpp.!-ov.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_OC_UN, "cmpp.!-ov.OC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_OC_UC, "cmpp.!-ov.OC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_OC_CN, "cmpp.!-ov.OC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_OC_CC, "cmpp.!-ov.OC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_OC_ON, "cmpp.!-ov.OC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_OC_OC, "cmpp.!-ov.OC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_OC_AN, "cmpp.!-ov.OC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_OC_AC, "cmpp.!-ov.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AN_UN, "cmpp.!-ov.AN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AN_UC, "cmpp.!-ov.AN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AN_CN, "cmpp.!-ov.AN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AN_CC, "cmpp.!-ov.AN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AN_ON, "cmpp.!-ov.AN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AN_OC, "cmpp.!-ov.AN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AN_AN, "cmpp.!-ov.AN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AN_AC, "cmpp.!-ov.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AC_UN, "cmpp.!-ov.AC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AC_UC, "cmpp.!-ov.AC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AC_CN, "cmpp.!-ov.AC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AC_CC, "cmpp.!-ov.AC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AC_ON, "cmpp.!-ov.AC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AC_OC, "cmpp.!-ov.AC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AC_AN, "cmpp.!-ov.AC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_NSV_AC_AC, "cmpp.!-ov.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_cmpp2_8()
{
   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UN_UN, "cmpp.-even.UN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UN_UC, "cmpp.-even.UN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UN_CN, "cmpp.-even.UN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UN_CC, "cmpp.-even.UN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UN_ON, "cmpp.-even.UN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UN_OC, "cmpp.-even.UN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UN_AN, "cmpp.-even.UN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UN_AC, "cmpp.-even.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UC_UN, "cmpp.-even.UC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UC_UC, "cmpp.-even.UC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UC_CN, "cmpp.-even.UC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UC_CC, "cmpp.-even.UC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UC_ON, "cmpp.-even.UC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UC_OC, "cmpp.-even.UC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UC_AN, "cmpp.-even.UC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_UC_AC, "cmpp.-even.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CN_UN, "cmpp.-even.CN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CN_UC, "cmpp.-even.CN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CN_CN, "cmpp.-even.CN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CN_CC, "cmpp.-even.CN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CN_ON, "cmpp.-even.CN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CN_OC, "cmpp.-even.CN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CN_AN, "cmpp.-even.CN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CN_AC, "cmpp.-even.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CC_UN, "cmpp.-even.CC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CC_UC, "cmpp.-even.CC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CC_CN, "cmpp.-even.CC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CC_CC, "cmpp.-even.CC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CC_ON, "cmpp.-even.CC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CC_OC, "cmpp.-even.CC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CC_AN, "cmpp.-even.CC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_CC_AC, "cmpp.-even.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_ON_UN, "cmpp.-even.ON.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_ON_UC, "cmpp.-even.ON.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_ON_CN, "cmpp.-even.ON.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_ON_CC, "cmpp.-even.ON.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_ON_ON, "cmpp.-even.ON.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_ON_OC, "cmpp.-even.ON.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_ON_AN, "cmpp.-even.ON.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_ON_AC, "cmpp.-even.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_OC_UN, "cmpp.-even.OC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_OC_UC, "cmpp.-even.OC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_OC_CN, "cmpp.-even.OC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_OC_CC, "cmpp.-even.OC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_OC_ON, "cmpp.-even.OC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_OC_OC, "cmpp.-even.OC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_OC_AN, "cmpp.-even.OC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_OC_AC, "cmpp.-even.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AN_UN, "cmpp.-even.AN.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AN_UC, "cmpp.-even.AN.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AN_CN, "cmpp.-even.AN.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AN_CC, "cmpp.-even.AN.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AN_ON, "cmpp.-even.AN.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AN_OC, "cmpp.-even.AN.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AN_AN, "cmpp.-even.AN.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AN_AC, "cmpp.-even.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AC_UN, "cmpp.-even.AC.UN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AC_UC, "cmpp.-even.AC.UC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AC_CN, "cmpp.-even.AC.CN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AC_CC, "cmpp.-even.AC.CC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AC_ON, "cmpp.-even.AC.ON");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AC_OC, "cmpp.-even.AC.OC");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AC_AN, "cmpp.-even.AC.AN");
   el_opcode_to_symbol_map.bind((Opcode) CMPP_W_EV_AC_AC, "cmpp.-even.AC.AC") ;
}


//----------------------------------------------------------------------------


void el_init_elcor_opcode_to_symbol_maps_cmpp2()
{
   el_init_elcor_opcode_to_symbol_maps_cmpp2_1() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp2_2() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp2_3() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp2_4() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp2_5() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp2_6() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp2_7() ;
   el_init_elcor_opcode_to_symbol_maps_cmpp2_8() ;
}

void el_init_elcor_opcode_to_symbol_maps()
{
  cerr << "initializing opcode symbol maps...\n" << flush;

    el_init_elcor_opcode_to_symbol_maps_arithmetic();
    el_init_elcor_opcode_to_symbol_maps_cmpp1();
    el_init_elcor_opcode_to_symbol_maps_cmpp2();
    el_init_elcor_opcode_to_symbol_maps_fcmpp1();
    el_init_elcor_opcode_to_symbol_maps_fcmpp2();
    el_init_elcor_opcode_to_symbol_maps_memory();
    el_init_elcor_opcode_to_symbol_maps_misc();

    el_init_elcor_base_opcode_to_symbol_maps();
}


//--------------------------------------------------------------------

void el_init_elcor_opcode_to_symbol_maps_fcmpp1_1()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UN_UN, "cmpp.f.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UN_UC, "cmpp.f.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UN_CN, "cmpp.f.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UN_CC, "cmpp.f.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UN_ON, "cmpp.f.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UN_OC, "cmpp.f.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UN_AN, "cmpp.f.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UN_AC, "cmpp.f.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UC_UN, "cmpp.f.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UC_UC, "cmpp.f.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UC_CN, "cmpp.f.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UC_CC, "cmpp.f.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UC_ON, "cmpp.f.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UC_OC, "cmpp.f.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UC_AN, "cmpp.f.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_UC_AC, "cmpp.f.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CN_UN, "cmpp.f.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CN_UC, "cmpp.f.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CN_CN, "cmpp.f.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CN_CC, "cmpp.f.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CN_ON, "cmpp.f.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CN_OC, "cmpp.f.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CN_AN, "cmpp.f.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CN_AC, "cmpp.f.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CC_UN, "cmpp.f.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CC_UC, "cmpp.f.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CC_CN, "cmpp.f.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CC_CC, "cmpp.f.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CC_ON, "cmpp.f.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CC_OC, "cmpp.f.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CC_AN, "cmpp.f.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_CC_AC, "cmpp.f.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_ON_UN, "cmpp.f.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_ON_UC, "cmpp.f.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_ON_CN, "cmpp.f.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_ON_CC, "cmpp.f.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_ON_ON, "cmpp.f.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_ON_OC, "cmpp.f.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_ON_AN, "cmpp.f.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_ON_AC, "cmpp.f.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_OC_UN, "cmpp.f.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_OC_UC, "cmpp.f.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_OC_CN, "cmpp.f.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_OC_CC, "cmpp.f.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_OC_ON, "cmpp.f.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_OC_OC, "cmpp.f.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_OC_AN, "cmpp.f.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_OC_AC, "cmpp.f.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AN_UN, "cmpp.f.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AN_UC, "cmpp.f.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AN_CN, "cmpp.f.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AN_CC, "cmpp.f.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AN_ON, "cmpp.f.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AN_OC, "cmpp.f.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AN_AN, "cmpp.f.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AN_AC, "cmpp.f.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AC_UN, "cmpp.f.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AC_UC, "cmpp.f.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AC_CN, "cmpp.f.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AC_CC, "cmpp.f.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AC_ON, "cmpp.f.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AC_OC, "cmpp.f.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AC_AN, "cmpp.f.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_FALSE_AC_AC, "cmpp.f.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp1_2()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UN_UN, "cmpp.=.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UN_UC, "cmpp.=.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UN_CN, "cmpp.=.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UN_CC, "cmpp.=.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UN_ON, "cmpp.=.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UN_OC, "cmpp.=.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UN_AN, "cmpp.=.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UN_AC, "cmpp.=.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UC_UN, "cmpp.=.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UC_UC, "cmpp.=.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UC_CN, "cmpp.=.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UC_CC, "cmpp.=.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UC_ON, "cmpp.=.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UC_OC, "cmpp.=.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UC_AN, "cmpp.=.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_UC_AC, "cmpp.=.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CN_UN, "cmpp.=.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CN_UC, "cmpp.=.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CN_CN, "cmpp.=.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CN_CC, "cmpp.=.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CN_ON, "cmpp.=.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CN_OC, "cmpp.=.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CN_AN, "cmpp.=.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CN_AC, "cmpp.=.CN.AC") ;
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CC_UN, "cmpp.=.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CC_UC, "cmpp.=.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CC_CN, "cmpp.=.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CC_CC, "cmpp.=.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CC_ON, "cmpp.=.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CC_OC, "cmpp.=.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CC_AN, "cmpp.=.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_CC_AC, "cmpp.=.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_ON_UN, "cmpp.=.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_ON_UC, "cmpp.=.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_ON_CN, "cmpp.=.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_ON_CC, "cmpp.=.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_ON_ON, "cmpp.=.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_ON_OC, "cmpp.=.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_ON_AN, "cmpp.=.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_ON_AC, "cmpp.=.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_OC_UN, "cmpp.=.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_OC_UC, "cmpp.=.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_OC_CN, "cmpp.=.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_OC_CC, "cmpp.=.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_OC_ON, "cmpp.=.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_OC_OC, "cmpp.=.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_OC_AN, "cmpp.=.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_OC_AC, "cmpp.=.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AN_UN, "cmpp.=.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AN_UC, "cmpp.=.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AN_CN, "cmpp.=.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AN_CC, "cmpp.=.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AN_ON, "cmpp.=.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AN_OC, "cmpp.=.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AN_AN, "cmpp.=.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AN_AC, "cmpp.=.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AC_UN, "cmpp.=.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AC_UC, "cmpp.=.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AC_CN, "cmpp.=.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AC_CC, "cmpp.=.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AC_ON, "cmpp.=.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AC_OC, "cmpp.=.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AC_AN, "cmpp.=.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_EQ_AC_AC, "cmpp.=.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp1_3()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UN_UN, "cmpp.<.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UN_UC, "cmpp.<.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UN_CN, "cmpp.<.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UN_CC, "cmpp.<.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UN_ON, "cmpp.<.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UN_OC, "cmpp.<.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UN_AN, "cmpp.<.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UN_AC, "cmpp.<.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UC_UN, "cmpp.<.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UC_UC, "cmpp.<.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UC_CN, "cmpp.<.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UC_CC, "cmpp.<.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UC_ON, "cmpp.<.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UC_OC, "cmpp.<.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UC_AN, "cmpp.<.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_UC_AC, "cmpp.<.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CN_UN, "cmpp.<.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CN_UC, "cmpp.<.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CN_CN, "cmpp.<.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CN_CC, "cmpp.<.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CN_ON, "cmpp.<.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CN_OC, "cmpp.<.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CN_AN, "cmpp.<.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CN_AC, "cmpp.<.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CC_UN, "cmpp.<.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CC_UC, "cmpp.<.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CC_CN, "cmpp.<.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CC_CC, "cmpp.<.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CC_ON, "cmpp.<.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CC_OC, "cmpp.<.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CC_AN, "cmpp.<.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_CC_AC, "cmpp.<.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_ON_UN, "cmpp.<.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_ON_UC, "cmpp.<.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_ON_CN, "cmpp.<.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_ON_CC, "cmpp.<.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_ON_ON, "cmpp.<.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_ON_OC, "cmpp.<.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_ON_AN, "cmpp.<.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_ON_AC, "cmpp.<.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_OC_UN, "cmpp.<.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_OC_UC, "cmpp.<.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_OC_CN, "cmpp.<.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_OC_CC, "cmpp.<.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_OC_ON, "cmpp.<.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_OC_OC, "cmpp.<.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_OC_AN, "cmpp.<.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_OC_AC, "cmpp.<.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AN_UN, "cmpp.<.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AN_UC, "cmpp.<.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AN_CN, "cmpp.<.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AN_CC, "cmpp.<.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AN_ON, "cmpp.<.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AN_OC, "cmpp.<.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AN_AN, "cmpp.<.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AN_AC, "cmpp.<.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AC_UN, "cmpp.<.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AC_UC, "cmpp.<.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AC_CN, "cmpp.<.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AC_CC, "cmpp.<.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AC_ON, "cmpp.<.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AC_OC, "cmpp.<.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AC_AN, "cmpp.<.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LT_AC_AC, "cmpp.<.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp1_4()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UN_UN, "cmpp.<=.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UN_UC, "cmpp.<=.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UN_CN, "cmpp.<=.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UN_CC, "cmpp.<=.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UN_ON, "cmpp.<=.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UN_OC, "cmpp.<=.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UN_AN, "cmpp.<=.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UN_AC, "cmpp.<=.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UC_UN, "cmpp.<=.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UC_UC, "cmpp.<=.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UC_CN, "cmpp.<=.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UC_CC, "cmpp.<=.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UC_ON, "cmpp.<=.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UC_OC, "cmpp.<=.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UC_AN, "cmpp.<=.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_UC_AC, "cmpp.<=.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CN_UN, "cmpp.<=.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CN_UC, "cmpp.<=.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CN_CN, "cmpp.<=.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CN_CC, "cmpp.<=.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CN_ON, "cmpp.<=.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CN_OC, "cmpp.<=.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CN_AN, "cmpp.<=.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CN_AC, "cmpp.<=.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CC_UN, "cmpp.<=.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CC_UC, "cmpp.<=.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CC_CN, "cmpp.<=.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CC_CC, "cmpp.<=.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CC_ON, "cmpp.<=.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CC_OC, "cmpp.<=.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CC_AN, "cmpp.<=.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_CC_AC, "cmpp.<=.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_ON_UN, "cmpp.<=.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_ON_UC, "cmpp.<=.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_ON_CN, "cmpp.<=.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_ON_CC, "cmpp.<=.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_ON_ON, "cmpp.<=.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_ON_OC, "cmpp.<=.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_ON_AN, "cmpp.<=.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_ON_AC, "cmpp.<=.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_OC_UN, "cmpp.<=.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_OC_UC, "cmpp.<=.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_OC_CN, "cmpp.<=.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_OC_CC, "cmpp.<=.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_OC_ON, "cmpp.<=.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_OC_OC, "cmpp.<=.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_OC_AN, "cmpp.<=.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_OC_AC, "cmpp.<=.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AN_UN, "cmpp.<=.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AN_UC, "cmpp.<=.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AN_CN, "cmpp.<=.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AN_CC, "cmpp.<=.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AN_ON, "cmpp.<=.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AN_OC, "cmpp.<=.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AN_AN, "cmpp.<=.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AN_AC, "cmpp.<=.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AC_UN, "cmpp.<=.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AC_UC, "cmpp.<=.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AC_CN, "cmpp.<=.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AC_CC, "cmpp.<=.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AC_ON, "cmpp.<=.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AC_OC, "cmpp.<=.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AC_AN, "cmpp.<=.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_LEQ_AC_AC, "cmpp.<=.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp1_5()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UN_UN, "cmpp.>.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UN_UC, "cmpp.>.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UN_CN, "cmpp.>.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UN_CC, "cmpp.>.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UN_ON, "cmpp.>.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UN_OC, "cmpp.>.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UN_AN, "cmpp.>.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UN_AC, "cmpp.>.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UC_UN, "cmpp.>.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UC_UC, "cmpp.>.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UC_CN, "cmpp.>.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UC_CC, "cmpp.>.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UC_ON, "cmpp.>.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UC_OC, "cmpp.>.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UC_AN, "cmpp.>.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_UC_AC, "cmpp.>.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CN_UN, "cmpp.>.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CN_UC, "cmpp.>.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CN_CN, "cmpp.>.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CN_CC, "cmpp.>.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CN_ON, "cmpp.>.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CN_OC, "cmpp.>.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CN_AN, "cmpp.>.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CN_AC, "cmpp.>.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CC_UN, "cmpp.>.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CC_UC, "cmpp.>.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CC_CN, "cmpp.>.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CC_CC, "cmpp.>.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CC_ON, "cmpp.>.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CC_OC, "cmpp.>.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CC_AN, "cmpp.>.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_CC_AC, "cmpp.>.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_ON_UN, "cmpp.>.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_ON_UC, "cmpp.>.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_ON_CN, "cmpp.>.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_ON_CC, "cmpp.>.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_ON_ON, "cmpp.>.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_ON_OC, "cmpp.>.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_ON_AN, "cmpp.>.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_ON_AC, "cmpp.>.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_OC_UN, "cmpp.>.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_OC_UC, "cmpp.>.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_OC_CN, "cmpp.>.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_OC_CC, "cmpp.>.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_OC_ON, "cmpp.>.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_OC_OC, "cmpp.>.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_OC_AN, "cmpp.>.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_OC_AC, "cmpp.>.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AN_UN, "cmpp.>.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AN_UC, "cmpp.>.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AN_CN, "cmpp.>.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AN_CC, "cmpp.>.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AN_ON, "cmpp.>.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AN_OC, "cmpp.>.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AN_AN, "cmpp.>.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AN_AC, "cmpp.>.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AC_UN, "cmpp.>.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AC_UC, "cmpp.>.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AC_CN, "cmpp.>.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AC_CC, "cmpp.>.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AC_ON, "cmpp.>.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AC_OC, "cmpp.>.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AC_AN, "cmpp.>.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GT_AC_AC, "cmpp.>.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp1_6()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UN_UN, "cmpp.>=.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UN_UC, "cmpp.>=.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UN_CN, "cmpp.>=.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UN_CC, "cmpp.>=.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UN_ON, "cmpp.>=.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UN_OC, "cmpp.>=.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UN_AN, "cmpp.>=.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UN_AC, "cmpp.>=.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UC_UN, "cmpp.>=.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UC_UC, "cmpp.>=.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UC_CN, "cmpp.>=.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UC_CC, "cmpp.>=.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UC_ON, "cmpp.>=.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UC_OC, "cmpp.>=.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UC_AN, "cmpp.>=.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_UC_AC, "cmpp.>=.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CN_UN, "cmpp.>=.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CN_UC, "cmpp.>=.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CN_CN, "cmpp.>=.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CN_CC, "cmpp.>=.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CN_ON, "cmpp.>=.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CN_OC, "cmpp.>=.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CN_AN, "cmpp.>=.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CN_AC, "cmpp.>=.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CC_UN, "cmpp.>=.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CC_UC, "cmpp.>=.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CC_CN, "cmpp.>=.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CC_CC, "cmpp.>=.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CC_ON, "cmpp.>=.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CC_OC, "cmpp.>=.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CC_AN, "cmpp.>=.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_CC_AC, "cmpp.>=.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_ON_UN, "cmpp.>=.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_ON_UC, "cmpp.>=.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_ON_CN, "cmpp.>=.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_ON_CC, "cmpp.>=.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_ON_ON, "cmpp.>=.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_ON_OC, "cmpp.>=.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_ON_AN, "cmpp.>=.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_ON_AC, "cmpp.>=.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_OC_UN, "cmpp.>=.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_OC_UC, "cmpp.>=.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_OC_CN, "cmpp.>=.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_OC_CC, "cmpp.>=.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_OC_ON, "cmpp.>=.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_OC_OC, "cmpp.>=.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_OC_AN, "cmpp.>=.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_OC_AC, "cmpp.>=.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AN_UN, "cmpp.>=.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AN_UC, "cmpp.>=.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AN_CN, "cmpp.>=.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AN_CC, "cmpp.>=.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AN_ON, "cmpp.>=.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AN_OC, "cmpp.>=.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AN_AN, "cmpp.>=.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AN_AC, "cmpp.>=.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AC_UN, "cmpp.>=.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AC_UC, "cmpp.>=.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AC_CN, "cmpp.>=.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AC_CC, "cmpp.>=.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AC_ON, "cmpp.>=.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AC_OC, "cmpp.>=.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AC_AN, "cmpp.>=.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_GEQ_AC_AC, "cmpp.>=.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp1_7()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UN_UN, "cmpp.<>.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UN_UC, "cmpp.<>.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UN_CN, "cmpp.<>.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UN_CC, "cmpp.<>.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UN_ON, "cmpp.<>.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UN_OC, "cmpp.<>.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UN_AN, "cmpp.<>.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UN_AC, "cmpp.<>.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UC_UN, "cmpp.<>.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UC_UC, "cmpp.<>.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UC_CN, "cmpp.<>.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UC_CC, "cmpp.<>.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UC_ON, "cmpp.<>.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UC_OC, "cmpp.<>.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UC_AN, "cmpp.<>.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_UC_AC, "cmpp.<>.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CN_UN, "cmpp.<>.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CN_UC, "cmpp.<>.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CN_CN, "cmpp.<>.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CN_CC, "cmpp.<>.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CN_ON, "cmpp.<>.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CN_OC, "cmpp.<>.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CN_AN, "cmpp.<>.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CN_AC, "cmpp.<>.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CC_UN, "cmpp.<>.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CC_UC, "cmpp.<>.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CC_CN, "cmpp.<>.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CC_CC, "cmpp.<>.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CC_ON, "cmpp.<>.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CC_OC, "cmpp.<>.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CC_AN, "cmpp.<>.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_CC_AC, "cmpp.<>.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_ON_UN, "cmpp.<>.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_ON_UC, "cmpp.<>.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_ON_CN, "cmpp.<>.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_ON_CC, "cmpp.<>.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_ON_ON, "cmpp.<>.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_ON_OC, "cmpp.<>.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_ON_AN, "cmpp.<>.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_ON_AC, "cmpp.<>.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_OC_UN, "cmpp.<>.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_OC_UC, "cmpp.<>.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_OC_CN, "cmpp.<>.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_OC_CC, "cmpp.<>.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_OC_ON, "cmpp.<>.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_OC_OC, "cmpp.<>.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_OC_AN, "cmpp.<>.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_OC_AC, "cmpp.<>.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AN_UN, "cmpp.<>.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AN_UC, "cmpp.<>.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AN_CN, "cmpp.<>.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AN_CC, "cmpp.<>.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AN_ON, "cmpp.<>.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AN_OC, "cmpp.<>.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AN_AN, "cmpp.<>.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AN_AC, "cmpp.<>.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AC_UN, "cmpp.<>.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AC_UC, "cmpp.<>.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AC_CN, "cmpp.<>.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AC_CC, "cmpp.<>.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AC_ON, "cmpp.<>.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AC_OC, "cmpp.<>.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AC_AN, "cmpp.<>.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_NEQ_AC_AC, "cmpp.<>.AC.AC") ;
}



void el_init_elcor_opcode_to_symbol_maps_fcmpp1()
{
   el_init_elcor_opcode_to_symbol_maps_fcmpp1_1() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp1_2() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp1_3() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp1_4() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp1_5() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp1_6() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp1_7() ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp2_1()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UN_UN, "cmpp.t.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UN_UC, "cmpp.t.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UN_CN, "cmpp.t.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UN_CC, "cmpp.t.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UN_ON, "cmpp.t.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UN_OC, "cmpp.t.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UN_AN, "cmpp.t.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UN_AC, "cmpp.t.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UC_UN, "cmpp.t.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UC_UC, "cmpp.t.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UC_CN, "cmpp.t.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UC_CC, "cmpp.t.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UC_ON, "cmpp.t.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UC_OC, "cmpp.t.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UC_AN, "cmpp.t.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_UC_AC, "cmpp.t.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CN_UN, "cmpp.t.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CN_UC, "cmpp.t.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CN_CN, "cmpp.t.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CN_CC, "cmpp.t.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CN_ON, "cmpp.t.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CN_OC, "cmpp.t.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CN_AN, "cmpp.t.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CN_AC, "cmpp.t.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CC_UN, "cmpp.t.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CC_UC, "cmpp.t.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CC_CN, "cmpp.t.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CC_CC, "cmpp.t.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CC_ON, "cmpp.t.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CC_OC, "cmpp.t.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CC_AN, "cmpp.t.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_CC_AC, "cmpp.t.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_ON_UN, "cmpp.t.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_ON_UC, "cmpp.t.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_ON_CN, "cmpp.t.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_ON_CC, "cmpp.t.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_ON_ON, "cmpp.t.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_ON_OC, "cmpp.t.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_ON_AN, "cmpp.t.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_ON_AC, "cmpp.t.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_OC_UN, "cmpp.t.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_OC_UC, "cmpp.t.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_OC_CN, "cmpp.t.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_OC_CC, "cmpp.t.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_OC_ON, "cmpp.t.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_OC_OC, "cmpp.t.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_OC_AN, "cmpp.t.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_OC_AC, "cmpp.t.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AN_UN, "cmpp.t.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AN_UC, "cmpp.t.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AN_CN, "cmpp.t.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AN_CC, "cmpp.t.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AN_ON, "cmpp.t.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AN_OC, "cmpp.t.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AN_AN, "cmpp.t.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AN_AC, "cmpp.t.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AC_UN, "cmpp.t.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AC_UC, "cmpp.t.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AC_CN, "cmpp.t.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AC_CC, "cmpp.t.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AC_ON, "cmpp.t.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AC_OC, "cmpp.t.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AC_AN, "cmpp.t.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_S_TRUE_AC_AC, "cmpp.t.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp2_2()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UN_UN, "cmpp.f.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UN_UC, "cmpp.f.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UN_CN, "cmpp.f.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UN_CC, "cmpp.f.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UN_ON, "cmpp.f.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UN_OC, "cmpp.f.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UN_AN, "cmpp.f.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UN_AC, "cmpp.f.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UC_UN, "cmpp.f.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UC_UC, "cmpp.f.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UC_CN, "cmpp.f.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UC_CC, "cmpp.f.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UC_ON, "cmpp.f.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UC_OC, "cmpp.f.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UC_AN, "cmpp.f.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_UC_AC, "cmpp.f.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CN_UN, "cmpp.f.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CN_UC, "cmpp.f.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CN_CN, "cmpp.f.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CN_CC, "cmpp.f.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CN_ON, "cmpp.f.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CN_OC, "cmpp.f.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CN_AN, "cmpp.f.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CN_AC, "cmpp.f.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CC_UN, "cmpp.f.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CC_UC, "cmpp.f.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CC_CN, "cmpp.f.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CC_CC, "cmpp.f.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CC_ON, "cmpp.f.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CC_OC, "cmpp.f.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CC_AN, "cmpp.f.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_CC_AC, "cmpp.f.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_ON_UN, "cmpp.f.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_ON_UC, "cmpp.f.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_ON_CN, "cmpp.f.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_ON_CC, "cmpp.f.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_ON_ON, "cmpp.f.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_ON_OC, "cmpp.f.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_ON_AN, "cmpp.f.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_ON_AC, "cmpp.f.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_OC_UN, "cmpp.f.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_OC_UC, "cmpp.f.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_OC_CN, "cmpp.f.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_OC_CC, "cmpp.f.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_OC_ON, "cmpp.f.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_OC_OC, "cmpp.f.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_OC_AN, "cmpp.f.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_OC_AC, "cmpp.f.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AN_UN, "cmpp.f.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AN_UC, "cmpp.f.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AN_CN, "cmpp.f.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AN_CC, "cmpp.f.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AN_ON, "cmpp.f.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AN_OC, "cmpp.f.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AN_AN, "cmpp.f.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AN_AC, "cmpp.f.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AC_UN, "cmpp.f.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AC_UC, "cmpp.f.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AC_CN, "cmpp.f.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AC_CC, "cmpp.f.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AC_ON, "cmpp.f.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AC_OC, "cmpp.f.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AC_AN, "cmpp.f.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_FALSE_AC_AC, "cmpp.f.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp2_3()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UN_UN, "cmpp.=.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UN_UC, "cmpp.=.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UN_CN, "cmpp.=.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UN_CC, "cmpp.=.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UN_ON, "cmpp.=.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UN_OC, "cmpp.=.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UN_AN, "cmpp.=.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UN_AC, "cmpp.=.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UC_UN, "cmpp.=.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UC_UC, "cmpp.=.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UC_CN, "cmpp.=.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UC_CC, "cmpp.=.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UC_ON, "cmpp.=.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UC_OC, "cmpp.=.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UC_AN, "cmpp.=.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_UC_AC, "cmpp.=.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CN_UN, "cmpp.=.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CN_UC, "cmpp.=.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CN_CN, "cmpp.=.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CN_CC, "cmpp.=.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CN_ON, "cmpp.=.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CN_OC, "cmpp.=.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CN_AN, "cmpp.=.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CN_AC, "cmpp.=.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CC_UN, "cmpp.=.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CC_UC, "cmpp.=.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CC_CN, "cmpp.=.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CC_CC, "cmpp.=.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CC_ON, "cmpp.=.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CC_OC, "cmpp.=.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CC_AN, "cmpp.=.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_CC_AC, "cmpp.=.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_ON_UN, "cmpp.=.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_ON_UC, "cmpp.=.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_ON_CN, "cmpp.=.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_ON_CC, "cmpp.=.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_ON_ON, "cmpp.=.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_ON_OC, "cmpp.=.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_ON_AN, "cmpp.=.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_ON_AC, "cmpp.=.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_OC_UN, "cmpp.=.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_OC_UC, "cmpp.=.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_OC_CN, "cmpp.=.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_OC_CC, "cmpp.=.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_OC_ON, "cmpp.=.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_OC_OC, "cmpp.=.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_OC_AN, "cmpp.=.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_OC_AC, "cmpp.=.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AN_UN, "cmpp.=.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AN_UC, "cmpp.=.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AN_CN, "cmpp.=.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AN_CC, "cmpp.=.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AN_ON, "cmpp.=.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AN_OC, "cmpp.=.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AN_AN, "cmpp.=.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AN_AC, "cmpp.=.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AC_UN, "cmpp.=.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AC_UC, "cmpp.=.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AC_CN, "cmpp.=.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AC_CC, "cmpp.=.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AC_ON, "cmpp.=.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AC_OC, "cmpp.=.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AC_AN, "cmpp.=.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_EQ_AC_AC, "cmpp.=.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp2_4()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UN_UN, "cmpp.<.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UN_UC, "cmpp.<.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UN_CN, "cmpp.<.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UN_CC, "cmpp.<.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UN_ON, "cmpp.<.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UN_OC, "cmpp.<.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UN_AN, "cmpp.<.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UN_AC, "cmpp.<.UN.AC") ;
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UC_UN, "cmpp.<.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UC_UC, "cmpp.<.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UC_CN, "cmpp.<.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UC_CC, "cmpp.<.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UC_ON, "cmpp.<.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UC_OC, "cmpp.<.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UC_AN, "cmpp.<.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_UC_AC, "cmpp.<.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CN_UN, "cmpp.<.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CN_UC, "cmpp.<.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CN_CN, "cmpp.<.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CN_CC, "cmpp.<.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CN_ON, "cmpp.<.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CN_OC, "cmpp.<.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CN_AN, "cmpp.<.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CN_AC, "cmpp.<.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CC_UN, "cmpp.<.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CC_UC, "cmpp.<.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CC_CN, "cmpp.<.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CC_CC, "cmpp.<.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CC_ON, "cmpp.<.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CC_OC, "cmpp.<.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CC_AN, "cmpp.<.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_CC_AC, "cmpp.<.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_ON_UN, "cmpp.<.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_ON_UC, "cmpp.<.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_ON_CN, "cmpp.<.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_ON_CC, "cmpp.<.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_ON_ON, "cmpp.<.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_ON_OC, "cmpp.<.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_ON_AN, "cmpp.<.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_ON_AC, "cmpp.<.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_OC_UN, "cmpp.<.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_OC_UC, "cmpp.<.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_OC_CN, "cmpp.<.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_OC_CC, "cmpp.<.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_OC_ON, "cmpp.<.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_OC_OC, "cmpp.<.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_OC_AN, "cmpp.<.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_OC_AC, "cmpp.<.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AN_UN, "cmpp.<.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AN_UC, "cmpp.<.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AN_CN, "cmpp.<.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AN_CC, "cmpp.<.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AN_ON, "cmpp.<.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AN_OC, "cmpp.<.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AN_AN, "cmpp.<.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AN_AC, "cmpp.<.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AC_UN, "cmpp.<.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AC_UC, "cmpp.<.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AC_CN, "cmpp.<.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AC_CC, "cmpp.<.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AC_ON, "cmpp.<.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AC_OC, "cmpp.<.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AC_AN, "cmpp.<.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LT_AC_AC, "cmpp.<.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp2_5()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UN_UN, "cmpp.<=.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UN_UC, "cmpp.<=.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UN_CN, "cmpp.<=.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UN_CC, "cmpp.<=.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UN_ON, "cmpp.<=.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UN_OC, "cmpp.<=.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UN_AN, "cmpp.<=.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UN_AC, "cmpp.<=.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UC_UN, "cmpp.<=.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UC_UC, "cmpp.<=.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UC_CN, "cmpp.<=.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UC_CC, "cmpp.<=.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UC_ON, "cmpp.<=.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UC_OC, "cmpp.<=.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UC_AN, "cmpp.<=.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_UC_AC, "cmpp.<=.UC.AC") ;


   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CN_UN, "cmpp.<=.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CN_UC, "cmpp.<=.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CN_CN, "cmpp.<=.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CN_CC, "cmpp.<=.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CN_ON, "cmpp.<=.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CN_OC, "cmpp.<=.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CN_AN, "cmpp.<=.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CN_AC, "cmpp.<=.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CC_UN, "cmpp.<=.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CC_UC, "cmpp.<=.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CC_CN, "cmpp.<=.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CC_CC, "cmpp.<=.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CC_ON, "cmpp.<=.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CC_OC, "cmpp.<=.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CC_AN, "cmpp.<=.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_CC_AC, "cmpp.<=.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_ON_UN, "cmpp.<=.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_ON_UC, "cmpp.<=.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_ON_CN, "cmpp.<=.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_ON_CC, "cmpp.<=.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_ON_ON, "cmpp.<=.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_ON_OC, "cmpp.<=.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_ON_AN, "cmpp.<=.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_ON_AC, "cmpp.<=.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_OC_UN, "cmpp.<=.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_OC_UC, "cmpp.<=.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_OC_CN, "cmpp.<=.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_OC_CC, "cmpp.<=.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_OC_ON, "cmpp.<=.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_OC_OC, "cmpp.<=.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_OC_AN, "cmpp.<=.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_OC_AC, "cmpp.<=.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AN_UN, "cmpp.<=.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AN_UC, "cmpp.<=.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AN_CN, "cmpp.<=.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AN_CC, "cmpp.<=.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AN_ON, "cmpp.<=.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AN_OC, "cmpp.<=.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AN_AN, "cmpp.<=.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AN_AC, "cmpp.<=.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AC_UN, "cmpp.<=.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AC_UC, "cmpp.<=.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AC_CN, "cmpp.<=.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AC_CC, "cmpp.<=.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AC_ON, "cmpp.<=.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AC_OC, "cmpp.<=.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AC_AN, "cmpp.<=.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_LEQ_AC_AC, "cmpp.<=.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp2_6()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UN_UN, "cmpp.>.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UN_UC, "cmpp.>.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UN_CN, "cmpp.>.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UN_CC, "cmpp.>.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UN_ON, "cmpp.>.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UN_OC, "cmpp.>.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UN_AN, "cmpp.>.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UN_AC, "cmpp.>.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UC_UN, "cmpp.>.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UC_UC, "cmpp.>.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UC_CN, "cmpp.>.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UC_CC, "cmpp.>.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UC_ON, "cmpp.>.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UC_OC, "cmpp.>.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UC_AN, "cmpp.>.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_UC_AC, "cmpp.>.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CN_UN, "cmpp.>.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CN_UC, "cmpp.>.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CN_CN, "cmpp.>.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CN_CC, "cmpp.>.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CN_ON, "cmpp.>.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CN_OC, "cmpp.>.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CN_AN, "cmpp.>.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CN_AC, "cmpp.>.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CC_UN, "cmpp.>.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CC_UC, "cmpp.>.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CC_CN, "cmpp.>.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CC_CC, "cmpp.>.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CC_ON, "cmpp.>.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CC_OC, "cmpp.>.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CC_AN, "cmpp.>.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_CC_AC, "cmpp.>.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_ON_UN, "cmpp.>.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_ON_UC, "cmpp.>.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_ON_CN, "cmpp.>.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_ON_CC, "cmpp.>.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_ON_ON, "cmpp.>.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_ON_OC, "cmpp.>.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_ON_AN, "cmpp.>.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_ON_AC, "cmpp.>.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_OC_UN, "cmpp.>.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_OC_UC, "cmpp.>.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_OC_CN, "cmpp.>.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_OC_CC, "cmpp.>.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_OC_ON, "cmpp.>.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_OC_OC, "cmpp.>.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_OC_AN, "cmpp.>.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_OC_AC, "cmpp.>.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AN_UN, "cmpp.>.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AN_UC, "cmpp.>.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AN_CN, "cmpp.>.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AN_CC, "cmpp.>.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AN_ON, "cmpp.>.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AN_OC, "cmpp.>.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AN_AN, "cmpp.>.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AN_AC, "cmpp.>.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AC_UN, "cmpp.>.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AC_UC, "cmpp.>.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AC_CN, "cmpp.>.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AC_CC, "cmpp.>.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AC_ON, "cmpp.>.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AC_OC, "cmpp.>.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AC_AN, "cmpp.>.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GT_AC_AC, "cmpp.>.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp2_7()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UN_UN, "cmpp.>=.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UN_UC, "cmpp.>=.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UN_CN, "cmpp.>=.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UN_CC, "cmpp.>=.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UN_ON, "cmpp.>=.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UN_OC, "cmpp.>=.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UN_AN, "cmpp.>=.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UN_AC, "cmpp.>=.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UC_UN, "cmpp.>=.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UC_UC, "cmpp.>=.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UC_CN, "cmpp.>=.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UC_CC, "cmpp.>=.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UC_ON, "cmpp.>=.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UC_OC, "cmpp.>=.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UC_AN, "cmpp.>=.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_UC_AC, "cmpp.>=.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CN_UN, "cmpp.>=.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CN_UC, "cmpp.>=.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CN_CN, "cmpp.>=.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CN_CC, "cmpp.>=.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CN_ON, "cmpp.>=.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CN_OC, "cmpp.>=.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CN_AN, "cmpp.>=.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CN_AC, "cmpp.>=.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CC_UN, "cmpp.>=.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CC_UC, "cmpp.>=.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CC_CN, "cmpp.>=.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CC_CC, "cmpp.>=.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CC_ON, "cmpp.>=.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CC_OC, "cmpp.>=.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CC_AN, "cmpp.>=.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_CC_AC, "cmpp.>=.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_ON_UN, "cmpp.>=.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_ON_UC, "cmpp.>=.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_ON_CN, "cmpp.>=.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_ON_CC, "cmpp.>=.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_ON_ON, "cmpp.>=.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_ON_OC, "cmpp.>=.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_ON_AN, "cmpp.>=.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_ON_AC, "cmpp.>=.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_OC_UN, "cmpp.>=.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_OC_UC, "cmpp.>=.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_OC_CN, "cmpp.>=.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_OC_CC, "cmpp.>=.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_OC_ON, "cmpp.>=.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_OC_OC, "cmpp.>=.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_OC_AN, "cmpp.>=.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_OC_AC, "cmpp.>=.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AN_UN, "cmpp.>=.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AN_UC, "cmpp.>=.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AN_CN, "cmpp.>=.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AN_CC, "cmpp.>=.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AN_ON, "cmpp.>=.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AN_OC, "cmpp.>=.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AN_AN, "cmpp.>=.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AN_AC, "cmpp.>=.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AC_UN, "cmpp.>=.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AC_UC, "cmpp.>=.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AC_CN, "cmpp.>=.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AC_CC, "cmpp.>=.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AC_ON, "cmpp.>=.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AC_OC, "cmpp.>=.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AC_AN, "cmpp.>=.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_GEQ_AC_AC, "cmpp.>=.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp2_8()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UN_UN, "cmpp.<>.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UN_UC, "cmpp.<>.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UN_CN, "cmpp.<>.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UN_CC, "cmpp.<>.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UN_ON, "cmpp.<>.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UN_OC, "cmpp.<>.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UN_AN, "cmpp.<>.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UN_AC, "cmpp.<>.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UC_UN, "cmpp.<>.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UC_UC, "cmpp.<>.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UC_CN, "cmpp.<>.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UC_CC, "cmpp.<>.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UC_ON, "cmpp.<>.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UC_OC, "cmpp.<>.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UC_AN, "cmpp.<>.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_UC_AC, "cmpp.<>.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CN_UN, "cmpp.<>.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CN_UC, "cmpp.<>.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CN_CN, "cmpp.<>.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CN_CC, "cmpp.<>.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CN_ON, "cmpp.<>.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CN_OC, "cmpp.<>.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CN_AN, "cmpp.<>.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CN_AC, "cmpp.<>.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CC_UN, "cmpp.<>.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CC_UC, "cmpp.<>.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CC_CN, "cmpp.<>.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CC_CC, "cmpp.<>.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CC_ON, "cmpp.<>.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CC_OC, "cmpp.<>.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CC_AN, "cmpp.<>.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_CC_AC, "cmpp.<>.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_ON_UN, "cmpp.<>.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_ON_UC, "cmpp.<>.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_ON_CN, "cmpp.<>.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_ON_CC, "cmpp.<>.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_ON_ON, "cmpp.<>.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_ON_OC, "cmpp.<>.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_ON_AN, "cmpp.<>.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_ON_AC, "cmpp.<>.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_OC_UN, "cmpp.<>.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_OC_UC, "cmpp.<>.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_OC_CN, "cmpp.<>.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_OC_CC, "cmpp.<>.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_OC_ON, "cmpp.<>.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_OC_OC, "cmpp.<>.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_OC_AN, "cmpp.<>.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_OC_AC, "cmpp.<>.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AN_UN, "cmpp.<>.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AN_UC, "cmpp.<>.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AN_CN, "cmpp.<>.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AN_CC, "cmpp.<>.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AN_ON, "cmpp.<>.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AN_OC, "cmpp.<>.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AN_AN, "cmpp.<>.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AN_AC, "cmpp.<>.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AC_UN, "cmpp.<>.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AC_UC, "cmpp.<>.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AC_CN, "cmpp.<>.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AC_CC, "cmpp.<>.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AC_ON, "cmpp.<>.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AC_OC, "cmpp.<>.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AC_AN, "cmpp.<>.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_NEQ_AC_AC, "cmpp.<>.AC.AC") ;
}

void el_init_elcor_opcode_to_symbol_maps_fcmpp2_9()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UN_UN, "cmpp.t.UN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UN_UC, "cmpp.t.UN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UN_CN, "cmpp.t.UN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UN_CC, "cmpp.t.UN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UN_ON, "cmpp.t.UN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UN_OC, "cmpp.t.UN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UN_AN, "cmpp.t.UN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UN_AC, "cmpp.t.UN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UC_UN, "cmpp.t.UC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UC_UC, "cmpp.t.UC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UC_CN, "cmpp.t.UC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UC_CC, "cmpp.t.UC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UC_ON, "cmpp.t.UC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UC_OC, "cmpp.t.UC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UC_AN, "cmpp.t.UC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_UC_AC, "cmpp.t.UC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CN_UN, "cmpp.t.CN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CN_UC, "cmpp.t.CN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CN_CN, "cmpp.t.CN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CN_CC, "cmpp.t.CN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CN_ON, "cmpp.t.CN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CN_OC, "cmpp.t.CN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CN_AN, "cmpp.t.CN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CN_AC, "cmpp.t.CN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CC_UN, "cmpp.t.CC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CC_UC, "cmpp.t.CC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CC_CN, "cmpp.t.CC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CC_CC, "cmpp.t.CC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CC_ON, "cmpp.t.CC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CC_OC, "cmpp.t.CC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CC_AN, "cmpp.t.CC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_CC_AC, "cmpp.t.CC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_ON_UN, "cmpp.t.ON.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_ON_UC, "cmpp.t.ON.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_ON_CN, "cmpp.t.ON.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_ON_CC, "cmpp.t.ON.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_ON_ON, "cmpp.t.ON.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_ON_OC, "cmpp.t.ON.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_ON_AN, "cmpp.t.ON.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_ON_AC, "cmpp.t.ON.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_OC_UN, "cmpp.t.OC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_OC_UC, "cmpp.t.OC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_OC_CN, "cmpp.t.OC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_OC_CC, "cmpp.t.OC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_OC_ON, "cmpp.t.OC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_OC_OC, "cmpp.t.OC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_OC_AN, "cmpp.t.OC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_OC_AC, "cmpp.t.OC.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AN_UN, "cmpp.t.AN.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AN_UC, "cmpp.t.AN.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AN_CN, "cmpp.t.AN.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AN_CC, "cmpp.t.AN.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AN_ON, "cmpp.t.AN.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AN_OC, "cmpp.t.AN.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AN_AN, "cmpp.t.AN.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AN_AC, "cmpp.t.AN.AC") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AC_UN, "cmpp.t.AC.UN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AC_UC, "cmpp.t.AC.UC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AC_CN, "cmpp.t.AC.CN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AC_CC, "cmpp.t.AC.CC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AC_ON, "cmpp.t.AC.ON") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AC_OC, "cmpp.t.AC.OC") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AC_AN, "cmpp.t.AC.AN") ;
   el_opcode_to_symbol_map.bind((Opcode) FCMPP_D_TRUE_AC_AC, "cmpp.t.AC.AC") ;
}


void el_init_elcor_opcode_to_symbol_maps_fcmpp2()
{
   el_init_elcor_opcode_to_symbol_maps_fcmpp2_1() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp2_2() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp2_3() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp2_4() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp2_5() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp2_6() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp2_7() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp2_8() ;
   el_init_elcor_opcode_to_symbol_maps_fcmpp2_9() ;
}



//-------------------------------------------------------------------------------

void el_init_elcor_opcode_to_symbol_maps_memory_1()
{
   
   el_opcode_to_symbol_map.bind((Opcode) L_B_V1_V1, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_V1_C1, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_V1_C2, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_V1_C3, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C1_V1, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C1_C1, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C1_C2, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C1_C3, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C2_V1, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C2_C1, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C2_C2, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C2_C3, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C3_V1, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C3_C1, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C3_C2, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_B_C3_C3, "ld") ;

   
   el_opcode_to_symbol_map.bind((Opcode) L_H_V1_V1, "ld") ;
   el_opcode_to_symbol_map.bind((Opcode) L_H_V1_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_V1_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_V1_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C1_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C1_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C1_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C1_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C2_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C2_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C2_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C2_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C3_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C3_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C3_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_C3_C3, "ld") ;

   
   el_opcode_to_symbol_map.bind((Opcode) L_W_V1_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_V1_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_V1_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_V1_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C1_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C1_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C1_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C1_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C2_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C2_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C2_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C2_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C3_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C3_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C3_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_C3_C3, "ld") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_2()
{
   
   el_opcode_to_symbol_map.bind((Opcode) LI_B_V1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_V1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_V1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_V1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C2_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C2_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C2_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C2_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C3_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C3_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C3_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_B_C3_C3, "ldi") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LI_H_V1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_V1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_V1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_V1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C2_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C2_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C2_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C2_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C3_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C3_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C3_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_H_C3_C3, "ldi") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LI_W_V1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_V1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_V1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_V1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C2_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C2_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C2_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C2_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C3_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C3_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C3_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) LI_W_C3_C3, "ldi") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_3()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FL_S_V1_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_V1_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_V1_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_V1_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C1_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C1_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C1_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C1_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C2_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C2_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C2_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C2_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C3_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C3_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C3_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_S_C3_C3, "ld") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FL_D_V1_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_V1_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_V1_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_V1_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C1_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C1_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C1_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C1_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C2_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C2_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C2_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C2_C3, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C3_V1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C3_C1, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C3_C2, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_C3_C3, "ld") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_V1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_V1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_V1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_V1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C2_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C2_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C2_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C2_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C3_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C3_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C3_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_S_C3_C3, "ldi") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_V1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_V1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_V1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_V1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C1_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C1_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C1_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C1_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C2_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C2_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C2_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C2_C3, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C3_V1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C3_C1, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C3_C2, "ldi");
   el_opcode_to_symbol_map.bind((Opcode) FLI_D_C3_C3, "ldi") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_4()
{
   
   el_opcode_to_symbol_map.bind((Opcode) S_B_V1, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_B_C1, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_B_C2, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_B_C3, "st") ;

   
   el_opcode_to_symbol_map.bind((Opcode) S_H_V1, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_H_C1, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_H_C2, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_H_C3, "st") ;

   
   el_opcode_to_symbol_map.bind((Opcode) S_W_V1, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_W_C1, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_W_C2, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_W_C3, "st") ;

   
   el_opcode_to_symbol_map.bind((Opcode) SI_B_V1, "sti");
   el_opcode_to_symbol_map.bind((Opcode) SI_B_C1, "sti");
   el_opcode_to_symbol_map.bind((Opcode) SI_B_C2, "sti");
   el_opcode_to_symbol_map.bind((Opcode) SI_B_C3, "sti") ;

   
   el_opcode_to_symbol_map.bind((Opcode) SI_H_V1, "sti");
   el_opcode_to_symbol_map.bind((Opcode) SI_H_C1, "sti");
   el_opcode_to_symbol_map.bind((Opcode) SI_H_C2, "sti");
   el_opcode_to_symbol_map.bind((Opcode) SI_H_C3, "sti") ;

   
   el_opcode_to_symbol_map.bind((Opcode) SI_W_V1, "sti");
   el_opcode_to_symbol_map.bind((Opcode) SI_W_C1, "sti");
   el_opcode_to_symbol_map.bind((Opcode) SI_W_C2, "sti");
   el_opcode_to_symbol_map.bind((Opcode) SI_W_C3, "sti") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FS_S_V1, "st");
   el_opcode_to_symbol_map.bind((Opcode) FS_S_C1, "st");
   el_opcode_to_symbol_map.bind((Opcode) FS_S_C2, "st");
   el_opcode_to_symbol_map.bind((Opcode) FS_S_C3, "st") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FS_D_V1, "st");
   el_opcode_to_symbol_map.bind((Opcode) FS_D_C1, "st");
   el_opcode_to_symbol_map.bind((Opcode) FS_D_C2, "st");
   el_opcode_to_symbol_map.bind((Opcode) FS_D_C3, "st") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FSI_S_V1, "FSI_S_V1");
   el_opcode_to_symbol_map.bind((Opcode) FSI_S_C1, "FSI_S_C1");
   el_opcode_to_symbol_map.bind((Opcode) FSI_S_C2, "FSI_S_C2");
   el_opcode_to_symbol_map.bind((Opcode) FSI_S_C3, "FSI_S_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FSI_D_V1, "FSI_D_V1");
   el_opcode_to_symbol_map.bind((Opcode) FSI_D_C1, "FSI_D_C1");
   el_opcode_to_symbol_map.bind((Opcode) FSI_D_C2, "FSI_D_C2");
   el_opcode_to_symbol_map.bind((Opcode) FSI_D_C3, "FSI_D_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_5()
{
   
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_V1_V1, "LDS_B_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_V1_C1, "LDS_B_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_V1_C2, "LDS_B_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_V1_C3, "LDS_B_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C1_V1, "LDS_B_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C1_C1, "LDS_B_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C1_C2, "LDS_B_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C1_C3, "LDS_B_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C2_V1, "LDS_B_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C2_C1, "LDS_B_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C2_C2, "LDS_B_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C2_C3, "LDS_B_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C3_V1, "LDS_B_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C3_C1, "LDS_B_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C3_C2, "LDS_B_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_B_C3_C3, "LDS_B_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_V1_V1, "LDS_H_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_V1_C1, "LDS_H_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_V1_C2, "LDS_H_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_V1_C3, "LDS_H_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C1_V1, "LDS_H_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C1_C1, "LDS_H_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C1_C2, "LDS_H_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C1_C3, "LDS_H_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C2_V1, "LDS_H_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C2_C1, "LDS_H_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C2_C2, "LDS_H_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C2_C3, "LDS_H_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C3_V1, "LDS_H_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C3_C1, "LDS_H_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C3_C2, "LDS_H_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_H_C3_C3, "LDS_H_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_V1_V1, "LDS_W_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_V1_C1, "LDS_W_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_V1_C2, "LDS_W_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_V1_C3, "LDS_W_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C1_V1, "LDS_W_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C1_C1, "LDS_W_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C1_C2, "LDS_W_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C1_C3, "LDS_W_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C2_V1, "LDS_W_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C2_C1, "LDS_W_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C2_C2, "LDS_W_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C2_C3, "LDS_W_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C3_V1, "LDS_W_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C3_C1, "LDS_W_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C3_C2, "LDS_W_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDS_W_C3_C3, "LDS_W_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_V1_V1, "LDSI_B_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_V1_C1, "LDSI_B_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_V1_C2, "LDSI_B_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_V1_C3, "LDSI_B_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C1_V1, "LDSI_B_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C1_C1, "LDSI_B_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C1_C2, "LDSI_B_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C1_C3, "LDSI_B_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C2_V1, "LDSI_B_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C2_C1, "LDSI_B_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C2_C2, "LDSI_B_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C2_C3, "LDSI_B_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C3_V1, "LDSI_B_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C3_C1, "LDSI_B_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C3_C2, "LDSI_B_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_B_C3_C3, "LDSI_B_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_V1_V1, "LDSI_H_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_V1_C1, "LDSI_H_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_V1_C2, "LDSI_H_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_V1_C3, "LDSI_H_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C1_V1, "LDSI_H_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C1_C1, "LDSI_H_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C1_C2, "LDSI_H_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C1_C3, "LDSI_H_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C2_V1, "LDSI_H_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C2_C1, "LDSI_H_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C2_C2, "LDSI_H_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C2_C3, "LDSI_H_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C3_V1, "LDSI_H_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C3_C1, "LDSI_H_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C3_C2, "LDSI_H_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_H_C3_C3, "LDSI_H_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_V1_V1, "LDSI_W_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_V1_C1, "LDSI_W_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_V1_C2, "LDSI_W_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_V1_C3, "LDSI_W_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C1_V1, "LDSI_W_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C1_C1, "LDSI_W_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C1_C2, "LDSI_W_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C1_C3, "LDSI_W_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C2_V1, "LDSI_W_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C2_C1, "LDSI_W_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C2_C2, "LDSI_W_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C2_C3, "LDSI_W_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C3_V1, "LDSI_W_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C3_C1, "LDSI_W_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C3_C2, "LDSI_W_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LDSI_W_C3_C3, "LDSI_W_C3_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_6()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_V1_V1, "FLDS_S_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_V1_C1, "FLDS_S_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_V1_C2, "FLDS_S_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_V1_C3, "FLDS_S_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C1_V1, "FLDS_S_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C1_C1, "FLDS_S_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C1_C2, "FLDS_S_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C1_C3, "FLDS_S_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C2_V1, "FLDS_S_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C2_C1, "FLDS_S_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C2_C2, "FLDS_S_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C2_C3, "FLDS_S_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C3_V1, "FLDS_S_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C3_C1, "FLDS_S_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C3_C2, "FLDS_S_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_S_C3_C3, "FLDS_S_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_V1_V1, "FLDS_D_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_V1_C1, "FLDS_D_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_V1_C2, "FLDS_D_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_V1_C3, "FLDS_D_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C1_V1, "FLDS_D_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C1_C1, "FLDS_D_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C1_C2, "FLDS_D_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C1_C3, "FLDS_D_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C2_V1, "FLDS_D_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C2_C1, "FLDS_D_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C2_C2, "FLDS_D_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C2_C3, "FLDS_D_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C3_V1, "FLDS_D_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C3_C1, "FLDS_D_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C3_C2, "FLDS_D_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDS_D_C3_C3, "FLDS_D_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_V1_V1, "FLDSI_S_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_V1_C1, "FLDSI_S_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_V1_C2, "FLDSI_S_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_V1_C3, "FLDSI_S_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C1_V1, "FLDSI_S_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C1_C1, "FLDSI_S_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C1_C2, "FLDSI_S_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C1_C3, "FLDSI_S_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C2_V1, "FLDSI_S_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C2_C1, "FLDSI_S_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C2_C2, "FLDSI_S_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C2_C3, "FLDSI_S_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C3_V1, "FLDSI_S_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C3_C1, "FLDSI_S_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C3_C2, "FLDSI_S_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_S_C3_C3, "FLDSI_S_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_V1_V1, "FLDSI_D_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_V1_C1, "FLDSI_D_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_V1_C2, "FLDSI_D_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_V1_C3, "FLDSI_D_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C1_V1, "FLDSI_D_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C1_C1, "FLDSI_D_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C1_C2, "FLDSI_D_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C1_C3, "FLDSI_D_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C2_V1, "FLDSI_D_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C2_C1, "FLDSI_D_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C2_C2, "FLDSI_D_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C2_C3, "FLDSI_D_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C3_V1, "FLDSI_D_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C3_C1, "FLDSI_D_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C3_C2, "FLDSI_D_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLDSI_D_C3_C3, "FLDSI_D_C3_C3") ;

   
   el_opcode_to_symbol_map.bind(LDV_B, "LDV_B");
   el_opcode_to_symbol_map.bind(LDV_H, "LDV_H");
   el_opcode_to_symbol_map.bind(LDV_W, "LDV_W") ;

   
   el_opcode_to_symbol_map.bind(FLDV_S, "FLDV_S");
   el_opcode_to_symbol_map.bind(FLDV_D, "FLDV_D") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_7()
{
   
   el_opcode_to_symbol_map.bind((Opcode) LX_B_V1_V1, "LX_B_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_V1_C1, "LX_B_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_V1_C2, "LX_B_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_V1_C3, "LX_B_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C1_V1, "LX_B_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C1_C1, "LX_B_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C1_C2, "LX_B_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C1_C3, "LX_B_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C2_V1, "LX_B_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C2_C1, "LX_B_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C2_C2, "LX_B_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C2_C3, "LX_B_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C3_V1, "LX_B_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C3_C1, "LX_B_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C3_C2, "LX_B_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_B_C3_C3, "LX_B_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LX_H_V1_V1, "LX_H_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_V1_C1, "LX_H_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_V1_C2, "LX_H_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_V1_C3, "LX_H_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C1_V1, "LX_H_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C1_C1, "LX_H_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C1_C2, "LX_H_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C1_C3, "LX_H_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C2_V1, "LX_H_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C2_C1, "LX_H_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C2_C2, "LX_H_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C2_C3, "LX_H_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C3_V1, "LX_H_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C3_C1, "LX_H_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C3_C2, "LX_H_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_H_C3_C3, "LX_H_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LX_W_V1_V1, "LX_W_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_V1_C1, "LX_W_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_V1_C2, "LX_W_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_V1_C3, "LX_W_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C1_V1, "LX_W_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C1_C1, "LX_W_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C1_C2, "LX_W_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C1_C3, "LX_W_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C2_V1, "LX_W_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C2_C1, "LX_W_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C2_C2, "LX_W_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C2_C3, "LX_W_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C3_V1, "LX_W_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C3_C1, "LX_W_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C3_C2, "LX_W_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LX_W_C3_C3, "LX_W_C3_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_8()
{
   
   el_opcode_to_symbol_map.bind((Opcode) LG_B_V1_V1, "LG_B_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_V1_C1, "LG_B_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_V1_C2, "LG_B_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_V1_C3, "LG_B_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C1_V1, "LG_B_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C1_C1, "LG_B_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C1_C2, "LG_B_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C1_C3, "LG_B_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C2_V1, "LG_B_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C2_C1, "LG_B_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C2_C2, "LG_B_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C2_C3, "LG_B_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C3_V1, "LG_B_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C3_C1, "LG_B_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C3_C2, "LG_B_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_B_C3_C3, "LG_B_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LG_H_V1_V1, "LG_H_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_V1_C1, "LG_H_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_V1_C2, "LG_H_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_V1_C3, "LG_H_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C1_V1, "LG_H_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C1_C1, "LG_H_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C1_C2, "LG_H_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C1_C3, "LG_H_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C2_V1, "LG_H_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C2_C1, "LG_H_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C2_C2, "LG_H_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C2_C3, "LG_H_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C3_V1, "LG_H_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C3_C1, "LG_H_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C3_C2, "LG_H_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_H_C3_C3, "LG_H_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LG_W_V1_V1, "LG_W_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_V1_C1, "LG_W_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_V1_C2, "LG_W_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_V1_C3, "LG_W_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C1_V1, "LG_W_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C1_C1, "LG_W_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C1_C2, "LG_W_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C1_C3, "LG_W_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C2_V1, "LG_W_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C2_C1, "LG_W_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C2_C2, "LG_W_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C2_C3, "LG_W_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C3_V1, "LG_W_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C3_C1, "LG_W_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C3_C2, "LG_W_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LG_W_C3_C3, "LG_W_C3_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_9()
{
   
   el_opcode_to_symbol_map.bind((Opcode) LM_B_V1_V1, "LM_B_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_V1_C1, "LM_B_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_V1_C2, "LM_B_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_V1_C3, "LM_B_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C1_V1, "LM_B_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C1_C1, "LM_B_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C1_C2, "LM_B_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C1_C3, "LM_B_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C2_V1, "LM_B_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C2_C1, "LM_B_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C2_C2, "LM_B_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C2_C3, "LM_B_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C3_V1, "LM_B_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C3_C1, "LM_B_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C3_C2, "LM_B_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_B_C3_C3, "LM_B_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LM_H_V1_V1, "LM_H_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_V1_C1, "LM_H_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_V1_C2, "LM_H_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_V1_C3, "LM_H_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C1_V1, "LM_H_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C1_C1, "LM_H_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C1_C2, "LM_H_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C1_C3, "LM_H_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C2_V1, "LM_H_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C2_C1, "LM_H_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C2_C2, "LM_H_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C2_C3, "LM_H_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C3_V1, "LM_H_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C3_C1, "LM_H_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C3_C2, "LM_H_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_H_C3_C3, "LM_H_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LM_W_V1_V1, "LM_W_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_V1_C1, "LM_W_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_V1_C2, "LM_W_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_V1_C3, "LM_W_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C1_V1, "LM_W_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C1_C1, "LM_W_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C1_C2, "LM_W_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C1_C3, "LM_W_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C2_V1, "LM_W_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C2_C1, "LM_W_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C2_C2, "LM_W_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C2_C3, "LM_W_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C3_V1, "LM_W_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C3_C1, "LM_W_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C3_C2, "LM_W_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LM_W_C3_C3, "LM_W_C3_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_10()
{
   
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_V1_V1, "LGX_B_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_V1_C1, "LGX_B_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_V1_C2, "LGX_B_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_V1_C3, "LGX_B_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C1_V1, "LGX_B_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C1_C1, "LGX_B_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C1_C2, "LGX_B_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C1_C3, "LGX_B_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C2_V1, "LGX_B_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C2_C1, "LGX_B_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C2_C2, "LGX_B_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C2_C3, "LGX_B_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C3_V1, "LGX_B_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C3_C1, "LGX_B_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C3_C2, "LGX_B_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_B_C3_C3, "LGX_B_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_V1_V1, "LGX_H_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_V1_C1, "LGX_H_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_V1_C2, "LGX_H_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_V1_C3, "LGX_H_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C1_V1, "LGX_H_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C1_C1, "LGX_H_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C1_C2, "LGX_H_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C1_C3, "LGX_H_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C2_V1, "LGX_H_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C2_C1, "LGX_H_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C2_C2, "LGX_H_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C2_C3, "LGX_H_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C3_V1, "LGX_H_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C3_C1, "LGX_H_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C3_C2, "LGX_H_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_H_C3_C3, "LGX_H_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_V1_V1, "LGX_W_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_V1_C1, "LGX_W_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_V1_C2, "LGX_W_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_V1_C3, "LGX_W_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C1_V1, "LGX_W_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C1_C1, "LGX_W_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C1_C2, "LGX_W_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C1_C3, "LGX_W_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C2_V1, "LGX_W_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C2_C1, "LGX_W_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C2_C2, "LGX_W_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C2_C3, "LGX_W_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C3_V1, "LGX_W_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C3_C1, "LGX_W_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C3_C2, "LGX_W_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LGX_W_C3_C3, "LGX_W_C3_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_11()
{
   
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_V1_V1, "LMX_B_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_V1_C1, "LMX_B_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_V1_C2, "LMX_B_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_V1_C3, "LMX_B_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C1_V1, "LMX_B_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C1_C1, "LMX_B_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C1_C2, "LMX_B_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C1_C3, "LMX_B_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C2_V1, "LMX_B_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C2_C1, "LMX_B_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C2_C2, "LMX_B_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C2_C3, "LMX_B_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C3_V1, "LMX_B_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C3_C1, "LMX_B_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C3_C2, "LMX_B_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_B_C3_C3, "LMX_B_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_V1_V1, "LMX_H_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_V1_C1, "LMX_H_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_V1_C2, "LMX_H_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_V1_C3, "LMX_H_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C1_V1, "LMX_H_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C1_C1, "LMX_H_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C1_C2, "LMX_H_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C1_C3, "LMX_H_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C2_V1, "LMX_H_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C2_C1, "LMX_H_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C2_C2, "LMX_H_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C2_C3, "LMX_H_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C3_V1, "LMX_H_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C3_C1, "LMX_H_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C3_C2, "LMX_H_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_H_C3_C3, "LMX_H_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_V1_V1, "LMX_W_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_V1_C1, "LMX_W_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_V1_C2, "LMX_W_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_V1_C3, "LMX_W_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C1_V1, "LMX_W_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C1_C1, "LMX_W_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C1_C2, "LMX_W_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C1_C3, "LMX_W_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C2_V1, "LMX_W_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C2_C1, "LMX_W_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C2_C2, "LMX_W_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C2_C3, "LMX_W_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C3_V1, "LMX_W_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C3_C1, "LMX_W_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C3_C2, "LMX_W_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) LMX_W_C3_C3, "LMX_W_C3_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_12()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_V1_V1, "FLG_S_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_V1_C1, "FLG_S_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_V1_C2, "FLG_S_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_V1_C3, "FLG_S_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C1_V1, "FLG_S_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C1_C1, "FLG_S_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C1_C2, "FLG_S_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C1_C3, "FLG_S_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C2_V1, "FLG_S_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C2_C1, "FLG_S_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C2_C2, "FLG_S_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C2_C3, "FLG_S_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C3_V1, "FLG_S_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C3_C1, "FLG_S_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C3_C2, "FLG_S_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLG_S_C3_C3, "FLG_S_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_V1_V1, "FLG_D_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_V1_C1, "FLG_D_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_V1_C2, "FLG_D_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_V1_C3, "FLG_D_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C1_V1, "FLG_D_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C1_C1, "FLG_D_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C1_C2, "FLG_D_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C1_C3, "FLG_D_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C2_V1, "FLG_D_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C2_C1, "FLG_D_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C2_C2, "FLG_D_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C2_C3, "FLG_D_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C3_V1, "FLG_D_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C3_C1, "FLG_D_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C3_C2, "FLG_D_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLG_D_C3_C3, "FLG_D_C3_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_13()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_V1_V1, "FLM_S_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_V1_C1, "FLM_S_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_V1_C2, "FLM_S_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_V1_C3, "FLM_S_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C1_V1, "FLM_S_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C1_C1, "FLM_S_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C1_C2, "FLM_S_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C1_C3, "FLM_S_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C2_V1, "FLM_S_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C2_C1, "FLM_S_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C2_C2, "FLM_S_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C2_C3, "FLM_S_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C3_V1, "FLM_S_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C3_C1, "FLM_S_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C3_C2, "FLM_S_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLM_S_C3_C3, "FLM_S_C3_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_V1_V1, "FLM_D_V1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_V1_C1, "FLM_D_V1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_V1_C2, "FLM_D_V1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_V1_C3, "FLM_D_V1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C1_V1, "FLM_D_C1_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C1_C1, "FLM_D_C1_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C1_C2, "FLM_D_C1_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C1_C3, "FLM_D_C1_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C2_V1, "FLM_D_C2_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C2_C1, "FLM_D_C2_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C2_C2, "FLM_D_C2_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C2_C3, "FLM_D_C2_C3");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C3_V1, "FLM_D_C3_V1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C3_C1, "FLM_D_C3_C1");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C3_C2, "FLM_D_C3_C2");
   el_opcode_to_symbol_map.bind((Opcode) FLM_D_C3_C3, "FLM_D_C3_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_14()
{
   
   el_opcode_to_symbol_map.bind((Opcode) SG_B_V1, "SG_B_V1");
   el_opcode_to_symbol_map.bind((Opcode) SG_B_C1, "SG_B_C1");
   el_opcode_to_symbol_map.bind((Opcode) SG_B_C2, "SG_B_C2");
   el_opcode_to_symbol_map.bind((Opcode) SG_B_C3, "SG_B_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) SG_H_V1, "SG_H_V1");
   el_opcode_to_symbol_map.bind((Opcode) SG_H_C1, "SG_H_C1");
   el_opcode_to_symbol_map.bind((Opcode) SG_H_C2, "SG_H_C2");
   el_opcode_to_symbol_map.bind((Opcode) SG_H_C3, "SG_H_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) SG_W_V1, "SG_W_V1");
   el_opcode_to_symbol_map.bind((Opcode) SG_W_C1, "SG_W_C1");
   el_opcode_to_symbol_map.bind((Opcode) SG_W_C2, "SG_W_C2");
   el_opcode_to_symbol_map.bind((Opcode) SG_W_C3, "SG_W_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_15()
{
   
   el_opcode_to_symbol_map.bind((Opcode) SM_B_V1, "SM_B_V1");
   el_opcode_to_symbol_map.bind((Opcode) SM_B_C1, "SM_B_C1");
   el_opcode_to_symbol_map.bind((Opcode) SM_B_C2, "SM_B_C2");
   el_opcode_to_symbol_map.bind((Opcode) SM_B_C3, "SM_B_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) SM_H_V1, "SM_H_V1");
   el_opcode_to_symbol_map.bind((Opcode) SM_H_C1, "SM_H_C1");
   el_opcode_to_symbol_map.bind((Opcode) SM_H_C2, "SM_H_C2");
   el_opcode_to_symbol_map.bind((Opcode) SM_H_C3, "SM_H_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) SM_W_V1, "SM_W_V1");
   el_opcode_to_symbol_map.bind((Opcode) SM_W_C1, "SM_W_C1");
   el_opcode_to_symbol_map.bind((Opcode) SM_W_C2, "SM_W_C2");
   el_opcode_to_symbol_map.bind((Opcode) SM_W_C3, "SM_W_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_16()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FSG_S_V1, "FSG_S_V1");
   el_opcode_to_symbol_map.bind((Opcode) FSG_S_C1, "FSG_S_C1");
   el_opcode_to_symbol_map.bind((Opcode) FSG_S_C2, "FSG_S_C2");
   el_opcode_to_symbol_map.bind((Opcode) FSG_S_C3, "FSG_S_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FSG_D_V1, "FSG_D_V1");
   el_opcode_to_symbol_map.bind((Opcode) FSG_D_C1, "FSG_D_C1");
   el_opcode_to_symbol_map.bind((Opcode) FSG_D_C2, "FSG_D_C2");
   el_opcode_to_symbol_map.bind((Opcode) FSG_D_C3, "FSG_D_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_17()
{
   
   el_opcode_to_symbol_map.bind((Opcode) FSM_S_V1, "FSM_S_V1");
   el_opcode_to_symbol_map.bind((Opcode) FSM_S_C1, "FSM_S_C1");
   el_opcode_to_symbol_map.bind((Opcode) FSM_S_C2, "FSM_S_C2");
   el_opcode_to_symbol_map.bind((Opcode) FSM_S_C3, "FSM_S_C3") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FSM_D_V1, "FSM_D_V1");
   el_opcode_to_symbol_map.bind((Opcode) FSM_D_C1, "FSM_D_C1");
   el_opcode_to_symbol_map.bind((Opcode) FSM_D_C2, "FSM_D_C2");
   el_opcode_to_symbol_map.bind((Opcode) FSM_D_C3, "FSM_D_C3") ;
}

void el_init_elcor_opcode_to_symbol_maps_memory_18()
{
  /*   
   el_opcode_to_symbol_map.bind((Opcode) L_B_LM, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_H_LM, "ld");
   el_opcode_to_symbol_map.bind((Opcode) L_W_LM, "ld") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FL_S_LM, "ld");
   el_opcode_to_symbol_map.bind((Opcode) FL_D_LM, "ld") ;

   
   el_opcode_to_symbol_map.bind((Opcode) S_B_LM, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_H_LM, "st");
   el_opcode_to_symbol_map.bind((Opcode) S_W_LM, "st") ;

   
   el_opcode_to_symbol_map.bind((Opcode) FS_S_LM, "st");
   el_opcode_to_symbol_map.bind((Opcode) FS_D_LM, "st") ;
  */
}

void el_init_elcor_opcode_to_symbol_maps_memory_19() 
{

   el_opcode_to_symbol_map.bind((Opcode) SAVE, "save") ;
   el_opcode_to_symbol_map.bind((Opcode) RESTORE, "restore") ;
   el_opcode_to_symbol_map.bind((Opcode) FSAVE, "fasve") ;
   el_opcode_to_symbol_map.bind((Opcode) FRESTORE, "frestore") ;
   el_opcode_to_symbol_map.bind((Opcode) BSAVE, "bsave") ;
   el_opcode_to_symbol_map.bind((Opcode) BRESTORE, "brestore") ;

}

void el_init_elcor_opcode_to_symbol_maps_memory()
{
  el_init_elcor_opcode_to_symbol_maps_memory_1() ;  // l
  el_init_elcor_opcode_to_symbol_maps_memory_2() ;  // li
  el_init_elcor_opcode_to_symbol_maps_memory_3() ;  // fl/fli
  el_init_elcor_opcode_to_symbol_maps_memory_4() ;  // s/fs
  el_init_elcor_opcode_to_symbol_maps_memory_5() ;  // lds/ldsi
  el_init_elcor_opcode_to_symbol_maps_memory_6() ;  // flds/fldsi/ldv/fldv
  el_init_elcor_opcode_to_symbol_maps_memory_7() ;  // lx
  el_init_elcor_opcode_to_symbol_maps_memory_8() ;  // lg
  el_init_elcor_opcode_to_symbol_maps_memory_9() ;  // lm
  el_init_elcor_opcode_to_symbol_maps_memory_10() ; // lgx
  el_init_elcor_opcode_to_symbol_maps_memory_11() ; // lmx
  el_init_elcor_opcode_to_symbol_maps_memory_12() ; // flg
  el_init_elcor_opcode_to_symbol_maps_memory_13() ; // flm
  el_init_elcor_opcode_to_symbol_maps_memory_14() ; // sg
  el_init_elcor_opcode_to_symbol_maps_memory_15() ; // sm
  el_init_elcor_opcode_to_symbol_maps_memory_16() ; // fsg
  el_init_elcor_opcode_to_symbol_maps_memory_17() ; // fsm
  el_init_elcor_opcode_to_symbol_maps_memory_18() ; // local memory
  el_init_elcor_opcode_to_symbol_maps_memory_19() ; // non-speculative ld/st
}

void el_init_elcor_opcode_to_symbol_maps_misc()
{
   
   el_opcode_to_symbol_map.bind(BRDVI, "brdvi");
   el_opcode_to_symbol_map.bind(BRDVF, "brdvf");// long literal generation
   
   el_opcode_to_symbol_map.bind(MOVELG, "movelg");
   el_opcode_to_symbol_map.bind(MOVELGS, "movelgs");// branch literal generation
   
   el_opcode_to_symbol_map.bind(MOVELB, "MOVELB");
   el_opcode_to_symbol_map.bind(MOVELBS, "MOVELBS");
   el_opcode_to_symbol_map.bind(PBRRLBS, "PBRRLBS");
   el_opcode_to_symbol_map.bind(PBRALBS, "PBRALBS") ;

   
   el_opcode_to_symbol_map.bind(PBRR, "pbrr");
   el_opcode_to_symbol_map.bind(PBRA, "pbra");
   el_opcode_to_symbol_map.bind(BRU, "bru");
   el_opcode_to_symbol_map.bind(BRCT, "brct");
   el_opcode_to_symbol_map.bind(BRCF, "brcf");
   el_opcode_to_symbol_map.bind(BRL, "brl");
   el_opcode_to_symbol_map.bind(BRLC, "brlc");
   el_opcode_to_symbol_map.bind(RTS, "rts");
   el_opcode_to_symbol_map.bind(BRDIR, "brdir");
   el_opcode_to_symbol_map.bind(BRIND, "brind");
   el_opcode_to_symbol_map.bind(BRF_B_B_F, "brf_B_B_F");
   el_opcode_to_symbol_map.bind(BRF_B_F_F, "brf_B_F_F");
   el_opcode_to_symbol_map.bind(BRF_F_B_B, "brf_F_B_B");
   el_opcode_to_symbol_map.bind(BRF_F_F_B, "brf_F_F_B");
   el_opcode_to_symbol_map.bind(BRF_F_F_F, "brf_F_F_F");
   el_opcode_to_symbol_map.bind(BRW_B_B_F, "brw_B_B_F");
   el_opcode_to_symbol_map.bind(BRW_B_F_F, "brw_B_F_F");
   el_opcode_to_symbol_map.bind(BRW_F_B_B, "brw_F_B_B");
   el_opcode_to_symbol_map.bind(BRW_F_F_B, "brw_F_F_B");
   el_opcode_to_symbol_map.bind(BRW_F_F_F, "brw_F_F_F") ;

   
   el_opcode_to_symbol_map.bind(PROLOGUE, "prologue");
   el_opcode_to_symbol_map.bind(EPILOGUE, "epilogue");
   el_opcode_to_symbol_map.bind(DEFINE, "define");
   el_opcode_to_symbol_map.bind(ALLOC, "alloc");
   el_opcode_to_symbol_map.bind(SIM_DIR, "sim-dir") ;

   
   el_opcode_to_symbol_map.bind(DUMMY_BR, "dummy_br");
   el_opcode_to_symbol_map.bind(C_MERGE, "cmerge");
   el_opcode_to_symbol_map.bind(D_SWITCH, "dswitch");
   el_opcode_to_symbol_map.bind(D_MERGE, "dmerge") ;

   
   el_opcode_to_symbol_map.bind(USE, "use");
   el_opcode_to_symbol_map.bind(DEF, "def") ;

   
   el_opcode_to_symbol_map.bind(REMAP, "remap") ;

   
   el_opcode_to_symbol_map.bind(PRED_CLEAR, "pred-clear");
   el_opcode_to_symbol_map.bind(PRED_CLEAR_ALL, "pred-ca");
   el_opcode_to_symbol_map.bind(PRED_CLEAR_ALL_STATIC, "pred-cas");
   el_opcode_to_symbol_map.bind(PRED_CLEAR_ALL_ROTATING, "pred-car");
   el_opcode_to_symbol_map.bind(PRED_SET, "pred-set");
   el_opcode_to_symbol_map.bind(PRED_AND, "pred-and");
   el_opcode_to_symbol_map.bind(PRED_COMPL, "pred-compl");
   el_opcode_to_symbol_map.bind(PRED_LOAD_ALL, "pred-la");
   el_opcode_to_symbol_map.bind(PRED_STORE_ALL, "pred-sa") ;

}

void el_init_elcor_base_opcode_to_symbol_maps()
{
   // add opcode-to-string mapping for base opcodes

   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_FALSE, "BASE_CMPP_W_FALSE");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_EQ, "BASE_CMPP_W_EQ");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_LT, "BASE_CMPP_W_LT");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_LEQ, "BASE_CMPP_W_LEQ");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_GT, "BASE_CMPP_W_GT");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_GEQ, "BASE_CMPP_W_GEQ");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_SV, "BASE_CMPP_W_SV");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_OD, "BASE_CMPP_W_OD");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_TRUE , "BASE_CMPP_W_TRUE");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_NEQ, "BASE_CMPP_W_NEQ");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_LLT, "BASE_CMPP_W_LLT");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_LLEQ , "BASE_CMPP_W_LLEQ");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_LGT, "BASE_CMPP_W_LGT");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_LGEQ , "BASE_CMPP_W_LGEQ");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_NSV, "BASE_CMPP_W_NSV");
   el_base_opcode_to_symbol_map.bind(BASE_CMPP_W_EV, "BASE_CMPP_W_EV");

   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_S_FALSE,"BASE_FCMPP_S_FALSE");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_S_EQ, "BASE_FCMPP_S_EQ");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_S_LT, "BASE_FCMPP_S_LT");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_S_LEQ, "BASE_FCMPP_S_LEQ");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_S_GT, "BASE_FCMPP_S_GT");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_S_GEQ, "BASE_FCMPP_S_GEQ");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_S_NEQ, "BASE_FCMPP_S_NEQ");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_S_TRUE, "BASE_FCMPP_S_TRUE");

   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_D_FALSE,"BASE_FCMPP_D_FALSE");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_D_EQ, "BASE_FCMPP_D_EQ");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_D_LT, "BASE_FCMPP_D_LT");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_D_LEQ, "BASE_FCMPP_D_LEQ");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_D_GT, "BASE_FCMPP_D_GT");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_D_GEQ, "BASE_FCMPP_D_GEQ");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_D_NEQ, "BASE_FCMPP_D_NEQ");
   el_base_opcode_to_symbol_map.bind(BASE_FCMPP_D_TRUE, "BASE_FCMPP_D_TRUE");
}

//////////////////////////////////////////////////////////////////////////




//---------------------------------------------------------------
//         operand -> pseudo-assembly -> gdl translator
//---------------------------------------------------------------
IR_outstream&  
operand_to_asm_to_gdl(IR_outstream &out, Operand &oper)
{

  char buf[512];

  // Write out an operand;
  Operand &op = oper;
    
  const Base_operand& operand = *op.get_ptr(); //sptr->optr ;
  if (operand.is_int())
    out << ((const Int_lit&) operand).value();
  else if (operand.is_predicate()) {
    if (!((const Pred_lit&) operand).value())
      out << 'f';
    //out << (((const Pred_lit&) operand).value() ? 't' : 'f') ;
  } else if (operand.is_float())
    out	<< ((const Float_lit&) operand).value();
  else if (operand.is_double())
    out	<< ((const Double_lit&) operand).value();
  else if (operand.is_string()) {
    sprintf(buf, "%s" , (char*)((const String_lit&)operand).value());
    int len = strlen(buf);
    buf[len-1]  = '\0';
    out << (char*)(buf+1);
  } else if (operand.is_label())
    out << (char*)((const Label_lit&)operand).value();
  else if (operand.is_cb()) {
    sprintf(buf, "BB%d", (int)((const Cb_operand&) operand).id());
    out << buf;
  } else if (operand.is_undefined()) {
    //out << UNDEFINED_OPERAND_STRING << L_ANGLE << R_ANGLE;
  } else if (operand.is_macro_reg()) {
    const Macro_reg &reg = (const Macro_reg&) operand;
    out << gMacroNames[(int)reg.name()] ;
    //out << MACRO_OPERAND_STRING << L_ANGLE << reg.name() << R_ANGLE;
  } else if (operand.is_reg()) {
    const Reg &reg = (const Reg&) operand;
    
    if (reg.file_type() == PR){
      if (reg.assigned_to_file() && reg.allocated()) {
	if (reg.is_rotating()) {
	  sprintf(buf, "p[%d]", reg.mc_num());
	} else {
	  sprintf(buf, "p%d", reg.mc_num());
	}
	out << buf;
      }
      else if (reg.assigned_to_file() && !reg.allocated()) {
	if (reg.is_rotating())
	  sprintf(buf, "p[%d]", reg.vr_num());
	else
	  sprintf(buf, "p%d", reg.vr_num());
	out << buf;
      }
      else
	out << "-";
    } else {
      if (reg.assigned_to_file() && reg.allocated()) {
	if (reg.is_rotating()) {
	  sprintf(buf, "r[%d]", reg.mc_num());
	} else {
	  sprintf(buf, "r%d", reg.mc_num());
	}
	out << buf;
      }
      else if (reg.assigned_to_file() && !reg.allocated()) {
	if (reg.is_rotating())
	  sprintf(buf, "r[%d]", reg.vr_num());
	else
	  sprintf(buf, "r%d", reg.vr_num());
	out << buf;
      }
      else
	out << "-";
    }
  } else if (operand.is_mem_vr()) {
    const Mem_vr &reg = (const Mem_vr&) operand;
    out << MEMVR_OPERAND_STRING << L_ANGLE << reg.vr_num();
    if (reg.omega() != 0)  out << L_BRACKET << reg.omega() << R_BRACKET;
    out << R_ANGLE;
  } else if (operand.is_vr_name()) {
    const VR_name &reg = (const VR_name&) operand;
    out << VR_NAME_OPERAND_STRING << L_ANGLE << reg.vr_num() <<
      COLON << reg.data_type() << R_ANGLE;
  } else {
    cerr << "unknown operand type" << endl;
    exit(1);
  }
  return out;
}



//---------------------------------------------------------------
//         operand -> pseudo-assembly -> gdl -> buf translator
//---------------------------------------------------------------
char* 
operand_to_asm_to_gdl_buf(IR_outstream &out, Operand &oper, char* buf)
{

  Operand &op = oper;
  char temp_buf[128];

  const Base_operand& operand = *op.get_ptr(); //sptr->optr ;
  if (operand.is_int()) {
    sprintf(buf, "%d", ((const Int_lit&) operand).value());
  } else if (operand.is_predicate()) {
    if (!((const Pred_lit&) operand).value())
      sprintf(buf, "f");
  } else if (operand.is_float()) {
    sprintf(buf, "%g", ((const Float_lit&) operand).value());
  } else if (operand.is_double()) {
    sprintf(buf, "%gl", ((const Double_lit&) operand).value());
  } else if (operand.is_string()) {
    sprintf(temp_buf, "%s" , (char*)((const String_lit&)operand).value());
    int len = strlen(temp_buf);
    temp_buf[len-1]  = '\0';
    sprintf(buf, "%s" , (temp_buf + 1));
  } else if (operand.is_label()) {
    sprintf(buf, "%s" , (char*)((const Label_lit&)operand).value());
  } else if (operand.is_cb()) {
    sprintf(buf, "BB%d", (int)((const Cb_operand&) operand).id());
  } else if (operand.is_undefined()) {
    sprintf(buf, "u");
  } else if (operand.is_macro_reg()) {
    const Macro_reg &reg = (const Macro_reg&) operand;
    sprintf(buf, "%s" , gMacroNames[(int)reg.name()]);
  } else if (operand.is_reg()) {
    const Reg &reg = (const Reg&) operand;
    if (reg.file_type() == PR){
      if (reg.assigned_to_file() && reg.allocated()) {
	if (reg.is_rotating()) {
	  sprintf(buf, "p%d[%d,%d]", reg.mc_num(), reg.vr_num(), reg.omega());
	} else {
	  sprintf(buf, "p%d", reg.mc_num());
	}
      }
      else if (reg.assigned_to_file() && !reg.allocated()) {
	if (reg.is_rotating())
	  sprintf(buf, "p[%d]", reg.vr_num());
	else
	  sprintf(buf, "p%d", reg.vr_num());
      }
    } else {
      if (reg.assigned_to_file() && reg.allocated()) {
	if (reg.is_rotating()) {
	  sprintf(buf, "r%d[%d,%d]", reg.mc_num(), reg.vr_num(), reg.omega());
	} else {
	  sprintf(buf, "r%d", reg.mc_num());
	}
      }
      else if (reg.assigned_to_file() && !reg.allocated()) {
	if (reg.is_rotating())
	  sprintf(buf, "r[%d]", reg.vr_num());
	else
	  sprintf(buf, "r%d", reg.vr_num());
      }
    }
  } else if (operand.is_mem_vr()) {
    const Mem_vr &reg = (const Mem_vr&) operand;
    if (reg.omega() != 0)
      sprintf(buf, "mvr%d(%d)", reg.vr_num(), reg.omega());
    else
      sprintf(buf, "mvr%d", reg.vr_num());
  } else if (operand.is_vr_name()) {
    const VR_name &reg = (const VR_name&) operand;
    sprintf(buf, "r%d", reg.vr_num());
  } else {
    cerr << "unknown operand type" << endl;
    exit(1);
  }
  return buf;
}


//--------------------------------------------------------------------

