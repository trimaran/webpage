/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   rv_resources.h (Resource file for ir-viewer)
// Author: Suren Talla
///////////////////////////////////////////////////////////////////////////////

#ifndef _RV_RESOURCES_H_
#define _RV_RESOURCES_H_



//------------------------------------------------------------
//  GDL COLORS ::
//------------------------------------------------------------
/*
  0,  //white      
  1,  //blue  
  2,  //red  
  3,  //green  
  4,  //yellow  
  5,  //magenta 
  6,  //cyan  
  7,  //darkgrey 
  8,  //darkblue 
  9,  //darkred  
  10, //darkgreen
  11, //darkyellow  
  12, //darkmagenta 
  13, //darkcyan  
  14, //gold  
  15, //lightgrey  
  16, //lightblue   
  17, //lightred  
  18, //lightgreen
  19, //lightyellow
  20, //lightmagenta
  21, //lightcyan 
  22, //lilac  
  23, //turquoise  
  24, //aquamarine 
  25, //khaki   
  26, //purple  
  27, //yellowgreen  
  28, //pink  
  29, //orange
  30, //orchid
  31  //black 

  */





//------------------------------------------------------------
//   OPCODE CLASSES AND THEIR COLOR CODES
//------------------------------------------------------------
#define NOOP            0
#define PSEUDO_OP       31
#define MEM_OP          16     //lightblue
#define IALU_OP         17     //lightred
#define CMPP_OP         18     //lightgreen
#define FALU_OP         19     //lightyellow
#define PBR_OP          20     //lightmagenta
#define SWITCH_OP       21     //lightcyan
#define PRED_OPS        15     //dark grey


//------------------------------------------------------------
//  POSITIONING COSTS FOR PLOTTING CYCLE-BY-CYCLE SCHEDULE 
//------------------------------------------------------------
#define NODE_Y_SEP           30
#define NODE_BIG_X_SEP       800
#define NODE_SMALL_X_SEP     100
#define NODE_ASM_X_SEP       550
#define NO_OP_INFO_WIDTH     70
#define OP_INFO_WIDTH        700
#define OP_INFO_ASM_WIDTH    500


//------------------------------------------------------------
//  COLORS FOR EDGE CLASSES (IN DDG)
//------------------------------------------------------------
#define SEQ_EDGE_COLOR         6
#define CONTROL0_EDGE_COLOR    6     //control0 is same as seq;
#define CONTROL1_EDGE_COLOR    29     
#define FLOW_EDGE_COLOR        2
#define ANTI_EDGE_COLOR        1
#define OUTPUT_EDGE_COLOR      3
#define MEM_EDGE_COLOR         4
#define TIMELINE_EDGE_COLOR    26
#define DEFAULT_EDGE_COLOR     31

//------------------------------------------------------------
//  CONSTS FOR EDGE CLASSES
//------------------------------------------------------------
#define SEQ_EDGES              0
#define CONTROL0_EDGES         0     //control0 is same as seq;
#define CONTROL1_EDGES         1
#define FLOW_EDGES             2
#define ANTI_EDGES             3
#define OUTPUT_EDGES           4
#define MEM_EDGES              5
#define TIMELINE_EDGES         6
#define DEFAULT_EGDES          7


#define DEST_OPERS_LEN    16
#define SRC_OPERS_LEN     36


//------------------------------------------------------------
// color temperature 
//------------------------------------------------------------
#define NUM_COLOR_RANGES  23

//------------------------------------------------------------
//  LABELS DENOTING DIFFERENT TYPES OF REGIONS
//------------------------------------------------------------
#define BB_REGION      "BB"
#define HB_REGION      "HB"
#define PROC_REGION    "PR"
#define LOOP_REGION    "LR"
#define COMP_REGION    "CR"
#define OP_REGION      "OP"

//------------------------------------------------------------

#define OP_INFO_SHORT_FORM    0
#define OP_INFO_LONG_FORM     1
#define OP_INFO_ASM_FORM      2


  
#endif  //_RV_RESOURCES_H_
