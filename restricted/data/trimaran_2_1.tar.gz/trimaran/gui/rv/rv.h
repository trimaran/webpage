/******************************************************************************
LICENSE NOTICE
--------------

IT IS A BREACH OF THE LICENSE AGREEMENT TO REMOVE THIS NOTICE FROM 
THIS FILE OR SOFTWARE OR ANY MODIFIED VERSIONS OF THIS FILE OR SOFTWARE.

Copyright notices/Licensor(s) Identification
--------------------------------------------
Each of the entity(ies) whose name properly appear immediately below in 
connection with a copyright notice is a Licensor(s) under the terms that 
follow.

Copyright 1998 New York University. All rights reserved by the foregoing, 
respectively.


License agreement
-----------------

The code contained in this file including both binary and source (hereafter, 
Software) is subject to copyright by Licensor(s) and ownership remains with
Licensor(s).

Licensor(s) grants you (hereafter, Licensee) a license to use the Software for 
academic, research and internal business purposes only, without a fee. 
"Internal business use" means that Licensee may install, use and execute the 
Software for the purpose of designing and evaluating products.  Licensee may 
also disclose results obtained by executing the Software, as well as algorithms
embodied therein.  Licensee may distribute the Software to third parties 
provided that the copyright notice and this statement appears on all 
copies and that no charge is associated with such copies.  
No patent or other intellectual property license is granted or implied by this
Agreement, and this Agreement does not license any acts except those expressly
recited.

Licensee may make derivative works, which shall also be governed by the terms 
of this License Agreement. If Licensee distributes any derivative work based 
on or derived from the Software, then Licensee will abide by the following 
terms.  Both Licensee and Licensor(s) will be considered joint owners of such
derivative work and considered Licensor(s) for the purpose of distribution of
such derivative work.  Licensee shall not modify this agreement except that 
Licensee shall clearly indicate that this is a derivative work by adding an 
additional copyright notice in the form "Copyright <year> <Owner>" to other 
copyright notices above, before the line "All rights reserved by the foregoing,
respectively".  A party who is not an original author of such derivative works
within the meaning of US Copyright Law shall not modify or add his name to the
copyright notices above.

Any Licensee wishing to make commercial use of the Software should contact 
each and every Licensor(s) to negotiate an appropriate license for such 
commercial use; permission of all Licensor(s) will be required for such a 
license.  Commercial use includes (1) integration of all or part of the source
code into a product for sale or license by or on behalf of Licensee to third 
parties, or (2) distribution of the Software to third parties that need it to
utilize a commercial product sold or licensed by or on behalf of Licensee.

LICENSOR (S) MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS SOFTWARE 
FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. 
LICENSOR (S) SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY THE USERS OF THIS
SOFTWARE.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY
COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE 
PROGRAM AS PERMITTED ABOVE, BE LIABLE FOR DAMAGES, INCLUDING ANY GENERAL, 
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR 
DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES 
OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH
HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

By using or copying this Software, Licensee agrees to abide by the copyright 
law and all other applicable laws of the U.S., and the terms of this license 
agreement. Any individual Licensor shall have the right to terminate this 
license immediately by written notice upon Licensee's breach of, or 
non-compliance with, any of its terms. Licensee may be held legally 
responsible for any copyright infringement that is caused or encouraged by 
Licensee's failure to abide by the terms of this license agreement.
******************************************************************************/

///////////////////////////////////////////////////////////////////////////////
// File:   rv.h (Rebel Viewer)
// Author: Suren Talla
///////////////////////////////////////////////////////////////////////////////

#ifndef _RV_H
#define _RV_H


#include <stdlib.h>
#include "region.h"
#include "IR_outstream.h"
#include <iostream.h>
#include "el_data.h"
#include "ir_data.h"
#include "ir_jumptbl.h"
#include "opcode.h"
#include "opcode_cmpp.h"
#include "opcode_load_store.h"


extern const char Q;


IR_outstream &operator<<(IR_outstream &out, const Elcor_region_flag flag);
IR_outstream &operator<<(IR_outstream &out, const Hash_set<Edge*> &edges);


extern IR_outstream *gdl_stream;
extern IR_instream  *rebel_stream;

extern int main_rview(int argc, char **argv, char** envp);

extern int all_hbs_bbs(Procedure*, Dlist<Region*>&);

extern IR_outstream& cfg_to_gdl(IR_instream& in, IR_outstream &out, char* procedure_name);
extern IR_outstream& region_to_gdl(IR_outstream &, char* proc_name, Region *, double);
extern IR_outstream& datalist_to_gdl(IR_outstream &out, El_datalist *datalist);
extern IR_outstream& op_to_gdl(IR_outstream &out, const Op &op);
extern IR_outstream& data_to_gdl(IR_outstream &out, El_data *data);
extern IR_outstream& operand_to_gdl(IR_outstream &out, Operand &op);
extern IR_outstream& sched_to_gdl(IR_instream& in, IR_outstream &out);
extern IR_outstream& ddg_to_gdl(IR_instream& in, IR_outstream &out);
extern IR_outstream& region_hierarchy_to_gdl(IR_instream& in, IR_outstream &out);
extern IR_outstream& bb_dfg_to_gdl(IR_outstream &out, Region* region, int bb_id);

extern IR_outstream& elcor_misc_to_gdl(IR_instream& in, IR_outstream &out);
extern IR_outstream& proc_cfg_to_gdl(IR_outstream &out, Procedure* f);

extern int dump_extra_color_entries(IR_outstream& out);

extern IR_outstream& op_to_asm_to_gdl(IR_outstream &out, const Op &op);
extern IR_outstream& operand_to_asm_to_gdl(IR_outstream &out, Operand &oper);
extern IR_outstream& liveness_to_gdl(IR_outstream &out, Liveness_info* liveness);
extern int proc_sched_to_gdl(IR_outstream &, Procedure*, int, int);
extern int stats_to_gdl();
extern IR_outstream& names_to_gdl(IR_instream& in, IR_outstream &out);
extern int proc_stats_to_gdl(IR_outstream &, Region*, int, int, double);

extern int    options_consistent();
extern int    op_node_color(Op*);
extern int    region_freq_color(double freq, double max_freq);
extern double region_max_freq(Region* r);
extern double procedure_total_cycle_count(Region*);
extern char*  operand_to_asm_to_gdl_buf(IR_outstream &, Operand &, char*);




extern void El_compute_elcor_resource(Procedure* f);
extern void test_res_len_dep_len(Procedure* f);
extern void test_critical_region_class(Procedure* f);
extern void test_flow_chains(Procedure* f);
extern void create_local_analysis_info (Compound_region* r);
extern void delete_local_analysis_info (Compound_region* r);
extern void create_local_analysis_info_for_all_hbs_bbs(Compound_region* r);
extern void delete_local_analysis_info_for_all_hbs_bbs(Compound_region* r);



//----------------------------------------------------------------
extern void el_init_elcor_opcode_to_symbol_maps_arithmetic();

extern void el_init_elcor_opcode_to_symbol_maps_cmpp1_1();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp1_2();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp1_3();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp1_4();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp1_5();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp1_6();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp1_7();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp1_8();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp1();

extern void el_init_elcor_opcode_to_symbol_maps_cmpp2_1();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp2_2();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp2_3();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp2_4();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp2_5();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp2_6();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp2_7();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp2_8();
extern void el_init_elcor_opcode_to_symbol_maps_cmpp2();

extern void el_init_elcor_opcode_to_symbol_maps_fcmpp1_1();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp1_2();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp1_3();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp1_4();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp1_5();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp1_6();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp1_7();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp1();

extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2_1();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2_2();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2_3();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2_4();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2_5();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2_6();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2_7();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2_8();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2_9();
extern void el_init_elcor_opcode_to_symbol_maps_fcmpp2();

extern void el_init_elcor_opcode_to_symbol_maps_memory_1();
extern void el_init_elcor_opcode_to_symbol_maps_memory_2();
extern void el_init_elcor_opcode_to_symbol_maps_memory_3();
extern void el_init_elcor_opcode_to_symbol_maps_memory_4();
extern void el_init_elcor_opcode_to_symbol_maps_memory_5();
extern void el_init_elcor_opcode_to_symbol_maps_memory_6();
extern void el_init_elcor_opcode_to_symbol_maps_memory_7();
extern void el_init_elcor_opcode_to_symbol_maps_memory_8();
extern void el_init_elcor_opcode_to_symbol_maps_memory_9();
extern void el_init_elcor_opcode_to_symbol_maps_memory_10();
extern void el_init_elcor_opcode_to_symbol_maps_memory_11();
extern void el_init_elcor_opcode_to_symbol_maps_memory_12();
extern void el_init_elcor_opcode_to_symbol_maps_memory_13();
extern void el_init_elcor_opcode_to_symbol_maps_memory_14();
extern void el_init_elcor_opcode_to_symbol_maps_memory_15();
extern void el_init_elcor_opcode_to_symbol_maps_memory_16();
extern void el_init_elcor_opcode_to_symbol_maps_memory_17();
extern void el_init_elcor_opcode_to_symbol_maps_memory_18();
extern void el_init_elcor_opcode_to_symbol_maps_memory_19();
extern void el_init_elcor_opcode_to_symbol_maps_memory();

extern void el_init_elcor_opcode_to_symbol_maps_misc();
extern void el_init_elcor_base_opcode_to_symbol_maps();

extern void el_init_elcor_opcode_to_symbol_maps();



#endif  // _RV_H
